import { Audit } from "../Common/Audit.model";

export class NotificationDetails {
  notificationId: string;
  caseNo: string;
  contentManagementId: string;
  sendTimeStamp: number;
  subjectText: string;
  tolist: Array<string> = new Array<string>();
  ccList: Array<string> = new Array<string>();
  bccList: Array<string> = new Array<string>();
  notificationStatus: string;
  htmlDocumentData: string;
  initiatedBy: string;
  audit: Audit = new Audit();
  fromEmail: string;
  targetType: string;
  notificationGrpId: number;
  eventId: string;
  parentNotificationId: string;

  constructor() {}
}
