export class AiaReviewDocket {
  serialVersionUID: number;
  createUserId: number;
  proceedingId: number;
  proceedingPartyGroupId: number;
  filingDate: string;
  noticeAccordedFilingDate: string;
  poPreliminaryRespFilingDate: string;
  instDecisionDate: string;
  terminationDecisionDate: string;
  userRole: string;
  partyRepresent: string;
  proceedingNo: string;
  proceedingTypeCd: string;
  poPetitionerName: string;
  patentOwnerName: string;
  petitionerPatentNumber: string;
  petitionerApplicationNumber: string;
  poApplicationNumber: string;
  poPatentNumber: string;
  poRealParty: string;
  petitionerRealParty: string;
  status: string;
  userPartyGroupType: string;
  prcdCreatedTs: string;
  lastModifiedTimestamp: string;
  judges: Array<string> = new Array<string>();
  petiTechCenterId: string;
  poTechCenterId: string;

  constructor() {}
}
