import { PetitionDocument } from "../Common/PetitionDocuments/PetitionDocument.model";

export class ExternalUserRehearing {
  rehearingId: number;
  rehearingTypeId: number;
  rehearingTypeNm: string;
  rehearingStatusId: number;
  rehearingStatusName: string;
  rehearingStatusDisplayName: string;
  requestorTypeId: number;
  requestorTypeName: string;
  filedDate: string;
  decisionDate: string;
  proceedingId: number;
  proceedingNumber: string;
  userPartyGroupType: string;
  rehearingDocuments: Array<PetitionDocument> = new Array<PetitionDocument>();

  constructor() {}
}
