export class Audit {
  lastModifiedTimestamp: number;
  lastModifiedUserIdentifier: string;
  createUserIdentifier: string;
  createdUserName?: string;
  lastModifiedUserName?: string;
  createTimestamp?: number;
  lockControlNumber?: number;
  createdPrefferedName?: string;
  lastModifiedPrefferedName?: string;

  constructor() {}
}
