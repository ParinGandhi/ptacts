import { StndMilestoneType } from "./StndMilestoneType.model";

export class StndRecipientType {
  serialVersionUID: number;
  recipientTypeId: number;
  recipientTypeCd: string;
  descriptionTx: string;
  displayOrderSequenceNo: number;
  beginEffectiveDt: number;
  createTs: number;
  createUserId: number;
  endEffectiveDt: number;
  lastModTs: number;
  lastModUserId: number;
  lockControlNo: number;
  stndMilestoneTypes: Array<StndMilestoneType> = new Array<StndMilestoneType>();

  constructor() {}
}
