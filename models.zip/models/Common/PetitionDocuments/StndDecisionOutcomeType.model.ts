import { ProceedingMilestone } from "./ProceedingMilestone.model";

export class StndDecisionOutcomeType {
  serialVersionUID: number;
  decisionOutcomeTypeId: number;
  decisionOutcomeTypeCd: string;
  descriptionTx: string;
  displayOrderSequenceNo: number;
  beginEffectiveDt: number;
  createTs: number;
  createUserId: number;
  endEffectiveDt: number;
  lastModTs: number;
  lastModUserId: number;
  proceedingMilestones: Array<ProceedingMilestone> =
    new Array<ProceedingMilestone>();

  constructor() {}
}
