import { Values } from "./Values.model";

export class Userpicklist {
  dataType: string;
  label: string;
  refattribute: string;
  values: Array<Values> = new Array<Values>();

  constructor() {}
}
