import { StndMilestoneType } from "./StndMilestoneType.model";

export class StndMilestoneGroupType {
  serialVersionUID: number;
  milestoneGroupTypeId: number;
  beginEffectiveDt: number;
  createTs: number;
  createUserId: number;
  descriptionTx: string;
  displayOrderSequenceNo: number;
  endEffectiveDt: number;
  lastModTs: number;
  lastModUserId: number;
  milestoneGroupTypeNm: string;
  stndMilestoneTypes: Array<StndMilestoneType> = new Array<StndMilestoneType>();

  constructor() {}
}
