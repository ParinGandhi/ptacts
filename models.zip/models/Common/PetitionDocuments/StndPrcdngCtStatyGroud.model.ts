import { StndPrcdngCtStatyGroundId } from "./StndPrcdngCtStatyGroundId.model.js";
import { StndProceedingType } from "./StndProceedingType.model.js";
import { StndStatutoryGround } from "./StndStatutoryGround.model.js";

export class StndPrcdngCtStatyGround {
  serialVersionUID: number;
  id: StndPrcdngCtStatyGroundId;
  beginEffectiveDt: number;
  endEffectiveDt: number;
  lockControlNo: number;
  stndProceedingType: StndProceedingType;
  stndStatutoryGround: StndStatutoryGround;

  constructor() {}
}
