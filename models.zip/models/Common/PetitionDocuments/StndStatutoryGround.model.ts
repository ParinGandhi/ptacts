import { StndPrcdngCtStatyGround } from "./StndPrcdngCtStatyGroud.model";

export class StndStatutoryGround {
  serialVersionUID: number;
  statutoryGroundId: number;
  beginEffectiveDt: number;
  displayOrderSequenceNo: number;
  endEffectiveDt: number;
  lockControlNo: number;
  statutoryGroundCd: string;
  descriptionTx: string;
  stndPrcdngCtStatyGrounds: Array<StndPrcdngCtStatyGround> =
    new Array<StndPrcdngCtStatyGround>();

  constructor() {}
}
