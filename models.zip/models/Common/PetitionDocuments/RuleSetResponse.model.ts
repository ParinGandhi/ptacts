export class RuleSetResponse {
  proceedingIdentifier: number;
  proceedingNumber: string;
  patentNumber: string;
  proceedingCategory: string;
  proceedingStateId: number;
  parentCaseStatusHistoryIdentifier: string;
  currentStateIdentifier: number;
  targetStateIdentifier: number;
  ptabEventIdentifier: number;
  currentTaskIdentifier: number;
  targetTaskIdentifier: number;
  targetWorkerId: string;
  targetTaskType: string;
  palmTransaction: string;
  notificationRequireIndicator: string;
  documentUploadRequireIndicator: string;
  dueDateCalculationIndicator: string;
  dueDateCalculationIdentifier: string;
  isPalmTrsanctionPosted: boolean = false;
  userName: string;

  constructor() {}
}
