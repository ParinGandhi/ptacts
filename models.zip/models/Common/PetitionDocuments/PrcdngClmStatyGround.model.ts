import { PrcdngStatyGrndClmRsn } from "./PrcdngStatyGrndClmRsn.model";
import { ProceedingClaim } from "./ProceedingClaim.model";
import { StndFinalWrittenDcsn } from "./StndFinalWrittenDcsn.model";
import { StndInstDcsnType } from "./StndInstDcsnType.model";
import { StndStatutoryGround } from "./StndStatutoryGround.model";

export class PrcdngClmStatyGround {
  serialVersionUID: number;
  prcdngClmStatyGroundId: number;
  claimDispositionCt: string;
  fkProceedingClaimId: number;
  fkStatGroundId: number;
  fkInstDcsnTypeId: number;
  fkFinalWrtnDcsnId: number;
  lockControlNo: number;
  proceedingClaim: ProceedingClaim;
  stndFinalWrittenDcsn: StndFinalWrittenDcsn;
  stndInstDcsnType: StndInstDcsnType;
  stndStatutoryGround: StndStatutoryGround;
  prcdngStatyGrndClmRsns: Array<PrcdngStatyGrndClmRsn> =
    new Array<PrcdngStatyGrndClmRsn>();

  constructor() {}
}
