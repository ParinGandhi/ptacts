export class Values {
  id: string;
  text: string;

  constructor() {}
}
