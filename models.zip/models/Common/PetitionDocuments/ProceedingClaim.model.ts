import { PrcdngClmStatyGround } from "./PrcdngClmStatyGround.model";
import { ProceedingEntity } from "./ProceedingEntity.model";
import { StndFinalWrittenDcsn } from "./StndFinalWrittenDcsn.model";

export class ProceedingClaim {
  serialVersionUID: number;
  proceedingClaimId: number;
  claimNo: string;
  finalWrittenDcsnCmntTx: string;
  fkProceedingId: number;
  instDcsnCmntTx: string;
  fkclaimFinalWrittenDcsnId: number;
  lockControlNo: number;
  prcdngClmStatyGrounds: Array<PrcdngClmStatyGround> =
    new Array<PrcdngClmStatyGround>();
  stndFinalWrittenDcsn: StndFinalWrittenDcsn;
  proceeding: ProceedingEntity;

  constructor() {}
}
