import { ProceedingEntity } from "./ProceedingEntity.model";
import { StndDecisionOutcomeType } from "./StndDecisionOutcomeType.model";
import { StndMilestoneType } from "./StndMilestoneType.model";

export class ProceedingMilestone {
  serialVersionUID: number;
  proceedingMilestoneId: number;
  lockControlNo: number;
  fkProceedingId: number;
  fkMilestoneTypeId: number;
  milestoneDt: number;
  outcomeStatus: string;
  fkDecisionOutcomeTypeId: number;
  proceeding: ProceedingEntity;
  stndMilestoneType: StndMilestoneType;
  stndDecisionOutcomeType: StndDecisionOutcomeType;

  constructor() {}
}
