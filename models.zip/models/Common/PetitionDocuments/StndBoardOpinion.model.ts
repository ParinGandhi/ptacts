import { ProceedingEntity } from "./ProceedingEntity.model";

export class StndBoardOpinion {
  serialVersionUID: number;
  boardOpinionId: number;
  boardOpinionNm: string;
  descriptionTx: string;
  beginEffectiveDt: number;
  endEffectiveDt: number;
  displayOrderSequenceNo: number;
  createUserId: number;
  createTs: number;
  lastModUserId: number;
  lastModTs: number;
  lockControlNo: number;
  proceedings: Array<ProceedingEntity> = new Array<ProceedingEntity>();

  constructor() {}
}
