export class ReferenceSummary {
  identifier: number;
  code: string;
  descriptionText: string;
  displayNameText: string;

  constructor() {}
}
