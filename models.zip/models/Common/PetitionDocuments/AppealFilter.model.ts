export class AppealFilter {
  statusCodes: Array<string> = new Array<string>();

  constructor() {}
}
