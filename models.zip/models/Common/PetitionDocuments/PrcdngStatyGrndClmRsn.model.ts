import { ClaimChallengeReason } from "./ClaimChallengeReason.model";
import { PrcdngClmStatyGround } from "./PrcdngClmStatyGround.model";

export class PrcdngStatyGrndClmRsn {
  serialVersionUID: number;
  prcdngStatyGrndClmRsnId: number;
  fkPrcdgClmStayGroundId: number;
  fkPrcdgClmChallengeReasonId: number;
  claimChallengeReason: ClaimChallengeReason;
  prcdngClmStatyGround: PrcdngClmStatyGround;
  lockControlNo: number;

  constructor() {}
}
