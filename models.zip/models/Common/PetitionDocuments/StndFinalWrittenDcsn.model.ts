import { PrcdngClmStatyGround } from "./PrcdngClmStatyGround.model";
import { ProceedingClaim } from "./ProceedingClaim.model";

export class StndFinalWrittenDcsn {
  serialVersionUID: number;
  finalWrittenDcsnId: number;
  beginEffectiveDt: number;
  descriptionTx: string;
  displayOrderSequenceNo: number;
  endEffectiveDt: number;
  finalWrittenDcsnNm: string;
  prcdngClmStatyGrounds: Array<PrcdngClmStatyGround> =
    new Array<PrcdngClmStatyGround>();
  proceedingClaims: Array<ProceedingClaim> = new Array<ProceedingClaim>();

  constructor() {}
}
