import { PrcdngClmStatyGround } from "./PrcdngClmStatyGround.model";

export class StndInstDcsnType {
  serialVersionUID: number;
  instDcsnTypeId: number;
  beginEffectiveDt: number;
  descriptionTx: string;
  displayOrderSequenceNo: number;
  endEffectiveDt: number;
  instDcsnTypeNm: string;
  prcdngClmStatyGrounds: Array<PrcdngClmStatyGround> =
    new Array<PrcdngClmStatyGround>();

  constructor() {}
}
