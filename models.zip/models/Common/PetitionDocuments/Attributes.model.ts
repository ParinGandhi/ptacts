import { Userpicklist } from "./Userpicklist.model";

export class Attributes {
  id: number;
  label: string;
  dataType: string;
  uielementId: string;
  outcomeTypeId: number;
  value: string;
  mandatory: boolean = false;
  visibility: boolean = false;
  rolesForEdit: Array<string> = new Array<string>();
  userpicklist: Userpicklist;

  constructor() {}
}
