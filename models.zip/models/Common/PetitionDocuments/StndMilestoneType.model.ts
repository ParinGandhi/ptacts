import { ProceedingMilestone } from "./ProceedingMilestone.model";
import { StndMilestoneGroupType } from "./StndMilestoneGroupType.model";
import { StndRecipientType } from "./StndRecipientType.model";

export class StndMilestoneType {
  serialVersionUID: number;
  milestoneTypeId: number;
  beginEffectiveDt: number;
  createTs: number;
  createUserId: number;
  descriptionTx: number;
  displayOrderSequenceNo: number;
  endEffectiveDt: number;
  lastModTs: number;
  lastModUserId: number;
  milestoneTypeNm: number;
  fkPrntMlstnTypeId: number;
  fkReceipentTypeId: number;
  dateCalcRefId: number;
  dateCalcRefIds: number;
  fkMlstnIdsToClr: number;
  proceedingMilestones: Array<ProceedingMilestone> =
    new Array<ProceedingMilestone>();
  stndMilestoneGroupType: StndMilestoneGroupType;
  stndRecipientType: StndRecipientType;

  constructor() {}
}
