import { AppealFilter } from "./AppealFilter.model";
import { Attributes } from "./Attributes.model";

export class DocumentTypeCustomAttributes {
  motionTypeIds: Array<number> = new Array<number>();
  rehearingIds: Array<number> = new Array<number>();
  attributes: Array<Attributes> = new Array<Attributes>();
  appealFilter: AppealFilter;

  constructor() {}
}
