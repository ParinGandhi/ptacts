import { PrcdngStatyGrndClmRsn } from "./PrcdngStatyGrndClmRsn.model";

export class ClaimChallengeReason {
  serialVersionUID: number;
  claimChallengeReasonId: number;
  claimReasonTx: string;
  lockControlNo: number;
  prcdngStatyGrndClmRsns: Array<PrcdngStatyGrndClmRsn> =
    new Array<PrcdngStatyGrndClmRsn>();

  constructor() {}
}
