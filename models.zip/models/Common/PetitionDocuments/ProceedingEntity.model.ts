import { ProceedingMilestone } from "./ProceedingMilestone.model";
import { StndBoardOpinion } from "./StndBoardOpinion.model";
import { StndInstDcsnType } from "./StndInstDcsnType.model";
import { StndProceedingType } from "./StndProceedingType.model";
import { StndTerminationType } from "./StndTerminationType.model";

export class ProceedingEntity {
  serialVersionUID: number;
  proceedingId: number;
  proceedingNameTx: string;
  patentNo: string;
  proceedingNo: string;
  patentOwnerNm: string;
  fiscalYearNo: number;
  claimListTx: string;
  challengedClaimQt: number;
  terminationTypeId: number;
  confidentialityIn: string;
  contentManagementPathDir: string;
  proceedingHeaderTx: string;
  lockControlNo: number;
  preliminaryResponseFiledIn: string;
  fkBoardOpinionId: string;
  fkInstDcsnTypeId: string;
  authorizePaymentIn: string;
  institutedClaimQt: string;
  sourceSytemCt: string;
  fkProceedingTypeId: string;
  stndTerminationType: StndTerminationType;
  stndProceedingType: StndProceedingType;
  stndBoardOpinion: StndBoardOpinion;
  stndInstDcsnType: StndInstDcsnType;
  proceedingMileStones: Array<ProceedingMilestone> =
    new Array<ProceedingMilestone>();

  constructor() {}
}
