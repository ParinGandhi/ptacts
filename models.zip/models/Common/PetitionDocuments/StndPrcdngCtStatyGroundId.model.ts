export class StndPrcdngCtStatyGroundId {
  serialVersionUID: number;
  fkStatutoryGroundId: number;
  fkProceedingTypeId: number;

  constructor() {}
}
