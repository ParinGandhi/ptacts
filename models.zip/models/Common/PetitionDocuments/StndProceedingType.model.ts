import { ProceedingEntity } from "./ProceedingEntity.model";
import { StndPrcdngCtStatyGround } from "./StndPrcdngCtStatyGroud.model";

export class StndProceedingType {
  serialVersionUID: number;
  proceedingTypeId: number;
  beginEffectiveDt: number;
  displayOrderSequenceNo: number;
  endEffectiveDt: number;
  proceedingTypeCd: string;
  proceedingTypeDescTx: string;
  proceedings: Array<ProceedingEntity> = new Array<ProceedingEntity>();
  stndPrcdngCtStatyGrounds: Array<StndPrcdngCtStatyGround> =
    new Array<StndPrcdngCtStatyGround>();

  constructor() {}
}
