import { ProceedingEntity } from "./ProceedingEntity.model";

export class StndTerminationType {
  serialVersionUID: number;
  terminationTypeId: number;
  beginEffectiveDt: number;
  descriptionTx: string;
  displayOrderSequenceNo: number;
  endEffectiveDt: number;
  lockControlNo: number;
  terminationTypeNm: string;
  proceedings: ProceedingEntity;

  constructor() {}
}
