import { PetitionDocument } from "../Common/PetitionDocuments/PetitionDocument.model";

export class AppealDetails {
  proceedingAppealId: number;
  appealTypeId: number;
  appealTypeNm: string;
  requestorTypeName: string;
  userRole: string;
  appealStatusId: number;
  appealStatusCd: string;
  appealNoticeDt: string;
  courtDecisionDt: string;
  courtMandateDt: string;
  exteralCourtDecisionBy: string;
  proceedingId: number;
  proceedingNo: string;
  userPartyGroupType: string;
  filingDate: string;
  appealDocuments: Array<PetitionDocument> = new Array<PetitionDocument>();

  constructor() {}
}
