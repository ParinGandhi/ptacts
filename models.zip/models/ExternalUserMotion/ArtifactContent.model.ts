export class ArtifactContent {
  documentName: string;
  paperNumber: number;
  exhibitNumber: number;

  constructor() {}
}
