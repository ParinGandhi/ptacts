import { PetitionDocument } from "../Common/PetitionDocuments/PetitionDocument.model";
import { ArtifactContent } from "./ArtifactContent.model";

export class ExternalUserMotion {
  motionId: number;
  requestorTypeId: number;
  requestorTypeName: string;
  filedDate: string;
  userDefinedMotionName: string;
  motionTypeId: number;
  motionTypeNm: string;
  motionStatusId: number;
  motionStatusName: string;
  motionStatusDate: string;
  proceedingId: number;
  proceedingNumber: string;
  userPartyGroupType: string;
  motionDocuments: Array<PetitionDocument> = new Array<PetitionDocument>();
  parentMotionId: number;
  commentText: string;
  artifactRoleName: string;
  artifactContent: Array<ArtifactContent> = new Array<ArtifactContent>();
  documentName: string;
  paperNumber: number;
  exhibitNumber: number;

  constructor() {}
}
