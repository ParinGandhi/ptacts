window.runtimeConfig = {
  dns_endpoint: "{{ dns_endpoint }}",
};
