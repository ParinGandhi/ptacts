#!/usr/bin/env bash

set -euo pipefail
set -x

export BA_S3_BUCKET="$BA_S3_BUCKET" # Like my-s3-bucket
export BA_API_GATEWAY_DOMAIN="$BA_API_GATEWAY_DOMAIN" # Like 0000000000.execute-api.us-east-1.amazonaws.com
export BA_API_GATEWAY_STAGE="$BA_API_GATEWAY_STAGE" # Like /Prod
#export FAD_API_GATEWAY_COGNITO_DOMAIN="$FAD_API_GATEWAY_COGNITO_DOMAIN" # api-okta-oidc-poc
#export FAD_API_GATEWAY_COGNITO_REGION="$FAD_API_GATEWAY_COGNITO_REGION" # us-east-1
#export FAD_COGNITO_APP_CLIENT_ID="$FAD_COGNITO_APP_CLIENT_ID" # 6gmp1kuva4u9tmn3sahqj4dgdr
#export FAD_API_GATEWAY_REDIRECT_URL="$FAD_API_GATEWAY_REDIRECT_URL" # https://poc.dashboard.healthcare.gov
#export IDP_LOGOUT_URI="$IDP_LOGOUT_URI" #Like https://dev-02582761.okta.com/login/signout

mkdir -p dist

envsubst $'
$BA_API_GATEWAY_DOMAIN
$BA_API_GATEWAY_STAGE
' <public-deploy/resourceUrls.json.envsubst >dist/resourceUrls.json

aws s3 sync dist "s3://$BA_S3_BUCKET"

# Work around svg files having the wrong content-type in S3
pushd dist
find . -type f -name '*.svg' -exec sh -c 'aws s3 cp --content-type image/svg+xml "$1" "s3://$BA_S3_BUCKET/$(printf %q "$1" | cut -c3-)"' _ {} ';'
popd
