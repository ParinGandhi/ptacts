import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

export const AuthGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const cookieService = inject(CookieService);

  let canProceed = true;
  let sessionCookie = cookieService.get('sessionId');
  console.log('Session cookie:', sessionCookie);
  if (canProceed) {
    return true;
  } else {
    router.navigate(['/login']);
    return false;
  }
};
