import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { CONSTANTS } from '../constants/batch-admin.constants';
import { IAlertsInfo } from '../models/AlertsInfo.model';
import { ToastrService } from 'ngx-toastr';
import { formatDate } from '@angular/common';
// import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root',
})
export class CommonUtilitiesService {
  constructor(private toastr: ToastrService) {}

  logger(
    logType: string,
    logMessage: string | any,
    componentName: string,
    functionName: string
  ) {
    if (!environment.production) {
      const message = this.setMessage(logMessage);
      switch (logType) {
        case CONSTANTS.LOGTYPES.INFO:
          console.info(`${message} | ${componentName} | ${functionName}`);
          break;
        case CONSTANTS.LOGTYPES.LOG:
          console.log(`${message} | ${componentName} | ${functionName}`);
          break;
        case CONSTANTS.LOGTYPES.ERROR:
          console.error(`${message} | ${componentName} | ${functionName}`);
          break;
        default:
          break;
      }
    } else {
      const message = this.setMessage(logMessage);
      switch (logType) {
        case CONSTANTS.LOGTYPES.ERROR:
          console.error(`${message} | ${componentName} | ${functionName}`);
          break;
        default:
          break;
      }
    }
  }

  setAlert(alertType: string, alertMessage: any) {
    const message = this.setMessage(alertMessage);
    const alertInfo: IAlertsInfo = {
      alertType: alertType,
      message: message,
    };
    return alertInfo;
  }

  setMessage(alertMessage: any) {
    let message;
    if (typeof alertMessage === 'string') {
      message = alertMessage;
    } else {
      message = alertMessage?.error?.error
        ? alertMessage?.error?.error
        : alertMessage?.error?.message;
    }
    return message;
  }

  setToastr(toastType: string, title: string, toastMsg: string) {
    const message = this.setMessage(toastMsg);
    switch (toastType) {
      case CONSTANTS.TOASTR_TYPES.INFO:
        this.toastr.info(message, title);
        break;
      case CONSTANTS.TOASTR_TYPES.SUCCESS:
        this.toastr.success(message, title);
        break;
      case CONSTANTS.TOASTR_TYPES.ERROR:
        this.toastr.error(message, title);
        break;
      default:
        break;
    }
  }

  convertToEST(date: Date): string | null {
    const utcDate = new Date(date);
    const zone = utcDate
      .toLocaleString('en-US', {
        timeStyle: 'long',
        timeZone: 'America/New_York',
      })
      .split(' ')[2];
    // EST is UTC-5 and EDT is UTC-4
    const offset = zone === 'EST' ? -5 : -4;
    const estDate = new Date(utcDate.setHours(utcDate.getUTCHours() + offset));
    // format to YYYY-MM-DD
    this.logger(
      'info',
      `Original date: ${date}`,
      'commonUtilities',
      'convertToEST'
    );
    this.logger(
      'info',
      `Formatted date: ${estDate.toISOString().split('T')[0]}`,
      'commonUtilities',
      'convertToEST'
    );

    return estDate.toISOString().split('T')[0];
  }
}
