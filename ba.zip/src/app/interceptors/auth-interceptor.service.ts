import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpResponse,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, from, Observable, tap, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthInterceptorService implements HttpInterceptor {
  constructor(private router: Router) {}

  intercept(
    req: HttpRequest<unknown>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    console.log('REQ FROM INT:', req);
    // if (req.url.includes('/verify-mfa'))
    //   req = req.clone({
    //     withCredentials: true,
    //   });
    // req = req.clone({
    //   setHeaders: {
    //     sessionId: 'ab32477a-dec8-46ff-8223-4daacf11fb47',
    //   },
    // });
    // return next.handle(req).pipe(
    //   tap((event: HttpEvent<any>) => {
    //     if (event instanceof HttpResponse) {
    //       const setCookieHeader = event.headers.get('Set-Cookie');
    //       if (setCookieHeader) {
    //         const cookies = setCookieHeader.split(';');
    //         cookies.forEach((cookie) => {
    //           const [name, value] = cookie.trim().split('=');
    //           console.log('Name', name);
    //           console.log('Value', value);
    //           // this.cookieService.set(name, value);
    //         });
    //       }
    //     }
    //   })
    // );

    req = req.clone({
      withCredentials: true,
      headers: req.headers.append('rejectUnauthorized', 'false'),
    });

    return next.handle(req).pipe(
      catchError((error: HttpErrorResponse) => {
        if (error.status === 401 || error.status === 403) {
          console.error('Unauthorized access');
          this.router.navigate(['/login']); // Redirect to login page
        }
        return throwError(() => error);
      })
    );

    // return next.handle(req);
  }
}
