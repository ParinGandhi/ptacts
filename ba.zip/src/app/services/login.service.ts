import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  dns_endpoint = (window as any).runtimeConfig?.dns_endpoint;

  constructor(private http: HttpClient) {
    console.log(environment.ENV);
  }

  login(credentials: any): Observable<any> {
    return this.http
      .post(`${this.dns_endpoint}${environment.LOGIN}`, credentials)
      .pipe(
        map((loginResponse) => {
          return loginResponse;
        })
      );
  }

  createNewPassword(credentials: any): Observable<any> {
    return this.http
      .post(`${this.dns_endpoint}${environment.RESET_PASSWORD}`, credentials)
      .pipe(
        map((newPasswordResponse) => {
          return newPasswordResponse;
        })
      );
  }

  setupMfa(mfaRequest: any) {
    return this.http
      .post(`${this.dns_endpoint}${environment.SETUP_MFA}`, mfaRequest)
      .pipe(
        map((mfaResponse) => {
          return mfaResponse;
        })
      );
  }

  verifyMfa(mfaRequest: any) {
    return this.http
      .post(`${this.dns_endpoint}${environment.VERIFY_MFA}`, mfaRequest, {
        observe: 'response',
      })
      .pipe(
        map((mfaResponse) => {
          console.log('MFA Response:', mfaResponse);
          return mfaResponse;
        })
      );
  }

  logout(logoutRequest: any) {
    return this.http
      .post(`${this.dns_endpoint}${environment.LOGOUT}`, logoutRequest)
      .pipe(
        map((logoutResponse) => {
          return logoutResponse;
        })
      );
  }
}
