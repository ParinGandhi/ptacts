import { Injectable } from '@angular/core';
import { MPMSJob } from '../models/MPMSJob.model';
import { IRunParam } from '../models/RunParam.model';
import { CommonUtilitiesService } from '../utils/common-utilities.service';
import { CONSTANTS } from '../constants/batch-admin.constants';
import { EEJob } from '../models/EEJob.model';

@Injectable({
  providedIn: 'root',
})
export class RunBatchHelperService {
  constructor(private commonUtils: CommonUtilitiesService) {}

  setupMPMSJob(selectedListing: any, selectedBatch: any): MPMSJob {
    const mpmsRunJobObj: MPMSJob = new MPMSJob(selectedListing, selectedBatch);

    let paramVals: Array<IRunParam> = [];
    selectedBatch.runParams.forEach((param: any) => {
      const runParam: IRunParam = {
        param: param.param,
        value: this.checkForSreFAVO(selectedBatch, param.defaultValue),
      };
      if (runParam.value) {
        mpmsRunJobObj.runParameters.push(runParam);
      }
      paramVals.push(this.checkForSreFAVO(selectedBatch, param.defaultValue));
    });

    paramVals = paramVals.filter((element: any) => {
      return element !== undefined;
    });

    const paramStr = paramVals.join('-');
    mpmsRunJobObj.name = `${
      mpmsRunJobObj.name
    }${paramStr}-${selectedListing.environment.toLowerCase()}`;
    this.commonUtils.logger(
      CONSTANTS.LOGTYPES.INFO,
      `New run batch: ${mpmsRunJobObj}`,
      'batch-listing.component',
      'runJob'
    );

    return mpmsRunJobObj;
  }

  setupEEJob(selectedListing: any, selectedBatch: any): EEJob {
    const eeRunJobObj: EEJob = new EEJob(selectedListing, selectedBatch);

    selectedBatch.runParams.forEach((param: any) => {
      const runParam: IRunParam = {
        param: param.param,
        value: this.checkForSreFAVO(selectedBatch, param.defaultValue),
      };
      if (runParam.value) {
        eeRunJobObj.runParameters.push(runParam);
      }
    });

    return eeRunJobObj;
  }

  setupMPMSReRunJob(
    selectedBatch: any,
    allBatchDetails: any,
    jobToReRun: any
  ): MPMSJob {
    const mpmsReRunJobObj: MPMSJob = new MPMSJob(
      selectedBatch,
      allBatchDetails
    );

    const fullName: any = [];

    /** Setting up run params */
    selectedBatch.params.forEach((originalParam: any) => {
      console.log(originalParam);
      jobToReRun.execution_params.forEach((param: any) => {
        if (
          originalParam.param.toLowerCase() ===
          param.parameter_name.toLowerCase()
        ) {
          const runParam: IRunParam = {
            param: param.parameter_name,
            value: param.parameter_value,
          };
          mpmsReRunJobObj.runParameters.push(runParam);
          fullName.push(param.parameter_value.toLowerCase());
        }
      });
    });

    mpmsReRunJobObj.name = `${mpmsReRunJobObj.name}${fullName.join(
      '-'
    )}-${mpmsReRunJobObj?.environment?.toLowerCase()}`;

    this.commonUtils.logger(
      CONSTANTS.LOGTYPES.INFO,
      `Specific job:, ${jobToReRun}`,
      'job-execution-listing.component',
      'rereunJob'
    );
    this.commonUtils.logger(
      CONSTANTS.LOGTYPES.INFO,
      `New payload: ${mpmsReRunJobObj}`,
      'job-execution-listing.component',
      'rereunJob'
    );

    return mpmsReRunJobObj;
  }

  checkForSreFAVO(selectedBatch: any, selectedVal: any) {
    let paramVal = selectedVal;
    if (
      selectedBatch?.name?.toLowerCase() == 'sreextract' &&
      selectedVal?.toLowerCase() == 'full_app_version_only'
    ) {
      paramVal = 'favo';
    }
    return paramVal;
  }
}
