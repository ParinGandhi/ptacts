import { TestBed } from '@angular/core/testing';

import { RunBatchHelperService } from './run-batch-helper.service';

describe('RunBatchHelperService', () => {
  let service: RunBatchHelperService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RunBatchHelperService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
