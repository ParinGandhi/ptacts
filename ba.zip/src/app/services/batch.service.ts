import { Injectable, signal } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, count, delay, map, Observable, retry } from 'rxjs';
import { environment } from '../../environments/environment';
import { BatchListing } from '../models/batch-listing/BatchListing';

@Injectable({
  providedIn: 'root',
})
export class BatchService {
  dns_endpoint = (window as any).runtimeConfig?.dns_endpoint;
  menuItemsBS = new BehaviorSubject({});
  menuItems = this.menuItemsBS.asObservable();

  constructor(private http: HttpClient) {}

  listJobs() {
    return this.http.get(`${this.dns_endpoint}${environment.LIST_JOBS}`).pipe(
      // return this.http.get('../../assets/payloads/list-jobs-response.json').pipe(
      map((listJobsResponse: any) => {
        const env: any = [];
        const tower: any = [];
        const batchapp: any = [];
        listJobsResponse.forEach((job: any) => {
          (job.runningInstances = null), (job.lastExecutedDatetime = null);
          env.push(job.environment);
          tower.push(job.appName);
          job.batches.forEach((batch: any) => {
            batchapp.push(batch.applicationName);
          });
        });
        const items = {
          env: [...new Set(env)],
          tower: [...new Set(tower)],
          batchapp: [...new Set(batchapp)],
        };
        this.menuItemsBS.next(items);
        return listJobsResponse;
      })
    );
  }

  getJobStatus(jobInfo: any) {
    return this.http
      .post(`${this.dns_endpoint}${environment.JOB_STATUS}`, jobInfo)
      .pipe(
        // retry({
        //   delay: 1500,
        //   count: 3,
        // }),
        map((logoutResponse) => {
          return logoutResponse;
        })
      );
  }

  getFrequencyStat(batchInfo: any) {
    return this.http
      .post(`${this.dns_endpoint}${environment.FREQUENCY_STAT}`, batchInfo)
      .pipe(
        // retry({ delay: 1000, count: 5 }),
        map((logoutResponse) => {
          return logoutResponse;
        })
      );
  }

  verifyUserAccess() {
    return this.http
      .get(`${this.dns_endpoint}${environment.VERIFY_USER_ACCESS}`)
      .pipe(
        map((userAccessResponse: any) => {
          return userAccessResponse;
        })
      );
  }

  runBatch(runBatchObj: any) {
    return this.http
      .post(`${this.dns_endpoint}${environment.BATCH_RUN}`, runBatchObj)
      .pipe(
        map((runBatchResponse) => {
          return runBatchResponse;
        })
      );
  }

  stopBatch(batchToStop: any) {
    return this.http
      .post(`${this.dns_endpoint}${environment.STOP_JOB}`, batchToStop)
      .pipe(
        map((stopBatchResponse) => {
          return stopBatchResponse;
        })
      );
  }

  updateJobsConfig(jobsConfig: any) {
    return this.http
      .post(`${this.dns_endpoint}${environment.UPDATE_JOBS_CONFIG}`, jobsConfig)
      .pipe(
        map((updateConfigResponse) => {
          return updateConfigResponse;
        })
      );
  }
}
