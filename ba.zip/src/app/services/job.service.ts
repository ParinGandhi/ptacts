import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class JobService {
  dns_endpoint = (window as any).runtimeConfig?.dns_endpoint;

  constructor(private http: HttpClient) {}

  getJobDetails(jobDetailsInfo: any) {
    return this.http
      .post(`${this.dns_endpoint}${environment.JOB_DETAILS}`, jobDetailsInfo)
      .pipe(
        map((jobDetailsResponse) => {
          return jobDetailsResponse;
        })
      );
  }

  getJobSummary(jobSummaryPayload: any) {
    return this.http
      .post(`${this.dns_endpoint}${environment.JOB_SUMMARY}`, jobSummaryPayload)
      .pipe(
        map((jobSummaryResponse) => {
          return jobSummaryResponse;
        })
      );
  }
}
