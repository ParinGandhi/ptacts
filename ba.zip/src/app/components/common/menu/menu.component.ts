import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { BatchService } from '../../../services/batch.service';

@Component({
  selector: 'app-menu',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './menu.component.html',
  styleUrl: './menu.component.css',
})
export class MenuComponent implements OnInit {
  menuItems: any;

  selectedEnvironment: string = 'All';
  environments: string[] = [];

  selectedTower: string = 'All';
  towers: string[] = [];

  selectedBatchApplication: string = 'All';
  batchApplications: string[] = [];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private batchService: BatchService
  ) {
    this.batchService.menuItems.subscribe({
      next: (items: any) => {
        this.environments = items.env;
        this.towers = items.tower;
        this.batchApplications = items.batchapp;
      },
    });
  }

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      const currentRoute = location.pathname;
      if (currentRoute.includes('batches')) {
        this.selectedEnvironment = params['env'] || 'All';
        this.selectedTower = params['tower'] || 'All';
        this.selectedBatchApplication = params['batchapp'] || 'All';
      }
    });
  }

  selectEnvironment(env: string) {
    this.selectedEnvironment = env; // Update the selected environment
    this.router.navigate(['/batches'], {
      queryParams: {
        env: env,
        tower: this.selectedTower,
        batchapp: this.selectedBatchApplication,
      },
    });
  }

  selectTower(tower: string) {
    this.selectedTower = tower; // Update the selected tower
    this.router.navigate(['/batches'], {
      queryParams: {
        env: this.selectedEnvironment,
        tower: tower,
        batchapp: this.selectedBatchApplication,
      },
    });
  }

  selectBatchApplication(batchApp: string) {
    this.selectedBatchApplication = batchApp; // Update the selected batch application
    this.router.navigate(['/batches'], {
      queryParams: {
        env: this.selectedEnvironment,
        tower: this.selectedTower,
        batchapp: batchApp,
      },
    });
  }

  resetFilters() {
    this.selectedEnvironment = 'All';
    this.selectedTower = 'All';
    this.selectedBatchApplication = 'All';
    this.router.navigate(['/batches']);
  }
}
