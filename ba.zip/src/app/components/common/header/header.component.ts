import { Component } from '@angular/core';
import { RouterOutlet, Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { CommonModule } from '@angular/common';
import { LoginService } from '../../../services/login.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
})
export class HeaderComponent {
  showHeader: boolean = true;
  loggingOut: boolean = false;

  constructor(private router: Router, private loginService: LoginService) {
    // Listen to route changes
    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        // Show menu unless the URL is '/', '/main', '/login' or '/mfa'
        this.showHeader = !(
          event.url === '/' ||
          event.url === '/login' ||
          event.url === '/mfa' ||
          event.url === '/main' ||
          event.url === '/new-password' ||
          event.url === '/setup-mfa'
        );
      });
  }

  logout() {
    // Redirect to the login page
    this.loggingOut = true;
    const logoutRequest = {
      sessionId: window.sessionStorage.getItem('sessionId'),
    };
    this.loginService.logout(logoutRequest).subscribe({
      next: (logoutRequest: any) => {
        console.log(logoutRequest);
        window.sessionStorage.clear();
        this.loggingOut = false;
        this.router.navigate(['/login']);
      },
      error: (e) => {
        console.log(e)
        window.sessionStorage.clear();
        this.loggingOut = false;
        this.router.navigate(['/login']);
      },
      complete: () => console.info('complete'),
    });
  }
}
