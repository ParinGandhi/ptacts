import { CommonModule } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { IAlertsInfo } from '../../../models/AlertsInfo.model';
import { CONSTANTS } from '../../../constants/batch-admin.constants';

@Component({
  selector: 'app-alerts',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './alerts.component.html',
  styleUrl: './alerts.component.css',
})
export class AlertsComponent implements OnInit {
  @Input() alertInfo!: IAlertsInfo;
  alertTypes = CONSTANTS.ALERTS;

  ngOnInit(): void {
    console.log(this.alertInfo);
  }
}
