import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-no-records-found',
  standalone: true,
  imports: [],
  templateUrl: './no-records-found.component.html',
  styleUrl: './no-records-found.component.css',
})
export class NoRecordsFoundComponent {
  @Input() columnSpan!: number;
  @Input() message!: string;
}
