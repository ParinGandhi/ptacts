import { Component } from '@angular/core';

@Component({
  selector: 'app-refresh-table-btn',
  standalone: true,
  imports: [],
  templateUrl: './refresh-table-btn.component.html',
  styleUrl: './refresh-table-btn.component.css',
})
export class RefreshTableBtnComponent {
  reloadTable() {
    location.reload();
  }
}
