import { CommonModule } from '@angular/common';
import {
  AfterViewInit,
  Component,
  ElementRef,
  OnInit,
  ViewChild,
} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../../../../services/login.service';
import { QRCodeModule } from 'angularx-qrcode';
import { AlertsComponent } from '../../../common/alerts/alerts.component';
import { IAlertsInfo } from '../../../../models/AlertsInfo.model';
import { CONSTANTS } from '../../../../constants/batch-admin.constants';
import { CommonUtilitiesService } from '../../../../utils/common-utilities.service';

@Component({
  selector: 'app-setup-mfa',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    QRCodeModule,
    AlertsComponent,
  ],
  templateUrl: './setup-mfa.component.html',
  styleUrl: './setup-mfa.component.css',
})
export class SetupMfaComponent implements OnInit, AfterViewInit {
  @ViewChild('mfaInput') mfaInput!: ElementRef;

  setupMfaForm!: FormGroup;
  mfaSetupQRCode: string = '';
  validating: boolean = false;
  email: string | null = null;
  loadingQRCode: boolean = false;
  alertInfo: IAlertsInfo = {
    alertType: null,
    message: null,
  };

  constructor(
    private router: Router,
    private loginService: LoginService,
    private commonUtils: CommonUtilitiesService,
    private formBuilder: FormBuilder
  ) {
    this.email = this.router.getCurrentNavigation()?.extras.state?.['email'];
  }

  ngOnInit(): void {
    this.createSetupMfaForm();
  }

  ngAfterViewInit() {
    this.mfaInput.nativeElement.focus();
    this.getQRCodeSecret();
  }

  createSetupMfaForm() {
    this.setupMfaForm = this.formBuilder.group({
      mfaCode: ['', Validators.required],
    });
  }

  getQRCodeSecret() {
    this.loadingQRCode = true;
    const mfaRequest = {
      otp: '',
      session: window.sessionStorage.getItem('session'),
    };
    this.loginService.setupMfa(mfaRequest).subscribe({
      next: (loginSuccess: any) => {
        this.alertInfo = {
          alertType: null,
          message: null,
        };
        this.mfaSetupQRCode = `otpauth://totp/BatchAdmin?secret=${loginSuccess.secretCode}`;
        this.loadingQRCode = false;
        window.sessionStorage.setItem('session', loginSuccess.session);
      },
      error: (e) => {
        this.alertInfo = this.commonUtils.setAlert(CONSTANTS.ALERTS.ERROR, e);
        this.loadingQRCode = false;
        this.validating = false;
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.ERROR,
          e.error.error,
          'SetupMFAComponent',
          'getQRCodeSecret'
        );
      },
      complete: () => {
        this.validating = false;
      },
    });
  }

  validateMfa() {
    this.validating = true;
    const setupMfaRequest = {
      email: this.email,
      otp: this.setupMfaForm.value.mfaCode,
      session: window.sessionStorage.getItem('session'),
    };
    this.loginService.setupMfa(setupMfaRequest).subscribe({
      next: (setupMfaSuccess: any) => {
        this.alertInfo = {
          alertType: null,
          message: null,
        };
        this.validating = false;
        window.sessionStorage.setItem('sessionId', setupMfaSuccess.sessionId);
        this.router.navigateByUrl(CONSTANTS.ROUTES.BATCHES);
      },
      error: (e) => {
        this.validating = false;
        this.alertInfo = this.commonUtils.setAlert(CONSTANTS.ALERTS.ERROR, e);
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.ERROR,
          e.error.error,
          'SetupMFAComponent',
          'onSubmit'
        );
      },
      complete: () => {
        this.validating = false;
      },
    });
  }
}
