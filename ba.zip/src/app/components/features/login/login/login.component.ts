import {
  Component,
  ViewChild,
  ElementRef,
  AfterViewInit,
  OnInit,
} from '@angular/core';
import { Router } from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { LoginService } from '../../../../services/login.service';
import { CommonModule } from '@angular/common';
import { AlertsComponent } from '../../../common/alerts/alerts.component';
import { IAlertsInfo } from '../../../../models/AlertsInfo.model';
import { CONSTANTS } from '../../../../constants/batch-admin.constants';
import { CommonUtilitiesService } from '../../../../utils/common-utilities.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, CommonModule, AlertsComponent],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent implements OnInit, AfterViewInit {
  @ViewChild('emailInput') emailInput!: ElementRef;

  loginForm!: FormGroup;
  submitting: boolean = false;
  alertInfo: IAlertsInfo = {
    alertType: null,
    message: null,
  };

  constructor(
    private router: Router,
    private loginService: LoginService,
    private commonUtils: CommonUtilitiesService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.createLoginForm();
  }

  ngAfterViewInit() {
    this.emailInput.nativeElement.focus();
    this.commonUtils.logger(
      CONSTANTS.LOGTYPES.INFO,
      `Endpoint from new file: ${(window as any).runtimeConfig?.dns_endpoint}`,
      'loginComponent',
      'ngAfterViewInit'
    );
  }

  createLoginForm() {
    this.loginForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  login() {
    this.submitting = true;
    this.loginService.login(this.loginForm.value).subscribe({
      next: (loginSuccess) => {
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.LOG,
          'Login Success',
          'LoginComponent',
          'onSubmit'
        );
        window.sessionStorage.setItem('session', loginSuccess.session);
        if (
          loginSuccess.challengeName === CONSTANTS.CHALLENGE_NAME.NEW_PASSWORD
        ) {
          this.router.navigateByUrl(CONSTANTS.ROUTES.NEW_PASSWORD, {
            state: { email: this.loginForm.value.email },
          });
        } else if (
          loginSuccess.challengeName === CONSTANTS.CHALLENGE_NAME.MFA_SETUP
        ) {
          this.router.navigateByUrl(CONSTANTS.ROUTES.SETUP_MFA, {
            state: { email: this.loginForm.value.email },
          });
        } else {
          this.router.navigateByUrl(CONSTANTS.ROUTES.MFA, {
            state: { email: this.loginForm.value.email },
          });
        }
      },
      error: (e) => {
        this.alertInfo = this.commonUtils.setAlert(CONSTANTS.ALERTS.ERROR, e);
        this.submitting = false;
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.ERROR,
          e.error.error,
          'LoginComponent',
          'login'
        );
      },
      complete: () => {
        this.submitting = false;
      },
    });
  }
}
