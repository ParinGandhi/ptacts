import {
  AfterViewInit,
  Component,
  ElementRef,
  OnInit,
  ViewChild,
} from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../../../../services/login.service';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AlertsComponent } from '../../../common/alerts/alerts.component';
import { IAlertsInfo } from '../../../../models/AlertsInfo.model';
import { CommonUtilitiesService } from '../../../../utils/common-utilities.service';
import { CONSTANTS } from '../../../../constants/batch-admin.constants';

@Component({
  selector: 'app-new-password',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, CommonModule, AlertsComponent],
  templateUrl: './new-password.component.html',
  styleUrl: './new-password.component.css',
})
export class NewPasswordComponent implements OnInit, AfterViewInit {
  @ViewChild('emailInput') emailInput!: ElementRef;

  newPasswordForm!: FormGroup;
  email: string = '';
  submitting: boolean = false;
  alertInfo: IAlertsInfo = {
    alertType: null,
    message: null,
  };

  constructor(
    private router: Router,
    private loginService: LoginService,
    private commonUtils: CommonUtilitiesService,
    private formBuilder: FormBuilder
  ) {
    this.email = this.router.getCurrentNavigation()?.extras.state?.['email'];
  }

  ngOnInit(): void {
    this.createNewPasswordForm();
  }

  ngAfterViewInit() {
    this.emailInput.nativeElement.focus();
  }

  createNewPasswordForm() {
    this.newPasswordForm = this.formBuilder.group({
      password: ['', Validators.required],
      verifyPassword: ['', Validators.required],
    });
  }

  setNewPassword() {
    if (
      this.newPasswordForm.value.password !==
      this.newPasswordForm.value.verifyPassword
    ) {
      this.alertInfo = this.commonUtils.setAlert(
        CONSTANTS.ALERTS.ERROR,
        'Passwords do not match. Please verify and try again.'
      );
    } else {
      this.submitting = true;
      const creds = {
        email: this.email,
        session: window.sessionStorage.getItem('session'),
        newPassword: this.newPasswordForm.value.password,
      };
      this.loginService.createNewPassword(creds).subscribe({
        next: (createPasswordSuccess) => {
          this.alertInfo = {
            alertType: null,
            message: null,
          };
          window.sessionStorage.setItem(
            'session',
            createPasswordSuccess.session
          );
          if (
            createPasswordSuccess.challengeName ===
            CONSTANTS.CHALLENGE_NAME.MFA_SETUP
          ) {
            this.router.navigateByUrl(CONSTANTS.ROUTES.SETUP_MFA, {
              state: { email: this.email },
            });
          } else {
            this.router.navigateByUrl(CONSTANTS.ROUTES.MFA, {
              state: { email: this.email },
            });
          }
        },
        error: (e) => {
          this.alertInfo = this.commonUtils.setAlert(CONSTANTS.ALERTS.ERROR, e);
          this.submitting = false;
          this.commonUtils.logger(
            CONSTANTS.LOGTYPES.ERROR,
            e.error.error,
            'NewPasswordComponent',
            'onSubmit'
          );
        },
        complete: () => {
          this.commonUtils.logger(
            CONSTANTS.LOGTYPES.INFO,
            'Complete',
            'mfaComponent',
            'validateMfa'
          );
          this.submitting = false;
        },
      });
    }
  }
}
