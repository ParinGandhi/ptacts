import {
  Component,
  ViewChild,
  ElementRef,
  AfterViewInit,
  OnInit,
} from '@angular/core';
import { Router } from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { LoginService } from '../../../../services/login.service';
import { CommonModule } from '@angular/common';
import { AlertsComponent } from '../../../common/alerts/alerts.component';
import { IAlertsInfo } from '../../../../models/AlertsInfo.model';
import { CommonUtilitiesService } from '../../../../utils/common-utilities.service';
import { CONSTANTS } from '../../../../constants/batch-admin.constants';

@Component({
  selector: 'app-mfa',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, CommonModule, AlertsComponent],
  templateUrl: './mfa.component.html',
  styleUrl: './mfa.component.css',
})
export class MfaComponent implements OnInit, AfterViewInit {
  @ViewChild('mfaInput') mfaInput!: ElementRef;

  mfaForm!: FormGroup;

  // mfaCode: string = '';
  email: string | null = null;
  validating: boolean = false;
  alertInfo: IAlertsInfo = {
    alertType: null,
    message: null,
  };

  constructor(
    private router: Router,
    private loginService: LoginService,
    private commonUtils: CommonUtilitiesService,
    private formBuilder: FormBuilder
  ) {
    this.email = this.router.getCurrentNavigation()?.extras.state?.['email'];
    this.commonUtils.logger(
      CONSTANTS.LOGTYPES.INFO,
      `Email from router state:, ${this.email}`,
      'mfa',
      'constructor'
    );
  }

  ngOnInit(): void {
    this.createMfaForm();
  }

  ngAfterViewInit() {
    this.mfaInput.nativeElement.focus();
  }

  createMfaForm() {
    this.mfaForm = this.formBuilder.group({
      mfaCode: ['', Validators.required],
    });
  }

  validateMfa() {
    this.validating = true;
    const mfaRequest = {
      email: this.email,
      otp: this.mfaForm.value.mfaCode,
      session: window.sessionStorage.getItem('session'),
    };
    this.loginService.verifyMfa(mfaRequest).subscribe({
      next: (mfaSuccess: any) => {
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.LOG,
          'MFA Success',
          'MFAComponent',
          'onSubmit'
        );
        window.sessionStorage.setItem('sessionId', mfaSuccess.sessionId);
        this.validating = false;
        this.router.navigateByUrl(CONSTANTS.ROUTES.BATCHES);
      },
      error: (e) => {
        this.alertInfo = this.commonUtils.setAlert(CONSTANTS.ALERTS.ERROR, e);
        this.validating = false;
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.ERROR,
          e,
          'MFAComponent',
          'onSubmit'
        );
      },
      complete: () => {
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.INFO,
          'Complete',
          'mfaComponent',
          'validateMfa'
        );
      },
    });
  }
}
