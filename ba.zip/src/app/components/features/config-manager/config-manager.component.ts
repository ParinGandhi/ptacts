import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CONSTANTS } from 'src/app/constants/batch-admin.constants';
import { BatchListing } from 'src/app/models/batch-listing/BatchListing';
import { BatchService } from 'src/app/services/batch.service';
import { CommonUtilitiesService } from 'src/app/utils/common-utilities.service';

@Component({
  selector: 'app-config-manager',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './config-manager.component.html',
  styleUrl: './config-manager.component.css',
})
export class ConfigManagerComponent implements OnInit {
  // dropdownItems: any = {
  //   app: [],
  //   environment: [],
  // };
  dropdownItems: any = {
    appNames: [],
    environments: [],
    batches: [],
  };
  selectedApp: string = 'default';
  selectedEnv: string = 'default';
  selectedBatch: string = 'default';

  originalValues = {
    appName: '',
    environment: '',
    jobName: '',
  };
  // configToEdit = {
  //   items: '',
  //   lists: []
  // };
  configToEdit: any = {};
  configDetails: any;

  config!: Array<BatchListing>;
  updating: boolean = false;

  constructor(
    private batchService: BatchService,
    private commonUtils: CommonUtilitiesService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // this.config.forEach((item) => {
    const configDetails = window.sessionStorage.getItem('configDetails');
    if (configDetails) {
      this.configDetails = JSON.parse(configDetails);
    }

    this.configToEdit = JSON.parse(JSON.stringify(this.configDetails.listing));
    this.configToEdit.batches = [];
    this.configToEdit.batches.push(this.configDetails.batch);

    this.originalValues = {
      appName: this.configToEdit.appName,
      environment: this.configToEdit.environment,
      jobName: this.configToEdit.batches[0].name,
    };
    // this.configToEdit.batches = this.configDetails.lisitng;
    // if (!this.dropdownItems.appNames.includes(item.appName)) {
    //   this.dropdownItems.appNames.push(item.appName);
    // }

    // if (!this.dropdownItems[item.appName]) {
    //   this.dropdownItems[item.appName] = [];
    //   this.dropdownItems[item.appName].push(item);
    // } else {
    //   this.dropdownItems[item.appName].push(item);
    // }
    // });
    console.log('Dropdown items:', this.dropdownItems);
  }

  getEnvironments() {
    this.dropdownItems.environments = [];
    this.config.forEach((item) => {
      if (item.appName === this.selectedApp) {
        if (!this.dropdownItems.environments.includes(item.environment)) {
          this.dropdownItems.environments.push(item.environment);
        }
      }
    });
  }

  getConfiguration() {
    this.config.forEach((item: BatchListing) => {
      if (item.appName === this.selectedApp) {
        if (item.environment === this.selectedEnv) {
          // for (const [key, value] of Object.entries(item)) {
          //   console.log(`${key}: ${value}`);
          //   if (typeof(value) == 'string') {
          //     this.configToEdit.items[key] = value;
          //   } else if (typeof(value) !== 'string') {
          //     this.configToEdit.lists =
          //   }
          // }
          // for (const [key, value] of Object.entries(item)) {
          //   console.log(`${key}: ${value}`);
          //   if (typeof value == 'string') {
          //     this.configToEdit[key] = value;
          //   } else if (typeof value !== 'string') {
          //     value.forEach((val: any) => {
          //       this.configToEdit[key + val.id] = val;
          //     });
          //   }
          // }
          this.dropdownItems.batches = item.batches;
          // this.configToEdit = JSON.parse(JSON.stringify(item));
        }
      }
    });
  }

  setConfiguration() {
    this.config.forEach((item: BatchListing) => {
      if (item.appName === this.selectedApp) {
        if (item.environment === this.selectedEnv) {
          item.batches.forEach((batch) => {
            if (batch.name === this.selectedBatch) {
              this.configToEdit = JSON.parse(JSON.stringify(item));
              const foundBatch = this.configToEdit.batches.find(
                (batch: any) => {
                  return batch.name == this.selectedBatch;
                }
              );
              this.configToEdit.batches = [];
              this.configToEdit.batches[0] = foundBatch;
            }
          });
          // this.dropdownItems.batches = item.batches;
          // this.configToEdit = JSON.parse(JSON.stringify(item));
        }
      }
    });
  }

  isArray(item: any) {
    console.log('Current item:', typeof item);
    return typeof item !== 'string';
  }

  getDisplayData() {
    return JSON.parse(this.configToEdit);
  }

  updateConfig() {
    this.updating = true;
    console.log(this.configToEdit);
    const updateObj = {
      // appName: this.configToEdit.appName,
      // environment: this.configToEdit.environment,
      // jobName: this.configToEdit.batches[0].name,
      appName: this.originalValues.appName,
      environment: this.originalValues.environment,
      jobName: this.originalValues.jobName,
      newConfigUpdate: this.configToEdit,
    };
    updateObj.newConfigUpdate.batch = this.configToEdit.batches[0];

    // if (
    //   updateObj.newConfigUpdate.batch.runParams &&
    //   updateObj.newConfigUpdate.batch.runParams.length > 0
    // ) {
    //   updateObj.newConfigUpdate.batch.runParams.forEach((runParam: any) => {
    //     if (runParam.dataType && runParam.dataType == 'enum') {
    //     }
    //   });
    // }
    delete updateObj.newConfigUpdate.batches;

    delete updateObj.newConfigUpdate.lastExecutedDatetime;
    delete updateObj.newConfigUpdate.runningInstances;
    delete updateObj.newConfigUpdate.frequencyStat;

    this.batchService.updateJobsConfig(updateObj).subscribe({
      next: (updateConfigResponse: any) => {
        this.commonUtils.setToastr(
          CONSTANTS.TOASTR_TYPES.SUCCESS,
          'Config update',
          'Successfully updated config'
        );
        this.updating = false;
        this.router.navigateByUrl(CONSTANTS.ROUTES.BATCHES);
      },
      error: (updateConfigError) => {
        this.commonUtils.setToastr(
          CONSTANTS.TOASTR_TYPES.ERROR,
          'Config update',
          'Failed to update config'
        );
        this.updating = false;
      },
    });
  }

  trackByFn(item: any) {
    return item;
  }
}
