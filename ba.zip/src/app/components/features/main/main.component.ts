import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { CONSTANTS } from 'src/app/constants/batch-admin.constants';

@Component({
  selector: 'app-main',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './main.component.html',
  styleUrl: './main.component.css'
})
export class MainComponent implements OnInit {
  alertVisible = true;

  constructor(private router:Router) {}

  ngOnInit(): void {
    const sessionId = window.sessionStorage.getItem('sessionId');
    if (sessionId) {
      this.router.navigateByUrl(CONSTANTS.ROUTES.BATCHES);
    } else {
      this.router.navigateByUrl(CONSTANTS.ROUTES.LOGIN);
    }
  }

  closeAlert() {
    this.alertVisible = false;
  }
}
