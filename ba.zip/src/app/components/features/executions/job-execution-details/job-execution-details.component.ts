import { Component } from '@angular/core';

@Component({
  selector: 'app-job-execution-details',
  standalone: true,
  imports: [],
  templateUrl: './job-execution-details.component.html',
  styleUrl: './job-execution-details.component.css'
})
export class JobExecutionDetailsComponent {

  execution: any = {
    id: 1234567890,
    params: 'param1=value1,param2=value2',
    startTime: '2024-10-01 14:30:00',
    endTime: '2024-10-01 14:35:00',
    status: 'COMPLETED',
    exitCode: 0,
    exitMessage: 'Job completed successfully',
  };

  selectedBatchJobName: string = 'Batch 1';

  constructor() { }
}
