import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JobExecutionListingComponent } from './job-execution-listing.component';

describe('JobExecutionListingComponent', () => {
  let component: JobExecutionListingComponent;
  let fixture: ComponentFixture<JobExecutionListingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [JobExecutionListingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(JobExecutionListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
