import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { JobService } from '../../../../services/job.service';
import { FormsModule } from '@angular/forms';
import { BatchService } from '../../../../services/batch.service';
import { CONSTANTS } from '../../../../constants/batch-admin.constants';
import { IAlertsInfo } from '../../../../models/AlertsInfo.model';
import { CommonUtilitiesService } from '../../../../utils/common-utilities.service';
import { LoaderComponent } from '../../../common/loader/loader.component';
import { ToastrService } from 'ngx-toastr';
import { MPMSJob } from 'src/app/models/MPMSJob.model';
import { RunBatchHelperService } from 'src/app/services/run-batch-helper.service';
declare var bootstrap: any;

@Component({
  selector: 'app-job-execution-listing',
  standalone: true,
  imports: [CommonModule, FormsModule, LoaderComponent],
  templateUrl: './job-execution-listing.component.html',
  styleUrl: './job-execution-listing.component.css',
})
export class JobExecutionListingComponent implements OnInit, OnDestroy {
  jobDetails: any;
  jobDetailsInfo: any;
  jobDetailsInterval: any;
  paginationDetails = {
    totalResultsCount: 0,
    page: 0,
    pageSize: 0,
    totalPages: 0,
  };
  alertInfo: IAlertsInfo = {
    alertType: null,
    message: null,
  };
  loading: boolean = false;
  jobSummary = {
    running: 0,
    completed: 0,
    stoppedAbandoned: 0,
    failedUnkonwn: 0,
  };
  status = CONSTANTS.STATUS;
  reRunningJob: boolean = false;
  editIndex: number = -1;

  constructor(
    private router: Router,
    private jobService: JobService,
    private batchService: BatchService,
    private commonUtils: CommonUtilitiesService,
    private runBatchJobHelper: RunBatchHelperService
  ) {}

  ngOnInit(): void {
    this.jobDetailsInfo = window.sessionStorage.getItem('jobDetails');
    if (this.jobDetailsInfo) {
      this.jobDetailsInfo = JSON.parse(this.jobDetailsInfo);
      this.jobDetailsInfo.page = 1;
      this.jobDetailsInfo.pageSize = 25;
      this.getJobDetails();
      this.getJobSummary();
    }
  }

  getJobDetails() {
    this.loading = true;
    this.jobService.getJobDetails(this.jobDetailsInfo).subscribe({
      next: (jobDetailsResponse: any) => {
        jobDetailsResponse?.results?.forEach((jobDetail: any) => {
          jobDetail.execution_params_str = '--';

          jobDetail.start_time = this.commonUtils.convertToEST(
            jobDetail.start_time
          );
          jobDetail.end_time = this.commonUtils.convertToEST(
            jobDetail.end_time
          );

          if (jobDetail.execution_params.length > 0) {
            const tempExParams: Array<string> = [];
            jobDetail.execution_params.forEach((ex_params: any) => {
              tempExParams.push(
                `${ex_params.parameter_name}: ${ex_params.parameter_value}`
              );
            });
            jobDetail.execution_params_str = tempExParams.join(' | ');
          }
        });
        this.jobDetails = jobDetailsResponse;
        this.setPaginationDetails();
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.INFO,
          `Job details: ${this.jobDetails}`,
          'job-execution-listing.component',
          'getJobDetails'
        );
        this.loading = false;
        this.getJobSummary();
        this.checkForStatus();
      },
      error: (jobDetailsError) => {
        this.loading = false;
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.ERROR,
          `Job details error: ${jobDetailsError.error.message}`,
          'job-execution-listing.component',
          'getJobDetails'
        );
        this.commonUtils.setToastr(
          CONSTANTS.TOASTR_TYPES.ERROR,
          'Job details',
          jobDetailsError
        );
        // this.toastr.error(jobDetailsError.error);
      },
    });
  }

  getJobSummary() {
    const jobSummaryPayload = {
      appName: this.jobDetailsInfo.appName,
      name: this.jobDetailsInfo.name,
      environment: this.jobDetailsInfo.environment,
    };
    this.jobService.getJobSummary(jobSummaryPayload).subscribe({
      next: (jobSummaryResponse) => {
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.INFO,
          `Job summary: ${jobSummaryResponse}`,
          'job-execution-listing.component',
          'getJobSummary'
        );
        this.calculateSummary(jobSummaryResponse);
      },
      error: (jobSummaryError) => {
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.ERROR,
          `Job summary error: ${jobSummaryError}`,
          'job-execution-listing.component',
          'getJobSummary'
        );
      },
    });
  }

  setPaginationDetails() {
    this.paginationDetails.totalResultsCount =
      this.jobDetails.totalResultsCount;
    this.paginationDetails.page = this.jobDetails.page;
    this.paginationDetails.pageSize = this.jobDetails.pageSize;
    this.paginationDetails.totalPages = this.jobDetails.totalPages;
    this.jobDetailsInfo.page = this.jobDetails.page;
    this.jobDetailsInfo.pageSize = this.jobDetails.pageSize;
  }

  checkForStatus() {
    let needToAutoRefresh: boolean = false;
    this.jobDetails?.results?.forEach((jobDetail: any) => {
      if (
        jobDetail.status === CONSTANTS.STATUS.STARTING ||
        jobDetail.status === CONSTANTS.STATUS.STARTED ||
        jobDetail.status === CONSTANTS.STATUS.STOPPING
      ) {
        needToAutoRefresh = true;
      }
    });
    if (needToAutoRefresh) {
      if (!this.jobDetailsInterval) {
        this.jobDetailsInterval = setInterval(() => {
          this.getJobDetails();
        }, 10000);
      }
    } else {
      if (this.jobDetailsInterval) {
        clearInterval(this.jobDetailsInterval);
      }
    }
  }

  viewExecutionDetails() {
    // Navigate to the job details page
    this.router.navigate(['/executions/1234567890']);
  }

  changePaginationPageSize(changeType: string, pageSize: number) {
    switch (changeType) {
      case 'pageSize':
        this.paginationDetails.pageSize = pageSize;
        this.jobDetailsInfo.pageSize = pageSize;
        break;
      case 'first':
        this.paginationDetails.page = 1;
        this.jobDetailsInfo.page = 1;
        break;
      case 'previous':
        this.paginationDetails.page--;
        this.jobDetailsInfo.page--;
        break;
      case 'next':
        this.paginationDetails.page++;
        this.jobDetailsInfo.page++;
        break;
      case 'last':
        this.paginationDetails.page = this.paginationDetails.totalPages;
        this.jobDetailsInfo.page = this.paginationDetails.totalPages;
        break;
      default:
        break;
    }

    this.commonUtils.logger(
      CONSTANTS.LOGTYPES.INFO,
      `Pagination details: ${this.paginationDetails}`,
      'job-execution-listing.component',
      'changePaginationPageSize'
    );
    this.getJobDetails();
  }

  rerunJob(jobToReRun: any, index: number) {
    this.editIndex = index;
    this.reRunningJob = true;

    const mpmsReRunJobObj: MPMSJob = this.runBatchJobHelper.setupMPMSReRunJob(
      this.jobDetailsInfo,
      this.jobDetails,
      jobToReRun
    );

    this.commonUtils.logger(
      CONSTANTS.LOGTYPES.INFO,
      `mpmsReRunJobObj: ${mpmsReRunJobObj}`,
      'job-execution-listing.component',
      'rerunJob'
    );

    this.batchService.runBatch(mpmsReRunJobObj).subscribe({
      next: (runJobResponse: any) => {
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.INFO,
          `RunJobResponse: ${runJobResponse}`,
          'job-execution-listing.component',
          'rerunJob'
        );
        this.commonUtils.setToastr(
          CONSTANTS.TOASTR_TYPES.SUCCESS,
          'ReRun job',
          `Successfully ran '${jobToReRun.job_name}' job`
        );
        this.reRunningJob = false;
        this.editIndex = -1;
      },
      error: (error) => {
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.ERROR,
          `RE-RunJobError: ${error.error.message}`,
          'job-execution-listing.component',
          'rerunJob'
        );
        this.commonUtils.setToastr(
          CONSTANTS.TOASTR_TYPES.ERROR,
          'ReRun failed',
          error
        );
        this.reRunningJob = false;
        this.editIndex = -1;
      },
      complete: () => {},
    });
  }

  calculateSummary(jobSummaryResponse: any) {
    this.jobSummary = {
      running: 0,
      completed: 0,
      failedUnkonwn: 0,
      stoppedAbandoned: 0,
    };
    jobSummaryResponse.forEach((jobDetail: any) => {
      switch (jobDetail.status) {
        case CONSTANTS.STATUS.STARTING:
          this.jobSummary.running =
            this.jobSummary.running + parseInt(jobDetail.count);
          break;
        case CONSTANTS.STATUS.STARTED:
          this.jobSummary.running =
            this.jobSummary.running + parseInt(jobDetail.count);
          break;
        case CONSTANTS.STATUS.COMPLETED:
          this.jobSummary.completed =
            this.jobSummary.completed + parseInt(jobDetail.count);
          break;
        case CONSTANTS.STATUS.STOPPING:
          this.jobSummary.stoppedAbandoned =
            this.jobSummary.stoppedAbandoned + parseInt(jobDetail.count);
          break;
        case CONSTANTS.STATUS.STOPPED:
          this.jobSummary.stoppedAbandoned =
            this.jobSummary.stoppedAbandoned + parseInt(jobDetail.count);
          break;
        case CONSTANTS.STATUS.ABANDONED:
          this.jobSummary.stoppedAbandoned =
            this.jobSummary.stoppedAbandoned + parseInt(jobDetail.count);
          break;
        case CONSTANTS.STATUS.FAILED:
          this.jobSummary.failedUnkonwn =
            this.jobSummary.failedUnkonwn + parseInt(jobDetail.count);
          break;
        case CONSTANTS.STATUS.UNKNOWN:
          this.jobSummary.failedUnkonwn =
            this.jobSummary.failedUnkonwn + parseInt(jobDetail.count);
          break;
      }
    });
  }

  stopJob(jobToStop: any) {
    const stopJobRequestObj = {
      appName: this.jobDetailsInfo.appName,
      environment: this.jobDetailsInfo.environment,
      jobName: jobToStop.job_name,
      serverInstance: this.jobDetails.serverInstance,
      jobExecutionId: jobToStop.job_execution_id,
      jobStatus: 'STOP',
    };
    this.batchService.stopBatch(stopJobRequestObj).subscribe({
      next: (stopJobResponse: any) => {
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.INFO,
          `StopJobResponse: ${stopJobResponse}`,
          'job-execution-listing.component',
          'stopJob'
        );
        this.commonUtils.setToastr(
          CONSTANTS.TOASTR_TYPES.SUCCESS,
          'Stop job',
          `Successfully requested job '${jobToStop.job_name}' to stop`
        );
        this.editIndex = -1;
      },
      error: (error) => {
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.ERROR,
          `StopJobError: ${error.error.message}`,
          'job-execution-listing.component',
          'stopJob'
        );
        this.commonUtils.setToastr(
          CONSTANTS.TOASTR_TYPES.ERROR,
          'Failed to stop job',
          error
        );
        this.editIndex = -1;
      },
      complete: () => {},
    });
  }

  ngOnDestroy(): void {
    clearInterval(this.jobDetailsInterval);
  }
}
