import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { BatchService } from '../../../services/batch.service';
import { Subject } from 'rxjs';
import { DataTablesModule } from 'angular-datatables';
import { RefreshTableBtnComponent } from '../../common/refresh-table-btn/refresh-table-btn.component';
import cronstrue from 'cronstrue';
import { FormsModule } from '@angular/forms';
import { AlertsComponent } from '../../common/alerts/alerts.component';
import { IAlertsInfo } from '../../../models/AlertsInfo.model';
import { CONSTANTS } from '../../../constants/batch-admin.constants';
import { CommonUtilitiesService } from '../../../utils/common-utilities.service';

import { LoaderComponent } from '../../common/loader/loader.component';
import { MPMSJob } from 'src/app/models/MPMSJob.model';
import { EEJob } from 'src/app/models/EEJob.model';
import { RunBatchHelperService } from 'src/app/services/run-batch-helper.service';
declare let $: any;

@Component({
  selector: 'app-batch-listing',
  standalone: true,
  imports: [
    CommonModule,
    DataTablesModule,
    RefreshTableBtnComponent,
    FormsModule,
    AlertsComponent,
    LoaderComponent,
  ],
  templateUrl: './batch-listing.component.html',
  styleUrl: './batch-listing.component.css',
})
export class BatchListingComponent {
  selectedEnvironment: string = '';
  selectedApplicationTower: string = '';
  selectedBatchApplication: string = '';
  batchListings: Array<any> = new Array<any>();
  filteredBatchListings: Array<any> = new Array<any>();
  selectedBatch: any;
  selectedListing: any;
  userAccess: any;
  alertInfo: IAlertsInfo = {
    alertType: null,
    message: null,
  };
  runningJob: boolean = false;
  selectedServer: string = 'ALL';
  dataTable: any;
  dummyData: Array<any> = [];
  serverList: Array<any> = [];
  dtTrigger: Subject<any> = new Subject<any>();
  loading: boolean = false;
  dtOptions: any = {};
  runJobObj: any;
  requiredRunParamsError = [];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private batchService: BatchService,
    private commonUtils: CommonUtilitiesService,
    private runBatchJobHelper: RunBatchHelperService
  ) {}

  ngOnInit(): void {
    this.dtOptions = {
      columnDefs: [
        { targets: [0], type: 'num', orderable: true },
        { targets: '_all', visible: true },
      ],
      order: [[0, 'asc']],
      pagingType: 'full_numbers',
      paging: false,
      searching: false,
    };
    window.sessionStorage.clear();
    this.route.queryParams.subscribe((params) => {
      this.selectedEnvironment = params['env'] || CONSTANTS.MENU_OPTIONS.ALL;
      this.selectedApplicationTower =
        params['tower'] || CONSTANTS.MENU_OPTIONS.ALL;
      this.selectedBatchApplication =
        params['batchapp'] || CONSTANTS.MENU_OPTIONS.ALL;
      this.getBatchListing();
      this.verifyUserAccess();
    });
  }

  getBatchListing() {
    this.loading = true;
    this.batchService.listJobs().subscribe((jobResponse: any) => {
      this.batchListings = jobResponse;
      this.filteredBatchListings = jobResponse;
      this.dtTrigger.next(null);
      this.loading = false;
      this.showFilteredResults();
      this.getJobStatus(this.filteredBatchListings);
    });
  }

  viewExecutions(listing: any, batch: any) {
    const jobDetailsInfo = {
      appName: listing.appName,
      name: batch.name,
      environment: listing.environment,
      params: batch.runParams,
    };
    window.sessionStorage.setItem('jobDetails', JSON.stringify(jobDetailsInfo));
    this.router.navigateByUrl(CONSTANTS.ROUTES.EXECUTIONS);
  }

  editConfig(listing: any, batch: any) {
    const editConfigInfo = {
      appName: listing.appName,
      name: batch.name,
      environment: listing.environment,
      batch: batch,
      listing: listing,
    };
    window.sessionStorage.setItem(
      'configDetails',
      JSON.stringify(editConfigInfo)
    );
    this.router.navigateByUrl(CONSTANTS.ROUTES.EDIT_CONFIG);
  }

  showFilteredResults() {
    let filteredBatchListings: any[] = [];
    let filteredTowerListings: any[] = [];
    let filteredBatchAppListings: any[] = [];
    if (this.selectedEnvironment !== CONSTANTS.MENU_OPTIONS.ALL) {
      filteredBatchListings = this.batchListings.filter((listing) => {
        return listing.environment === this.selectedEnvironment;
      });
    } else {
      filteredBatchListings = JSON.parse(JSON.stringify(this.batchListings));
    }

    if (this.selectedApplicationTower !== CONSTANTS.MENU_OPTIONS.ALL) {
      filteredTowerListings = filteredBatchListings.filter((listing: any) => {
        return listing.appName === this.selectedApplicationTower;
      });
    } else {
      filteredTowerListings = JSON.parse(JSON.stringify(filteredBatchListings));
    }

    if (this.selectedBatchApplication !== CONSTANTS.MENU_OPTIONS.ALL) {
      filteredTowerListings.forEach((listing: any) => {
        const batches = listing.batches.filter((batch: any) => {
          return batch.applicationName.includes(this.selectedBatchApplication);
        });
        listing.batches = batches;
        filteredBatchAppListings.push(listing);
      });
    } else {
      filteredBatchAppListings = JSON.parse(
        JSON.stringify(filteredTowerListings)
      );
    }
    this.filteredBatchListings = [];
    this.filteredBatchListings = JSON.parse(
      JSON.stringify(filteredBatchAppListings)
    );
  }

  setSelectedJob(listing: any, batch: any) {
    this.serverList = [];
    this.selectedBatch = batch;
    this.selectedListing = listing;
    if (this.selectedBatch.serverInstances) {
      const numberOfServers = parseInt(this.selectedBatch.serverInstances);
      for (let i = 0; i < numberOfServers; i++) {
        this.serverList.push(i + 1);
      }
      this.commonUtils.logger(
        CONSTANTS.LOGTYPES.INFO,
        `Server list: ${this.serverList}`,
        'batch-listing.component',
        'setSelectedJob'
      );
    }
    // if (this.serverList.length === 1) {
    //   this.selectedServer = this.serverList[0];
    // }
  }

  getJobStatus(batchListings: any) {
    for (let i = 0; i < batchListings.length; i++) {
      for (let j = 0; j < batchListings[i].batches.length; j++) {
        const jobInfo = {
          appName: batchListings[i].appName,
          name: batchListings[i].batches[j].name,
          environment: batchListings[i].environment,
        };
        this.batchService.getJobStatus(jobInfo).subscribe({
          next: (jobStatusResponse: any) => {
            batchListings[i].batches[j].lastExecutedDatetime = jobStatusResponse
              .lastExecutedData?.end_time
              ? jobStatusResponse.lastExecutedData?.end_time
              : 'N/A';
            batchListings[i].batches[j].runningInstances =
              jobStatusResponse?.runningInstances?.length > 0
                ? jobStatusResponse?.runningInstances?.length
                : 'N/A';
          },
          error: (jobStatusError) => {
            batchListings[i].batches[j].lastExecutedDatetime = 'FAILED';
            batchListings[i].batches[j].runningInstances = 'FAILED';
          },
          complete: () => {},
        });
        const batchInfo = {
          appName: batchListings[i].appName,
          name: batchListings[i].batches[j].key,
          environment: batchListings[i].environment,
          namespace: batchListings[i].batches[j].namespace,
        };

        this.batchService.getFrequencyStat(batchInfo).subscribe({
          next: (frequencyStatResponse: any) => {
            if (frequencyStatResponse && frequencyStatResponse.schedule) {
              batchListings[i].batches[j].frequencyStat = cronstrue.toString(
                frequencyStatResponse.schedule
              );
            } else {
              batchListings[i].batches[j].frequencyStat = 'N/A';
            }
          },
          error: (frequencyStatError) => {
            this.commonUtils.logger(
              CONSTANTS.LOGTYPES.ERROR,
              frequencyStatError,
              'batch-listing.component',
              'getJobStatus'
            );
          },
          complete: () => {},
        });
      }
    }
  }

  runJob() {
    if (this.validateRequiredParams()) {
      this.commonUtils.logger(
        CONSTANTS.LOGTYPES.INFO,
        this.selectedBatch,
        'batch-listing.component',
        'runJob'
      );
      this.commonUtils.logger(
        CONSTANTS.LOGTYPES.INFO,
        this.selectedListing,
        'batch-listing.component',
        'runJob'
      );

      if (this.selectedListing.appName === 'MPMS') {
        // this.runMPMSJob();
        const mpmsRunJobObj: MPMSJob = this.runBatchJobHelper.setupMPMSJob(
          this.selectedListing,
          this.selectedBatch
        );
        this.runBatch(mpmsRunJobObj);
      } else if (this.selectedListing.appName === 'EE') {
        const eeRunJobObj: EEJob = this.runBatchJobHelper.setupEEJob(
          this.selectedListing,
          this.selectedBatch
        );
        this.runForSelectedServers(eeRunJobObj);
      }
    } else {
      this.alertInfo = this.commonUtils.setAlert(
        CONSTANTS.ALERTS.ERROR,
        `Please enter all required fields.`
      );
    }
  }

  validateRequiredParams(): boolean {
    let validated: boolean = true;
    this.selectedBatch.runParams.forEach((runParam: any) => {
      if (runParam.required) {
        if (!runParam?.defaultValue || runParam.defaultValue == '') {
          validated = false;
        }
      }
    });
    return validated;
  }

  runForSelectedServers(eeRunJobObj: EEJob) {
    if (this.serverList.length <= 0) {
      this.selectedServer = '';
    }
    if (this.selectedServer === 'ALL') {
      this.serverList.forEach((server) => {
        eeRunJobObj.serverInstance = server.toString();
        this.runBatch(eeRunJobObj);
      });
    } else {
      eeRunJobObj.serverInstance = this.selectedServer;
      this.runBatch(eeRunJobObj);
    }
  }

  runBatch(runJobObj: any) {
    this.runningJob = true;
    this.batchService.runBatch(runJobObj).subscribe({
      next: (runJobResponse: any) => {
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.INFO,
          `RunJobResponse: ${runJobResponse}`,
          'batch-listing.component',
          'runJob'
        );
        this.runningJob = false;

        setTimeout(() => {
          // this.toastr.info(
          //   CONSTANTS.MESSAGES.RUN_JOB,
          //   `${this.selectedBatch.name} execution requested`
          // );
          this.commonUtils.setToastr(
            CONSTANTS.TOASTR_TYPES.INFO,
            CONSTANTS.MESSAGES.RUN_JOB,
            `${this.selectedBatch.name} execution requested`
          );
          document.getElementById('runJobModalClose')?.click();
          this.viewExecutions(this.selectedListing, this.selectedBatch);
        }, 200);
      },
      error: (error) => {
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.ERROR,
          error,
          'batch-listing.component',
          'runJob'
        );
        this.alertInfo = this.commonUtils.setAlert(
          CONSTANTS.ALERTS.ERROR,
          error
        );
        this.runningJob = false;
      },
      complete: () => {},
    });
  }

  verifyUserAccess() {
    this.batchService.verifyUserAccess().subscribe({
      next: (verifyUserResponse) => {
        this.userAccess = verifyUserResponse.appNames;
      },
      error: (verifyUserError) => {
        this.commonUtils.logger(
          CONSTANTS.LOGTYPES.ERROR,
          verifyUserError,
          'batch-listing.component',
          'runJob'
        );
      },
      complete: () => {},
    });
  }

  viewJobDetails(listing: any, batch: any) {
    const jobDetailsInfo = {
      appName: listing.appName,
      name: batch.name,
      environment: listing.environment,
    };
    window.sessionStorage.setItem('jobDetails', JSON.stringify(jobDetailsInfo));
    this.router.navigateByUrl(CONSTANTS.ROUTES.JOB_DETAILS);
  }

  renderTable() {
    $('#batchListingTable').DataTables().destroy();
    $('#batchListingTable').DataTables(this.dtOptions);
    $('#batchListingTable').DataTables().draw();
  }
}
