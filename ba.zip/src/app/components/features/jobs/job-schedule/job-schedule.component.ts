import { Component } from '@angular/core';

@Component({
  selector: 'app-job-schedule',
  standalone: true,
  imports: [],
  templateUrl: './job-schedule.component.html',
  styleUrl: './job-schedule.component.css'
})
export class JobScheduleComponent {

}
