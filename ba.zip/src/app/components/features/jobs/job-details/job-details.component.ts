import { Component, OnInit } from '@angular/core';
import { RefreshTableBtnComponent } from '../../../common/refresh-table-btn/refresh-table-btn.component';
import { JobService } from '../../../../services/job.service';

@Component({
  selector: 'app-job-details',
  standalone: true,
  imports: [RefreshTableBtnComponent],
  templateUrl: './job-details.component.html',
  styleUrl: './job-details.component.css',
})
export class JobDetailsComponent implements OnInit {
  jobDetails: any;

  constructor(private jobService: JobService) {}

  ngOnInit(): void {
    this.getJobDetails();
  }

  getJobDetails() {
    let jobDetailsInfo = window.sessionStorage.getItem('jobDetails');
    if (jobDetailsInfo) {
      jobDetailsInfo = JSON.parse(jobDetailsInfo);
      this.jobService.getJobDetails(jobDetailsInfo).subscribe({
        next: (jobDetailsResponse) => {
          this.jobDetails = jobDetailsResponse;
        },
      });
    }
  }
}
