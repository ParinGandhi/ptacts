import { IRunParam } from './RunParam.model';

export class MPMSJob {
  appName: string | null = null;
  environment: string | null = null;
  name: string | null = null;
  namespace: string | null = null;
  // serverInstance: string | null = null;
  runParameters: Array<IRunParam | null> = new Array<null>();

  constructor(selectedListing: any, selectedBatch: any) {
    this.appName = selectedListing.appName;
    this.environment = selectedListing.environment;
    this.name = selectedBatch.key;
    this.namespace = selectedBatch.namespace;
  }
}
