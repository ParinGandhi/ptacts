export interface EnvironmentProperty {
  appDir: 'string';
  dbCredentials: 'string';
  javaHome: 'string';
  propertiesHome: 'string';
}
