import { Batch } from './Batch.model';
import { EnvironmentProperty } from './EnvironmentProperty.model';

export interface BatchListing {
  appName: string;
  platformType: string;
  environment: string;
  envProps: Array<EnvironmentProperty>;
  batches: Array<Batch>;
}
