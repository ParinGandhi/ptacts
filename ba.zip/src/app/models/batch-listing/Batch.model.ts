import { RunParam } from './RunParam.model';

export interface Batch {
  id: string;
  name: string;
  applicationName: string;
  description: string;
  serverInstances?: string;
  executable?: string;
  serverArray?: Array<{}>;
  key?: string;
  namespace?: string;
  runParams: Array<RunParam>;
}
