export interface RunParam {
  param: string;
  dataType: string;
  required: boolean;
  allowedValues: Array<string>;
  defaultValue?: string;
}
