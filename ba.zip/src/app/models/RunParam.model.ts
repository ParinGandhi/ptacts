export interface IRunParam {
  param: 'string';
  value: 'string';
}
