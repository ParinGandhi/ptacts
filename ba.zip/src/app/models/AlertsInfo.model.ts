export interface IAlertsInfo {
  alertType: string | null;
  message: string |  null;
}
