import { Routes } from '@angular/router';
import { BatchListingComponent } from './components/features/batch-listing/batch-listing.component';
import { JobDetailsComponent } from './components/features/jobs/job-details/job-details.component';
import { LoginComponent } from './components/features/login/login/login.component';
import { MfaComponent } from './components/features/login/mfa/mfa.component';
import { MainComponent } from './components/features/main/main.component';
import { JobExecutionListingComponent } from './components/features/executions/job-execution-listing/job-execution-listing.component';
import { JobExecutionDetailsComponent } from './components/features/executions/job-execution-details/job-execution-details.component';
import { AuthGuard } from './guards/auth.guard';
import { NewPasswordComponent } from './components/features/login/new-password/new-password.component';
import { SetupMfaComponent } from './components/features/login/setup-mfa/setup-mfa.component';
import { ConfigManagerComponent } from './components/features/config-manager/config-manager.component';

export const routes: Routes = [
  { path: '', component: MainComponent },
  { path: 'main', component: MainComponent },
  {
    path: 'batches',
    component: BatchListingComponent,
    canActivate: [AuthGuard],
  },
  { path: 'executions', component: JobExecutionListingComponent },
  { path: 'executions/:id', component: JobExecutionDetailsComponent },
  { path: 'job-details', component: JobDetailsComponent },
  { path: 'login', component: LoginComponent },
  { path: 'new-password', component: NewPasswordComponent },
  { path: 'mfa', component: MfaComponent },
  { path: 'setup-mfa', component: SetupMfaComponent },
  { path: 'config-manager', component: ConfigManagerComponent },
];
