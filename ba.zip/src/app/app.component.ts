import { Component } from '@angular/core';
import { RouterOutlet, Router, NavigationEnd } from '@angular/router';
import { HeaderComponent } from './components/common/header/header.component';
import { MenuComponent } from './components/common/menu/menu.component';
import { filter } from 'rxjs/operators';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, MenuComponent, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'BatchAdmin';
  showMenu: boolean = true;

  constructor(private router: Router) {
    // Listen to route changes
    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        // Show menu unless the URL is '/', '/main', '/login' or '/mfa'
        this.showMenu = !(
          event.url === '/' ||
          event.url === '/login' ||
          event.url === '/mfa' ||
          event.url === '/main' ||
          event.url === '/new-password' ||
          event.url === '/setup-mfa'
        );
      });
  }
}
