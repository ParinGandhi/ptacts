export const CONSTANTS = {
  ALERTS: {
    ERROR: 'danger',
    INFO: 'info',
  },
  TOASTR_TYPES: {
    INFO: 'info',
    SUCCESS: 'success',
    ERROR: 'error',
  },
  LOGTYPES: {
    INFO: 'info',
    LOG: 'log',
    ERROR: 'error',
  },
  CHALLENGE_NAME: {
    NEW_PASSWORD: 'NEW_PASSWORD_REQUIRED',
    MFA_SETUP: 'MFA_SETUP',
  },
  ROUTES: {
    EDIT_CONFIG: '/config-manager',
    EXECUTIONS: '/executions',
    JOB_DETAILS: '/job-details',
    NEW_PASSWORD: '/new-password',
    SETUP_MFA: '/setup-mfa',
    MFA: '/mfa',
    BATCHES: '/batches',
    LOGIN: '/login',
  },
  MESSAGES: {
    RUN_JOB:
      'Requested job can take some time to show on the table below. Please refresh the table to see the updated execution details.',
  },
  STATUS: {
    STARTING: 'STARTING',
    STARTED: 'STARTED',
    STOPPING: 'STOPPING',
    COMPLETED: 'COMPLETED',
    STOPPED: 'STOPPED',
    ABANDONED: 'ABANDONED',
    FAILED: 'FAILED',
    UNKNOWN: 'UNKNOWN',
  },
  MENU_OPTIONS: {
    ALL: 'All',
  },
};
