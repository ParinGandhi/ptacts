import { createApp } from "vue";
import App from "./App.vue";
import router from "./router";
import { createPinia } from "pinia";
import Colada, { PiniaColadaPlugin } from "colada-plugin";

import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap";
// import "@cmsgov/design-system/dist/css/index.css";
// import "@cmsgov/design-system/dist/css/core-theme.css";

const app = createApp(App);
const pinia = createPinia();

app.use(pinia);
pinia.use(PiniaColadaPlugin);
app.use(Colada);
app.use(router);
app.mount("#app");
