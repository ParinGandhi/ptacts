Terms
==============
Software code created by U.S. Government employees is not subject to copyright
in the United States (17 U.S.C. §105). The United States/Department of Commerce
reserve all rights to seek and obtain copyright protection in countries other
than the United States for Software authored in its entirety by the Department
of Commerce.  To this end, the Department of Commerce hereby grants to Recipient
a royalty-free, nonexclusive license to use, copy, and create derivative works
of the Software outside of the United States.

## Exceptions

- [Bootstrap](http://getbootstrap.com/) is licensed under MIT.
- [Select2](https://github.com/ivaynberg/select2) by Igor Vaynberg
is licensed under Apache License Version 2.0.
- [jquery.inputmask](https://github.com/RobinHerbots/jquery.inputmask) by Robin
Herbots is licensed under MIT.
- [jQuery](http://jquery.com/) by The jQuery Foundation is licensed under MIT.
- [Font Awesome](https://github.com/FortAwesome/Font-Awesome) by Dave Gandy
is licensed under SIL OFL 1.1 / MIT.
