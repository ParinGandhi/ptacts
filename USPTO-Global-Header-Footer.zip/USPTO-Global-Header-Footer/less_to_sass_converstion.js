const fs = require('fs');
const { exec } = require('child_process');
const path = require('path');
const less2sass = require('less2sass');

function convertLessTwoScss(sourcePath, destinationPath){

    fs.readdir(sourcePath, (err, files) =>{
        if(err){
            console.error("Could not read directory:", err);
            return;
        }

        files.forEach((file) =>{
            const filePath = path.join(sourcePath,file);

            fs.stat(filePath, (err, stats) =>{
                if(err){
                    console.log("Error reading filepath:"+err.message);
                    return;
                }
                
                if(stats.isDirectory()){
                    convertLessTwoScss(filePath, filePath);
                } else{
                    if(path.extname(file) === '.less'){
                        exec("less2scss -s " +path.resolve(filePath)+" -d "+path.resolve(destinationPath), (error, stdout, stderr) => {
         
                         if(error){
                             console.error("Error executing command:"+error.message);
                         }
         
                         if(stderr){
                             console.error("Error output:"+stderr)
                         }
         
                         console.log("Conversion successfull!!!");
         
                        });
                     }
                }
            });
        });
    });
}

const sourceDir = "./app/styles/less";
const desDir = "./app/styles/scss";

convertLessTwoScss(sourceDir, desDir);