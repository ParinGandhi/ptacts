var logout = (function () {
  'use strict';
  var stmLogout = function () {

    if (window.location.hostname.indexOf('fqt') != -1 || window.location.hostname.indexOf('dev') != -1 || window.location.hostname.indexOf('pvt') != -1 || window.location.hostname.indexOf('sit') != -1) {
      $.ajax({
        type: 'GET',
        url: 'https://rbac-services-fqt.etc.uspto.gov/rbac/services/authentication/logout/urls',
        dataType: 'json',
        xhrFields: {
          withCredentials: true
        },
        success: function (data) {
          console.log(data);
          for (var i = 0; i < data.length; i++) {

            if (data[i].search('TAB') != -1) {
              console.log("Okta Global logout being opened in new Tab to kill the session: " + data[i].split('::')[1]);
              var new_Window = window.open(data[i].split('::')[1], "_blank");
              setTimeout(function () {
                new_Window.close();
                console.log("New Okta Window closed!!!!!!!!");
              }, 2000);
            } else if (data[i].search('LANDING') != -1) {
              var redirectUri = data[i].split('::')[1];
              setTimeout(function () {
                window.location.href = redirectUri;
              }, 3000);
            } else {
              $.ajax({
                type: 'GET',
                url: data[i],
                dataType: 'text',
                xhrFields: {
                  withCredentials: true
                },
                success: function (response) {
                  console.log("Logged from Session Widget !!!!!!" + data[i]);
                },
                error: function (response) {
                  console.error("Failed to logout user!!!!!");
                }
              });
            }
          }
        },
        error: function (data) {
          console.error("Failed to fetch the urls!!!!!");
        }
      });
    } else {
      $.ajax({
        type: 'GET',
        url: 'https://rbac-services.uspto.gov/rbac/services/authentication/logout/urls',
        dataType: 'json',
        xhrFields: {
          withCredentials: true
        },
        success: function (data) {
          console.log(data);
          for (var i = 0; i < data.length; i++) {

            if (data[i].search('TAB') != -1) {
              console.log("Okta Global logout being opened in new Tab to kill the session: " + data[i].split('::')[1]);
              var new_Window = window.open(data[i].split('::')[1], "_blank");
              setTimeout(function () {
                new_Window.close();
                console.log("New Okta Window closed!!!!!!!!");
              }, 2000);
            } else if (data[i].search('LANDING') != -1) {
              var redirectUri = data[i].split('::')[1];
              setTimeout(function () {
                window.location.href = redirectUri;
              }, 3000);
            } else {
              $.ajax({
                type: 'GET',
                url: data[i],
                dataType: 'text',
                xhrFields: {
                  withCredentials: true
                },
                success: function (response) {
                  console.log("Logged from Session Widget !!!!!!" + data[i]);
                },
                error: function (response) {
                  console.error("Failed to logout user!!!!!");
                }
              });
            }
          }
        },
        error: function (data) {
          console.error("Failed to fetch the urls!!!!!");
        }
      });
    }

    localStorage.clear();
  }

  return {
    stmLogout: stmLogout
  };

})();