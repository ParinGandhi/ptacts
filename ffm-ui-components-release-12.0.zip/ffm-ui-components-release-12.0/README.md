# ffm-ui-components

# To Build Angular Components
- for commands below, prepend `npm run` if Angular CLI is not or cannot be installed (e.g. in Dev VM)
- `cd angular/`
- `npm install`
- If you have Angular CLI installed:
  - `ng build ngx-cms-design`
  - `ng build ngx-ffm-ui-components`
  - `ng serve`
    - to serve without conflicting with existing process using the same 4200 port (i.e. if PM-UI is running), serve on a different port with: `ng serve --port=4201`
      - if using npm run: `npm run ng serve -- --port=4201`
  - when updating ngx-cms-design or ngx-ffm-ui-components components, must rebuild changed project and serve to see changes
    - only ngx-cms-design: `ng build ngx-cms-design && ng serve`
    - only ngx-ffm-ui-components: `ng build ngx-ffm-ui-components && ng serve`
    - build both: `ng build ngx-cms-design && ng build ngx-ffm-ui-components`
    - build both & serve: `ng build ngx-cms-design && ng build ngx-ffm-ui-components && ng serve`
- Without Angular CLI installed (i.e. dev VM)
  - `npm run build ngx-cms-design`
  - `npm run build ngx-ffm-ui-components`
  - `npm start`
    - to serve without conflicting with existing process using the same 4200 port (i.e. if PM-UI is running), serve on a different port with: `npm start -- --port=4201`
  - when updating ngx-cms-design or ngx-ffm-ui-components components, must rebuild changed project and serve to see changes
    - only ngx-cms-design: `npm run build ngx-cms-design && npm start`
    - only ngx-ffm-ui-components: `npm run build ngx-ffm-ui-components && npm start`
    - build both: `npm run build ngx-cms-design && npm run build ngx-ffm-ui-components`
    - build both & serve: `npm run build ngx-cms-design && npm run build ngx-ffm-ui-components && npm start`

# To see demo page
- On a web browser, go to localhost:4200 (served on port 4200 by default)