const scanner = require('sonarqube-scanner');
const { exec } = require('child_process');
const argv = require('yargs-parser')(process.argv.slice(2))

require('dotenv').config();

const getBranch = () => new Promise((resolve, reject) => {
    return exec('git rev-parse --abbrev-ref HEAD', (err, stdout, stderr) => {
        if (err)
            reject(`getBranch Error: ${err}`);
        else if (typeof stdout === 'string')
            resolve(stdout.trim());
        else {
            reject('Failed to retrieve git branch')
        }
    });
});

async function retrieveGitBranch() {
    const branch = await getBranch();
    return branch;
}

retrieveGitBranch().then(bn => {

    if(argv.environment !== "local" && argv.environment !== "remote") {
        return Promise.reject("Invalid sonar env value or not provided. Abort sonar operation")
    }

    const projectName = "FFM-UI-COMPONENTS";

    const sonarProjectKey = (argv.environment === "local") ? `${projectName}:${bn.replace("/", "-")}` : projectName;
    const sonarProjectName = (argv.environment === "local") ? `${projectName}:${bn.replace("/", "-")}` : projectName;
    const sonarBranchName = (argv.environment === "local") ? "" : bn;

    if(argv.environment === "local") {
        scanner(
          {
            serverUrl : process.env.SONAR_LOCAL_URL,
            options: {
              'sonar.projectName': sonarProjectName,
              'sonar.projectDescription': 'FFM-UI-COMPONENTS',
              'sonar.projectKey': sonarProjectKey,
              'sonar.login': process.env.SONAR_LOCAL_LOGIN,
              'sonar.password': process.env.SONAR_LOCAL_PASSWORD,
              'sonar.sources': 'projects/ngx-cms-design/src, projects/ngx-ffm-ui-components/src, src',
              'sonar.tests': 'projects/ngx-cms-design/src, projects/ngx-ffm-ui-components/src, src',
              'sonar.javascript.lcov.reportPaths': 'reports/html/coverage/lcov.info, coverage/ngx-cms-design/lcov.info, coverage/ngx-ffm-ui-components/lcov.info',
              'sonar.testExecutionReportPaths': 'reports/ut_report.xml',
              'sonar.exclusions': '**/node_modules/**, src/app/assets/images',
              'sonar.test.inclusions': '**/*.spec.ts',
              'sonar.sourceEncoding': 'UTF-8',
              'sonar.log.level': (argv.sonarloglevel) ? argv.sonarloglevel : "INFO",
              'sonar.verbose': (argv.sonarverbose) ? argv.sonarverbose : "false"
            }
          },
          () => process.exit()
        )
    } else {
        scanner(
          {
            serverUrl : process.env.SONAR_URL,
            token : process.env.SONAR_TOKEN,
            options: {
              'sonar.projectName': sonarProjectName,
              'sonar.projectDescription': 'FFM-UI-COMPONENTS',
              'sonar.projectKey': sonarProjectKey,
              'sonar.branch.name': sonarBranchName,
              'sonar.sources': 'projects/ngx-cms-design/src, projects/ngx-ffm-ui-components/src, src',
              'sonar.tests': 'projects/ngx-cms-design/src, projects/ngx-ffm-ui-components/src, src',
              'sonar.javascript.lcov.reportPaths': 'reports/html/coverage/lcov.info, coverage/ngx-cms-design/lcov.info, coverage/ngx-ffm-ui-components/lcov.info',
              'sonar.testExecutionReportPaths': 'reports/ut_report.xml',
              'sonar.exclusions': '**/node_modules/**, src/app/assets/images',
              'sonar.test.inclusions': '**/*.spec.ts',
              'sonar.sourceEncoding': 'UTF-8',
              'sonar.log.level': (argv.sonarloglevel) ? argv.sonarloglevel : "INFO",
              'sonar.verbose': (argv.sonarverbose) ? argv.sonarverbose : "false"
            }
          },
          () => process.exit()
        )
    }

}).catch(err => {
    console.error('Failed to complete Sonar process!', err);
});
