# FFM-UI-COMPONENTS

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 13.1.4.

# Versions
1.4 - For use with Angular 18
1.3 - For use with Angular 17
1.2 - For use with Angular 15
1.1 - For use with Angular 13

## Development server

Run `ng build ngx-cms-design` to build the project. The build artifacts will be stored in the `dist/` directory.
Run `ng build ngx-ffm-ui-components` to build the project. The build artifacts will be stored in the `dist/` directory.
Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build ngx-cms-design` to build the project. The build artifacts will be stored in the `dist/` directory.
Run `ng build ngx-ffm-ui-components` to build the project. The build artifacts will be stored in the `dist/` directory.
Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `npm run test:coverage:ci` to execute tests for sample all and libraries for CI - Headless
Run `ng test library-name` to execute tests for a specific library
Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities.

## Build ngx-ffm-ui-components library

Run `ng build ngx-ffm-ui-components` to build the project. The build artifacts will be stored in the `dist/ngx-ffm-ui-components` directory.

## Troubleshooting

If there are conflicts with dependencies remove node_modules folder and package-lock file. Run npm install again.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
