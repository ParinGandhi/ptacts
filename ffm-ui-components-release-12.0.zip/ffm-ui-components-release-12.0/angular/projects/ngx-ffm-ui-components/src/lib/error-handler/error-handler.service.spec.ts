import { Injectable } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { LogService } from '../log/log.service';
import { ErrorHandlerService } from './error-handler.service';

describe('ErrorHandlerService', () => {
  let service: ErrorHandlerService;

  @Injectable()
  class LogServiceMock extends LogService {

  };

  let envMock = {
    production: true,
    debug: false,
    logLevel: 0,
    logWithDate: true,
    logRemote: false,
    logUri: '',
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: 'environment', useValue: envMock },
        { provide: LogService, useClass: LogServiceMock}
      ]
    });
    service = TestBed.inject(ErrorHandlerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
