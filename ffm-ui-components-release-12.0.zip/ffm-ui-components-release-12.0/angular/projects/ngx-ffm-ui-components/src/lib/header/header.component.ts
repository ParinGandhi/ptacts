import { DomSanitizer } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/common';
import { Component, Inject, OnInit, ViewEncapsulation, SecurityContext, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AuthorizationService } from '../authorization/authorization.service';
import { StateService } from '../state/state.service';
import { HeaderService } from './header.service';
import { BannerComponent } from 'ngx-cms-design';
import { subscribeOn } from 'rxjs';
import { MenuItem } from '../header-dropdown-menu/header-dropdown-menu.component';

export interface HeaderLinks {
  label: string;
  route?: string;
  options?: any;
  path?: string;
  menuItems: Array<MenuItem>;
  relatedRoutes?: RegExp[];
}

@Component({
  selector: 'ffm-ui-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  encapsulation: ViewEncapsulation.None,
  host: {
    '(document:click)': 'handleOutsideClick($event)',
  },
})
export class HeaderComponent implements OnInit {
  public menuOpenedMap = new Map();
  public window: Window | null;

  @ViewChild(BannerComponent) govBanner?: BannerComponent;
  bannerHidden?: boolean = true;

  constructor(
    private router: Router,
    public headerService: HeaderService,
    @Inject(DOCUMENT) private document: Document,
    private authService: AuthorizationService,
    public stateService: StateService,
    private sanitizer: DomSanitizer
  ) {
    this.window = this.document.defaultView;
  }

  ngOnInit(): void {
      // This is intentional
  }

  ngAfterViewInit(): void {
    if (this.govBanner) {
      this.govBanner.stateChanged.subscribe((stateBanner) => {
        this.headerService.$bannerHidden.next(stateBanner);
      });
      this.headerService.$bannerHidden.subscribe((stateBanner) => {
        this.bannerHidden = stateBanner;
      });
    }
  }

  /**
   * Checks if the path passed in is the active one
   * @param path the URL path to be checked
   */
  isActive(path: string): boolean {
    const splitHref = this.window?.location.href.split('/');
    if (splitHref) {
      const toCompare = splitHref[3];
      if (path === toCompare) {
        return true;
      }
    }

    return false;
  }

  /**
   * Checks if current Header link is active
   * @param link the HeaderLinks to check
   */
   isLinkActive(link: HeaderLinks): boolean {
    const href = this.window?.location?.href;
    return this.isHrefIncludesRoute(link?.route, href)
      || link.menuItems.some(item => this.isHrefIncludesRoute(item?.route, href))
      || (link.relatedRoutes !== undefined && link.relatedRoutes.some(route => this.isHrefIncludesRouteRegex(route, href)));
  }

  isHrefIncludesRoute(route: any, href: any | undefined): boolean {
    return route && href?.includes(route);
  }

  /**
   * Checks if a related route to the Header link is active using regex
   * @param route - the route expressed as a regex
   * @param href - the current URL
   * @returns boolean - true if the regex and href finds a match
   */
  isHrefIncludesRouteRegex(route: RegExp, href: string | undefined): boolean {
    return href !== undefined && route.test(href);
  }

  /**
   * Perform logic for logout such as redirect to the sign out endpoint
   * exposed by the oauth identity provider, etc.
   */
  logout(): void {
    this.authService.logout();
  }

  /**
   * Send the user to the home page which is whatever the page configured
   * in the router for "/"
   */
  goHome(): void {
    let sanitizedUrl = this.sanitizer.sanitize(SecurityContext.URL, '/');
    if (sanitizedUrl && this.window) {
      this.window.location.href = sanitizedUrl;
    }
  }

  alertClosed(id: string): void {
      // This is intentional
  }

  /**
   * Toggle dropdown menu open
   * @param label Current event label
   */
  toggleMenuOpen(label: string): void {
    if (!this.menuOpenedMap.has(label)) {
      this.menuOpenedMap.set(label, false);
    }
    for (let [key, value] of this.menuOpenedMap) {
      if (key === label) {
        this.menuOpenedMap.set(key, !value);
      } else {
        this.menuOpenedMap.set(key, false);
      }
    }
  }

  /**
   * Method to close dropdown on outside clicks
   * @param event Clicking event
   */
  handleOutsideClick(event: any) {
    if (
      !(
        event.target?.classList?.contains('headerMenuDropdownLink') ||
        event.target?.classList?.contains('headerMenuDropdownArrowIcon') ||
        event.target?.parentNode?.classList?.contains('headerMenuDropdownArrowIcon')
      )
    ) {
      this.menuOpenedMap.clear();
    }
  }
}
