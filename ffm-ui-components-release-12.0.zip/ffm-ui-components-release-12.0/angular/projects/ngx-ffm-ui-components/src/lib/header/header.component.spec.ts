import { DOCUMENT } from '@angular/common';
import { Injectable } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CmsDesignModule } from 'ngx-cms-design';

import { HeaderComponent } from './header.component';
import { HeaderService } from './header.service';

@Injectable()
class HeaderServiceMock extends HeaderService {

};

let envMock = {
  production: false,
  debug: false,
  bffUri: 'http://localhost:9999/api',
  oauthUri: '',
  logoutRedirectUri: '',
  logoutRedirectFromUri: ''
}

let appConfigMock = {
  serviceHeaders: {
    'role-id': 'pm',
    'source-system-name': 'FFM_PM',
    'user-id': 'testUser',
  },
}

const mockEvent = (target: boolean, parent: boolean) => {
  return {
    target: {
      classList: {
        contains: function () {
          return target;
        },
      },
      parentNode: {
        classList: {
          contains: function () {
            return parent;
          },
        },
      }
    },
  };
};

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  let mockWindow = { location: { href: 'http://localhost:4200/sample' } };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, CmsDesignModule],
      declarations: [HeaderComponent],
      providers: [
        {
          provide: HeaderService, useClass: HeaderServiceMock,
        },
        {
          provide: 'Window', useValue: mockWindow
        },
        {
          provide: 'environment', useValue: envMock
        },
        { provide: 'AppConfig', useValue: appConfigMock }
      ]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should not be active path', () => {
    expect(component.isActive('')).toBeFalse();
  })

  it('should not be active route', () => {
    let link = {
      label: 'test',
      route: '/not-active-test',
      menuItems: [],
    }
    expect(component.isLinkActive(link)).toBeFalse();
  })

  it('should not be active route for menu item', () => {
    let link = {
      label: 'menu',
      menuItems: [
        {
          label: 'test',
          route: '/not-active-test',
        },
      ],
    }
    expect(component.isLinkActive(link)).toBeFalse();
  })

  it('should be active route', () => {
    let link = {
      label: 'test',
      route: '/',
      menuItems: [],
    }
    expect(component.isLinkActive(link)).toBeTrue();
  })
  
  it('should be active route for menu', () => {
    let link = {
      label: 'menu',
      menuItems: [
        {
          label: 'test',
          route: '/',
        },
      ],
    }
    expect(component.isLinkActive(link)).toBeTrue();
  })

  it('should not be active route for relatedRoute', () => {
    let link = {
      label: 'relatedRoute',
      menuItems: [],
      relatedRoutes: [
        /\/fruits/
      ]
    };
    expect(component.isLinkActive(link)).toBeFalse();
  });

  it('should toggleMenuOpen', () => {
    let label = 'label';
    let label2 = 'label2';
    component.toggleMenuOpen(label);
    expect(component.menuOpenedMap.get(label)).toBeTrue;
    component.toggleMenuOpen(label2);
    expect(component.menuOpenedMap.get(label)).toBeFalse;
    expect(component.menuOpenedMap.get(label2)).toBeTrue;
    component.toggleMenuOpen("");
    expect(component.menuOpenedMap.get(label2)).toBeFalse;
  })

  it('should handleOutsideClick', () => {
    component.toggleMenuOpen('label');
    component.handleOutsideClick(mockEvent(true, false));
    component.handleOutsideClick(mockEvent(false, true));
    expect(component.menuOpenedMap.size).toBe(1);
    component.handleOutsideClick(mockEvent(false, false));
    expect(component.menuOpenedMap.size).toBe(0);
  })
});
