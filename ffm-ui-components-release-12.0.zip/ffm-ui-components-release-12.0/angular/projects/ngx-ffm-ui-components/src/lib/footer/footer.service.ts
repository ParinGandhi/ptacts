import { FooterLinkGroup } from './footer.component';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FooterService {

  private footerLinks: FooterLinkGroup[] = [];
  linkGroupLimit?: number;

  constructor() {
      // This is intentional
  }
  /**
   * change the links displayed in the footer.  Array of FooterLinkGroup, each group contains an array of links.
   * 3 FooterLinkGroups max
   * @param  {FooterLinkGroup[]} links
   */
  setFooterLinks(links: FooterLinkGroup[]) {

    /**
     * Limit amount of links allowed
     */
    if (this.linkGroupLimit) {
      this.footerLinks = [];
      for (let index = 0; index < links.length; index++) {
        if (index < this.linkGroupLimit) {
          this.footerLinks.push(links[index]);
        }
        else {
          break;
        }
      }
    }
    else {
      this.footerLinks = links;
    }
  }

  getFooterLinks(): FooterLinkGroup[] {
    return this.footerLinks;
  }
}
