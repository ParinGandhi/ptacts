import { CmsDesignModule } from 'ngx-cms-design';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { FooterComponent } from './footer.component';
import { FooterService } from 'ngx-ffm-ui-components';
import { Injectable } from '@angular/core';

@Injectable()
class FooterServiceMock extends FooterService {

};

let envMock = {
  production: false,
  debug: false,
  bffUri: 'http://localhost:9999/api',
  oauthUri: '',
  logoutRedirectUri: '',
  logoutRedirectFromUri: ''
}

let appConfigMock = {
  serviceHeaders: {
    'role-id': 'pm',
    'source-system-name': 'FFM_PM',
    'user-id': 'testUser'
  },
}


describe('FooterComponent', () => {
  let component: FooterComponent;
  let fixture: ComponentFixture<FooterComponent>;
  let mockWindow = { location: { href: 'http://localhost:4200/sample' } };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, CmsDesignModule],
      declarations: [FooterComponent],
      providers: [
        {
          provide: FooterService, useClass: FooterServiceMock,
        },
        {
          provide: 'Window', useValue: mockWindow
        },
        {
          provide: 'environment', useValue: envMock
        },
        { provide: 'AppConfig', useValue: appConfigMock }
      ]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
