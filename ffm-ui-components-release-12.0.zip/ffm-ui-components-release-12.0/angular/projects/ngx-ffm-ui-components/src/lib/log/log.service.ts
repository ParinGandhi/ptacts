import { LogEntry } from './log-entry.model';
import { Observable, of } from 'rxjs';
import { Inject, Injectable } from '@angular/core';

export enum LogLevel {
  All = 0,
  Debug = 1,
  Info = 2,
  Warn = 3,
  Error = 4,
  Fatal = 5,
  Off = 6
}

@Injectable({
  providedIn: 'root'
})
export class LogService {

  level: LogLevel = LogLevel.Warn;
  logWithDate: boolean = true;
  logRemote: boolean = false;
  logUri: string | undefined;

  constructor(@Inject('environment') private environment: any) {
    console.log('Log Level: ', environment?.logLevel);
    this.level = environment?.logLevel;
    this.logWithDate = environment?.logWithDate;
    this.logRemote = environment?.logRemote;
    if (environment?.logUri && environment?.logUri.length) {
      this.logUri = environment?.logUri;
    }
  }

    log(msg: string, ...optionalParams: any[]) {
      this.writeToLog(msg, LogLevel.All, optionalParams);
    }

    debug(msg: string, ...optionalParams: any[]) {
      this.writeToLog(msg, LogLevel.Debug, optionalParams);
    }

    info(msg: string, ...optionalParams: any[]) {
      this.writeToLog(msg, LogLevel.Info, optionalParams);
    }

    warn(msg: string, ...optionalParams: any[]) {
      this.writeToLog(msg, LogLevel.Warn, optionalParams);
    }

    error(msg: string, ...optionalParams: any[]) {
      this.writeToLog(msg, LogLevel.Error, optionalParams);
    }

    fatal(msg: string, ...optionalParams: any[]) {
      this.writeToLog(msg, LogLevel.Fatal, optionalParams);
    }


    private writeToLog(msg: string, level: LogLevel, params: any[]) {
      if (this.shouldLog(level)) {
        let entry: LogEntry = new LogEntry();
        entry.message = msg;
        entry.level = level;
        entry.additionalInfo = params;
        entry.logWithDate = this.logWithDate;

        this.logConsole(entry);

        // If remote login enabled,
        if(this.logRemote) {
          this.logRemoteApi(entry);
        }
      }
    }

    private shouldLog(level: LogLevel): boolean {
      if ((level >= this.level && level !== LogLevel.Off) || this.level === LogLevel.All) {
        return true;
      }
      return false
    }

    private formatParams(params: any[]): string {
      let response: string = params.join(", ");

      if (params.some(p => typeof p == "object")) {
        response = "";

        for (let item of params) {
          response += JSON.stringify(item) + ", ";
        }
      }
      return response;
    }

    private logConsole(entry: LogEntry): Observable<boolean> {
      if(entry.level === LogLevel.Error || entry.level === LogLevel.Fatal) {
        console.error(entry.buildLogString());
      }
      else {
        console.log(entry.buildLogString());
      }
      return of(true);
    }

    private logRemoteApi(entry: LogEntry): Observable<boolean> {
      // Implement an http request to log to our backend or a service
      return of(true);
    }
}
