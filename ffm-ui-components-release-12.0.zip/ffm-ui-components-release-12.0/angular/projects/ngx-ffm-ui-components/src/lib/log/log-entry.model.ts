import { LogLevel } from './log.service';
export class LogEntry {
  entryDate: Date = new Date();
  message: string = "";
  level: LogLevel = LogLevel.Debug;
  additionalInfo: any[] = [];
  logWithDate: boolean = true;

  buildLogString(): string {
    let result: string = "";

    if (this.logWithDate) {
      result = new Date() + " - ";
    }

    result += "Type: " + LogLevel[this.level];
    result += " - Message: " + this.message;

    if(this.additionalInfo.length) {
      result += " - Additional Info: " + this.formatParams(this.additionalInfo);
    }

    return result;
  }

  private formatParams(params: any[]): string {
    let ret: string = params.join(",");

    // Is there at least one object in the array?
    if (params.some(p => typeof p == "object")) {
        ret = "";

        // Build comma-delimited string
        for (let item of params) {
            ret += JSON.stringify(item) + ",";
        }
    }

    return ret;
  }
}
