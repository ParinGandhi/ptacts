import { LogEntry } from './log-entry.model';

describe('LogEntry', () => {
  it('should create an instance', () => {
    expect(new LogEntry()).toBeTruthy();
  });
});
