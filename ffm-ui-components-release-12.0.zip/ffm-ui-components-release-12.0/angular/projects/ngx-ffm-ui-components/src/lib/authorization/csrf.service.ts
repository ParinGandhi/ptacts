import { StateService } from './../state/state.service';
import { Inject, Injectable } from '@angular/core';
import { Get } from 'arch-ng-ui/lib/rest-client/rest-client';
import { LogService } from '../log/log.service';
import { StateServiceDefaultKeys } from '../state/state-default-keys';

@Injectable({
  providedIn: 'root',
})
export class CsrfService {
  constructor(
    @Inject('environment') private environment: any,
    @Inject('AppConfig') private AppConfig: any,
    private readonly logService: LogService,
    private readonly stateService: StateService
  ) {}

  checkCSRF(): boolean {
    if (this.getCSRFToken()) {
      return true;
    }
    return false;
  }

  getCSRFToken(): string | null {
    return this.stateService.dataSubject.value[
      StateServiceDefaultKeys.CSRF_TOKEN
    ];
  }

  getNewCSRFToken(): Promise<string> {
    let bffUri = this.environment?.bffUri;
    let domainSplit = bffUri.split('/');
    let baseDomain;
    if (domainSplit.length > 1) {
      baseDomain = bffUri.split(domainSplit[domainSplit.length - 1])[0];
    } else {
      baseDomain = bffUri + '/';
    }

    const endpoint = `${baseDomain}csrf`;

    return new Promise((resolve, reject) => {
      new Get(endpoint)
        .withHeaders(this.AppConfig.serviceHeaders)
        .execute()
        .then((response: any) => {
          if (
            response &&
            response.body &&
            response.body.resultType === 'SUCCESS' &&
            response.body.result &&
            response.body.result.csrfToken &&
            response.body.result.csrfToken.value
          ) {
            this.stateService.setData(
              StateServiceDefaultKeys.CSRF_TOKEN,
              response.body.result.csrfToken.value
            );
            this.setEncryptionKey(response.body.result.csrfToken.value);
            return resolve(response.body.result.csrfToken.value);
          }
          return reject();
        })
        .catch((err: any) => {
          this.logService.error(
            'Error requesting csrf token: ',
            err,
            'CsrfService',
            58
          );
          return reject();
        });
    });
  }

  private setEncryptionKey(token: string): void {
    this.stateService.setData(
      StateServiceDefaultKeys.EK,
      new Date().getMonth() +
        token.replace(/-/g, '') +
        new Date().getFullYear()
    );
  }
}
