import { LogService } from './../log/log.service';
import { CsrfService } from './csrf.service';
import { SessionService } from './session.service';
import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  Route,
  RouterStateSnapshot,
  UrlSegment,
  UrlTree,
} from '@angular/router';
import { Observable } from 'rxjs';
import { AuthorizationService } from './authorization.service';

@Injectable({
  providedIn: 'root',
})
export class ComponentGuard {
  constructor(
    private authService: AuthorizationService,
    private sessionService: SessionService,
    private csrfService: CsrfService,
    private logService: LogService,
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ):
    | boolean
    | UrlTree
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree> {
    if (route.data) {
      // Use of Promise.all to wait for all async methods kicked off by service and caching decorator
      return this.authorizeComponent(route)
        .then((result) => {
          if (result !== undefined && result) {
            return true;
          } else {
            this.authService.redirectUnauthorized();
            return false;
          }
        })
        .catch((err) => {
          this.authService.logout();
          return false;
        });
    } else {
      return false;
    }
  }

  canMatch(
    route: Route,
    segments: UrlSegment[]
  ):
    | boolean
    | UrlTree
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree> {
    if (route.data) {
      return this.authorizeComponent(route)
        .then((result) => {
          if (result !== undefined && result) {
            return true;
          } else {
            this.authService.redirectUnauthorized();
            return false;
          }
        })
        .catch((err) => {
          this.authService.logout();
          return false;
        });
    } else {
      return false;
    }
  }

  private async authorizeComponent(
    route: Route | ActivatedRouteSnapshot
  ): Promise<boolean> {
    if (route.data) {
      let componentName = route.data['componentName'] as string;

      if (this.sessionService.checkSessionCookie('X-Session-Id')) {
        if (this.csrfService.checkCSRF()) {
          return this.authService.authorize(componentName);
        } else {
          // Get new CSRF token
          return this.csrfService.getNewCSRFToken().then((result) => {
            return this.authService.authorize(componentName);
          });
        }
      } else {
        // Get new Session cookie
        return this.sessionService.getNewSessionCookie().then((result) => {
          if (result) {
            // Get new CSRF token
            return this.authService.authorize(componentName);
          } else {
            // Error getting Session cookie
            return Promise.reject(false);
          }
        });
      }
    } else {
      return Promise.resolve(false);
    }
  }
}
