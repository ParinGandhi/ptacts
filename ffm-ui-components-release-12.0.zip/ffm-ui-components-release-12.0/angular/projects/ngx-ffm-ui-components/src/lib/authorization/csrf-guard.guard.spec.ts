import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CsrfGuard } from './csrf-guard.guard';

describe('CsrfGuardGuard', () => {
  let guard: CsrfGuard;

  let envMock = {
    production: false,
    debug: false,
    bffUri: 'http://localhost:9999/api',
    oauthUri: '',
    logoutRedirectUri: '',
    logoutRedirectFromUri: '',
  };

  let appConfigMock = {
    serviceHeaders: {
      'role-id': 'pm',
      'source-system-name': 'FFM_PM',
      'user-id': 'testUser',
    },
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: 'environment', useValue: envMock },
        { provide: 'AppConfig', useValue: appConfigMock },
      ],
      imports: [RouterTestingModule],
    });
    guard = TestBed.inject(CsrfGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
