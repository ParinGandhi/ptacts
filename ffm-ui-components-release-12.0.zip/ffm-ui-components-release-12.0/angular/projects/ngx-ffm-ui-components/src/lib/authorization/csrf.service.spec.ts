import { TestBed } from '@angular/core/testing';

import { CsrfService } from './csrf.service';
import { Response } from 'arch-ng-ui/lib/rest-client/response';
import { Get } from 'arch-ng-ui/lib/rest-client/rest-client';

describe('CsrfService', () => {
  let service: CsrfService;

  let envMock = {
    production: false,
    debug: false,
    bffUri: 'http://localhost:9999/api',
    oauthUri: '',
    logoutRedirectUri: '',
    logoutRedirectFromUri: '',
  };

  let appConfigMock = {
    serviceHeaders: {
      'role-id': 'pm',
      'source-system-name': 'FFM_PM',
      'user-id': 'testUser',
    },
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: 'environment', useValue: envMock },
        { provide: 'AppConfig', useValue: appConfigMock },
      ],
    });
    service = TestBed.inject(CsrfService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('csrf should not exist', () => {
    expect(service.checkCSRF()).toBeFalse();
  });

  it('csrf should be sample-token', (done) => {
    let getSpy = spyOn(Get.prototype, 'execute').and.returnValue(
      new Promise((resolve) => {
        resolve(
          new Response({}, 200, 'Ok', {}, {}).withBody({
            resultType: 'SUCCESS',
            result: {
              csrfToken: {
                value: 'sample-token',
              },
            },
          })
        );
      })
    );

    service.getNewCSRFToken().then(() => {
      expect(service.checkCSRF()).toBeTrue();
      expect(service.getCSRFToken()).toEqual('sample-token');
      done();
    });
  });
});
