export enum StateServiceDefaultKeys {
  USER_ID = 'userId',
  CSRF_TOKEN = 'csrfToken',
  EK = 'ek'
}
