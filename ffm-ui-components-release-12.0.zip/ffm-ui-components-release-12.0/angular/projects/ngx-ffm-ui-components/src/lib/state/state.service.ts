import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class StateService {
  private data: { [key: string]: any } = {};
  public dataSubject = new BehaviorSubject<any>(this.data);

  constructor() {
      // This is intentional
  }

  /**
   * @param  {string} key value to store data under
   * @param  {any} data data to be stored
   */
  setData(key: string, data: any) {
    this.data[key] = data;
    this.dataSubject.next(this.data);
  }

  getData(key: string): Observable<any> {
    let objKey = key as keyof typeof this.dataSubject;

    if (objKey) {
      const dataValue = this.dataSubject.value;
      return of(dataValue[objKey]);
    }

    throw new Error('Data not found');
  }

  clearData() {
    this.data = {};
    this.dataSubject.next(this.data);
    this.dataSubject.complete();
  }
}
