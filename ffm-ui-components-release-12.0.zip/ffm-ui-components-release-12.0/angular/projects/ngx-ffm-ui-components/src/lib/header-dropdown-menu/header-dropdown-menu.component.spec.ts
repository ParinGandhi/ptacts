import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CmsDesignModule } from 'ngx-cms-design';
import { HeaderDropdownMenuComponent } from './header-dropdown-menu.component';

describe('HeaderComponent', () => {
  let component: HeaderDropdownMenuComponent;
  let fixture: ComponentFixture<HeaderDropdownMenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, CmsDesignModule],
      declarations: [HeaderDropdownMenuComponent],
      providers: []
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderDropdownMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should onClick', () => {
    expect(component.onClick(new MouseEvent("test"), 0)).toBeUndefined;
  })
});
