import { Component, EventEmitter, Input, Output } from '@angular/core';

export interface MenuIndex {
  menuIndex: number;
}

export interface MenuItem {
  label: string;
  route?: string;
  options?: any;
  path?: string;
  description?: string;
}

@Component({
  selector: 'header-dropdown-menu',
  templateUrl: './header-dropdown-menu.component.html',
  styleUrls: ['./header-dropdown-menu.component.scss']
})
export class HeaderDropdownMenuComponent {
  @Input()  public menuItems: Array<MenuItem> = [];
  @Output() public itemSelected = new EventEmitter<MenuIndex>();

  constructor() {
      // This is intentional
  }

  public onClick(event: MouseEvent, menuIndex: number) {
    event.stopPropagation();
    this.itemSelected.emit({
      menuIndex: menuIndex
    });
  }
}
