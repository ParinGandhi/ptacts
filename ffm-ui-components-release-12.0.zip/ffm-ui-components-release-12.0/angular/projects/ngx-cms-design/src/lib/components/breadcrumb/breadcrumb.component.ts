import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  OnDestroy,
  SecurityContext,
} from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { NavigationEnd, Router, ActivationEnd, Params } from '@angular/router';
import classNames from 'classnames';
import { find, findIndex, uniqueId } from 'lodash';
import { BehaviorSubject, combineLatest, Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';

export type BreadCrumb = {
  alias: string;
  url: string;
  hidden?: boolean;
};

export type BreadcrumbSize = 'small';

@Component({
  selector: 'cms-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.css'],
})
export class BreadcrumbComponent implements OnInit, OnDestroy {
  urlAliasMap$ = new BehaviorSubject<BreadCrumb[]>([]);
  primitiveRoutes$: Observable<NavigationEnd>;
  aliasedRoutes$: Observable<BreadCrumb[]>;
  // using BehaviorSubject so that it fires at least once, even if there are no parameters
  params$: BehaviorSubject<Params> = new BehaviorSubject<Params>({});

  @Input() id: string | number | undefined;
  @Input() className?: string;
  @Input() autoFocus = false;
  @Input() hidden = false;
  @Input() size?: BreadcrumbSize;
  @Input() set urlAliasesMap(value: BreadCrumb[]) {
    this.urlAliasMap$.next(value);
  }
  @Output() onItemClick: EventEmitter<any> = new EventEmitter();

  public classes?: string;
  public sizeClass?: string;
  public routes: BreadCrumb[] = [];

  constructor(
    private readonly router: Router,
    private sanitizer: DomSanitizer
  ) {
    this.id = this.id || uniqueId('breadcrumb_');

    // Observable which gets updated when navigation changes
    this.primitiveRoutes$ = this.router.events.pipe(
      filter((e): e is NavigationEnd => e instanceof NavigationEnd)
    );

    // Observable which gets updated when route parameters change
    this.router.events
      .pipe(
        filter(
          (e) =>
            e instanceof ActivationEnd &&
            Object.keys(e.snapshot.params).length > 0
        ),
        map((e) => (e instanceof ActivationEnd ? e.snapshot.params : {}))
      )
      .subscribe(this.params$);

    // Group all 3 Observables and update breadcrumbs whenever any of the 3 get notifications
    this.aliasedRoutes$ = combineLatest([
      this.urlAliasMap$,
      this.primitiveRoutes$,
      this.params$,
    ]).pipe(
      map(([urlAliases, activeURL, params]) => {
        let splitRoutes = [...new Set(activeURL.url.split('#')[0].split('/'))];        
        let paramsArray = Object.values(params);
        let routeTokenBuilder: unknown = '';

        return splitRoutes.map(
          (routeToken: string, index: number, array: string[]) => {
            let nextParam;
            if (
              index + 1 < array.length &&
              paramsArray.find((e) => e.trim() === array[index + 1].trim())
            ) {
              nextParam = array[index + 1];
            }
            // checks if current token is a parameter
            if (paramsArray.find((e) => e.trim() === routeToken.trim())) {
              return {
                url: `/${routeToken}`,
                alias: routeToken.trim(),
                hidden: true,
              };
            }
            // checks if current token has an alias set
            else if (find(urlAliases, ['url', routeToken])) {
              let index = findIndex(urlAliases, ['url', routeToken]);
              // if there is a parameter next
              if (nextParam) {
                let urlLink = `${routeTokenBuilder}/${routeToken}/${nextParam}`;
                routeTokenBuilder += '/' + routeToken + '/' + nextParam;
                return {
                  url: urlLink,
                  alias: urlAliases[index].alias + ' - ' + nextParam,
                };
              } else if (routeTokenBuilder == '') {
                routeTokenBuilder = routeToken;
                return {
                  url: `${routeToken}`,
                  alias: urlAliases[index].alias,
                  hidden: urlAliases[index].hidden,
                };
              } else
                return {
                  url: `${routeTokenBuilder}/${routeToken}`,
                  alias: urlAliases[index].alias,
                  hidden: urlAliases[index].hidden,
                };
            }
            // use token without an alias
            else {
              if (routeToken === '') {
                return { url: `/${routeToken}`, alias: 'Home' };
              } else {
                let tmpAlias = routeToken.split('?')[0];
                let title = tmpAlias
                  .split('-')
                  .map(
                    (urlTitle) =>
                      urlTitle.charAt(0).toUpperCase() + urlTitle.slice(1)
                  );
                // if there is a parameter next
                if (nextParam) {
                  let urlLink = `${routeTokenBuilder}/${routeToken}/${nextParam}`;
                  routeTokenBuilder += '/' + routeToken + '/' + nextParam;
                  // Check if parameter has been aliased with previous token
                  if (find(urlAliases, ['url', routeToken + ' - ' + nextParam])) {
                    let index = findIndex(urlAliases, ['url', routeToken + ' - ' + nextParam]);
                    return {
                      url: urlLink,
                      alias: urlAliases[index].alias,
                      hidden: urlAliases[index].hidden
                    };
                  }
                  else {
                    return {
                      url: urlLink,
                      alias: title.join(' ') + ' - ' + nextParam,
                    };
                  }
                } else if (routeTokenBuilder == '') {
                  let urlLink = `${routeToken}`;
                  routeTokenBuilder = routeToken;
                  return { url: urlLink, alias: title.join(' ') };
                } else {
                  let urlLink = `${routeTokenBuilder}/${routeToken}`;
                  routeTokenBuilder += '/' + routeToken;
                  return { url: urlLink, alias: title.join(' ') };
                }
              }
            }
          }
        );
      })
    );
  }

  ngOnInit(): void {
    this.sizeClass = this.size && 'breadcrumb--' + this.size;
    this.classes = classNames('breadcrumb', this.sizeClass, this.className);

    this.aliasedRoutes$.subscribe((routes) => {
      this.routes = routes;
    });
  }

  ngOnDestroy(): void {
    this.urlAliasMap$.unsubscribe();
  }

  itemClick(event: any, item: BreadCrumb) {
    if (!item.url) {
      event.preventDefault();
    }

    this.onItemClick.emit({
      originalEvent: event,
      item: item,
    });
  }

  isLink(index: number): boolean {
    if (index >= this.routes.length - 1) {
      return false;
    } else if (
      index === this.routes.length - 2 &&
      this.routes[this.routes.length - 1].hidden === true
    ) {
      return false;
    }
    return true;
  }

  sanitizeUrl(url: string): string | null {
    return this.sanitizer?.sanitize(SecurityContext.URL, url);
  }
}
