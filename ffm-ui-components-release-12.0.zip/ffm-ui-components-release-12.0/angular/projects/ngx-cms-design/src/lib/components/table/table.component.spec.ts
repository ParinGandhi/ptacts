import { ComponentFixture, TestBed } from '@angular/core/testing';
//import { createPublicKey } from 'crypto';
import { CmsDesignModule } from 'ngx-cms-design';
import { DefaultConfig, TableModule } from 'ngx-easy-table';

import { TableComponent } from './table.component';

describe('TableComponent', () => {
  let component: TableComponent;
  let fixture: ComponentFixture<TableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ CmsDesignModule, TableModule ],
      declarations: [ TableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TableComponent);
    component = fixture.componentInstance;
    component.data = [{
      status: '',
      phone: '+1 (934) 551-2224',
      age: 20,
      address: { street: 'North street', number: 12 },
      company: 'ZILLANET',
      companyUrl: 'http://www.google.com',
      name: 'Valentine Webb',
      picker: 3,
    }];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should throw error', () => {
    component.config = {...DefaultConfig,checkboxes: true};
    component.displayFirstRowAsHeader = true;
    fixture.detectChanges();
    expect(function() { component.ngOnInit() }).toThrow(new Error("A table can't have both checkboxes and have the first column set as header"));
  })

  it('should set th for element', () => {
    component.displayFirstRowAsHeader = true;

    component.rowAccessibilityUpdates();
    fixture.detectChanges();
    const compiled = fixture.nativeElement.querySelectorAll('th') as HTMLElement;
    expect(compiled).toBeTrue;
  })
});
