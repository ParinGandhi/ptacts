import { ButtonComponent } from './../button/button.component';
import {
  DropdownErrorPlacement,
  DropdownOptions,
  DropdownSize,
} from './../dropdown/dropdown.component';
import {
  Component,
  Input,
  OnInit,
  ElementRef,
  AfterViewInit,
  Self,
  Optional,
  ViewChild,
  ViewEncapsulation,
  Renderer2,
  ChangeDetectorRef,
  AfterContentInit,
  OnDestroy,
} from '@angular/core';
import { NOOP_VALUE_ACCESSOR } from './../text-field/text-input.component';
import { NgControl, UntypedFormGroup, AbstractControl } from '@angular/forms';
import { FormControlComponent } from '../form-control/form-control.component';
import { errorPlacementDefault } from '../flags';
import * as _ from 'lodash';
import { DropdownPosition, NgSelectComponent } from '@ng-select/ng-select';
import classNames from 'classnames';
import { Subscription } from 'rxjs';

@Component({
  selector: 'cms-multi-dropdown',
  templateUrl: './multi-dropdown.component.html',
  styleUrls: ['./multi-dropdown.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class MultiDropdownComponent
  implements OnInit, AfterViewInit, AfterContentInit, OnDestroy
{
  /**
   * Adds `aria-label` attribute. When using `aria-label`, `label` should be empty string.
   */
  @Input() ariaLabel?: string;
  /**
   * Aria-label for clear button
   */
  @Input() ariaClearLabel?: string = 'Clear All';
  /**
   * Text for clear button
   */
  @Input() clearInputText?: any = 'Clear All';
  /**
   * Additional classes to be added to the root element.
   */
  @Input() className?: string;

  /**
   * Disables the entire field.
   */
  @Input() disabled?: boolean;
  @Input() errorMessage?: any;

  /**
   * Additional classes to be added to the error message
   */
  @Input() errorMessageClassName?: string;

  /**
   * Location of the error message relative to the field input
   */
  @Input() errorPlacement?: DropdownErrorPlacement;

  /**
   * Additional classes to be added to the select element
   */
  @Input() fieldClassName?: string;

  /**
   * Used to focus `select` on `componentDidMount()`
   */
  @Input() focusTrigger?: boolean;

  /**
   * Additional hint text to display
   */
  @Input() hint?: any;

  /**
   * Additional hint text for screen reader only
   */
   @Input() hiddenHint?: string;

  /**
   * A unique ID to be used for the dropdown field. If one isn't provided, a unique ID will be generated.
   */
  @Input() id?: string;

  /**
   * Applies the "inverse" UI theme
   */
  @Input() inversed?: boolean;

  /**
   * Label for the field. If using `Dropdown` without a label, provide an empty string for `label` and use the `ariaLabel` prop instead.
   */
  @Input() label?: any;

  /**
   * Additional classes to be added to the `FormLabel`.
   */
  @Input() labelClassName?: string;

  /**
   * The field's `name` attribute
   */
  @Input() name?: string;

  /**
   * The list of options to be rendered. Provide an empty list if using custom options via the `children` prop.
   */
  @Input() options?: DropdownOptions[];
  @Input() onBlur?: (...args: any[]) => any;
  @Input() onChange?: (...args: any[]) => any;

  /**
   * Text showing the requirement ("Required", "Optional", etc.). See [Required and Optional Fields]({{root}}/guidelines/forms/#required-and-optional-fields).
   */
  @Input() requirementLabel?: any;
  @Input() isRequired?: boolean;

  /**
   * If the component renders a select, set the max-width of the input either to `'small'` or `'medium'`.
   */
  @Input() size?: DropdownSize;

  @Input() fullWidthOptions?: boolean = false;

  /**
   * If want a disabled option to be removeable but not selectable.
   * For this use case, the option will appear if the user has it pre-selected, but once removed
   * it will not be available to be re-selected
   */
  @Input() oneWayRemove?: boolean = false;

  /**
   * Used in conjunction with formGroup to associate angular form
   * @param  {string;} formControlName?
   * @returns string
   */
  @Input() formControlName?: string;
  @Input() parentGroup?: UntypedFormGroup;

  /**
   * ng-select inputs
   */
  @Input() addTag?: boolean;
  @Input() addTagText?: string;
  @Input() appendTo?: string;
  @Input() clearAllText?: string;
  @Input() clearable?: boolean;
  @Input() clearOnBackspace?: boolean;
  @Input() dropdownPosition?: DropdownPosition;
  @Input() groupBy?: string | ((value: any) => any);
  @Input() groupValue?: (key: string | any, children: any[]) => string | any;
  @Input() selectableGroup?: boolean;
  @Input() selectableGroupAsModel?: boolean;
  @Input() loading?: boolean;
  @Input() loadingText?: string;
  @Input() hideAsterisk?: boolean = false;
  @Input() inputAttrs: { [key: string]: string } = {};

  /**
  * Set the aria-describedby of the dropdownInput
  */
  @Input() ariaDescribedBy?: string;


  @ViewChild('formRef') formComponent?: FormControlComponent;
  @ViewChild('selectRef') selectComponent?: NgSelectComponent;
  @ViewChild('selectRef', { read: ElementRef }) selectRef?: ElementRef;
  @ViewChild('clearRef', { read: ElementRef }) clearRef?: ElementRef;
  @ViewChild('clearLink') clearLink?: ElementRef;

  content?: string;
  formControlElem?: HTMLElement;
  selectElem?: HTMLElement;
  containerProps: any[] = [];
  inputOnlyProps: any[] = [];

  selectClasses?: string;
  clearLinkClasses?: string;
  ngSelectClasses?: string;
  ariaRequired?: { [key: string]: string };
  statusSub$?: Subscription;

  constructor(
    @Self() @Optional() public ngControl: NgControl,
    public renderer: Renderer2,
    private cdr: ChangeDetectorRef
  ) {
    if (this.ngControl) {
      // Note: we provide the value accessor through here, instead of
      // the `providers` to avoid running into a circular import.
      // And we use NOOP_VALUE_ACCESSOR so TextField doesn't do anything with NgControl
      this.ngControl.valueAccessor = NOOP_VALUE_ACCESSOR;
    }
  }

  ngOnInit(): void {
    const OmitProps = [
      'size',
      'value',
      'label',
      'className',
      'children',
      'defaultValue',
      'disabled',
      'id',
      'name',
      'onBlur',
      'onChange',
    ];

    if (this.isRequired && !this.hideAsterisk) {
      this.ariaClearLabel += ' * ' + this.label;
    } else {
      this.ariaClearLabel += ' ' + this.label;
    }

    this.errorPlacement = this.errorPlacement || errorPlacementDefault();
    this.updateSelectComponent();

    if (this.ngControl) {
      setTimeout(() => {
        this.checkIfIsRequired();
      });
    }
  }

  ngAfterViewInit(): void {
    if (this.formComponent) {
      setTimeout(() => {
        if (this.selectRef?.nativeElement) {
          this.formComponent?.labelRef?.labelRoot?.nativeElement.after(
            this.selectRef.nativeElement
          );
          this.formComponent?.labelRef?.labelRoot?.nativeElement.after(
            this.clearRef?.nativeElement
          );
          if (
            this.errorPlacement === 'bottom' &&
            this.formComponent?.bottomErrorRef?.nativeElement
          ) {
            this.selectRef.nativeElement.after(
              this.formComponent?.bottomErrorRef?.nativeElement
            );
          }
        }

        let classList: string[] = Array.from(
          this.selectRef?.nativeElement.classList
        )
          ? Array.from(this.selectRef?.nativeElement.classList)
          : [];
        let sanitizedClassList = classList.filter((e) => e !== 'undefined');
        this.selectClasses = classNames(
          sanitizedClassList,
          'dropdown-styles',
          'ds-c-field',
          {
            'ds-c-field--inverse': this.inversed,
          },
          this.size && `ds-c-field--` + this.size,
          {
            'full-width-options': this.fullWidthOptions,
          },
          {
            'one-way-removal': this.oneWayRemove,
          }
        );

        this.clearLinkClasses = classNames(
          'clearLink'
        );
      });
    }

    if (this.ngControl) {
      this.statusSub$ = this.ngControl.statusChanges?.subscribe((status) => {
        setTimeout(() => {
          if (this.selectRef) {
            if (status === 'DISABLED') {
              this.renderer.setAttribute(
                this.selectRef.nativeElement,
                'disabled',
                ''
              );
              if (this.clearLink) {
                this.renderer.setAttribute(this.clearLink.nativeElement, 'display', 'none');
              }
            } else {
              this.renderer.removeAttribute(
                this.selectRef.nativeElement,
                'disabled'
              );
              if (this.clearLink) {
                this.renderer.setAttribute(this.clearLink.nativeElement, 'display', 'inline-block');
              }
            }
          }
        });
      });
    }

    if (this.selectRef) {
      const dropdownInput =
        this.selectRef.nativeElement.querySelector('input');
      const ngSelectContainerDiv = this.selectRef.nativeElement.querySelector('.ng-select-container');

      ngSelectContainerDiv.id = _.uniqueId('ng-select-container_div_');

      dropdownInput.setAttribute('aria-describedby',  this.ariaDescribedBy ?? ngSelectContainerDiv.id);

      if(this.ariaLabel){
        dropdownInput.setAttribute('aria-label', this.ariaLabel);
      }

      if(this.hiddenHint) {
        const hiddenHintSpan = document.createElement('span');
        hiddenHintSpan.textContent = this.hiddenHint;
        hiddenHintSpan.setAttribute('class', 'ds-u-visibility--screen-reader');
        hiddenHintSpan.setAttribute('id', 'anticipatoryText_Corrections');
        ngSelectContainerDiv.appendChild(hiddenHintSpan);
        this.selectRef?.nativeElement.setAttribute('aria-describedby', 'anticipatoryText_Corrections');
      }
    }
  }

  ngAfterContentInit(): void {
    this.cdr.detectChanges();
  }

  ngOnDestroy(): void {
    this.statusSub$?.unsubscribe();
  }

  checkIfIsRequired() {
    if (this.isRequired === undefined && this.ngControl.control?.validator) {
      let validator = this.ngControl.control.validator({} as AbstractControl);
      if (validator && validator['required']) {
        this.isRequired = true;
      } else {
        this.isRequired = false;
      }
    }
  }
  checkAriaRequired() {
    if (this.isRequired === true) {
      this.ariaRequired = { 'aria-required': 'true' };
    } else {
      this.ariaRequired = { 'aria-required': 'false' };
    }
    return this.ariaRequired;
  }

  updateInputAttrs() {
    let attrs = {
      ...(this.ariaRequired ? { 'aria-required': 'true' } : { 'aria-required': 'false' }),
      ...(this.inputAttrs && this.inputAttrs)
    }
    return attrs;
  }

  updateSelectComponent() {
    if (this.selectComponent) {
      if (this.addTag) {
        this.selectComponent.addTag = this.addTag;
      }
      if (this.addTagText) {
        this.selectComponent.addTagText = this.addTagText;
      }
      if (this.appendTo) {
        this.selectComponent.appendTo = this.appendTo;
      }
      if (this.clearAllText) {
        this.selectComponent.clearAllText = this.clearAllText;
      }
      if (this.clearable) {
        this.selectComponent.clearable = this.clearable;
      }
      if (this.clearOnBackspace) {
        this.selectComponent.clearOnBackspace = this.clearOnBackspace;
      }
      if (this.dropdownPosition) {
        this.selectComponent.dropdownPosition = this.dropdownPosition;
      }
      if (this.groupBy) {
        this.selectComponent.groupBy = this.groupBy;
      }
      if (this.groupValue) {
        this.selectComponent.groupValue = this.groupValue;
      }
      if (this.selectableGroup) {
        this.selectComponent.selectableGroup = this.selectableGroup;
      }
      if (this.selectableGroupAsModel) {
        this.selectComponent.selectableGroupAsModel =
          this.selectableGroupAsModel;
      }
      if (this.loading) {
        this.selectComponent.loading = this.loading;
      }
      if (this.loadingText) {
        this.selectComponent.loadingText = this.loadingText;
      }
    }
  }

  handleChange(event: any): void {
    if (!this.disabled && this.onChange) {
      this.onChange(event);
    }
  }

  handleBlur(event: any): void {
    if (!this.disabled && this.ngControl) {
      this.ngControl.control?.markAsTouched();
    }
    if (!this.disabled && this.onBlur) {
      this.onBlur(event);
    }
  }

  isSelected(el: HTMLElement) {
    let parent = el.parentNode as HTMLElement;
    if (!parent.classList.contains('ng-option-selected')) {
      return 'visibility: hidden;';
    } else {
      if (parent.classList.contains('ng-option-marked')) {
        return 'font-size: 10px; color: #ffffff;';
      } else {
        return 'font-size: 10px; color: #0071bc;';
      }
    }
  }

  handleClearClick (event?: any)  {
    if(event !== undefined){
      event?.preventDefault();
    }
    this.selectComponent?.handleClearClick();
  };
}
