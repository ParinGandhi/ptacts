import { Component, OnInit, Input, ElementRef, Renderer2, ComponentRef, ViewContainerRef, Injector, AfterViewInit, ViewChild } from '@angular/core';
import { InlineErrorComponent } from '../inline-error/inline-error.component';
import classNames from 'classnames';

export type FormLabelComponentType = 'label' | 'legend';

@Component({
  selector: 'cms-form-label',
  templateUrl: './form-label.component.html',
  styleUrls: ['./form-label.component.css']
})
export class FormLabelComponent implements OnInit, AfterViewInit {

  /**
   * Additional classes to be added to the root element.
   */
  @Input() className?: string;
  /** The root HTML element used to render the label */
  @Input() component?: FormLabelComponentType;
  /**
   * The ID of the error message applied to the Select field.
   */
  @Input() errorId?: string;
  /** Enable the error state by providing an error message. */
  @Input() errorMessage?: any;
  /**
   * Additional classes to be added to the error message
   */
  @Input() errorMessageClassName?: string;

  /**
   * The ID of the field this label is for. This is used for the label's `for`
   * attribute and any related ARIA attributes, such as for the error message.
   */
  @Input() fieldId?: string;

  /**
   * Additional hint text to display
   */
  @Input() hint?: any;

  /**
   * A unique `id` for the label element. Useful for referencing the label from
   * other components with `aria-describedby`.
   */
  @Input() id?: string;

  /**
   * Applies the "inverse" UI theme
   */
  @Input() inversed?: boolean;

  /**
   * Text showing the requirement ("Required", "Optional", etc.).
   * See [Required and Optional Fields]({{root}}/guidelines/forms/#required-and-optional-fields).
   */
  @Input() requirementLabel?: any;

  /**
   * Additional classes to be added to the label text.
   */
  @Input() textClassName?: string;
  @ViewChild('labelRoot') labelRoot?: ElementRef;

  content?: string;
  classes = '';
  hintClasses = '';
  hintMessage = '';
  hintElem?: HTMLElement;
  errorMessageElem?: HTMLElement;
  inlineRef?: ComponentRef<InlineErrorComponent>;

  constructor(private elementRef: ElementRef, private renderer: Renderer2,
    private vcr: ViewContainerRef, private injector: Injector) { }

  ngOnInit(): void {
    if (!this.component) {
      this.component = 'label';
    }

    this.updateRootElement();
    this.updateHint();
    this.updateErrorMessage();
  }

  ngAfterViewInit(): void {
    // TODO: other label properties

    if (this.labelRoot) {
      const parent = this.renderer.parentNode(this.elementRef.nativeElement);
      this.renderer.insertBefore(parent, this.labelRoot.nativeElement, this.elementRef.nativeElement, true);
      this.renderer.removeChild(parent, this.elementRef.nativeElement, true);
    }
  }

  updateRootElement() {
    const inverseClass = this.inversed && 'ds-c-label--inverse';
    this.classes = classNames('ds-c-label', inverseClass, this.className);
  }

  updateHint() {
    if (!this.hint && !this.requirementLabel) return;

    const inverseClass = this.inversed && 'ds-c-field__hint--inverse';
    this.hintClasses = classNames('ds-c-field__hint', inverseClass);

    let hintPadding;

    if (this.requirementLabel && this.hint) {
      if (typeof this.requirementLabel === 'string') {
        // Remove any existing spacing and punctuation
        this.requirementLabel = this.requirementLabel.trim().replace(/\.$/, '');
        // Add punctuation after the requirementLabel so it doesn't run into the hint
        this.requirementLabel = this.requirementLabel + '.';
      }

      hintPadding = ' ';
    }

    this.hintMessage = '';
    if (this.requirementLabel) {
      this.hintMessage += this.requirementLabel;
      hintPadding ? this.hintMessage += hintPadding : null;
    }
    this.hint ? this.hintMessage += this.hint : null;

    // if hint message contains slashes (i.e. for MM/DD/YYY) then break or add a new line after so that 
    // it's responsive based on window size
    if (this.hintMessage.includes('MM/DD/YYYY')) {
      this.hintMessage = this.hintMessage.replace(/\/(?=[^\s])/g, "/\n");
    }
  }

  updateErrorMessage() {
    if (!this.errorId && this.fieldId) {
      this.errorId = this.fieldId + '-error';
    }
  }
}
