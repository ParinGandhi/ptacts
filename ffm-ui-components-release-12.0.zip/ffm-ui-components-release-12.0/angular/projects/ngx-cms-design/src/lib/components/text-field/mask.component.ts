import { TextInputComponent } from './text-input.component';
import { Component, Input, OnChanges, OnInit, SimpleChanges, ChangeDetectorRef, ViewChild, ElementRef, Renderer2, AfterViewInit, ViewContainerRef, Injector } from '@angular/core';
import * as _ from "lodash";
import { maskValue, unmaskValue } from './maskHelpers';

// TODO: Remove `maskValue` and `unmaskValue` exports with next major release (v3.x.x)
export { maskValue, unmaskValue };

const maskPattern = {
  phone: '[0-9-]*',
  ssn: '[0-9-*]*',
  zip: '[0-9-]*',
  currency: '[0-9.,-]*',
};

const maskOverlayContent = {
  currency: '$',
};

export type MaskMask = 'currency' | 'phone' | 'ssn' | 'zip';

@Component({
  selector: 'cms-mask',
  template: '<div #container></div>',
  styleUrls: ['./mask.component.css']
})
export class MaskComponent implements OnInit, OnChanges, AfterViewInit {

  @Input() mask?: MaskMask;
  @Input() fieldElem?: HTMLElement;
  @Input() field?: ElementRef<TextInputComponent>;

  @ViewChild('container', {read: ElementRef}) container?: ElementRef;
  // @ContentChild(TextInputComponent) field?: TextInputComponent;


  debouncedOnBlurEvent: any;
  state: any;

  constructor(changeDetector: ChangeDetectorRef, private elementRef: ElementRef,
    private renderer: Renderer2, private vcr: ViewContainerRef, private injector: Injector) {
    const initialValue = this.field?.nativeElement.value || this.field?.nativeElement.defaultValue
    this.state = {
      value: maskValue(initialValue as string, this.mask)
    }
  }

  ngOnInit(): void {
      // This is intentional
  }

  ngAfterViewInit(): void {
    if(this.container) {
      this.renderer.setAttribute(this.container.nativeElement, 'class', 'ds-c-field-mask ds-c-field-mask--' + this.mask);
    }

    if(maskOverlayContent[this.mask as keyof typeof maskOverlayContent]) {
      console.log('maskOverlayContent matches');
      const maskOverlay = this.renderer.createElement('div');
      this.renderer.setAttribute(maskOverlay, 'class', 'ds-c-field__before ds-c-field__before--' + this.mask);
      const maskText = this.renderer.createText(maskOverlayContent[this.mask as keyof typeof maskOverlayContent]);
      this.renderer.appendChild(maskOverlay, maskText);
      this.renderer.appendChild(this.container?.nativeElement, maskOverlay);
    }

    if(this.fieldElem) {
      const fieldElem = this.fieldElem;
      const field = this.field;
      const modifiedField = _.cloneDeep(fieldElem);

      this.renderer.setProperty(modifiedField, 'defaultValue', undefined);
      this.renderer.setProperty(modifiedField, 'value', this.state.value);
      this.renderer.setProperty(modifiedField, 'type', 'text');
      this.renderer.setProperty(modifiedField, 'inputMode', 'numeric');
      this.renderer.setProperty(modifiedField, 'pattern', maskPattern[this.mask as keyof typeof maskPattern]);

      this.renderer.listen(modifiedField, 'change', (evt) => this.handleChange(evt, field!));
      this.renderer.listen(modifiedField, 'blur', (evt) => this.handleBlur(evt, field!));
      this.renderer.appendChild(this.container?.nativeElement, modifiedField);
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
      console.log('onChanges: ', changes);
      if(this.debouncedOnBlurEvent && this.field && this.field.nativeElement.onBlur) {
        this.field?.nativeElement.onBlur(this.debouncedOnBlurEvent);
        this.debouncedOnBlurEvent = null;
      }

      const isControlled = this.field?.nativeElement.value !== undefined;
      if(this.field && isControlled && changes['value'].currentValue !== changes['value'].previousValue) {
        const { mask } = this.elementRef.nativeElement;
        // For controlled components, the value prop should ideally be changed by
        // the controlling component once we've called onChange with our updates.
        // If the change was triggered this way through user input, then the prop
        // given should match our internal state when unmasked. If what we're
        // given and what we have locally don't match, that means the controlling
        // component has made its own unrelated change, so we should update our
        // state and mask this new value.

        if(unmaskValue(this.field.nativeElement.value as string, mask) !== unmaskValue(this.state.value, mask)) {
          const value = maskValue(this.field.nativeElement.value as string || '', mask);
          this.state  = { value };
        }
      }

  }

  /**
   * To avoid a jarring experience for screen readers, we only
   * add/remove characters after the field has been blurred,
   * rather than when the user is typing in the field
   * @param {Object} evt
   * @param {React.Element} field - Child TextField
   */
  handleBlur(evt: Event, field: ElementRef<TextInputComponent>): void {
    console.log('handleBlur in Mask: ', evt);
    if( !(evt.target instanceof HTMLInputElement)) return;

    const value = maskValue(evt.target.value, this.mask);

    // We only debounce the onBlur when we know for sure that
    // this component will re-render (AKA when the value changes)
    // and when an onBlur callback is present
    const debounce = value !== this.state.value && typeof field.nativeElement.onBlur === 'function';

    if (debounce) {
      // We need to retain a reference to the event after the callback
      // has been called. We pass this onto the consuming app's onBlur
      // only after the value has been manipulated – this way, the
      // value returned by event.target.value is the value after masking

      this.debouncedOnBlurEvent = evt;
    }

    this.state = { value };

    if (!debounce && typeof field.nativeElement.onBlur === 'function') {
      // If we didn't debounce the onBlur event, then we need to
      // call the onBlur callback from here
      field.nativeElement.onBlur(evt);
    }
  }

  /**
   * @param {Object} evt
   * @param {React.Element} field - Child TextField
   */
  handleChange(evt: Event, field: ElementRef<TextInputComponent>): void {
    console.log('handleChange in Mask: ', evt);
    this.state = ({ value: field.nativeElement.value});

    if (typeof field.nativeElement.onChange === 'function') {
      field.nativeElement.onChange(evt);
    }
  }
}
