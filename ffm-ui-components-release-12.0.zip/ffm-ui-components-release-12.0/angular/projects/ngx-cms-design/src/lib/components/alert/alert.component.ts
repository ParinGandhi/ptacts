import { Component, ElementRef, Input, OnInit, ViewChild, AfterViewInit, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import classNames from 'classnames';
import * as _ from "lodash";

export type AlertHeadingLevel = '1' | '2' | '3' | '4' | '5' | '6';
export type AlertRole = 'alert' | 'alertdialog' | 'region' | 'status';
export type AlertVariation = 'error' | 'warn' | 'success';
export type AlertWeight = 'lightweight';

export interface AlertProps {
  /**
   * Sets the focus on Alert during the first mount
   */
  autoFocus?: boolean;

  /**
   * Selector for element to move focus back to when alert is closed
   */
  focusId?: string;

  /**
   * Text that shows in the body of the alert
   */
  body?: string;

  /**
   * Determines whether Alert has a close button
   */
  canClose?: boolean;

  delay?: number;

  className?: string;
  /**
   * Text for the alert heading
   */
  heading?: string;
  /**
   * Optional id used to link the `aria-labelledby` attribute to the heading. If not provided, a unique id will be automatically generated and used.
   */
  headingId: string;
  /**
   * Heading type to override default `<h2>`.
   */
  headingLevel?: AlertHeadingLevel;
  /**
   * Boolean to hide the `Alert` icon
   */
  hideIcon?: boolean;
  /**
   * ARIA `role`, defaults to 'region'
   */
  role?: AlertRole;
  /**
   * A string corresponding to the `Alert` weight classes (`lightweight`)
   */
  weight?: AlertWeight;
  /**
   * A string corresponding to the `Alert` variation classes (`error`, `warn`, `success`)
   */
  variation?: AlertVariation;

  [key: string]: any;
}

@Component({
  selector: 'cms-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AlertComponent implements OnInit, AfterViewInit {

  @Input() className?: string;
  @Input('autoFocus') autoFocus?: boolean;
  @Input() heading?: string;
  @Input() headingId?: string;
  @Input() headingLevel?: AlertHeadingLevel = '2';

  // 2 options for setting the body of the alert
  // - inject HTML using ng-content
  // - use the body input (will override the first option). Best used with Alerts component
  @Input() body?: string;

  @Input('hideIcon') hideIcon?: boolean;
  @Input() role?: AlertRole = 'alert';
  @Input() weight?: AlertWeight;
  @Input() variation?: AlertVariation;
  @Input() canClose?: boolean = false;
  @Input() focusId?: string;
  @Input() delay?: number = 60000;
  @Output() closeEmitter = new EventEmitter<string>();
  @ViewChild('alertheader') alertHeader?: ElementRef;
  @ViewChild('firstdiv') firstDiv?: ElementRef;

  private timeOutID: any;

  private a11yLabel = {
    error: 'Alert',
    warn: 'Warning',
    success: 'Success',
  };
  public classes?: string;
  public readerMessage?: string;

  constructor(private host: ElementRef<HTMLElement>) {
    this.headingId = this.headingId || _.uniqueId('alert_');
  }

  ngOnInit(): void {
    this.classes = classNames('ds-c-alert',
      this.hideIcon && 'ds-c-alert--hide-icon',
      this.variation && 'ds-c-alert--' + this.variation,
      this.weight && 'ds-c-weight--' + this.weight,
      this.className
    );
    this.readerMessage = this.variation ? this.a11yLabel[this.variation] : 'Notice' + ' ';

    if (this.variation === "success" && this.canClose) {
      this.timeOutID = setTimeout(() => {
        this.doClose();
      }, this.delay);
    }
  }

  ngAfterViewInit(): void {
    if (this.autoFocus) {
      this.firstDiv?.nativeElement.focus();
    }
  }

  /**
   * Handle close button by emitting closeEmitter to support custom behavior if specified, and perform
   * default action of removing this current element
   * @param evt event
   */
  handleClose = (evt: any): void => {
    clearTimeout(this.timeOutID);
    this.doClose();
  }

  private doClose(): void {
    this.closeEmitter.emit(this.headingId);
    this.host.nativeElement.remove();
    if (this.focusId) {
      let focusEl = document.querySelector<HTMLInputElement>(this.focusId);
      setTimeout(()=>{ focusEl?.focus() });
    }
  };
}
