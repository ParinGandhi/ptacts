import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import classNames from 'classnames';

@Component({
  selector: 'cms-download-icon',
  template: `<cms-svg-icon [className]="iconCssClasses" [ariaHidden]="ariaHidden"
                [description]="description"
                [id]="id"
                [inversed]="inversed"
                [title]="title"
                [viewBox]="viewBox">
              <svg width="20px" height="20px" viewBox="0 0 11.4916667 19" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <title>Component / Icon / DownloadIcon</title>
                  <g id="Components-&gt;-Button" stroke="none" stroke-width="1" fill-rule="evenodd">
                      <g id="Component/Button/On-light/Outline/Main/Icon-Dropdown-with-Download-Icon" transform="translate(-25.312500, -13.500000)">
                          <g id="content" transform="translate(24.000000, 0.500000)">
                              <g id="Component-/-Icon-/-DownloadIcon" transform="translate(1.312500, 13.000000)">
                                  <path d="M1.16666667,12.8748958 L1.16666667,11.6666667 L10.5,11.6666667 L10.5,14 L1.16666667,14 L1.16666667,12.8748958 Z M0,3.8915625 L0.794791667,3.09677083 L1.588125,2.33333333 L3.10770833,3.82302083 L4.66666667,5.25 L4.66666667,0 L7,0 L7,5.25 L8.37958333,3.81135417 C9.205,2.9859375 9.90864583,2.33333333 9.91666667,2.33333333 C9.9246875,2.33333333 10.2666667,2.6665625 10.70125,3.10114583 L11.4916667,3.8915625 L8.62604167,6.7571875 C7.67097917,7.71713542 6.71089271,8.672125 5.74583333,9.62208333 C5.7378125,9.62208333 4.440625,8.33291667 2.865625,6.75645833 L0,3.89083333 L0,3.8915625 Z" id="Icon"></path>
                              </g>
                          </g>
                      </g>
                  </g>
              </svg>
            </cms-svg-icon>
`,
  styles: [],
  encapsulation: ViewEncapsulation.None,
})
export class DownloadIconComponent implements OnInit {

  @Input() ariaHidden?: boolean;
  @Input() className?: string;
  @Input() description?: string;
  @Input() id?: string;
  @Input() inversed?: boolean;
  @Input() title?: string = 'Download';
  @Input() viewBox?: string = '4 0 11.4916667 19';

  iconCssClasses?: string;

  constructor() {
      // This is intentional
  }

  ngOnInit(): void {
    this.iconCssClasses = classNames('ds-c-icon--download', this.className);
  }
}
