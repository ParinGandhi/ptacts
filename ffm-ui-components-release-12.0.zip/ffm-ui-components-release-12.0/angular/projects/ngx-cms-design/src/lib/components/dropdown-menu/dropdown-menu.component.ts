import {
  Component,
  OnInit,
  ViewEncapsulation,
  AfterViewInit,
  Input,
  ViewChild,
  ElementRef,
  Renderer2,
  SimpleChanges,
  OnChanges
} from '@angular/core';
import { DropdownPosition, NgSelectComponent } from '@ng-select/ng-select';
import classNames from 'classnames';
import { DropdownSize } from '../dropdown/dropdown.component';

export type DropdownMenuOptionType = 'action' | 'route';
export interface DropdownMenuOptions {
  label: any;
  value: number | string;
  type: DropdownMenuOptionType;
  disabled?: boolean;
}

@Component({
  selector: 'cms-dropdown-menu',
  templateUrl: './dropdown-menu.component.html',
  styleUrls: ['./dropdown-menu.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class DropdownMenuComponent implements OnInit, AfterViewInit, OnChanges {
  /**
   * Adds `aria-label` attribute. When using `aria-label`, `label` should be empty string.
   */
  @Input() ariaLabel?: string;
  /**
   * additional classes for select
   */
  @Input() className?: string;

  /**
   * classes to be used on icon div
   */
  @Input() iconClassName?: string;

  /**
   * Disables the entire field.
   */
  @Input() disabled?: boolean;
  /**
   * A unique ID to be used for the dropdown field. If one isn't provided, a unique ID will be generated.
   */
  @Input() id?: string;

  /**
   * Applies the "inverse" UI theme
   */
  @Input() inversed?: boolean;

  /**
   * Label for the field. If using `Dropdown` without a label, provide an empty string for `label` and use the `ariaLabel` prop instead.
   */
  @Input() label?: any;

  /**
   * Adjusts the dropdown so that it is within the view, enable when the menu is used on the right edge of the view.
   */
  @Input() rightSide?: boolean = true;

  /**
   * The list of options to be rendered. Provide an empty list if using custom options via the `children` prop.
   */
  @Input() options?: DropdownMenuOptions[];
  @Input() onBlur?: (...args: any[]) => any;
  @Input() onChange?: (...args: any[]) => any;

  /**
   * If the component renders a select, set the max-width of the input either to `'small'` or `'medium'`.
   */
  @Input() size?: DropdownSize;
  @Input() dropdownPosition?: DropdownPosition = 'bottom';

  /**
   * Must be set to true when adding a left icon to drop down.  Icon to be shown must be component content.
   */
  @Input() hasIcon?: boolean = false;

  @ViewChild('selectRef') selectComponent?: NgSelectComponent;
  @ViewChild('selectRef', { read: ElementRef }) selectRef?: ElementRef;
  @ViewChild('widthTarget', { read: ElementRef }) widthTarget?: ElementRef;

  selectClasses?: string;
  iconClasses?: string;
  calculatedWidth?: string;
  private functionBindListener: any;

  constructor(private elementRef: ElementRef, private renderer: Renderer2) {}

  ngOnInit(): void {
    this.updateSelectComponent();
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      if (this.selectRef) {
        this.updateStyles();
        if (this.hasIcon) {
          this.iconClasses = classNames('left-icon', 'ds-u-margin-left--3', 'ds-u-valign--middle', this.iconClassName);
        }
        if (!this.size) {
          if (this.hasIcon) {
            this.selectClasses += " ds-u-margin-left--1 ds-u-margin-right--3"
          } else {
            this.selectClasses += " ds-u-margin-left--3 ds-u-margin-right--3"
          }
        }

        if (this.ariaLabel) {
          const dropdownInput =
            this.selectRef.nativeElement.querySelector('input');
          dropdownInput.setAttribute('aria-label', this.ariaLabel);
        }

        const labelDiv = this.selectRef.nativeElement.querySelector('.ng-placeholder') as HTMLElement;
        labelDiv.classList.add('ds-u-margin-left--1');
      }
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['rightSide']) {
      this.updateStyles();
    }
  }

  // Moving options to the left side of the dropdown
  adjustRightSideMargin() {
    const panelElem = document.querySelector('.ng-dropdown-panel');
    // Setting the panel options to line up with the right side of the dropdown button
    if (panelElem && panelElem.parentElement) {
      this.renderer.setStyle(panelElem, 'left', 'auto');
      this.renderer.setStyle(panelElem, 'right', '0');
    } 
  }

  updateDropdownStyle() { 
    let dropdowns = document.getElementsByClassName('ng-dropdown-panel-items scroll-host');
    Array.from(dropdowns).forEach(drop => {
      // Currrent menu dropdown element
        let dropdownContainer = drop.parentElement;
        // Wrap contents if they overflow 80% of view screen
        if (dropdownContainer) {
          (dropdownContainer as HTMLElement).style.width = 'max-content';

          // Getting the dropdown button
          let dropdownButton = dropdownContainer.parentElement;

          if (dropdownButton) {
            // Determining the length of the offset between the side of the screen and the dropdown depending if it is sitting on the right side/left side of page
            let screenWidth = (!this.rightSide) ? dropdownButton.getBoundingClientRect().right : (document.documentElement.clientWidth - dropdownButton.getBoundingClientRect().left);

            if (((drop as HTMLElement).offsetWidth) > (screenWidth * .89)) {
              let dropdownOptions = (drop as HTMLElement).getElementsByClassName('ng-option');
              Array.from(dropdownOptions).forEach(option => {
                (option as HTMLElement).style.whiteSpace = 'normal';         
              });
              // Setting the dropdown container to 80 viewport
              dropdownContainer.style.width = (screenWidth * .89) + "px";
            } else {
              dropdownContainer.style.width = 'max-content';
              // Don't wrap contents since they are long enough
              let dropdownOptions = (drop as HTMLElement).getElementsByClassName('ng-option');
              Array.from(dropdownOptions).forEach(option => {
                (option as HTMLElement).style.whiteSpace = 'nowrap';
              });    
            }
          }
        }
    });
  }

  updateStyles() {
    if (this.selectRef) {
      let classList: string[] = Array.from(
        this.selectRef?.nativeElement.classList
      )
        ? Array.from(this.selectRef?.nativeElement.classList)
        : [];
      let sanitizedClassList = classList.filter((e) => e !== 'undefined');
      let addedClasses = [
        'dropdown-menu-styles',
        'right-side-menu',
        'ds-c-field',
        'ds-c-field--inverse',
        'has-left-icon',
        'ds-c-field--small',
        'ds-c-field--medium',
      ];
      sanitizedClassList = sanitizedClassList.filter(
        (item) => addedClasses.indexOf(item) < 0
      );
      this.selectClasses = classNames(
        sanitizedClassList,
        'dropdown-menu-styles',
        {
          'right-side-menu': this.rightSide,
        },
        'ds-c-field',
        {
          'ds-c-field--inverse': this.inversed,
        },
        this.size && `ds-c-field--` + this.size,
        {
          'has-left-icon': this.hasIcon,
        },
        this.className
      );
    }
  }

  updateSelectComponent() {
    if (this.selectComponent) {
      if (this.dropdownPosition) {
        this.selectComponent.dropdownPosition = this.dropdownPosition;
      }
    }
  }

  handleChange(event: any): void {
    if (event && !this.disabled && this.onChange) {
      this.onChange(event);
    }

    this.selectComponent?.handleClearClick();
  }

  handleBlur(event: any): void {
    if (!this.disabled && this.onBlur) {
      this.onBlur(event);
    }
  }

  adjustDropdown() {
    setTimeout(() => {
      // Function to bind to the event listener
      this.functionBindListener = this.updateDropdownStyle.bind(this);
      // Adding event listener to handle resize
      window.addEventListener('resize', this.functionBindListener, false);

      // Moves the options to the left side of the dropdown
      if (!this.rightSide) {
        this.adjustRightSideMargin();
      }
      this.updateDropdownStyle();
    });
  }

  destroyCurrentEventListener(): void {
    // Removing the dropdown event listener when closing the modal
    window.removeEventListener('resize', this.functionBindListener);
  }
}
