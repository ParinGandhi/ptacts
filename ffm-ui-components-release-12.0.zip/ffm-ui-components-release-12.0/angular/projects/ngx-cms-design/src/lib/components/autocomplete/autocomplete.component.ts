import { ButtonComponent } from './../button/button.component';
import {
  TextFieldComponent,
  TextFieldDefaultValue,
  TextFieldErrorPlacement,
  TextFieldSize,
  TextFieldValue,
} from './../text-field/text-field.component';
import { NOOP_VALUE_ACCESSOR } from './../text-field/text-input.component';
import { NgControl, UntypedFormGroup } from '@angular/forms';
import {
  ConnectionPositionPair,
  Overlay,
  OverlayRef,
} from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import {
  Component,
  ElementRef,
  OnInit,
  ViewChild,
  TemplateRef,
  Self,
  Optional,
  ViewContainerRef,
  Input,
  AfterViewInit,
  Renderer2,
  ViewChildren,
  QueryList,
  ChangeDetectorRef,
  OnDestroy,
  ViewEncapsulation,
} from '@angular/core';
import { uniqueId } from 'lodash';
import { fromEvent, Subscription } from 'rxjs';
import { takeUntil, filter } from 'rxjs/operators';
import classNames from 'classnames';
import { errorPlacementDefault } from '../flags';

export interface AutocompleteItems {
  /**
   * Unique identifier for this item
   */
  id?: string;
  /**
   * Displayed value of the item. May alternatively provide a `children` value
   */
  name?: string;
  /**
   * Custom React node as an alternative to a string-only `name`
   */
  children?: any;
  /**
   * Additional classes to be added to the root element.
   * Useful for adding utility classes.
   */
  className?: string;
  /**
   * Whether this item should be counted as one of the results for the purpose of announcing the
   * result count to screen readers
   */
  isResult?: boolean;
}

type PropsNotPassedToDownshift =
  | 'ariaClearLabel'
  | 'clearInputText'
  | 'items'
  | 'label'
  | 'loading'
  | 'children'
  | 'className'
  | 'clearInputOnBlur'
  | 'clearSearchButton';

export interface AutocompleteProps {
  /**
   * Screenreader-specific label for the Clear search `<button>`. Intended to provide a longer, more descriptive explanation of the button's behavior.
   */
  ariaClearLabel?: string;
  /**
   * Control the `TextField` autocomplete attribute. Defaults to "off" to support accessibility. [Read more.](https://developer.mozilla.org/en-US/docs/Web/Security/Securing_your_site/Turning_off_form_autocompletion)
   */
  autoCompleteLabel?: string;
  /**
   * Must contain a `TextField` component
   */
  children: any;
  /**
   * Additional classes to be added to the root element.
   * Useful for adding utility classes.
   */
  className?: string;
  /**
   * When set to `false`, do not clear the input when the input element loses focus.
   */
  clearInputOnBlur?: boolean;
  /**
   * Text rendered on the page if `clearInput` prop is passed. Default is "Clear search".
   */
  clearInputText?: any;
  /**
   * Removes the Clear search button when set to `false`
   */
  clearSearchButton?: boolean;
  /**
   * Used to focus child `TextField` on `componentDidMount()`
   */
  focusTrigger?: boolean;
  /**
   * A unique id to be passed to the child `TextField`. If no id is passed as a prop,
   * the `Autocomplete` component will auto-generate one. This prop was provided in cases
   * where an id might need to be passed to multiple components, such as the `htmlFor`
   * attribute on a label and the id of an input.
   */
  id?: string;
  /**
   * Access a reference to the child `TextField`'s `input` element
   */
  inputRef?: (...args: any[]) => any;
  /**
   * Array of objects used to populate the suggestion list that appears below the input as users type. This array of objects is intended for an async data callback, and should conform to the prescribed shape to avoid errors.
   */
  items?: AutocompleteItems[];
  /**
   * Adds a heading to the top of the autocomplete list. This can be used to convey to the user that they're required to select an option from the autocomplete list.
   */
  label?: any;
  /**
   * A unique `id` to be used on the child `TextField` label tag
   */
  labelId?: string;
  /**
   * Can be called when the `items` array is being fetched remotely, or will be delayed for more than 1-2 seconds.
   */
  loading?: boolean;
  /**
   * Message users will see when the `loading` prop is passed to `Autocomplete`.
   */
  loadingMessage?: any;
  /**
   * Message users will see when the `items` array returns empty and the `loading` prop is passed to `<Autocomplete />`.
   */
  noResultsMessage?: any;
  /**
   * Called when the user selects an item and the selected item has changed. Called with the item that was selected and the new state. [Read more on downshift docs.](https://github.com/paypal/downshift#onchange)
   */
  onChange?: (...args: any[]) => any;
}

@Component({
  selector: 'cms-autocomplete',
  templateUrl: './autocomplete.component.html',
  styleUrls: ['./autocomplete.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AutocompleteComponent implements OnInit, AfterViewInit, OnDestroy {
  @Input() ariaClearLabel?: string = 'Clear search to try again';
  @Input() autoCompleteLabel?: string = 'none';
  @Input() className?: string;
  @Input() clearInputBlur?: boolean = true;
  @Input() clearInputText?: any = 'Clear search';
  @Input() clearSearchButton?: boolean = true;
  @Input() focusTrigger?: boolean;
  @Input() id?: string;
  @Input() itemToString: (...args: any[]) => string = (
    item: AutocompleteItems
  ) => (item ? item.name! : '');
  @Input() items?: AutocompleteItems[];
  @Input() label?: any;
  @Input() labelId?: string;
  @Input() loading?: boolean;
  @Input() loadingMessage?: any = 'Loading...';
  @Input() noResultsMessage?: any = 'No results';

  // TextField inputs
  @Input() inputLabel?: any;
  @Input() inputClassName?: string;
  @Input() hint?: any;
  @Input() name: string = '';
  @Input() numeric?: boolean;
  @Input() requirementLabel?: any;
  @Input() defaultValue?: TextFieldDefaultValue;
  @Input() disabled?: boolean;
  @Input() errorMessage?: any;
  @Input() errorMessageClassName?: string;
  @Input() errorPlacement?: TextFieldErrorPlacement;
  @Input() pattern?: string;
  @Input() size?: TextFieldSize;
  @Input() type?: string = 'text';
  @Input() value?: TextFieldValue;
  @Input() placeholder?: string;
  @Input() onBlur?: (...args: any[]) => any;
  @Input() onChange?: (...args: any[]) => any;
  @Input() onFocus?: (...args: any[]) => any;
  @Input() formControlName?: string | number | null;
  @Input() parentGroup?: UntypedFormGroup;

  @ViewChild('root') rootTemplate?: TemplateRef<any>;
  @ViewChild('autoTextComp') textComp?: TextFieldComponent;
  @ViewChild('autoTextComp', { read: ElementRef }) inputRef?: ElementRef;
  @ViewChildren('item') itemsRef?: QueryList<ElementRef>;
  @ViewChild('clearButton') clearButton?: ButtonComponent;

  private overlayRef?: OverlayRef | null;
  filterString = '';
  listboxId?: string;
  listboxContainerId?: string;
  listboxHeadingId?: string;
  highlightedIndex: number = -1;
  isOpen = false;
  rootClasses = '';
  clearButtonClasses = '';
  statusSub$?: Subscription;

  constructor(
    private overlay: Overlay,
    private elementRef: ElementRef<HTMLInputElement>,
    private vcr: ViewContainerRef,
    private renderer: Renderer2,
    @Self() @Optional() public ngControl: NgControl,
    public changeRef: ChangeDetectorRef
  ) {
    if (this.ngControl) {
      this.ngControl.valueAccessor = NOOP_VALUE_ACCESSOR;
    }
  }

  ngOnInit(): void {
    this.id = this.id || uniqueId('autocomplete_');
    this.labelId = this.labelId || uniqueId('autocomplete_label_');
    this.listboxId = uniqueId('autocomplete_owned_listbox_');
    this.listboxContainerId = uniqueId('autocomplete_owned_container_');
    this.listboxHeadingId = uniqueId('autocomplete_header_');

    this.rootClasses = classNames(
      'ds-u-clearfix',
      'ds-c-autocomplete',
      this.className
    );

    this.clearButtonClasses = classNames(
      'ds-c-label',
      'autocomplete-clear-button-container',
      this.size === 'medium' && 'ds-c-label--medium',
      this.size === 'small' && 'ds-c-label--small'
    );
  }

  ngAfterViewInit(): void {
    if (this.textComp?.inputElemRef) {
      this.renderer.listen(
        this.textComp.inputElemRef.nativeElement,
        'keydown',
        this.handleInputKey
      );
    }

    setTimeout(() => {
      this.updateFieldBasedOnControl();
    });

    if (this.ngControl) {
      this.statusSub$ = this.ngControl.statusChanges?.subscribe((status) => {
        setTimeout(() => {
          if (this.textComp?.inputComponent?.inputRoot?.nativeElement) {
            if (status === 'DISABLED') {
              this.renderer.setAttribute(
                this.textComp.inputComponent?.inputRoot?.nativeElement,
                'disabled',
                ''
              );
              if (this.clearButton) {
                this.clearButton.disabled = true;
              }
            } else {
              this.renderer.removeAttribute(
                this.textComp.inputComponent?.inputRoot?.nativeElement,
                'disabled'
              );
              if (this.clearButton) {
                this.clearButton.disabled = false;
              }
            }
          }
        });
      });
    }
  }

  ngOnDestroy(): void {
      this.statusSub$?.unsubscribe();
  }

  updateFieldBasedOnControl() {
    if (this.ngControl) {
      this.filterString = this.ngControl.control?.value;
      if (this.textComp?.inputComponent) {
        this.textComp.inputComponent.value = this.ngControl.control?.value;
      }
      if (this.textComp?.inputElemRef) {
        this.textComp.inputElemRef.nativeElement.value =
          this.ngControl.control?.value;
      }
      this.changeRef.detectChanges();
    }
  }

  /**
   * Input methods
   */
  getErrorMessageClassName() {
    const bottomError =
      (this.errorPlacement === 'bottom' ||
        errorPlacementDefault() === 'bottom') &&
      this.errorMessage;
    return bottomError
      ? classNames(
          'ds-c-autocomplete__error-message',
          {
            'ds-c-autocomplete__error-message--clear-btn':
              this.clearSearchButton,
          },
          this.errorMessageClassName
        )
      : this.errorMessageClassName;
  }

  handleChange = (evt: any) => {
    this.filterString = evt.target.value;
    if (this.ngControl) {
      this.ngControl.control?.markAsDirty();
    }
    if (this.onChange) {
      this.onChange(evt);
    }
  };

  handleBlur = (evt: any) => {
    if (this.onBlur) {
      this.onBlur(evt);
    }
  };

  handleFocus = (evt: any) => {
    if (!this.isOpen) {
      this.openDropdown();
    }
    if (this.onFocus) {
      this.onFocus(evt);
    }
  };

  handleInputKey = (evt: any) => {
    if (evt.key === 'ArrowDown') {
      evt.stopPropagation();
      evt.preventDefault();
      if (this.itemsRef?.length) {
        this.itemsRef.first.nativeElement.focus();
      }
    }
  };

  /**
   * Item methods
   */
  itemClick(item: AutocompleteItems, evt: any) {
    if (this.textComp?.inputComponent) {
      this.textComp.inputComponent.value = this.itemToString(item);
    }
    if (this.textComp?.inputElemRef) {
      this.textComp.inputElemRef.nativeElement.value = this.itemToString(item);
    }

    if (this.ngControl) {
      this.ngControl.control?.setValue(item.name);
      this.ngControl.control?.markAsDirty();
    }

    this.close();

    if (this.onBlur) {
      this.onBlur(evt);
    }
  }

  itemClass(item: AutocompleteItems, index: number) {
    return classNames(item.className, 'ds-c-autocomplete__list-item', {
      'ds-c-autocomplete__list-item--active': this.highlightedIndex === index,
    });
  }

  itemKey(item: AutocompleteItems, evt: any, index: number) {
    evt.stopPropagation();
    evt.preventDefault();

    if (this.itemsRef) {
      if (evt.key === 'ArrowUp') {
        let elem = evt.target.previousElementSibling as HTMLElement;
        if (elem) {
          elem.focus();
        }
      } else if (evt.key === 'ArrowDown') {
        let elem = evt.target.nextElementSibling as HTMLElement;
        if (elem) {
          elem.focus();
        }
      } else if (evt.key === 'Enter') {
        this.itemClick(item, evt);
      } else if (evt.key === 'Escape') {
        this.close();
      }
    }
  }

  /**
   * Overlay methods
   */
  openDropdown() {
    this.isOpen = true;
    if (this.rootTemplate) {
      this.overlayRef = this.overlay.create({
        width: this.origin.offsetWidth,
        maxHeight: 40 * 3,
        backdropClass: '',
        scrollStrategy: this.overlay.scrollStrategies.reposition(),
        positionStrategy: this.getOverlayPosition(),
      });

      const template = new TemplatePortal(this.rootTemplate, this.vcr);
      this.overlayRef.attach(template);
      overlayClickOutside(this.overlayRef, this.origin).subscribe(() => {
        this.close();

        setTimeout(() => {
          this.updateFieldBasedOnControl();

          if (this.onBlur) {
            this.onBlur();
          }
        });
      });
      this.overlayRef.detachments().subscribe(() => this.close());
    }
  }

  close() {
    this.overlayRef?.detach();
    this.overlayRef = null;
    this.isOpen = false;
  }

  /**
   * Clear button methods
   */
  clearSelection = (evt: any) => {
    this.filterString = '';
    if (this.textComp?.inputComponent) {
      this.textComp.inputComponent.value = '';
    }
    if (this.textComp?.inputElemRef) {
      this.textComp.inputElemRef.nativeElement.value = '';
    }

    if (this.ngControl) {
      this.ngControl.control?.setValue('');
      this.ngControl.control?.markAsDirty();
    }

    if (this.onChange) {
      this.onChange(evt);
    }

    if (this.onBlur) {
      this.onBlur(evt);
    }
  };

  get origin() {
    return this.textComp?.inputComponent?.inputRoot?.nativeElement;
  }

  private getOverlayPosition() {
    const positions = [
      new ConnectionPositionPair(
        { originX: 'start', originY: 'bottom' },
        { overlayX: 'start', overlayY: 'top' }
      ),
      new ConnectionPositionPair(
        { originX: 'start', originY: 'top' },
        { overlayX: 'start', overlayY: 'bottom' }
      ),
    ];

    return this.overlay
      .position()
      .flexibleConnectedTo(this.origin)
      .withPositions(positions)
      .withFlexibleDimensions(false)
      .withPush(false);
  }
}

export function overlayClickOutside(
  overlayRef: OverlayRef,
  origin: HTMLElement
) {
  return fromEvent<MouseEvent>(document, 'click').pipe(
    filter((event: Event) => {
      const clickTarget = event.target as HTMLElement;
      const notOrigin = clickTarget !== origin;
      const notOverlay =
        !!overlayRef &&
        overlayRef.overlayElement.contains(clickTarget) === false;
      return notOrigin && notOverlay;
    }),
    takeUntil(overlayRef.detachments())
  );
}
