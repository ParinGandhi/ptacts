import { UntypedFormGroup } from '@angular/forms';
import {
  ChoiceComponent,
  ChoiceProps as ChoiceComponentProps,
} from './choice.component';
import {
  FormControlPropKeys,
  FormControlComponent,
} from './../form-control/form-control.component';
import {
  Component,
  Input,
  OnInit,
  ElementRef,
  Renderer2,
  ViewContainerRef,
  Injector,
  AfterViewInit,
  ViewChild,
  OnChanges,
  SimpleChanges,
  ComponentRef,
  ChangeDetectorRef,
  AfterContentInit,
} from '@angular/core';
import classNames from 'classnames';
import * as _ from 'lodash';

export type ChoiceListSize = 'small';
export type ChoiceListType = 'checkbox' | 'radio';
export type ChoiceListErrorPlacement = 'top' | 'bottom';

type OmitChoiceProps =
  | 'inversed'
  | 'name'
  | 'onBlur'
  | 'onChange'
  | 'size'
  | 'type'
  | 'inputRef';
type ChoiceProps = Omit<ChoiceComponentProps, OmitChoiceProps>;

@Component({
  selector: 'cms-choicelist',
  templateUrl: './choicelist.component.html',
  styleUrls: ['./choicelist.component.css'],
})
export class ChoicelistComponent
  implements OnInit, AfterViewInit, OnChanges, AfterContentInit
{
  /**
   * Array of [`Choice`]({{root}}/components/choice/#components.choice.react) data objects to be rendered.
   */
  @Input() choices?: ChoiceProps[];
  /**
   * Additional classes to be added to the root element.
   */
  @Input() className?: string;
  /**
   * Disables the entire field.
   */
  @Input() disabled?: boolean;
  @Input() errorMessage?: any;
  /**
   * Additional classes to be added to the error message
   */
  @Input() errorMessageClassName?: string;
  /**
   * Location of the error message relative to the field input
   */
  @Input() errorPlacement?: ChoiceListErrorPlacement;
  /**
   * Additional hint text to display
   */
  @Input() hint?: any;
  /**
   * Text showing the requirement ("Required", "Optional", etc.). See [Required and Optional Fields]({{root}}/guidelines/forms/#required-and-optional-fields).
   */
  @Input() requirementLabel?: any;
  @Input() isRequired?: boolean;
  @Input() requiredAria?: boolean;
  /**
   * Applies the "inverse" UI theme
   */
  @Input() inversed?: boolean;
  /**
   * Label for the field
   */
  @Input() label: any;
  /**
   * Additional classes to be added to the `FormLabel`.
   */
  @Input() labelClassName?: string;
  /**
   * @hide-prop [Deprecated] This prop is deprecated after changing `type` to a required prop
   */
  @Input() multiple?: boolean;
  /**
   * The field's `name` attribute
   */
  @Input() name?: string;
  /**
   * Called anytime any choice is blurred
   */
  @Input() onBlur?: (...args: any[]) => any;
  /**
   * Called when any choice is blurred and the focus does not land on one
   * of the other choices inside this component (i.e., when the whole
   * component loses focus)
   */
  @Input() onComponentBlur?: (...args: any[]) => any;
  @Input() onChange?: (choice: any, event: any) => any;
  /**
   * Sets the size of the checkbox or radio button
   */
  @Input() size?: ChoiceListSize;
  /**
   *Input to hide the red required asterisk.
   */
   @Input() hideAsterisk?: boolean = false;
  /**
   * Sets the type to render `checkbox` fields or `radio` buttons
   */
  
  @Input() type?: ChoiceListType;
  @Input() parentGroup?: UntypedFormGroup;
  @Input() formGroupName?: string;
  @Input() hiddenLabel?: boolean;
  @Input() anticipatoryText?: string;
  @ViewChild('formRef') formControl?: FormControlComponent;
  @ViewChild('formRef', { read: ElementRef }) formRef?: ElementRef;

  choiceRefs: ComponentRef<ChoiceComponent>[];
  divElem?: HTMLElement;
  

  constructor(
    private elementRef: ElementRef,
    private renderer: Renderer2,
    private vcr: ViewContainerRef,
    private injector: Injector,
    private cdr: ChangeDetectorRef
  ) {
    this.choiceRefs = [];
    this.handleBlur.bind(this);
  }

  ngOnInit(): void {
    this.updateFormControl();
  }

  ngAfterViewInit(): void {
    if (this.formRef) {
      let fieldset = (this.formRef?.nativeElement as HTMLElement).querySelector(
        'fieldset'
      );
      if (fieldset) {
        this.renderer.appendChild(fieldset, this.divElem);
      }
    }
    this.updateChoices();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['choices'] || changes['disabled']) {
      this.updateChoices();
    }
  }

  ngAfterContentInit(): void {
    this.cdr.detectChanges();
  }

  handleBlur(evt: any): void {
    if (this.onBlur) {
      this.onBlur(evt);
    }

    if (this.onComponentBlur) {
      this.handleComponentBlur(evt);
    }
  }

  handleComponentBlur(evt: any): void {
    // This is intentional
  }

  getChoices(): HTMLElement[] {
    this.choiceRefs = [];
    if (!this.choices) return [];

    const choices: HTMLElement[] = this.choices.map((choiceProps) => {
      const choiceRef = this.vcr.createComponent(ChoiceComponent, {
        injector: this.injector,
      });

      Object.entries(choiceProps).forEach(([key, value]) => {
        Object.assign(choiceRef.instance, { [key]: value });
      });
      if (this.inversed) {
        choiceRef.instance.inversed = this.inversed;
      }
      if (this.name) {
        choiceRef.instance.name = this.name;
      }
      if (this.type) {
        choiceRef.instance.type = this.type;
      }
      if (this.onBlur || this.onComponentBlur) {
        choiceRef.instance.onBlur = this.handleBlur;
      }
      if (this.onChange) {
        choiceRef.instance.onChange = this.onChange;
      }
      if (this.size) {
        choiceRef.instance.size = this.size;
      }
      if (this.isRequired !== undefined) {
        // If is required is shown on choicelist label, don't display on choice labels
        choiceRef.instance.isRequired = false;
        if(this.isRequired === true) {
          choiceRef.instance.isRequiredAria = true;
        }
      }
      const inputClasses = classNames(choiceProps.inputClassName, {
        'ds-c-choice--error': this.errorMessage,
      });
      choiceRef.instance.inputClassName = inputClasses;

      if (this.parentGroup) {
        choiceRef.instance.parentGroup = this.parentGroup;
      }
      if (choiceProps.formControlName) {
        choiceRef.instance.formControlName = choiceProps.formControlName;
      } else {
        if (this.disabled || choiceProps.disabled) {
          choiceRef.instance.disabled = true;
        }
      }
      if (this.formGroupName) {
        choiceRef.instance.formGroupName = this.formGroupName;
      }
      if (choiceProps.anticipatoryText) {
        choiceRef.instance.anticipatoryText = choiceProps.anticipatoryText;
      }

      this.choiceRefs.push(choiceRef);
      const elem = choiceRef.location.nativeElement as HTMLElement;
      this.renderer.setProperty(elem, 'key', choiceProps.value);

      return elem;
    });

    return choices;
  }

  updateFormControl() {
    const containerProps: any = _.pick(this, FormControlPropKeys);

    if (this.formControl) {
      Object.entries(containerProps).forEach(([key, value]) => {
        Object.assign(this.formControl!, { [key]: value });
      });
    }

    this.divElem = this.renderer.createElement('div');
    if (this.formGroupName) {
      this.renderer.setAttribute(
        this.divElem,
        'formGroupName',
        this.formGroupName
      );
      this.renderer.setProperty(this.divElem, 'formGroup', this.parentGroup);
    }
  }

  updateChoices() {
    let choices = this.divElem?.querySelectorAll('cms-choice');
    choices?.forEach((choice) => {
      this.renderer?.removeChild(this.divElem, choice);
    });

    if (this.divElem) {
      this.getChoices();
      this.choiceRefs.forEach((choiceRef) => {
        this.renderer?.appendChild(
          this.divElem,
          choiceRef.location.nativeElement
        );
      });
    }
  }
}
