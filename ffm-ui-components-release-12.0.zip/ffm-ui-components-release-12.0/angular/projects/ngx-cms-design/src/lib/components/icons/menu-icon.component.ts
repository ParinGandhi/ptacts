import { Component, Input, OnInit } from '@angular/core';
import classNames from 'classnames';

@Component({
  selector: 'cms-menu-icon',
  template: `
  <cms-svg-icon [className]="iconCssClasses" [ariaHidden]="ariaHidden"
                [description]="description"
                [id]="id"
                [inversed]="inversed"
                [title]="title"
                [viewBox]="viewBox">
              <svg:path
                fill="currentColor"
                d="M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z" />
            </cms-svg-icon>
            `,
  styles: []
})
export class MenuIconComponent implements OnInit {

  @Input() ariaHidden?: boolean;
  @Input() className?: string;
  @Input() description?: string;
  @Input() id?: string;
  @Input() inversed?: boolean;
  @Input() title?: string = 'Menu Icon';
  @Input() viewBox?: string = '0 0 448 512';

  iconCssClasses?: string;

  constructor() {
      // This is intentional
  }

  ngOnInit(): void {
    this.iconCssClasses = classNames('ds-c-icon--menu', this.className);
  }
}
