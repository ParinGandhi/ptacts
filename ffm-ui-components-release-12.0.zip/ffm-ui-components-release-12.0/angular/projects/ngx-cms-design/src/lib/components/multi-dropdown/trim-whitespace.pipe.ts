import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'trimWhitespace'
})
export class TrimWhitespacePipe implements PipeTransform {

  transform(value: any): string {
    return (value) ? value.replace(/\s/g,'') : '';
  }
}
