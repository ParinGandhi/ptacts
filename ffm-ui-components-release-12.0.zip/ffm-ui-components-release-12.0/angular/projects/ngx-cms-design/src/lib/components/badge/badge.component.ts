import { Component, Input, OnInit } from '@angular/core';
import classNames from 'classnames';
import { uniqueId } from 'lodash';

export type BadgeSize = 'big';
export type BadgeVariation = 'info' | 'success' | 'warn' | 'alert';

export interface BadgeProps {
  /**
   * Additional classes to be added to the root badge element.
   * Useful for adding utility classes.
   */
  className?: string;
  /**
   * Sets the font size of the Badge. Only supports 'big'
   */
  size?: BadgeSize;
  /**
   * A string corresponding to the badge-component variation classes
   */
  variation?: BadgeVariation;

  /**
   * Unique ID to be passed down to badge
   */
  id?: string;
}

@Component({
  selector: 'cms-badge',
  template: `<span [class]="classes" [id]="id" [attr.aria-label]="readerMessage">
              <ng-content></ng-content>
            </span>`,
  styleUrls: ['./badge.component.css']
})
export class BadgeComponent implements OnInit {

  @Input() className?: string;
  @Input() size?: BadgeSize;
  @Input() variation?: BadgeVariation;
  @Input() id?: string;

  private a11yLabel = {
    info: 'Notice',
    success: 'Success',
    warn: 'Warning',
    alert: 'Alert'
  };
  private sizeClasses = { big: 'ds-c-badge--big' };
  public classes?: string;
  public readerMessage?: string;

  constructor() {
    // This is intentional
  }

  ngOnInit(): void {
    const variationClass = this.variation && 'ds-c-badge--' + this.variation;
    this.readerMessage = this.variation && this.a11yLabel[this.variation];
    this.classes = classNames('ds-c-badge', variationClass, this.sizeClasses[this.size!], this.className);
    this.id = this.id || uniqueId('badge_');
  }
}
