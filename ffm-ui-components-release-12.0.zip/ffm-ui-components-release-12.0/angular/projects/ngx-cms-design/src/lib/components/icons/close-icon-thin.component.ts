import { Component, Input, OnInit } from '@angular/core';
import classNames from 'classnames';

@Component({
  selector: 'cms-close-icon-thin',
  template: `<cms-svg-icon [className]="iconCssClasses" [ariaHidden]="ariaHidden"
                [description]="description"
                [id]="id"
                [inversed]="inversed"
                [title]="title"
                [viewBox]="viewBox">
                  <svg:path
                    attr.stroke="currentColor"
                    attr.strokeLinecap="round"
                    attr.strokeWidth="2"
                    d="M0 13.0332964L13.0332964 0M13.0332964 13.0332964L0 0"
                    style="stroke-width: initial;"/>
            </cms-svg-icon>`,
  styles: []
})
export class CloseIconThinComponent implements OnInit {

  @Input() ariaHidden?: boolean;
  @Input() className?: string;
  @Input() description?: string;
  @Input() id?: string;
  @Input() inversed?: boolean;
  @Input() title?: string = 'Close';
  @Input() viewBox?: string = '-2 -2 18 18';

  iconCssClasses?: string;

  constructor() {
      // This is intentional
  }

  ngOnInit(): void {
    this.iconCssClasses = classNames('ds-c-icon--close', 'ds-c-icon--close-thin', this.className);
  }
}
