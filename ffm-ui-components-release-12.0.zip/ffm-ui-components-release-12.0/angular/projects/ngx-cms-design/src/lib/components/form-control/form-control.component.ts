import { FormLabelComponent } from './../form-label/form-label.component';
import {
  Component,
  Input,
  OnInit,
  AfterViewInit,
  ElementRef,
  ViewContainerRef,
  OnChanges,
  SimpleChanges,
  ViewChild,
  AfterContentInit,
  ChangeDetectorRef,
} from '@angular/core';
import * as _ from 'lodash';
import { errorPlacementDefault } from '../flags';
import classNames from 'classnames';

/**
 * <FormControl> is an internal component used form components (i.e <TextField>, <Dropdown>, <DateField>, <MonthPicker>)
 * It contains logic shared across form components, handling form labels, errors, id generation, and other shared props
 * <FormControl> is also exported for advanced design system use cases, where the internal component can be leveraged to build custom form components
 * As an internal component, it's subject to more breaking changes. Exercise caution using <FormControl> outside of those special cases
 */

interface FormControlRenderProps {
  id: string;
  labelId: string;
  errorId: string;
  setRef: (elem: HTMLElement) => void;
}

@Component({
  selector: 'cms-form-control',
  templateUrl: './form-control.component.html',
  styleUrls: ['./form-control.component.css'],
})
export class FormControlComponent
  implements OnInit, AfterViewInit, OnChanges, AfterContentInit
{
  /**
   * Additional classes to be added to the field container.
   */
  @Input() className?: string;

  /**
   * The HTML element used to render the container
   */
  @Input() component?: 'div' | 'fieldset' = 'div';

  /**
   * The ID of the error message applied to the Select field.
   */
  @Input() errorId?: string;
  @Input() errorMessage?: any;

  /**
   * Additional classes to be added to the error message
   */
  @Input() errorMessageClassName?: string;

  /**
   * Location of the error message relative to the field input
   */
  @Input() errorPlacement?: 'top' | 'bottom' = errorPlacementDefault();

  /**
   * Used to focus `select` on `componentDidMount()`
   */
  @Input() focusTrigger?: boolean;

  /**
   * Additional hint text to display
   */
  @Input() hint?: any;

  /**
   * A unique ID to be used for the field input. If one isn't provided, a unique ID will be generated.
   */
  @Input() id?: string;

  /**
   * Access a reference to the field input
   */
  @Input() inputRef?: HTMLElement;

  /**
   * Applies the "inverse" UI theme
   */
  @Input() inversed?: boolean;

  /**
   * Label for the field.
   */
  @Input() label?: any;

  /**
   * Additional classes to be added to the `FormLabel`.
   */
  @Input() labelClassName?: string;

  /**
   * The root HTML element used to render the field label
   */
  @Input() labelComponent?: 'label' | 'legend';

  /**
   * A unique `id` to be used on the field label. If one isn't provided, a unique ID will be generated.
   */
  @Input() labelId?: string;

  /**
   *Input to hide the red required asterisk. If true and isRequired is also true the asterisk should be hidden
   */
  @Input() hideAsterisk?: boolean = false;

  /**
   * Text showing the requirement ("Required", "Optional", etc.).
   * See [Required and Optional Fields]({{root}}/guidelines/forms/#required-and-optional-fields).
   */
  @Input() requirementLabel?: any;
  @Input() isRequired?: boolean;
  @Input() ariaRequired?: boolean;
  @Input() hiddenLabel?: boolean = false;

  @ViewChild('rootElem') rootElem?: ElementRef<HTMLElement>;
  @ViewChild('labelRef') labelRef?: FormLabelComponent;
  @ViewChild('bottomErrorRef', { read: ElementRef })
  bottomErrorRef?: ElementRef;

  classes?: string = '';
  labelClasses?: string = '';
  isFieldset = false;
  bottomError = false;
  ariaInvalid = false;

  constructor(public vcr: ViewContainerRef, private cdRef: ChangeDetectorRef) {
  }

  ngOnInit(): void {
    this.id = this.id || _.uniqueId('field_');
    this.labelId = this.labelId || this.id + '-label';
    this.errorId = this.errorId || this.id + '-error';

    this.bottomError = this.errorPlacement === 'bottom' && this.errorMessage;

    if (!this.component) {
      this.component = 'div';
    }
    if (!this.errorPlacement) {
      this.errorPlacement = errorPlacementDefault();
    }
    if (
      this.requirementLabel &&
      (this.requirementLabel as string).length &&
      this.isRequired === undefined
    ) {
      this.isRequired = true;
    }
    this.isFieldset = this.component === 'fieldset';
    this.classes = classNames(
      {
        'ds-c-fieldset': this.isFieldset,
      },
      this.className
    );
    this.labelClasses = classNames(this.labelClassName, {
      'ds-u-visibility--screen-reader': this.hiddenLabel,
    });

    // Use `aria-invalid` attribute on errored fieldsets
    // Errored form components without fieldsets must handle `aria-invalid` in their own component
    this.ariaInvalid = this.isFieldset && this.errorMessage ? true : false;

    this.updateErrorMessage();
  }

  ngAfterViewInit(): void {
      // This is intentional
  }

  ngAfterContentInit(): void {
    this.cdRef.detectChanges();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['errorMessage']) {
      this.updateErrorMessage();
    }
  }

  componentDidMount(): void {
    if (this.focusTrigger && this.inputRef) {
      this.inputRef.focus();
    }
  }

  updateErrorMessage() {
    this.bottomError = this.errorPlacement === 'bottom' && this.errorMessage;
  }
}

export const FormControlPropKeys = [
  'className',
  'component',
  'errorId',
  'errorMessageClassName',
  'focusTrigger',
  'hint',
  'id',
  'inversed',
  'label',
  'labelClassName',
  'labelComponent',
  'labelId',
  'requirementLabel',
  'render',
  'hiddenLabel',
];
