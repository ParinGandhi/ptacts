import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cms-ellipses',
  template: `<li>
              <span className="ds-c-pagination__overflow">&hellip;</span>
            </li>`,
  styles: []
})
export class EllipsesComponent implements OnInit {

  constructor() {
      // This is intentional
  }

  ngOnInit(): void {
      // This is intentional
  }

}
