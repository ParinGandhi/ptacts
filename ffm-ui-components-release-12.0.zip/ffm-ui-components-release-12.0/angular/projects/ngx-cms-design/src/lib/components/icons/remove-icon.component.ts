import { Component, Input, OnInit } from '@angular/core';
import classNames from 'classnames';

@Component({
  selector: 'cms-remove-icon',
  template: `<cms-svg-icon [className]="iconCssClasses" [ariaHidden]="ariaHidden"
                [description]="description"
                [id]="id"
                [inversed]="inversed"
                [title]="title"
                [viewBox]="viewBox">
              <svg:path d="M19 13H5v-2h14v2z" />
            </cms-svg-icon>`,
  styles: []
})
export class RemoveIconComponent implements OnInit {

  @Input() ariaHidden?: boolean;
  @Input() className?: string;
  @Input() description?: string;
  @Input() id?: string;
  @Input() inversed?: boolean;
  @Input() title?: string = 'Remove';
  @Input() viewBox?: string = '0 0 24 24';

  iconCssClasses?: string;

  constructor() {
      // This is intentional
  }

  ngOnInit(): void {
    this.iconCssClasses = classNames('ds-c-icon--ad', this.className);
  }
}
