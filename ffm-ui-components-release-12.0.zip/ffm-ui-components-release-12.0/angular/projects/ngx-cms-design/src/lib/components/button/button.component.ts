import { uniqueId } from 'lodash';
import { Component, Input, OnInit, Renderer2, ElementRef, AfterViewInit, ViewChild, ViewEncapsulation } from '@angular/core';
import classNames from 'classnames';

export type ButtonSize = 'small' | 'big';
export type ButtonVariation = 'primary' | 'success' | 'transparent';
export type ButtonType = 'button' | 'submit' | 'reset';

type CommonButtonProps = {
  /**
   * Additional classes to be added to the root button element.
   * Useful for adding utility classes.
   */
  className?: string;
  disabled?: boolean;
  /**
   * When provided the root component will render as an `<a>` element
   * rather than `button`.
   */
  href?: string;
  /**
   * @hide-prop [Deprecated] Use inversed instead
   */
  inverse?: boolean;
  /** Applies the inverse theme styling */
  inversed?: boolean;
  /**
   * Returns the [`SyntheticEvent`](https://facebook.github.io/react/docs/events.html).
   * Not called when the button is disabled.
   */
  onClick?: (...args: any[]) => any;
  size?: ButtonSize;
  /**
   * Button [`type`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button#attr-type) attribute
   */
  type?: ButtonType;
  /**
   * A string corresponding to the button-component variation classes.
   * The `'danger'` variation is deprecated and will be removed in a future release.
   */
  variation?: ButtonVariation;
};

export const buttonAttributes: string[] = [
  'autofocus', 'form', 'formaction', 'formenctype', 'formmethod', 'formnovalidate',
  'formtarget', 'name', 'value'
]

export const anchorAttributes: string[] = [
  'download', 'hreflang', 'ping', 'referrerpolicy', 'rel', 'target'
]

@Component({
  selector: 'cms-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ButtonComponent implements OnInit, AfterViewInit {

  @Input() className?: string;
  @Input() disabled?: boolean;
  @Input() href?: string;
  @Input() inversed?: boolean;
  @Input() onClick?: (...args: any[]) => any;
  @Input() size?: ButtonSize;
  @Input() type?: ButtonType = 'button';
  @Input() variation?: ButtonVariation;
  @Input() id?: string;
  @Input() ariaDescribedby?: string;
  @Input() ariaLabel?: string;
  @Input() roleAttr?: string;
  @ViewChild('toremove') toRemove?: ElementRef;
  @ViewChild('buttonRef') buttonRef?: ElementRef;
  @ViewChild('aRef') aRef?: ElementRef;

  componentType?: string;
  variationClass?: string;
  sizeClass?: string;
  inverseClass?: any;
  classes?: string = '';
  disabledClass?: any;
  content?: string;

  constructor(private renderer: Renderer2, private elementRef: ElementRef) {
  }

  ngOnInit(): void {
    this.componentType = this.href ? 'a' : 'button';
    this.variationClass = this.variation && 'ds-c-button--' + this.variation;
    this.sizeClass = this.size && 'ds-c-button--' + this.size;
    this.inverseClass = this.inversed && 'ds-c-button--inverse';
    this.classes = classNames('ds-c-button', this.variationClass, this.inverseClass, this.sizeClass, this.className);
    this.id = this.id || uniqueId('button_');
  }

  ngAfterViewInit(): void {
    const attributes = Array.from(this.elementRef.nativeElement.attributes);
    var filteredAttributes: any[] = [];

    if (this.componentType === 'button') {
      filteredAttributes = attributes.filter((e: any) => {
        return buttonAttributes.some(item => item == e.name);
      });
    }
    else if (this.componentType === 'a') {
      filteredAttributes = attributes.filter((e: any) => {
        return anchorAttributes.some(item => item == e.name);
      });
    }

    filteredAttributes?.forEach((attr: any) => {
      if (this.buttonRef) {
        this.renderer.setAttribute(this.buttonRef.nativeElement, attr.name, attr.value);
      }
      if (this.aRef) {
        this.renderer.setAttribute(this.aRef.nativeElement, attr.name, attr.value);
      }
    });
  }

  handleClick(event: any): void {
    if (!this.disabled && this.onClick) {
      this.onClick(event);
    }
  }

  handleKeyPress(event: any): void {
    if (event.key === ' ') {
      this.handleClick(event);
    }
  }
}
