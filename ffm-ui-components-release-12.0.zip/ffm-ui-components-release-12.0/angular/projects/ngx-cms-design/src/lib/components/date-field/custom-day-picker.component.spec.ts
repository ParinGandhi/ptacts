import { CmsDesignModule } from 'ngx-cms-design';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomDayPickerComponent } from './custom-day-picker.component';

describe('CustomDayPickerComponent', () => {
  let component: CustomDayPickerComponent;
  let fixture: ComponentFixture<CustomDayPickerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ CmsDesignModule],
      declarations: [ CustomDayPickerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomDayPickerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
