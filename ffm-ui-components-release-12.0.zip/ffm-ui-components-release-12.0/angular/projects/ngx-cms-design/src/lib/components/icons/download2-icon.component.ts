import { Component, Input, OnInit } from '@angular/core';
import classNames from 'classnames';

@Component({
  selector: 'cms-download2-icon',
  template: `<cms-svg-icon [className]="iconCssClasses" [ariaHidden]="ariaHidden"
                [description]="description"
                [id]="id"
                [inversed]="inversed"
                [title]="title"
                [viewBox]="viewBox">
              <svg>
               <path fill-rule="evenodd"
                    d="M7.04727305,6 L5.88954613,4.78361162 C5.48634246,4.37558579 5.48634246,3.71404521 5.88954613,3.30601937 C6.29274981,2.89799354 6.94647213,2.89799354 7.34967581,3.30601937 L11,7 L7.34967581,10.6939806 C6.94647213,11.1020065 6.29274981,11.1020065 5.88954613,10.6939806 C5.48634246,10.2859548 5.48634246,9.62441421 5.88954613,9.21638838 L7.04727305,8.0448155 L2.0324676,8 C1.46225149,8 1,7.57703567 1,7 C1,6.42296433 1.46225149,6 2.0324676,6 L7.04727305,6 Z M12,2 C12.5522847,2 13,2.44771525 13,3 L13,11 C13,11.5522847 12.5522847,12 12,12 C11.4477153,12 11,11.5522847 11,11 L11,3 C11,2.44771525 11.4477153,2 12,2 Z"
                    transform="rotate(90 7 7)"></path>
          </svg>
            </cms-svg-icon>`,
  styles: []
})
export class Download2IconComponent implements OnInit {

  @Input() ariaHidden?: boolean;
  @Input() className?: string;
  @Input() description?: string;
  @Input() id?: string;
  @Input() inversed?: boolean;
  @Input() title?: string = 'Download';
  @Input() viewBox?: string = '0 0 14 14';

  iconCssClasses?: string;

  constructor() {
      // This is intentional
  }

  ngOnInit(): void {
    this.iconCssClasses = classNames(this.className);
  }
}
