import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {
  transform(items: any[], searchTerm: string, labelKey?: string) {
    if (!items || !searchTerm) {
      return items;
    }

    return items.filter(
      item => {
        return item[labelKey || 'name']
          .toLowerCase()
          .includes(searchTerm.toLowerCase()) === true
      }
    );
  }
}
