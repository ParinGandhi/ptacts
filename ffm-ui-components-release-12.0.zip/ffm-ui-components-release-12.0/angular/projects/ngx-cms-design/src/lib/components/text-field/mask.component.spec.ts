import { Renderer2 } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CmsDesignModule } from 'ngx-cms-design';

import { MaskComponent } from './mask.component';

describe('MaskComponent', () => {
  let component: MaskComponent;
  let fixture: ComponentFixture<MaskComponent>;
  let renderer: Renderer2;

  class MockRenderer {
    setAttribute(document: string, name: string, value: string): boolean {
      return true;
    }
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ CmsDesignModule ],
      declarations: [ MaskComponent ],
      providers: [ { provide: Renderer2, useClass: MockRenderer }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MaskComponent);
    renderer = fixture.componentRef.injector.get(Renderer2);

    component = fixture.componentInstance;
    component.mask = 'currency';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
