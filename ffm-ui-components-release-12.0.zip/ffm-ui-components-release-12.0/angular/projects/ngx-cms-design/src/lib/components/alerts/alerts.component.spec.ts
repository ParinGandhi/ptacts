import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CmsDesignModule } from 'ngx-cms-design';

import { AlertsComponent } from './alerts.component';

describe('AlertComponent', () => {
  let component: AlertsComponent;
  let fixture: ComponentFixture<AlertsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ CmsDesignModule ],
      declarations: [ AlertsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AlertsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
