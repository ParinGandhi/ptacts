import { uniqueId } from 'lodash';
import {
  Component,
  Input,
  OnInit,
  ViewChild,
  AfterViewInit,
  TemplateRef,
  OnChanges,
  SimpleChanges,
  Renderer2,
  ChangeDetectorRef,
  NgZone,
  ViewEncapsulation,
  ElementRef,
  ChangeDetectionStrategy,
} from '@angular/core';
import {
  Columns,
  Config,
  DefaultConfig,
  API,
  APIDefinition,
  Pagination,
} from 'ngx-easy-table';
import classNames from 'classnames';

export type TableStackableBreakpoint = 'sm' | 'md' | 'lg';
export type ColumnPosition = 'body' | 'header';
export interface ColumnTemplate {
  key: string;
  position: ColumnPosition;
  template: TemplateRef<any>;
}

export interface TableProps {
  /**
   * Applies the borderless variation of the table.
   */
  borderless?: boolean;
  /**
   * Additional classes to be added to the root table element.
   */
  className?: string;
  /**
   * Applies the compact variation of the table.
   */
  compact?: boolean;
  /**
   * Returns the [`SyntheticEvent`](https://facebook.github.io/react/docs/events.html).
   */
  onSelect?: (...args: any[]) => any;
  /**
   * Applies a horizontal scrollbar and scrollable notice on `TableCaption` when the `Table`'s contents exceed the container width.
   */
  scrollable?: boolean;
  /**
   * Additional text or content to display when the horizontal scrollbar is visible to give the user notice of the scroll behavior.
   * This prop will only be used when the `Table` `scrollable` prop is set and the table width is wider than the viewport.
   */
  scrollableNotice?: any;
  /**
   * A stackable variation of the table.
   * When `stackable` is set, `id` or `headers` prop is required in `Table`
   */
  stackable?: boolean;
  /**
   * Applies responsive styles to vertically stacked rows at different viewport sizes.
   */
  stackableBreakpoint?: TableStackableBreakpoint;
  /**
   * A striped variation of the table.
   */
  striped?: boolean;
  /**
   * Disables the warning message on development console when a responsive stackable table cell does not contain an `id` or `headers`.
   * It's recommended that accessibility with screen readers is tested to ensure the stacked table meets the requirement.
   */
  warningDisabled?: boolean;
  /**
   * Additional text or content to dsiplay in caption
   */
  caption?: any;
  /**
   * ID for table
   */
}

@Component({
  selector: 'cms-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TableComponent implements OnInit, AfterViewInit, OnChanges {
  @Input() borderless?: boolean;
  @Input() className?: string;
  @Input() compact?: boolean;
  @Input() striped?: boolean;
  @Input() data: any[] = [];
  @Input() columns: Columns[] = [];
  @Input() config?: Config;
  @Input() pagination?: Pagination;
  @Input() onSelect?: (...args: any[]) => any;
  @Input() generateCheckboxAriaLabels?: (...args: any[]) => any;
  @Input() captionLabel?: any;
  @Input() hideCaption?: boolean;
  @Input() detailsTemplate?: TemplateRef<any>;
  @Input() summaryTemplate?: TemplateRef<any>;
  @Input() filtersTemplate?: TemplateRef<any>;
  @Input() loadingTemplate?: TemplateRef<any>;
  @Input() noResultsTemplate?: TemplateRef<any>;
  @Input() additionalActionsTemplate?: TemplateRef<any>;
  @Input() columnTemplates?: ColumnTemplate[];
  @Input() id?: string;
  @Input() role?: string;
  /**
   * Cannot be set along with checkboxes.  Displays the first column of the table as a Header
   * @param  {boolean=false;} displayFirstRowAsHeader
   * @returns boolean
   */
  @Input() displayFirstRowAsHeader: boolean = false;
  @Input() selectAllCheckboxText?: string = "Select All";
  selectAllSelected: boolean = false;
  @ViewChild('ngxTable') table?: APIDefinition;
  @ViewChild('ngxTable', { read: ElementRef })
  tableRef?: ElementRef<HTMLElement>;

  public configuration: Config = { ...DefaultConfig };
  public selected: Set<number> = new Set();
  toggled = false;

  captionId?: string;
  showTable: boolean = true;

  updatedDataFromSorting: any[] = [];

  constructor(
    private renderer: Renderer2,
    private cdr: ChangeDetectorRef,
    private ngZone: NgZone,
    private elem: ElementRef
  ) {}

  ngOnInit(): void {
    this.id = this.id || uniqueId('table_');
    this.captionId = this.id + '_caption';

    // set to threeWaySort by default
    if (this.configuration.orderEnabled) {
      this.configuration.threeWaySort = true;
    }

    if (this.config?.checkboxes && this.displayFirstRowAsHeader) {
      throw new Error(
        "A table can't have both checkboxes and have the first column set as header"
      );
    }
  }

  ngAfterViewInit(): void {
    this.updateStyles();

    if (this.table) {
      if (this.detailsTemplate) {
        Object.assign(this.table, { detailsTemplate: this.detailsTemplate });
      }
      if (this.summaryTemplate) {
        Object.assign(this.table, { summaryTemplate: this.summaryTemplate });
      }
      if (this.filtersTemplate) {
        Object.assign(this.table, { filtersTemplate: this.filtersTemplate });
      }
      if (this.loadingTemplate) {
        Object.assign(this.table, { loadingTemplate: this.loadingTemplate });
      }
      if (this.noResultsTemplate) {
        Object.assign(this.table, {
          noResultsTemplate: this.noResultsTemplate,
        });
      }
      if (this.additionalActionsTemplate) {
        Object.assign(this.table, {
          additionalActionsTemplate: this.additionalActionsTemplate,
        });
      }

      if (this.pagination) {
        this.pagination = {
          ...this.pagination,
          offset: this.pagination.offset ? this.pagination.offset : 1,
          limit: this.pagination.limit ? this.pagination.limit : 5,
          count: this.data.length ? this.data.length : -1,
        };
      }
    }

    this.addCaption();
    this.updateHeaders();
    this.accessibilityUpdates();
    this.addHeaderListeners();
    if(this.configuration.orderEnabled !== false){
      this.addDefaultSortHeadersForScreenReader();
    }

    this.cdr.detectChanges();
  }

  updateStyles() {
    this.cdr.detectChanges();
    let classes = classNames(
      'ds-c-table',
      {
        'ds-c-table--borderless': this.borderless,
        'ds-c-table--striped': this.striped,
        'ds-c-table--compact': this.compact,
      },
      this.className
    );

    this.cdr.detectChanges();
    this.table?.apiEvent({
      type: API.setTableClass,
      value: classes,
    });
  }

  addCaption(): void {
    if (this.tableRef && this.captionId) {
      let tableElem = this.tableRef.nativeElement.querySelector('table');
      this.renderer.setAttribute(tableElem, 'aria-describedby', this.captionId);
      if (tableElem) {
        let caption = tableElem.createCaption();
        caption.textContent = this.captionLabel;
        caption.id = this.captionId;
        if (this.hideCaption) {
          caption.className = 'ds-u-visibility--screen-reader position-static';
        } else {
          caption.className = 'ds-c-table__caption';
        }
      }
    }
  }

  addDefaultSortHeadersForScreenReader(): void {
    // by default have aria-sort for sort order set to none
    let headerTitles = this.elem.nativeElement.querySelectorAll(
      '.ngx-table__header-cell'
    );
    headerTitles.forEach((element: HTMLElement, index: number) => {
      let headerEl = element.querySelector('.ngx-table__header-title');
      let columnHeader = headerEl?.firstChild?.nodeValue?.toLowerCase().trim();
      if (
        this.configuration?.orderEnabled !== false && 
        this.columns.find((col) => {
          return col.title.toLowerCase().trim() === columnHeader;
        })?.orderEnabled !== false
      ) {
        let span = this.renderer.createElement('span');
        span.innerHTML = '<br/>';
        this.renderer.setAttribute(
          element,
          'aria-description',
          'Sorted none. Activate to sort column descending'
        );
        this.renderer.setAttribute(
          span,
          'aria-description',
          'Sorted none. Activate to sort column descending'
        );
        this.renderer.addClass(span, 'ds-u-visibility--screen-reader');
        this.renderer.setAttribute(span, 'id', 'screen-reader-sort-order');
        this.renderer.appendChild(headerEl, span);
        this.renderer.setAttribute(
          element,
          'aria-sort',
          'none'
        );
      }
    });
  }

  updateHeadersForScreenReader(sortedBy?: string, order?: string): void {
    let headerTitles = this.elem.nativeElement.querySelectorAll(
      '.ngx-table__header-cell'
    );
    let span = this.renderer.createElement('span');
    span.innerHTML = '<br/>';
    let colTitle = this.columns.find((col) => {
      return col.key.toLowerCase().trim() === sortedBy?.toLowerCase().trim();
    })?.title;

    headerTitles.forEach((element: HTMLElement, index: number) => {
      let headerEl = element.querySelector('.ngx-table__header-title');
      let columnHeader = headerEl?.firstChild?.nodeValue?.trim();
      if (colTitle === columnHeader) {
        if (this.configuration?.threeWaySort && this.columns[index]?.orderEnabled !== false) {
          if (order === 'asc') {
            this.renderer.setAttribute(
              element,
              'aria-sort',
              'ascending'
            );
            this.renderer.setAttribute(
              element,
              'aria-description',
              'Sorted ascending. Activate to sort column none'
            );
            this.renderer.setAttribute(
              span,
              'aria-description',
              'Sorted ascending. Activate to sort column none'
            );
          }
          if (order === 'desc') {
            this.renderer.setAttribute(
              element,
              'aria-sort',
              'descending'
            );
            this.renderer.setAttribute(
              element,
              'aria-description',
              'Sorted descending. Activate to sort column ascending'
            );
            this.renderer.setAttribute(
              span,
              'aria-description',
              'Sorted descending. Activate to sort column ascending'
            );
          }
          if (order === '') {
            this.renderer.setAttribute(
              element,
              'aria-sort',
              'none'
            );
            this.renderer.setAttribute(
              element,
              'aria-description',
              'Sorted none. Activate to sort column descending'
            );
            this.renderer.setAttribute(
              span,
              'aria-description',
              'Sorted none. Activate to sort column descending'
            );
          }
        } else {
          if (order === 'asc') {
            this.renderer.setAttribute(
              element,
              'aria-sort',
              'ascending'
            );
            this.renderer.setAttribute(
              element,
              'aria-description',
              'Sorted ascending. Activate to sort column descending'
            );
            this.renderer.setAttribute(
              span,
              'aria-description',
              'Sorted none. Activate to sort column descending'
            );
          }
          if (order === 'desc') {
            this.renderer.setAttribute(
              element,
              'aria-sort',
              'descending'
            );
            this.renderer.setAttribute(
              element,
              'aria-description',
              'Sorted descending. Activate to sort column ascending'
            );
            this.renderer.setAttribute(
              span,
              'aria-description',
              'activate to sort column ascending'
            );
          }
        }

        this.renderer.addClass(span, 'ds-u-visibility--screen-reader');
        this.renderer.setAttribute(span, 'id', 'screen-reader-sort-order');

        // remove/clean up existing screen reader spans before adding
        let screenReaderElements = this.elem.nativeElement.querySelectorAll(
          '#screen-reader-sort-order'
        );
        screenReaderElements.forEach((screenReaderElement: HTMLElement) => {
          if (headerEl === screenReaderElement.parentElement) {
            screenReaderElement.remove();
          } else {
            screenReaderElement.setAttribute(
              'aria-description',
              'Sorted none. Activate to sort column descending'
            );
          }
        });

        this.renderer.appendChild(headerEl, span);
      }
    });
  }

  accessibilityUpdates(): void {
    if (this.role && this.id) {
      let table = document.getElementById(this.id);
      if (table)
        this.renderer.setAttribute(table, 'role', this.role);
    }

    // By default (table with column header only) set all headers to scope col
    let headers = this.elem.nativeElement.querySelectorAll(
      '.ngx-table__header-cell'
    );
    headers.forEach((element: HTMLElement) => {
      this.renderer.setAttribute(element, 'scope', 'col');
    });

    this.rowAccessibilityUpdates();
  }

  /**
   * This function updates the scopes for different table types concerning 508
   * Table with checkmarks as the first column and Table with first column as header
   */
  rowAccessibilityUpdates(): void {
    setTimeout(() => {
      let rows = this.elem.nativeElement.querySelectorAll('tr');
      rows.forEach((element: HTMLElement) => {
        if (this.displayFirstRowAsHeader) {
          // if the first column is a header then set the tds of the first column to a th
          let children = element.children;
          if (children.length > 0 && !this.config?.checkboxes && this.data.length > 0) {
            let td0 = children[0] as HTMLElement;
            let th = this.renderer.createElement('th');

            if (element.className !== 'ngx-table__header') {
              this.renderer.setAttribute(th, 'scope', 'row');
              this.renderer.addClass(th, 'row-header');
            } else {
              this.renderer.setAttribute(th, 'scope', 'col');
            }

            th.innerHTML = td0.innerHTML;
            td0.replaceWith(th);
          }
          this.renderer.setAttribute(element, 'role', 'row');
        } else {
          let children = element.children;
          if (children.length > 0) {
            if (
              this.config?.checkboxes &&
              element.querySelector('ngx-form-checkbox')
            ) {
              let td1 = children[0] as HTMLElement;
              let td = this.renderer.createElement('td');
              td.innerHTML = td1.innerHTML;
              td1.replaceWith(td);
            }
          }
        }
      });

      let checkboxes =
        this.elem.nativeElement.querySelectorAll('.ngx-form-checkbox');
      checkboxes.forEach((element: HTMLElement) => {
        let input = element.querySelector('input');
        let splitId = input?.id.split('checkbox-');
        if (splitId && splitId?.length > 1) {
          let number = parseInt(splitId[1]) + 1;
          if (this.generateCheckboxAriaLabels) {
            if (this.updatedDataFromSorting && this.updatedDataFromSorting.length > 0) {
              this.renderer.setAttribute(input, 'aria-label', this.generateCheckboxAriaLabels(number, this.updatedDataFromSorting));
            } else {
              this.renderer.setAttribute(input, 'aria-label', this.generateCheckboxAriaLabels(number));
            }
            this.updatedDataFromSorting = [];
          } else if(this.data[0]?.deficiencyLevel === 'Level 2'){
            this.renderer.setAttribute(
              input,
              'aria-label',
              'Select Correction Level 2: ' + this.data[number - 1].deficiencyCode
            );
          }
          else if (this.data[0]?.fileName){
            this.renderer.setAttribute(
              input,
              'aria-label',
              'Select ' + this.data[number - 1].fileName + ' for ' + this.data[number - 1].domain
            );
          }
          else {
              this.renderer.setAttribute(
              input,
              'aria-label',
              'Select Row ' + number
            );
          }
          let span = element.querySelector('span');
          if (span) {
            this.renderer.removeChild(element, span);
          }
          let hiddenTextElem = this.renderer.createElement('span');
          this.renderer.addClass(
            hiddenTextElem,
            'ds-u-visibility--screen-reader'
          );
          this.renderer.setAttribute(
            hiddenTextElem,
            'aria-hidden',
            'true'
          )
          let hiddenText = this.renderer.createText('Select Row ' + number);
          this.renderer.appendChild(hiddenTextElem, hiddenText);
          this.renderer.appendChild(element, hiddenTextElem);
        }
      });
    }, 2);
  }

  addHeaderListeners(): void {
    if (this.tableRef) {
      let titleElems = this.tableRef.nativeElement.querySelectorAll(
        '.ngx-table__header-title'
      );
      titleElems.forEach((element) => {
        this.renderer.listen(element, 'keydown', (event) => {
          event.stopPropagation();
          if (event.code === 'Enter') {
            let el = element as HTMLElement;
            el.click();
          }
        });
      });
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['data']) {
      this.recreateTable(changes['data']);
    }
    if (changes['columns']) {
      this.updateColumnTemplates();
    }
    if (changes['columnTemplates']) {
      this.updateColumnTemplates();
    }
    if (changes['config']) {
      this.configuration = { ...this.config! };
      this.configuration.collapseAllRows = false;
    }
    if (changes['captionLabel']) {
      this.addCaption();
    }

    this.updateStyles();
  }

  recreateTable(changes: any) {
    this.showTable = false;
    this.cdr.detectChanges();
    this.showTable = true;
    this.cdr.detectChanges();
    this.addCaption();
    this.updateHeaders(undefined, '');
    this.addDefaultSortHeadersForScreenReader();
    this.updateHeadersForScreenReader(undefined, '');
    this.accessibilityUpdates();
  }
  /**
   * Iterates through passing in columnTemplates and replaces the view in each column matching key
   */
  updateColumnTemplates() {
    if (this.columnTemplates && this.columnTemplates.length) {
      this.columnTemplates.forEach((temp) => {
        const columnIndex = this.columns.findIndex((col) => {
          return col.key === temp.key;
        });
        switch (temp.position) {
          case 'body':
            this.ngZone.run(() => {
              if (this.columns[columnIndex]) {
                Object.assign(this.columns[columnIndex], {
                  cellTemplate: temp.template,
                });
              }
            });
            break;
          case 'header':
            this.ngZone.run(() => {
              Object.assign(this.columns[columnIndex], {
                headerActionTemplate: temp.template,
              });
            });
            break;
        }
      });
      this.columns = [...this.columns];
    }
  }

  /**
   * Method called when table row is checked
   * @param  {{event:string;value:any}} $event
   * @returns void
   */
  eventEmitted($event: { event: string; value: any }): void {
    switch ($event.event) {
      case 'onCheckboxSelect':
        if (this.selected.has($event.value.rowId)) {
          this.selected.delete($event.value.rowId);
          this.selectAllSelected = false;
        } else {
          this.selected.add($event.value.rowId);
          if (this.data.length === this.selected.size) {
            this.selectAllSelected = true;
          }
        }
        this.cdr.detectChanges();
        break;
      case 'onSelectAll':
        if ($event.value) {
          this.data.forEach((_, key) => {
            if (!this.selected.has(key)) {
              this.selected.add(key);
            }
            this.selectAllSelected = true;
          });
        } else {
          this.selected.clear();
          this.selectAllSelected = false;
        }
        this.cdr.detectChanges();
        break;
      case 'onClick':
        break;
      case 'onPagination':
        if (this.configuration.rows !== $event.value.limit) {
          this.configuration.rows = $event.value.limit;
        }
        break;
      case 'onOrder':
        this.updateHeaders($event.value.key, $event.value.order);
        this.updateHeadersForScreenReader($event.value.key, $event.value.order);

        if (this.generateCheckboxAriaLabels) {
          // update data based on sorting. this is being used to generate the aria-labels for checkboxes
          this.updatedDataFromSorting = [...this.data.sort((a, b) => {
            const valueA = a[$event.value.key];
            const valueB = b[$event.value.key];

            if ($event.value.order === 'asc') {
              return valueA.localeCompare(valueB);
            } else if ($event.value.order === 'desc') {
              return valueB.localeCompare(valueA);
            } else {
              // do nothing when no sort order
            }
          })];
        }

        this.rowAccessibilityUpdates();
        break;

      default:
        break;
    }

    if (this.onSelect) {
      if (this.configuration.checkboxes) {
        this.onSelect($event, this.selected);
      } else {
        this.onSelect($event);
      }
    }
  }
  /**
   *
   * @param _type API enum from ngx-easy-table
   * @param _value values to change depends on API type
   */
  apiEvent(_type: API, _value?: any) {
    this.table?.apiEvent({ type: _type, value: _value });
  }

  removeBothArrows(): void {
    if (this.tableRef) {
      let titleElems = this.tableRef.nativeElement.querySelectorAll(
        '.ngx-table__header-title'
      );
      titleElems.forEach((element) => {
        let bothArrows = element.querySelector('.ngx-icon-arrow-both');
        if (bothArrows) {
          this.renderer.removeChild(element, bothArrows);
        }
      });
    }
  }

  removeHeaderSortAttributes(): void {
    if (this.tableRef) {
      let titleElems = this.tableRef.nativeElement.querySelectorAll(
        '.ngx-table__header-title'
      );
      titleElems.forEach((element) => {
          this.renderer.removeAttribute(element, "tabindex");
        });
    }
  }

  updateHeaders(sortedBy?: string, order?: string): void {
    this.removeBothArrows();
    if (this.tableRef && this.configuration.orderEnabled) {
      let titleElems = this.tableRef.nativeElement.querySelectorAll(
        '.ngx-table__header-cell'
      );

      titleElems.forEach((element, index) => {
        let colTitle = this.columns.find((col) => {
          return (
            col.key.toLowerCase().trim() === sortedBy?.toLowerCase().trim()
          );
        })?.title;
        let headerEl = element.querySelector('.ngx-table__header-title');
        let columnHeader = headerEl?.firstChild?.nodeValue?.toLowerCase().trim();

        if ((columnHeader !== colTitle?.toLowerCase().trim() || order === '' || !order) && this.columns[index]?.orderEnabled !== false) {
          let em = this.renderer.createElement('em');
          this.renderer.addClass(em, 'ngx-icon');
          this.renderer.addClass(em, 'ngx-icon-arrow-both');
          this.renderer.appendChild(headerEl, em);
        }
        this.renderer.setAttribute(headerEl, 'tabindex', '0');

        if (columnHeader === colTitle?.toLowerCase().trim()) {
          let fullTextOrder =
          order === 'asc'
            ? 'ascending'
            : order === 'desc'
            ? 'descending'
            : 'none';
          if (order === 'asc') {
            this.renderer.setAttribute(
              element,
              'aria-sort',
              'ascending'
            );
          } else if (order === 'desc') {
            this.renderer.setAttribute(
              element,
              'aria-sort',
              'descending'
            );
          } else {
            if (fullTextOrder === 'none') {
              this.renderer.setAttribute(
                element,
                'aria-sort',
                'none'
              );
            }
          }
        } else {
          // announce none sort order by default (when no sort order is active)
          this.renderer.setAttribute(
            element,
            'aria-sort',
            'none'
          );
        }
      });
    } else {
      this.removeHeaderSortAttributes();
    }

    if (this.tableRef && !this.configuration.searchEnabled) {
      let searchHeader = this.tableRef.nativeElement.querySelector(
        'tr.ngx-table__search-header'
      );
      let parent = searchHeader?.parentElement;
      if (searchHeader && parent) {
        this.renderer.removeChild(parent, searchHeader);
      }
    }
  }
}
