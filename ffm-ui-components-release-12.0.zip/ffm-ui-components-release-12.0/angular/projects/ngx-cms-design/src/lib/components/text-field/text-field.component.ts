import {
  InputAttributes,
  NOOP_VALUE_ACCESSOR,
  TextAreaAttributes,
  TextInputComponent,
} from './text-input.component';
import {
  Component,
  Input,
  OnInit,
  ElementRef,
  AfterViewInit,
  Self,
  Optional,
  ViewChild,
  ChangeDetectorRef,
} from '@angular/core';
import {
  FormControlComponent,
  FormControlPropKeys,
} from '../form-control/form-control.component';
import classNames from 'classnames';
import * as _ from 'lodash';
import { errorPlacementDefault } from '../flags';
import { NgControl, UntypedFormGroup, AbstractControl } from '@angular/forms';

// TODO: Remove this export, apps shouldnt be importing `unmaskValue` from `TextField`
export { unmaskValue } from './maskHelpers';

export type TextFieldDefaultValue = string | number;
export type TextFieldMask = 'currency' | 'phone' | 'ssn' | 'zip';
export type TextFieldRows = number | string;
export type TextFieldSize = 'small' | 'medium';
export type TextFieldValue = string | number;
export type TextFieldErrorPlacement = 'top' | 'bottom';

export interface TextFieldProps {
  /**
   * Apply an `aria-label` to the text field to provide additional
   * context to assistive devices.
   */
  ariaLabel?: string;
  /**
   * Apply an `aria-labelledby` to the text field to provide additional
   * context to assistive devices.
   */
  ariaLabelledby?: string;
  /**
   * Apply an `aria-describedby` to the text field to provide additional
   * context to assistive devices.
   */
  ariaDescribedby?: string;
  /**
   * Additional classes to be added to the root `div` element
   */
  className?: string;
  /**
   * Sets the initial value. Use this for an uncontrolled component; otherwise,
   * use the `value` property.
   */
  defaultValue?: TextFieldDefaultValue;
  disabled?: boolean;
  errorMessage?: any;
  /**
   * Additional classes to be added to the error message
   */
  errorMessageClassName?: string;
  /**
   * Location of the error message relative to the field input
   */
  errorPlacement?: TextFieldErrorPlacement;
  /**
   * Additional classes to be added to the field element
   */
  fieldClassName?: string;
  /**
   * Used to focus `input` on `componentDidMount()`
   */
  focusTrigger?: boolean;
  /**
   * Additional hint text to display
   */
  hint?: any;
  /**
   * A unique `id` to be used on the text field.
   */
  id?: string;
  /**
   * Access a reference to the `input` or `textarea` element
   */
  // inputRef?: (...args: any[]) => any;
  /**
   * Text showing the requirement ("Required", "Optional", etc.). See [Required and Optional Fields]({{root}}/guidelines/forms/#required-and-optional-fields).
   */
  requirementLabel?: any;
  isRequired?: boolean;
  /**
   * Applies the "inverse" UI theme
   */
  inversed?: boolean;
  /**
   * Label for the input
   */
  label: any;
  /**
   * Additional classes to be added to the `FormLabel`.
   */
  labelClassName?: string;
  /**
   * A unique `id` to be used on the label field.
   */
  labelId?: string;
  /**
   * Apply formatting to the field that's unique to the value
   * you expect to be entered. Depending on the mask, the
   * field's appearance and functionality may be affected.
   */
  mask?: TextFieldMask;
  /**
   * Whether or not the text field is a multiline text field
   */
  multiline?: boolean;
  name: string;
  /**
   * Sets `inputMode`, `type`, and `pattern` to improve accessibility and consistency for number fields. Use this prop instead of `type="number"`, see [here](https://technology.blog.gov.uk/2020/02/24/why-the-gov-uk-design-system-team-changed-the-input-type-for-numbers/) for more information.
   */
  numeric?: boolean;
  onBlur?: (...args: any[]) => any;
  onChange?: (...args: any[]) => any;
  onFocus?: (...args: any[]) => any;
  onKeyDown?: (...args: any[]) => any;
  /**
   * @hide-prop HTML `input` [pattern](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#htmlattrdefpattern).
   */
  pattern?: string;
  /**
   * Optionally specify the number of visible text lines for the field. Only
   * applicable if this is a multiline field.
   */
  rows?: TextFieldRows;
  /**
   * Set the max-width of the input either to `'small'` or `'medium'`.
   */
  size?: TextFieldSize;
  /**
   * HTML `input` [type](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#<input>_types) attribute. If you are using `type=number` please use the numeric prop instead.
   */
  type?: string;
  /**
   * Sets the input's `value`. Use this in combination with `onChange`
   * for a controlled component; otherwise, set `defaultValue`.
   */
  value?: TextFieldValue;
}

@Component({
  selector: 'cms-text-field',
  templateUrl: './text-field.component.html',
  styleUrls: ['./text-field.component.css'],
})
export class TextFieldComponent implements OnInit, AfterViewInit {
  @Input() className?: string;
  @Input() ariaLabel?: string;
  @Input() ariaRequired?: boolean;
  @Input() ariaLabelledby?: string;
  @Input() ariaDescribedby?: string;
  @Input() defaultValue?: TextFieldDefaultValue;
  @Input() disabled?: boolean;
  @Input() errorMessage?: any;
  @Input() errorMessageClassName?: string;
  @Input() errorPlacement?: TextFieldErrorPlacement;
  @Input() fieldClassName?: string;
  @Input() focusTrigger?: boolean;
  @Input() hint?: any;
  @Input() id?: string;
  @Input() requirementLabel?: any;
  @Input() isRequired?: boolean;
  @Input() inversed?: boolean;
  @Input() label: any;
  @Input() labelClassName?: string;
  @Input() labelId?: string;
  @Input() mask?: TextFieldMask;
  @Input() multiline?: boolean;
  @Input() name: string = '';
  @Input() numeric?: boolean;
  @Input() onBlur?: (...args: any[]) => any;
  @Input() onChange?: (...args: any[]) => any;
  @Input() onFocus?: (...args: any[]) => any;
  @Input() onInputHandler?: (...args: any[]) => any;
  @Input() pattern?: string;
  @Input() rows?: TextFieldRows;
  @Input() size?: TextFieldSize;
  @Input() type?: string = 'text';
  @Input() value?: TextFieldValue;
  @Input() formControlName?: string | number | null;
  @Input() parentGroup?: UntypedFormGroup;

  @ViewChild('inputRef', { read: ElementRef }) inputElemRef?: ElementRef;
  @ViewChild('inputRef') inputComponent?: TextInputComponent;
  @ViewChild('formRef') formComponent?: FormControlComponent;

  constructor(
    @Self() @Optional() public ngControl: NgControl,
    private elementRef: ElementRef,
    private cdr: ChangeDetectorRef
  ) {
    if (this.ngControl) {
      // Note: we provide the value accessor through here, instead of
      // the `providers` to avoid running into a circular import.
      // And we use NOOP_VALUE_ACCESSOR so TextField doesn't do anything with NgControl
      this.ngControl.valueAccessor = NOOP_VALUE_ACCESSOR;
    }
  }

  ngOnInit(): void {
    this.errorPlacement = this.errorPlacement || errorPlacementDefault();

    this.updateFormControl();
    this.updateInput();

    if (this.ngControl) {
      setTimeout(() => {
        this.checkIfIsRequired();
      });
    }
  }

  ngAfterViewInit(): void {
    if (this.formComponent) {
      setTimeout(() => {
        if (this.inputElemRef?.nativeElement) {
          this.formComponent?.labelRef?.labelRoot?.nativeElement.after(
            this.inputElemRef.nativeElement
          );
          if (
            this.errorPlacement === 'bottom' &&
            this.formComponent?.bottomErrorRef?.nativeElement
          ) {
            this.inputElemRef.nativeElement.after(
              this.formComponent?.bottomErrorRef?.nativeElement
            );
          }
        }
      });
    }
  }

  ngAfterContentInit(): void {
    this.cdr.detectChanges();
  }

  containerClasses = '';

  checkIfIsRequired() {
    if (this.isRequired === undefined && this.ngControl?.control?.validator) {
      let validator = this.ngControl.control.validator({} as AbstractControl);
      if (validator && validator['required']) {
        this.isRequired = true;
      } else {
        this.isRequired = false;
      }
    }
  }

  updateFormControl() {
    const containerProps: any = _.pick(this, FormControlPropKeys);

    this.containerClasses = classNames(
      'ds-u-clearfix', // fixes issue where the label's margin is collapsed
      this.className
    );

    if (this.formComponent) {
      Object.entries(containerProps).forEach(([key, value]) => {
        Object.assign(this.formComponent!, { [key]: value });
      });
    }
  }

  filteredAttributes: any[] = [];
  updateInput() {
    const InputOmitProps = [
      'vcr',
      'elementRef',
      'renderer',
      'injector',
      '__ngContext__',
      'inputOnlyProps',
      'containerProps',
      'value',
    ];
    const inputOnlyProps = _.omit(this, [
      ...FormControlPropKeys,
      ...InputOmitProps,
    ]);

    // pass attributes from text-field
    const attributesArray = Array.from(
      this.elementRef.nativeElement.attributes
    );
    this.filteredAttributes = [];
    if (this.multiline) {
      this.filteredAttributes = attributesArray.filter((e: any) => {
        return TextAreaAttributes.some((item) => item == e.name);
      });
    } else {
      this.filteredAttributes = attributesArray.filter((e: any) => {
        return InputAttributes.some((item) => item == e.name);
      });
    }

    if (this.inputComponent) {
      Object.entries(inputOnlyProps).forEach(([key, value]) => {
        Object.assign(this.inputComponent!, { [key]: value });
      });
    }
  }
}
