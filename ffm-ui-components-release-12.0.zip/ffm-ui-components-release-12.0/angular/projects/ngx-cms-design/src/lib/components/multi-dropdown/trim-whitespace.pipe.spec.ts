import { TrimWhitespacePipe } from './trim-whitespace.pipe';

describe('TrimWhitespacePipe', () => {
  it('create an instance', () => {
    const pipe = new TrimWhitespacePipe();
    expect(pipe).toBeTruthy();
  });
});
