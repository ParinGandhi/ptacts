import { Component, ElementRef, Input, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import classNames from 'classnames';
import { BadgeVariation } from '../badge/badge.component';

export interface TabProps {
  /**
   * Additional classes to be added to the root tab element.
   */
  className?: string;
  /**
   * A unique `id`, to be used on the rendered tab element.
   */
  id: string;
  /**
   * Sets the tab text
   */
  label?: string;
  /**
   * Sets the `href` attribute used for the tab. This can be useful if you want
   * to use relative links rather than a URL hash (the default).
   */
  href?: string;
  /**
   * Called when the tab is clicked, with the following arguments:
   * [`SyntheticEvent`](https://facebook.github.io/react/docs/events.html),
   * `panelId`, `id`, `href`
   */
  onClick?: (evt: any, panelId: string, id: string, href: string) => any;
  /**
   * Called when the tab is selected and a keydown event is triggered.
   * Called with the following arguments:
   * [`SyntheticEvent`](https://facebook.github.io/react/docs/events.html),
   * `panelId`, `id`, `href`
   */
  onKeyDown?: (evt: any, panelId: string, id: string, href: string) => any;
  /**
   * The `id` of the associated `TabPanel`. Used for the `aria-controls` attribute.
   */
  panelId: string;
  selected?: boolean;
  disabled?: boolean;
  /**
   * Used to add a badget to the tab label
   */
  badgeLabel?: string;
  /**
   * Change badge variation to display different colors
   */
  badgeVariation?: BadgeVariation;
}

@Component({
  selector: 'cms-tab',
  template: `<a
      *ngIf="!disabled"
      [attr.aria-selected]="selected"
      [attr.aria-controls]="panelId"
      [class]="classes"
      role="tab"
      [id]="id"
      [href]="href"
      (click)="handleClick($event)"
      (keydown)="handleKeyDown($event)"
      #link
      >{{ label
      }}<cms-badge
        *ngIf="badgeLabel"
        [variation]="badgeVariation ?? undefined"
        [attr.aria-label]="badgeLabel"
        className="ds-u-margin-left--2 ds-u-font-weight--normal"
        >{{ badgeLabel }}</cms-badge
      ></a
    >
    <span
      *ngIf="disabled"
      [attr.aria-disabled]="true"
      [class]="classes"
      role="tab"
      [id]="id"
      >{{ label
      }}<cms-badge
        *ngIf="badgeLabel"
        [variation]="badgeVariation ?? undefined"
        [attr.aria-label]="badgeLabel"
        className="ds-u-margin-left--2 ds-u-font-weight--normal"
        >{{ badgeLabel }}</cms-badge
      ></span
    >`,
  styleUrls: ['./tab.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class TabComponent implements OnInit {
  @Input() className?: string;
  @Input() id?: string;
  @Input() label?: string;
  @Input() href?: string;
  @Input() onClick?: (
    evt: any,
    panelId: string,
    id: string,
    href: string
  ) => any;
  @Input() onKeyDown?: (
    evt: any,
    panelId: string,
    id: string,
    href: string
  ) => any;
  @Input() panelId?: string;
  @Input() selected?: boolean;
  @Input() disabled?: boolean;
  @Input() badgeLabel?: string;
  @Input() badgeVariation?: BadgeVariation;

  @ViewChild('link') link?: ElementRef;

  classes: string = '';
  displayName: string = 'Tab';

  constructor(private elementRef: ElementRef) {}

  ngOnInit(): void {
    this.classes = classNames(
      'ds-c-tabs__item',
      this.badgeLabel && 'ds-c-tabs__badge',
      this.className
    );
    this.href = this.href || `#${this.panelId}`;
  }

  handleClick = (evt: any): void => {
    if (this.onClick) {
      this.onClick(evt, this.panelId!, this.id!, this.href!);
    }
  };

  handleKeyDown = (evt: any): void => {
    if (this.onKeyDown) {
      this.onKeyDown(evt, this.panelId!, this.id!, this.href!);
    }
  };

  setFocus() {
    this.link?.nativeElement.focus();
  }
}
