import { EllipsesComponent } from './ellipses.component';
import { PageComponent } from './page.component';
import { Component, Input, OnInit, ViewContainerRef, Injector, ElementRef, Renderer2, ComponentRef, ViewChild, AfterViewInit, OnChanges, SimpleChanges, ViewEncapsulation } from '@angular/core';
import classNames from 'classnames';


export interface PaginationProps {
  /**
   * Defines `aria-label` on wrapping Pagination element. Since this exists on a `<nav>` element, the word "navigation" should be omitted from this label. Optional.
   */
  ariaLabel?: string;
  /**
   * Class to be applied to parent `<nav>` element of Pagination component. Optional.
   */
  className?: string;
  /**
   * Renders compact layout. Optional.
   */
  compact?: boolean;
  /**
   * Defines active page in Pagination. Optional.
   */
  currentPage?: number;
  /**
   * Determines if navigation is hidden when current page is the first or last of Pagination page set. Optional.
   */
  isNavigationHidden?: boolean;
  /**
   * A callback function used to handle state changes.
   */
  onPageChange: (evt: any, page: number, paginator?: number) => void;
  /**
   * Defines application-specific routing in url for links.
   */
  renderHref?: (page: number, ...args: any[]) => string;
  /**
   * Sets custom label on start navigation. Added for language support. Optional.
   */
  startLabelText?: string;
  /**
   * Sets custom ARIA label on start navigation. Added for language support. Label structure should be the equivalent of: Previous Page. Optional.
   */
  startAriaLabel?: string;
  /**
   * Sets custom label on end navigation. Added for language support. Optional.
   */
  endLabelText?: string;
  /**
   * Sets custom ARIA label on end navigation. Added for language support. Label structure should be the equivalent of: Next Page. Optional.
   */
  endAriaLabel?: string;
  /**
   * Sets total number of pages in Pagination component.
   */
  totalPages: number;

  /**
   * Used on pages where there are multiple paginators
   */
  paginator?: number;
  /**
   * Sets prefix on ARIA label which is appended on buttons startAriaLabel, EndAriaLabel and page number ARIA labels. Optional.
   */
  ariaLabelPrefix?: string;
}

// Determines number of pages visible to either side of active page.
const overflow = 1;

// Determines total number of visible pages without Ellipses.
const maxVisiblePages = 7;

@Component({
  selector: 'cms-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class PaginationComponent implements OnInit, AfterViewInit, OnChanges {

  @Input() ariaLabel?: string = 'Pagination';
  @Input() className?: string;
  @Input() compact?: boolean = false;
  @Input() currentPage?: number = 0;
  @Input() isNavigationHidden?: boolean = false;
  @Input() onPageChange?: (evt: any, page: number, paginator?: number) => void;
  @Input() renderHref?: (page: number, ...args: any[]) => string;
  @Input() startLabelText?: string = 'Previous';
  @Input() startAriaLabel?: string = 'Previous Page';
  @Input() endLabelText?: string = 'Next';
  @Input() endAriaLabel?: string = 'Next Page';
  @Input() totalPages: number = 0;
  @Input() paginator?: number;
  @Input() ariaLabelPrefix?: string = '';
  @ViewChild('ulElem') ulElem?: ElementRef<HTMLElement>;


  classes = '';
  paginationRange: number[] = [];
  pages: ComponentRef<any>[] = [];
  subPageChange = false;

  constructor(private elementRef: ElementRef, private renderer: Renderer2,
    private vcr: ViewContainerRef, private injector: Injector) { }

  ngOnInit(): void {
    this.classes = classNames('ds-c-pagination', this.className);
    if (this.onPageChange) {
      this.onPageChange.bind(this);
    }

    this.createPages();
  }

  ngAfterViewInit(): void {
    this.renderPages();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['currentPage'] && this.ulElem) {
      this.clearPages();
      this.createPages();
      this.renderPages();
    }
    else if (changes['totalPages'] && this.ulElem) {
      this.clearPages();
      this.createPages();
      this.renderPages();
    }
  }

  /**
   * Remove pages from DOM and clear pages array
   */
  clearPages() {
    this.pages.forEach(page => {
      this.renderer.removeChild(this.ulElem?.nativeElement, page.location.nativeElement);
    });
    this.pages = [];
  }

  /**
   * Recreate pages
   */
  createPages() {
    if (!this.compact) {
      const pageRange = this.paginationBuilder(this.currentPage!, this.totalPages);

      if (pageRange[0] >= 2) {
        /**
         * If `pageRange` begins with a page of 2 or greater,
         * begin Pagination with Page 1
         */
        const pageRef = this.vcr.createComponent(PageComponent, { injector: this.injector });
        if (this.renderHref) {
          pageRef.instance.href = this.renderHref(1, this.paginator);
        }
        this.renderer.setAttribute(pageRef.location.nativeElement, 'key', 'page-1');
        pageRef.instance.index = 1;
        pageRef.instance.isActive = this.currentPage === 1;
        pageRef.instance.focusPage = this.subPageChange;
        pageRef.instance.onPageChange.subscribe((pageNumber) => this.pageChangeFromSubscription(pageNumber));
        this.pages.push(pageRef);

        /**
         * If `pageRange` doesn't equal 2, second Pagination element is Ellipses,
         * otherwise page count continues.
         */
        if (pageRange[0] !== 2) {
          const ellipsesRef = this.vcr.createComponent(EllipsesComponent, { injector: this.injector });
          this.renderer.setAttribute(ellipsesRef.location.nativeElement, 'key', 'ellipses-1');
          this.pages.push(ellipsesRef);
        }
      }

      pageRange.forEach((page) => {
        const pageRef = this.vcr.createComponent(PageComponent, { injector: this.injector });
        if (this.renderHref) {
          pageRef.instance.href = this.renderHref(page, this.paginator);
        }
        this.renderer.setAttribute(pageRef.location.nativeElement, 'key', 'page-' + page);
        pageRef.instance.index = page;
        pageRef.instance.isActive = this.currentPage === page;
        pageRef.instance.focusPage = this.subPageChange;
        pageRef.instance.ariaLabelPrefix = this.ariaLabelPrefix;
        pageRef.instance.onPageChange.subscribe((pageNumber) => this.pageChangeFromSubscription(pageNumber));

        this.pages.push(pageRef);
      });

      /**
       * Defines if/when the Ellipses component appears
       * at the end of the Pagination component -
       * as long as there are fewer than 7 pages.
       */
      if (this.currentPage! <= this.totalPages - 3 && this.totalPages > maxVisiblePages) {
        if (this.currentPage! < this.totalPages - 3) {
          const ellipsesRef2 = this.vcr.createComponent(EllipsesComponent, { injector: this.injector });
          this.renderer.setAttribute(ellipsesRef2.location.nativeElement, 'key', 'ellipses-2');
          this.pages.push(ellipsesRef2);
        }

        const pageRef = this.vcr.createComponent(PageComponent, { injector: this.injector });
        if (this.renderHref) {
          pageRef.instance.href = this.renderHref(this.totalPages, this.paginator);
        }
        this.renderer.setAttribute(pageRef.location.nativeElement, 'key', 'page-' + this.totalPages);
        pageRef.instance.index = this.totalPages;
        pageRef.instance.isActive = this.currentPage === this.totalPages;
        pageRef.instance.focusPage = this.subPageChange;
        pageRef.instance.onPageChange.subscribe((pageNumber) => this.pageChangeFromSubscription(pageNumber));
        this.pages.push(pageRef);
      }
    }
  }

  /**
   * render pages on DOM
   */
  renderPages() {
    this.pages.forEach((page) => {
      this.renderer.appendChild(this.ulElem?.nativeElement, page.location.nativeElement);
    });
  }

  pageChange = (page: number, ariaLabelPrefix: any) => (evt: any) => {
    if (this.onPageChange) {
      this.subPageChange = false;
      this.onPageChange(evt, page, this.paginator);
      this.emitScreenReaderMessage(ariaLabelPrefix, page)

    }
  }

  /**
   * Function to emit a message for screen readers
   */
  emitScreenReaderMessage(ariaLabelPrefix: any, currentPage: any ) {
    let screenReaderElement : HTMLElement | null = document?.getElementById('screenReaderMessage');
    screenReaderElement!.textContent  = ariaLabelPrefix ? 'current page ' + currentPage + ' for ' + ariaLabelPrefix : 'current page ' + currentPage;
}

  pageChangeFromSubscription(page: number, evt?: any) {
    if (this.onPageChange) {
      this.subPageChange = true;
      this.onPageChange(evt, page, this.paginator);
    }
  }

  paginationBuilder(page: number, pages: number): number[] {
    this.paginationRange = [];

    let start = page - overflow;
    let end = page + overflow;

    const availableSlots = maxVisiblePages - 2;

    /**
     * If the current page is < `maxVisiblePages`,
     * add 1 - 5 pages.
     */
    if (page < availableSlots) {
      start = 1;
      end = availableSlots;
    }

    /**
     * If the current page equals `pages` - 1,
     * make sure `start` begins one page earlier.
     */
    if (page === pages - 2) {
      start -= 1;
      end += 1;
    }

    /**
     * If `end` page is two from the end,
     * make sure the last page shows instead of ellipsis.
     */
    if (end === pages - 2) {
      end += 1;
    }

    /**
     * If `end` > `pages`,
     * add last pages to `paginationRange[]`.
     */
    if (end >= pages) {
      start = pages - (availableSlots - 1);
      end = pages;
    }

    /**
     * If `pages` is 5 or fewer,
     * all pages added to `paginationRange[]`
     */
    if (pages <= maxVisiblePages) {
      start = 1;
      end = pages;
    }

    for (let i = start; i <= end; i++) {
      this.paginationRange.push(i);
    }

    return this.paginationRange;
  }

}
