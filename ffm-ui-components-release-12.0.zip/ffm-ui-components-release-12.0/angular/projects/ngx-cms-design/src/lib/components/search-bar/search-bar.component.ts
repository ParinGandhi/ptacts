import {
  TextFieldDefaultValue,
  TextFieldSize,
  TextFieldValue,
} from '../text-field/text-field.component';
import {
  TextInputComponent,
  NOOP_VALUE_ACCESSOR
} from '../text-field/text-input.component';
import { NgControl } from '@angular/forms';
import {
  Component,
  OnInit,
  ViewChild,
  TemplateRef,
  Self,
  Optional,
  Input,
  ChangeDetectorRef,
  ViewEncapsulation,
} from '@angular/core';
import { uniqueId } from 'lodash';
import classNames from 'classnames';

export interface SearchBarItems {
  /**
   * Unique identifier for this item
   */
  id?: string;
  /**
   * Displayed value of the item. May alternatively provide a `children` value
   */
  name?: string;
  /**
   * Custom React node as an alternative to a string-only `name`
   */
  children?: any;
  /**
   * Additional classes to be added to the root element.
   * Useful for adding utility classes.
   */
  className?: string;
  /**
   * Whether this item should be counted as one of the results for the purpose of announcing the
   * result count to screen readers
   */
  isResult?: boolean;
}

type PropsNotPassedToDownshift =
  | 'ariaClearLabel'
  | 'clearInputText'
  | 'items'
  | 'label'
  | 'loading'
  | 'children'
  | 'className'
  | 'clearInputOnBlur'
  | 'clearSearchButton';

export interface SearchBarProps {
  /**
   * Screenreader-specific label for the Clear search `<button>`. Intended to provide a longer, more descriptive explanation of the button's behavior.
   */
  ariaClearLabel?: string;
  /**
   * Control the `TextField` autocomplete attribute. Defaults to "off" to support accessibility. [Read more.](https://developer.mozilla.org/en-US/docs/Web/Security/Securing_your_site/Turning_off_form_autocompletion)
   */
  autoCompleteLabel?: string;
  /**
   * Must contain a `TextField` component
   */
  children: any;
  /**
   * Additional classes to be added to the root element.
   * Useful for adding utility classes.
   */
  className?: string;
  /**
   * When set to `false`, do not clear the input when the input element loses focus.
   */
  clearInputOnBlur?: boolean;
  /**
   * Text rendered on the page if `clearInput` prop is passed. Default is "Clear search".
   */
  clearInputText?: any;
  /**
   * Removes the Clear search button when set to `false`
   */
  clearSearchButton?: boolean;
  /**
   * Used to focus child `TextField` on `componentDidMount()`
   */
  focusTrigger?: boolean;
  /**
   * A unique id to be passed to the child `TextField`. If no id is passed as a prop,
   * the `Autocomplete` component will auto-generate one. This prop was provided in cases
   * where an id might need to be passed to multiple components, such as the `htmlFor`
   * attribute on a label and the id of an input.
   */
  id?: string;
  /**
   * Access a reference to the child `TextField`'s `input` element
   */
  inputRef?: (...args: any[]) => any;
  /**
   * Array of objects used to populate the suggestion list that appears below the input as users type. This array of objects is intended for an async data callback, and should conform to the prescribed shape to avoid errors.
   */
  items?: SearchBarItems[];
  /**
   * Adds a heading to the top of the autocomplete list. This can be used to convey to the user that they're required to select an option from the autocomplete list.
   */
  label?: any;
  /**
   * A unique `id` to be used on the child `TextField` label tag
   */
  labelId?: string;
  /**
   * Can be called when the `items` array is being fetched remotely, or will be delayed for more than 1-2 seconds.
   */
  loading?: boolean;
  /**
   * Message users will see when the `loading` prop is passed to `Autocomplete`.
   */
  loadingMessage?: any;
  /**
   * Message users will see when the `items` array returns empty and the `loading` prop is passed to `<Autocomplete />`.
   */
  noResultsMessage?: any;
  /**
   * Called when the user selects an item and the selected item has changed. Called with the item that was selected and the new state. [Read more on downshift docs.](https://github.com/paypal/downshift#onchange)
   */
  onChange?: (...args: any[]) => any;
}

export type SearchBarVariation = 'success' | 'header';

@Component({
  selector: 'cms-searchbar',
  templateUrl: './search-bar.component.html',
  styleUrls: ['./search-bar.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class SearchBarComponent implements OnInit {
  @Input() ariaClearLabel?: string = 'Clear search to try again';
  @Input() autoCompleteLabel?: string = 'none';
  @Input() className?: string;
  @Input() clearInputBlur?: boolean = true;
  @Input() clearInputText?: any = 'Clear search';
  @Input() clearSearchButton?: boolean = false;
  @Input() focusTrigger?: boolean;
  @Input() id?: string;
  @Input() variation?: SearchBarVariation;
  @Input() buttonClassName?: string;
  @Input() buttonLabel?: string = 'Search';

  // TextField inputs
  @Input() inputLabel?: any;
  @Input() inputClassName?: string;
  @Input() name: string = '';
  @Input() numeric?: boolean;
  @Input() defaultValue?: TextFieldDefaultValue;
  @Input() disabled?: boolean;
  @Input() size?: TextFieldSize;
  @Input() type?: string = 'text';
  @Input() value?: TextFieldValue;
  @Input() placeholder?: string;
  @Input() onBlur?: (...args: any[]) => any;
  @Input() onChange?: (...args: any[]) => any;
  @Input() onFocus?: (...args: any[]) => any;
  @Input() onSearch?: (...args: any[]) => any;
  @Input() onInput?: (...args: any[]) => any;

  @ViewChild('root') rootTemplate?: TemplateRef<any>;
  @ViewChild('textInput') textInputComponent?: TextInputComponent;

  searchString = '';
  rootClasses = '';
  buttonClasses = '';
  inputClasses = '';
  variationClass?: string;

  constructor(
    @Self() @Optional() public ngControl: NgControl,
    public changeRef: ChangeDetectorRef
  ) {
    if (this.ngControl) {
      this.ngControl.valueAccessor = NOOP_VALUE_ACCESSOR;
    }
  }

  ngOnInit(): void {
    this.id = this.id || uniqueId('searchbar_');

    this.rootClasses = classNames(
      'ds-u-clearfix',
      'ds-c-searchbar',
      this.className
    );
    this.variationClass =
      this.variation && 'searchbar-button--' + this.variation;
    this.buttonClasses = classNames(
      'searchbar-button',
      this.variationClass,
      this.buttonClassName
    );
    this.inputClasses = classNames('searchbar-input', this.inputClassName);
  }

  ngAfterContentInit(): void {
    this.changeRef.detectChanges();
  }

  /**
   * Input methods
   */

  handleChange = (evt: any) => {
    this.searchString = evt.target.value;
    if (this.ngControl) {
      this.ngControl.control?.markAsDirty();
    }
    if (this.onChange) {
      this.onChange(evt);
    }
  };

  handleBlur = (evt: any) => {
    if (this.onBlur) {
      this.onBlur(evt);
    }
  };

  handleInput = (evt: any) => {
    if (this.onInput) {
      this.onInput(evt);
    }
  };

  handleFocus = (evt: any) => {
    if (this.onFocus) {
      this.onFocus(evt);
    }
  };

  handleEnterKey = (evt: any) => {
    if (this.onSearch) {
      this.onSearch(this.searchString);
    }
  };

  /**
   *
   * Search button methods
   */

  searchButtonHandler = (evt: any) => {
    if (this.onSearch) {
      this.onSearch(this.searchString);
    }
  };

  /**
   * Clears search bar text field
   */
  clearTextField() {
    this.value = '';
    this.searchString = '';
    if (this.textInputComponent?.inputRoot) {
      this.textInputComponent.inputRoot.nativeElement.value = '';
    }
  }
}
