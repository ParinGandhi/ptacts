import { Component, Input, OnInit } from '@angular/core';
import classNames from 'classnames';
import * as _ from 'lodash';

export interface SvgIconProps {
  /**
   * Describes the value of the `aria-hidden` attribute on the SVG. Defaulted to true with the assumption that most icons are decorative.
   * If the icon does not have any associated label text, set this to `false` and ensure a `title` is provided for improved accessibility.
   */
  ariaHidden?: boolean;
  /**
   * Additional CSS classes to be added to the svg element
   */
  className?: string;
  /**
   * Long-text description of any SVG. Use for complex icons, otherwise `title` prop will suffice.
   */
  description?: string;
  /**
   * A custom `id` attribute for the SVG
   */
  id?: string;
  /**
   * If `true` sets inverse fill color.
   */
  inversed?: boolean;
  /**
   * The descriptive name for the SVG icon
   */
  title: string;
  /**
   * A string describing the viewbox of the SVG.
   *
   * It is recommended that the icon is centered and fill up the default viewport size.
   * See [this blog post](https://webdesign.tutsplus.com/tutorials/svg-viewport-and-viewbox-for-beginners--cms-30844) for further explanation on viewBox and how to use it.
   */
  viewBox?: string;
}

// a type for icon components that makes the 'title' prop optional & removes 'children' from type
export type IconCommonProps = Partial<Omit<SvgIconProps, 'children'>>;

type OmitProps = 'className' | 'children' | 'id' | 'title' | 'viewBox';

@Component({
  selector: 'cms-svg-icon',
  template: `<svg
                [attr.aria-labelledby]="ariaLabelledBy"
                [attr.aria-hidden]="ariaHidden"
                [class]="svgClasses"
                [id]="iconId"
                focusable=false
                role="img"
                [attr.viewBox]="viewBox"
                xmlns="http://www.w3.org/2000/svg">
                  <title [id]="titleId">{{title}}</title>
                  <desc *ngIf="description" [id]="descriptionId">{{description}}</desc>
                  <ng-content></ng-content>
                </svg>
                `,
  styles: [`
            .horizontal-mirror-icon {
              transform: scale(-1, 1);
            }
            .vertical-mirror-icon {
              transform: scale(1, -1);
            }
            .ds-c-icon-color--success {
              color: #12890E;
            }`]
})
export class SvgIconComponent implements OnInit {

  @Input() ariaHidden?: boolean;
  @Input() className?: string;
  @Input() description?: string;
  @Input() id?: string;
  @Input() inversed?: boolean;
  @Input() title?: string;
  @Input() viewBox?: string;

  svgClasses?: string;
  iconId?: string;
  titleId?: string;
  descriptionId?: string;
  ariaLabelledBy?: string;

  constructor() {
      // This is intentional
  }

  ngOnInit(): void {
    if (this.ariaHidden == undefined) {
      this.ariaHidden = true;
    }
    this.inversed = this.inversed || false;
    this.svgClasses = classNames('ds-c-icon',
      { 'ds-c-icon--inverse': this.inversed }, this.className);
    this.iconId = this.id || _.uniqueId('icon-');
    this.titleId = this.iconId + '__title';
    this.descriptionId = this.iconId + '__desc';
    this.ariaLabelledBy = this.description ? this.titleId + ' ' + this.descriptionId : this.titleId;
  }
}
