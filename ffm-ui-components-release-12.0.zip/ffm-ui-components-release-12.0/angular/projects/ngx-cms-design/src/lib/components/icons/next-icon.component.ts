import { Component, Input, OnInit } from '@angular/core';
import classNames from 'classnames';

@Component({
  selector: 'cms-next-icon',
  template: `
  <cms-svg-icon [className]="iconCssClasses" [ariaHidden]="ariaHidden"
                [description]="description"
                [id]="id"
                [inversed]="inversed"
                [title]="title"
                [viewBox]="viewBox">
              <svg:path
                d="M16 6.667l-6.678 6.666H4.906L9.99 8H0V5.333h9.954L4.897 0h4.436z"
                fillRule="evenodd" />
            </cms-svg-icon>
            `,
  styles: []
})
export class NextIconComponent implements OnInit {

  @Input() ariaHidden?: boolean;
  @Input() className?: string;
  @Input() description?: string;
  @Input() id?: string;
  @Input() inversed?: boolean;
  @Input() title?: string = 'Next';
  @Input() viewBox?: string = '0 0 16 13';

  iconCssClasses?: string;

  constructor() {
      // This is intentional
  }

  ngOnInit(): void {
    this.iconCssClasses = classNames('ds-c-icon--next', this.className);
  }
}
