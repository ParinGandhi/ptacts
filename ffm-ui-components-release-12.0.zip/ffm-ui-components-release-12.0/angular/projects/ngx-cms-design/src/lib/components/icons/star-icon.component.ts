import { Component, Input, OnChanges, OnInit } from '@angular/core';
import classNames from 'classnames';

@Component({
  selector: 'cms-star-icon',
  template: `
  <cms-svg-icon [className]="iconCssClasses" [ariaHidden]="ariaHidden"
                [description]="description"
                [id]="id"
                [inversed]="inversed"
                [title]="title"
                [viewBox]="viewBox">
              <svg:path *ngIf="isFilled"
                d="M8.533 13.063l-5.274 2.69 1.008-5.699L0 6.017l5.896-.831L8.533 0l2.637 5.186 5.897.831-4.267 4.037 1.007 5.7z"
                fillRule="nonzero"
              />
              <svg:path *ngIf="!isFilled"
                className="ds-c-icon--star__outline"
                d="M13.14 14.852l-.88-4.976 3.709-3.508-5.126-.723-2.31-4.542-2.309 4.542-5.126.723 3.708 3.508-.88 4.976 4.607-2.35 4.607 2.35z"
                fillRule="nonzero"
                fill="none"
                stroke="currentColor"
                strokeWidth="1"
                style="stroke-width: initial"
              />
            </cms-svg-icon>
            `,
  styles: []
})
export class StarIconComponent implements OnChanges {

  @Input() ariaHidden?: boolean;
  @Input() className?: string;
  @Input() description?: string;
  @Input() id?: string;
  @Input() inversed?: boolean;
  @Input() title?: string = 'Star';
  @Input() viewBox?: string = '0 0 18 16';
  @Input() isFilled?: boolean = false;

  iconCssClasses?: string;

  constructor() {
      // This is intentional
  }

  ngOnChanges(): void {
    this.title = this.isFilled ? 'Star filled' : 'Star';
    this.iconCssClasses = classNames('ds-c-icon--star',
      {'ds-c-icon--star-filled': this.isFilled}, this.className);
  }
}
