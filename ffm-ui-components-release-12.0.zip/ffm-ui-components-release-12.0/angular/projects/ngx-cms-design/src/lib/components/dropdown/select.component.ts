import { Subscription } from 'rxjs';
import { NOOP_VALUE_ACCESSOR } from './../text-field/text-input.component';
import { NgControl } from '@angular/forms';
import {
  Component,
  Input,
  OnInit,
  AfterViewInit,
  ElementRef,
  Renderer2,
  ViewChild,
  Self,
  Optional,
  OnChanges,
  SimpleChanges,
  ViewEncapsulation,
  OnDestroy,
} from '@angular/core';
import classNames from 'classnames';
import * as _ from 'lodash';

export type SelectDefaultValue = number | string;
export interface SelectOptions {
  label: any;
  value: number | string;
  disabled?: boolean;
  ariaLabel?: string;
}
export type SelectSize = 'small' | 'medium';
export type SelectValue = number | string;
export type SelectErrorPlacement = 'top' | 'bottom';

@Component({
  selector: 'cms-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class SelectComponent implements OnInit, AfterViewInit, OnChanges, OnDestroy {
  /**
   * Adds `aria-label` attribute. When using `aria-label`, `label` should be empty string.
   */
  @Input() ariaLabel?: string;

  /**
   * Adds `aria-labelledby` attribute.
   */
  @Input() ariaLabelledby?: string;

  /**
   * Adds `aria-describedby` attribute.
   */
  @Input() ariaDescribedby?: string;

  /**
    * Adds `aria-requried` attribute.
    */
  @Input() ariaRequired?: boolean;

  /**
   * Sets the initial selected state. Use this for an uncontrolled component;
   * otherwise, use the `value` property.
   */
  @Input() defaultValue?: SelectDefaultValue;

  /**
   * Disables the entire field.
   */
  @Input() disabled?: boolean;

  /**
   * The ID of the error message applied to the Select field.
   */
  @Input() errorId?: string;
  @Input() errorMessage?: any;
  /**
   * Location of the error message relative to the field input
   */
  @Input() errorPlacement?: SelectErrorPlacement;

  /**
   * Additional classes to be added to the select element
   */
  @Input() fieldClassName?: string;

  /**
   * A unique ID to be used for the Select field.
   */
  @Input() id?: string;

  /**
   * The field's `name` attribute
   */
  @Input() inversed?: boolean;

  /**
   * The field's `name` attribute
   */
  @Input() name?: string;

  /**
   * The list of options to be rendered. Provide an empty list if using custom options via the `children` prop.
   */
  @Input() options?: SelectOptions[];

  @Input() onBlur?: (...args: any[]) => any;
  @Input() onChange?: (...args: any[]) => any;

  /**
   * If the component renders a select, set the max-width of the input either to `'small'` or `'medium'`.
   */
  @Input() size?: SelectSize;

  /**
   * Sets the field's `value`. Use this in combination with `onChange`
   * for a controlled component; otherwise, set `defaultValue`.
   */
  @Input() value?: SelectValue;

  /**
   * Used in conjunction with formGroup to associate angular form
   * @param  {string;} formControlName?
   * @returns string
   */
  @Input() formControlName?: string;

  @ViewChild('dropdownSelectElement') selectElement?: ElementRef;

  classes?: string = '';
  content?: string;
  statusSub$?: Subscription;

  private selectAttributes = [
    'autofocus',
    'form_id',
    'multiple',
    'required',
    'number',
  ];

  constructor(
    @Self() @Optional() public ngControl: NgControl,
    private elementRef: ElementRef,
    private renderer: Renderer2
  ) {
    if (this.ngControl) {
      // Note: we provide the value accessor through here, instead of
      // the `providers` to avoid running into a circular import.
      // And we use NOOP_VALUE_ACCESSOR so TextField doesn't do anything with NgControl
      this.ngControl.valueAccessor = NOOP_VALUE_ACCESSOR;
    }
  }

  ngOnInit(): void {
    this.updateValue();
  }

  ngAfterViewInit(): void {
    this.updateSelect();

    if (this.ngControl) {
      this.statusSub$ = this.ngControl.statusChanges?.subscribe((status) => {
        setTimeout(() => {
          this.updateDisabled(status);
        });
      });
      this.ngControl.valueChanges?.subscribe((value) => {
        setTimeout(() => {
          this.updateValue();
        });
      });
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['errorMessage']) {
      this.classes = classNames(
        'ds-c-field',
        'custom-select',
        {
          'ds-c-field--error': this.errorMessage,
          'ds-c-field--inverse': this.inversed,
        },
        this.size && 'ds-c-field--' + this.size,
        this.fieldClassName
      );
    }
  }

  ngOnDestroy(): void {
      this.statusSub$?.unsubscribe();
  }

  updateSelect() {
    const attributes = this.elementRef.nativeElement.attributes;
    const attributesArray = Array.from(
      this.elementRef.nativeElement.attributes
    );
    var filteredAttributes: any[] = [];

    if (attributes['aria-invalid'] || this.errorMessage) {
      this.renderer.setAttribute(
        this.selectElement?.nativeElement,
        'aria-invalid',
        attributes['aria-invalid']
          ? attributes['aria-invalid']
          : !!this.errorMessage
      );
    } else {
      this.renderer.setAttribute(
        this.selectElement?.nativeElement,
        'aria-invalid',
        'false'
      );
    }

    if (this.errorMessage) {
      this.ariaDescribedby = this.errorId;
    }

    if (this.formControlName) {
      this.renderer.setAttribute(
        this.selectElement?.nativeElement,
        'formControlName',
        this.formControlName
      );
    }

    filteredAttributes = attributesArray.filter((e: any) => {
      return this.selectAttributes.some((item) => item == e.name);
    });

    filteredAttributes?.forEach((attr: any) => {
      this.renderer.setAttribute(
        this.selectElement?.nativeElement,
        attr.name,
        attr.value
      );
    });

    this.renderer.listen(this.selectElement?.nativeElement, 'change', (event) =>
      this.handleChange(event)
    );
    this.renderer.listen(this.selectElement?.nativeElement, 'blur', (event) =>
      this.handleBlur(event)
    );
  }

  handleChange(event: any): void {
    if (!this.disabled && this.ngControl) {
      this.ngControl.control?.setValue(event.target.value);
      this.ngControl.control?.markAsDirty();
    }
    if (!this.disabled && this.onChange) {
      this.onChange(event);
    }
  }

  handleBlur(event: any): void {
    if (!this.disabled && this.ngControl) {
      this.ngControl.control?.markAsTouched();
    }
    if (!this.disabled && this.onBlur) {
      this.onBlur(event);
    }
  }

  updateValue() {
    if (this.ngControl && this.ngControl.value && this.value !== this.ngControl.value) {
      this.value = this.ngControl.value;
    }
    else if (this.defaultValue && this.value !== this.defaultValue) {
      this.value = this.defaultValue;
    }
  }

  updateDisabled(status: string) {
    if (this.selectElement?.nativeElement) {
      if (status === 'DISABLED') {
        this.renderer.setAttribute(
          this.selectElement?.nativeElement,
          'disabled',
          ''
        );
      } else {
        this.renderer.removeAttribute(
          this.selectElement?.nativeElement,
          'disabled'
        );
      }
    }
  }
}
