import { Subscription } from 'rxjs';
import { ButtonComponent } from './../button/button.component';
import {
  FormControlComponent,
  FormControlPropKeys,
} from './../form-control/form-control.component';
import {
  TextInputComponent,
  NOOP_VALUE_ACCESSOR,
  InputAttributes,
} from './../text-field/text-input.component';
import { TextFieldSize } from './../text-field/text-field.component';
import { UntypedFormGroup, NgControl, AbstractControl } from '@angular/forms';
import { Datepicker } from 'vanillajs-datepicker';
import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  AfterViewInit,
  Input,
  Self,
  Optional,
  ChangeDetectorRef,
  AfterContentInit,
  Renderer2,
  OnDestroy,
  ViewEncapsulation,
  Inject,
  OnChanges,
  SimpleChanges,
} from '@angular/core';
import classNames from 'classnames';
import * as _ from 'lodash';
import { DOCUMENT, formatDate } from '@angular/common';

/**
 * Takes the string value from an input and returns a string
 * with appropriate date format masking applied concatenated
 * with the date hint text, MM/DD/YYYY.
 *
 * `valueOnly` defaults to false. If true, returns formatted
 * string without additional hint text.
 */
export type MaskFunction = (rawInput: string, valueOnly?: boolean) => string;

export const RE_DATE = /^(\d{1,2})[\D]?(\d{1,2})?[\D]?(\d{1,4})?/;
const digitPattern: RegExp = /^[0-9]$/;

export const DATE_MASK: MaskFunction = (rawInput = '', valueOnly = false) => {
  const match = RE_DATE.exec(rawInput);
  let formattedDate = '';
  if (match) {
    const [month, day, year] = match.slice(1);
    formattedDate = [
      // We treat all non-numeric characters as a delimiter. If they're using a
      // delimiter after a month or day, we interpret that as the user supplying
      // a single digit for month or day, which we will automatically pad for them.
      month && month.padStart(2, '0'),
      day && day.padStart(2, '0'),
      year,
    ]
      .filter((s) => s)
      .join('/');
  }
  if (valueOnly) {
    return formattedDate;
  }
  const hint = 'MM/DD/YYYY';
  const hintSub = hint.substring(formattedDate.length);
  return formattedDate + hintSub;
};

@Component({
  selector: 'cms-day-picker',
  templateUrl: './custom-day-picker.component.html',
  styleUrls: ['./custom-day-picker.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class CustomDayPickerComponent
  implements OnInit, AfterViewInit, AfterContentInit, OnDestroy, OnChanges
{
  @Input() className?: string;
  @Input() ariaLabel?: string =
    'Date picker input field enter date or Tab to button to open picker.';
  @Input() ariaLabelledby?: string;
  @Input() ariaRequired?: boolean;
  @Input() ariaDescription?: string =
    'Navigate days with arrow keys. Switch Month with Shift key + left or right arrow. Switch view with Shift or Ctrl key + up arrow.  Enter to select, Esc to exit, focus return to input field.';
  @Input() ariaDescribedby?: string;
  @Input() disabled?: boolean;
  @Input() errorMessage?: any;
  @Input() errorMessageClassName?: string;
  @Input() hint?: any;
  @Input() id?: string;
  @Input() errorPlacement?: 'top' | 'bottom';
  @Input() requirementLabel?: any;
  @Input() isRequired?: boolean;
  @Input() inversed?: boolean;
  @Input() label?: string;
  @Input() labelClassName?: string;
  @Input() buttonClassName?: string;
  @Input() fieldClassName?: string;
  @Input() labelId?: string;
  @Input() name?: string;
  @Input() onBlur?: (event: any) => any;
  @Input() onInputChange?: (event: any) => any;
  @Input() onChange?: (updatedValue: string, formattedValue: string) => any;
  @Input() value?: string;
  @Input() defaultMonth?: Date;
  @Input() fromDate?: Date;
  @Input() fromYear?: number;
  @Input() toDate?: Date;
  @Input() toMonth?: Date;
  @Input() toYear?: number;
  @Input() size?: TextFieldSize;
  @Input() formControlName?: string | number | null;
  @Input() parentGroup?: UntypedFormGroup;
  @Input() datePickerOptions?: any;

  @ViewChild('dateInput', { read: ElementRef }) dateInputRef?: ElementRef;
  @ViewChild('dateInput') dateInputComponent?: TextInputComponent;
  @ViewChild('formRef') formComponent?: FormControlComponent;
  @ViewChild('calendarButton') calendarButtonComponent?: ButtonComponent;
  @ViewChild('calendarButton', { read: ElementRef })
  calendarButtonRef?: ElementRef;
  @ViewChild('ariadiv', { read: ElementRef }) ariaDiv?: ElementRef;
  containerClasses = '';
  buttonClasses = '';
  updatedValue = '';
  currentView = 0;
  datePicker?: Datepicker;
  statusSub$?: Subscription;
  valueSub$?: Subscription;
  focusedDate?: HTMLElement;

  constructor(
    @Self() @Optional() public ngControl: NgControl,
    private elementRef: ElementRef,
    private cdr: ChangeDetectorRef,
    private renderer: Renderer2,
    @Inject(DOCUMENT) private document: Document
  ) {
    if (this.ngControl) {
      // Note: we provide the value accessor through here, instead of
      // the `providers` to avoid running into a circular import.
      // And we use NOOP_VALUE_ACCESSOR so TextField doesn't do anything with NgControl
      this.ngControl.valueAccessor = NOOP_VALUE_ACCESSOR;
    }
  }

  ngOnInit(): void {
    this.updateFormControl();
    this.updateInput();

    this.document.addEventListener('keydown', this.handleKeyDown);
    this.document.addEventListener('keyup', this.handleKeyUp);

    this.buttonClasses = classNames(
      'ds-c-single-input-date-field__button',
      this.buttonClassName
    );
    let ngControl = this.ngControl;

    let defaultPickerOptions = {
      enableOnReadonly: false,
      showOnClick: false,
      showOnFocus: false,
      maxDate: '12/31/9999',
      format: {
        toValue(date: Date | string | number, format: any, locale: any) {
          let dateObject = new Date(date);
          if (dateObject) {
            return dateObject;
          }
          return null;
        },
        toDisplay(date: Date, format: any, locale: any) {
          let dateString = formatDate(date, 'MM/dd/yyyy', 'en-US');
          if (ngControl) {
            ngControl.control?.markAsDirty();
            ngControl.control?.markAsTouched();
          }
          return dateString;
        },
      },
      shortcutKeys: {
        nextButton: { key: 'ArrowRight', shiftKey: true },
        prevButton: { key: 'ArrowLeft', shiftKey: true },
        viewSwitch: { key: 'ArrowUp', shiftKey: true },
      },
    };
    this.datePickerOptions = {
      ...defaultPickerOptions,
      ...this.datePickerOptions,
    };

    this.ariaLabelledby = this.ariaLabelledby
      ? this.ariaLabelledby
      : this.formComponent?.labelId;

    this.ariaDescription =
      this.ariaDescription && !this.ariaDescribedby
        ? this.ariaDescription
        : undefined;

    setTimeout(() => {
      this.checkIfIsRequired();
    });
  }

  ngAfterViewInit(): void {
    this.datePicker = new Datepicker(
      this.dateInputComponent?.inputRoot?.nativeElement,
      this.datePickerOptions
    );

    // Setting aria-label for datepicker buttons
    document.getElementsByClassName(
      'button prev-button prev-btn'
    )[0].ariaLabel = 'Go to Previous Month';
    document.getElementsByClassName(
      'button next-button next-btn'
    )[0].ariaLabel = 'Go to Next Month';

    this.renderer.setAttribute(
      this.dateInputComponent?.inputRoot?.nativeElement,
      'autocomplete',
      'off'
    );

    // vanillajs-datepicker custom events: https://mymth.github.io/vanillajs-datepicker/#/api?id=events
    this.dateInputComponent?.inputRoot?.nativeElement.addEventListener(
      'changeDate',
      this.handlePickerChange
    );

    this.dateInputComponent?.inputRoot?.nativeElement.addEventListener(
      'changeView',
      this.handleViewChange
    );

    this.dateInputComponent?.inputRoot?.nativeElement.addEventListener(
      'hide',
      this.onHide
    );

    if (this.ngControl) {
      // set initial values
      if (this.dateInputComponent) {
        this.dateInputComponent.value = this.ngControl.control?.value;
      }
      if (this.dateInputRef?.nativeElement) {
        this.dateInputRef.nativeElement.value = this.ngControl.control?.value;
      }
      this.datePicker?.setDate(this.ngControl.control?.value);

      // Disabled state
      if (this.ngControl.status === 'DISABLED') {
        this.renderer.setAttribute(
          this.dateInputComponent?.inputRoot?.nativeElement,
          'disabled',
          ''
        );
        this.disabled = true;
      }

      this.statusSub$ = this.ngControl.statusChanges?.subscribe((status) => {
        setTimeout(() => {
          if (this.dateInputComponent?.inputRoot?.nativeElement) {
            if (status === 'DISABLED') {
              this.renderer.setAttribute(
                this.dateInputComponent?.inputRoot?.nativeElement,
                'disabled',
                ''
              );
              this.disabled = true;
            } else {
              this.renderer.removeAttribute(
                this.dateInputComponent?.inputRoot?.nativeElement,
                'disabled'
              );
              this.disabled = false;
            }
          }
        });
      });

      this.valueSub$ = this.ngControl.valueChanges?.subscribe((value) => {
        setTimeout(() => {
          this.value = value
        })
      })
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['datePickerOptions'] && this.datePicker) {
      this.datePickerOptions = {
        ...this.datePickerOptions,
        ...changes['datePickerOptions'].currentValue
      };
      this.datePicker.setOptions(this.datePickerOptions)
    }
  }

  /**
   * handle custom event when datepicker box is closed
   * @param event
   */
  onHide = (event: any)  => {
    setTimeout(() => {
      event.target.focus();
    },)
  }

  ngAfterContentInit(): void {
    this.cdr.detectChanges();
  }

  ngOnDestroy(): void {
    this.statusSub$?.unsubscribe();
    this.document.removeEventListener('keydown', this.handleKeyDown);
    this.document.removeEventListener('keyup', this.handleKeyUp);
  }

  updateFormControl() {
    const containerProps: any = _.pick(this, FormControlPropKeys);

    this.containerClasses = classNames(
      'ds-u-clearfix', // fixes issue where the label's margin is collapsed
      'ds-c-single-input-date-field',
      'ds-c-single-input-date-field--with-picker',
      this.className
    );

    if (this.formComponent) {
      Object.entries(containerProps).forEach(([key, value]) => {
        Object.assign(this.formComponent!, { [key]: value });
      });
    }
  }

  filteredAttributes: any[] = [];
  updateInput() {
    const InputOmitProps = [
      'vcr',
      'elementRef',
      'renderer',
      'injector',
      '__ngContext__',
      'inputOnlyProps',
      'containerProps',
      'value',
    ];
    const inputOnlyProps = _.omit(this, [
      ...FormControlPropKeys,
      ...InputOmitProps,
    ]);

    // pass attributes from Custom Day Picker
    const attributesArray = Array.from(
      this.elementRef.nativeElement.attributes
    );
    this.filteredAttributes = [];
    this.filteredAttributes = attributesArray.filter((e: any) => {
      return InputAttributes.some((item) => item == e.name);
    });

    if (this.dateInputComponent) {
      Object.entries(inputOnlyProps).forEach(([key, value]) => {
        Object.assign(this.dateInputComponent!, { [key]: value });
      });
    }
  }

  // Set up change handlers
  handleInputChange = (event: any) => {
    event.target.value = event.target.value.substring(0, 10);
    event.target.value = event.target.value
      .replace(/[^0-9/]/g, '')
      .replace(/(\..*)\./g, '$1');
    if (
      event.data &&
      digitPattern.test(event.data) &&
      event.target.value.length < 11
    ) {
      if (event.target.value.length == 2 || event.target.value.length == 5) {
        event.target.value = event.target.value.concat('/');
      }
    }
    if (this.ngControl) {
      this.ngControl.control?.markAsDirty();
    }

    if (this.onInputChange) {
      this.onInputChange(event);
    }
  };

  handleInputBlur = (event: any) => {
    if (this.ngControl) {
      this.ngControl.control?.markAsTouched();
    }
    if (this.onBlur) {
      this.onBlur(event);
    }
  };

  handlePickerChange = (event: CustomEvent) => {
    if (event?.detail?.date) {
      this.updatedValue = formatDate(event?.detail.date, 'MM/dd/yyyy', 'en-US');
    } else {
      this.updatedValue = '';
    }
    if (this.ngControl) {
      this.ngControl.control?.setValue(this.updatedValue);
      this.ngControl.control?.markAsDirty();
      this.ngControl.control?.markAsTouched();
    } else {
      this.renderer.setProperty(
        this.dateInputComponent?.inputRoot?.nativeElement,
        'value',
        this.updatedValue
      );
    }
    if (this.onChange) {
      this.onChange(this.updatedValue, DATE_MASK(this.updatedValue, true));
    }
  };

  handleViewChange = (event: CustomEvent) => {
    this.currentView = event?.detail?.viewId;

    if (this.currentView == 0) {
      this.renderer.setProperty(
        this.ariaDiv?.nativeElement,
        'innerHTML',
        'Days displayed'
      );
    } else if (this.currentView == 1) {
      this.renderer.setProperty(
        this.ariaDiv?.nativeElement,
        'innerHTML',
        'Months displayed'
      );
    } else if (this.currentView == 2) {
      this.renderer.setProperty(
        this.ariaDiv?.nativeElement,
        'innerHTML',
        'Years displayed'
      );
    } else if (this.currentView == 3) {
      this.renderer.setProperty(
        this.ariaDiv?.nativeElement,
        'innerHTML',
        'Decades displayed'
      );
    }
  };

  handleButton = (event: any) => {
    this.datePicker?.show();
  };

  handleKeyDown = (event: KeyboardEvent) => {
    if (this.datePicker?.active) {
      if (event.code === 'Enter') {
        this.cancelEvent(event);
      }
    }
  };

  handleKeyUp = (event: KeyboardEvent) => {
    if (this.datePicker?.active) {
      if (
        event.ctrlKey &&
        (event.code === 'ArrowUp' || event.code === 'ArrowDown')
      ) {
        if (event.code === 'ArrowUp') {
          if (this.currentView === this.datePicker.config.maxView) {
            return;
          }
          this.datePicker.picker.changeView(this.currentView + 1).render();
          this.cancelEvent(event);
          setTimeout(() => {
            this.datePicker?.exitEditMode({
              update: true,
              autohide: this.datePicker?.config.autohide,
            });
          });
        }
      } else if (this.currentView == 0) {
        if (
          event.code === 'ArrowUp' ||
          event.code === 'ArrowDown' ||
          event.code === 'ArrowLeft' ||
          event.code === 'ArrowRight'
        ) {
          this.focusedDate = this.datePicker?.pickerElement?.querySelectorAll(
            '.focused'
          )[0] as HTMLElement;

          if (this.focusedDate) {
            let timeStamp = Number(this.focusedDate.dataset['date']!);
            let date = new Date(timeStamp);
            this.renderer.setProperty(
              this.ariaDiv?.nativeElement,
              'innerHTML',
              '' +
                formatDate(date, 'EEEE, MMMM d, y', 'en-US') +
                ' To activate press Enter.'
            );
          }
        } else if (event.code === 'Enter') {
          this.cancelEvent(event);
          this.focusedDate = this.datePicker?.pickerElement?.querySelectorAll(
            '.selected'
          )[0] as HTMLElement;

          if (this.focusedDate) {
            let timeStamp = Number(this.focusedDate.dataset['date']!);
            let date = new Date(timeStamp);
            this.renderer.setProperty(
              this.ariaDiv?.nativeElement,
              'innerHTML',
              '' + formatDate(date, 'EEEE, MMMM d, y', 'en-US') + ' Selected'
            );
          }
        } else if (event.code === 'Escape' && this.focusedDate) {
          this.focusedDate = undefined;
          this.renderer.setProperty(
            this.ariaDiv?.nativeElement,
            'innerHTML',
            ''
          );
        }
      } else if (this.currentView == 1) {
        if (
          event.code === 'ArrowUp' ||
          event.code === 'ArrowDown' ||
          event.code === 'ArrowLeft' ||
          event.code === 'ArrowRight'
        ) {
          let focusedMonth =
            this.datePicker?.pickerElement?.querySelectorAll('.focused')[0];
          this.renderer.setProperty(
            this.ariaDiv?.nativeElement,
            'innerHTML',
            '' + focusedMonth?.innerHTML + ' To activate press Enter.'
          );
        }
      } else if (this.currentView == 2) {
        if (
          event.code === 'ArrowUp' ||
          event.code === 'ArrowDown' ||
          event.code === 'ArrowLeft' ||
          event.code === 'ArrowRight'
        ) {
          let focusedYear =
            this.datePicker?.pickerElement?.querySelectorAll('.focused')[0];
          this.renderer.setProperty(
            this.ariaDiv?.nativeElement,
            'innerHTML',
            '' + focusedYear?.innerHTML + ' To activate press Enter.'
          );
        }
      } else if (this.currentView == 3) {
        if (
          event.code === 'ArrowUp' ||
          event.code === 'ArrowDown' ||
          event.code === 'ArrowLeft' ||
          event.code === 'ArrowRight'
        ) {
          let focusedDecade =
            this.datePicker?.pickerElement?.querySelectorAll('.focused')[0];
          this.renderer.setProperty(
            this.ariaDiv?.nativeElement,
            'innerHTML',
            '' + focusedDecade?.innerHTML + ' To activate press Enter.'
          );
        }
      }
    }
  };

  checkIfIsRequired() {
    if (this.isRequired === undefined && this.ngControl?.control?.validator) {
      let validator = this.ngControl.control.validator({} as AbstractControl);
      if (validator && validator['required']) {
        this.isRequired = true;
      } else {
        this.isRequired = false;
      }
    }
  }

  cancelEvent(event: Event) {
    event.preventDefault();
    event.stopPropagation();
  }
}
