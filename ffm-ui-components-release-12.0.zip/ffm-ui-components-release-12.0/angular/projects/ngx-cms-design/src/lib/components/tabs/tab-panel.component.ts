import { Component, OnInit, Input, ElementRef, ViewEncapsulation } from '@angular/core';
import classNames from 'classnames';
import { BadgeVariation } from '../badge/badge.component';

export interface TabPanelProps {
  children: any;
  /**
   * Additional classes to be added to the root element.
   */
  className?: string;
  /**
   * A unique `id`, to be used on the rendered panel element.
   */
  id: string;
  selected?: boolean;
  disabled?: boolean;
  /**
   * The associated tab's label. Only applicable when the panel is a
   * child of `Tabs`.
   */
  tab?: string;
  /**
   * Additional classes for the associated tab. Only applicable when the panel
   * is a child of `Tabs`.
   */
  tabClassName?: string;
  /**
   * The associated tab's `href`. Only applicable when the panel is a
   * child of `Tabs`.
   */
  tabHref?: string;
  // tabId is actually required, but it's not marked here since we generate
  // this id within the Tabs component. Otherwise React will yell at you even
  // though it's ultimately being passed in.
  /**
   * The `id` of the associated `Tab`. Used for the `aria-labelledby` attribute.
   */
  tabId?: string;
  /**
   * Used to display a badge with the tab label
   */
  tabBadgeLabel?: string;
  /**
   * Change the color of the badge
   */
  tabBadgeVariation?: BadgeVariation;
}

@Component({
  selector: 'cms-tab-panel',
  template: `<div
                [attr.aria-labelledby]="tabId"
                [attr.aria-hidden]="!selected"
                [attr.aria-disabled]="disabled"
                [class]="classes"
                [id]="id"
                [hidden]="!selected"
                role="tabpanel">
                <ng-content></ng-content>
            </div>`,
  styleUrls: ['./tab-panel.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class TabPanelComponent implements OnInit {

  @Input() className?: string;
  @Input() id?: string;
  @Input() selected?: boolean;
  @Input() disabled?: boolean;
  @Input() tab?: string;
  @Input() tabBadgeLabel?: string;
  @Input() tabBadgeVariation?: BadgeVariation;
  @Input() tabClassName?: string;
  @Input() tabHref?: string;
  @Input() tabId?: string;

  classes: string = '';
  displayName = 'TabPanel';
  key?: string;

  constructor(private elementRef: ElementRef) { }

  ngOnInit(): void {
    this.classes = classNames('ds-c-tabs__panel', this.className);
    this.selected = false;
    this.key = this.elementRef.nativeElement.attributes['key'];
  }
}
