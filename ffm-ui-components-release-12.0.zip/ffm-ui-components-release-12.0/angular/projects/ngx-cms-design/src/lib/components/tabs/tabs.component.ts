import { TabComponent } from './tab.component';
import { TabPanelComponent } from './tab-panel.component';
import {
  Component,
  Input,
  OnInit,
  ContentChildren,
  QueryList,
  AfterViewInit,
  ViewChildren,
  SecurityContext,
} from '@angular/core';
import classNames from 'classnames';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';


export interface TabsProps {
  /**
   * Sets the initial selected `TabPanel` state. If this isn't set, the first
   * `TabPanel` will be selected.
   */
  defaultSelectedId?: string;
  /**
   * A callback function that's invoked when the selected tab is changed.
   * `(selectedId, prevSelectedId) => void`
   */
  onChange?: (selectedId: string, prevSelectedId: string) => any;
  /**
   * Additional classes to be added to the component wrapping the tabs
   */
  tablistClassName?: string;
}

@Component({
  selector: 'cms-tabs',
  template: `<div>
    <div [class]="listClasses" role="tablist">
      <ng-container *ngFor="let panel of panelChildren as TabPanel">
        <cms-tab
          [className]="panel.tabClassName"
          [href]="panel.tabHref"
          [disabled]="panel.disabled"
          [id]="panelTabId(panel)"
          [attr.key]="panel.key"
          [onClick]="handleTabClick"
          [onKeyDown]="handleTabKeyDown"
          [panelId]="panel.id"
          [selected]="selectedId === panel.id"
          [label]="panel.tab"
          [badgeLabel]="panel.tabBadgeLabel"
          [badgeVariation]="panel.tabBadgeVariation"
          #tab
        ></cms-tab>
      </ng-container>
    </div>
    <ng-content></ng-content>
    <div class="no-enabled-tabs" *ngIf="!initialSelectedId">
      There is no content to display.
    </div>
  </div>`,
  styleUrls: ['./tabs.component.css'],
})
export class TabsComponent implements OnInit, AfterViewInit {
  @Input() defaultSelectedId?: string;
  @Input() onChange?: (selectedId: string, prevSelectedId: string) => any;
  @Input() tablistClassName?: string;
  @ContentChildren(TabPanelComponent)
  panelChildren?: QueryList<TabPanelComponent>;
  @ViewChildren(TabComponent) tabs?: QueryList<TabComponent>;

  LEFT_ARROW = 'ArrowLeft';
  RIGHT_ARROW = 'ArrowRight';
  selectedId?: string;
  listClasses?: string;
  initialSelectedId?: string;
  splitUrl!: string[];

  constructor(private sanitizer: DomSanitizer, private router: Router) {}

  ngOnInit(): void {
    this.listClasses = classNames('ds-c-tabs', this.tablistClassName);
    this.splitUrl = [
      ...new Set(this.router.routerState.snapshot.url.split('#')),
    ];
  }

  ngAfterViewInit(): void {
    const currentTab = this.splitUrl[1];
    this.initialSelectedId =
      this.defaultSelectedId || currentTab || this.getDefaultSelectedId();

    setTimeout(() => {
      this.selectedId = this.initialSelectedId;

      // assign tab id to each panel after being created
      this.tabs?.forEach((tab) => {
        const panel = this.panelChildren?.find(
          (panel) => panel.id === tab.panelId
        );
        if (panel) {
          panel.selected = this.selectedId === panel?.id;
          panel.tabId = tab.id;
        }
      });
    });
  }

  /**
   * Get the id of the first TabPanel child
   * @return {String} The id
   */
  getDefaultSelectedId = (): string | undefined => {
    if (this.panelChildren?.first && !this.panelChildren.first.disabled) {
      return this.panelChildren?.first.id;
    } else {
      let foundId: string | undefined;
      this.panelChildren?.forEach((panel) => {
        if (!foundId && panel && !panel.disabled) {
          panel.id && this.handleSelectedTabChange(panel.id);
          foundId = panel.id;
        }
      });
      return foundId;
    }
  };

  /**
   * Generate an id for a panel's associated tab if one doesn't yet exist
   * @param {Object} TabPanel component
   * @return {String} Tab ID
   */
  panelTabId = (panel: TabPanelComponent): string => {
    return panel.tabId || `ds-c-tabs__item--${panel.id}`;
  };

  /**
   * Update the URL in the browser without adding a new entry to the history.
   * @param {String} tabId - Absolute or relative URL
   */
  replaceState = (tabId: string): void => {
    if (window.history) {
      let parentUrl = this.splitUrl[0];
      let url = parentUrl + tabId;
      let sanitizedUrl = this.sanitizer.sanitize(SecurityContext.URL, url);
      window.history.replaceState({}, document.title, sanitizedUrl);
    }
  };

  handleSelectedTabChange = (newSelectedId: string): void => {
    if (this.onChange) {
      this.onChange(newSelectedId, this.selectedId!);
    }

    const tab = this.tabs?.find((tb) => tb.panelId === newSelectedId);
    this.replaceState(tab?.href!);
    this.selectedId = newSelectedId;
    tab?.setFocus();

    this.panelChildren?.forEach((panel) => {
      panel.selected = panel.id === newSelectedId;
    });
  };

  handleTabClick = (evt: any, panelId: string): void => {
    evt.preventDefault();
    this.handleSelectedTabChange(panelId);
  };

  handleTabKeyDown = (evt: any, panelId: string): void => {
    if (!this.tabs) return;
    let tabIndex = -1;
    this.tabs.forEach((tab, index) => {
      if (tab.panelId === panelId) {
        tabIndex = index;
      }
    });
    let target;
    let length = this.tabs.length;

    switch (evt.key) {
      case this.LEFT_ARROW:
        evt.preventDefault();
        if (tabIndex === 0) {
          const prevTab = this.tabs.last;
          target = prevTab.panelId;
        } else {
          const prevTab = this.tabs.toArray()[tabIndex - 1];
          target = prevTab.panelId;
        }
        this.handleSelectedTabChange(target!);
        break;
      case this.RIGHT_ARROW:
        evt.preventDefault();
        if (tabIndex === length - 1) {
          const currentTab = this.tabs.first;
          target = currentTab.panelId;
        } else {
          const nextTab = this.tabs.toArray()[tabIndex + 1];
          target = nextTab.panelId;
        }
        this.handleSelectedTabChange(target!);
        break;
      default:
        break;
    }
  };
}
