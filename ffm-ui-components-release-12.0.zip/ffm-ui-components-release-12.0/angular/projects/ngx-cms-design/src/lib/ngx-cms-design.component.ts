import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'ngx-cms-design',
  template: `<ng-content></ng-content>`,
  styleUrls: ['./assets/css/easy-table.css','./assets/css/index.css', './assets/css/ng-select.theme.css', './assets/css/datepicker.css'],
  encapsulation: ViewEncapsulation.None
})
export class CmsDesign {
}
