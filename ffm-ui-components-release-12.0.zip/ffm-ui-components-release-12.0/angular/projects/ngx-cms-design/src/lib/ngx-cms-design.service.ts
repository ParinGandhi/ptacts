import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CmsDesignService {

  constructor() {
      // This is intentional
  }

}
