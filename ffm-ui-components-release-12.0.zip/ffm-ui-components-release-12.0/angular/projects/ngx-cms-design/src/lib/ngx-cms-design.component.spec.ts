import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmsDesign } from './ngx-cms-design.component';

describe('NgxFfmStylingComponent', () => {
  let component: CmsDesign;
  let fixture: ComponentFixture<CmsDesign>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CmsDesign ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CmsDesign);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
