// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  debug: true,
  logLevel: 0,
  logWithDate: true,
  logRemote: false,
  logUri: '',
  bffUri: 'http://localhost:9999/bff',
  oauthUri: 'https://pm-test1m.insuranceoversight.cms.gov/oauth2/sign_out',
  logoutRedirectUri: 'https://test.idp.idm.cms.gov/login/signout',
  logoutRedirectFromUri: 'https://pm-test1m.insuranceoversight.cms.gov'
};

/*
  Remove oauth and logout variables to test backend logout api
*/

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
