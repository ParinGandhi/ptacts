export const environment = {
  production: true,
  debug: false,
  logLevel: 2,
  logWithDate: true,
  logRemote: false,
  logUri: '',
  bffUri: 'http://localhost:9999/bff',
  domain: 'http://localhost:4200',
  oktaIssuer: '',
  logoutRedirectUri: 'http://localhost:4200',
};
