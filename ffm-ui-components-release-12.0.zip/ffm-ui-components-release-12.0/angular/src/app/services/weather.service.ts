import { Injectable } from '@angular/core';
import { Response } from 'arch-ng-ui/lib/rest-client/response';
import { Get } from 'arch-ng-ui/lib/rest-client/rest-client';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class WeatherService {

  constructor() {
      // This is intentional
  }

  getDCWeather(): Promise<Response> {
    console.log('getDCWeather');
    return new Get("https://api.open-meteo.com/v1/forecast?latitude=38.95&longitude=-77.45&hourly=temperature_2m,relativehumidity_2m,rain&daily=weathercode,temperature_2m_max,temperature_2m_min&temperature_unit=fahrenheit&windspeed_unit=mph&precipitation_unit=inch&timezone=America%2FNew_York&past_days=5")
      .withBody({ "language": "en-US" })
      .execute();
  }
}
