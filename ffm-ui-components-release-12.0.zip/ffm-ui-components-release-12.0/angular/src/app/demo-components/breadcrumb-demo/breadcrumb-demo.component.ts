import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ffm-components-breadcrumb-demo',
  templateUrl: './breadcrumb-demo.component.html',
  styleUrls: ['./breadcrumb-demo.component.scss']
})
export class BreadcrumbDemoComponent implements OnInit {

  constructor() {
      // This is intentional
  }

  ngOnInit(): void {
      // This is intentional
  }
}
