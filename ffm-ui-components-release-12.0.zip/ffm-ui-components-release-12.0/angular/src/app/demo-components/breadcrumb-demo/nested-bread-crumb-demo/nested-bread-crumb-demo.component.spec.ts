import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NestedBreadCrumbDemoComponent } from './nested-bread-crumb-demo.component';

describe('NestedBreadCrumbDemoComponent', () => {
  let component: NestedBreadCrumbDemoComponent;
  let fixture: ComponentFixture<NestedBreadCrumbDemoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NestedBreadCrumbDemoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NestedBreadCrumbDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
