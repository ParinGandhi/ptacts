import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ffm-nested-bread-crumb-demo',
  templateUrl: './nested-bread-crumb-demo.component.html',
  styleUrls: ['./nested-bread-crumb-demo.component.scss']
})
export class NestedBreadCrumbDemoComponent implements OnInit {

  constructor() {
      // This is intentional
  }

  ngOnInit(): void {
      // This is intentional
  }

}
