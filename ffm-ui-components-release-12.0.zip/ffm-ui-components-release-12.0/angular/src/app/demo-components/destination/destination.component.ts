import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ffm-destination',
  templateUrl: './destination.component.html',
  styleUrls: ['./destination.component.scss']
})
export class DestinationComponent implements OnInit {

  constructor() {
      // This is intentional
  }

  ngOnInit(): void {
      // This is intentional
  }

}
