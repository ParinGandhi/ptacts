import { API, Config, DefaultConfig, Pagination } from 'ngx-easy-table';
import { WeatherService } from '../../services/weather.service';
import {
  Component,
  OnInit,
  TemplateRef,
  ViewChild,
  AfterViewInit,
  ChangeDetectorRef,
  OnDestroy,
  ViewEncapsulation,
} from '@angular/core';
import {
  AbstractControlOptions,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import {
  HeaderService,
  ValidationService,
  StateService,
  FooterService,
  FooterLinkGroup,
} from 'ngx-ffm-ui-components';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import {
  AlertProps,
  TableComponent,
  SearchBarComponent,
  BreadCrumb,
  AutocompleteItems,
  SelectOptions,
  ChoiceProps,
  DropdownMenuOptions,
  CustomDayPickerComponent
} from 'ngx-cms-design';
import * as _ from 'lodash';
import { CacheService, Cacheable } from 'arch-ng-ui/lib/cache';

@Component({
  selector: 'ffm-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class DemoComponent implements OnInit, AfterViewInit, OnDestroy {
  alerts: AlertProps[] = [
    {
      headingId: 'alert1',
      variation: 'error',
      heading: 'Test Heading',
      body: 'This is an <strong>error message</strong> that can be closed.',
      canClose: true,
    },
    {
      headingId: 'alert2',
      variation: 'success',
      body: 'This is a success message that can be closed.',
      canClose: true,
    },
    {
      headingId: 'alert3',
      body: 'This is an info message that can be closed.',
      canClose: true,
    },
  ];

  @ViewChild('imageTpl') imageTpl?: TemplateRef<any>;
  @ViewChild('linkTpl') linkTpl?: TemplateRef<any>;
  @ViewChild('dropDownTpl') dropDownTpl?: TemplateRef<any>;
  @ViewChild('detailsTpl') detailsTpl?: TemplateRef<any>;
  @ViewChild('myTable') myTable?: TableComponent;
  @ViewChild('pagTable') pagTable?: TableComponent;
  @ViewChild('searchBar') searchBar?: SearchBarComponent;

  breadCrumbAliases: BreadCrumb[] = [
    { url: 'bread-crumb-path-longer', alias: 'Its a me Mario!' },
    { url: 'another-long-name-to-test', alias: 'What about luigi?' },
    { url: 'dropdown-manu-item-test', alias: 'Dropdown Manu Item' },
    {
      url: 'another-dropdown-manu-item-test',
      alias: 'Another Dropdown Manu Item',
    },
    {
      url: 'second-dropdown-manu-item-test',
      alias: 'Second Dropdown Manu Item',
    },
    {
      url: 'another-second-dropdown-manu-item-test',
      alias: 'Another Second Dropdown Manu Item',
    },
    { url: 'sub - XXXX', alias: 'Sub - Aliased Parameter' },
  ];

  /**
   * Autocomplete items
   */
  autoItems: AutocompleteItems[] = [
    {
      id: 'kRf6c2fY',
      name: 'Cook County, IL',
    },
    {
      id: 'lYf5cGfM',
      name: 'Cook County, MD',
    },
    {
      id: 'mZfKcGf9',
      name: 'Cook County, TN',
    },
    {
      id: 'xFz6dLba',
      name: 'Cook County, AK',
    },
    {
      id: 'vTr5c99',
      name: 'Cook County, FL',
    },
    {
      id: 'ntY8Lha',
      name: 'Cook County, AL',
    },
    {
      id: 'uRe0Wqo',
      name: 'Cook County, WA',
    },
    {
      id: 'yUR7MWl',
      name: 'Cook County, OR',
    },
  ];
  /**
   * Form variables
   */
  testform!: UntypedFormGroup;
  formErrors: any = {};
  submitted = false;
  validationMessages = {
    Name: {
      required: 'Name is required.',
    },
    email: {
      required: 'Email is required.',
      pattern: 'Please provide valid Email address',
    },
    confirm: {
      required: 'Confirm is required',
    },
    privacy: {
      required: 'Privacy is required',
    },
    checkboxGroup: {
      notAllChecked: 'Please confirm both checkboxes',
    },
    hairColor: {
      required: 'Field is required.',
    },
    standaloneCheckbox: {
      required: 'Field is required.',
    },
    state: {
      required: 'State is required.',
    },
    FirstField: {
      required: 'Field is required.',
    },
    SecondField: {
      required: 'Field is required.',
      mismatch: 'Fields do not match',
    },
    dateGroup: {
      notValidDate: 'Please enter your date of birth',
    },
    Month: {
      required: 'Month is required',
    },
    Day: {
      required: 'Day is required',
    },
    Year: {
      required: 'Year is required',
    },
    dateField: {
      required: 'Date field is required',
    },
    favoriteCity: {
      required: 'Favorite city is required',
    },
    favoriteStates: {
      required: 'Favorite states are required',
    },
    favoriteStates_oneway: {
      required: 'Favorite states are required',
    },
    datePickerField: {
      required: 'Date picker field is required',
    },
  };

  /**
   * Dropdown variables
   */
  selectValue = 4;
  standAlone = new UntypedFormControl('Stand Alone text');
  selectOptions: SelectOptions[] = [
    {
      label: 'Text 1',
      value: 1,
    },
    {
      label: 'Text 2',
      value: 2,
    },
    {
      label: 'Text 3',
      value: 3,
    },
    {
      label: 'Text 4',
      value: 4,
    },
    {
      label: 'Text 5',
      value: 5,
    },
  ];

  paginationOptions: SelectOptions[] = [
    {
      label: '5',
      value: 5,
      ariaLabel: 'Show 5 results per page for Demo',
    },
    {
      label: '10',
      value: 10,
      ariaLabel: 'Show 10 results per page for Demo',
    },
    {
      label: '25',
      value: 25,
      ariaLabel: 'Show 25 results per page for Demo',
    },
    {
      label: '50',
      value: 50,
      ariaLabel: 'Show 50 results per page for Demo',
    },
    {
      label: '100',
      value: 100,
      ariaLabel: 'Show 100 results per page for Demo',
    },
  ];

  stateOptions: SelectOptions[] = [
    { label: 'Select State', value: '' },
    { label: 'Alabama', value: 'AL' },
    { label: 'Alaska', value: 'AK' },
    { label: 'Arizona', value: 'AZ', disabled: true },
    {
      label:
        'Arkansas a much longer label because I need to test that multi-select label value',
      value: 'AR',
    },
    { label: 'California', value: 'CA' },
    { label: 'Colorado', value: 'CO' },
    { label: 'Connecticut', value: 'CT' },
    { label: 'Delaware', value: 'DE' },
    { label: 'District of Columbia', value: 'DC' },
    { label: 'Florida', value: 'FL' },
    { label: 'Georgia', value: 'GA' },
    { label: 'Hawaii', value: 'HI' },
    { label: 'Idaho', value: 'ID' },
    { label: 'Illinois', value: 'IL' },
    { label: 'Indiana', value: 'IN' },
    { label: 'Iowa', value: 'IA' },
    { label: 'Kansa', value: 'KS' },
    { label: 'Kentucky', value: 'KY' },
    { label: 'Lousiana', value: 'LA' },
    { label: 'Maine', value: 'ME' },
    { label: 'Maryland', value: 'MD' },
    { label: 'Massachusetts', value: 'MA' },
    { label: 'Michigan', value: 'MI' },
    { label: 'Minnesota', value: 'MN' },
    { label: 'Mississippi', value: 'MS' },
    { label: 'Missouri', value: 'MO' },
    { label: 'Montana', value: 'MT' },
    { label: 'Nebraska', value: 'NE' },
    { label: 'Nevada', value: 'NV' },
    { label: 'New Hampshire', value: 'NH' },
    { label: 'New Jersey', value: 'NJ' },
    { label: 'New Mexico', value: 'NM' },
    { label: 'New York', value: 'NY' },
    { label: 'North Carolina', value: 'NC' },
    { label: 'North Dakota', value: 'ND' },
    { label: 'Ohio', value: 'OH' },
    { label: 'Oklahoma', value: 'OK' },
    { label: 'Oregon', value: 'OR' },
    { label: 'Pennsylvania', value: 'PA' },
    { label: 'Rhode Island', value: 'RI' },
    { label: 'South Carolina', value: 'SC' },
    { label: 'South Dakota', value: 'SD' },
    { label: 'Tennessee', value: 'TN' },
    { label: 'Texas', value: 'TX' },
    { label: 'Utah', value: 'UT' },
    { label: 'Vermont', value: 'VT' },
    { label: 'Virginia', value: 'VA' },
    { label: 'Washington', value: 'WA' },
    { label: 'West Virginia', value: 'WV' },
    { label: 'Wisconsin', value: 'WI' },
    { label: 'Wyoming', value: 'WY' },
  ];

  checkOptions: ChoiceProps[] = [
    { label: 'Confirmed Receipt', value: 'true', formControlName: 'confirm' },
    { label: 'Read Privacy', value: 'true', formControlName: 'privacy' },
  ];

  radioOptions: ChoiceProps[] = [
    { label: 'Black', value: 'black', formControlName: 'hairColor' },
    { label: 'Brown', value: 'brown', formControlName: 'hairColor' },
    { label: 'Blonde', value: 'blonde', formControlName: 'hairColor' },
    { label: 'Red', value: 'red', formControlName: 'hairColor' },
  ];

  largeContentOptions: SelectOptions[] = [
    { label: 'Select', value: '' },
    {
      label:
        '25000052: The URL does not provide information regarding whether an enrollee may have financial liability for out-of-network services',
      value: '',
    },
    {
      label:
        '25000052: The URL does not provide information regarding whether an enrollee may have financial liability for out-of-network services',
      value: '',
    },
    {
      label:
        '25000052: The URL does not provide information regarding whether an enrollee may have financial liability for out-of-network services',
      value: '',
    },
    { label: 'small content', value: '' },
    {
      label:
        '25000052: The URL does not provide information regarding whether an enrollee may have financial liability for out-of-network services',
      value: '',
    },
  ];

  /**
   * Table variables
   */
  tableData = [
    {
      status: '',
      phone: '+1 (934) 551-2224',
      age: 20,
      address: { street: 'North street', number: 12 },
      company: 'ZILLANET',
      companyUrl: 'http://www.google.com',
      name: 'Valentine Webb',
      picker: 3,
    },
    {
      status: 'warn',
      phone: '+1 (948) 460-3627',
      age: 31,
      address: { street: 'South street', number: 12 },
      company: 'KNOWLYSIS',
      companyUrl: 'http://www.google.com',
      name: 'Heidi Duncan',
      picker: 1,
    },
    {
      status: 'warn',
      phone: '+1 (934) 551-2224',
      age: 18,
      address: { street: 'North street', number: 12 },
      company: 'ZILLANET',
      companyUrl: 'http://www.google.com',
      name: 'John Smith',
      picker: 4,
    },
    {
      status: '',
      phone: '+1 (948) 460-3627',
      age: 35,
      address: { street: 'South street', number: 12 },
      company: 'KNOWLYSIS',
      companyUrl: 'http://www.google.com',
      name: 'William Shakespeare',
      picker: 2,
    },
    {
      status: '',
      phone: '+1 (934) 551-2224',
      age: 22,
      address: { street: 'North street', number: 12 },
      company: 'ZILLANET',
      companyUrl: 'http://www.google.com',
      name: 'Valentine Webb',
      picker: 3,
    },
    {
      status: 'alert',
      phone: '+1 (948) 460-3627',
      age: 31,
      address: { street: 'South street', number: 12 },
      company: 'KNOWLYSIS',
      companyUrl: 'http://www.google.com',
      name: 'Heidi Duncan',
      picker: 1,
    },
    {
      status: 'warn',
      phone: '+1 (934) 551-2224',
      age: 16,
      address: { street: 'North street', number: 12 },
      company: 'ZILLANET',
      companyUrl: 'http://www.google.com',
      name: 'John Smith',
      pciker: 4,
    },
    {
      status: 'alert',
      phone: '+1 (948) 460-3627',
      age: 33,
      address: { street: 'South street', number: 12 },
      company: 'KNOWLYSIS',
      companyUrl: 'http://www.google.com',
      name: 'William Shakespeare',
      picker: 2,
    },
  ];

  capLab = 'Caption';

  pagination: Pagination = {
    limit: 5,
    offset: 1,
    count: 10,
  };
  paginationTableData = [
    {
      status2: '',
      phone2: '+1 (934) 551-2224',
      age2: 20,
      address2: { street: 'North street', number: 12 },
      company2: 'ZILLANET',
      companyUrl2: 'http://www.google.com',
      name2: 'Valentine Webb',
      picker2: 3,
    },
    {
      status2: 'warn',
      phone2: '+1 (948) 460-3627',
      age2: 31,
      address2: { street: 'South street', number: 12 },
      company2: 'KNOWLYSIS',
      companyUrl2: 'http://www.google.com',
      name2: 'Heidi Duncan',
      picker2: 1,
    },
    {
      status2: 'warn',
      phone2: '+1 (934) 551-2224',
      age2: 18,
      address2: { street: 'North street', number: 12 },
      company2: 'ZILLANET',
      companyUrl2: 'http://www.google.com',
      name2: 'John Smith',
      picker2: 4,
    },
    {
      status2: '',
      phone2: '+1 (948) 460-3627',
      age2: 35,
      address2: { street: 'South street', number: 12 },
      company2: 'KNOWLYSIS',
      companyUrl2: 'http://www.google.com',
      name2: 'William Shakespeare',
      picker2: 2,
    },
    {
      status2: '',
      phone2: '+1 (934) 551-2224',
      age2: 22,
      address2: { street: 'North street', number: 12 },
      company2: 'ZILLANET',
      companyUrl2: 'http://www.google.com',
      name2: 'Valentine Webb',
      picker2: 3,
    },
    {
      status2: 'alert',
      phone2: '+1 (948) 460-3627',
      age2: 31,
      address2: { street: 'South street', number: 12 },
      company2: 'KNOWLYSIS',
      companyUrl2: 'http://www.google.com',
      name2: 'Heidi Duncan',
      picker2: 1,
    },
    {
      status2: 'warn',
      phone2: '+1 (934) 551-2224',
      age2: 16,
      address2: { street: 'North street', number: 12 },
      company2: 'ZILLANET',
      companyUrl2: 'http://www.google.com',
      name2: 'John Smith',
      pciker: 4,
    },
    {
      status2: 'alert',
      phone2: '+1 (948) 460-3627',
      age2: 33,
      address2: { street: 'South street', number: 12 },
      company2: 'KNOWLYSIS',
      companyUrl2: 'http://www.google.com',
      name2: 'William Shakespeare',
      picker2: 2,
    },
    {
      status2: '',
      phone2: '+1 (934) 551-2224',
      age2: 20,
      address2: { street: 'North street', number: 12 },
      company2: 'ZILLANET',
      companyUrl2: 'http://www.google.com',
      name2: 'Valentine Webb',
      picker2: 3,
    },
    {
      status2: 'warn',
      phone2: '+1 (948) 460-3627',
      age2: 31,
      address2: { street: 'South street', number: 12 },
      company2: 'KNOWLYSIS',
      companyUrl2: 'http://www.google.com',
      name2: 'Heidi Duncan',
      picker2: 1,
    },
    {
      status2: 'warn',
      phone2: '+1 (934) 551-2224',
      age2: 18,
      address2: { street: 'North street', number: 12 },
      company2: 'ZILLANET',
      companyUrl2: 'http://www.google.com',
      name2: 'John Smith',
      picker2: 4,
    },
    {
      status2: '',
      phone2: '+1 (948) 460-3627',
      age2: 35,
      address2: { street: 'South street', number: 12 },
      company2: 'KNOWLYSIS',
      companyUrl2: 'http://www.google.com',
      name2: 'William Shakespeare',
      picker2: 2,
    },
    {
      status2: '',
      phone2: '+1 (934) 551-2224',
      age2: 22,
      address2: { street: 'North street', number: 12 },
      company2: 'ZILLANET',
      companyUrl2: 'http://www.google.com',
      name2: 'Valentine Webb',
      picker2: 3,
    },
    {
      status2: 'alert',
      phone2: '+1 (948) 460-3627',
      age2: 31,
      address2: { street: 'South street', number: 12 },
      company2: 'KNOWLYSIS',
      companyUrl2: 'http://www.google.com',
      name2: 'Heidi Duncan',
      picker2: 1,
    },
    {
      status2: 'warn',
      phone2: '+1 (934) 551-2224',
      age2: 16,
      address2: { street: 'North street', number: 12 },
      company2: 'ZILLANET',
      companyUrl2: 'http://www.google.com',
      name2: 'John Smith',
      pciker: 4,
    },
    {
      status2: 'alert',
      phone2: '+1 (948) 460-3627',
      age2: 33,
      address2: { street: 'South street', number: 12 },
      company2: 'KNOWLYSIS',
      companyUrl2: 'http://www.google.com',
      name2: 'William Shakespeare',
      picker2: 2,
    },
    {
      status2: '',
      phone2: '+1 (934) 551-2224',
      age2: 20,
      address2: { street: 'North street', number: 12 },
      company2: 'ZILLANET',
      companyUrl2: 'http://www.google.com',
      name2: 'Valentine Webb',
      picker2: 3,
    },
    {
      status2: 'warn',
      phone2: '+1 (948) 460-3627',
      age2: 31,
      address2: { street: 'South street', number: 12 },
      company2: 'KNOWLYSIS',
      companyUrl2: 'http://www.google.com',
      name2: 'Heidi Duncan',
      picker2: 1,
    },
    {
      status2: 'warn',
      phone2: '+1 (934) 551-2224',
      age2: 18,
      address2: { street: 'North street', number: 12 },
      company2: 'ZILLANET',
      companyUrl2: 'http://www.google.com',
      name2: 'John Smith',
      picker2: 4,
    },
    {
      status2: '',
      phone2: '+1 (948) 460-3627',
      age2: 35,
      address2: { street: 'South street', number: 12 },
      company2: 'KNOWLYSIS',
      companyUrl2: 'http://www.google.com',
      name2: 'William Shakespeare',
      picker2: 2,
    },
    {
      status2: '',
      phone2: '+1 (934) 551-2224',
      age2: 22,
      address2: { street: 'North street', number: 12 },
      company2: 'ZILLANET',
      companyUrl2: 'http://www.google.com',
      name2: 'Valentine Webb',
      picker2: 3,
    },
    {
      status2: 'alert',
      phone2: '+1 (948) 460-3627',
      age2: 31,
      address2: { street: 'South street', number: 12 },
      company2: 'KNOWLYSIS',
      companyUrl2: 'http://www.google.com',
      name2: 'Heidi Duncan',
      picker2: 1,
    },
    {
      status2: 'warn',
      phone2: '+1 (934) 551-2224',
      age2: 16,
      address2: { street: 'North street', number: 12 },
      company2: 'ZILLANET',
      companyUrl2: 'http://www.google.com',
      name2: 'John Smith',
      pciker: 4,
    },
    {
      status2: 'alert',
      phone2: '+1 (948) 460-3627',
      age2: 33,
      address2: { street: 'South street', number: 12 },
      company2: 'KNOWLYSIS',
      companyUrl2: 'http://www.google.com',
      name2: 'William Shakespeare',
      picker2: 2,
    },
    {
      status2: 'warn',
      phone2: '+1 (934) 551-2224',
      age2: 18,
      address2: { street: 'North street', number: 12 },
      company2: 'ZILLANET',
      companyUrl2: 'http://www.google.com',
      name2: 'John Smith',
      picker2: 4,
    },
    {
      status2: '',
      phone2: '+1 (948) 460-3627',
      age2: 35,
      address2: { street: 'South street', number: 12 },
      company2: 'KNOWLYSIS',
      companyUrl2: 'http://www.google.com',
      name2: 'William Shakespeare',
      picker2: 2,
    },
    {
      status2: '',
      phone2: '+1 (934) 551-2224',
      age2: 22,
      address2: { street: 'North street', number: 12 },
      company2: 'ZILLANET',
      companyUrl2: 'http://www.google.com',
      name2: 'Valentine Webb',
      picker2: 3,
    },
    {
      status2: 'alert',
      phone2: '+1 (948) 460-3627',
      age2: 31,
      address2: { street: 'South street', number: 12 },
      company2: 'KNOWLYSIS',
      companyUrl2: 'http://www.google.com',
      name2: 'Heidi Duncan',
      picker2: 1,
    },
    {
      status2: 'warn',
      phone2: '+1 (934) 551-2224',
      age2: 16,
      address2: { street: 'North street', number: 12 },
      company2: 'ZILLANET',
      companyUrl2: 'http://www.google.com',
      name2: 'John Smith',
      pciker: 4,
    },
    {
      status2: 'alert',
      phone2: '+1 (948) 460-3627',
      age2: 33,
      address2: { street: 'South street', number: 12 },
      company2: 'KNOWLYSIS',
      companyUrl2: 'http://www.google.com',
      name2: 'William Shakespeare',
      picker2: 2,
    },
  ];

  tableColumns = [
    { key: 'status', title: 'Status', width: '10%' },
    { key: 'phone', title: 'Phone' },
    { key: 'age', title: 'Age' },
    { key: 'company', title: 'Company' },
    { key: 'name', title: 'Name' },
    { key: 'picker', title: 'Value' },
  ];

  pagTableColumns = [
    { key: 'status2', title: 'Status', width: '10%' },
    { key: 'phone2', title: 'Phone' },
    { key: 'age2', title: 'Age' },
    { key: 'company2', title: 'Company' },
    { key: 'name2', title: 'Name' },
    { key: 'picker2', title: 'Value' },
  ];

  tableConfig: Config = { ...DefaultConfig };
  pagTableConfig: Config = { ...DefaultConfig };
  pagTableConfig2: Config = { ...DefaultConfig, headerEnabled: false };
  columnTemplates: any[] = [];

  /**
   * Pagination variables
   */
  page = 1;
  totalPages = 1;

  /**
   * Top Cities
   * */
  topCities: AutocompleteItems[] = [
    {
      id: '1',
      name: 'Hong Kong, China',
    },
    {
      id: '2',
      name: 'Bangkok, Thailand',
    },
    {
      id: '3',
      name: 'Macau, China',
    },
    {
      id: '4',
      name: 'Singapore, Singapore',
    },
    {
      id: '5',
      name: 'London, England',
    },
    {
      id: '6',
      name: 'Paris, France',
    },
    {
      id: '7',
      name: 'Dubai, United Arab Emirates',
    },
    {
      id: '8',
      name: 'Delhi, India',
    },
    {
      id: '9',
      name: 'Istanbul, Turkey',
    },
    {
      id: '10',
      name: 'Kuala Lumpur, Malaysia',
    },
    {
      id: '11',
      name: 'New York City, USA',
    },
    {
      id: '12',
      name: 'Antalya, Turkey',
    },
    {
      id: '13',
      name: 'Mumbai, India',
    },
    {
      id: '14',
      name: 'Shenzhen, China',
    },
    {
      id: '15',
      name: 'Phuket, Thailand',
    },
    {
      id: '16',
      name: 'Tokyo, Japan',
    },
    {
      id: '17',
      name: 'Rome, Italy',
    },
    {
      id: '18',
      name: 'Agra, India',
    },
    {
      id: '19',
      name: 'Taipei, Taiwan',
    },
    {
      id: '20',
      name: 'Pattaya, Thailand',
    },
    {
      id: '21',
      name: 'Seville, Spain',
    },
  ];

  menuOptions: DropdownMenuOptions[] = [
    {
      label:
        'Menu Item 1 Menu Item 1 Menu Item 1 Menu Item 1 Menu Item 1Menu Item 1 Menu Item 1 Menu Item 1Menu Item 1Menu Item 1',
      value: 0,
      type: 'action',
    },
    { label: 'Menu Item 2', value: 1, type: 'action', disabled: true },
    { label: 'Menu Item 3', value: 2, type: 'action' },
    { label: 'Menu Item 3', value: 3, type: 'action' },
  ];

  data2: any;
  data2Sub$?: Subscription;
  menuHandlerSub$?: Subscription;
  signInSub$?: Subscription;

  //dateField: string = "";

  constructor(
    private formBuilder: UntypedFormBuilder,
    private weatherService: WeatherService,
    private cdr: ChangeDetectorRef,
    private validationService: ValidationService,
    public headerService: HeaderService,
    public stateService: StateService,
    public footerService: FooterService,
    private router: Router
  ) {
    headerService.title = 'CMS Design Components';
    headerService.setUserName('John Smith');
    headerService.routes = [
      {
        label: 'Home',
        route: '/demo',
        menuItems: [],
      },
      {
        label: 'Bread Crumb',
        route: '/bread-crumb-path-longer',
        menuItems: [],
      },
      {
        label: 'Dropdown Menu',
        menuItems: [
          {
            label: 'DropDown Manu item',
            route: '/dropdown-manu-item-test',
            description: 'DropDown Manu item description',
          },
          {
            label: 'Another DropDown Manu item',
            route: '/another-dropdown-manu-item-test',
            description: 'Another DropDown Manu item description',
          },
        ],
      },
      {
        label: 'Second Dropdown Menu',
        menuItems: [
          {
            label: 'Second DropDown Manu item',
            route: '/second-dropdown-manu-item-test',
            description: 'Second DropDown Manu item description',
          },
          {
            label: 'Another Second DropDown Manu item',
            route: '/another-second-dropdown-manu-item-test',
            description: 'Another Second DropDown Manu item description',
          },
        ],
      },
    ];

    let footerLinkGroup: FooterLinkGroup = {
      header: 'Additional Resources',
      links: [
        {
          label: 'Freedom of Informaction Act',
          url: 'http://www.cms.gov/About-CMS/Agency-Information/Aboutwebsite/FOIA.html',
        },
        {
          label: 'Inspector General',
          url: 'https://oig.hhs.gov/',
        },
        {
          label: 'No Fear Act',
          url: 'http://www.cms.gov/About-CMS/Agency-Information/Aboutwebsite/NoFearAct.html',
        },
        {
          label: 'Plain Writing',
          url: 'http://www.medicare.gov/about-us/plain-writing/plain-writing.html',
        },
        {
          label: 'USA.gov',
          url: 'http://www.usa.gov',
        },
        {
          label: 'Privacy Policy',
          url: 'https://cms.gov/privacy/',
        },
      ],
    };
    let links: FooterLinkGroup[] = [];
    links.push(footerLinkGroup);
    links.push(footerLinkGroup);
    links.push(footerLinkGroup);
    footerService.setFooterLinks(links);

    this.testform = this.formBuilder.group(
      {
        Name: ['sample text', Validators.required],
        email: [
          '',
          [
            Validators.required,
            Validators.pattern(this.validationService.regex.email),
          ],
        ],
        changingCheck: [true],
        checkboxGroup: this.formBuilder.group(
          {
            confirm: [true, Validators.requiredTrue],
            privacy: [false, Validators.requiredTrue],
          },
          {
            validator: this.validationService.requireCheckboxesToBeChecked(2),
          } as AbstractControlOptions
        ),
        hairColor: ['brown', Validators.required],
        standaloneCheckbox: [true, Validators.requiredTrue],
        state: ['', Validators.required],
        FirstField: ['', [Validators.required]],
        SecondField: ['', [Validators.required]],
        dateGroup: this.formBuilder.group(
          {
            Month: ['2', [Validators.required]],
            Day: ['28', [Validators.required]],
            Year: ['1980', [Validators.required]],
          },
          {
            validator: this.validationService.isAValidDate(),
          } as AbstractControlOptions
        ),
        dateField: ['01/01/2022', Validators.required],
        datePickerField: ['10/23/2017', Validators.required],
        favoriteCity: ['Seville, Spain', Validators.required],
        favoriteStates: [['AZ', 'MD'], Validators.required],
        favoriteStates_oneway: [['AZ', 'MD'], Validators.required],
      },
      {
        validator: this.validationService.matchItems(
          'FirstField',
          'SecondField'
        ),
      } as AbstractControlOptions
    );
  }

  ngOnInit(): void {
    // modifying default table config
    this.tableConfig.searchEnabled = false;
    this.tableConfig.checkboxes = true;

    this.pagTableConfig.searchEnabled = false;
    this.pagTableConfig.checkboxes = false;
    this.pagTableConfig.paginationEnabled = false;
    this.pagTableConfig.paginationRangeEnabled = false;
    this.pagTableConfig.threeWaySort = true;

    this.pagination = {
      limit: 10,
      offset: 1,
      count: -1,
    };

    // this.testform.valueChanges.subscribe((changes) => {
    //   console.log('changes: ', changes);
    // })
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.columnTemplates = [
        {
          key: 'status',
          position: 'body',
          template: this.imageTpl!,
        },
        {
          key: 'icon',
          position: 'body',
          template: this.imageTpl!,
        },
        {
          key: 'company',
          position: 'body',
          template: this.linkTpl!,
        },
        {
          key: 'picker',
          position: 'body',
          template: this.dropDownTpl!,
        },
      ];
    });

    this.pagination = {
      limit: 5,
      offset: this.page,
      count: this.paginationTableData.length,
    };

    this.totalPages = Math.ceil(
      this.paginationTableData.length / this.pagination.limit
    );
    this.cdr.detectChanges();
  }

  openGovBanner = () => {
    this.headerService.$bannerHidden.next(false);
  };

  closeGovBanner = () => {
    this.headerService.$bannerHidden.next(true);
  };

  ngOnDestroy(): void {
    this.data2Sub$?.unsubscribe();
  }

  public clicked = (event: any): void => {
    console.log('clicked in AppComponent: ', event);
    this.selectValue = 3;
  };

  public changed = (event: any): void => {
    console.log('changed in AppComponent: ', event);
    console.log(
      'dropdown id: ',
      event.target.id,
      ' value: ',
      event.target.value
    );
    this.selectValue = event.target.value;
  };

  public changedDropdownMenu = (event: any): void => {
    console.log('changed in AppComponent: ', event);
    if (event.value == 0) {
      this.menuOptions = [
        { label: 'Menu Item 1', value: 0, type: 'action', disabled: true },
        { label: 'Menu Item 2', value: 1, type: 'action' },
        { label: 'Menu Item 3', value: 2, type: 'action' },
        { label: 'Menu Item 4', value: 3, type: 'action' },
      ];
    } else if (event.value == 1) {
      this.menuOptions = [
        { label: 'Menu Item 1', value: 0, type: 'action' },
        { label: 'Menu Item 2', value: 1, type: 'action', disabled: true },
        { label: 'Menu Item 3', value: 2, type: 'action' },
        { label: 'Menu Item 4', value: 3, type: 'action' },
      ];
    } else if (event.value == 2) {
      this.menuOptions = [
        { label: 'Menu Item 1', value: 0, type: 'action' },
        { label: 'Menu Item 2', value: 1, type: 'action' },
        { label: 'Menu Item 3', value: 2, type: 'action', disabled: true },
        { label: 'Menu Item 4', value: 3, type: 'action' },
      ];
    } else if (event.value == 3) {
      this.menuOptions = [
        { label: 'Menu Item 1', value: 0, type: 'action' },
        { label: 'Menu Item 2', value: 1, type: 'action' },
        { label: 'Menu Item 3', value: 2, type: 'action' },
        { label: 'Menu Item 4', value: 3, type: 'action', disabled: true },
      ];
    }
  };

  public changedMulti = (event: any): void => {
    console.log('changed in AppComponent: ', event);
  };

  public textChanged = (event: any) => {
    console.log('text changed in AppComponent: ', event);
    this.standAlone.setValue(event.target.value);
  };

  public checkboxChanged = (choice: any, evt: any) => {
    console.log(
      'checkboxChanged in AppComponent: ',
      choice,
      ' checked: ',
      evt.target.checked
    );
  };

  public cardClicked = (event: any): void => {
    console.log('clicked in CardComponent: ', event);
  };

  public onTableSelect = (event: any, selected: Set<number>) => {
    console.log('table event: ', event);
  };

  onSubmit() {
    console.log('form: ', this.testform);
    if (this.testform.invalid) {
      console.error('Test form invalid');
      return;
    }

    this.submitted = true;
    console.log('Test form valid, submitted');
  }
  logValidationErrors = () => {
    this.formErrors = this.validationService.getValidationErrors(
      this.testform,
      this.validationMessages
    );
    console.log('formErrors: ', this.formErrors);
  };

  getDCWeather = (event: any) => {
    this.weatherService.getDCWeather().then((resp) => {
      console.log('DC Weather: ', resp.body);
      this.tableData = [
        {
          status: '',
          phone: resp.body.latitude,
          age: 20,
          address: { street: 'North street', number: 12 },
          company: 'UPDATED',
          companyUrl: 'https://www.google.com',
          name: resp.body.timezone,
          picker: 3,
        },
      ];
    });
  };

  changeTable = (event: any) => {
    this.tableData = [
      {
        status: '',
        phone: '+1 (123) 456-7891',
        age: 20,
        address: { street: 'North street', number: 12 },
        company: 'UPDATED',
        companyUrl: 'https://www.google.com',
        name: 'Valentine Webb',
        picker: 3,
      },
      {
        status: 'warn',
        phone: '+1 (123) 456-7891',
        age: 31,
        address: { street: 'South street', number: 12 },
        company: 'UPDATED',
        companyUrl: 'https://www.google.com',
        name: 'Heidi Duncan',
        picker: 1,
      },
    ];

    this.capLab = 'new caption';
  };

  changeColor = () => {
    this.myTable?.apiEvent(API.setCellClass, {
      row: 1,
      cell: 3,
      className: 'ds-u-fill--warn-lighter',
    });
  };

  pageRefFunc = (page: number, paginator?: number) => {
    return 'demo#' + page;
  };

  pageChange = (evt: any, page: number, paginator?: number) => {
    console.log('pageChange: ', page, ' paginator: ', paginator);
    // Added timeout so that href can call the pageRefFunc first before the currentPage is incremented
    setTimeout(() => {
      evt?.stopPropagation();
      this.page = page;
      this.pagination = {
        ...this.pagination,
        offset: page,
      };
    });
  };

  dateObject = {
    day: '10',
    month: '1',
    year: '2000',
  };
  dateChanged = (evt: any, date: any) => {
    console.log('date changed app component: ', evt, ' date: ', date);
    this.dateObject = date;
  };

  autoCompleteChanged = (evt: any) => {
    console.log('autocomplete changed in app compoenent: ', evt);
  };

  throwError = () => {
    throw Promise.reject({ message: 'Rejection in promise' });
  };

  onSearch = (evt: any) => {
    console.log('onSearch: ', evt);
  };

  onInput = (evt: any) => {
    console.log('onInput: ', evt);
  };

  clearSearch = (evt: any) => {
    this.searchBar?.clearTextField();
  };

  setData = () => {
    let test = {
      name: 'Lorem',
      body: 'Ipsum dolor est',
    };

    this.stateService.setData('test', test);
  };

  setData2 = () => {
    let test2 = {
      color: 'red',
      size: 'large',
    };

    this.stateService.setData('test2', test2);

    if (!this.data2Sub$) {
      this.data2Sub$ = this.stateService.dataSubject.subscribe({
        next: (result) => {
          this.data2 = result['test2'];
          console.log('dataSubj was updated: ', result);
        },
      });
    }
  };

  setData3 = () => {
    let test2 = {
      color: 'orange',
      size: 'large',
    };

    this.stateService.setData('test2', test2);
  };

  setData4 = () => {
    let test = {
      name: 'John Smith',
      body: 'This data has been changed ',
    };

    this.stateService.setData('test', test);
  };

  cacheButtonHandler = () => {
    this.cacheData()?.then((res) => {
      console.log('result from cached data: ', res);
    });
  };

  cacheEncryptedButtonHandler = () => {
    this.cacheDataEncrypted()?.then((res) => {
      console.log('result from encrypted cached data: ', res);
    });
  };

  @Cacheable<DemoComponent>(function () {
    return {
      storageType: CacheService.StorageType.Session,
      ttl: 3600,
      domain: 'app',
    };
  })
  async cacheData(): Promise<string> {
    return 'this is the result from cacheData method';
  }

  @Cacheable<DemoComponent>(function () {
    return {
      storageType: CacheService.StorageType.Session,
      ttl: 3600,
      domain: 'app',
      encryption: true,
    };
  })
  async cacheDataEncrypted(): Promise<string> {
    return 'this is the result from cacheData encrypted method';
  }

  clearData = () => {
    this.stateService.clearData();
  };

  setHairColor = () => {
    this.testform.get('hairColor')?.setValue('black');
    console.log('setHairColor: ', 'black');
  };

  setHairColorRed = () => {
    this.testform.get('hairColor')?.setValue('red');
    console.log('setHairColor: ', 'red');
  };

  logoutButtonHandler = () => {
    console.log('logout in demo component');
  };

  alertId?: string;

  addHeaderAlert = () => {
    //this.alertId = this.headerService.addAlert('Lorem Ipsum..', 'title', 'warn', 60000);
  };

  focusAlerts: AlertProps[] = [];
  addFocusAlert = () => {
    this.focusAlerts.push({
      headingId: _.uniqueId('focusAlert_'),
      variation: 'error',
      canClose: true,
      autoFocus: true,
      focusId: 'button#focusAlertButton',
      heading: 'Test Focus Heading',
      body: 'This is a focused error message that can be closed. Focus will move to button after closing.',
    });
  };

  removeHeaderAlert = () => {
    //this.headerService.removeAlert(this.alertId!);
  };

  goToBreadcrumb = () => {
    this.router.navigateByUrl('bread-crumb-path-id/XXXX/detail-view');
  };

  switchChoice = () => {
    this.testform.controls['changingCheck'].setValue(
      !this.testform.controls['changingCheck'].value
    );
  };

  addChoice = () => {
    this.radioOptions = [
      ...this.radioOptions,
      { label: 'Green', value: 'green', formControlName: 'hairColor' },
    ];
  };

  datePattern: RegExp = /^[0-9]{2}\/[0-9]{2}\/[0-9]{4}$/;

  singleDate: Date = new Date();

  errorMessage: string = '';

  validateAndSetDates = (value: any) => {
    if (value && this.datePattern.test(value)) {
      this.errorMessage = '';
      this.singleDate = new Date(value);
    } else {
      this.errorMessage = 'Date Invalid';
      this.singleDate = new Date(0);
    }
    console.log(this.singleDate.toString());
  };

  disableStateDropdown = () => {
    console.log('disable state dropdown in form');
    this.testform.get('state')?.disable();
  };

  isDropdownRight = true;
  changeDropdownLocation = () => {
    this.isDropdownRight = !this.isDropdownRight;
    console.log('change dropdown location: ', this.isDropdownRight);
  };

  datePickerChange = (value: any) => {
    console.log('datepicker changed: ', value);
  };

  disableForm = () => {
    if (this.testform.disabled) {
      this.testform.enable();
    } else {
      this.testform?.disable();
    }
  };

  updateSelect = () => {
    this.testform?.patchValue({state: 'TX'});
  }
}
