//*
/* Config file to use for variables which dont change from environment to environment
**/

// 'X-Forwarded-Access-Token': needed for local testing against a backend with security context expecting a user token
export const AppConfig = {
  googlePath: 'http://www.google.com',
  serviceHeaders: {
    'role-id': 'pm',
    'source-system-name': 'FFM_PM',
    'user-id': 'testUser'
  }
};
