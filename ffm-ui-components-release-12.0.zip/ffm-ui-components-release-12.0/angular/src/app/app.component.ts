import { Component, OnInit, ViewEncapsulation, ElementRef } from '@angular/core';
import { HeaderService, FooterService, AuthorizationService } from 'ngx-ffm-ui-components';
import { BreadCrumb } from 'ngx-cms-design';

@Component({
  selector: 'ffm-ui-components-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class AppComponent implements OnInit {
  title = 'ffm-ui-components';

  breadCrumbAliases: BreadCrumb[] = [
    { url: 'bread-crumb-path-longer', alias: 'Its a me Mario!' },
    { url: 'another-long-name-to-test', alias: 'What about luigi?' },
    { url: 'dropdown-manu-item-test', alias: 'Dropdown Manu Item' },
    { url: 'another-dropdown-manu-item-test', alias: 'Another Dropdown Manu Item' },
    { url: 'second-dropdown-manu-item-test', alias: 'Second Dropdown Manu Item' },
    { url: 'another-second-dropdown-manu-item-test', alias: 'Another Second Dropdown Manu Item' },
    { url: 'sub - XXXX', alias: 'Sub - Aliased Parameter' },
  ];

  constructor(public headerService: HeaderService, public footerService: FooterService, private elementRef: ElementRef, private authService: AuthorizationService) { }


  ngOnInit(): void {
      // This is intentional
  }

  logoutButtonHandler = () => {
    console.log('logout in app component');
    this.authService.logout();
  };

  onSearch = (evt: any) => {
    console.log('onSearch: ', evt);
  };

  skipNav(): void {
    let firstInMain = this.elementRef.nativeElement.querySelector('h1');
    firstInMain.focus();
    firstInMain.scrollIntoView();
  }
}
