import { environment } from './../environments/environment';
import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReactiveFormsModule } from '@angular/forms';
import { WeatherService } from './services/weather.service';
import { HttpClientModule } from '@angular/common/http';
import { BreadcrumbDemoComponent } from './demo-components/breadcrumb-demo/breadcrumb-demo.component';
import { NestedBreadCrumbDemoComponent } from './demo-components/breadcrumb-demo/nested-bread-crumb-demo/nested-bread-crumb-demo.component';
import { DestinationComponent } from './demo-components/destination/destination.component';
import { AppConfig } from './config/appconfig';
import { CmsDesignModule } from 'ngx-cms-design';
import { FFMUIComponentsModule, ErrorHandlerService } from 'ngx-ffm-ui-components';
import { DemoComponent } from './demo-components/demo/demo.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent,
    BreadcrumbDemoComponent,
    NestedBreadCrumbDemoComponent,
    DestinationComponent,
    DemoComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    CmsDesignModule,
    FFMUIComponentsModule.forRoot(environment, AppConfig),
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [
    WeatherService,
    {
      provide: ErrorHandler,
      useClass: ErrorHandlerService
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
