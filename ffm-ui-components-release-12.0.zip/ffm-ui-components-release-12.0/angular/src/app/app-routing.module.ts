import { DestinationComponent } from './demo-components/destination/destination.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes, mapToCanActivate } from '@angular/router';
import { BreadcrumbDemoComponent } from './demo-components/breadcrumb-demo/breadcrumb-demo.component';
import { NestedBreadCrumbDemoComponent } from './demo-components/breadcrumb-demo/nested-bread-crumb-demo/nested-bread-crumb-demo.component';
import { ComponentGuard } from 'ngx-ffm-ui-components';
import { DemoComponent } from './demo-components/demo/demo.component';



const routes: Routes = [
  {
    path: 'demo',
    component: DemoComponent,
    pathMatch: 'full'
  },
  {
    path: 'bread-crumb-path-longer',
    component: BreadcrumbDemoComponent,
    children: [
      { path: 'another-long-name-to-test', component: NestedBreadCrumbDemoComponent }
    ]
  },
  {
    path: 'dropdown-manu-item-test',
    component: BreadcrumbDemoComponent,
  },
  {
    path: 'another-dropdown-manu-item-test',
    component: BreadcrumbDemoComponent,
  },
  {
    path: 'second-dropdown-manu-item-test',
    component: BreadcrumbDemoComponent,
  },
  {
    path: 'another-second-dropdown-manu-item-test',
    component: BreadcrumbDemoComponent,
  },
  {
    path: 'destination',
    component: DestinationComponent,
    canActivate: mapToCanActivate([ComponentGuard]),
    data: { componentName: 'DestinationComponent' }
  },
  {
    path: 'bread-crumb-path-id/:id/detail-view',
    component: BreadcrumbDemoComponent,
    pathMatch: 'full'
  },
  {
    path: 'bread-crumb-path-id/:id',
    pathMatch: 'full',
    redirectTo: 'bread-crumb-path-id/:id/detail-view'
  },
  {
    path: 'bread-crumb-path-id/:id/detail-view/:two/second-child',
    component: BreadcrumbDemoComponent,
  },
  {
    path: 'bread-crumb-path/detail-view-to-show',
    component: BreadcrumbDemoComponent
  },
  {
    path: 'bread-crumb-path/detail-view-to-show/sub/:id',
    component: BreadcrumbDemoComponent
  },
  {
    path: '**',
    redirectTo: '/demo',
    pathMatch: 'full'
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
