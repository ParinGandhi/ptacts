import { HttpClientModule } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { CmsDesignModule } from 'ngx-cms-design';
import { FFMUIComponentsModule } from 'ngx-ffm-ui-components';
import { AppComponent } from './app.component';

let envMock = {
  production: false,
  debug: false,
  bffUri: 'http://localhost:9999/api',
  oauthUri: '',
  logoutRedirectUri: '',
  logoutRedirectFromUri: ''
}

let appConfigMock = {
  serviceHeaders: {
    'role-id': 'pm',
    'source-system-name': 'FFM_PM',
    'user-id': 'testUser'
  },
}

describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        ReactiveFormsModule,
        HttpClientModule,
        CmsDesignModule,
        FFMUIComponentsModule
      ],
      declarations: [
        AppComponent
      ],
      providers: [
        {
          provide: 'environment', useValue: envMock
        },
        { provide: 'AppConfig', useValue: appConfigMock }
      ]
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'ffm-ui-components'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('ffm-ui-components');
  });
});
