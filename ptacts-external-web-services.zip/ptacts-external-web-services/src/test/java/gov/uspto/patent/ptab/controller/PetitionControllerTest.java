package gov.uspto.patent.ptab.controller;

import com.fasterxml.jackson.databind.JsonNode;
import gov.uspto.patent.ptab.domain.PaymentRequest;
import gov.uspto.patent.ptab.domain.PaymentVO;
import gov.uspto.patent.ptab.service.PaymentService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import gov.uspto.patent.ptab.domain.PetitionBasicInformation;
import gov.uspto.patent.ptab.service.PetitionService;
import org.springframework.util.MultiValueMap;

public class PetitionControllerTest {

    @InjectMocks
    PetitionController petitionController;

    @Mock
    PetitionService petitionService;

    @Mock
    PaymentService paymentService;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void createPetitionTest() {
        PetitionBasicInformation petition = new PetitionBasicInformation();
        Mockito.when(petitionService.createPetition(Mockito.any())).thenReturn(petition);
        PetitionBasicInformation response = petitionController.createPetition(Mockito.any());
        Assert.assertNotNull(response);
    }

    @Test
    public void ccreatePaymentTest() {
        PaymentRequest pr = new PaymentRequest();
        PaymentVO vo = new PaymentVO();
        Mockito.when(paymentService.createPayment(Mockito.any(), Mockito.any())).thenReturn(vo);
        var response = petitionController.createPayment(1L, pr);
        Assert.assertNotNull(response);
    }

    @Test
    public void createAdhocPaymentTest(){
        PaymentVO vo = new PaymentVO();
        JsonNode adhocPayment = null;
        Mockito.when(paymentService.createAdhocPayment(Mockito.anyLong(), Mockito.any())).thenReturn(vo);
        var response = petitionController.createAdhocPayment(1L,adhocPayment);
        Assert.assertNotNull(response);
    }

    @Test
    public void getReceiptPaymentsTest() {
        PaymentVO vo = new PaymentVO();
        Mockito.when(paymentService.getPayments(Mockito.anyLong())).thenReturn(vo);
        var response = petitionController.getReceiptPayments(1L);
        Assert.assertNotNull(response);
    }
  @Test
    public void processCompletePaymentTest() {
        Mockito.when(paymentService.updateCompletePayment(Mockito.anyLong(),Mockito.anyLong(),Mockito.any())).thenReturn("vo");
        var response = petitionController.processCompletePayment(1L,1L,"parameters");
        Assert.assertNotNull(response);
    }

    @Test
    public void processCompletePaymentWithTransactionIdTest(){
        Mockito.when(paymentService.updatePaymentDetails(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyString(),
                Mockito.anyString())).thenReturn("vo");
        Assert.assertNotNull(petitionController.processCancelPaymentWithTransactionId(1L,1L,""));
    }

    @Test
    public void processCancelPaymentTest(){
        MultiValueMap<String, String> parameters = null;
        Mockito.when(paymentService.updateCancelPayment(Mockito.anyLong(),Mockito.anyLong(),Mockito.any())).thenReturn(
                "vo");
        Assert.assertNotNull(petitionController.processCancelPayment(1L,1L,parameters));
    }

}
