package gov.uspto.patent.ptab.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import gov.uspto.patent.ptab.domain.FilingPartyDropDownList;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import gov.uspto.patent.ptab.service.ExternalUserService;

/**
 * This is a Test class for CaseSearchControllerTest
 *
 * @author 2020 DevelopmentTeam
 *
 */
public class ExternalUserControllerTest {

    @InjectMocks
    private ExternalUserController externalUserController;

    @Mock
    private ExternalUserService externalUserService;

    @Before
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getPrcdPartyGroupTypeTest() throws Exception {

        String grpType = "petitioner";
        when(externalUserService.getPrcdPartyGroupType(any())).thenReturn(grpType);

        final String respGrpType = externalUserController.getPrcdPartyGroupType("IPR2020-1234");
        assertEquals(grpType, respGrpType);
    }

    public void getDropDownListTest() {
        when(externalUserService.getDropDownlist(any())).thenReturn(new FilingPartyDropDownList());

        FilingPartyDropDownList dropDownList = externalUserController.getDropDownList("IPR2020-1234");
        assertNotNull(dropDownList);
    }
}
