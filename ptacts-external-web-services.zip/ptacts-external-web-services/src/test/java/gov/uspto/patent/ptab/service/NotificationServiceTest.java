package gov.uspto.patent.ptab.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.NotificationDetails;
import gov.uspto.patent.ptab.utils.RestServiceClient;

/**
 * Test Class to test NotificationService
 *
 * @author 2020 Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class NotificationServiceTest {

    private static final String CONTENT_ID_12345 = "12345";

    private static final String NOTIFICATION_EMAIL_DETAILS_URL = "notificationEmailDetailsUrl";

    private static final String TEST = "test";

    @InjectMocks
    private NotificationService notificationService;

    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Method used to test the get email notification details
     */
    @Test
    public void testGetNotificationEmailDetails() {
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(NOTIFICATION_EMAIL_DETAILS_URL);
        Mockito.when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(TEST);
        final NotificationDetails notificationDetails = new NotificationDetails();
        notificationDetails.setContentManagementId(CONTENT_ID_12345);
        final JsonNode nodeMock = Mockito.mock(JsonNode.class);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(new ResponseEntity<>(nodeMock, HttpStatus.CREATED));
        final JsonNode response = notificationService.getNotificationEmailDetails(CONTENT_ID_12345);
        assertNotNull(response);
    }
}
