package gov.uspto.patent.ptab.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * Test case for ExternalUserDao
 * 
 * @author 2020 - Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ExternalUserDaoTest {

    @InjectMocks
    private ExternalUserDao externalUserDao;

    @Mock
    private final SessionFactory sessionFactory = Mockito.mock(SessionFactory.class);

    private Session session;
    @SuppressWarnings("rawtypes")
    private Query query;

    @Before
    public void initMocks() {

        MockitoAnnotations.initMocks(this);
    }

    /**
     * Test method for getUserPrcdPartyGroupType
     */
    @Test
    public void testGetUserPrcdPartyGroupType() {
        mockSession();
        Mockito.when(query.uniqueResult()).thenReturn("userId");
        final String response = externalUserDao.getUserPrcdPartyGroupType("getUserPrcdPartyGroupType",
                "getUserPrcdPartyGroupType");
        assertEquals("userId", response);
    }

    /**
     * Test method for getUserPrcdPartyGroupTypeForStaff
     */
    @Test
    public void testGetUserPrcdPartyGroupTypeForStaff() {
        mockSession();
        Mockito.when(query.uniqueResult()).thenReturn("userId");
        final String response = externalUserDao.getUserPrcdPartyGroupTypeForStaff("getUserPrcdPartyGroupType",
                "getUserPrcdPartyGroupType");
        assertEquals("userId", response);
    }

    /**
     * Test method to mock session
     */
    private void mockSession() {

        session = Mockito.mock(Session.class);
        query = Mockito.mock(Query.class);
        Mockito.when(sessionFactory.getCurrentSession()).thenReturn(session);
        Mockito.when(session.createNamedQuery(Mockito.anyString(), Mockito.any())).thenReturn(query);

    }
}
