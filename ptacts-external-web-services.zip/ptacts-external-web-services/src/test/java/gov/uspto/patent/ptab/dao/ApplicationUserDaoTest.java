package gov.uspto.patent.ptab.dao;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 * Test case for ApplicationUserDao
 * 
 * @author 2020 - Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ApplicationUserDaoTest {

    private static final String USER_ID = "userId";
    private static final String APPLICATION_USER_ID = "applicationUserId";
    private static final String JUDGE_IDENTIFIER = "judgeIdentifier";

    @InjectMocks
    private ApplicationUserDao applicationUserDao;

    @Mock
    private final SessionFactory sessionFactory = Mockito.mock(SessionFactory.class);

    private Session session;
    @SuppressWarnings("rawtypes")
    private Query query;

    @Before
    public void initMocks() {

        MockitoAnnotations.initMocks(this);
    }

    /**
     * Test method for GetValidUserRole
     */
    @Test
    public void testGetValidUserRole() {
        mockSession();
        Mockito.when(query.uniqueResult()).thenReturn("userId");
        final String response = applicationUserDao.getValidUserRole(USER_ID);
        assertEquals("userId", response);
    }

    /**
     * Test method for GetRoleDescription
     */
    @Test
    public void testGetRoleDescription() {
        mockSession();
        Mockito.when(query.uniqueResult()).thenReturn("applicationUserId");
        final String response = applicationUserDao.getRoleDescription(APPLICATION_USER_ID);
        assertEquals("applicationUserId", response);
    }

    /**
     * Test method for GetRoleId
     */
    @Test
    public void testGetRoleId() {
        mockSession();
        Mockito.when(query.uniqueResult()).thenReturn(Integer.parseInt("10"));
        final BigDecimal response = applicationUserDao.getRoleId(APPLICATION_USER_ID);
        assertEquals(BigDecimal.TEN, response);

    }

    /**
     * Test method for GetLoginModalAccessByUserId
     */
    @Test
    public void testGetLoginModalAccessByUserId() {
        mockSession();
        List<String> userList = new ArrayList<>();
        userList.add(USER_ID);
        Mockito.when(query.list()).thenReturn(userList);
        final List<String> response = applicationUserDao.getLoginModalAccessByUserId(USER_ID);
        assertEquals("userId", response.get(0));
    }

    /**
     * Test method for GetDiscipline
     */
    @Test
    public void testGetDiscipline() {
        mockSession();
        Mockito.when(query.uniqueResult()).thenReturn("judgeIdentifier");
        final String response = applicationUserDao.getDiscipline(JUDGE_IDENTIFIER);
        assertEquals("judgeIdentifier", response);
    }

    /**
     * Test method for GetConfigurredResourceObjectsByUserId
     */
    @Test
    public void testGetConfigurredResourceObjectsByUserId() {
        mockSession();
        List<String> userList = new ArrayList<>();
        userList.add(USER_ID);
        Mockito.when(query.list()).thenReturn(userList);
        final List<String> response = applicationUserDao.getConfigurredResourceObjectsByUserId(USER_ID);
        assertEquals(USER_ID, response.get(0));
    }

    /**
     * Test method to mock session
     */
    private void mockSession() {

        session = Mockito.mock(Session.class);
        query = Mockito.mock(Query.class);
        Mockito.when(sessionFactory.getCurrentSession()).thenReturn(session);
        Mockito.when(session.createNamedQuery(Mockito.anyString(), Mockito.any())).thenReturn(query);

    }

}
