package gov.uspto.patent.ptab.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.Petition;
import gov.uspto.patent.ptab.domain.ProceedingQuery;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import jakarta.servlet.http.HttpServletRequest;

@RunWith(MockitoJUnitRunner.class)
public class ProceedingServiceTest {

    @InjectMocks
    private ProceedingService proceedingService;

    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Mock
    private HttpServletRequest httpServletRequest;

    /**
     * test method to test getProceeding
     */
    @Test
    public void testGetProceeding() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("motionDetailsUrl");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(),anyString())).thenReturn("userName");
        final ProceedingQuery proceedingQuery=new ProceedingQuery();
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.callPTABExternalServiceURL(any(),any(),any(),any(),anyString())).thenReturn(responseObj);
        proceedingService.getProceeding(proceedingQuery);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }

    /**
     * test method to test getBasicProceedingAndPaymentDetails
     */
    @Test
    public void testGetBasicProceedingAndPaymentDetails() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("motionDetailsUrl");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(),anyString())).thenReturn("userName");
        final ProceedingQuery proceedingQuery=new ProceedingQuery();
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.callPTABExternalServiceURL(any(),any(),any(),any(),anyString())).thenReturn(responseObj);
        proceedingService.getBasicProceedingAndPaymentDetails(proceedingQuery);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }

    /**
     * test method to test submitProceeding200OK
     */
    @Test
    public void testSubmitProceeding200OK() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("motionDetailsUrl");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(),anyString())).thenReturn("userName");
        final Petition petition=new Petition();
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.callPTABExternalServiceURL(any(),any(),any(),any(),anyString())).thenReturn(responseObj);
        when(responseObj.getStatusCode()).thenReturn(HttpStatus.OK);
        proceedingService.submitProceeding(petition);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }

    /**
     * test method to test submitProceeding
     */
    @Test(expected=Exception.class)
    public void testSubmitProceeding400() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("motionDetailsUrl");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(),anyString())).thenReturn("userName");
        final Petition petition=new Petition();
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.callPTABExternalServiceURL(any(),any(),any(),any(),anyString())).thenReturn(responseObj);
        when(responseObj.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
        proceedingService.submitProceeding(petition);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }

    /**
     * test method to test submitProceeding
     */
    @Test(expected=Exception.class)
    public void testSubmitProceeding500() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("motionDetailsUrl");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(),anyString())).thenReturn("userName");
        final Petition petition=new Petition();
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.callPTABExternalServiceURL(any(),any(),any(),any(),anyString())).thenReturn(responseObj);
        when(responseObj.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        proceedingService.submitProceeding(petition);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }
}
