package gov.uspto.patent.ptab.utils;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.InputStream;

import org.junit.Before;
import org.junit.Ignore;
@RunWith(MockitoJUnitRunner.class)
public class RestDefaultErrorHandlerTest {
	
	@InjectMocks
    private RestDefaultErrorHandler restDefaultErrorHandler;
	
	@Mock
	private ClientHttpResponse response;
	
	
	@Mock
	private InputStream inputstream;
	
	@Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }
	 @Test
	 public void hasErrorTest() {
		 
        
         try {
			Mockito.when(response.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
			boolean hasError = restDefaultErrorHandler.hasError(response);
			assertTrue(hasError);
		} catch (IOException e) {
			fail("is not expected to be here");
		}
	        
	 }
	 
	 
	 @Test
	 public void handleServerErrorTest() {
		 
        
         try {
			Mockito.when(response.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
			boolean hasError = restDefaultErrorHandler.hasError(response);
			assertTrue(hasError);
		} catch (IOException e) {
			fail("is not expected to be here");
		}
	 }
         
         @Test
    	 public void handleSuccessTest() {
    		 
            
             try {
    			Mockito.when(response.getStatusCode()).thenReturn(HttpStatus.OK);
    			boolean hasError = restDefaultErrorHandler.hasError(response);
    			assertFalse(hasError);
    		} catch (IOException e) {
    			fail("is not expected to be here");
    		}
    	        
    	 }
	        
         
         
         @Test
    	 public void handlethrowExceptionTest() {
    		 
            
             try {
    			Mockito.when(response.getStatusCode()).thenThrow(IOException.class);
    			boolean hasError = restDefaultErrorHandler.hasError(response);
    			assertFalse(hasError);
    		} catch (IOException e) {
    			fail("is not expected to be here");
    		}
    	        
    	 }
         
         
         @Test
         
    	 public void handleErrorwithExceptionTest() {
    		 
            
             try {
    			Mockito.when(response.getStatusCode()).thenReturn(HttpStatus.OK);
    			Mockito.when(response.getBody()).thenThrow(IOException.class);
    			restDefaultErrorHandler.handleError(response);
    		} catch (IOException e) {
    			fail("is not expected to be here");
    		}
    	        
        }
	 @Test
     
	 public void handleErrorTest() {
		 
        
         try {
			Mockito.when(response.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
			Mockito.when(response.getBody()).thenReturn(inputstream);
			Mockito.when(inputstream.toString()).thenReturn("abc");
			restDefaultErrorHandler.handleError(response);
		} catch (IOException e) {
			fail("is not expected to be here");
		}
	        
    }
         

}
