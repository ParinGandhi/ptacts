package gov.uspto.patent.ptab.utils;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class DateUtilityTest {

    @InjectMocks
    private DateUtility dateUtility;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Test method for formatStringToDate
     */
    @Test
    public void formatStringToDateTest() {
        final Date date = DateUtility.formatStringToDate("mm/DD/yyyy", "01/01/2020");
        assertNotNull(date);
    }

    /**
     * Test method for formatStringToDateInvalidDate
     */
    @Test(expected = PTABException.class)
    public void formatStringToDateInvalidDateTest() {
        DateUtility.formatStringToDate("mm/DD/yyyy", "abcd");
    }

    /**
     * Test method for formatStringToDateNullDate
     */
    @Test
    public void formatStringToDateNullDateTest() {
        final Date date = DateUtility.formatStringToDate("mm/DD/yyyy", null);
        assertNull(date);
    }

}
