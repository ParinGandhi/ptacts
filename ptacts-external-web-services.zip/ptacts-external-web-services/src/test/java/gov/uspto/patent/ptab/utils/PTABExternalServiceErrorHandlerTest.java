package gov.uspto.patent.ptab.utils;

import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.mock.http.client.MockClientHttpResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PTABExternalServiceErrorHandlerTest {

    private final PTABExternalServiceErrorHandler pTABExternalServiceErrorHandler = new PTABExternalServiceErrorHandler();

    @Test(expected = PTABException.class)
    public void handleErrorTest() {
        final String errorMessage = "{\"errorMessage\":\"Bad Request\"}";
        final ClientHttpResponse paramClientHttpResponse = new MockClientHttpResponse(errorMessage.getBytes(),
                HttpStatus.BAD_REQUEST);
        pTABExternalServiceErrorHandler.handleError(paramClientHttpResponse);

    }

    @Test
    public void hasErrorTest() {
        final String errorMessage = "Bad data";
        final ClientHttpResponse paramClientHttpResponse = new MockClientHttpResponse(errorMessage.getBytes(),
                HttpStatus.INTERNAL_SERVER_ERROR);

        final boolean hasErrorReponse = pTABExternalServiceErrorHandler.hasError(paramClientHttpResponse);
        assertEquals(true, hasErrorReponse);
    }
}
