package gov.uspto.patent.ptab.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.dao.ExternalUserDocketDao;
import gov.uspto.patent.ptab.dao.ProceedingArtifactDao;
import gov.uspto.patent.ptab.domain.AIAReviewsDocket;
import gov.uspto.patent.ptab.domain.AppealDetails;
import gov.uspto.patent.ptab.domain.ExternalUserMotion;
import gov.uspto.patent.ptab.domain.ExternalUserRehearing;
import gov.uspto.patent.ptab.domain.NotificationDetails;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.entities.ProceedingArtifact;
import gov.uspto.patent.ptab.helper.ProceedingArtifactUtilityHelper;

/**
 *
 * @author 2020 - development team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ExternalUserDocketServiceTest {

    @InjectMocks
    private ExternalUserDocketService extUserDtService;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private HttpServletRequest httpServletRequest;

    @Mock
    private ExternalUserDocketDao extUserDocketDao;

    @Mock
    List<ExternalUserMotion> motionDetails;

    @Mock
    ExternalUserMotion motionDetail;

    @Mock
    List<ExternalUserRehearing> rehearings;

    @Mock
    ExternalUserRehearing rehearing;

    @Mock
    ExternalUserDocketDao externalUserDocketDao;

    @Mock
    List<NotificationDetails> notifications;

    @Mock
    NotificationDetails notification;

    @Mock
    List<ProceedingArtifact> proceedingArtifactList;

    @Mock
    ProceedingArtifact proceedingArtifact;

    @Mock
    ProceedingArtifactUtilityHelper proceedingArtifactUtilityHelper;

    @Mock
    private ProceedingArtifactDao proceedingArtifactDao;

    @Mock
    List<PetitionDocument> petitionDocumentList;

    @Mock
    PetitionDocument petitionDocument;

    String username;

    @Before
    public void setUp() {

        MockitoAnnotations.initMocks(this);
        motionDetails = new ArrayList<>();
        motionDetail = new ExternalUserMotion();
        motionDetail.setMotionId(1234L);
        motionDetail.setMotionStatusId(123L);
        motionDetails.add(motionDetail);

        rehearings = new ArrayList<>();
        rehearing = new ExternalUserRehearing();
        rehearing.setRehearingId(1234L);
        rehearing.setRehearingStatusId(123L);
        rehearings.add(rehearing);

        notifications = new ArrayList<>();
        notification = new NotificationDetails();
        notification.setNotificationId("1234");
        notifications.add(notification);

        proceedingArtifactList = new ArrayList<>();
        proceedingArtifact.setArtifactNm("Test");
        proceedingArtifact.setProceedingArtifactId(1234L);
        proceedingArtifactList.add(proceedingArtifact);

        username = "tesUser";
        Mockito.when(httpServletRequest.getAttribute("valid-user")).thenReturn(username);

        petitionDocumentList = new ArrayList<>();
        petitionDocument.setArtifactIdentifer("1234");
        petitionDocument.setProceedingArtifactIdentifier(1234L);
        petitionDocumentList.add(petitionDocument);

    }

    @Test
    public void getAIAReviews() {
        String stateId = "20~22~24~10~11~12~13";
        List<AIAReviewsDocket> dockets = new ArrayList<>();
        AIAReviewsDocket extUsrDocket = new AIAReviewsDocket();
        dockets.add(extUsrDocket);
        String proceedingState = "AllAIA";
        String actual = "patentOwnerName";
        extUsrDocket.setPatentOwnerName(actual);
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue("ProceedingState", proceedingState))
                .thenReturn(stateId);

        extUserDtService.getAIAReviews(proceedingState);
        verify(extUserDocketDao, Mockito.atMost(1)).getAIAReviews(Mockito.anyString(), Mockito.anyList(), Mockito.anyList());
        verify(codeReferenceDao, Mockito.atMost(1)).findDescriptionByTypeCodeAndValueTx(Mockito.anyString(), Mockito.anyString());
        assertEquals(dockets.get(0).getPatentOwnerName(), actual);
    }

    @Test
    public void getNotificationsTest() {

        List<NotificationDetails> response = extUserDtService.getNotifications();
        verify(extUserDocketDao, Mockito.atMost(1)).getNotifications(Mockito.anyString());
        assertNotNull(response);
    }

    @Test
    public void getMotionsTest() {
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn("1");

        List<ExternalUserMotion> response = extUserDtService.getMotions("ALL", false);
        verify(extUserDocketDao, Mockito.atMost(1)).getMotions(Mockito.anyString(), Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.any(), Mockito.any());
        assertNotNull(response);
    }

    @Test
    public void getRehearingsTest() {
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn("1");

        List<ExternalUserRehearing> response = extUserDtService.getRehearings("ALL");
        verify(extUserDocketDao, Mockito.atMost(1)).getRehearings(Mockito.anyString(), Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyList());
        assertNotNull(response);
    }

    @Test
    public void getAppealsTest() {
        List<AppealDetails> appealsFromDB = new ArrayList<>();
        AppealDetails appealDetails = new AppealDetails();
        appealDetails.setAppealTypeId(1L);
        appealDetails.setAppealStatusId(5L);
        appealDetails.setRequestorTypeName("Petitioner");
        appealsFromDB.add(appealDetails);
        List<Long> testIds = new ArrayList<>();
        testIds.add(1L);
        List<ProceedingArtifact> proceedingArtifactList = new ArrayList<>();
        ProceedingArtifact proceedingArtifact = new ProceedingArtifact();
        proceedingArtifact.setProceedingArtifactId(123L);
        proceedingArtifactList.add(proceedingArtifact);
        List<PetitionDocument> petitionDocumentList = new ArrayList<>();
        PetitionDocument petitionDocument = new PetitionDocument();
        petitionDocument.setArtifactSubmissionIdentifier(123L);
        petitionDocumentList.add(petitionDocument);
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn("1");
        Mockito.when(externalUserDocketDao.getAppeals(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(appealsFromDB);
        // Mockito.when(proceedingArtifactDao.getAllProceedingArtifactsForAppeals(123L)).thenReturn(proceedingArtifactList);
        // doNothing().when(proceedingArtifactUtilityHelper).getAllPetitionDocuments(Mockito.anyList(),
        // Mockito.anyList());
        List<AppealDetails> response = extUserDtService.getAppeals("ALL");
        assertNotNull(response);
    }
    
    /**
     * test method to test getRehearingsByPrcdNum
     */
    @Test
    public void testGetRehearingsByPrcdNum() {
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn("1");
        List<ExternalUserRehearing> response = extUserDtService.getRehearingsByPrcdNum("ALL","ALL",145L);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).findDescriptionByTypeCodeAndValueTx(anyString(),anyString());
        assertNotNull(response);
    }
    
    /**
     * test method to test getRehearingsByPrcdNumNull
     */
    @Test
    public void testGetRehearingsByPrcdNumNull() {
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn("1");
        List<ExternalUserRehearing> response = extUserDtService.getRehearingsByPrcdNum("ALL","rehearingStatus",145L);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).findDescriptionByTypeCodeAndValueTx(anyString(),anyString());
        assertNotNull(response);
    }
}
