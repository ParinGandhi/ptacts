package gov.uspto.patent.ptab.trials.services;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.Petition;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.trials.domain.MotionDetails;
import gov.uspto.patent.ptab.trials.domain.RehearingInfo;
import gov.uspto.patent.ptab.trials.service.TrialsAdapterService;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;

@RunWith(MockitoJUnitRunner.class)
public class TrialsAdapterServiceTest {

    @InjectMocks
    private TrialsAdapterService trialsAdapterService;
    
    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    private HttpServletRequest httpServletRequest;

    @Mock
    private CodeReferenceDao codeReferenceDao;
    
    @Mock
    private PTABBusinessUtils ptabBusinessUtils;
    
    /**
     * test method to test createMotion
     */
    @Test
    public void testCreateMotion() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("createMotionUrl");
        final MotionDetails motionDetails=new MotionDetails();
        final RehearingInfo rehearingInfo=new RehearingInfo();
        final Petition petition=new Petition();
        final List<PetitionDocument> petitionDocumentsList=new ArrayList<>();
        final PetitionDocument docPetition=new PetitionDocument();
        petitionDocumentsList.add(docPetition);
        petition.setPetitionDocuments(petitionDocumentsList);
        when(httpServletRequest.getAttribute(anyString())).thenReturn("userIdentifier");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);     
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.OK);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        trialsAdapterService.createMotion(motionDetails);
        trialsAdapterService.createRehearing(rehearingInfo);
        trialsAdapterService.submitProceeding(petition);
        trialsAdapterService.deleteRehearing(145L);
        trialsAdapterService.updatePartyRehearing(rehearingInfo, 145L);
        trialsAdapterService.deleteMotion(145L);
        trialsAdapterService.updatePartyMotion(motionDetails, 145L);
        Mockito.verify(codeReferenceDao, Mockito.atMost(7)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }
    
    /**
     * test method to test createMotionBAD_REQUEST
     */
    @Test(expected=PTABException.class)
    public void testCreateMotionBAD_REQUEST() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("createMotionUrl");
        final MotionDetails motionDetails=new MotionDetails();
        final RehearingInfo rehearingInfo=new RehearingInfo();
        when(httpServletRequest.getAttribute(anyString())).thenReturn("userIdentifier");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);     
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        trialsAdapterService.createMotion(motionDetails);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }
    
    /**
     * test method to test createMotionINTERNAL_SERVER_ERROR
     */
    @Test(expected=PTABException.class)
    public void testCreateMotionINTERNAL_SERVER_ERROR() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("createMotionUrl");
        final MotionDetails motionDetails=new MotionDetails();
        final RehearingInfo rehearingInfo=new RehearingInfo();
        when(httpServletRequest.getAttribute(anyString())).thenReturn("userIdentifier");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);     
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        trialsAdapterService.createMotion(motionDetails);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }
    
    /**
     * test method to test createRehearingBAD_REQUEST
     */
    @Test(expected=PTABException.class)
    public void testCreateRehearingBAD_REQUEST() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("createMotionUrl");
        final RehearingInfo rehearingInfo=new RehearingInfo();
        when(httpServletRequest.getAttribute(anyString())).thenReturn("userIdentifier");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);     
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        trialsAdapterService.createRehearing(rehearingInfo);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }
    
    /**
     * test method to test createRehearingINTERNAL_SERVER_ERROR
     */
    @Test(expected=PTABException.class)
    public void testCreateRehearingINTERNAL_SERVER_ERRORT() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("createMotionUrl");
        final RehearingInfo rehearingInfo=new RehearingInfo();
        when(httpServletRequest.getAttribute(anyString())).thenReturn("userIdentifier");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);     
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        trialsAdapterService.createRehearing(rehearingInfo);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }
    
    /**
     * test method to test submitProceedingBAD_REQUEST
     */
    @Test(expected=PTABException.class)
    public void testSubmitProceedingBAD_REQUEST() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("createMotionUrl");
        final Petition petition=new Petition();
        when(httpServletRequest.getAttribute(anyString())).thenReturn("userIdentifier");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);     
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        trialsAdapterService.submitProceeding(petition);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }
    
    /**
     * test method to test submitProceedingINTERNAL_SERVER_ERROR
     */
    @Test(expected=PTABException.class)
    public void testSubmitProceedingINTERNAL_SERVER_ERROR() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("createMotionUrl");
        final Petition petition=new Petition();
        when(httpServletRequest.getAttribute(anyString())).thenReturn("userIdentifier");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);     
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        trialsAdapterService.submitProceeding(petition);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }
    
    /**
     * test method to test deleteRehearingBAD_REQUEST
     */
    @Test(expected=PTABException.class)
    public void testDeleteRehearingBAD_REQUEST() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("createMotionUrl");
        when(httpServletRequest.getAttribute(anyString())).thenReturn("userIdentifier");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);     
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        trialsAdapterService.deleteRehearing(145L);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }
    
    /**
     * test method to test deleteRehearingINTERNAL_SERVER_ERROR
     */
    @Test(expected=PTABException.class)
    public void testDeleteRehearingINTERNAL_SERVER_ERRORT() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("createMotionUrl");
        when(httpServletRequest.getAttribute(anyString())).thenReturn("userIdentifier");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);     
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        trialsAdapterService.deleteRehearing(145L);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }
    
    /**
     * test method to test updatePartyRehearingBAD_REQUEST
     */
    @Test(expected=PTABException.class)
    public void testUpdatePartyRehearingBAD_REQUEST() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("createMotionUrl");
        final RehearingInfo rehearingInfo=new RehearingInfo();
        when(httpServletRequest.getAttribute(anyString())).thenReturn("userIdentifier");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);     
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        trialsAdapterService.updatePartyRehearing(rehearingInfo,145L);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }
    
    /**
     * test method to test updatePartyRehearingINTERNAL_SERVER_ERROR
     */
    @Test(expected=PTABException.class)
    public void testUpdatePartyRehearingINTERNAL_SERVER_ERRORT() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("createMotionUrl");
        final RehearingInfo rehearingInfo=new RehearingInfo();
        when(httpServletRequest.getAttribute(anyString())).thenReturn("userIdentifier");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);     
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        trialsAdapterService.updatePartyRehearing(rehearingInfo,145L);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }
    
    /**
     * test method to test deleteMotionBAD_REQUEST
     */
    @Test(expected=PTABException.class)
    public void testDeleteMotionBAD_REQUEST() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("createMotionUrl");
        final RehearingInfo rehearingInfo=new RehearingInfo();
        when(httpServletRequest.getAttribute(anyString())).thenReturn("userIdentifier");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);     
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        trialsAdapterService.deleteMotion(145L);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }
    
    /**
     * test method to test deleteMotionINTERNAL_SERVER_ERROR
     */
    @Test(expected=PTABException.class)
    public void testDeleteMotionINTERNAL_SERVER_ERRORT() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("createMotionUrl");
        final RehearingInfo rehearingInfo=new RehearingInfo();
        when(httpServletRequest.getAttribute(anyString())).thenReturn("userIdentifier");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);     
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        trialsAdapterService.deleteMotion(145L);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }
    
    /**
     * test method to test updatePartyMotionBAD_REQUEST
     */
    @Test(expected=PTABException.class)
    public void testUpdatePartyMotionBAD_REQUEST() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("createMotionUrl");
        final RehearingInfo rehearingInfo=new RehearingInfo();
        final MotionDetails motionDetails=new MotionDetails();
        when(httpServletRequest.getAttribute(anyString())).thenReturn("userIdentifier");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);     
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        trialsAdapterService.updatePartyMotion(motionDetails,145L);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }
    
    /**
     * test method to test updatePartyMotionINTERNAL_SERVER_ERROR
     */
    @Test(expected=PTABException.class)
    public void testUpdatePartyMotionINTERNAL_SERVER_ERRORT() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("createMotionUrl");
        final RehearingInfo rehearingInfo=new RehearingInfo();
        final MotionDetails motionDetails=new MotionDetails();
        when(httpServletRequest.getAttribute(anyString())).thenReturn("userIdentifier");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);     
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        trialsAdapterService.updatePartyMotion(motionDetails,145L);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }
}
