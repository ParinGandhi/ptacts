package gov.uspto.patent.ptab.utils;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

@RunWith(MockitoJUnitRunner.class)
public class RestServiceClientTest {

    @InjectMocks
    private RestServiceClient restServiceClient;

    @Mock
    private ResponseEntity<Object> response;

    @Mock
    private RestTemplate restTemplate;
    
    @Mock
    private PTABBusinessUtils ptabBusinessUtils;

    @Test(expected = Exception.class)
    public void callPTABExternalServiceURLTest() {
        final Object object = new Object();
        final String loggedInUser ="loggedInUser";
//        Mockito.when(ptabBusinessUtils.getLoggedInUserId()).thenReturn(loggedInUser);
        restServiceClient.callPTABExternalServiceURL("https://abc.com", object, HttpMethod.POST, String.class, "sbartlett");

    }

    @Test(expected = Exception.class)
    public void invokeWebServiceTest() {
        final Object object = new Object();
        final String loggedInUser ="loggedInUser";
//        Mockito.when(ptabBusinessUtils.getLoggedInUserId()).thenReturn(loggedInUser);
        restServiceClient.invokeWebService("https://abc.com", object, HttpMethod.POST, String.class, "sbartlett");

    }

    @Test(expected = Exception.class)
    public void callExternalServiceURLTest() {
        final Object object = new Object();
        restServiceClient.callExternalServiceURL("https://abc.com", object, HttpMethod.POST, String.class);

    }
    

}
