package gov.uspto.patent.ptab.controller;

import static org.junit.Assert.assertNotEquals;

import java.math.BigDecimal;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

import gov.uspto.patent.ptab.dao.ApplicationUserDao;
import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.PtabUser;
import gov.uspto.patent.ptab.entities.ApplicationUserEntity;
import gov.uspto.patent.ptab.repository.ApplicationUserRepository;
import gov.uspto.patent.ptab.utils.RBACService;
import gov.uspto.rbac.util.AuthenticatedUser;

/**
 * Test Class to test WhoAmIController
 *
 * @author 2020 Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class WhoAmIControllerTest {

    @InjectMocks
    private WhoAmIController whoAmIController;

    @Mock
    private RBACService rbacService;

    @Mock
    private ApplicationUserRepository applicationUserRepository;

    @Mock
    private ApplicationUserDao applicationUserDao;

    @Mock
    private Authentication auths;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    Principal principal;

    @Before
    public void setUp() {

        MockitoAnnotations.initMocks(this);

    }

    /**
     * method to test GetUserDetails
     */
    @Test
    public void listUserDetailsTest() {
        PtabUser ptabUser = new PtabUser();
        ptabUser.setUserId("anonymousUser");
        Boolean kerberosEnabled = false;
        ReflectionTestUtils.setField(whoAmIController, "kerberosEnabled", kerberosEnabled);
        SecurityContextHolder.getContext().setAuthentication(auths);

        ApplicationUserEntity applicationUserEntity = new ApplicationUserEntity();
        applicationUserEntity.setUserId("userId");
        applicationUserEntity.setFirstNm("USER");
        applicationUserEntity.setLastNm("PTAB");
        Mockito.when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(Mockito.anyString(), Mockito.anyString()))
                .thenReturn("anonymousUser");
        whoAmIController.listUserDetails();
        WhoAmIController test1 = new WhoAmIController();
        WhoAmIController test2 = new WhoAmIController();
        assertNotEquals(test1, test2);

    }

    /**
     * method to test GetUserDetails
     */
    @Test
    public void listUserDetailsTestTrue() {
        Boolean kerberosEnabled = true;
        ReflectionTestUtils.setField(whoAmIController, "kerberosEnabled", kerberosEnabled);
        Mockito.when(auths.getCredentials()).thenReturn("test@mail.com");
        Mockito.when(auths.getName()).thenReturn("test-etc@mail.com");
        SecurityContextHolder.getContext().setAuthentication(auths);
        SecurityContextHolder.getContext().getAuthentication().getCredentials().getClass().getName();
        PtabUser ptabUser = new PtabUser();
        ptabUser.setUserId("anonymousUser");
        ApplicationUserEntity applicationUserEntity = new ApplicationUserEntity();
        applicationUserEntity.setApplicationUserId(new BigDecimal("45754"));
        applicationUserEntity.setFirstNm("USER");
        applicationUserEntity.setLastNm("PTAB");
        List<String> ptabLoginModalAccessList = new ArrayList<>();
        ptabLoginModalAccessList.add("test@mail.com");
        Mockito.when(applicationUserRepository.findOneByUserId(Mockito.anyString())).thenReturn(applicationUserEntity);
        whoAmIController.listUserDetails();

        WhoAmIController test1 = new WhoAmIController();
        WhoAmIController test2 = new WhoAmIController();
        assertNotEquals(test1, test2);

    }
    @AfterEach
    public void clearSecurityContext() {
        SecurityContextHolder.clearContext();
    }

    /**
     * method to test GetUserDetails
     */
    @Test
    public void getUserDetailsTest() {
        AuthenticatedUser authenticatedUser = Mockito.mock(AuthenticatedUser.class);
        Mockito.when(rbacService.getApplicationAcessUserData()).thenReturn(authenticatedUser);
        whoAmIController.getUserDetails();
        WhoAmIController test1 = new WhoAmIController();
        WhoAmIController test2 = new WhoAmIController();
        assertNotEquals(test1, test2);
    }

 
}
