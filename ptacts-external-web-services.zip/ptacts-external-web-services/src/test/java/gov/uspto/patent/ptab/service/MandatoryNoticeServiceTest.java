package gov.uspto.patent.ptab.service;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import jakarta.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.MandatoryNotice;
import gov.uspto.patent.ptab.domain.ProceedingParties;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.RestServiceClient;

@RunWith(MockitoJUnitRunner.class)
public class MandatoryNoticeServiceTest {

    @InjectMocks
    private MandatoryNoticeService mandatoryNoticeService;

    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private PTABBusinessUtils ptabBusinessUtils;
    
    @Mock
    private HttpServletRequest httpServletRequest;

    /**
     * test method to test createMandatoryNotice
     */
    @Test(expected=Exception.class)
    public void testCreateMandatoryNotice() {
        final MandatoryNotice mandatoryNotice = new MandatoryNotice();
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("mnNoticeCreateUrl");
        when(ptabBusinessUtils.getLoggedInUserId()).thenReturn("userName");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
//        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
//                Mockito.any())).thenReturn(responseObj);
//        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.OK);
        mandatoryNoticeService.createMandatoryNotice(mandatoryNotice);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).findDescriptionByTypeCodeAndValueTx(anyString(), anyString());
    }

    /**
     * test method to test updateMandatoryNoticeDetails
     */
    @Test
    public void testUpdateMandatoryNoticeDetails() {
        final ProceedingParties proceedingParties = new ProceedingParties();
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("mnNoticeCreateUrl");
        when(ptabBusinessUtils.getLoggedInUserId()).thenReturn("userName");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(responseObj);
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.OK);
        mandatoryNoticeService.updateMandatoryNoticeDetails(proceedingParties);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).findDescriptionByTypeCodeAndValueTx(anyString(), anyString());
    }

}
