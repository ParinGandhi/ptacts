package gov.uspto.patent.ptab.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import gov.uspto.patent.ptab.domain.TrialsBase;
import gov.uspto.patent.ptab.service.CaseViewerService;
import gov.uspto.patent.ptab.service.ExternalUserDocketService;
import gov.uspto.patent.ptab.trials.controller.TrialsAdapterController;
import gov.uspto.patent.ptab.trials.service.TrialsAdapterService;

/**
 * Test case for CaseViewerController
 * 
 * @author 2020 - Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class CaseViewerControllerTest {

    @InjectMocks
    private CaseViewerController caseViewerController;
    
    @Mock
    private CaseViewerService caseViewerService;
    
    @Mock
    private ExternalUserDocketService exterDocketService;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }
    
    /**
     * test method to test getCaseBasicDetails
     */
    @Test
    public void testGetCaseBasicDetails() {
        final TrialsBase trialsbase=new TrialsBase();
        Mockito.when(caseViewerService.getBasicDataDetails(Mockito.any())).thenReturn(null);
        caseViewerController.getCaseBasicDetails(trialsbase);
        Mockito.verify(caseViewerService, Mockito.atMost(1)).getBasicDataDetails(Mockito.any());
    }
    
    /**
     * test method to test getCaseData
     */
    @Test
    public void testGetCaseData() {
        Mockito.when(caseViewerService.getValidCaseData(Mockito.any(),Mockito.any())).thenReturn(null);
        caseViewerController.getCaseData("searchType","CN145");
        Mockito.verify(caseViewerService, Mockito.atMost(1)).getValidCaseData(Mockito.any(),Mockito.any());
    }
    
    
    /**
     * test method to test getRehearings
     */
    @Test
    public void testGetRehearings() {
        Mockito.when(exterDocketService.getRehearingsByPrcdNum(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(null);
        caseViewerController.getRehearings("proceedingNumber","rehearingStatus",145L);
        Mockito.verify(exterDocketService, Mockito.atMost(1)).getRehearingsByPrcdNum(Mockito.any(),Mockito.any(),Mockito.any());
    }
    
    /**
     * test method to test getAppealDetails
     */
    @Test
    public void testGetAppealDetails() {
        Mockito.when(exterDocketService.getAppealsByPrcdNum(Mockito.any(),Mockito.any())).thenReturn(null);
        caseViewerController.getAppealDetails("proceedingNumber","appealStatus");
        Mockito.verify(exterDocketService, Mockito.atMost(1)).getAppealsByPrcdNum(Mockito.any(),Mockito.any());
    }
}
