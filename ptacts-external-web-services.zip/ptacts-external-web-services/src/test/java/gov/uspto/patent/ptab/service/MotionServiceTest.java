package gov.uspto.patent.ptab.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.trials.domain.MotionDetails;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.RestServiceClient;

@RunWith(MockitoJUnitRunner.class)
public class MotionServiceTest {

    @InjectMocks
    private MotionService motionService;

    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    /**
     * test method to test getAllMotions
     */
    @Test
    public void testGetAllMotions() {
        final CaseDocumentsDataQuery caseDocumentsDataQuery = new CaseDocumentsDataQuery();
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("motionDetailsUrl");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(), anyString())).thenReturn("userName");
        when(externalServiceUriGenerator.getCaseDocumentDataQueryUrl(any(), anyString())).thenReturn("url");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.callPTABExternalServiceURL(any(), any(), any(), any(), anyString())).thenReturn(responseObj);
        motionService.getAllMotions(caseDocumentsDataQuery);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

    /**
     * test method to test getMotionDetails
     */
    @Test
    public void testGetMotionDetails() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("motionDetailsUrl");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(), anyString())).thenReturn("userName");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.callPTABExternalServiceURL(any(), any(), any(), any(), anyString())).thenReturn(responseObj);
        motionService.getMotionDetails(145L);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

    /**
     * test method to test getAllMotions
     */
    @Test
    public void testGetMotionDetailsTrials() {
        final CaseDocumentsDataQuery caseDocumentsDataQuery = new CaseDocumentsDataQuery();
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("motionDetailsUrl");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(), anyString())).thenReturn("userName");
        when(externalServiceUriGenerator.getCaseDocumentDataQueryUrl(any(), anyString())).thenReturn("url");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.callPTABExternalServiceURL(any(), any(), any(), any(), anyString())).thenReturn(responseObj);
        when(responseObj.getStatusCode()).thenReturn(HttpStatus.OK);
        final List<MotionDetails> motionList = new ArrayList<>();
        final MotionDetails motion = new MotionDetails();
        motionList.add(motion);
        final String jsonResponse = "{\n" + "  \"\": {\n" + "    \"results\": [\n" + "      {\n"
                + "        \"motionId\": \"3650\",\n" + "        \"feeAmount\": \"500\"\n" + "      }\n" + "    ]\n" + "  }\n"
                + "}";

        Mockito.when(responseObj.getBody()).thenReturn(jsonResponse);
        motionService.getMotionDetailsTrials(caseDocumentsDataQuery);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

    /**
     * test method to test getAllMotions
     */
    @Test
    public void testCreateMotion() {
        final MotionDetails motion = new MotionDetails();
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("motionDetailsUrl");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(), anyString())).thenReturn("userName");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.callPTABExternalServiceURL(any(), any(), any(), any(), anyString())).thenReturn(responseObj);
        motionService.createMotion(motion);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }
}
