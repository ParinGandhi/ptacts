package gov.uspto.patent.ptab.service;

import gov.uspto.patent.ptab.dao.PetitionClaimDao;
import gov.uspto.patent.ptab.domain.ClaimComponent;
import gov.uspto.patent.ptab.domain.ClaimMetaData;
import gov.uspto.patent.ptab.entities.*;
import gov.uspto.patent.ptab.repository.PrcdngStatyGrndClmRsnRepository;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class PetitionClainServiceTest {

    @InjectMocks
    private PetitionClaimService petitionClaimService;
    @Mock
    private PTABBusinessUtils ptabBusinessUtils;

    @Mock
    private PrcdngStatyGrndClmRsnRepository prcdngStatyGrndClmRsnRepository;

    @Mock
    private PetitionClaimDao claimsInfoDao;

    @Before
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getAllPetitionClaimsTest() {

        final ProceedingEntity proceeding = new ProceedingEntity();
        Mockito.when(ptabBusinessUtils.validateAndGetProceedingInformation(Mockito.any())).thenReturn(proceeding);
        final List<ClaimChallengeReason> claimChallengeReasonList = new ArrayList<>();
        final ClaimChallengeReason claimChallengeReason = new ClaimChallengeReason();
        final List<PrcdngStatyGrndClmRsn> prcdngStatyGrndClmRsns = new ArrayList<>();

        final PrcdngStatyGrndClmRsn prcdngStatyGrndClmRsn = new PrcdngStatyGrndClmRsn();

        final PrcdngClmStatyGround prcdngClmStatyGround = new PrcdngClmStatyGround();

        final StndStatutoryGround stndStatutoryGround = new StndStatutoryGround();
        prcdngClmStatyGround.setStndStatutoryGround(stndStatutoryGround);

        final ProceedingClaim proceedingClaim = new ProceedingClaim();
        proceedingClaim.setClaimNo("100");
        prcdngClmStatyGround.setProceedingClaim(proceedingClaim);
        prcdngStatyGrndClmRsn.setPrcdngClmStatyGround(prcdngClmStatyGround);

        final ClaimChallengeReason claimChallengeReason1 = new ClaimChallengeReason();
        prcdngStatyGrndClmRsn.setClaimChallengeReason(claimChallengeReason1);
        prcdngStatyGrndClmRsns.add(prcdngStatyGrndClmRsn);
        claimChallengeReason.setPrcdngStatyGrndClmRsns(prcdngStatyGrndClmRsns);

        claimChallengeReasonList.add(claimChallengeReason);
        Mockito.when(prcdngStatyGrndClmRsnRepository.getAllClaims(Mockito.any())).thenReturn(claimChallengeReasonList);

        Mockito.when(claimsInfoDao.getTotalClaims(Mockito.any())).thenReturn(BigDecimal.valueOf(20));

        final ClaimComponent claimComponent = petitionClaimService.getAllPetitionClaims("1234");
        assertNotNull(claimComponent);
        assertEquals(20, claimComponent.getTotalClaims());
        assertEquals("100", claimComponent.getClaimMetaData().get(0).getChallengedGroupClaimList());
    }

    @Test
    public void getFramedCLaimNumbersTest() {
        final ClaimMetaData claim = new ClaimMetaData();
        final List<String> claimNumbersList = new ArrayList<>();
        claimNumbersList.add("10");
        claimNumbersList.add("20");
        claim.setClaimNumberList(claimNumbersList);
        final List<Integer> claimNumberList = new ArrayList<>();
        claimNumberList.add(10);
        claimNumberList.add(20);
        claimNumberList.add(30);

        petitionClaimService.getFramedCLaimNumbers(claim, claimNumberList);
        assertNotNull("10,20", claim.getChallengedGroupClaimList());
    }

}
