package gov.uspto.patent.ptab.controller;

import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.service.PetitionClaimService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;


public class PetitionClaimControllerTest {

    @InjectMocks
    PetitionClaimController petitionClaimController;

    @Mock
    private PetitionClaimService claimsInfoService;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

    }

    @Test
    public void testGetClaimsInfo() {
        final CaseDocumentsDataQuery caseDocumentsDataQuery = new CaseDocumentsDataQuery();
        caseDocumentsDataQuery.setProceedingNumber("1001");
        caseDocumentsDataQuery.setCaseStatus("status");
        caseDocumentsDataQuery.setCaseType("type");
        caseDocumentsDataQuery.setDocType("doc");
        caseDocumentsDataQuery.setProceedingPartyGroupId(010L);
        caseDocumentsDataQuery.setStatus("status");
        petitionClaimController.getClaimsInfo(caseDocumentsDataQuery);
        Mockito.verify(claimsInfoService, Mockito.atMost(1)).getAllPetitionClaims(Mockito.anyString());

    }

}
