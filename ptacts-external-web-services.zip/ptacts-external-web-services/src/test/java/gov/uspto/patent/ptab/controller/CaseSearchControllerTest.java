package gov.uspto.patent.ptab.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import gov.uspto.patent.ptab.domain.CaseSearchRequest;
import gov.uspto.patent.ptab.domain.CaseSearchResponse;
import gov.uspto.patent.ptab.service.CaseSearchService;

/**
 * This is a Test class for CaseSearchControllerTest
 *
 * @author 2020 DevelopmentTeam
 *
 */
public class CaseSearchControllerTest {

    @InjectMocks
    private CaseSearchController caseSearchController;

    @Mock
    private CaseSearchService caseSearchService;

    @Before
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getCaseBasicDetailsTest() throws Exception {
        final CaseSearchRequest caseSearchRequest = new CaseSearchRequest();
        caseSearchRequest.setProceedingNumber("IPR2016-00449");
        final CaseSearchResponse response = new CaseSearchResponse();
        response.setStatusDisplay("descriptionTx");
        final List<CaseSearchResponse> list = new ArrayList<>();
        list.add(response);
        when(caseSearchService.getSearchInfo(any(), anyBoolean())).thenReturn(list);

        final List<CaseSearchResponse> responseList = caseSearchController.getCaseSearchInfo(caseSearchRequest);
        assertEquals(responseList.get(0).getStatusDisplay(), response.getStatusDisplay());
    }

}
