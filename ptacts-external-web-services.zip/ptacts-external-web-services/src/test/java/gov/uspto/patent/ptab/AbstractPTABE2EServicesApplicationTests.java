package gov.uspto.patent.ptab;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringRunner;

import com.jayway.restassured.RestAssured;

/**
 * Class is used to sets the embedded Tomcat server to start on a randomized unused port. captures the port used for the local
 * serve and sets RestAssured to use the correct port
 *
 * @RunWith annotation will invoke the SpringJUnit4ClassRunner.class to run the tests in that class instead of the runner built
 *          into JUnit.
 * @SpringBootTest is used to determine how to load and configure an ApplicationContext for integration tests.
 *
 * @author 2020 Development Team
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = PTABE2EApplication.class, webEnvironment = WebEnvironment.RANDOM_PORT)
public abstract class AbstractPTABE2EServicesApplicationTests extends AbstractTransactionalJUnit4SpringContextTests {

    @LocalServerPort
    int port;

    /**
     * Setup the port of embedded Tomcat in spring boot
     */
    @Before
    public void setup() {
        RestAssured.port = port;
    }
}
