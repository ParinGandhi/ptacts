package gov.uspto.patent.ptab.service;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import jakarta.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.CaseSearchRequest;
import gov.uspto.patent.ptab.utils.RestServiceClient;

@RunWith(MockitoJUnitRunner.class)
public class CaseSearchServiceTest {

    @InjectMocks
    private CaseSearchService caseSearchService;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    private HttpServletRequest httpServletRequest;

    @Test(expected=Exception.class)
    public void testGetSearchInfo() throws JsonMappingException, JsonProcessingException, JSONException {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("case search Url");
        when(httpServletRequest.getAttribute(anyString())).thenReturn("userIdentifier");
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("exclusion");
        final CaseSearchRequest searchRequest = new CaseSearchRequest();
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        final String jsonData = "[ {\"statusDisplay\":\"statusDisplay\"}]";
//        Mockito.when(responseObj.getBody()).thenReturn(jsonData);
//        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
//                Mockito.any())).thenReturn(responseObj);
        caseSearchService.getSearchInfo(searchRequest, false);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).findDescriptionByTypeCodeAndValueTx(anyString(), anyString());
    }
}
