package gov.uspto.patent.ptab.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.NoSuchFileException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.formula.functions.T;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import gov.uspto.patent.ptab.domain.EmployeeDetails;
import gov.uspto.patent.ptab.domain.Person;

/**
 * Test case for PTABServiceUtils
 * 
 * @author 2020 - Development Team
 *
 */
@SuppressWarnings("static-access")
@RunWith(MockitoJUnitRunner.class)
public class PTABServiceUtilsTest {

    private static final String TEST_PROPERTY = "test.property";

    @InjectMocks
    private PTABServiceUtils ptabServiceUtils;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Test method for NotFoundIfNull
     */
    @Test
    public void testNotFoundIfNullTString() {
        final String abc = "test";
        final String ptabException = ptabServiceUtils.notFoundIfNull(abc, "");
        assertEquals(abc, ptabException);
    }

    /**
     * Test method for NotFoundIfNull
     */
    @Test(expected = PTABException.class)
    public void testNotFoundIfNullTStringNull() {
        final String abc = "test";
        final String ptabException = ptabServiceUtils.notFoundIfNull(null, "");
    }

    /**
     * Test method for NotFoundIfNotNull
     */
    public void testNotFoundIfNotNull() {
        final String abc = "test";
        final String ptabException = ptabServiceUtils.notFoundIfNotNull(abc, "");
        assertEquals(abc, ptabException);
    }

    /**
     * Test method for NotFoundIfNotNulValue
     */
    @Test
    public void testNotFoundIfNotNulValue() {

        final String ptabException = ptabServiceUtils.notFoundIfNotNull(null, "");
        assertEquals(null, ptabException);
    }

    /**
     * Test method for NotFoundIfNullCollection
     */
    @Test(expected = PTABException.class)
    public void testNotFoundIfNullCollectionCollectionOfTString() {
        final Collection<Object> ptabException = ptabServiceUtils.notFoundIfNullCollection(null, "");    }

    /**
     * Test method for NotFoundIfNullCollection
     */
    @Test
    public void testNotFoundIfNullCollectionCollectionOfTStringWithValue() {
        Collection<String> data = new ArrayList<>();
        data.add("value");
        final Collection<String> ptabException = ptabServiceUtils.notFoundIfNullCollection(data, "");
        assertNotEquals("value", ptabException.toString());
    }

    /**
     * Test method for ValidateCondition
     */
    @Test
    public void testValidateCondition() {

        ptabServiceUtils.validateCondition(false, "message");
    }

    /**
     * Test method for ValidateConditionNull
     */
    @Test(expected = Exception.class)
    public void testValidateConditionNull() {

        ptabServiceUtils.validateCondition(true, "message");
    }

    /**
     * Test method for ValidateConditionAndThrowException
     */
    @Test
    public void testValidateConditionAndThrowException() {

        ptabServiceUtils.validateConditionAndThrowException(false, "message");
    }

    /**
     * Test method for ConvertBigDecimalToString
     */
    @Test
    public void testConvertBigDecimalToString() {
        String test = ptabServiceUtils.convertBigDecimalToString(null);
        test = ptabServiceUtils.convertBigDecimalToString(new BigDecimal(1));
        assertEquals("1", test);
    }

    /**
     * Test method for FetchNodeElements
     * 
     * @throws IOException
     */
    @SuppressWarnings("static-access")
    @Test(expected = JsonParseException.class)
    public void testFetchNodeElements() throws IOException {
        @SuppressWarnings("unused")
        final ObjectNode json = (ObjectNode) new ObjectMapper()
                .readTree("{\"applicationIdentifier\":[{\"applicationNumberText\":\"0986745\"}]}");
        InputStream stubInputStream = IOUtils.toInputStream("some test data for my input stream", "UTF-8");
        ptabServiceUtils.fetchNodeElements(stubInputStream);
    }

    /**
     * Test method for RemoveFile
     * 
     * @throws IOException
     */
    @SuppressWarnings("static-access")
    @Test(expected = NoSuchFileException.class)
    public void testRemoveFile() throws IOException {
        ptabServiceUtils.removeFile("src//test//resources//FILE_NAME");
    }

    /**
     * Test method for ValidateStringReqest
     */
    @SuppressWarnings("static-access")
    @Test
    public void testValidateStringReqest() {
        ptabServiceUtils.validateStringReqest("value", "message");
    }

    /**
     * Test method for ValidateStringReqestEmpty
     */
    @Test(expected = PTABException.class)
    public void testValidateStringReqestEmpty() {
        ptabServiceUtils.validateStringReqest(null, "message");
    }

    /**
     * Test method for ValidateConditionAndThrowExceptionStatus
     */
    @Test
    public void testValidateConditionAndThrowExceptionStatus() {
        ptabServiceUtils.validateConditionAndThrowExceptionStatus(false, TEST_PROPERTY, HttpStatus.OK);
    }

    /**
     * Test method for ValidateConditionAndThrowExceptionStatusNull
     */
    @Test
    public void testValidateConditionAndThrowExceptionStatusNull() {
        ptabServiceUtils.validateConditionAndThrowExceptionStatus(false, TEST_PROPERTY, HttpStatus.OK);
    }

    /**
     * Test method for NotFoundIfNullTStringString
     */
    @Test
    public void testNotFoundIfNullTStringString() {

        Object data = "test";
        ptabServiceUtils.notFoundIfNull(data, "message", "value");
        Assert.assertNotNull(ptabServiceUtils);

    }

    /**
     * Test method for NotFoundIfNullCollection
     */
    @Test
    public void testNotFoundIfNullCollectionCollectionOfTStringString() {

        ArrayList<Object> data = new ArrayList<>();
        data.add(TEST_PROPERTY);
        ptabServiceUtils.notFoundIfNullCollection(data, "messageKey", "value");
        Assert.assertNotNull(data);
    }

    /**
     * Test method for NotFoundIfNullCollectionNull
     */
    @Test(expected = Exception.class)
    public void testNotFoundIfNullCollectionNull() {

        ArrayList<Object> data = new ArrayList<>();
        data.add(TEST_PROPERTY);
        ptabServiceUtils.notFoundIfNullCollection(null, "messageKey", "value");
    }

    /**
     * Test method for NotFoundIfNullCollectionNull
     */
    @Test
    public void testNotFoundIfNullCollectionCollectionOfTStringStringNull() {

        ArrayList<Object> data = new ArrayList<>();
        data.add(TEST_PROPERTY);
        ptabServiceUtils.notFoundIfNullCollection(data, "messageKey", "value");
        Assert.assertNotNull(data);
    }

    /**
     * Test method for ValidateAndThrowExceptionWithMsg
     */
    @Test(expected = PTABException.class)
    public void testValidateAndThrowExceptionWithMsg() {
        ptabServiceUtils.validateAndThrowExceptionWithMsg(true, TEST_PROPERTY, HttpStatus.ACCEPTED);
    }

    /**
     * Test method for ValidateAndThrowExceptionWithMsgFalse
     */
    @Test
    public void testValidateAndThrowExceptionWithMsgFalse() {
        ptabServiceUtils.validateAndThrowExceptionWithMsg(false, TEST_PROPERTY, HttpStatus.ACCEPTED);
    }

    /**
     * Test method GetWorkerFullNameEmployeeDetails
     */
    @Test
    public void testGetWorkerFullNameEmployeeDetails() {
        EmployeeDetails employeeDetails = new EmployeeDetails();
        employeeDetails.setFirstName("ptab");
        employeeDetails.setLastName("user");
        employeeDetails.setMiddleName("admin");
        employeeDetails.setUserCt("WRKQUEUE");
        final String response = ptabServiceUtils.getWorkerFullName(employeeDetails);
        assertEquals("ptab user admin", response);
    }

    /**
     * Test method for GetWorkerFullNameEmployeeDetailsDot
     */
    @Test
    public void testGetWorkerFullNameEmployeeDetailsDot() {
        EmployeeDetails employeeDetails = new EmployeeDetails();
        employeeDetails.setFirstName("ptab");
        employeeDetails.setLastName("user");
        employeeDetails.setUserCt("WRKQUEUE");
        final String response = ptabServiceUtils.getWorkerFullName(employeeDetails);
        assertEquals("ptab user", response);
    }

    /**
     * Test method for GetWorkerFullNameEmployeeDetailsOtherEmtpy
     */
    @Test
    public void testGetWorkerFullNameEmployeeDetailsOtherEmtpy() {
        EmployeeDetails employeeDetails = new EmployeeDetails();
        employeeDetails.setFirstName("ptab");
        employeeDetails.setMiddleName("-");
        employeeDetails.setUserCt("WRKQUEUE");
        final String response = ptabServiceUtils.getWorkerFullName(employeeDetails);
        assertEquals("ptab -.", response);
    }

    /**
     * Test method for GetWorkerFullNameEmployeeDetailsOtherDiff
     */
    @Test
    public void testGetWorkerFullNameEmployeeDetailsOtherDiff() {
        EmployeeDetails employeeDetails = new EmployeeDetails();
        employeeDetails.setFirstName("ptab");

        employeeDetails.setMiddleName("-");
        employeeDetails.setUserCt("QUEUE");
        final String response = ptabServiceUtils.getWorkerFullName(employeeDetails);
        assertEquals("ptab -.", response);
    }

    /**
     * Test method for GetWorkerFullNameEmployeeDetailsNoUserCount
     */
    @Test
    public void testGetWorkerFullNameEmployeeDetailsNoUserCount() {
        EmployeeDetails employeeDetails = new EmployeeDetails();
        employeeDetails.setFirstName("ptab");
        employeeDetails.setLastName("user");
        employeeDetails.setMiddleName("admin");
        final String response = ptabServiceUtils.getWorkerFullName(employeeDetails);
        assertEquals("user, ptab admin", response);
    }

    /**
     * Test method for GetFirstNameLastName
     */
    @Test
    public void testGetFirstNameLastName() {
        EmployeeDetails employeeDetails = new EmployeeDetails();
        employeeDetails.setFirstName("ptab");
        employeeDetails.setLastName("user");
        employeeDetails.setUserCt("WRKQUEUE");
        final String response = ptabServiceUtils.getFirstNameLastName(employeeDetails);
        assertEquals("ptab user", response);
    }

    /**
     * Test method for GetWorkerFullNameString
     */
    @Test
    public void testGetWorkerFullNameStringStringString() {
        final String response = ptabServiceUtils.getWorkerFullName("ptab", "user", "admin");
        assertEquals("user, ptab admin", response);
    }

    /**
     * Test method for GetWorkerFullNameString
     */
    @Test
    public void testGetWorkerFullNameStringStringStringNull() {
        final String response = ptabServiceUtils.getWorkerFullName("ptab", "user", null);
        assertEquals("user, ptab ", response);
    }

    /**
     * Test method for GetWorkerFullName
     */
    @Test
    public void testGetWorkerFullNameStringStringStringCompleteNull() {
        final String response = ptabServiceUtils.getWorkerFullName(null, null, null);
        assertEquals(" ", response);
    }

    /**
     * Test method for UserMiddleNameFormat
     */
    @Test
    public void testUserMiddleNameFormat() {
        final String response = ptabServiceUtils.userMiddleNameFormat("J");
        assertEquals("J.", response);
    }

    /**
     * Test method for UserMiddleNameFormatDiff
     */
    @Test
    public void testUserMiddleNameFormatDiff() {
        final String response = ptabServiceUtils.userMiddleNameFormat("J.");
        assertEquals("J.", response);
    }

    /**
     * Test method for LeastOfTwoDates
     */
    @Test
    public void testLeastOfTwoDates() {
        Date response = ptabServiceUtils.leastOfTwoDates(new Date(), new Date());
        assertEquals((new Date()).getTime(), response.getTime());
    }

    /**
     * Test method for LeastOfTwoDatesADate
     */
    @Test
    public void testLeastOfTwoDatesADate() {
        Date response = ptabServiceUtils.leastOfTwoDates(new Date(), null);
        assertEquals(new Date(), response);
    }

    /**
     * Test method for LeastOfTwoDatesBDate
     */
    @Test
    public void testLeastOfTwoDatesBDate() {
        Date response = ptabServiceUtils.leastOfTwoDates(null, new Date());
        assertEquals(new Date(), response);
    }

    /**
     * Test method for LeastOfTwoDatesDiffDate
     */
    @Test
    public void testLeastOfTwoDatesDiffDate() {
        ptabServiceUtils.leastOfTwoDates(new Date(14 / 11 / 1980), new Date());
        // Date response = ptabServiceUtils.leastOfTwoDates(new
        // Date(14/11/1980),new Date());
        // assertEquals(new Date(31/12/1969),response);
        Assert.assertNotNull(ptabServiceUtils);
    }

    /**
     * Test method for MaxOfTwoDates
     */
    @Test
    public void testMaxOfTwoDates() {
        ptabServiceUtils.maxOfTwoDates(new Date(), new Date());

        Assert.assertNotNull(ptabServiceUtils);
    }

    /**
     * Test method for MaxOfTwoDatesADate
     */
    @Test
    public void testMaxOfTwoDatesADate() {
        Date response = ptabServiceUtils.maxOfTwoDates(new Date(), null);
        assertEquals(new Date(), response);
    }

    /**
     * Test method for MaxOfTwoDatesBDate
     */
    @Test
    public void testMaxOfTwoDatesBDate() {
        Date response = ptabServiceUtils.maxOfTwoDates(null, new Date());
        assertEquals(new Date(), response);
    }

    /**
     * Test method for MaxOfTwoDatesGivenDate
     */
    @Test
    public void testMaxOfTwoDatesGivenDate() {

        Date response = ptabServiceUtils.maxOfTwoDates(new Date(14 / 11 / 1980), new Date());
        assertEquals(new Date(), response);
    }

    /**
     * Test method for RecordExistInDB
     */
    @Test
    public void testRecordExistInDB() {
        Object data = "abc";
        ptabServiceUtils.recordExistInDB(data, "message");
        Assert.assertNotNull(ptabServiceUtils.recordExistInDB(data, "message"));
    }

    /**
     * Test method for RecordExistInDBNull
     */
    @Test(expected = PTABException.class)
    public void testRecordExistInDBNull() {
        ptabServiceUtils.recordExistInDB(null, "message");
    }

    /**
     * Test method for SafeCollection
     */
    @Test
    public void testSafeCollection() {
        Collection<Object> data = new ArrayList<>();
        data.add("value");
        ptabServiceUtils.safeCollection(data, "message");
        Assert.assertNotNull(ptabServiceUtils.safeCollection(data, "message"));
    }

    /**
     * Test method for SafeCollection
     */
    @Test(expected = PTABException.class)
    public void testSafeCollectionNull() {

        ptabServiceUtils.safeCollection(null, "message");
    }

    /**
     * Test method for ValidateRequest
     */
    @SuppressWarnings("static-access")
    @Test
    public void testValidateRequest() {
        Collection<Object> data = new ArrayList<>();
        data.add("value");
        ptabServiceUtils.validateRequest(data, "message");
    }

    /**
     * Test method for ValidateRequest
     */
    @Test(expected = PTABException.class)
    public void testValidateRequestNull() {
        Collection<Object> data = new ArrayList<>();
        data.add("value");
        ptabServiceUtils.validateRequest(null, "message");
    }

    /**
     * Test method for SafeLockControlNumber
     */
    @Test(expected = PTABException.class)
    public void testSafeLockControlNumber() {
        ptabServiceUtils.safeLockControlNumber(BigDecimal.ONE, BigDecimal.TEN);
    }

    /**
     * Test method for SafeLockControlNumberSame
     */
    @Test
    public void testSafeLockControlNumberSame() {
        ptabServiceUtils.safeLockControlNumber(BigDecimal.ONE, BigDecimal.ONE);
        Assert.assertNotNull(ptabServiceUtils);
    }

    /**
     * Test method for validateConditionWithMsg
     */
    @Test(expected = PTABException.class)
    public void testValidateConditionWithMsg() {
        ptabServiceUtils.validateConditionWithMsg(true, "message");
    }

    /**
     * Test method for validateConditionAndThrowException
     */
    @Test(expected = Exception.class)
    public void testValidateConditionAndThrowExceptionNull() {
        ptabServiceUtils.validateConditionAndThrowException(true, "message");
    }

    /**
     * Test method for validateListRequest
     */
    @Test
    public void testValidateListRequest() {
        final Collection<T> data = new ArrayList<T>();
        final T e = new T();
        data.add(e);
        ptabServiceUtils.validateListRequest(data, "message");
        Assert.assertNotNull(ptabServiceUtils);
    }

    /**
     * Test method for validateListRequestNull
     */
    @Test(expected = Exception.class)
    public void testValidateListRequestNull() {
        final Collection<T> data = new ArrayList<T>();
        ptabServiceUtils.validateListRequest(data, "message");
    }

    /**
     * Test method for validateNotEmptyListRequest
     */
    @Test(expected = Exception.class)
    public void testValidateNotEmptyListRequest() {
        final Collection<T> data = new ArrayList<T>();
        final T e = new T();
        data.add(e);
        ptabServiceUtils.validateNotEmptyListRequest(data, "message");
    }

    /**
     * Test method for checkNullAndTrim
     */
    @Test
    public void testCheckNullAndTrim() {
        ptabServiceUtils.checkNullAndTrim("message");
        Assert.assertNotNull(ptabServiceUtils);
    }

    /**
     * Test method for validateConditionWithOutPropertyAndThrowExceptionStatus
     */
    @Test(expected = Exception.class)
    public void testValidateConditionWithOutPropertyAndThrowExceptionStatus() {
        ptabServiceUtils.validateConditionWithOutPropertyAndThrowExceptionStatus(true, "message", HttpStatus.OK);
    }

    /**
     * Test method for checkNullBigDecimal
     */
    @Test
    public void testCheckNullBigDecimal() {
        ptabServiceUtils.checkNullBigDecimal("15452");
        Assert.assertNotNull(ptabServiceUtils);
    }

    /**
     * Test method for checkNullAndLong
     */
    @Test
    public void testCheckNullAndLong() {
        ptabServiceUtils.checkNullAndLong("15452");
        Assert.assertNotNull(ptabServiceUtils);
    }

    /**
     * Test method for checkNullDate
     */
    @Test
    public void testCheckNullDate() {
        ptabServiceUtils.checkNullDate(new Date(0));
        Assert.assertNotNull(ptabServiceUtils);
    }

    /**
     * Test method for checkNullAndFetchBigDecimal
     */
    @Test
    public void testCheckNullAndFetchBigDecimal() {
        final Object[] inputBig = { 0 };
        inputBig[0] = new BigDecimal(14544);
        ptabServiceUtils.checkNullAndFetchBigDecimal(inputBig, 0);
        Assert.assertNotNull(ptabServiceUtils);
    }

    /**
     * Test method for getCurrentDate
     */
    @Test
    public void testGetCurrentDate() {
        ptabServiceUtils.getCurrentDate();
        Assert.assertNotNull(ptabServiceUtils);
    }

    /**
     * Test method for checkNullAndFetchDate
     */
    @Test
    public void testCheckNullAndFetchDate() {
        ptabServiceUtils.checkNullAndFetchDate(new Date(0));
        Assert.assertNotNull(ptabServiceUtils);
    }

    /**
     * Test method for equalDates
     */
    @Test
    public void testEqualDates() {
        ptabServiceUtils.equalDates(new Date(0), new Date(0));
        Assert.assertNotNull(ptabServiceUtils);
    }

    /**
     * Test method for getWorkerFullName
     */
    @Test
    public void testGetWorkerFullName() {
        final Person person = new Person();
        person.setFirstName("FirstNm");
        person.setLastName("LasNm");
        person.setMiddleInitial("MiddleNm");
        ptabServiceUtils.getWorkerFullName(person);
        Assert.assertNotNull(ptabServiceUtils);
    }

}
