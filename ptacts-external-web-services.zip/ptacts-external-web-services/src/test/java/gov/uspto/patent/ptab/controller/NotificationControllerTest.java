package gov.uspto.patent.ptab.controller;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.service.NotificationService;

/**
 * Test Class to test NotificationController
 *
 * @author 2020 Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class NotificationControllerTest {

    private static final String NOTIFICATION_ID_2323 = "2323";

    @InjectMocks
    private NotificationController notificationController;

    @Mock
    private NotificationService notificationService;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Method used to get the Notification email details
     */
    @Test
    public void testGetNotificationEmailDetails() {
        final JsonNode nodeMock = Mockito.mock(JsonNode.class);
        Mockito.when(notificationService.getNotificationEmailDetails(Mockito.anyString())).thenReturn(nodeMock);
        final JsonNode response = notificationController.getNotificationEmailDetails(NOTIFICATION_ID_2323);
        assertNotNull(response);
    }
}
