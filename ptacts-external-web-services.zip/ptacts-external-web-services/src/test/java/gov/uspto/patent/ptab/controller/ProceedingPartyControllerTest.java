package gov.uspto.patent.ptab.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.domain.ProceedingPartyQuery;
import gov.uspto.patent.ptab.service.ProceedingPartyService;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;

/**
 * Test Class to test ProceedingPartyController
 *
 * @author 2020 Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ProceedingPartyControllerTest {

    private static final String STR_N = "N";

    private static final int INT_ONE = 1;

    private static final String PROCEEDING_NUMBER = "123";

    private static final String PTAB = "ptab";

    private static final String TEST = "test";

    @InjectMocks
    private ProceedingPartyController proceedingPartyController;

    @Mock
    private ProceedingPartyService proceedingPartyService;

    @Mock
    private PTABBusinessUtils ptabBusinessUtils;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Method used to test get next exhibit sequence details
     */
    @Test
    public void testGetNextExhibitSequenceDetails() {
        final Map<String, String> map = new HashMap<>();
        map.put(TEST, PTAB);
        Mockito.when(proceedingPartyService.getNextExhibitNumber(Mockito.anyString())).thenReturn(map);
        final CaseDocumentsDataQuery caseDocumentsDataQuery = new CaseDocumentsDataQuery();
        caseDocumentsDataQuery.setProceedingNumber(PROCEEDING_NUMBER);
        final Map<String, String> response = proceedingPartyController.getNextExhibitSequenceDetails(caseDocumentsDataQuery);
        assertEquals(PTAB, response.get(TEST));
    }

    /**
     * Method used to test save proceeding party details
     */
    @Test
    public void testSaveProceedingPartyDetails() {

        Mockito.doNothing().when(proceedingPartyService).savePartyDetails(Mockito.any(ObjectNode.class), Mockito.anyString());
        final ObjectNode mock = Mockito.mock(ObjectNode.class);
        proceedingPartyController.saveProceedingPartyDetails(mock, STR_N);
        Mockito.verify(proceedingPartyService, Mockito.times(INT_ONE)).savePartyDetails(mock, STR_N);

    }

    /**
     * Method used to test update proceeding party details
     */
    @Test
    public void testUpdateProceedingPartyDetails() {

        Mockito.doNothing().when(proceedingPartyService).updatePartyDetails(Mockito.any(ObjectNode.class));
        final ObjectNode proceedingParties = Mockito.mock(ObjectNode.class);
        proceedingPartyController.updateProceedingPartyDetails(proceedingParties);
        Mockito.verify(proceedingPartyService, Mockito.times(INT_ONE)).updatePartyDetails(proceedingParties);
    }

    /**
     * Method used to test perform counsel switch
     */
    @Test
    public void testPerformCounselSwitch() {

        final ObjectNode proceedingParties = Mockito.mock(ObjectNode.class);
        Mockito.when(proceedingPartyService.performCounselSwitch(Mockito.any(ObjectNode.class), Mockito.anyBoolean()))
                .thenReturn(proceedingParties);
        proceedingPartyController.performCounselSwitch(proceedingParties, true);
        Mockito.verify(proceedingPartyService, Mockito.times(INT_ONE)).performCounselSwitch(proceedingParties, true);
    }

    /**
     * Method used to test perform counsel switch
     */
    @Test
    public void testDeleteProceedingPartyDetails() {

        Mockito.doNothing().when(proceedingPartyService).deletePartyDetails(Mockito.any(ProceedingPartyQuery.class));
        final ProceedingPartyQuery proceedingPartyQuery = new ProceedingPartyQuery();
        proceedingPartyController.deleteProceedingPartyDetails(proceedingPartyQuery);
        Mockito.verify(proceedingPartyService, Mockito.times(INT_ONE)).deletePartyDetails(proceedingPartyQuery);
    }

    /**
     * Method used to test perform counsel switch
     */
    @Test
    public void testGetProceedingPartyDetails() {

        final JsonNode node = Mockito.mock(JsonNode.class);
        Mockito.when(proceedingPartyService.getPrcdCounselInfo(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
                .thenReturn(node);
        proceedingPartyController.getPrcdCounselInfo("TRIALS", TEST, TEST);
        Mockito.verify(proceedingPartyService, Mockito.times(INT_ONE)).getPrcdCounselInfo("TRIALS", TEST, TEST);
    }

}
