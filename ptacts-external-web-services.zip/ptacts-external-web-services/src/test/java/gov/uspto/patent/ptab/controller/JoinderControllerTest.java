package gov.uspto.patent.ptab.controller;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import gov.uspto.patent.ptab.domain.RelatedProceeding;
import gov.uspto.patent.ptab.service.JoinderService;

@RunWith(MockitoJUnitRunner.class)
public class JoinderControllerTest {

    @InjectMocks
    JoinderController joinderController;

    @Mock
    private JoinderService joinderService;

    @Mock
    List<RelatedProceeding> relatedProceedings;

    @Mock
    RelatedProceeding relatedProceeding;

    @Before
    public void SetUp() {
        relatedProceedings = new ArrayList<>();
        relatedProceeding = new RelatedProceeding();
        relatedProceeding.setRelatedProceedingNo("123");
        relatedProceeding.setProceedingNo("123");
        relatedProceeding.setDescriptionText("test");
        relatedProceedings.add(relatedProceeding);
    }

    @Test
    public void getRelatedCasesByCaseNumberTest() {

        Mockito.when(joinderService.getRelatedCasesByCaseNumber(Mockito.any())).thenReturn(relatedProceedings);
        joinderController.getRelatedCasesByCaseNumber("123");
        Assert.assertNotNull(joinderController.getRelatedCasesByCaseNumber("123"));
    }

    @Test
    public void getJoinderInformationTest() {

        Mockito.when(joinderService.getJoinderInformation(Mockito.any())).thenReturn(relatedProceedings);
        joinderController.getJoinderInformation("123");
        Assert.assertNotNull(joinderController.getJoinderInformation("123"));
    }
}
