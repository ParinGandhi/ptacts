package gov.uspto.patent.ptab.service;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.ProceedingAppealInfo;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.RestServiceClient;

@RunWith(MockitoJUnitRunner.class)
public class ProceedingAppealServiceTest {

    @InjectMocks
    private ProceedingAppealService proceedingAppealService;

    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private PTABBusinessUtils ptabBusinessUtils;

    /**
     * test method to test createProceedingAppealInfo
     */
    @Test
    public void testCreateProceedingAppealInfo() {
        final ProceedingAppealInfo proceedingAppealInfo = new ProceedingAppealInfo();
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("prcdAppealCreateUrl");
        when(ptabBusinessUtils.getLoggedInUserId()).thenReturn("userName");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(responseObj);
        proceedingAppealService.createProceedingAppealInfo(proceedingAppealInfo);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).findDescriptionByTypeCodeAndValueTx(anyString(), anyString());
    }
}
