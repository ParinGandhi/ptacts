package gov.uspto.patent.ptab.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import gov.uspto.patent.ptab.domain.LoginQuery;
import gov.uspto.patent.ptab.domain.UserLoginDetails;
import gov.uspto.patent.ptab.service.LoginService;

/**
 * Test Class to test LoginController
 *
 * @author 2020 Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class LoginControllerMockTest {

    private static final String EMAIL_ID = "test@test.com";

    @InjectMocks
    private LoginController loginController;

    @Mock
    private LoginService loginService;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Method used to test the get user details functionality
     */
    @Test
    public void testGetUserDetails() {
        final UserLoginDetails userLoginDetails = new UserLoginDetails();
        userLoginDetails.setEmailId(EMAIL_ID);
        Mockito.when(loginService.getUserDetails(Mockito.any(LoginQuery.class))).thenReturn(userLoginDetails);
        final UserLoginDetails response = loginController.getUserDetails(new LoginQuery());
        assertEquals(userLoginDetails.getEmailId(), response.getEmailId());

    }

}
