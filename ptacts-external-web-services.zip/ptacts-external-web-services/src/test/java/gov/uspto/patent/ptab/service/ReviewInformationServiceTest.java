package gov.uspto.patent.ptab.service;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonProcessingException;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.utils.RestServiceClient;

@RunWith(MockitoJUnitRunner.class)
public class ReviewInformationServiceTest {

    @InjectMocks
    private ReviewInformationService reviewInformationService;
    
    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private ExternalUserService externalUserService;
    
    /**
     * test method to test getReviewInformationPATENTOWNER
     */
    @Test
    public void testGetReviewInformationPATENTOWNER() throws JsonProcessingException{
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("externalArtifactUpdateUrl");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(),anyString())).thenReturn("systemusername");
        when(externalUserService.getPrcdPartyGroupType(anyString())).thenReturn("PATENTOWNER");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);    
        final String jsonData =  "[ {\"party\":\"PATENTOWNER\"}]";
        Mockito.when(responseObj.getBody()).thenReturn(jsonData);  
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        reviewInformationService.getReviewInformation("postingReferenceText");
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).findDescriptionByTypeCodeAndValueTx(anyString(),anyString());
    }
    
    /**
     * test method to test getReviewInformationPETITIONER
     */
    @Test
    public void testGetReviewInformationPETITIONER() throws JsonProcessingException{
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString())).thenReturn("externalArtifactUpdateUrl");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(),anyString())).thenReturn("systemusername");
        when(externalUserService.getPrcdPartyGroupType(anyString())).thenReturn("PETITIONER");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);    
        final String jsonData =  "[ {\"party\":\"PETITIONER\"}]";
        Mockito.when(responseObj.getBody()).thenReturn(jsonData);  
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        reviewInformationService.getReviewInformation("postingReferenceText");
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).findDescriptionByTypeCodeAndValueTx(anyString(),anyString());
    }
}
