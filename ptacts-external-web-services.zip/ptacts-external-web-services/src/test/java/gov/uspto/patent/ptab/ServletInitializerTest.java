package gov.uspto.patent.ptab;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.springframework.boot.builder.SpringApplicationBuilder;

/**
 * Test class for {@link ServletInitializer}.
 *
 * @author 2020 development team
 */
public class ServletInitializerTest {

    private ServletInitializer servletInitializer;

    /**
     * Test setup for ServletInitializer
     */
    @Before
    public void setUp() {
        servletInitializer = new ServletInitializer();
    }

    /**
     * test the servlet configurations
     */
    @Test
    public void testConfigure() {
        assertNotNull(servletInitializer.configure(new SpringApplicationBuilder()));
    }
}