package gov.uspto.patent.ptab.dao;

import gov.uspto.patent.ptab.domain.StatutoryGround;
import gov.uspto.patent.ptab.entities.StndStatutoryGround;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

/**
 * Tests for StatutoryGroundsDAO
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class StatutoryGroundsDAOTest {

    @InjectMocks
    StatutoryGroundsDAO statutoryGroundsDAO;
    @Mock
    private final SessionFactory sessionFactory = mock(SessionFactory.class);

    private Session session;

    @SuppressWarnings("rawtypes")
    private Query query;

    /**
     * Method used to initialize mock objects
     */
    @Before
    public void initMocks() {

        MockitoAnnotations.initMocks(this);
    }

    /**
     * This method is used to mock session and query objects.
     */
    private void mockSession() {

        session = Mockito.mock(Session.class);
        query = Mockito.mock(Query.class);
        Mockito.when(sessionFactory.getCurrentSession()).thenReturn(session);
        Mockito.when(session.createNamedQuery(Mockito.anyString(), Mockito.any())).thenReturn(query);
    }

    @Test
    public void testGetStatutoryGrounds(){
        mockSession();
        List<StndStatutoryGround> stndStatutoryGrounds = new ArrayList<>();
        StndStatutoryGround stndStatutoryGround = new StndStatutoryGround();
        stndStatutoryGround.setStatutoryGroundId(123L);
        stndStatutoryGrounds.add(stndStatutoryGround);

        Mockito.when(query.getResultList()).thenReturn(stndStatutoryGrounds);
        List<StatutoryGround> statutoryGround = statutoryGroundsDAO.getStatutoryGrounds();
        assertNotNull(statutoryGround);
    }

}
