package gov.uspto.patent.ptab.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import gov.uspto.patent.ptab.domain.ReferenceQuery;
import gov.uspto.patent.ptab.domain.ReferenceType;
import gov.uspto.patent.ptab.entities.StndDocumentType;
import gov.uspto.patent.ptab.entities.StndMotionType;
import gov.uspto.patent.ptab.entities.StndProceedingType;

@RunWith(MockitoJUnitRunner.class)
public class ReferenceDAOTest {

    @InjectMocks
    private ReferenceDAO referenceDAO;

    @Mock
    private final SessionFactory sessionFactory = Mockito.mock(SessionFactory.class);
    
    @Mock
    private EntityManager entityManager;
    
    private Session session;
    @SuppressWarnings("rawtypes")
    private Query query;

    @Before
    public void initMocks() {

        MockitoAnnotations.initMocks(this);
    }
    
    /**
     * test method to test getTrialTypeDetails
     */
    @Test
    public void testGetTrialTypeDetails() {
        mockSession();
        Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
        final List<StndProceedingType> stndProceedingTypeList = new ArrayList<>();
        final StndProceedingType stndProceedingType=new StndProceedingType();
        stndProceedingTypeList.add(stndProceedingType);
        stndProceedingType.setProceedingTypeCd("ProceedingTypeCd");
        stndProceedingType.setProceedingTypeDescTx("ProceedingTypeDescTx");
        stndProceedingType.setProceedingTypeId(1457L);
        Mockito.when(query.getResultList()).thenReturn(stndProceedingTypeList);
        referenceDAO.getTrialTypeDetails("trialType");
        Mockito.verify(entityManager, Mockito.atMost(1)).createQuery(Mockito.anyString());
    }
    
    /**
     * test method to test getDocumentTypes
     */
    @Test
    public void testGetDocumentTypes() {
        mockSession();
        final ReferenceQuery referenceQuery=new ReferenceQuery();
        referenceQuery.setCategoryType("referenceQuery");
        Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
        final List<StndDocumentType> stndDocumentTypeList = new ArrayList<>();
        final StndDocumentType stndDocumentType=new StndDocumentType();
        stndDocumentTypeList.add(stndDocumentType);
        stndDocumentType.setDocumentTypeCd("DocumentTypeCd");
        stndDocumentType.setDocumentTypeNm("DocumentTypeNm");
        stndDocumentType.setDocumentTypeId(145L);
        stndDocumentType.setDisplayName("DisplayName");
        stndDocumentType.setSignificantIndicator("SignificantIndicator");
        stndDocumentType.setJoinderCheckInd("JoinderCheckInd");
        stndDocumentType.setCustomAttributes("CustomAttributes");
        stndDocumentType.setCustomAttributes("CustomAttributes");
        Mockito.when(query.getResultList()).thenReturn(stndDocumentTypeList);
        referenceDAO.getDocumentTypes(referenceQuery);
        Mockito.verify(entityManager, Mockito.atMost(1)).createQuery(Mockito.anyString());
    }
    
    /**
     * test method to test getDocumentTypes CategoryTypeNull
     */
    @Test
    public void testGetDocumentTypesCategoryTypeNull() {
        mockSession();
        final ReferenceQuery referenceQuery=new ReferenceQuery();
        Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
        referenceDAO.getDocumentTypes(referenceQuery);
        Mockito.verify(entityManager, Mockito.atMost(1)).createQuery(Mockito.anyString());
    }
    
    /**
     * test method to test getDocumentTypeDetails
     */
    @Test
    public void testGetDocumentTypeDetails() {
        mockSession();
        final ReferenceQuery referenceQuery=new ReferenceQuery();
        Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
        referenceDAO.getDocumentTypes(referenceQuery);
        Mockito.verify(entityManager, Mockito.atMost(1)).createQuery(Mockito.anyString());
    }
    
    /**
     * test method to test getMotionTypes
     */
    @Test
    public void testGetMotionTypes() {
        mockSession();
        Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
        referenceDAO.getMotionTypes();
        Mockito.verify(entityManager, Mockito.atMost(1)).createQuery(Mockito.anyString());
    }
    
    /**
     * test method to test getAllMotionTypes
     */
    @Test
    public void testGetAllMotionTypess() {
        mockSession();
        final List<StndMotionType> stndMotionTypeList=new ArrayList<>();
        final StndMotionType stndMotionType=new StndMotionType();
        stndMotionTypeList.add(stndMotionType);
        stndMotionType.setMotionTypeNm("MotionTypeNm");
        stndMotionType.setDescriptionTx("DescriptionTx");
        stndMotionType.setMotionTypeId(145L);
        referenceDAO.getAllMotionTypes(stndMotionTypeList);
        Mockito.verify(entityManager, Mockito.atMost(1)).createQuery(Mockito.anyString());
    }
    
    
    
    /**
     * Test method to mock session
     */
    private void mockSession() {

        session = Mockito.mock(Session.class);
        query = Mockito.mock(Query.class);

    }
}
