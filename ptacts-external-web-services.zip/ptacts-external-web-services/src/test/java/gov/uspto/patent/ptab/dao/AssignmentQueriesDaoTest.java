package gov.uspto.patent.ptab.dao;

import static org.mockito.Mockito.mock;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class AssignmentQueriesDaoTest {

    @InjectMocks
    private AssignmentQueriesDao assignmentQueriesDao;

    @Mock
    private final SessionFactory sessionFactory = mock(SessionFactory.class);

    private Session session;
    @SuppressWarnings("rawtypes")
    private Query query;

    /**
     * Method used to initialize mock objects
     */
    @Before
    public void initMocks() {

        MockitoAnnotations.initMocks(this);
    }

    /**
     * test method to test fetchFullNamesOfEmployee
     */
    @Test(expected = NullPointerException.class)
    public void testFetchFullNamesOfEmployee() {
        session = Mockito.mock(Session.class);
        query = Mockito.mock(Query.class);
        Mockito.when(sessionFactory.getCurrentSession()).thenReturn(session);
        assignmentQueriesDao.fetchFullNamesOfEmployee("12415", "154548");
        Mockito.verify(session, Mockito.atMost(1)).createNamedQuery(Mockito.anyString());
    }
}
