package gov.uspto.patent.ptab.dao;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import gov.uspto.patent.ptab.domain.CodeReferenceLookup;
import gov.uspto.patent.ptab.entities.CodeReferenceEntity;
import gov.uspto.patent.ptab.repository.CodeReferenceRepository;

/**
 * Test case for CodeReferenceDao
 * 
 * @author 2020 - Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class CodeReferenceDaoTest {

    private static final String VALUE_TX = "valueTx";
    private static final String TYPE_CD = "TypeCd";
    private static final String TEST_DESC = "TestDesc";
    
    @InjectMocks
    private CodeReferenceDao codeReferenceDao;
    
    @Mock
    private CodeReferenceRepository codeReferenceRepository;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Test method for FindDescriptionByTypeCodeAndValueTx
     */
    @Test
    public void testFindDescriptionByTypeCodeAndValueTx() {
        final CodeReferenceEntity codeReferenceEntity = new CodeReferenceEntity();
        codeReferenceEntity.setDescriptionTx(TEST_DESC);
        Mockito.when(codeReferenceRepository.findDescriptionByTypeCdAndValueTx(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(codeReferenceEntity);

        final String response = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(TYPE_CD, VALUE_TX);
        assertEquals(TEST_DESC, response);
        
    }
    
    /**
     * Test method for FindDescriptionByTypeCodeAndValueTxEmpty
     */
    @Test
    public void testFindDescriptionByTypeCodeAndValueTxEmpty() {
        final CodeReferenceEntity codeReferenceEntity = new CodeReferenceEntity();
        codeReferenceEntity.setDescriptionTx(null);
        Mockito.when(codeReferenceRepository.findDescriptionByTypeCdAndValueTx(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(codeReferenceEntity);

        final String response = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(TYPE_CD, VALUE_TX);
        assertEquals(null, response);
        
    }

    /**
     * Test method for GetFirstDescCodeRefByTypeCdAndValue
     */
    @Test
    public void testGetFirstDescCodeRefByTypeCdAndValue() {
        final CodeReferenceEntity codeReferenceEntity = new CodeReferenceEntity();
        codeReferenceEntity.setDescriptionTx(TEST_DESC);
        Mockito.when(codeReferenceRepository.findById(Mockito.any())).thenReturn(Optional.of(codeReferenceEntity));
                
        final String response = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(TYPE_CD, VALUE_TX);
        assertEquals(TEST_DESC, response);
    }

    /**
     * Test method for FetchCodeReferenceViaTypeCode
     */
    @Test
    public void testFetchCodeReferenceViaTypeCode() {
        
        List<CodeReferenceEntity> codeReferenceEntityList = new ArrayList<>();
        CodeReferenceEntity codeReferenceEntity = new CodeReferenceEntity();
        codeReferenceEntity.setDescriptionTx(TEST_DESC);
        codeReferenceEntityList.add(codeReferenceEntity);
        Mockito.when(codeReferenceRepository.findAllByTypeCdOrderByValueTx(Mockito.anyString()))
                .thenReturn(codeReferenceEntityList );

        final List<CodeReferenceLookup> response = codeReferenceDao.fetchCodeReferenceViaTypeCode(TYPE_CD);
        assertEquals(TEST_DESC, response.get(0).getDescriptionText());
        
    }

}
