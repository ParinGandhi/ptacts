package gov.uspto.patent.ptab.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.mock.http.MockHttpInputMessage;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;

public class PtabControllerAdviceTest {

    private final PtabControllerAdvice ptabControllerAdvice = new PtabControllerAdvice();

    @Test
    public void handlePtabCustomExceptionTest() {
        final PTABException exception = new PTABException(HttpStatus.BAD_REQUEST, "Bad Data");
        final ResponseEntity responseEntity = ptabControllerAdvice.handlePtabCustomException(exception);
        assertEquals("Bad Data", responseEntity.getBody());
    }

    // @Test
    // public void handleConstraintViolationTest() {
    // final Set<ConstraintViolation<?>> constraintViolations = new HashSet<>();
    // final ConstraintViolation constraintViolation = new ConstraintViolationImpl(null, null, null, null, null, null, null,
    // null, null);
    // constraintViolations.add(constraintViolation);
    // final ConstraintViolationException exception = new ConstraintViolationException(constraintViolations);
    // final ErrorPayload responseEntity = ptabControllerAdvice.handleConstraintViolation(exception);
    // assertEquals("Mandatory Input is Missing: null", responseEntity.getMessage());
    // //assertEquals("Mandatory Input is Missing", responseEntity.getMessage());
    // }

    @Test
    public void handleMissingServletRequestParameterExceptionTest() {
        final MissingServletRequestParameterException exception = new MissingServletRequestParameterException(null, null);
        final ErrorPayload errorPayload = ptabControllerAdvice.handleMissingServletRequestParameterException(exception);
        assertEquals("Mandatory request parameter is missing", errorPayload.getMessage());
    }

    @Test
    public void handleEmptyJSONTest() {
        final HttpInputMessage httpInputMessage = new MockHttpInputMessage("Bad Data".getBytes());

        final HttpMessageNotReadableException exception = new HttpMessageNotReadableException("Error", httpInputMessage);
        final ErrorPayload errorPayload = ptabControllerAdvice.handleEmptyJSON(exception);
        assertEquals("JSON cannot be empty", errorPayload.getMessage());
    }

    @Test
    public void handleDataIntegrityViolationTest() {

        final DataIntegrityViolationException exception = new DataIntegrityViolationException("Error");
        final ErrorPayload errorPayload = ptabControllerAdvice.handleDataIntegrityViolation(exception);
        assertEquals("Issue with Data :Error", errorPayload.getMessage());
    }

    @Test
    public void handleInvalidDataAccessTest() {

        final InvalidDataAccessApiUsageException exception = new InvalidDataAccessApiUsageException("Error");
        final ErrorPayload errorPayload = ptabControllerAdvice.handleInvalidDataAccess(exception);
        assertEquals("Please enter valid Reference/Parent Key Data", errorPayload.getMessage());
    }

    @Test
    public void handleHttpRequestMethodNotSupportedExceptionTest() {

        final HttpRequestMethodNotSupportedException exception = new HttpRequestMethodNotSupportedException("Error");
        final ErrorPayload errorPayload = ptabControllerAdvice.handleHttpRequestMethodNotSupportedException(exception);
        assertEquals("Request method 'Error' is not supported", errorPayload.getMessage());
    }

    @Test
    public void handleExceptionTest() {

        final Exception exception = new Exception("Error");
        final ErrorPayload errorPayload = ptabControllerAdvice.handleException(exception);
        assertEquals("Application System Error.Please Contact PTAB Support Team", errorPayload.getMessage());
    }

}
