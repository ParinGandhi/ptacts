package gov.uspto.patent.ptab.controller;

import gov.uspto.patent.ptab.domain.ProceedingQWithDecision;
import gov.uspto.patent.ptab.domain.ProceedingQWithUserDetails;
import gov.uspto.patent.ptab.domain.QualatativeQuestioner;
import gov.uspto.patent.ptab.service.QualitativeQuestionsServices;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;


@RunWith(MockitoJUnitRunner.class)
public class QualitativeQuestionsControllerTest {

    public static final String TEST_USER = "test-user";
    @InjectMocks
    QualitativeQuestionsController ctrl;

    @Mock
    QualitativeQuestionsServices qqService;

    @Mock
    PTABBusinessUtils ptabBusinessUtils;

    @Before
    public void setUp() throws Exception {
        when(ptabBusinessUtils.getLoggedInUserId()).thenReturn(TEST_USER);
    }

    @AfterEach
    public void verifyUserLoggedInCall(){
        verify(ptabBusinessUtils,atMost(1)).getLoggedInUserId();
    }

    @Test
    public void getConfiguredQuestionersTest(){
        //to avoid unnecessary stubbing
        ptabBusinessUtils.getLoggedInUserId();

        List<QualatativeQuestioner> expected = new ArrayList<>();
        when(qqService.getCOnfiguredQuestions()).thenReturn(expected);
        var res = ctrl.getConfiguredQuestioners();
        Assert.assertNotNull(res);

    }

    @Test
    public void getQuestionsBasedOnProceedingNumberAndUserIdTest(){
        List<ProceedingQWithDecision> expected = new ArrayList<>();
        when(qqService.getQuestionsBasedOnProceedingNumberAndUserId(Mockito.eq(TEST_USER),any())).thenReturn(expected);
        var res = ctrl.getQuestionsBasedOnProceedingNumberAndUserId("");
        Assert.assertEquals(expected,res.getBody());
    }

    @Test
    public void getQuestionsBasedOnProceedingNumberTest(){
       ProceedingQWithUserDetails expected = new ProceedingQWithUserDetails();
        when(qqService.getQuestionsBasedOnProceedingNumber(Mockito.eq(TEST_USER),any())).thenReturn(expected);
        var res = ctrl.getQuestionsBasedOnProceedingNumber("");
        Assert.assertEquals(expected,res.getBody());
    }


    @Test
    public void createProceedingQualatativeTest(){
        List<ProceedingQWithDecision> expected  = new ArrayList<>();
        when(qqService.createProceedingQualatative(Mockito.eq(TEST_USER),any())).thenReturn(expected);
        var res = ctrl.createProceedingQualatative(new ArrayList<>());
        Assert.assertEquals(expected,res);
    }

    @Test
    public void updateProceedingQualatativeTest(){
        List<ProceedingQWithDecision> expected = new ArrayList<>();
        when(qqService.updateProceedingQualatative(Mockito.eq(TEST_USER),any(),
                Mockito.eq(0))).thenReturn(expected);
        var res = ctrl.updateProceedingQualatative(new ArrayList<>());
        Assert.assertEquals(expected,res);

    }
    @Test
    public void updateProceedingQualatativeAnswerTest(){
        List<ProceedingQWithDecision> expected = new ArrayList<>();
        when(qqService.updateProceedingQualatative(Mockito.eq(TEST_USER),
                any(), Mockito.eq(1))).thenReturn(expected);
        var res = ctrl.updateProceedingQualatativeQFinalAnswer(new ArrayList<>());
        Assert.assertEquals(expected,res);

    }
}