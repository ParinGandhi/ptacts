package gov.uspto.patent.ptab.utils;

import org.junit.Test;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ErrorPayloadTest {

    @Test
    public void constructorTest() {
        ErrorPayload errorPayload = new ErrorPayload("message");
        assertEquals("message", errorPayload.getMessage());

        errorPayload = new ErrorPayload("message", 10, 20);
        assertEquals("message", errorPayload.getMessage());
        assertEquals(10, errorPayload.getErrorCode());
        assertEquals(20, errorPayload.getReasonCode());
        assertNull(errorPayload.getSystemMessage());

    }

}
