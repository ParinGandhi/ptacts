package gov.uspto.patent.ptab.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.PetitionBasicInformation;
import gov.uspto.patent.ptab.domain.PetitionQuery;
import gov.uspto.patent.ptab.entities.ExternalUser;
import gov.uspto.patent.ptab.repository.ExternalUserRepository;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;

@RunWith(MockitoJUnitRunner.class)
public class PetitionServiceTest {

    @InjectMocks
    private PetitionService petitionService;

    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    private ExternalUserRepository externalUserRepository;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Mock
    private PTABBusinessUtils ptabBusinessUtils;

    /**
     * test method to test createPetition
     */
    @Test
    public void testCreatePetition() {
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(), anyString())).thenReturn("systemusername");
        final ExternalUser externalUser = new ExternalUser();
        final PetitionBasicInformation petitionBasicInformation = new PetitionBasicInformation();
        petitionBasicInformation.setSubmitterEmailAddress("submitterEmailAddress");
        when(externalUserRepository.findAllByEmail(anyString())).thenReturn(externalUser);
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.callPTABExternalServiceURL(any(), any(), any(), any(), anyString())).thenReturn(responseObj);
        when(responseObj.getStatusCode()).thenReturn(HttpStatus.OK);
        when(ptabBusinessUtils.getLoggedInUserId()).thenReturn("loggedUsedId");
        petitionService.createPetition(petitionBasicInformation);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

    /**
     * test method to test getPetitionDetails
     */
    @Test
    public void testGetPetitionDetails() {
        final PetitionQuery petitionQuery = new PetitionQuery();
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString()))
                .thenReturn("externalArtifactUpdateUrl");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(), anyString())).thenReturn("systemusername");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.callPTABExternalServiceURL(any(), any(), any(), any(), anyString())).thenReturn(responseObj);
        petitionService.getPetitionDetails(petitionQuery);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

    /**
     * test method to test getPetitionDetails
     */
    @Test
    public void testDeletePetitionDetails() {
        final PetitionQuery petitionQuery = new PetitionQuery();
        petitionQuery.setProceedingNumberText("PNT1454");
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString()))
                .thenReturn("petitionCommonServiceUrl");
        when(ptabBusinessUtils.getLoggedInUserId()).thenReturn("userName");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.invokeWebService(any(), any(), any(), any(), anyString())).thenReturn(responseObj);
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.OK);
        petitionService.deletePetitionDetails(petitionQuery);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

    /**
     * test method to test getPetitionDetailsHttp400
     */
    @Test(expected = PTABException.class)
    public void testDeletePetitionDetailsHttp400() {
        final PetitionQuery petitionQuery = new PetitionQuery();
        petitionQuery.setProceedingNumberText("PNT1454");
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString()))
                .thenReturn("petitionCommonServiceUrl");
        when(ptabBusinessUtils.getLoggedInUserId()).thenReturn("userName");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.invokeWebService(any(), any(), any(), any(), anyString())).thenReturn(responseObj);
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
        petitionService.deletePetitionDetails(petitionQuery);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

    /**
     * test method to test getPetitionDetailsHttp500
     */
    @Test(expected = PTABException.class)
    public void testDeletePetitionDetailsHttp500() {
        final PetitionQuery petitionQuery = new PetitionQuery();
        petitionQuery.setProceedingNumberText("PNT1454");
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString()))
                .thenReturn("petitionCommonServiceUrl");
        when(ptabBusinessUtils.getLoggedInUserId()).thenReturn("userName");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.invokeWebService(any(), any(), any(), any(), anyString())).thenReturn(responseObj);
        Mockito.when(responseObj.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        petitionService.deletePetitionDetails(petitionQuery);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }
}
