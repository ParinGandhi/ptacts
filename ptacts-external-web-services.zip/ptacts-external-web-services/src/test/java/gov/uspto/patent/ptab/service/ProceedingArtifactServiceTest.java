package gov.uspto.patent.ptab.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.dao.UserPermissionsDao;
import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.domain.Petition;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.entities.ProceedingEntity;
import gov.uspto.patent.ptab.repository.ProceedingRepository;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.RestServiceClient;

@RunWith(MockitoJUnitRunner.class)
public class ProceedingArtifactServiceTest {

    @InjectMocks
    private ProceedingArtifactService proceedingArtifactService;

    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private PTABBusinessUtils ptabBusinessUtils;

    @Mock
    private ExternalUserService externalUserService;
    
    @Mock
    private ProceedingRepository proceedingRepository;
    
    @Mock
    private UserPermissionsDao userPermissionsDao;

    /**
     * test method to test getNextPaperSequenceIdentifier
     */
    @Test
    public void testGetNextPaperSequenceIdentifier() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("motionDetailsUrl");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        final CaseDocumentsDataQuery caseDocumentsDataQuery = new CaseDocumentsDataQuery();
        proceedingArtifactService.getNextPaperSequenceIdentifier(caseDocumentsDataQuery);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

    /**
     * test method to test getAllArtifactsConfidentialityInY
     */
    @Test
    public void testGetAllArtifactsConfidentialityInY() {
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        final ProceedingEntity proceedingEntity=new ProceedingEntity();
        proceedingEntity.setConfidentialityIn("Y");
        when(proceedingRepository.getProceedingDetails(any())).thenReturn(proceedingEntity);
        final CaseDocumentsDataQuery caseDocumentsDataQuery = new CaseDocumentsDataQuery();
        caseDocumentsDataQuery.setProceedingNumber("CNPN1457");
        final String jsonData = "[ {\"availability\":\"Board\",\"filingParty\":\"filingParty\"}]";
        final List<PetitionDocument> petitionDocumentList = new ArrayList<>();
        final PetitionDocument petitionDocument = new PetitionDocument();
        petitionDocumentList.add(petitionDocument);
        proceedingArtifactService.getAllArtifacts(caseDocumentsDataQuery, false);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }
    
    /**
     * test method to test getAllArtifacts
     */
    @Test(expected = Exception.class)
    public void testGetAllArtifacts() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("motionDetailsUrl");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        final ProceedingEntity proceedingEntity=new ProceedingEntity();
        proceedingEntity.setConfidentialityIn("confidentialityIn");
        when(proceedingRepository.getProceedingDetails(any())).thenReturn(proceedingEntity);
        when(externalUserService.getPrcdPartyGroupType(anyString())).thenReturn("prcdPartyGrpType");
        final CaseDocumentsDataQuery caseDocumentsDataQuery = new CaseDocumentsDataQuery();
        caseDocumentsDataQuery.setProceedingNumber("CNPN1457");
        final String jsonData = "[ {\"availability\":\"Board\",\"filingParty\":\"filingParty\"}]";
        when(restServiceClient.callExternalServiceURL(any(), any(), any(), any())).thenReturn(jsonData);
        final List<PetitionDocument> petitionDocumentList = new ArrayList<>();
        final PetitionDocument petitionDocument = new PetitionDocument();
        petitionDocumentList.add(petitionDocument);
        proceedingArtifactService.getAllArtifacts(caseDocumentsDataQuery, false);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

    /**
     * test method to test createProceedingArtifactForExternal
     */
    @Test
    public void testCreateProceedingArtifactForExternal() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString()))
                .thenReturn("externalArtifactUpdateUrl");
        when(ptabBusinessUtils.getLoggedInUserId()).thenReturn("userName");
        final Petition petition = new Petition();
        final ResponseEntity<Object> responseObj = ResponseEntity.ok(petition);
        final List<PetitionDocument> petDocs=new ArrayList<>();
        final PetitionDocument petitionDocument=new PetitionDocument();
        petDocs.add(petitionDocument);
        petitionDocument.setArtifactIdentifer("123456");
        petition.setPetitionDocuments(petDocs);
        when(restServiceClient.callPTABExternalServiceURL(any(), any(), any(), any(), anyString())).thenReturn(responseObj);
        proceedingArtifactService.createProceedingArtifactForExternal(petition);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

    /**
     * test method to test createProceedingArtifact
     */
    @Test
    public void testCreateProceedingArtifact() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString()))
                .thenReturn("externalArtifactUpdateUrl");
        when(ptabBusinessUtils.getLoggedInUserId()).thenReturn("userName");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.callPTABExternalServiceURL(any(), any(), any(), any(), anyString())).thenReturn(responseObj);
        final Petition petition = new Petition();
        proceedingArtifactService.createProceedingArtifact(petition);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

    /**
     * test method to test updateProceedingArtifact
     */
    @Test
    public void testUpdateProceedingArtifact() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString()))
                .thenReturn("externalArtifactUpdateUrl");
        when(ptabBusinessUtils.getLoggedInUserId()).thenReturn("userName");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.callPTABExternalServiceURL(any(), any(), any(), any(), anyString())).thenReturn(responseObj);
        final PetitionDocument petitionDocument = new PetitionDocument();
        proceedingArtifactService.updateProceedingArtifact(145L, petitionDocument);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

    /**
     * test method to test deleteProceedingArtifact
     */
    @Test
    public void testDeleteProceedingArtifact() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString()))
                .thenReturn("externalArtifactUpdateUrl");
        when(ptabBusinessUtils.getLoggedInUserId()).thenReturn("userName");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.callPTABExternalServiceURL(any(), any(), any(), any(), anyString())).thenReturn(responseObj);
        when(responseObj.getStatusCode()).thenReturn(HttpStatus.OK);
        proceedingArtifactService.deleteProceedingArtifact(154L);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

    /**
     * test method to test exportPaperAndExhibitsAsExcel
     */
    @Test(expected = Exception.class)
    public void testExportPaperAndExhibitsAsExcel() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString()))
                .thenReturn("externalArtifactUpdateUrl");
        final CaseDocumentsDataQuery caseDocumentsDataQuery = new CaseDocumentsDataQuery();
        caseDocumentsDataQuery.setProceedingNumber("CNPN1457");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(), anyString())).thenReturn("systemusername");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        proceedingArtifactService.exportPaperAndExhibitsAsExcel(caseDocumentsDataQuery);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

    /**
     * test method to test getInitiatePetitionArtifacts
     */
    @Test(expected = Exception.class)
    public void testGetInitiatePetitionArtifacts() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString()))
                .thenReturn("externalArtifactUpdateUrl");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        final CaseDocumentsDataQuery caseDocumentsDataQuery = new CaseDocumentsDataQuery();
        caseDocumentsDataQuery.setProceedingNumber("CNPN1457");
        proceedingArtifactService.getInitiatePetitionArtifacts(caseDocumentsDataQuery);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }
}
