package gov.uspto.patent.ptab.controller;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.domain.FeeCalculationQuery;
import gov.uspto.patent.ptab.service.FeeCalculationService;

/**
 * This is a Test class for FeeCalculationControllerTest
 *
 * @author 2020 DevelopmentTeam
 *
 */
public class FeeCalculationControllerTest {

    @InjectMocks
    private FeeCalculationController feeCalculationController;

    @Mock
    private FeeCalculationService feeCalculationService;

    @Before
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getFeeCalculationDetailsTest() throws Exception {

        FeeCalculationQuery feeCalculationQuery = new FeeCalculationQuery();
        feeCalculationQuery.setProceedingNumber("IPR1234");
        final JsonNode nodeMock = Mockito.mock(JsonNode.class);
        when(feeCalculationService.getFeeCalculationDetails(any())).thenReturn(nodeMock);

        final JsonNode response = feeCalculationController.getFeeCalculationDetails(feeCalculationQuery);
        assertNotNull(response);
    }
}
