package gov.uspto.patent.ptab.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.dao.ReferenceDAO;
import gov.uspto.patent.ptab.domain.CodeReferenceLookup;
import gov.uspto.patent.ptab.domain.CodeReferenceQuery;
import gov.uspto.patent.ptab.domain.DocumentTypeQuery;
import gov.uspto.patent.ptab.domain.ReferenceDataResponse;
import gov.uspto.patent.ptab.domain.ReferenceQuery;
import gov.uspto.patent.ptab.domain.ReferenceType;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.RestServiceClient;

/**
 *
 * @author 2020 - development team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ReferenceDataServiceTest {

    private static final String REFERENCE_DATA_URL = "referenceDataUrl";
    private static final String TEST = "test";
    public static final String REF_DOCUMENT_TYPES = "documentTypes";
    public static final String REF_MOTION_TYPES = "motionTypes";


    @InjectMocks
    private ReferenceDataService referenceDataService;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Mock
    private RestServiceClient restServiceClient;
    
    @Mock
    private ReferenceDAO referenceDAO;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);

    }

    /**
     * Test method for code reference type test
     */
    @Test
    public void getCodeReferenceTypesTest() {

        final CodeReferenceQuery codeReferenceQuery = new CodeReferenceQuery();
        codeReferenceQuery.setTypeCode("typeCode");
        final List<CodeReferenceLookup> codeReferenceLookupList = new ArrayList<>();
        final CodeReferenceLookup codeReferenceLookup = new CodeReferenceLookup();
        codeReferenceLookup.setValueText("valueText");
        codeReferenceLookupList.add(codeReferenceLookup);
        Mockito.when(codeReferenceDao.fetchCodeReferenceViaTypeCode(codeReferenceQuery.getTypeCode()))
                .thenReturn(codeReferenceLookupList);

        final List<CodeReferenceLookup> responseCodeReferenceLookupList = referenceDataService
                .getCodeReferenceTypes(codeReferenceQuery);
        assertEquals(codeReferenceLookup.getValueText(), responseCodeReferenceLookupList.get(0).getValueText());

    }

    /**
     * Method used to test the get reference data
     *
     * @throws JsonProcessingException
     */
    @Test
    public void testGetReferenceData() throws JsonProcessingException {
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(REFERENCE_DATA_URL);
        Mockito.when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(TEST);
        final List<ReferenceType> list = new ArrayList<>();
        final ReferenceType referenceType = new ReferenceType();
        referenceType.setCode(TEST);
        list.add(referenceType);
        final ObjectMapper mapper = new ObjectMapper();
        final String json = mapper.writeValueAsString(list);
        Mockito.when(externalServiceUriGenerator.constructReferenceDataUrl(Mockito.any(ReferenceQuery.class),
                Mockito.anyString())).thenReturn(TEST);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity<>(json, HttpStatus.CREATED));
        final List<ReferenceType> response = referenceDataService.getReferenceData(new ReferenceQuery());
        assertEquals(TEST, response.get(0).getCode());
    }
    

    /**
     * Method used to test the get reference data with preceeding number
     *
     * @throws JsonProcessingException
     */
    @Test
    public void testGetReferenceDataWithPreceedingNumber() throws JsonProcessingException {
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(REFERENCE_DATA_URL);
        Mockito.when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(TEST);
        final ReferenceDataResponse referenceDataResponse = new ReferenceDataResponse();
        Mockito.when(externalServiceUriGenerator.constructReferenceDataUrl(Mockito.any(ReferenceQuery.class),
                Mockito.anyString())).thenReturn(TEST);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity<>(referenceDataResponse, HttpStatus.CREATED));
        final ReferenceDataResponse response = referenceDataService
                .getReferenceDataWithProceedingNumber(new ReferenceQuery());
        assertNotNull(response);
    }
    
    /**
     * Method used to test getCodeReferenceType
     *
     * @throws JsonProcessingException
     */
    @Test
    public void testGetCodeReferenceType() throws JsonProcessingException {
        final CodeReferenceQuery codeReferenceQuery=new CodeReferenceQuery();
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(REFERENCE_DATA_URL);
        Mockito.when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(TEST);
        final List<ReferenceType> list = new ArrayList<>();
        final ReferenceType referenceType = new ReferenceType();
        referenceType.setCode(TEST);
        list.add(referenceType);
        final ObjectMapper mapper = new ObjectMapper();
        final String json = mapper.writeValueAsString(list);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity<>(json, HttpStatus.CREATED));
        referenceDataService.getCodeReferenceType(codeReferenceQuery);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }

    /**
     * test method to test getReferenceDataByTypeCodeDocTypes
     */
    @Test
    public void testGetReferenceDataByTypeCode() {
        final ReferenceQuery referenceQuery=new ReferenceQuery();
        referenceQuery.setTypeCode(REF_DOCUMENT_TYPES);
        final List<ReferenceType> list=new ArrayList<>();
        when(referenceDAO.getDocumentTypes(Mockito.any())).thenReturn(list);
        referenceDataService.getReferenceDataByTypeCode(referenceQuery);
        Mockito.verify(referenceDAO, Mockito.atMost(1)).getDocumentTypes(Mockito.any());
    }
    
    /**
     * test method to test getReferenceDataByTypeCodeMotionTypes
     */
    @Test
    public void testGetReferenceDataByTypeCodeMotionType() {
        final ReferenceQuery referenceQuery=new ReferenceQuery();
        referenceQuery.setTypeCode(REF_MOTION_TYPES);
        final List<ReferenceType> list=new ArrayList<>();
        when(referenceDAO.getMotionTypes()).thenReturn(list);
        referenceDataService.getReferenceDataByTypeCode(referenceQuery);
        Mockito.verify(referenceDAO, Mockito.atMost(1)).getDocumentTypes(Mockito.any());
    }
    
    /**
     * Method used to test getDocumentInfo
     *
     * @throws JsonProcessingException
     */
    @Test
    public void testGetDocumentInfo() throws JsonProcessingException {
        final DocumentTypeQuery documentTypeQuery=new DocumentTypeQuery();
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(REFERENCE_DATA_URL);
        Mockito.when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(TEST);
        final List<ReferenceType> list = new ArrayList<>();
        final ReferenceType referenceType = new ReferenceType();
        referenceType.setCode(TEST);
        list.add(referenceType);
        final ObjectMapper mapper = new ObjectMapper();
        final String json = mapper.writeValueAsString(list);
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        referenceDataService.getDocumentInfo(documentTypeQuery);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }

}
