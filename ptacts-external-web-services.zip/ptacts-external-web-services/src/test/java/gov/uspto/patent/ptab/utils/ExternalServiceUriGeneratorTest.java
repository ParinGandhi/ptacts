package gov.uspto.patent.ptab.utils;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import gov.uspto.patent.ptab.common.opsg.domain.ApplicationIdentifierQuery;
import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.domain.DocumentQuery;
import gov.uspto.patent.ptab.domain.DocumentTypeQuery;
import gov.uspto.patent.ptab.domain.FeeCalculationQuery;
import gov.uspto.patent.ptab.domain.LoginQuery;
import gov.uspto.patent.ptab.domain.PetitionQuery;
import gov.uspto.patent.ptab.domain.ProceedingPartyQuery;
import gov.uspto.patent.ptab.domain.ProceedingQuery;
import gov.uspto.patent.ptab.domain.ReferenceQuery;
import gov.uspto.patent.ptab.domain.TrialsBase;

/**
 * Test Case for ExternalServiceUriGenerator
 *
 * @author 2020 - Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ExternalServiceUriGeneratorTest {

    private static final String HTTP_TESTURL = "http://testurl";
    @InjectMocks
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Method used to test construct reference data url
     */
    @Test
    public void testConstructReferenceDataUrl() {
        final ReferenceQuery referenceQuery = new ReferenceQuery();
        referenceQuery.setCategoryType("categoryType");
        final String url = externalServiceUriGenerator.constructReferenceDataUrl(referenceQuery, HTTP_TESTURL);
        assertNotNull(url);
    }

    /**
     * Method used to test application info url
     */
    @Test
    public void testApplicationInfoUrl() {
        final String url = externalServiceUriGenerator.applicationInfoUrl(new ApplicationIdentifierQuery(),
                HTTP_TESTURL);
        assertNotNull(url);
    }

    /**
     * Method used to test user detail url
     */
    @Test
    public void testUserDetailsUrl() {
        final String url = externalServiceUriGenerator.userDetailsUrl(new LoginQuery(), HTTP_TESTURL);
        assertNotNull(url);
    }
    
    /**
     * method used to test proceeding party delete url
     */
    
    @Test
    public void testProceedingPartyDeleteUrl() {
        final ProceedingPartyQuery proceedingPartyQuery = new ProceedingPartyQuery();
        String result ="serviceUrl?emailAddressText=abc@uspto.gov&proceedingNumber=1234&registrationNumberText=1234&proceedingPartyIdentifier=10";
        proceedingPartyQuery.setEmailAddressText("abc@uspto.gov");
        proceedingPartyQuery.setProceedingNumber("1234");
        proceedingPartyQuery.setRegistrationNumberText("1234");
        proceedingPartyQuery.setProceedingPartyIdentifier(10L);
        
        assertEquals(result,externalServiceUriGenerator.getProceedingPartyDeleteUrl(proceedingPartyQuery,"serviceUrl"));
        
        
        
    }
    
    
    @Test
    public void testDownloadDocumentUrl() {
    	final DocumentQuery documentQuery = new DocumentQuery();
        String result ="serviceUrlreturnvaluesearchurl?searchType=searchtype";
        
        assertNotNull(result,externalServiceUriGenerator.getDownloadDocumentUrl(documentQuery,"serviceUrl"));
        
        
        
    }
    
    /**
     * method used to test case viewer Details url
     */
    
    @Test
    public void testCaseViewerDetailsUrl() {
        final TrialsBase trialsbase = new TrialsBase();
        String result ="serviceUrl?proceedingCoreId=123&proceedingSupplementaryId=jkl&proceedingType=abc";
        trialsbase.setProceedingCoreId("123");
        trialsbase.setProceedingSupplementaryId("jkl");
        trialsbase.setProceedingType("abc");
          
        
        assertEquals(result,externalServiceUriGenerator.getCaseViewerDetailsUrl(trialsbase,"serviceUrl"));
         
        
    }
    
    @Test
    public void testCaseNumberSearchUrl()
    
    {
    	String result="searchurl?searchType=searchtype";
    	System.out.print("return value"+externalServiceUriGenerator.getCaseNumberSearchUrl("searchtype","", "searchurl"));
    	assertNotNull(result,externalServiceUriGenerator.getCaseNumberSearchUrl("searchtype","", "searchurl"));
    }
    
    @Test
    public void testProceedingPartyDetailsUrl()
    
    {
    	String result="detailsurl/counsels/TRIALS?registrationNumber=458&EMAIL=abc@uspto.govreturn valuesearchurl?searchType=searchtype";
    	assertNotNull(result,externalServiceUriGenerator.getProceedingPartyDetailsUrl("asd", "458","abc@uspto.gov","detailsurl"));
    }
    
    @Test
    public void testFeeCalculationQuery()
    
    {
    	final FeeCalculationQuery feeCalculationQuery = new FeeCalculationQuery(); 
    	String result="feeurl?isMotionFeeCalculation=falsereturn valuesearchurl?searchType=searchtype";
    	assertNotNull(result,externalServiceUriGenerator.getFeeCalculationQuery(feeCalculationQuery, "feeurl"));
    }
    
    /**
     * Method used to test getCommonPetitionsUrl
     */
    @Test
    public void testGetCommonPetitionsUrl() {
        final PetitionQuery petitionquery=new PetitionQuery();
        final String url = externalServiceUriGenerator.getCommonPetitionsUrl(petitionquery, HTTP_TESTURL);
        assertNotNull(url);
    }
    
    /**
     * Method used to test getPetitonDetailsUrl
     */
    @Test
    public void testGetPetitonDetailsUrl() {
        final PetitionQuery petitionQuery = new PetitionQuery();
        petitionQuery.setProceedingNumberText("proceeding");
        petitionQuery.setPetitionIdentifier(145L);
        final String url = externalServiceUriGenerator.getPetitonDetailsUrl(petitionQuery, HTTP_TESTURL);
        assertNotNull(url);
    }

    /**
     * Method used to test getProceedingQuery
     */
    @Test
    public void testGetProceedingQuery() {
        final ProceedingQuery proceedingQuery = new ProceedingQuery();
        proceedingQuery.setApplicationNumber("APP145");
        proceedingQuery.setPatentNum("PT145");
        proceedingQuery.setProceedingNumber("PRO145");
        final String url = externalServiceUriGenerator.getProceedingQuery(proceedingQuery, HTTP_TESTURL);
        assertNotNull(url);
    }
    
    /**
     * Method used to test getCodeReferenceTypesUrl
     */
    @Test
    public void testGetCodeReferenceTypesUrl() {
        final String url = externalServiceUriGenerator.getCodeReferenceTypesUrl("typeCode", HTTP_TESTURL);
        assertNotNull(url);
    }

    /**
     * Method used to test constructDocumentTypesUrl
     */
    @Test
    public void testConstructDocumentTypesUrl() {
        final DocumentTypeQuery documentTypeQuery = new DocumentTypeQuery();
        documentTypeQuery.setMotionTypeName("Motion");
        documentTypeQuery.setRehearingTypeName("Rehearing");
        final String url = externalServiceUriGenerator.constructDocumentTypesUrl(documentTypeQuery, HTTP_TESTURL);
        assertNotNull(url);
    }
    
    /**
     * Method used to test getCaseDocumentDataQueryUrl
     */
    @Test
    public void testGetCaseDocumentDataQueryUrl() {
        final CaseDocumentsDataQuery caseDocumentsDataQuery = new CaseDocumentsDataQuery();
        caseDocumentsDataQuery.setCaseStatus("caseStatus");
        caseDocumentsDataQuery.setDocType("doc");
        caseDocumentsDataQuery.setCaseType("caseType");
        caseDocumentsDataQuery.setProceedingNumber("proceedingNumber");
        caseDocumentsDataQuery.setProceedingPartyGroupId(145L);
        caseDocumentsDataQuery.setExcludeArtifacts(true);
        caseDocumentsDataQuery.setStatus("status");
        final String url = externalServiceUriGenerator.getCaseDocumentDataQueryUrl(caseDocumentsDataQuery, HTTP_TESTURL);
        assertNotNull(url);
    }

}
