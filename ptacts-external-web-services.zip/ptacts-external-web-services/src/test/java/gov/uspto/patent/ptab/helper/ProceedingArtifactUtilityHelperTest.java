package gov.uspto.patent.ptab.helper;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.DocumentTypeCustomAttributes;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.entities.ArtifactSubmission;
import gov.uspto.patent.ptab.entities.ArtifactSubmissionStatus;
import gov.uspto.patent.ptab.entities.Document;
import gov.uspto.patent.ptab.entities.Exhibit;
import gov.uspto.patent.ptab.entities.ProceedingArtifact;
import gov.uspto.patent.ptab.entities.StndArtifactType;
import gov.uspto.patent.ptab.entities.StndAvailability;
import gov.uspto.patent.ptab.entities.StndDocumentType;
import gov.uspto.patent.ptab.entities.StndProxySubmitterRole;

@RunWith(MockitoJUnitRunner.class)
public class ProceedingArtifactUtilityHelperTest {

    @InjectMocks
    private ProceedingArtifactUtilityHelper proceedingArtifactUtilityHelper;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    /**
     * test method to test ProceedingArtifactUtilityHelper
     */
    @Test
    public void testGetAllPetitionDocumentsAddFilterToUpdatePetitionDocs() {
        final List<PetitionDocument> petitionDocumentList = new ArrayList<>();
        final PetitionDocument petitionDocument = new PetitionDocument();
        petitionDocumentList.add(petitionDocument);
        petitionDocument.setAvailability("Board");
        petitionDocument.setFilingParty("filingParty");
        final List<ProceedingArtifact> proceedingArtifactList = new ArrayList<>();
        final ProceedingArtifact proceedingArtifact = new ProceedingArtifact();
        proceedingArtifactList.add(proceedingArtifact);
        final ArtifactSubmission artifactSubmission = new ArtifactSubmission();
        proceedingArtifact.setArtifactSubmission(artifactSubmission);
        final Document document = new Document();
        proceedingArtifact.setDocument(document);
        final Exhibit exhibit = new Exhibit();
        proceedingArtifact.setExhibit(exhibit);
        artifactSubmission.setArtifactSubmissionId(145L);
        proceedingArtifact.setFilingTS(new Date(0));
        final StndAvailability stndAvailability = new StndAvailability();
        proceedingArtifact.setStndAvailability(stndAvailability);
        stndAvailability.setAvailabilityCd("AVAIL");
        stndAvailability.setDescriptionTx("DESC");
        stndAvailability.setDisplayName("PETITION");
        proceedingArtifact.setArtifactNm("ART");
        proceedingArtifact.setFileName("PETNM");
        proceedingArtifact.setPageCountQt(5);
        proceedingArtifact.setFkDirectionCd("FKPETI");
        proceedingArtifact.setProceedingArtifactId(145L);
        proceedingArtifact.setContentManagementId("CONT");
        proceedingArtifact.setComment("PROC");
        final StndArtifactType stndArtifactType = new StndArtifactType();
        proceedingArtifact.setStndArtifactType(stndArtifactType);
        stndArtifactType.setDescriptionTx("DESCST");
        stndArtifactType.setArtifactTypeCd("ARTCD");
        stndArtifactType.setDescriptionTx("DESCTX");
        exhibit.setExhibitNo(145L);
        final StndDocumentType stndDocumentType = new StndDocumentType();
        document.setStndDocumentType(stndDocumentType);
        stndDocumentType.setDocumentTypeCd("DOC");
        stndDocumentType.setDocumentTypeId(145L);
        stndDocumentType.setDocumentTypeNm("1457");
        final ArtifactSubmissionStatus artifactSubmissionStatus = new ArtifactSubmissionStatus();
        proceedingArtifact.setArtifactSubmission(artifactSubmission);
        artifactSubmissionStatus.setFkSubmissionStatusCd("EXPUNGED");
        final StndProxySubmitterRole proxyRole = new StndProxySubmitterRole();
        artifactSubmissionStatus.setStndProxySubmitterRole(proxyRole);
        proxyRole.setDisplayName("PROXY");
        proxyRole.setProxySubmitterRoleNm("PROXSUB");
        proxyRole.setDescriptionTx("PROXDESC");
        artifactSubmission.setArtifactSubmissionStatuses(artifactSubmissionStatus);
        DocumentTypeCustomAttributes customAttributes = new DocumentTypeCustomAttributes();
        final ObjectMapper mapper = new ObjectMapper();
        try {
            stndDocumentType.setCustomAttributes(mapper.writeValueAsString(customAttributes));
        } catch (Exception e) {
        }
        String value = "Do Not Publish for 30 minutes - filed as Board";
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(), anyString())).thenReturn(value);
        proceedingArtifactUtilityHelper.getAllPetitionDocuments(petitionDocumentList, proceedingArtifactList);
        proceedingArtifactUtilityHelper.addFilterToUpdatePetitionDocs(petitionDocumentList, "prcdPartyGrpType");
        assertEquals("145", proceedingArtifact.getArtifactSubmission().getArtifactSubmissionId().toString());
    }
}
