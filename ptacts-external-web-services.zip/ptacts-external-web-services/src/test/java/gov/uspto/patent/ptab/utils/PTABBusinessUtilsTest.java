package gov.uspto.patent.ptab.utils;

import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import gov.uspto.patent.ptab.dao.AssignmentQueriesDao;
import gov.uspto.patent.ptab.domain.EmployeeDetails;
import gov.uspto.patent.ptab.entities.ApplicationUserEntity;
import gov.uspto.patent.ptab.entities.ExternalUser;
import gov.uspto.patent.ptab.repository.ApplicationUserRepository;
import gov.uspto.patent.ptab.repository.ExternalUserRepository;

/**
 * Test Case for PTABBusinessUtils
 * 
 * @author 2020 - Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class PTABBusinessUtilsTest {

    private static final String USER_ID = "userId";
    private static final String APPLICATION_USER_ID = "applicationUserId";

    @InjectMocks
    private PTABBusinessUtils pTABBusinessUtils;

    @Mock
    private AssignmentQueriesDao assignmentQueriesDao;

    @Mock
    private ApplicationUserRepository applicationUserRepository;

    @Mock
    private ExternalUserRepository externalUserRepository;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Test method for GetName
     */
    @Test
    public void testGetName() {
        List<EmployeeDetails> employeeDetailsList = new ArrayList<>();
        EmployeeDetails employeeDetails = new EmployeeDetails();
        employeeDetails.setFirstName("ptab");
        employeeDetails.setLastName("user");
        employeeDetails.setMiddleName("admin");

        Mockito.when(assignmentQueriesDao.fetchFullNamesOfEmployee(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(employeeDetailsList);
        final String response = pTABBusinessUtils.getName(USER_ID, APPLICATION_USER_ID);
        assertNotEquals("userId", response);
    }

    /**
     * Test method for GetUserId
     */
    @Test
    public void testGetUserId() {

        ApplicationUserEntity applicationUserEntity = new ApplicationUserEntity();
        applicationUserEntity.setUserId(USER_ID);
        Mockito.when(applicationUserRepository.findOneByApplicationUserId(Mockito.any())).thenReturn(applicationUserEntity);
        final String response = pTABBusinessUtils.getUserId(BigDecimal.TEN);
        assertEquals(USER_ID, response);
    }

    /**
     * Test method for GetUserIdentifier
     */
    @Test
    public void testGetUserIdentifier() {
        ApplicationUserEntity applicationUserEntity = new ApplicationUserEntity();
        applicationUserEntity.setApplicationUserId(BigDecimal.ONE);
        Mockito.when(applicationUserRepository.findOneByUserId(Mockito.anyString())).thenReturn(applicationUserEntity);
        final BigDecimal response = pTABBusinessUtils.getUserIdentifier("1");
        assertEquals(BigDecimal.ONE, response);
    }

    /**
     * Test method for GetExternalUserIdentifier
     */

    @Test
    public void testGetExternalUserIdentifier() {
        ExternalUser externalUserEntity = new ExternalUser();
        externalUserEntity.setFkApplicationUserId(BigDecimal.ONE);

        Mockito.when(externalUserRepository.findOneByUserId(Mockito.anyString())).thenReturn(externalUserEntity);
        final BigDecimal response = pTABBusinessUtils.getExternalUserIdentifier("1");
        assertEquals(BigDecimal.ONE, response);
    }

    /**
     * Test method for ConvertDateToString
     */
    @Test
    public void testConvertDateToString() {
        Assertions.assertNotNull(pTABBusinessUtils.convertDateToString(new Date()));
    }

    /**
     * Test method for ConvertDateToStringNull
     */
    @Test
    public void testConvertDateToStringNull() {
        Assertions.assertNull(pTABBusinessUtils.convertDateToString(null));
    }

    /**
     * Test mehtod for ConvertDateToStringActual
     */
    @Test
    public void testConvertDateToStringActual() {
        Assertions.assertNotNull(pTABBusinessUtils.convertDateToString("1980/11/14"));
    }

}
