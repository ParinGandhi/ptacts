package gov.uspto.patent.ptab.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.mock;

public class PetitionClaimDaoTest {

    @InjectMocks
    private PetitionClaimDao claimsInfoDao;

    @Mock
    private final SessionFactory sessionFactory = mock(SessionFactory.class);

    private Session session;

    @SuppressWarnings("rawtypes")
    private Query query;

    /**
     * Method used to initialize mock objects
     */
    @Before
    public void initMocks() {

        MockitoAnnotations.initMocks(this);
    }

    /**
     * This method is used to mock session and query objects.
     */
    private void mockSession() {

        session = Mockito.mock(Session.class);
        query = Mockito.mock(Query.class);
        Mockito.when(sessionFactory.getCurrentSession()).thenReturn(session);
        Mockito.when(session.createNamedQuery(Mockito.anyString(), Mockito.any())).thenReturn(query);

    }

    @Test
    public void getClaimsInfoTest() {
        mockSession();
        claimsInfoDao.getTotalClaims("123456");
        // Mockito.verify(claimsInfoDao).getTotalClaims("123456");
        Assert.assertNull(claimsInfoDao.getTotalClaims("123456"));

    }

}
