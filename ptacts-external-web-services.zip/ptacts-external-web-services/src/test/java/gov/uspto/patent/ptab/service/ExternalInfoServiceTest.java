package gov.uspto.patent.ptab.service;

import static org.mockito.ArgumentMatchers.any;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import gov.uspto.patent.ptab.utils.RestServiceClient;

@RunWith(MockitoJUnitRunner.class)
public class ExternalInfoServiceTest {

    @InjectMocks
    private ExternalInfoService externalInfoService;
    
    @Mock
    RestServiceClient restServiceClient;
    
    @Test(expected=Exception.class)
    public void testGetCountriesFromICT(){
        ReflectionTestUtils.setField(externalInfoService,"countryServiceUrl","countryServiceUrl");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);      
        final String jsonData =  " [{\"statusDisplay\":\"statusDisplay\"}]";         
        Mockito.when(restServiceClient.callExternalServiceURL(any(), any(), any(), any())).thenReturn(jsonData);
        externalInfoService.getCountriesFromICT();
    }
    
    @Test(expected=Exception.class)
    public void testGetStatesFromICT(){
        ReflectionTestUtils.setField(externalInfoService,"serviceUrl","serviceUrl");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);     
        final String jsonData =  "[ {\"statusDisplay\":\"statusDisplay\"}]";
        Mockito.when(restServiceClient.callExternalServiceURL(any(), any(), any(), any())).thenReturn(jsonData);
        externalInfoService.getStatesFromICT("countryCode");
    }
}
