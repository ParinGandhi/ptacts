package gov.uspto.patent.ptab.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import gov.uspto.patent.ptab.utils.RestServiceClient;

@RunWith(MockitoJUnitRunner.class)
public class GeoLocationInfoControllerTest {

    @InjectMocks
    GeoLocationInfoController geoLocationInfoController;

    @Mock
    RestServiceClient restServiceClient;

    @Test
    public void testGetCountries() {

        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        Mockito.when(restServiceClient.callExternalServiceURL(any(), any(), any(), any())).thenReturn("success");
        ResponseEntity<String> responseEntity = geoLocationInfoController.getCountriesInfo("TRIALS");

        assertEquals(200, responseEntity.getStatusCodeValue());
     }

    @Test
    public void testStates() {

        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        Mockito.when(restServiceClient.callExternalServiceURL(any(), any(), any(), any())).thenReturn("success");
        ResponseEntity<String> responseEntity = geoLocationInfoController.getStatesInfo("TRIALS",
            "US");

        assertEquals(200, responseEntity.getStatusCodeValue());
    }
}
