package gov.uspto.patent.ptab.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.TrialsBase;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.RestServiceClient;

@RunWith(MockitoJUnitRunner.class)
public class CaseViewerServiceTest {

    @InjectMocks
    private CaseViewerService caseViewerService;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @SuppressWarnings("unchecked")
    @Test
    public void testGetBasicDataDetails() {
        final TrialsBase trialsbase = new TrialsBase();
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("case search Url");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(), anyString())).thenReturn("system user name");
        when(externalServiceUriGenerator.getCaseViewerDetailsUrl(any(), anyString())).thenReturn("url");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(responseObj);
        caseViewerService.getBasicDataDetails(trialsbase);
        Mockito.verify(restServiceClient, Mockito.atMost(1)).callPTABExternalServiceURL(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetValidCaseData() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("case search Url");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(), anyString())).thenReturn("system user name");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(responseObj);
        caseViewerService.getValidCaseData("searchType", "CN154");
        Mockito.verify(restServiceClient, Mockito.atMost(1)).callPTABExternalServiceURL(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());
    }
}
