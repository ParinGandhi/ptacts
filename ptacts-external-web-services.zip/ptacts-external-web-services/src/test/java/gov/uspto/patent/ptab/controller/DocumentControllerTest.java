package gov.uspto.patent.ptab.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import gov.uspto.patent.ptab.domain.DocumentQuery;
import gov.uspto.patent.ptab.domain.DocumentsQuery;
import gov.uspto.patent.ptab.domain.PetitionFile;
import gov.uspto.patent.ptab.service.DocumentService;

/**
 * Test Class to test DocumentController
 *
 * @author 2020 Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentControllerTest {

    private static final String FILE_NAME = "test.pdf";

    @InjectMocks
    private DocumentController documentController;

    @Mock
    private DocumentService documentService;

    @Mock
    private InputStreamResource inputStreamResource;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * This method is used to test the store document
     *
     * @throws IOException
     */
    @Test
    public void testStoreDocument() throws IOException {
        final PetitionFile petitionFile = new PetitionFile();
        petitionFile.setFileName(FILE_NAME);
        Mockito.when(documentService.storeDocument(Mockito.anyLong(), Mockito.any(), Mockito.any())).thenReturn(petitionFile);
        final MultipartFile multipartMock = Mockito.mock(MultipartFile.class);
        final PetitionFile response = documentController.storeDocument(1234567L, multipartMock, "PAPER");
        assertEquals(petitionFile.getFileName(), response.getFileName());
    }

    /**
     * This method is used to test the downloadDocument
     *
     * @throws IOException
     */
    @Test
    public void testDownloadDocument() throws IOException {
        final DocumentQuery documentQuery = new DocumentQuery();
        documentQuery.setArtifactId("1234567123");
        Mockito.when(documentService.downloadDocument(1234567123L, documentQuery, false))
                .thenReturn(new ResponseEntity<>(inputStreamResource, HttpStatus.OK));
        documentController.downloadDocument(1234567123L, documentQuery);
        Mockito.verify(documentService, times(1)).downloadDocument(1234567123L, documentQuery, false);

    }

    /**
     * This method is used to test the getDocument
     *
     * @throws IOException
     */
    @Test
    public void testGetDocument() throws IOException {
        final DocumentsQuery documentQuery = new DocumentsQuery();
        Mockito.when(documentService.getDocument(1234567123L, documentQuery))
                .thenReturn(new ResponseEntity<>(inputStreamResource, HttpStatus.OK));
        documentController.getDocument(1234567123L, documentQuery);
        Mockito.verify(documentService, times(1)).getDocument(1234567123L, documentQuery);

    }

}
