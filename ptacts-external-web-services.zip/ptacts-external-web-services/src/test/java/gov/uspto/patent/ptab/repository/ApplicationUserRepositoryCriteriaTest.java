package gov.uspto.patent.ptab.repository;

import static org.mockito.ArgumentMatchers.anyString;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import gov.uspto.patent.ptab.domain.ApplicationUserQuery;
import gov.uspto.patent.ptab.entities.ApplicationUserEntity;

@RunWith(MockitoJUnitRunner.class)
public class ApplicationUserRepositoryCriteriaTest {

    @InjectMocks
    private ApplicationUserRepositoryCriteria applicationUserRepositoryCriteria;
    
    @Mock
    private EntityManager entityManager;
    
    @Mock
    private CriteriaBuilder builder;
    
    @Mock
    private CriteriaQuery<Object> query;
    
    @Mock
    private Root<ApplicationUserEntity> applicationUserEntity;
    
    @Mock
    private TypedQuery<ApplicationUserEntity> typedQuery;
    
    /**
     * test method to test getUserInfo
     */
    @Test(expected=Exception.class)
    public void testgetUserInfo() {
        final ApplicationUserQuery applicationUserQuery=new ApplicationUserQuery();
        Mockito.when(entityManager.getCriteriaBuilder()).thenReturn(builder);
        Mockito.when(builder.createQuery(Mockito.any())).thenReturn(query);
        Mockito.when(query.from(ApplicationUserEntity.class)).thenReturn(applicationUserEntity);
        applicationUserQuery.setLoginId("14547");
        applicationUserQuery.setUserIdentiifier("14547");
        applicationUserQuery.setUserWorkerNumber("14547");
        applicationUserQuery.setFirstName("firstNm");
        applicationUserQuery.setLastName("lastNm");
        applicationUserRepositoryCriteria.getUserInfo(applicationUserQuery);
    }
}
