package gov.uspto.patent.ptab.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import gov.uspto.patent.ptab.domain.AIAReviewsDocket;
import gov.uspto.patent.ptab.domain.ExternalUserMotion;
import gov.uspto.patent.ptab.domain.ExternalUserRehearing;
import gov.uspto.patent.ptab.domain.NotificationDetails;
import jakarta.persistence.EntityManager;

/**
 * Test case for ExternalUserDocketDao
 * 
 * @author 2020 - Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ExternalUserDocketDaoTest {

    @InjectMocks
    private ExternalUserDocketDao extUserDocketDao;

    @Mock
    private EntityManager entityManager;

    @Mock
    private final SessionFactory sessionFactory = mock(SessionFactory.class);

    List<Object[]> testArray;

    @Mock
    private Session session;

    @SuppressWarnings("rawtypes")
    private Query query;

    @SuppressWarnings("rawtypes")
    private NativeQuery nativeQuery;

    @Before
    public void initMocks() {
        MockitoAnnotations.openMocks(this);

        // Mockito.when(entityManager.createNamedQuery(Mockito.anyString())).thenReturn(query);
        // Mockito.when(session.createNamedQuery(Mockito.anyString(), Mockito.any())).thenReturn(query);

        testArray = new ArrayList<>();
        Object[] objects = new Object[30];
        objects[0] = 123456;
        objects[12] = "petitioner";
        testArray.add(objects);
    }

    @SuppressWarnings("unchecked")
    private void mockSession() {
        session = Mockito.mock(Session.class);
        query = Mockito.mock(Query.class);
        nativeQuery = Mockito.mock(NativeQuery.class);
        when(entityManager.unwrap(Mockito.any())).thenReturn(session);
        Mockito.when(sessionFactory.getCurrentSession()).thenReturn(session);
        Mockito.when(session.createNamedQuery(Mockito.anyString(), Mockito.any())).thenReturn(query);
        Mockito.when(session.createNativeQuery(Mockito.anyString(),Mockito.eq(Object[].class))).thenReturn(nativeQuery);
    }

    @Test
    public void getAIAReviews() {
        mockSession();
        List<Long> testList = new ArrayList<Long>();
        testList.add(Long.valueOf(1234));
         Mockito.when(query.list()).thenReturn(testArray);
        String procdNoc = "userName";
        List<AIAReviewsDocket> response = extUserDocketDao.getAIAReviews(procdNoc, testList, testList);
        assertEquals("123456", response.get(0).getProceedingId().toString());
    }

    @Test
    public void getMotionsTest() {
        mockSession();
        String user = "userName";
        List<Long> testList = new ArrayList<>();
        testList.add(1234L);
        Mockito.when(nativeQuery.getResultList()).thenReturn(testArray);
        List<ExternalUserMotion> response = extUserDocketDao.getMotions(user, testList, testList, testList, null, null);
        assertEquals(null, response.get(0).getMotionId());
    }

    @Test
    public void getRehearingsTest() {
        mockSession();
        String user = "userName";
        List<Long> testList = new ArrayList<>();
        testList.add(1234L);
        Mockito.when(query.getResultList()).thenReturn(testArray);
        List<ExternalUserRehearing> response = extUserDocketDao.getRehearings(user, testList, testList, testList,
                testList);
        assertEquals(123456L, response.get(0).getRehearingId());
    }

    @Test
    public void getNotificationTest() {
        mockSession();
        String user = "userName";
        Mockito.when(query.getResultList()).thenReturn(testArray);
        List<NotificationDetails> response = extUserDocketDao.getNotifications(user);
        assertEquals("123456", response.get(0).getCaseNo());
    }

    @Test
    public void getMotionsTestProceedingNum() {
        mockSession();
        String user = "userName";
        List<Long> testList = new ArrayList<>();
        testList.add(1234L);
        extUserDocketDao.getMotions(user, testList, testList, testList, "1234", 145L);
        Mockito.verify(query, Mockito.atMost(1)).getResultList();
    }

    @Test
    public void testGetAppeals() {
        mockSession();
        String user = "userName";
        List<Long> testList = new ArrayList<>();
        testList.add(1234L);
        Mockito.when(nativeQuery.getResultList()).thenReturn(testArray);
        extUserDocketDao.getAppeals(user, testList, testList, testList, testList, null);
        Mockito.verify(query, Mockito.atMost(1)).getResultList();
    }

    @Test
    public void testGetAppealsProceedingNum() {
        mockSession();
        String user = "userName";
        List<Long> testList = new ArrayList<>();
        testList.add(1234L);
        extUserDocketDao.getAppeals(user, testList, testList, testList, testList, "1234");
        Mockito.verify(query, Mockito.atMost(1)).getResultList();
    }

    @Test
    public void testGetRehearingsByPrcdNum() {
        mockSession();
        String user = "userName";
        List<Long> testList = new ArrayList<>();
        testList.add(1234L);
        extUserDocketDao.getRehearingsByPrcdNum(user, testList, testList, testList, testList, "1234", 1245L);
        Mockito.verify(query, Mockito.atMost(1)).getResultList();
    }

    @Test
    public void testGetUnSubmittedAIAReviews() {
        mockSession();
        String user = "userName";
        List<Long> testList = new ArrayList<>();
        testList.add(1234L);
        extUserDocketDao.getUnSubmittedAIAReviews(user, testList, testList);
        Mockito.verify(query, Mockito.atMost(1)).getResultList();
    }

}
