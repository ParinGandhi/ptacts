package gov.uspto.patent.ptab.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import gov.uspto.patent.ptab.domain.ReferenceDataResponse;
import gov.uspto.patent.ptab.domain.ReferenceQuery;
import gov.uspto.patent.ptab.domain.ReferenceType;
import gov.uspto.patent.ptab.service.ReferenceDataService;

/**
 * Test Class to test ReferenceDataController
 *
 * @author 2020 Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ReferenceDataControllerTest {

    private static final int INT_ZERO = 0;

    private static final String TEST = "TEST";

    @InjectMocks
    private ReferenceDataController referenceDataController;

    @Mock
    private ReferenceDataService referenceDataService;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Method used to test get reference type
     */
    @Test
    public void testGetReferenceType() {
        final List<ReferenceType> list = new ArrayList<>();
        final ReferenceType referenceType = new ReferenceType();
        referenceType.setCode(TEST);
        list.add(referenceType);
        Mockito.when(referenceDataService.getReferenceData(Mockito.any(ReferenceQuery.class))).thenReturn(list);
        final List<ReferenceType> response = referenceDataController.getReferenceType(new ReferenceQuery());
        assertEquals(list.get(INT_ZERO).getCode(), response.get(INT_ZERO).getCode());
    }

    /**
     * Method used to test get reference data using proceeding number
     */
    @Test
    public void testGetReferenceDataWithProceedingNumber() {

        final ReferenceDataResponse referenceDataResponse = new ReferenceDataResponse();
        Mockito.when(referenceDataService.getReferenceDataWithProceedingNumber(Mockito.any(ReferenceQuery.class)))
                .thenReturn(referenceDataResponse);
        final ReferenceDataResponse response = referenceDataController
                .getReferenceDataWithProceedingNumber(new ReferenceQuery());
        assertNotNull(response);
    }

}
