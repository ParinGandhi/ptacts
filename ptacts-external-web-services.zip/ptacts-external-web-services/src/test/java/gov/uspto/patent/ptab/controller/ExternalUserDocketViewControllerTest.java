package gov.uspto.patent.ptab.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import gov.uspto.patent.ptab.domain.AIAReviewsDocket;
import gov.uspto.patent.ptab.domain.ExternalUserRehearing;
import gov.uspto.patent.ptab.domain.ExternalUserMotion;
import gov.uspto.patent.ptab.domain.NotificationDetails;
import gov.uspto.patent.ptab.service.ExternalUserDocketService;

/**
 * Test Class to test WhoAmIController
 *
 * @author 2020 Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ExternalUserDocketViewControllerTest {

    @InjectMocks
    private ExternalUserDocketViewController extUsrDtCtrller;

    @Mock
    private ExternalUserDocketService extUsrDtCaseViewerSvc;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getAIAReviewsTest() {
        List<AIAReviewsDocket> dockets = new ArrayList<>();
        AIAReviewsDocket extUsrDocket = new AIAReviewsDocket();
        dockets.add(extUsrDocket);
        String actual = "patentOwnerName";
        extUsrDocket.setPatentOwnerName(actual);
        Mockito.when(extUsrDtCaseViewerSvc.getAIAReviews(Mockito.anyString())).thenReturn(dockets);
        List<AIAReviewsDocket> response = extUsrDtCtrller.getAIAReviews(Mockito.anyString());
        verify(extUsrDtCaseViewerSvc, Mockito.atMost(1)).getAIAReviews(Mockito.anyString());
        assertEquals(response.get(0).getPatentOwnerName(), actual);
    }

    @Test
    public void getMotionsTest() {
        List<ExternalUserMotion> motions = new ArrayList<>();
        ExternalUserMotion motion = new ExternalUserMotion();
        motion.setMotionId(1234L);
        motion.setProceedingId(1234L);
        motions.add(motion);
        Mockito.when(extUsrDtCaseViewerSvc.getMotions(Mockito.anyString(), Mockito.anyBoolean())).thenReturn(motions);
        List<ExternalUserMotion> response = extUsrDtCtrller.getMotions(Mockito.anyString(), Mockito.anyBoolean());
        verify(extUsrDtCaseViewerSvc, Mockito.atMost(1)).getMotions(Mockito.anyString(), Mockito.anyBoolean());
        assertEquals(1234L, response.get(0).getProceedingId());
    }

    @Test
    public void getNotificationsTest() {
        List<NotificationDetails> notifications = new ArrayList<>();
        NotificationDetails notification = new NotificationDetails();
        notification.setNotificationId("1234");
        notifications.add(notification);
        Mockito.when(extUsrDtCaseViewerSvc.getNotifications()).thenReturn(notifications);
        List<NotificationDetails> response = extUsrDtCtrller.getNotifications();
        verify(extUsrDtCaseViewerSvc, Mockito.atMost(1)).getNotifications();
        assertEquals("1234", response.get(0).getNotificationId());
    }

    @Test
    public void getRehearingsTest() {
        List<ExternalUserRehearing> rehearings = new ArrayList<>();
        ExternalUserRehearing rehearing = new ExternalUserRehearing();
        rehearing.setRehearingId(1234L);
        rehearing.setProceedingId(1234L);
        rehearings.add(rehearing);
        Mockito.when(extUsrDtCaseViewerSvc.getRehearings(Mockito.anyString())).thenReturn(rehearings);
        List<ExternalUserRehearing> response = extUsrDtCtrller.getRehearings(Mockito.anyString());
        verify(extUsrDtCaseViewerSvc, Mockito.atMost(1)).getRehearings(Mockito.anyString());
        assertEquals(1234L, response.get(0).getProceedingId());
    }

}
