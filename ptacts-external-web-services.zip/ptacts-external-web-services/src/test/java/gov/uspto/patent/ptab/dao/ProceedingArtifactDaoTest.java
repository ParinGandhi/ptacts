package gov.uspto.patent.ptab.dao;

import gov.uspto.patent.ptab.entities.ProceedingArtifact;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import jakarta.persistence.EntityManager;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

/**
 * Tests for ProceedingArtifactDao
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ProceedingArtifactDaoTest {

    @InjectMocks
    private ProceedingArtifactDao proceedingArtifactDao;

    @Mock
    private final SessionFactory sessionFactory = mock(SessionFactory.class);

    private Session session;
    @SuppressWarnings("rawtypes")
    private Query query;

    @Mock
    private EntityManager entityManager;

    final private Long proceedingId = 1234L;

    /**
     * Method used to initialize mock objects
     */
    @Before
    public void initMocks() {

        MockitoAnnotations.initMocks(this);
    }

    /**
     * This method is used to mock session and query objects.
     */
    private void mockSession() {

        session = Mockito.mock(Session.class);
        query = Mockito.mock(Query.class);
        Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);

    }

    @Test
   public void testGetAllProceedingArtifacts() {
        mockSession();

       List<ProceedingArtifact> docsList = new ArrayList<>();
       ProceedingArtifact proceedingArtifactOne = new ProceedingArtifact();
       proceedingArtifactOne.setArtifactNm("artifctNm");
        docsList.add(proceedingArtifactOne);
       Mockito.when(query.getResultList()).thenReturn(docsList).thenReturn(docsList);
       final List<ProceedingArtifact> docsListResult = proceedingArtifactDao
               .getAllProceedingArtifacts(proceedingId);
       assertNotNull(docsListResult);
       assertEquals(2, docsList.size());
   }

   @Test
   public void testGetAllProceedingArtifactsForMandatoryNotice() {
       mockSession();

       List<ProceedingArtifact> docsList = new ArrayList<>();
       ProceedingArtifact proceedingArtifactOne = new ProceedingArtifact();
       proceedingArtifactOne.setArtifactNm("artifctNm");
       docsList.add(proceedingArtifactOne);
       Mockito.when(query.getResultList()).thenReturn(docsList);
       final List<ProceedingArtifact> docsListResult = proceedingArtifactDao
               .getAllProceedingArtifactsForMandatoryNotice(proceedingId, 12L);
       assertNotNull(docsListResult);
       assertEquals(1, docsList.size());
   }

    @Test
    public void testGetAllProceedingArtifactsForMotions() {
        mockSession();

        List<ProceedingArtifact> docsList = new ArrayList<>();
        ProceedingArtifact proceedingArtifactOne = new ProceedingArtifact();
        proceedingArtifactOne.setArtifactNm("artifctNm");
        docsList.add(proceedingArtifactOne);
        Mockito.when(query.getResultList()).thenReturn(docsList);
        final List<ProceedingArtifact> docsListResult = proceedingArtifactDao
                .getAllProceedingArtifactsForMotions(12L);
        assertNotNull(docsListResult);
        assertEquals(1, docsList.size());
    }
    
    @Test
    public void testGetAllProceedingArtifactsForAppeals() {
        mockSession();

        List<ProceedingArtifact> docsList = new ArrayList<>();
        ProceedingArtifact proceedingArtifactOne = new ProceedingArtifact();
        proceedingArtifactOne.setArtifactNm("artifctNm");
        docsList.add(proceedingArtifactOne);
        Mockito.when(query.getResultList()).thenReturn(docsList);
        final List<ProceedingArtifact> docsListResult = proceedingArtifactDao
                .getAllProceedingArtifactsForAppeals(12L);
        assertNotNull(docsListResult);
        assertEquals(1, docsList.size());
    }
    
    @Test
    public void testGetAllProceedingArtifactsForRehearing() {
        mockSession();

        List<ProceedingArtifact> docsList = new ArrayList<>();
        ProceedingArtifact proceedingArtifactOne = new ProceedingArtifact();
        proceedingArtifactOne.setArtifactNm("artifctNm");
        docsList.add(proceedingArtifactOne);
        Mockito.when(query.getResultList()).thenReturn(docsList);
        final List<ProceedingArtifact> docsListResult = proceedingArtifactDao
                .getAllProceedingArtifactsForRehearing(12L);
        assertNotNull(docsListResult);
        assertEquals(1, docsList.size());
    }
}
