package gov.uspto.patent.ptab.helper;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ProceedingCaseHelperTest {

    @InjectMocks
    private ProceedingCaseHelper proceedingCaseHelper;

    /**
     * Method used to initialize mock objects
     */
    @Before
    public void initMocks() {

        MockitoAnnotations.initMocks(this);
    }

    /**
     * test method to test prepareAsCaputuredClaimListFOUR
     */
    @Test
    public void testPrepareAsCaputuredClaimListFOUR() {
        final List<String> claimList = new ArrayList<>();
        claimList.add("5");
        claimList.add("1789");
        claimList.add("4578");
        claimList.add("457878");
        proceedingCaseHelper.prepareAsCaputuredClaimList(claimList);
        assertEquals("5", claimList.get(0));
    }

    /**
     * test method to test prepareExpandedList
     */
    @Test
    public void testPrepareExpandedList() {
        final List<String> response = proceedingCaseHelper.prepareExpandedList("1-1,1");
        assertEquals("1", response.get(0));
    }
}
