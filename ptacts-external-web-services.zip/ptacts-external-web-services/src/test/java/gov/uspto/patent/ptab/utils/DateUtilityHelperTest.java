package gov.uspto.patent.ptab.utils;

import org.junit.Test;

import java.util.Date;
import java.util.TimeZone;

import static gov.uspto.patent.ptab.utils.DateUtilityHelper.convertEpochTimeStampToDate;
import static gov.uspto.patent.ptab.utils.DateUtilityHelper.convertToDate;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

/**
 * This class is used to test DateUtilityHelper
 * 
 * @author 2020 development team
 */
public class DateUtilityHelperTest {

    /**
     * Test for convertToDate
     */
    @Test
    public void testConvertToDate() {
        Date date = convertToDate(null);
        date = convertToDate(new Date());
        assertEquals(new Date().toString(), date.toString());
    }

    /**
     * Test for converting msToDate
     */
    @Test
    public void testMsToDate() {
        final Date date = convertEpochTimeStampToDate(new Date().getTime());
        assertEquals(new Date().toString(), date.toString());

    }

    /**
     * Test for converting msToDate
     */
    @Test
    public void testEndOfTheDay() {
        final Date date = DateUtilityHelper.endOfTheDay(1547238881L);
        assertNotNull(date);

    }

    /**
     * Test for converting msToDate
     */
    @Test
    public void testConvertDateToString() {
        final String date = DateUtilityHelper.convertDateToString(new Date(), "MM/DD/YY");
        assertNotEquals(new Date().toString(), date.toString());
    }

    /**
     * Test for converting msToDate
     */
    @Test
    public void testFirstOrLastDayOfWeek() {
        final Date date = DateUtilityHelper.firstOrLastDayOfWeek(1547238881L, 2, "yyyy-MM-dd");
        assertNotEquals(new Date(), date);
    }

    /**
     * Test for converting msToDate
     */
    @Test
    public void testRemoveTime() {
        final Date date = DateUtilityHelper.removeTime(new Date());
        assertNotEquals(new Date().toString(), date.toString());

    }

    /**
     * Test for converting msToDate
     */
    @Test
    public void testConvertDateToLong() {
        final Long date = DateUtilityHelper.convertDateToLong(new Date());
        assertNotEquals(new Date().toString(), date.toString());
    }

    /**
     * Test for converting msToDate
     */
    @Test
    public void testLongToZone() {
        final String date = DateUtilityHelper.longToZone(121L);
        assertNotEquals(new Date().toString(), date.toString());
    }

    /**
     * Test for convertDateToStringFormat
     */
    @Test
    public void convertDateToStringFormatTest() {
        final String date = DateUtilityHelper.convertDateToStringFormat(new Date(), "mm/DD/yyyy");
        assertNotEquals(new Date().toString(), date.toString());
    }

    /**
     * Test for getDateFromEpochDate
     */
    @Test
    public void getDateFromEpochDateTest() {
        final Date input = new Date();
        final Date date = DateUtilityHelper.getDateFromEpochDate(input.getTime());
        assertNotNull(date);

    }

    /**
     * Test for addDays
     */
    @Test
    public void addDaysTest() {
        final Date input = new Date();
        final Date date = DateUtilityHelper.addDays(input);
        assertNotNull(date);
    }

    /**
     * Test for addOneYearToDate
     */
    @Test
    public void addOneYearToDateTest() {
        final Date input = new Date();
        final Date date = DateUtilityHelper.addOneYearToDate(input);
        assertNotNull(date);
    }
    
    /**
     * Test for longToDate
     */
    @Test
    public void testLongToDate() {
        final Date date = DateUtilityHelper.longToDate(145L);
        assertNotNull(date);
    }
    
    /**
     * Test for addDays
     */
    @Test
    public void testAddDays() {
        final Date input = new Date();
        final Date date = DateUtilityHelper.addDays(input,1);
        assertNotNull(date);
    }
    
    /**
     * Test for longToDateWithNoTimeStamp
     */
    @Test
    public void testLongToDateWithNoTimeStamp() {
        final Date date = DateUtilityHelper.longToDateWithNoTimeStamp(145L);
        assertNotNull(date);
    }
    
    /**
     * Test for getDate
     */
    @Test
    public void testGetDate() {
        final Date input = new Date();
        TimeZone tz = TimeZone.getTimeZone("0");
        final Date date = DateUtilityHelper.getDate(tz,input);
        assertNotNull(date);
    }

}
