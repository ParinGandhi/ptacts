package gov.uspto.patent.ptab.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.common.opsg.domain.ApplicationIdentifierQuery;
import gov.uspto.patent.ptab.service.ApplicationInformationService;

/*import gov.uspto.patent.ptab.common.opsg.domain.ApplicationIdentifierQuery;
import gov.uspto.patent.ptab.service.ApplicationInformationService;*/

/**
 * Test Class to test OpsgApplicationInformationController
 *
 * @author 2020 Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class OpsgApplicationInformationControllerTest {

    @InjectMocks
    private OpsgApplicationInformationController opsgApplicationInformationController;

    @Mock
    private ApplicationInformationService applicationInformationService;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    /**
     * Method used to test the get application info details
     */

    @Test
    public void testGetApplicationInfoDetails() {
        final JsonNode nodeMock = Mockito.mock(JsonNode.class);
        Mockito.when(applicationInformationService.getApplicationInfoDetails(Mockito.any())).thenReturn(nodeMock);
        final JsonNode response = opsgApplicationInformationController
                .getApplicationInfoDetails(new ApplicationIdentifierQuery());
        assertNotNull(response);
    }

}
