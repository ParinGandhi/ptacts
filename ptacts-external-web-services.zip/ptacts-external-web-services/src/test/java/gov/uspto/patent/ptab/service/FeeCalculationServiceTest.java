package gov.uspto.patent.ptab.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.FeeCalculationQuery;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.RestServiceClient;

@RunWith(MockitoJUnitRunner.class)
public class FeeCalculationServiceTest {

    @InjectMocks
    private FeeCalculationService feeCalculationService;
    
    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private ExternalServiceUriGenerator externalServiceUriGenerator;
    
    /**
     * test method to test getFeeCalculationDetails
     */
    @Test
    public void testGetFeeCalculationDetails() {
        final FeeCalculationQuery feeCalculationQuery=new FeeCalculationQuery();
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("feeCalculationUrl");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(), anyString())).thenReturn("userName");
        when(externalServiceUriGenerator.getFeeCalculationQuery(any(), anyString())).thenReturn("userName");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);    
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseObj);
        feeCalculationService.getFeeCalculationDetails(feeCalculationQuery);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).findDescriptionByTypeCodeAndValueTx(anyString(),anyString());

    }
}
