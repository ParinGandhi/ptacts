package gov.uspto.patent.ptab.dao;

import gov.uspto.patent.ptab.domain.Audit;
import gov.uspto.patent.ptab.domain.Claims;
import gov.uspto.patent.ptab.domain.ProceedingClaims;
import gov.uspto.patent.ptab.entities.*;
import gov.uspto.patent.ptab.helper.ProceedingCaseHelper;
import gov.uspto.patent.ptab.repository.ClaimChallengeReasonRepository;
import gov.uspto.patent.ptab.repository.PrcdngClmStatyGroundRepository;
import gov.uspto.patent.ptab.repository.PrcdngStatyGrndClmRsnRepository;
import gov.uspto.patent.ptab.repository.ProceedingRepository;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

public class TrialsProceedingClaimsInfoDAOTest {

    @InjectMocks
    private TrialsProceedingClaimsInfoDAO trialsProceedingClaimsInfoDAO;

    @Mock
    private final SessionFactory sessionFactory = mock(SessionFactory.class);

    @Mock
    private ProceedingCaseHelper proceedingCaseHelper;

    @Mock
    private ProceedingRepository proceedingRepository;

    @Mock

    private PrcdngClmStatyGroundRepository prcdngClmStatyGroundRepository;

    @Mock
    private PrcdngStatyGrndClmRsnRepository prcdngStatyGrndClmRsnRepository;

    @Mock
    private ClaimChallengeReasonRepository claimChallengeReasonRepository;

    @Mock
    private PTABBusinessUtils ptabBusinessUtils;

    private Session session;
    @SuppressWarnings("rawtypes")
    private Query query;
    @SuppressWarnings("rawtypes")
    private Query query1;

    /**
     * Method used to initialize mock objects
     */
    @Before
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * This method is used to mock session and query objects.
     */
    private void mockSession() {
        session = Mockito.mock(Session.class);
        query = Mockito.mock(Query.class);
        query1 = Mockito.mock(Query.class);
        Mockito.when(sessionFactory.getCurrentSession()).thenReturn(session);
        Mockito.when(session.createNamedQuery(Mockito.anyString(), Mockito.any())).thenReturn(query);

    }

    /**
     * method to test getProceedingClaimsInfo
     */
    @Test
    public void getProceedingClaimsInfoTest() {
        mockSession();
        Mockito.when(session.getNamedQuery("getTrailsClaimsInfo")).thenReturn(query);
        Mockito.when(session.getNamedQuery("getTrailsCapturedClaimsInfo")).thenReturn(query1);
        Mockito.when(proceedingCaseHelper.prepareAsCaputuredClaimList(Mockito.<String> anyList())).thenReturn("1-3,5-7");

        final List<Object[]> resultSet1 = new ArrayList<>();
        final Object[] result1 = { "1234", "Category 1" };
        resultSet1.add(result1);

        final List<String> resultSet2 = new ArrayList<>();
        resultSet2.add("1");
        resultSet2.add("2");
        resultSet2.add("3");
        resultSet2.add("5");
        resultSet2.add("6");
        resultSet2.add("7");

        Mockito.when(query.list()).thenReturn(resultSet1);
        Mockito.when(query1.list()).thenReturn(resultSet2);

        final ProceedingClaims proceedingClaims = trialsProceedingClaimsInfoDAO.getProceedingClaimsInfo("IPR2019-01369");

        assertEquals(1, proceedingClaims.getClaims().size());
    }

    @Test
    public void deleteClaimsByIdsTest() {

        mockSession();
        final List<BigDecimal> claimIdsList = new ArrayList<>();
        claimIdsList.add(BigDecimal.valueOf(123));
        claimIdsList.add(BigDecimal.valueOf(124));
        claimIdsList.add(BigDecimal.valueOf(125));
        Mockito.when(session.getNamedQuery("deleteClaimsByIds")).thenReturn(query);
        Mockito.when(query.executeUpdate()).thenReturn(1);
        trialsProceedingClaimsInfoDAO.deleteClaimsByIds(claimIdsList);
        int out = trialsProceedingClaimsInfoDAO.deleteClaimsByIds(claimIdsList);
        assertEquals(1, out);

    }

    @Test
    public void createProceedingClaimsInfoTest() {
        mockSession();
        ProceedingClaims proceedingClaimsRequest = new ProceedingClaims();
        proceedingClaimsRequest.setCaseNo("IPR2020-987");
        Audit audit = new Audit();
        audit.setLastModifiedUserIdentifier("userOne");
        List<Claims> claims = new ArrayList<>();
        Claims claim = new Claims();
        claim.setAsCaptured("4");
        claim.setStatGroundId(1L);
        claims.add(claim);

        proceedingClaimsRequest.setAudit(audit);
        proceedingClaimsRequest.setClaims(claims);

        ProceedingEntity proceeding = new ProceedingEntity();
        proceeding.setProceedingId(123456L);
        when(proceedingRepository.getProceedingDetails(anyString())).thenReturn(proceeding);
        List<String> expandedList = List.of("4");
        when(proceedingCaseHelper.prepareExpandedList(anyString())).thenReturn(expandedList);
        BigDecimal userId = new BigDecimal(123);
        when(ptabBusinessUtils.getUserIdentifier(anyString())).thenReturn(userId);
        when(sessionFactory.getCurrentSession().save(any(ProceedingClaim.class))).thenReturn(1);
        when(sessionFactory.getCurrentSession().save(any(ClaimChallengeReason.class))).thenReturn(2);
        when(sessionFactory.getCurrentSession().save(any(PrcdngClmStatyGround.class))).thenReturn(3);

        trialsProceedingClaimsInfoDAO.createProceedingClaimsInfo(proceedingClaimsRequest);

        verify(session).persist(any(ClaimChallengeReason.class));
        verify(session).persist(any(ProceedingClaim.class));

    }

    @Test
    public void updateProceedingClaimsInfoTest() {
        mockSession();
        ProceedingClaims proceedingClaimsRequest = new ProceedingClaims();
        proceedingClaimsRequest.setCaseNo("IPR2020-987");
        Audit audit = new Audit();
        audit.setLastModifiedUserIdentifier("userOne");
        List<Claims> claims = new ArrayList<>();
        Claims claim = new Claims();
        claim.setAsCaptured("4");
        claim.setStatGroundId(1L);
        claim.setIdentifier("1234");
        claims.add(claim);

        proceedingClaimsRequest.setAudit(audit);
        proceedingClaimsRequest.setClaims(claims);

        List<PrcdngStatyGrndClmRsn> grndClmRsnList = new ArrayList<>();
        PrcdngStatyGrndClmRsn prcdngStatyGrndClmRsn = new PrcdngStatyGrndClmRsn();
        prcdngStatyGrndClmRsn.setPrcdngStatyGrndClmRsnId(2L);
        prcdngStatyGrndClmRsn.setFkPrcdgClmChallengeReasonId(3L);
        grndClmRsnList.add(prcdngStatyGrndClmRsn);
        when(prcdngStatyGrndClmRsnRepository.getAllClaimsByReasonId(anyLong())).thenReturn(grndClmRsnList);
        ProceedingEntity proceeding = new ProceedingEntity();
        proceeding.setProceedingId(123456L);
        when(proceedingRepository.getProceedingDetails(anyString())).thenReturn(proceeding);
        List<String> expandedList = List.of("4");
        when(proceedingCaseHelper.prepareExpandedList(anyString())).thenReturn(expandedList);

        BigDecimal userId = new BigDecimal(123);
        when(ptabBusinessUtils.getUserIdentifier(anyString())).thenReturn(userId);
        when(sessionFactory.getCurrentSession().save(any(ProceedingClaim.class))).thenReturn(1);
        when(sessionFactory.getCurrentSession().save(any(ClaimChallengeReason.class))).thenReturn(2);
        when(sessionFactory.getCurrentSession().save(any(PrcdngClmStatyGround.class))).thenReturn(3);

        trialsProceedingClaimsInfoDAO.updateProceedingClaimsInfo(proceedingClaimsRequest);

        //verify(session).(any(ClaimChallengeReason.class));
        //verify(session).save(any(ProceedingClaim.class));

    }
}
