package gov.uspto.patent.ptab.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.RestServiceClient;

@RunWith(MockitoJUnitRunner.class)
public class PtabStateRoleServiceTest {

    @InjectMocks
    private PtabStateRoleService ptabStateRoleService;
    
    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Mock
    private RestServiceClient restServiceClient;
    
    /**
     * test method to test getStateRoleDisplay
     */
    @Test
    public void testgetStateRoleDisplay() {
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(),Mockito.anyString())).thenReturn("ptabStateRoleUrl");
        Mockito.when(externalServiceUriGenerator.constructPtabStateRoleUrl(Mockito.anyString(),Mockito.anyString())).thenReturn("ptabStateRoleUrl");
        Mockito.when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(Mockito.anyString(),Mockito.anyString())).thenReturn("ptabStateRoleUrl");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.callPTABExternalServiceURL(any(),any(),any(),any(),anyString())).thenReturn(responseObj);
        ptabStateRoleService.getStateRoleDisplay("CN478");
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(),anyString());
    }
}
