package gov.uspto.patent.ptab.controller;

import gov.uspto.patent.ptab.dao.StatutoryGroundsDAO;
import gov.uspto.patent.ptab.domain.ProceedingClaims;
import gov.uspto.patent.ptab.domain.ProceedingIdentifiers;
import gov.uspto.patent.ptab.service.ProceedingClaimsInfo;
import gov.uspto.patent.ptab.service.ProceedingClaimsInfoService;
import gov.uspto.patent.ptab.utils.PTABException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * Test case for ProceedingClaimsController
 * 
 * @author 2020 - Development Team
 *
 */
public class ProceedingClaimsControllerTest {

    @InjectMocks
    private ProceedingClaimsController proceedingClaimsController;

    @Mock
    private ProceedingClaimsInfo proceedingClaimsInfo;

    @Mock
    private ProceedingClaimsInfoService proceedingClaimsInfoService;

    @Mock
    private StatutoryGroundsDAO statutoryGroundsDAO;

    @Before
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Test method for ProceedingClaimsInfo
     * 
     * @throws Exception
     */
    @Test(expected = PTABException.class)
    public void getProceedingClaimsInfo() throws Exception {
        final ProceedingClaims proceedingClaims = new ProceedingClaims();

        when(proceedingClaimsInfo.getProceedingClaims(any(ProceedingIdentifiers.class))).thenReturn(proceedingClaims);
        proceedingClaimsController.getProceedingClaimsInfo("TRIALS", "IPR2014-00497");
        Mockito.verify(proceedingClaimsInfo, Mockito.atMost(1)).updateProceedingClaim(any(ProceedingClaims.class));

    }

    @Test (expected = PTABException.class)
    public void getProceedingClaimsNullInfo() throws Exception {
        when(proceedingClaimsInfo.getProceedingClaims(any(ProceedingIdentifiers.class))).thenReturn(null);
        proceedingClaimsController.getProceedingClaimsInfo("TRIALS", "IPR2014-00497");
    }

    /**
     * Test method for createClaims Test
     * 
     * @throws Exception
     */
    @Test
    public void createClaimTest() throws Exception {
        ProceedingClaims proceedingClaims = new ProceedingClaims();
        proceedingClaimsController.createClaim(proceedingClaims);
        Mockito.verify(proceedingClaimsInfo, Mockito.atMost(1)).createProceedingClaim(any(ProceedingClaims.class));
    }

    /**
     * Test method for updateClaimsInfo
     * 
     * @throws Exception
     */
    @Test
    public void updateClaimsInfoTest() throws Exception {
        ProceedingClaims proceedingClaims = new ProceedingClaims();
        proceedingClaimsController.updateClaimsInfo(proceedingClaims);
        Mockito.verify(proceedingClaimsInfo, Mockito.atMost(1)).updateProceedingClaim(any(ProceedingClaims.class));
    }

    /**
     * Test method for deleteClaimsInfo
     * 
     * @throws Exception
     */
    @Test
    public void deleteClaimsInfoTest() throws Exception {
        proceedingClaimsController.deleteClaimsInfo(1234L);
        Mockito.verify(proceedingClaimsInfo, Mockito.atMost(1)).deleteProceedingClaim(any(Long.class));
    }
    
    /**
     * Test method for getStatutoryGrounds
     * 
     * @throws Exception
     */
    @Test
    public void testGetStatutoryGrounds() throws Exception {
        proceedingClaimsController.getStatutoryGrounds();
        Mockito.verify(proceedingClaimsInfo, Mockito.atMost(1)).deleteProceedingClaim(any(Long.class));
    }

}
