package gov.uspto.patent.ptab.utils;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import static org.junit.Assert.assertNotNull;

public class PTABExceptionTest {

    @Test
    public void constructorTest() {
        PTABException pTABException = new PTABException(HttpStatus.BAD_REQUEST, "test", new RuntimeException());
        assertNotNull(pTABException.getResponseEntity());
        pTABException = new PTABException(HttpStatus.BAD_REQUEST, "test");
        assertNotNull(pTABException.getResponseEntity());
    }

}
