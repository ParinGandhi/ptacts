package gov.uspto.patent.ptab.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.domain.ProceedingPartyQuery;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.RestServiceClient;

/**
 * Test Class to test ProceedingPartyService
 *
 * @author 2020 Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ProceedingPartyServiceTest {

    private static final String CHAR_N = "N";

    private static final int INT_ONE = 1;

    private static final String EXHIBIT_NUM_1234 = "1234";

    private static final String PROCEEDING_PARTY_DETAILS_URL = "proceedingPartyDetailsUrl";

    private static final String TEST = "test";

    @InjectMocks
    private ProceedingPartyService proceedingPartyService;

    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Mock
    private PTABBusinessUtils ptabBusinessUtils;

    @Mock
    private ExternalUserService externalUserService;
    
    @Mock
    private HttpServletRequest httpServletRequest;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        when(httpServletRequest.getAttribute(Mockito.any())).thenReturn("test");
    }

    /**
     * Method used to test the get next exhibit number
     *
     * @throws JsonProcessingException
     */
    @Test
    public void testGetNextExhibitNumber() throws JsonProcessingException {
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(PROCEEDING_PARTY_DETAILS_URL);
        final Map<String, String> map = new HashMap<>();
        map.put(TEST, TEST);
        final ObjectMapper mapper = new ObjectMapper();
        final String json = mapper.writeValueAsString(map);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(new ResponseEntity<>(json, HttpStatus.CREATED));
        final Map<String, String> response = proceedingPartyService.getNextExhibitNumber(EXHIBIT_NUM_1234);
        assertEquals(TEST, response.get(TEST));
    }

    /**
     * Method used to test save proceeding part details
     *
     *
     */
    @Test
    public void testSavePartyDetails() {
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(PROCEEDING_PARTY_DETAILS_URL);
        final ObjectNode proceedingParties = Mockito.mock(ObjectNode.class);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(new ResponseEntity<>(proceedingParties, HttpStatus.CREATED));
        proceedingPartyService.savePartyDetails(proceedingParties, CHAR_N);
        Mockito.verify(restServiceClient, Mockito.times(INT_ONE)).callPTABExternalServiceURL(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());
    }

    /**
     * Method used to test update proceeding part details
     *
     *
     */
    @Test
    public void testUpdatePartyDetails() {
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(PROCEEDING_PARTY_DETAILS_URL);
        final ObjectNode proceedingParties = Mockito.mock(ObjectNode.class);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(new ResponseEntity<>(proceedingParties, HttpStatus.CREATED));
        proceedingPartyService.updatePartyDetails(proceedingParties);
        Mockito.verify(restServiceClient, Mockito.times(INT_ONE)).callPTABExternalServiceURL(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());
    }

    /**
     * Method used to test delete proceeding part details
     *
     *
     */
    @Test
    public void testDeletePartyDetails() {
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(PROCEEDING_PARTY_DETAILS_URL);
        Mockito.when(externalServiceUriGenerator.getProceedingPartyDeleteUrl(Mockito.any(ProceedingPartyQuery.class),
                Mockito.anyString())).thenReturn("value");
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(new ResponseEntity<>(null, HttpStatus.CREATED));
        proceedingPartyService.deletePartyDetails(new ProceedingPartyQuery());
        Mockito.verify(restServiceClient, Mockito.times(INT_ONE)).callPTABExternalServiceURL(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());
    }

    /**
     * Method used to test switch proceeding part details
     *
     *
     */
    @Test
    public void testPerformCounselSwitch() {
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(PROCEEDING_PARTY_DETAILS_URL);
        final ObjectNode proceedingParties = Mockito.mock(ObjectNode.class);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(new ResponseEntity<>(proceedingParties, HttpStatus.CREATED));
        proceedingPartyService.performCounselSwitch(proceedingParties, true);
        Mockito.verify(restServiceClient, Mockito.times(INT_ONE)).callPTABExternalServiceURL(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());
    }

    /**
     * Method used to test getAllProceedingPartyDetails
     */
    @Test
    public void testGetAllProceedingPartyDetails() {
        final CaseDocumentsDataQuery caseDocumentsDataQuery = new CaseDocumentsDataQuery();
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(PROCEEDING_PARTY_DETAILS_URL);
        final ObjectNode proceedingParties = Mockito.mock(ObjectNode.class);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(new ResponseEntity<>(proceedingParties, HttpStatus.CREATED));
        Mockito.when(externalUserService.getPrcdPartyGroupType(caseDocumentsDataQuery.getProceedingNumber()))
                .thenReturn("PETITIONER");
        proceedingPartyService.getAllProceedingPartyDetails(caseDocumentsDataQuery);
        Mockito.verify(restServiceClient, Mockito.times(INT_ONE)).callPTABExternalServiceURL(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());
    }

    /**
     * Method used to test getPrcdCounselInfo
     */
    @Test
    public void testGetPrcdCounselInfo() {
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(PROCEEDING_PARTY_DETAILS_URL);
        final ObjectNode proceedingParties = Mockito.mock(ObjectNode.class);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(new ResponseEntity<>(proceedingParties, HttpStatus.CREATED));
        proceedingPartyService.getPrcdCounselInfo("caseType", "registrationNumber", "email");
        Mockito.verify(restServiceClient, Mockito.times(INT_ONE)).callPTABExternalServiceURL(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());
    }
}
