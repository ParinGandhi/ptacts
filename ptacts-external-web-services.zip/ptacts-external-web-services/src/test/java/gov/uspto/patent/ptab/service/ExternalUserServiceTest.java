package gov.uspto.patent.ptab.service;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import jakarta.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import gov.uspto.patent.ptab.dao.ExternalUserDao;
import gov.uspto.patent.ptab.utils.PTABException;

@RunWith(MockitoJUnitRunner.class)
public class ExternalUserServiceTest {

    @InjectMocks
    private ExternalUserService externalUserService;
    
    @Mock
    ExternalUserDao externalUserDao;

    @Mock
    private HttpServletRequest httpServletRequest;
    
    /**
     * test method to test getPrcdPartyGroupType
     */
    @Test
    public void testGetPrcdPartyGroupType() {
        when(externalUserDao.getUserPrcdPartyGroupType(anyString(), anyString())).thenReturn("userName");
        when(httpServletRequest.getAttribute(anyString())).thenReturn("valid-user");
        externalUserService.getPrcdPartyGroupType("PRO145");
        Mockito.verify(externalUserDao, Mockito.atMost(1)).getUserPrcdPartyGroupType(anyString(),anyString());
    }

}
