package gov.uspto.patent.ptab.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.domain.Petition;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.encrypt.RC4CipherEntity;
import gov.uspto.patent.ptab.service.ProceedingArtifactService;

public class ProceedingArtifactControllerTest {

    @InjectMocks
    ProceedingArtifactController proceedingArtifactController;

    @Mock
    private ProceedingArtifactService proceedingArtifactService;

    @Mock
    CaseDocumentsDataQuery query;

    @Mock
    List<PetitionDocument> petitionDocuments;

    @Mock
    PetitionDocument petitionDocument;

    @Mock
    Petition petition;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        query = new CaseDocumentsDataQuery();
        query.setCaseStatus("test");
        query.setProceedingNumber("123");

        petition = new Petition();
        petition.setPatentNumber("1234");
        petition.setPetitionIdentifier(123L);

        petitionDocuments = new ArrayList<>();
        petitionDocument = new PetitionDocument();
        petitionDocument.setArtifactIdentifer("111");
        petitionDocument.setArtifactSubmissionIdentifier(111L);
        petitionDocument.setDocumentAction("testDocument");
        petitionDocuments.add(petitionDocument);

        final Multimap<String, List<PetitionDocument>> joinderDocumentMap = ArrayListMultimap.create();
        joinderDocumentMap.put("key", petitionDocuments);
        petition.setJoinderDocumentMap(joinderDocumentMap);

    }

    @Test
    public void getNextPaperSequenceIdentifierTest() {

        final Map<String, String> sequenceMap = new HashMap<>();
        sequenceMap.put("test", "test");
        Mockito.when(proceedingArtifactService.getNextPaperSequenceIdentifier(query)).thenReturn(sequenceMap);
        final Map<String, String> response = proceedingArtifactController.getNextPaperSequenceIdentifier(query);
        Assert.assertNotNull(response);
    }

    @Test
    public void updateProceedingArtifactTest() {
        final PetitionDocument petitionDoc = new PetitionDocument();
        Mockito.when(proceedingArtifactService.updateProceedingArtifact(Mockito.anyLong(), Mockito.any()))
                .thenReturn(petitionDoc);
        final String encryptString = RC4CipherEntity.encrypt("123");
        final PetitionDocument response = proceedingArtifactController.updateProceedingArtifact(petitionDoc, encryptString);
        Assert.assertNotNull(response);
    }

    @Test
    public void getAllArtifactsTest() {
        CaseDocumentsDataQuery caseDocumentsDataQuery = new CaseDocumentsDataQuery();
        Mockito.verify(proceedingArtifactService, Mockito.atMost(1)).getAllArtifacts(Mockito.any(), Mockito.anyBoolean());
        final List<PetitionDocument> response = proceedingArtifactController.getAllArtifacts(caseDocumentsDataQuery);
        Assert.assertNotNull(response);

    }

    @Test
    public void createProceedingArtifactForExternalTest() {
        final Petition petition = new Petition();
        Mockito.when(proceedingArtifactService.createProceedingArtifactForExternal(Mockito.any())).thenReturn(petition);
        final Petition response = proceedingArtifactController.createProceedingArtifactForExternal(petition);
        Assert.assertNotNull(response);
    }

    @Test
    public void deleteProceedingArtifactTest() {
        Mockito.doNothing().when(proceedingArtifactService).deleteProceedingArtifact(Mockito.any());
        final String encryptString = RC4CipherEntity.encrypt("123");
        proceedingArtifactController.deleteProceedingArtifact(encryptString);
        Assert.assertNotNull(proceedingArtifactController);
    }
}
