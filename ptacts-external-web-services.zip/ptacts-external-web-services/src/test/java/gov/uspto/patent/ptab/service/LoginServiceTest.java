package gov.uspto.patent.ptab.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.LoginQuery;
import gov.uspto.patent.ptab.domain.UserLoginDetails;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.RestServiceClient;

/**
 * Test Class to test LoginService
 *
 * @author 2020 Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class LoginServiceTest {

    private static final String USER_DETAILS_URL = "userDetailsUrl";

    private static final String TEST = "test";

    private static final String TEST_URL = "someur";

    @InjectMocks
    private LoginService loginService;

    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Method used to test the get user details
     */
    @Test
    public void testGetUserDetails() {

        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(USER_DETAILS_URL);
        Mockito.when(externalServiceUriGenerator.userDetailsUrl(Mockito.any(LoginQuery.class), Mockito.anyString()))
                .thenReturn(TEST_URL);
        Mockito.when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(TEST);
        final LoginQuery loginQuery = new LoginQuery();
        loginQuery.setEmailAddressText(TEST);
        final UserLoginDetails userLoginDetails = new UserLoginDetails();
        userLoginDetails.setEmailId(TEST);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity<>(userLoginDetails, HttpStatus.CREATED));
        final UserLoginDetails response = loginService.getUserDetails(loginQuery);
        assertEquals(userLoginDetails.getEmailId(), response.getEmailId());
    }

}
