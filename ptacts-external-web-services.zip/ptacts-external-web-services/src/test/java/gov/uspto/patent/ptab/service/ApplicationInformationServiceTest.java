package gov.uspto.patent.ptab.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.patent.ptab.common.opsg.domain.ApplicationIdentifierQuery;
import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.RestServiceClient;

/**
 * Test Class to test ApplicationInformationService
 *
 * @author 2020 Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ApplicationInformationServiceTest {

    private static final String APP_NO_12345 = "12345";

    private static final String TEST = "test";

    private static final String TEST_URL = "someurl";

    private static final String APPLICATION_INFO_DETAILS_URL = "applicationInfoDetailsUrl";

    @InjectMocks
    private ApplicationInformationService applicationInformationService;

    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Before
    public void setUp() {

        MockitoAnnotations.initMocks(this);
    }

    /**
     * Method used to test the get the application info details
     *
     * @throws JsonProcessingException
     */
    @Test
    public void testGetApplicationInfoDetails() throws JsonProcessingException {
        Mockito.when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(APPLICATION_INFO_DETAILS_URL);
        Mockito.when(externalServiceUriGenerator.applicationInfoUrl(Mockito.any(ApplicationIdentifierQuery.class),
                Mockito.anyString())).thenReturn(TEST_URL);
        Mockito.when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(TEST);
        final ApplicationIdentifierQuery applicationIdentifierQuery = new ApplicationIdentifierQuery();
        applicationIdentifierQuery.setApplicationNumber(APP_NO_12345);
        final ObjectMapper mapper = new ObjectMapper();
        final String json = mapper.writeValueAsString(applicationIdentifierQuery);
        Mockito.when(restServiceClient.callPTABExternalServiceURL(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity<>(json, HttpStatus.CREATED));
        final JsonNode response = applicationInformationService.getApplicationInfoDetails(applicationIdentifierQuery);
        assertNotNull(response);
    }

}
