package gov.uspto.patent.ptab.utils;



import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;



@RunWith(MockitoJUnitRunner.class)
public class MilliSecEpochSeralizerTest {
	
	@InjectMocks
	private MilliSecEpochSeralizer milliSecEpochSeralize;
	
	@Mock
	private JsonGenerator jsonGenerator;
	
	@Mock
	private SerializerProvider serializerProvider;
	
	@Before
    public  void setup() {
        MockitoAnnotations.initMocks(this);
    }
	
	
	@Test
	 public void serializeTest(){
		try {
			
			
			
			milliSecEpochSeralize.serialize(new Date(),jsonGenerator,serializerProvider);
			
		} catch (IOException e) {
			fail("is not expected to be here");
		}
	}
	
	
	

}
