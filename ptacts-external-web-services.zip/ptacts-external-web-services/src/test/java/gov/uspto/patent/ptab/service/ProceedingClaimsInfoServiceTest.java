package gov.uspto.patent.ptab.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.Claims;
import gov.uspto.patent.ptab.domain.ProceedingClaims;
import gov.uspto.patent.ptab.domain.ProceedingIdentifiers;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.RestServiceClient;

@RunWith(MockitoJUnitRunner.class)
public class ProceedingClaimsInfoServiceTest {
    @InjectMocks
    private ProceedingClaimsInfoService proceedingClaimsInfoService;

    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    private CodeReferenceDao codeReferenceDao;
    
    @Mock
    private PTABBusinessUtils ptabBusinessUtils;

    @Test
    public void getProceedingClaims() {
        ProceedingIdentifiers searchIdentifier = new ProceedingIdentifiers();
        searchIdentifier.setCaseNo("IPR2019-01369");
        searchIdentifier.setCaseType("TRIALS");

        ProceedingClaims proceedingClaims = new ProceedingClaims();
        proceedingClaims.setCaseNo("IPR2019-01369");
        proceedingClaims.setCaseType("TRIALS");

        List<Claims> claimsList = new ArrayList<Claims>();
        Claims claims = new Claims();
        claims.setIdentifier("12345");
        claims.setCount("9");
        claims.setAsCaptured("4-8,12-15");
        claims.setExpanded("[4, 5, 6, 7, 8, 12, 13, 14, 15]");
        claimsList.add(claims);
        proceedingClaims.setClaims(claimsList);

        final String loggedInUser ="loggedInUser";
        Mockito.when(ptabBusinessUtils.getLoggedInUserId()).thenReturn(loggedInUser);
        
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("motionDetailsUrl");
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        when(restServiceClient.callPTABExternalServiceURL(any(), any(), any(), any(), anyString())).thenReturn(responseObj);
        proceedingClaimsInfoService.getProceedingClaims(searchIdentifier);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

}
