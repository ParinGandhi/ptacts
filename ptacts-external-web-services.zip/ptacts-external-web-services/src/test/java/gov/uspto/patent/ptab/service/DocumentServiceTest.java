package gov.uspto.patent.ptab.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.DocumentQuery;
import gov.uspto.patent.ptab.domain.DocumentsQuery;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.entities.ProceedingEntity;
import gov.uspto.patent.ptab.repository.ProceedingRepository;
import gov.uspto.patent.ptab.utils.DocumentUtils;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.RestServiceClient;

@RunWith(MockitoJUnitRunner.class)
public class DocumentServiceTest {

    @InjectMocks
    private DocumentService DocumentService;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Mock
    private ProceedingRepository proceedingRepository;

    @Mock
    private ExternalUserService externalUserService;

    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ResponseEntity<byte[]> fileContentRespons;
    
    @Mock
    private DocumentUtils docUtils;

    /**
     * test method to test storeDocument
     * @throws IOException 
     */
    @Test(expected = Exception.class)
    public void testStoreDocument() throws IOException {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString()))
                .thenReturn("externalArtifactUpdateUrl");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(), anyString())).thenReturn("systemusername");
        when(docUtils.checkforPassWordEncrypter(any())).thenReturn(true);
        final ResponseEntity<Object> responseObj = Mockito.mock(ResponseEntity.class);
        final String str = "string";
        final byte array[] = str.getBytes();
        final MultipartFile file = new MockMultipartFile("name", array);
        DocumentService.storeDocument(145L, file,"PAPER");
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

    /**
     * test method to test downloadDocument
     * 
     * @throws IOException
     */
    @Test(expected = Exception.class)
    public void testDownloadDocument() throws IOException {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString()))
                .thenReturn("externalArtifactUpdateUrl");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(), anyString())).thenReturn("systemusername");
        when(externalServiceUriGenerator.getDownloadDocumentUrl(any(), anyString())).thenReturn("Board");
        final ProceedingEntity proceedingEntity = new ProceedingEntity();
        when(proceedingRepository.getProceeding(any())).thenReturn(proceedingEntity);
        final PetitionDocument responseObj = new PetitionDocument();
        when(restServiceClient.callExternalServiceURL(any(), any(), any(), any())).thenReturn(responseObj);
        final DocumentQuery documentQuery = new DocumentQuery();
        documentQuery.setArtifactId("145");
        DocumentService.downloadDocument(145L, documentQuery, false);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

    /**
     * test method to test downloadDocumentAVAIBOARD
     * 
     * @throws IOException
     */
    @Test(expected = Exception.class)
    public void testDownloadDocumentAVAIBOARD() throws IOException {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString()))
                .thenReturn("externalArtifactUpdateUrl");
        final ProceedingEntity proceedingEntity = new ProceedingEntity();
        when(proceedingRepository.getProceeding(any())).thenReturn(proceedingEntity);
        final PetitionDocument responseObj = new PetitionDocument();
        when(restServiceClient.callExternalServiceURL(any(), any(), any(), any())).thenReturn(responseObj);
        final DocumentQuery documentQuery = new DocumentQuery();
        documentQuery.setArtifactId("145");
        responseObj.setAvailability("Board");
        DocumentService.downloadDocument(145L, documentQuery, false);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }

    /**
     * test method to test downloadDocumentFilingParty
     * 
     * @throws IOException
     */
    @Test(expected = Exception.class)
    public void testDownloadDocumentFilingParty() throws IOException {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString()))
                .thenReturn("externalArtifactUpdateUrl");
        final ProceedingEntity proceedingEntity = new ProceedingEntity();
        when(proceedingRepository.getProceeding(any())).thenReturn(proceedingEntity);
        final PetitionDocument responseObj = new PetitionDocument();
        when(restServiceClient.callExternalServiceURL(any(), any(), any(), any())).thenReturn(responseObj);
        final DocumentQuery documentQuery = new DocumentQuery();
        documentQuery.setArtifactId("145");
        responseObj.setFilingParty("Filing party and Board");
        responseObj.setAvailability("Filing party and Board");
        DocumentService.downloadDocument(145L, documentQuery, false);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }
    
    /**
     * test method to test storeDocument
     * 
     * @throws IOException
     */
    @Test(expected = Exception.class)
   
    public void testGetDocument() throws IOException {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString()))
                .thenReturn("externalArtifactUpdateUrl");
        //when(externalServiceUriGenerator.constructGetDocumentUrl(any(), anyString())).thenReturn("Board");
        when(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(anyString(), anyString())).thenReturn("systemusername");
        final PetitionDocument responseObj = new PetitionDocument();
        final DocumentsQuery documentQuery = new DocumentsQuery();
        documentQuery.setArtifactId(145L);
        documentQuery.setFileName("newFile");
        responseObj.setFilingParty("Filing party and Board");
        responseObj.setAvailability("Filing party and Board");
        DocumentService.getDocument(145L, documentQuery);
        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
    }
    
}
