package gov.uspto.patent.ptab.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;

@RunWith(MockitoJUnitRunner.class)
public class MilliSecEpochDeserializerTest {
	
	@InjectMocks
	private MilliSecEpochDeserializer milliSecEpochDeserializer;
	
	@Mock
	private JsonParser jsonParser;
	
	@Mock
	private DeserializationContext deserializationContext;
	
	@Before
    public  void setup() {
        MockitoAnnotations.initMocks(this);
    }
	
	@Test
	public void deserializeTest() {
		try {
			Mockito.when(jsonParser.getText()).thenReturn("123");
			Date date =milliSecEpochDeserializer.deserialize(jsonParser,deserializationContext);
			assertEquals(date,new Date(123));
		} catch (IOException e) {
			fail("not expected to be here");
			
		}
		
	}
	
	

}
