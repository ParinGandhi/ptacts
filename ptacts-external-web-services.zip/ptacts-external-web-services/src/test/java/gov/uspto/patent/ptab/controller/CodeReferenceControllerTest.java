package gov.uspto.patent.ptab.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import gov.uspto.patent.ptab.domain.CodeReferenceLookup;
import gov.uspto.patent.ptab.domain.CodeReferenceQuery;
import gov.uspto.patent.ptab.service.ReferenceDataService;

/**
 * This is a Test class for CaseSearchControllerTest
 *
 * @author 2020 DevelopmentTeam
 *
 */
public class CodeReferenceControllerTest {

    @InjectMocks
    private CodeReferenceDataController codeReferenceDataController;

    @Mock
    private ReferenceDataService referenceDataService;

    @Before
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getCaseBasicDetailsTest() throws Exception {
        final CodeReferenceQuery codeReferenceQuery = new CodeReferenceQuery();
        codeReferenceQuery.setTypeCode("IPR2016-00449");
        final CodeReferenceLookup response = new CodeReferenceLookup();
        response.setTypeCode("descriptionTx");

        final List<CodeReferenceLookup> list = new ArrayList<>();
        list.add(response);
        when(referenceDataService.getCodeReferenceType(any())).thenReturn(list);

        final List<CodeReferenceLookup> responseList = codeReferenceDataController.getCodeReferenceTypes(codeReferenceQuery);
        assertEquals(responseList.get(0).getTypeCode(), response.getTypeCode());
    }
}
