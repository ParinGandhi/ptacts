package gov.uspto.patent.ptab.utils;

import static org.junit.Assert.assertEquals;

import java.util.Locale;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.MessageSource;

@RunWith(MockitoJUnitRunner.class)
public class PTABMessageUtilTest {

    @InjectMocks
    private PTABMessageUtil pTABMessageUtil;

    @Mock
    private MessageSource messageSource;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        pTABMessageUtil.setMessageSource(messageSource);

    }

    @Test
    public void getMessage() {
        Mockito.when(messageSource.getMessage("dfg", new Object[] { 123 }, Locale.getDefault())).thenReturn("123");
        String value = pTABMessageUtil.getMessage("dfg", new Object[] { 123 });
        assertEquals("123", value);

    }
	

	

}
