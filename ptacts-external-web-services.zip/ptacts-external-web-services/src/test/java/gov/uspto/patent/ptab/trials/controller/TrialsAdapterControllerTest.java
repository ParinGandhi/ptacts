package gov.uspto.patent.ptab.trials.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import gov.uspto.patent.ptab.domain.Petition;
import gov.uspto.patent.ptab.trials.domain.MotionDetails;
import gov.uspto.patent.ptab.trials.domain.RehearingInfo;
import gov.uspto.patent.ptab.trials.service.TrialsAdapterService;

/**
 * Test case for TrialsAdapterController
 * 
 * @author 2020 - Development Team
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class TrialsAdapterControllerTest {

    @InjectMocks
    private TrialsAdapterController trialsAdapterController;
    
    @Mock
    private TrialsAdapterService trialsAdapterService;;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }
    
    /**
     * test method to test createMotion
     */
    @Test
    public void testCreateMotion() {
        final MotionDetails motionDetails=new MotionDetails();
        Mockito.when(trialsAdapterService.createMotion(Mockito.any())).thenReturn(motionDetails);
        trialsAdapterController.createMotion(motionDetails);
        Mockito.verify(trialsAdapterService, Mockito.atMost(1)).createMotion(Mockito.any());
    }
    
    /**
     * test method to test createRehearing
     */
    @Test
    public void testCreateRehearing() {
        final RehearingInfo rehearingInfo=new RehearingInfo();
        Mockito.when(trialsAdapterService.createRehearing(Mockito.any())).thenReturn(rehearingInfo);
        trialsAdapterController.createRehearing(rehearingInfo);
        Mockito.verify(trialsAdapterService, Mockito.atMost(1)).createMotion(Mockito.any());
    }
    
    /**
     * test method to test DeleteRehearing
     */
    @Test
    public void testDeleteRehearing() {
        Mockito.doNothing().when(trialsAdapterService).deleteRehearing(Mockito.any());
        trialsAdapterController.deleteRehearing(154L);
        Mockito.verify(trialsAdapterService, Mockito.atMost(1)).deleteRehearing(Mockito.any());
    }
    
    /**
     * test method to test updatePartyRehearing
     */
    @Test
    public void testUpdatePartyRehearing() {
        final RehearingInfo rehearingInfo=new RehearingInfo();
        Mockito.when(trialsAdapterService.updatePartyRehearing(Mockito.any(),Mockito.any())).thenReturn(rehearingInfo);
        trialsAdapterController.updatePartyRehearing(rehearingInfo,154L);
        Mockito.verify(trialsAdapterService, Mockito.atMost(1)).updatePartyRehearing(Mockito.any(),Mockito.any());
    }
    
    /**
     * test method to test deleteMotion
     */
    @Test
    public void testDeleteMotion() {
        Mockito.doNothing().when(trialsAdapterService).deleteMotion(Mockito.any());
        trialsAdapterController.deleteMotion(154L);
        Mockito.verify(trialsAdapterService, Mockito.atMost(1)).deleteMotion(Mockito.any());
    }
    
    /**
     * test method to test updatePartyMotion
     */
    @Test
    public void testUpdatePartyMotion() {
        final MotionDetails motionDetails=new MotionDetails();
        Mockito.when(trialsAdapterService.updatePartyMotion(Mockito.any(),Mockito.any())).thenReturn(motionDetails);
        trialsAdapterController.updatePartyMotion(motionDetails,154L);
        Mockito.verify(trialsAdapterService, Mockito.atMost(1)).updatePartyMotion(Mockito.any(),Mockito.any());
    }
    
    /**
     * test method to test submitProceeding
     */
    @Test
    public void testSubmitProceeding() {
        final Petition petition=new Petition();
        Mockito.doNothing().when(trialsAdapterService).submitProceeding(Mockito.any());
        trialsAdapterController.submitProceeding(petition);
        Mockito.verify(trialsAdapterService, Mockito.atMost(1)).submitProceeding(Mockito.any());
    }
    
}
