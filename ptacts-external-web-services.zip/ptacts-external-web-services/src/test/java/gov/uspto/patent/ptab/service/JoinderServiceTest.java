package gov.uspto.patent.ptab.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.RelatedProceeding;
import gov.uspto.patent.ptab.repository.ProceedingRepository;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;

@RunWith(MockitoJUnitRunner.class)
public class JoinderServiceTest {

    private static final String CASE_NUMBER = "IPR2019-01526";

    @InjectMocks
    private JoinderService joinderService;

    @Mock
    private CodeReferenceDao codeReferenceDao;

    @Mock
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Mock
    private ProceedingRepository proceedingRepository;

    @Mock
    private PTABBusinessUtils ptabBusinessUtils;

    @Mock
    private RestServiceClient restServiceClient;

    @Mock
    List<RelatedProceeding> relatedProceedings;

    @Mock
    RelatedProceeding relatedProceeding;

    @Before
    public void SetUp() {
        relatedProceedings = new ArrayList<>();
        relatedProceeding = new RelatedProceeding();
        relatedProceeding.setRelatedProceedingNo("123");
        relatedProceeding.setProceedingNo(CASE_NUMBER);
        relatedProceeding.setDescriptionText("test");
        relatedProceedings.add(relatedProceeding);
    }

    /**
     * test method for getRelatedCasesByCaseNumber
     * 
     * @throws Exception
     */
    @Test
    public void testGetRelatedCasesByCaseNumber() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("joinderurl");
        List<RelatedProceeding> proceedingList = new ArrayList<>();
        RelatedProceeding proceeding = new RelatedProceeding();
        proceeding.setProceedingNo(CASE_NUMBER);
        proceedingList.add(proceeding);

        when(externalServiceUriGenerator.getJoinderCaseUrl(any(), anyString())).thenReturn("url");
        when(ptabBusinessUtils.getLoggedInUserId()).thenReturn("userName");
        String json = extracted();
        when(restServiceClient.callPTABExternalServiceURL(any(), any(), any(), any(), anyString()))
                .thenReturn(new ResponseEntity<>(json, HttpStatus.CREATED));

        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
        final List<RelatedProceeding> response = joinderService.getRelatedCasesByCaseNumber(CASE_NUMBER);
        assertEquals(CASE_NUMBER, response.get(0).getProceedingNo());
    }

    @Test(expected = PTABException.class)
    public void testGetRelatedCasesByCaseNumber401Exception() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("joinderurl");
        List<RelatedProceeding> proceedingList = new ArrayList<>();
        RelatedProceeding proceeding = new RelatedProceeding();
        proceeding.setProceedingNo(CASE_NUMBER);
        proceedingList.add(proceeding);

        when(externalServiceUriGenerator.getJoinderCaseUrl(any(), anyString())).thenReturn("url");
        when(ptabBusinessUtils.getLoggedInUserId()).thenReturn("userName");
        String json = extracted();
        when(restServiceClient.callPTABExternalServiceURL(any(), any(), any(), any(), anyString()))
                .thenReturn(new ResponseEntity<>(json, HttpStatus.UNAUTHORIZED));

        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
        joinderService.getRelatedCasesByCaseNumber(CASE_NUMBER);
    }

    @Test(expected = PTABException.class)
    public void testGetRelatedCasesByCaseNumber500Exception() {
        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("joinderurl");
        List<RelatedProceeding> proceedingList = new ArrayList<>();
        RelatedProceeding proceeding = new RelatedProceeding();
        proceeding.setProceedingNo(CASE_NUMBER);
        proceedingList.add(proceeding);

        when(externalServiceUriGenerator.getJoinderCaseUrl(any(), anyString())).thenReturn("url");
        when(ptabBusinessUtils.getLoggedInUserId()).thenReturn("userName");
        String json = extracted();
        when(restServiceClient.callPTABExternalServiceURL(any(), any(), any(), any(), anyString()))
                .thenReturn(new ResponseEntity<>(json, HttpStatus.INTERNAL_SERVER_ERROR));

        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
        joinderService.getRelatedCasesByCaseNumber(CASE_NUMBER);
    }

    private String extracted() {
        final ObjectMapper mapper = new ObjectMapper();
        String json = null;
        try {
            json = mapper.writeValueAsString(relatedProceedings);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return json;
    }

    /**
     * test method for getJoinderInformation
     * 
     * @throws JsonProcessingException
     */
    @SuppressWarnings("unchecked")
    @Test
    public void testGetJoinderInformation() throws Exception {

        when(codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString())).thenReturn("joinderurl");
        List<RelatedProceeding> proceedingList = new ArrayList<>();
        RelatedProceeding proceeding = new RelatedProceeding();
        proceeding.setProceedingNo(CASE_NUMBER);
        proceedingList.add(proceeding);

        when(externalServiceUriGenerator.getJoinderCaseUrl(any(), anyString())).thenReturn("url");
        when(ptabBusinessUtils.getLoggedInUserId()).thenReturn("userName");

        final ObjectMapper mapper = new ObjectMapper();
        final String json = mapper.writeValueAsString(relatedProceedings);

        when(restServiceClient.callPTABExternalServiceURL(any(), any(), any(), any(), anyString()))
                .thenReturn(new ResponseEntity<>(json, HttpStatus.CREATED));

        Mockito.verify(codeReferenceDao, Mockito.atMost(1)).getFirstDescCodeRefByTypeCdAndValue(anyString(), anyString());
        final List<RelatedProceeding> response = joinderService.getJoinderInformation(CASE_NUMBER);
        assertEquals(CASE_NUMBER, response.get(0).getProceedingNo());

    }

}
