package gov.uspto.patent.ptab.utils;

import org.junit.Test;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class InputValidationsUtilTest {

    @Test
    public void checkNullForObjectTest() {
        final String returnStr = (String) InputValidationsUtil.checkNullForObject("abc");
        assertSame("abc", returnStr);
    }

    @Test
    public void checkNullAndTrimTest() {
        final String returnStr = InputValidationsUtil.checkNullAndTrim("abc");
        assertSame("abc", returnStr);
    }

    @Test
    public void splitStringAsIntListWithoutExitingOnErrTest() {
        final List<Integer> returnStr = InputValidationsUtil.splitStringAsIntListWithoutExitingOnErr("12~34", "~");
        assertSame(2, returnStr.size());
    }

    @Test
    public void splitStringAsIntListWithoutExitingOnErrInvlidTest() {
        final List<Integer> returnStr = InputValidationsUtil.splitStringAsIntListWithoutExitingOnErr("12|34", "~");
        assertNull(returnStr);
    }

    @Test
    public void checkNullAndFetchIntegerTest() {
        final Integer returnStr = InputValidationsUtil.checkNullAndFetchInteger("123");
        assertSame(123, returnStr);
    }

    @Test
    public void checkNullAndFetchBigDecimalTest() {
        final Object[] inputBig = new Object[10];
        inputBig[0] = BigDecimal.valueOf(10);
        inputBig[1] = BigDecimal.valueOf(20);
        inputBig[2] = BigDecimal.valueOf(30);

        final BigDecimal returnStr = InputValidationsUtil.checkNullAndFetchBigDecimal(inputBig, 2);
        assertSame(30, returnStr.intValue());
    }

    @Test
    public void checkDateNullAndConvertTest() {
        final Date returnStr = InputValidationsUtil.checkDateNullAndConvert("01/01/2020", "mm/DD/yyyy");
        assertNotNull(returnStr);
    }

}
