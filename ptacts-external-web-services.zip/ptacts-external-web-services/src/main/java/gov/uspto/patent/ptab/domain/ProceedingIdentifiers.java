package gov.uspto.patent.ptab.domain;

import lombok.Data;

@Data
public class ProceedingIdentifiers {

    private String caseNo;

    private String caseType;

    private String proceedingSupplementaryId;

    private boolean includeInactive;
}
