package gov.uspto.patent.ptab.repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import gov.uspto.patent.ptab.domain.ApplicationUserQuery;
import gov.uspto.patent.ptab.entities.ApplicationUserEntity;

@Repository
public class ApplicationUserRepositoryCriteria {

    @Autowired
    private EntityManager entityManager;

    public List<ApplicationUserEntity> getUserInfo(ApplicationUserQuery applicationUserQuery) {
        final CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        final CriteriaQuery<ApplicationUserEntity> query = builder.createQuery(ApplicationUserEntity.class);
        final Root<ApplicationUserEntity> applicationUserEntity = query.from(ApplicationUserEntity.class);
        final List<Predicate> predicates = new ArrayList<>();

        if (null != applicationUserQuery.getLoginId()) {
            predicates.add(builder.equal(applicationUserEntity.get("userId"), applicationUserQuery.getLoginId()));
        }
        if (null != applicationUserQuery.getUserIdentiifier()) {

            predicates.add(builder.equal(applicationUserEntity.get("applicationUserId"),
                    new BigDecimal(applicationUserQuery.getUserIdentiifier())));
        }
        if (null != applicationUserQuery.getUserWorkerNumber()) {

            predicates.add(
                    builder.equal(applicationUserEntity.get("cfkEmployeeId"), applicationUserQuery.getUserWorkerNumber()));

        }

        if (null != applicationUserQuery.getFirstName()) {

            predicates.add(builder.like(builder.lower(applicationUserEntity.<String> get("firstNm")),
                    "%" + applicationUserQuery.getFirstName().toLowerCase() + "%"));
        }
        if (null != applicationUserQuery.getLastName()) {

            predicates.add(builder.like(builder.lower(applicationUserEntity.<String> get("lastNm")),
                    "%" + applicationUserQuery.getLastName().toLowerCase() + "%"));
        }
        final TypedQuery<ApplicationUserEntity> typedQuery = entityManager
                .createQuery(query.select(applicationUserEntity).where(predicates.toArray(new Predicate[] {})));

        return typedQuery.getResultList();
    }

}
