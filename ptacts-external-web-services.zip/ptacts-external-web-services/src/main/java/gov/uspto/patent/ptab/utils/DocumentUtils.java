package gov.uspto.patent.ptab.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import jakarta.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.tika.config.TikaConfig;
import org.apache.tika.exception.EncryptedDocumentException;
import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;

import org.apache.tika.parser.Parser;
import org.apache.tika.sax.BodyContentHandler;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;



@Component
@Slf4j
public class DocumentUtils {

	private TikaConfig tikaConfig;

	private ParseContext defaultParseContext;

	private AutoDetectParser defaultParser;

	@PostConstruct
	public void init() throws Exception {

		tikaConfig = new TikaConfig();

		initializeDefaultParser();

	}

	public boolean checkforPassWordEncrypter(InputStream stream)  {
		boolean parsable = true;
		ByteArrayOutputStream outStream = new ByteArrayOutputStream(1);
		BodyContentHandler handler = new BodyContentHandler(outStream);
		Metadata metadata = new Metadata();
		// otherwise, run default documents parser
		try {
			defaultParser.parse(stream, handler, metadata, defaultParseContext);
		
			if (StringUtils.equalsIgnoreCase(metadata.get("pdf:encrypted"),"true"))
				
			{
				log.info("*********************Procted File********************");
				parsable = false;
			}
		} catch (EncryptedDocumentException e) {
			
			parsable = false;
		} catch (IOException e) {
			parsable = false;
		} catch (TikaException e) {
			parsable = false;
		}
		catch (Exception e) {
			parsable = false;
		}

		return parsable;
	}

	private void initializeDefaultParser() {
		defaultParser = new AutoDetectParser(tikaConfig);

		defaultParseContext = new ParseContext();
		defaultParseContext.set(TikaConfig.class, tikaConfig);
		// defaultParseContext.set(TesseractOCRConfig.class, tessConfig);
		defaultParseContext.set(AutoDetectParser.class, defaultParser);
		defaultParseContext.set(Parser.class, defaultParser); // need to add this to make sure recursive parsing
																// happens!
	}

}
