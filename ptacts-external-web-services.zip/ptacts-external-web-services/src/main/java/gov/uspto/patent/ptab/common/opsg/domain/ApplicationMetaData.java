package gov.uspto.patent.ptab.common.opsg.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Description of ApplicationMetaData.
 *
 * @author 2020 Development Team
 */
@Data
@JsonInclude(Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
public class ApplicationMetaData extends PatentCaseCommonDomain {

    private Long filingDate;

    private String customerNumberText;

    private Long grantDate;

    private String currentApplClass;

    private String subclass;

    private String groupArtUnitNumber;

    private String firstInventorToFileIndicator;

    private Long effectiveFilingDate;

    private Long applicationWithdrawnDate;

    private String applicationFileReference;

    private String applicationConfirmationNumber;

    private String inventionTitle;

    private String partyIdentifier;

    private String unmatchedPetitionIndicator;

    private String secrecyCode;

    private Long applicationStatusDate;

    private String physicalObjectStatusCode;

    private Boolean isPublic = Boolean.FALSE;

    private String applicationTypeCategory;

    private String inventionSubjectMatterCategory;

    private String patentNumber;

    private String statusNumber;

    private String nationalStageIndicator;

    private String applicationStatusDescriptionText;

    private String errorMessage;

    private String specialExaminationIndicator;

    private String firstActionOnMeritIndicator;

    private Long abandonedDate;

    private String disposalIndicator;

    private String applicationFileCategory;

}
