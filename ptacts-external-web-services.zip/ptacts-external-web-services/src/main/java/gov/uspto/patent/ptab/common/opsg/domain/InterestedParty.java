package gov.uspto.patent.ptab.common.opsg.domain;

import java.math.BigDecimal;

//import jakarta.validation.constraints.Digits;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.validation.constraints.Digits;
import lombok.Data;

/**
 * Description of InterestedParty PCDM.
 *
 * @author 2020 Development Team
 */
@Data
@JsonInclude(Include.NON_NULL)
public class InterestedParty {

    private String status;

    private String referenceType;

    @Digits(fraction = 0, message = "The named order contains non-numeric characters", integer = 4)
    private BigDecimal sequenceNumber;

    private BigDecimal newSequenceNumber;

    private String authorityType;

    private String partyIdentifier;

    private String interestedPartyType;

    private String pctRoleType;

    private String deceasedIndicator;

    private String allStatesIndicator;

    private String usOnlyIndicator;

    private String indicatedStatesIndicator;

    private String allStatesUsExcludedIndicator;

    private String legalCapcity;

    private String actingForName;

    private String primaryAppInventorIndicator;

    private String signatureVerifiedIndicator;

    private String applAddressMatchIndicator;

    private Integer pctItemNo;

    private String signatureLocation;

    private String nationalityCode;

    private String nationalityName;

    private String residenceCountryCode;

    private String residenceCountryName;

}
