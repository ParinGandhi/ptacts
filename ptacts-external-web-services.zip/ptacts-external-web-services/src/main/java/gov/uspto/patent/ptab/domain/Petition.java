package gov.uspto.patent.ptab.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.google.common.collect.Multimap;

import gov.uspto.patent.ptab.entities.ProceedingEntity;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class Petition extends PtabCommonDomain {

    private List<PetitionDocument> petitionDocuments;
    private List<PartyRequestType> partyRequestTypes;
    private String joinderOrginalIndicator;
    private String parentCaseNumber;

    @JsonIgnore
    private List<String> decsionDocumentList;

    @JsonIgnore
    private ProceedingEntity proceeding;

    @JsonIgnore
    private Multimap<String, List<PetitionDocument>> joinderDocumentMap;

    @JsonIgnore
    private Multimap<String, Descision> notificationMotionMap;

    @JsonIgnore
    private Multimap<String, Descision> notificationRehearingMap;

    private Descision rehearing;

    private Descision motion;

    @JsonIgnore
    private String rehearingEvent;

    @JsonIgnore
    private String motionEvent;

    @JsonIgnore
    private String documentUploadEvent;

    @JsonIgnore
    private String userName;

    @JsonIgnore
    private List<EAIHubDocument> eaiHubDocumentList = new ArrayList<>();

    @JsonIgnore
    private String eaiHubUploadUrl;

    @JsonIgnore
    private String usptoDocUploadUrl;

    @JsonIgnore
    private String docUploadSourceType;

    @JsonIgnore
    private Long petitionId;

    @JsonIgnore
    private String notificationEndPoint;

    @JsonIgnore
    private String mountLocation;

    @JsonIgnore
    private String textExtractionUrl;

    @JsonIgnore
    private BigDecimal userIdentifier;

    @JsonIgnore
    private String petitionSubmissionIndicator;

    private String alfrescoDocSubmitUrl;

    private List<String> trialCheckListCaseNumberList;

    private String otherDocumentLoad;

    private String internalUserSubmitter;
}
