package gov.uspto.patent.ptab.controller;

import java.util.List;

import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.domain.DocumentTypeQuery;
import gov.uspto.patent.ptab.domain.ReferenceDataResponse;
import gov.uspto.patent.ptab.domain.ReferenceQuery;
import gov.uspto.patent.ptab.domain.ReferenceType;
import gov.uspto.patent.ptab.service.ReferenceDataService;

/**
 * This class is used to retrieve the reference data
 *
 * @author 2020 development team
 *
 */
@RestController
@RequestMapping("/references")
public class ReferenceDataController {

    @Autowired
    private ReferenceDataService referenceDataService;

    /**
     * Gets reference type base on its type.
     *
     * @param referenceQuery
     * @return
     */
    @GetMapping
    public List<ReferenceType> getReferenceType(@NotNull final ReferenceQuery referenceQuery) {
        return referenceDataService.getReferenceData(referenceQuery);
    }

    /**
     * Gets reference type base on its type.
     *
     * @param referenceType
     * @return
     */
    @GetMapping(path = "/proceeding-number", produces = "application/json")
    public ReferenceDataResponse getReferenceDataWithProceedingNumber(@NotNull final ReferenceQuery referenceQuery) {
        return referenceDataService.getReferenceDataWithProceedingNumber(referenceQuery);
    }

    /**
     * Gets document type base on motion name.
     *
     * @param referenceType
     * @return
     */
    @GetMapping(path = "/documentTypes", produces = "application/json")
    public JsonNode getDocumentDetails(DocumentTypeQuery documentTypeQuery) {
        return referenceDataService.getDocumentInfo(documentTypeQuery);
    }
    /**
     * Gets document type for Director review
     *
     * @param referenceType
     * @return
     */
    @GetMapping(path = "/documentTypes/director-review", produces = "application/json")
    public List<ReferenceType> getDocumentDetailsForDirectorReview(ReferenceQuery referenceQuery) {
        return referenceDataService.getDocumentDetailsForDirectorReview(referenceQuery);
    }


}
