package gov.uspto.patent.ptab.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Descision {

    private String type;
    private String description;
    private String status;
    private String submittedDate;
    private String filingParty;
    private String lastUpdatedDate;
}
