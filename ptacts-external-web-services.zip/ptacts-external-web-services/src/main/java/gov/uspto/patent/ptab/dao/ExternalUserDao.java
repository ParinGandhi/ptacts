package gov.uspto.patent.ptab.dao;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.extern.slf4j.Slf4j;

/**
 * DAO Implementation for ExternalUser
 *
 * @author 2020 development team
 *
 */
@Repository
@Slf4j
public class ExternalUserDao {

    private static final String USER_ID = "userId";
    private static final String PROCEEDING_NUM = "proceedingNum";

    @Autowired
    private SessionFactory sessionFactory;

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * This method is used to validate user id
     *
     * @param userId - unique userId to be validated
     * @return
     */
    @Transactional(readOnly = true)
    public String getUserPrcdPartyGroupType(final String userId, final String proceedingNum) {
        log.info("Dao call for getUserPrcdPartyGroupType method");
        final Query<?> query = sessionFactory.getCurrentSession().createNamedQuery("getUserPrcdPartyGroupTypeOne",
                Object[].class);
        query.setParameter(USER_ID, userId);
        query.setParameter(PROCEEDING_NUM, proceedingNum);
        final String uniqueResult = (String) query.uniqueResult();
        return StringUtils.isEmpty(uniqueResult) ? "" : uniqueResult;
    }

    /**
     * This method is used to validate user id
     *
     * @param userId - unique userId to be validated
     * @return
     */
    @Transactional(readOnly = true)
    public String getUserPrcdPartyGroupTypeForStaff(final String userId, final String proceedingNum) {
        log.info("Dao call for getUserPrcdPartyGroupType method");
        final Query<?> query = sessionFactory.getCurrentSession().createNamedQuery("getUserPrcdPartyGroupTypeForStaff",
                Object.class);
        query.setParameter(USER_ID, userId);
        query.setParameter(PROCEEDING_NUM, proceedingNum);
        final String uniqueResult = (String) query.uniqueResult();
        return StringUtils.isEmpty(uniqueResult) ? "" : uniqueResult;
    }
}