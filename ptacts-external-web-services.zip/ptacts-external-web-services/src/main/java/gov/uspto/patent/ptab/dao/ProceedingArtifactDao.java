package gov.uspto.patent.ptab.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import gov.uspto.patent.ptab.entities.ProceedingArtifact;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

@Component
public class ProceedingArtifactDao {

    private static final String FROM_PROCEEDING_ARTIFACT = "FROM ProceedingArtifact a WHERE "
            + "a.artifactSubmission.fkProceedingId = :id ";

    private static final String FROM_PROCEEDING_ARTIFACT_WITH_ARTIFACT_SUBMISSION = "from ProceedingArtifact pa where "
            + "pa.artifactSubmission.artifactSubmissionId ";
    private static final String ARTIFACTS_REHEARING_ASSOCIATION = "in (select "
            + "ras.artifactSubmission.artifactSubmissionId from RehearingArtfctSubmn ras "
            + "where ras.rehearing.rehearingId = :id) ";
    private static final String ORDER_FILE_TS_ASC = " ORDER BY pa.createTs ASC";
    private static final String PRCDNG_PARTY = " and a.proceedingParty is null ";
    private static final String SEPARATE_INITIATED_ARTIFACTS = "and a.artifactSubmission.artifactSubmissionId NOT IN "
            + " (select ras.artifactSubmission.artifactSubmissionId from RehearingArtfctSubmn ras "
            + "where ras.rehearing.stndRehearingStatus.rehearingStatusId = 5) "
            + " and a.artifactSubmission.artifactSubmissionId NOT IN ("
            + "select mas.artifactSubmission.artifactSubmissionId from MotionArtfctSubmn mas "
            + "where mas.motion.stndMotionStatus.motionStatusId = 5) "
            + " and a.artifactSubmission.artifactSubmissionId NOT IN ("
            + "select pas.artifactSubmission.artifactSubmissionId from PrcdngAplArtfctSubmn pas "
            + "where pas.proceedingAppeal.stndAppealStatus.appealStatusId = 5)";
    private static final String ORDER_BY = " order by a.proceedingArtifactId asc";
    private static final String UNFILTERED_DOCUMENTS_SECOND = FROM_PROCEEDING_ARTIFACT
            + " and (a.proceedingParty.proceedingPartyGroup.stndPrcdngPartyGroupStat.prcdngPartyGroupStatId in (1,6) "
            + "or a.proceedingParty.proceedingPartyGroup.statusApprovedIndicator='Y') " + SEPARATE_INITIATED_ARTIFACTS
            + ORDER_BY;

    private static final String GET_ALL_PROCEEDING_ARTIFACTS_FOR_PARTY_GROUP_AS_INTERNAL_USER = FROM_PROCEEDING_ARTIFACT
            + " and a.proceedingParty.proceedingPartyGroup.proceedingPartyGroupId = :partyGroupId order by a.createTs asc";
    private static final String SELECT_PROCEEDING_ARTIFACT = "from ProceedingArtifact pa  "
            + "where pa.artifactSubmission.artifactSubmissionId ";
    private static final String ARTIFACTS_MOTION_ASSOCIATION = "in (select mas.artifactSubmission.artifactSubmissionId "
            + "from MotionArtfctSubmn mas where mas.motion.motionId = :motionId) ";
    private static final String SELECT_MOTIONS_FORM_PROCEEDINGARTIFACT = SELECT_PROCEEDING_ARTIFACT
            + ARTIFACTS_MOTION_ASSOCIATION;

    private static final String ARTIFACTS_APPEAL_ASSOCIATION = "in (select pas.artifactSubmission.artifactSubmissionId "
            + "from PrcdngAplArtfctSubmn pas where pas.proceedingAppeal.proceedingAppealId = :prcdAppealId) ";
    private static final String SELECT_APPEALS_FORM_PROCEEDINGARTIFACT = SELECT_PROCEEDING_ARTIFACT
            + ARTIFACTS_APPEAL_ASSOCIATION;

    private static final String MOTION_ID = "motionId";
    private static final String PRCD_APPEAL_ID = "prcdAppealId";

    @PersistenceContext
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")
    public List<ProceedingArtifact> getAllProceedingArtifacts(final Long proceedingId) {
        Query query = entityManager.createQuery(FROM_PROCEEDING_ARTIFACT + PRCDNG_PARTY + SEPARATE_INITIATED_ARTIFACTS
                + "order by a.proceedingArtifactId asc");
        query.setParameter("id", proceedingId);
        final List<ProceedingArtifact> docsList = query.getResultList();
        query = this.entityManager.createQuery(UNFILTERED_DOCUMENTS_SECOND);
        query.setParameter("id", proceedingId);
        docsList.addAll(query.getResultList());
        return docsList;

    }

    @SuppressWarnings("unchecked")
    public List<ProceedingArtifact> getAllProceedingArtifactsForMandatoryNotice(final Long proceedingId,
            final Long groupId) {
        final Query query = entityManager.createQuery(GET_ALL_PROCEEDING_ARTIFACTS_FOR_PARTY_GROUP_AS_INTERNAL_USER);
        query.setParameter("id", proceedingId);
        query.setParameter("partyGroupId", groupId);
        return query.getResultList();

    }

    @SuppressWarnings("unchecked")
    public List<ProceedingArtifact> getAllProceedingArtifactsForMotions(final Long motionId) {
        final Query query = this.entityManager.createQuery(SELECT_MOTIONS_FORM_PROCEEDINGARTIFACT);
        query.setParameter(MOTION_ID, motionId);
        return query.getResultList();

    }

    @SuppressWarnings("unchecked")
    public List<ProceedingArtifact> getAllProceedingArtifactsForAppeals(final Long prcdAppealId) {
        final Query query = this.entityManager.createQuery(SELECT_APPEALS_FORM_PROCEEDINGARTIFACT);
        query.setParameter(PRCD_APPEAL_ID, prcdAppealId);
        return query.getResultList();

    }

    @SuppressWarnings("unchecked")
    public List<ProceedingArtifact> getAllProceedingArtifactsForRehearing(final Long rehearingId) {
        final jakarta.persistence.Query query = entityManager.createQuery(
                FROM_PROCEEDING_ARTIFACT_WITH_ARTIFACT_SUBMISSION + ARTIFACTS_REHEARING_ASSOCIATION + ORDER_FILE_TS_ASC);
        query.setParameter("id", rehearingId);
        return query.getResultList();
    }
}
