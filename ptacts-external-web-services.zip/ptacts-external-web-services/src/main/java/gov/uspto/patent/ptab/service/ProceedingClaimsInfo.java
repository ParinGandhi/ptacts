package gov.uspto.patent.ptab.service;

import gov.uspto.patent.ptab.domain.ProceedingClaims;
import gov.uspto.patent.ptab.domain.ProceedingIdentifiers;

/**
 * Interface used for service implementations for Proceeding Claims services
 * 
 * @author 2020 development team
 *
 */
public interface ProceedingClaimsInfo {
    /**
     * This is an interface method to get the proceeding claims
     * 
     * @param searchIdentifiers
     * @return
     */
    ProceedingClaims getProceedingClaims(ProceedingIdentifiers searchIdentifiers);

    /**
     * This is an interface method to create the proceeding claims
     * 
     * @param proceedingClaims
     */
    void createProceedingClaim(ProceedingClaims proceedingClaims);

    /**
     * This is an interface method to update the proceeding claims
     * 
     * @param proceedingClaims
     */
    void updateProceedingClaim(ProceedingClaims proceedingClaims);

    /**
     * This is an interface method to delete the proceeding claims
     * 
     * @param proceedingClaims
     */
    void deleteProceedingClaim(final Long identifier);
}
