package gov.uspto.patent.ptab.domain;

import java.util.Date;
import java.util.List;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.uspto.patent.ptab.utils.MilliSecEpochDeserializer;
import gov.uspto.patent.ptab.utils.MilliSecEpochSeralizer;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = false)
public class ProceedingAppealInfo extends PtabCommonDomain {

    private Long proceedingAppealId;
    private String proceedingNumber;

    private String appealPartyTypeCode;
    private String appealPartyTypeDescription;

    @JsonSerialize(using = MilliSecEpochSeralizer.class)
    @JsonDeserialize(using = MilliSecEpochDeserializer.class)
    private Date appealNoticeDate;

    @JsonSerialize(using = MilliSecEpochSeralizer.class)
    @JsonDeserialize(using = MilliSecEpochDeserializer.class)
    private Date courtDecisionDate;

    private String appealStatusCode;
    private String appealStatusDescription;

    private String appealTypeName;
    private String appealTypeDescription;

    private String externalCourtName;
    private String externalCourtDescription;

    private String commentText;

    private List<PetitionDocument> appealDocuments;

    @JsonSerialize(using = MilliSecEpochSeralizer.class)
    @JsonDeserialize(using = MilliSecEpochDeserializer.class)
    private Date courtMandateDate;

    @JsonIgnore
    private boolean isCourtDecisionDateUpdated;

    @JsonIgnore
    private boolean isCourtMandateDateUpdated;

    @JsonIgnore
    private Petition petition;
}
