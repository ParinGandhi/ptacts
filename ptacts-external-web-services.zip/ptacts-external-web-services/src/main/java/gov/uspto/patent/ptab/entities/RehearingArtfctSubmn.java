package gov.uspto.patent.ptab.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "REHEARING_ARTFCT_SUBMN")
@NamedQuery(name = "RehearingArtfctSubmn.findAll", query = "SELECT m FROM RehearingArtfctSubmn m")
public class RehearingArtfctSubmn extends AbstractAuditEntity {

    private static final long serialVersionUID = -6826705080507989386L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "REHEARING_ARTFCT_SUBMN_SEQ")
    @SequenceGenerator(name = "REHEARING_ARTFCT_SUBMN_SEQ", sequenceName = "REHEARING_ARTFCT_SUBMN_SEQ", allocationSize = 1)
    @Column(name = "REHEARING_ARTFCT_SUBMN_ID")
    private long rehearingArtfctSubmnId;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    @ManyToOne
    @JoinColumn(name = "FK_ARTIFACT_SUBMISSION_ID")
    private ArtifactSubmission artifactSubmission;

    @ManyToOne
    @JoinColumn(name = "FK_REHEARING_ID")
    private Rehearing rehearing;

}
