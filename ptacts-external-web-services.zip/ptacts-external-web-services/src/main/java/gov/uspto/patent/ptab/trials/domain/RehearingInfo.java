package gov.uspto.patent.ptab.trials.domain;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.uspto.patent.ptab.domain.Petition;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.domain.PtabCommonDomain;
import gov.uspto.patent.ptab.utils.MilliSecEpochDeserializer;
import gov.uspto.patent.ptab.utils.MilliSecEpochSeralizer;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RehearingInfo extends PtabCommonDomain {
    private Long rehearingId;
    private String proceedingNumber;
    private String rehearingTypeName;
    @JsonSerialize(using = MilliSecEpochSeralizer.class)
    @JsonDeserialize(using = MilliSecEpochDeserializer.class)
    private Date filedDate;
    @JsonSerialize(using = MilliSecEpochSeralizer.class)
    @JsonDeserialize(using = MilliSecEpochDeserializer.class)
    private Date decisionDate;
    private Long rehearingTypeId;
    private String requestorTypeName;
    private Long rehearingStatusId;
    private String rehearingStatus;
    private String rehearingStatusDisplayName;
    private List<PetitionDocument> rehearingDocuments;
    private String notificationRequiredIndicator;

    @JsonIgnore
    private Petition petition;

}