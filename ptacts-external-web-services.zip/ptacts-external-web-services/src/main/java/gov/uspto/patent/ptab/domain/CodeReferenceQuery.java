package gov.uspto.patent.ptab.domain;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This class is for query information for endpoint /reference-data/code-reference-types
 *
 * @author 2020 development team
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CodeReferenceQuery {
    private String valueText;

    private String descriptionText;

    private String typeCode;

}
