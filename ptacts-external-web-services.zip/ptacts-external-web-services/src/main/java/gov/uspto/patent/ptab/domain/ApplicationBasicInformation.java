package gov.uspto.patent.ptab.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import gov.uspto.patent.ptab.common.opsg.domain.ApplicationAddress;
import gov.uspto.patent.ptab.common.opsg.domain.Inventor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class ApplicationBasicInformation {

    private String applicationNumberText;

    private Long filingDate;

    private String customerNumberText;

    private Long grantDate;

    private String currentApplClass;

    private String subclass;

    private String groupArtUnitNumber;

    private Long applicationWithdrawnDate;

    private String applicationFileReference;

    private String applicationConfirmationNumber;

    private String inventionTitle;

    private String partyIdentifier;

    private Long applicationStatusDate;

    private String physicalObjectStatusCode;

    private String applicationTypeCategory;

    private String inventionSubjectMatterCategory;

    private String patentNumber;

    private String statusNumber;

    private String applicationStatusDescriptionText;

    private String applicationFileCategory;

    private Inventor inventor;

    private String techCenter;

    private String attorneyDocketNumber;

    private ApplicationAddress applicationAddress;

    private Integer totalClaims;

    private List<Assignee> assignees;

    private String patentOwnerName;

}
