package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the STND_MILESTONE_TYPE database table.
 * 
 */
@Entity
@Table(name = "STND_MILESTONE_TYPE")
@NamedQuery(name = "StndMilestoneType.findAll", query = "SELECT s FROM StndMilestoneType s")
@Getter
@Setter
@NoArgsConstructor
public class StndMilestoneType implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "MILESTONE_TYPE_ID")
    private long milestoneTypeId;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Column(name = "CREATE_TS")
    private Timestamp createTs;

    @Column(name = "CREATE_USER_ID")
    private BigDecimal createUserId;

    @Column(name = "DESCRIPTION_TX")
    private String descriptionTx;

    @Column(name = "DISPLAY_ORDER_SEQUENCE_NO")
    private BigDecimal displayOrderSequenceNo;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Column(name = "LAST_MOD_TS")
    private Timestamp lastModTs;

    @Column(name = "LAST_MOD_USER_ID")
    private BigDecimal lastModUserId;

    @Column(name = "MILESTONE_TYPE_NM")
    private String milestoneTypeNm;

    @Column(name = "FK_PRNT_MLSTN_TYPE_ID")
    private Long fkPrntMlstnTypeId;

    @Column(name = "FK_RECEIPENT_TYPE_ID")
    private Long fkReceipentTypeId;

    @Column(name = "DATE_CALC_REF_ID")
    private Long dateCalcRefId;

    @Column(name = "DATE_CALC_REF_IDS")
    private String dateCalcRefIds;

    @Column(name = "FK_MLSTN_IDS_TO_CLR")
    private String fkMlstnIdsToClr;

    @OneToMany(mappedBy = "stndMilestoneType")
    private List<ProceedingMilestone> proceedingMilestones;

    @ManyToOne
    @JoinColumn(name = "FK_MILESTONE_GROUP_TYPE_ID")
    private StndMilestoneGroupType stndMilestoneGroupType;

    @ManyToOne
    @JoinColumn(name = "FK_RECEIPENT_TYPE_ID", insertable = false, updatable = false)
    private StndRecipientType stndRecipientType;

}
