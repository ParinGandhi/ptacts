package gov.uspto.patent.ptab.common.opsg.domain;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

/**
 * Description of ApplicationIdentifierQuery.
 *
 * @author 2020 Development Team
 */
@Getter
@Setter
public class ApplicationIdentifierQuery {

    @Schema(description = "An uniquely number identifies the Application Patent Case"
            + " among others that are either US domestic or international applications.")
    private String applicationNumber;
    @Schema(description = "An uniquely Number to identify the patent as published "
            + "in the Official Gazette. Patent number should be between 7 to 13 digits.")
    private String patentNumber;

}
