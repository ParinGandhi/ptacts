package gov.uspto.patent.ptab.common.opsg.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * This class models supplemental data of an application
 *
 * @author 2020 Development Team
 */
@Data
@JsonInclude(Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
public class ApplicationSupplementalData extends PatentCaseCommonDomain {

    private ApplicationClaimData applicationClaimData = new ApplicationClaimData();

}
