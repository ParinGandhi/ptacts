package gov.uspto.patent.ptab.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.domain.PaymentInformation;
import gov.uspto.patent.ptab.service.PaymentService;

@RestController
@RequestMapping(value = "/payments")
public class PaymentInfoController {

    @Autowired
    private PaymentService paymentService;

    @GetMapping
    public List<PaymentInformation> getPaymentDetails(final CaseDocumentsDataQuery caseDocumentsDataQuery) {
        return paymentService.getAllPaymentDetails(caseDocumentsDataQuery);
    }

}
