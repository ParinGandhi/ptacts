package gov.uspto.patent.ptab.domain;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.uspto.patent.ptab.utils.EpochDeserializer;
import gov.uspto.patent.ptab.utils.EpochSerializer;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * This class is to give the notification details
 *
 * @author 2020 Development Team
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
public class NotificationDetails {

    private String notificationId;

    private String caseNo;

    private String contentManagementId;

    @JsonSerialize(using = EpochSerializer.class)
    @JsonDeserialize(using = EpochDeserializer.class)
    private Date sendTimeStamp;

    private String subjectText;

    private List<String> tolist;

    private List<String> ccList;

    private List<String> bccList;

    private String notificationStatus;

    private String htmlDocumentData;

    private String initiatedBy;

    private Audit audit;

    private String fromEmail;

    private String targetType;

    private Long notificationGrpId;

    private String eventId;

    private String parentNotificationId;
}