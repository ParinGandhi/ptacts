package gov.uspto.patent.ptab.domain;

import lombok.Data;

/**
 * 
 * @author Skytech Development Team
 *
 */
@Data
public class FilingPartyDropDownList {
	
	String partyRepresenting;
	boolean prelim=true;
	boolean motions=true;
	boolean rehearing=true;
	boolean appeal=true;
	boolean other=true;
	boolean directorReview=false;

}
