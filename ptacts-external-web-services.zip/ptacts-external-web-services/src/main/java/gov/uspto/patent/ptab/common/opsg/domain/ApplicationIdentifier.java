package gov.uspto.patent.ptab.common.opsg.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

/**
 * Description of ApplicationIdentifier.
 *
 * @author 2020 Development Team
 */
@Data
@JsonInclude(Include.NON_NULL)
public class ApplicationIdentifier {

    private String applicationNumberText;

    private String patentNumber;

    private String publicationNumber;

    private String internationalRegistrationNumber;

    private String barCodeNumber;

    private String attorneyDocketNumber;

    private String workerNumber;

    private String customerNumber;

    private String appealNumber;

}
