package gov.uspto.patent.ptab.controller;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gov.uspto.patent.ptab.domain.ReviewInformation;
import gov.uspto.patent.ptab.service.ReviewInformationService;
import lombok.extern.slf4j.Slf4j;

/**
 * Controller class for payments
 *
 * @author 2020 development team
 *
 */
@Slf4j
@RestController
@RequestMapping("/reviewInfo")
public class ReviewInfoController {

    @Autowired
    private ReviewInformationService reviewInformationService;

    /**
     * Method used to get the review info
     *
     * @param postingReferenceText -posting reference text
     * @throws JsonProcessingException
     * @throws JsonMappingException
     *
     */
    @GetMapping(value = "", produces = { MediaType.APPLICATION_JSON_VALUE })
    public @ResponseBody List<ReviewInformation> getReviewInfo(@RequestParam @Valid @NotBlank String postingReferenceText)
            throws JsonProcessingException {

        log.info("GET all getReviewInfo:{}", postingReferenceText);
        return reviewInformationService.getReviewInformation(postingReferenceText);
    }

}
