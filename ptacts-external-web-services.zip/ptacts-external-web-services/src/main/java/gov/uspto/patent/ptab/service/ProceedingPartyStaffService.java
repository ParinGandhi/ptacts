package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;
import static org.springframework.http.HttpStatus.BAD_REQUEST;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.InterestedParty;
import gov.uspto.patent.ptab.domain.ProceedingParties;
import gov.uspto.patent.ptab.domain.ProceedingPartyQuery;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to get proceeding party details
 *
 * @author 2020 development team
 *
 */
@Component
@Slf4j
public class ProceedingPartyStaffService {

    private static final String PROCEEDING_PARTY_DETAILS_URL = "PROCEEDING_PARTY_DETAILS_URL";
    private static final String PARTY_REPRESENT_INDICATOR_QUERY_PARAM = "?partyRepresentIndicator=";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    private static final String PROCEEDING_PARTY_URL = "PROCEEDING_PARTY_URL";
    private static final String PROCEEDING_URL = "Proceeding Party details Url";

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Autowired
    private ExternalUserService externalUserService;

    @Autowired
    private PTABBusinessUtils ptabBusinessUtils;

    /**
     * Method used to save the proceeding party details
     *
     * @param proceedingParties - request object containing the proceeding party details
     * @param partyRepresentIndicator - party represent indicator
     */
    @Transactional
    public JsonNode savePartyStaffDetails(@Valid @NotNull final ProceedingParties proceedingParties,
            final String partyRepresentIndicator) {

        final String proceedingPartyDetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_PARTY_URL);
        notFoundIfNull(proceedingPartyDetailsUrl, PROCEEDING_URL);
        final String userName = ptabBusinessUtils.getLoggedInUserId();
        final List<InterestedParty> parties = proceedingParties.getParties();
        ptabBusinessUtils.validateAndSetStaffTypeDetails(proceedingParties, parties);
        final ObjectMapper mapper = new ObjectMapper();
        final JsonNode proceedingPartiesNode = mapper.convertValue(proceedingParties, JsonNode.class);
        JsonNode jsonNodeUpdated = null;
        try {
            final ResponseEntity<JsonNode> reponse = restServiceClient.callPTABExternalServiceURL(
                    proceedingPartyDetailsUrl + PARTY_REPRESENT_INDICATOR_QUERY_PARAM + partyRepresentIndicator,
                    proceedingPartiesNode, HttpMethod.POST, JsonNode.class, userName);
            if (null != reponse && reponse.getStatusCode().is2xxSuccessful()) {
                jsonNodeUpdated = reponse.getBody();
            }
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return jsonNodeUpdated;

    }

    /**
     * Method used to update the proceeding party details
     *
     * @param proceedingParties - request object containing the proceeding party details
     *
     */
    @Transactional
    public JsonNode updatePartyStaffDetails(@Valid @NotNull final ProceedingParties proceedingParties) {

        final String proceedingPartyDetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_PARTY_URL);
        notFoundIfNull(proceedingPartyDetailsUrl, PROCEEDING_URL);
        final String userName = ptabBusinessUtils.getLoggedInUserId();

        final List<InterestedParty> parties = proceedingParties.getParties();
        ptabBusinessUtils.validateExternalUserAndStaffDetailsForUpdate(proceedingParties, parties);
        final ObjectMapper mapper = new ObjectMapper();
        final JsonNode proceedingPartiesNode = mapper.convertValue(proceedingParties, JsonNode.class);
        JsonNode jsonNodeUpdated = null;
        try {
            final ResponseEntity<JsonNode> reponse = restServiceClient.callPTABExternalServiceURL(
                    proceedingPartyDetailsUrl, proceedingPartiesNode, HttpMethod.PUT, JsonNode.class, userName);
            if (null != reponse && reponse.getStatusCode().is2xxSuccessful()) {
                jsonNodeUpdated = reponse.getBody();
            }
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return jsonNodeUpdated;

    }

    /**
     * Method used to delete proceeding party details
     *
     * @param proceedingPartyQuery - object containing the query parameter information
     * @param userName - user name
     */
    @Transactional
    public void deleteStaffDetails(final ProceedingPartyQuery proceedingPartyQuery) {

        final String proceedingPartyDetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_PARTY_URL);
        notFoundIfNull(proceedingPartyDetailsUrl, PROCEEDING_URL);
        final String userName = ptabBusinessUtils.getLoggedInUserId();

        final String submitterType = externalUserService
                .getPrcdPartyGroupTypeForStaff(proceedingPartyQuery.getProceedingNumber());
        if (StringUtils.isBlank(submitterType)) {
            throw new PTABException(BAD_REQUEST,
                    new ErrorPayload("The user doesn't have permission delete staff details."));
        }
        final String url = externalServiceUriGenerator.getProceedingPartyDeleteUrl(proceedingPartyQuery,
                proceedingPartyDetailsUrl);
        try {
            restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.DELETE, Void.class, userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
    }

}