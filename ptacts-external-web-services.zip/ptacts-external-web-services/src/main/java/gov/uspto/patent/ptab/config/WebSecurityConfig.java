package gov.uspto.patent.ptab.config;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import gov.uspto.patent.ptab.dao.CommonCodeReferenceDao;


@Configuration
@EnableWebSecurity
@Order(1)
public class WebSecurityConfig  {

    private static final String OIDC_FILE_EXT_IGNORE = "OIDC_FILE_EXT_IGNORE";
    private static final String PTAB_UI_ROUTING = "PTAB_UI_ROUTING";

    @Autowired
    private CommonCodeReferenceDao codeReferenceDao;   

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests().requestMatchers("/**").permitAll().anyRequest().authenticated().and().oauth2ResourceServer().jwt();

        return http.build();      
    } 
    
    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
    	 List<String> antMatchersList = getAntMatchersFromDatabase();
    	// String[] antMatchersArray = antMatchersList.toArray(new String[antMatchersList.size()]);
    	 
		return (web) -> web.ignoring().requestMatchers(createAntMatchers(antMatchersList.toArray(new String[0])));
    	
    }

    private AntPathRequestMatcher[] createAntMatchers(String[] antMatchersArray) {
        return Arrays.stream(antMatchersArray)
                .map(AntPathRequestMatcher::new)
                .toArray(AntPathRequestMatcher[]::new);
    }

    private List<String> getAntMatchersFromDatabase() {
        final List<String> antMatchersList = Arrays.asList(StringUtils
                .split(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_UI_ROUTING, OIDC_FILE_EXT_IGNORE), "~"));

        return antMatchersList;
    }

    private JwtAuthenticationConverter jwtAuthenticationConverter() {
        JwtAuthenticationConverter converter = new JwtAuthenticationConverter() {
            protected Collection<GrantedAuthority> extractAuthorities(Jwt jwt) {
                return extractAuthorityFromClaims(jwt.getClaims());
            }
        };
        return converter;
    }

    private Collection<GrantedAuthority> extractAuthorityFromClaims(Map<String, Object> claims) {
        return Collections.emptyList(); // Return an empty list if not using custom authorities
    }
}

