package gov.uspto.patent.ptab.common.opsg.domain;

//import jakarta.validation.Valid;
//import jakarta.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Description of PatentCaseCommonDomain. Main business domain which is being used across all patent case domains .
 * Contains attributes to track life cycle of the domains.
 * 
 * @author 2020 Development Team
 */
@Data
@JsonInclude(Include.NON_NULL)
public class PatentCaseCommonDomain implements Auditable {

    @Valid
    @NotNull(message = "applicationIdentifier cannot be null")
    private ApplicationIdentifier applicationIdentifier;

    @Valid
    @NotNull(message = "audit cannot be null")
    private AuditData audit;

}
