package gov.uspto.patent.ptab.repository;

import gov.uspto.patent.ptab.entities.PrcdngClmStatyGround;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

/**
 *
 * This is the repository class for ProceedingClaim
 *
 * @author 2020 Development Team
 *
 */
@Repository
public interface PrcdngClmStatyGroundRepository extends JpaRepository<PrcdngClmStatyGround, BigDecimal> {

    /**
     * Fetch ProceedingClaim from DB using proceedingClaimId
     *
     * @return
     */
    @Query(value = "select proceedingClaimStatyGround from PrcdngClmStatyGround proceedingClaimStatyGround "
            + "where proceedingClaimStatyGround.fkProceedingClaimId=(?1)")
    public PrcdngClmStatyGround findOneByFkProceedingClaimId(Long fkProceedingClaimId);

    @Query(value = "select DISTINCT (prcdngClmStatyGround.fkProceedingClaimId) from PrcdngClmStatyGround prcdngClmStatyGround "
            + "where prcdngClmStatyGround.prcdngClmStatyGroundId in (?1)")
    List<Long> getAllProccedingClaims(final List<Long> statyGroundList);

    @Modifying
    @Query(value = "DELETE from PrcdngClmStatyGround prcdngClmStatyGround "
            + "where prcdngClmStatyGround.prcdngClmStatyGroundId in (?1)")
    void deleteStatyGroundsByIds(final List<Long> statyGroundIds);

    @Query(value = "select prcdngClmStatyGround from PrcdngClmStatyGround prcdngClmStatyGround "
            + "where prcdngClmStatyGround.prcdngClmStatyGroundId in (?1)")
    List<PrcdngClmStatyGround> getAllStatyGrounds(final List<Long> prcdngClmStatyGroundId);

}
