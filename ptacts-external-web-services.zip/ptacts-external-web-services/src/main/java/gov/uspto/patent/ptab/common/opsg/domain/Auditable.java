
package gov.uspto.patent.ptab.common.opsg.domain;

/**
 * Description of Auditable.
 * 
 * @author 2020 Development Team
 */
public interface Auditable {

    /**
     * Description of the method getAudit.
     * 
     * @return
     */
    public AuditData getAudit();

    /**
     * Description of the method setAudit.
     * 
     * @param auditIn
     */
    public void setAudit(AuditData auditIn);

}
