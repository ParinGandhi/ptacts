package gov.uspto.patent.ptab.trials.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import java.util.List;

//import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.Petition;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.trials.domain.MotionDetails;
import gov.uspto.patent.ptab.trials.domain.RehearingInfo;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

/**
 * This class is used for Trials Adapater Service
 *
 * @author 2020 development team
 *
 */
@Validated
@Component
@Slf4j
public class TrialsAdapterService {

    private static final String TRIALS_CREATE_MOTION_URL = "TRIALS_CREATE_MOTION_URL";
    private static final String TRIALS_CREATE_REHEARING_URL = "TRIALS_CREATE_REHEARING_URL";
    private static final String TRIALS_SUBMIT_PROCEEDING_URL = "TRIALS_SUBMIT_PROCEEDING_URL";
    private static final String TRIALS_DELETE_REHEARING_URL = "TRIALS_DELETE_REHEARING_URL";
    private static final String TRIALS_DELETE_MOTION_URL = "TRIALS_DELETE_MOTION_URL";
    private static final String TRIALS_UPDATE_REHEARING_URL = "TRIALS_UPDATE_REHEARING_URL";
    private static final String TRIALS_UPDATE_MOTION_URL = "TRIALS_UPDATE_MOTION_URL";
    private static final String LOGGEDIN_USER_MESSAGE = "Logged-In user name";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    private static final String USER_ID = "User Id";
    private static final String PROXY_USER_ID = "proxy-user-id";

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private HttpServletRequest httpServletRequest;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private PTABBusinessUtils ptabBusinessUtils;

    @Transactional
    public MotionDetails createMotion(@Valid @NotNull final MotionDetails motionDetails) {

        final String createMotionUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                TRIALS_CREATE_MOTION_URL);
        notFoundIfNull(createMotionUrl, "Create Motion details Url");
        final String loggedInUserName = getLoggedInUserId();
        notFoundIfNull(loggedInUserName, LOGGEDIN_USER_MESSAGE);
        log.info("calling common services for fetching application Information");
        updateMotionArtifactObject(motionDetails);
        ResponseEntity<MotionDetails> response = null;
        response = restServiceClient.callPTABExternalServiceURL(createMotionUrl, motionDetails, HttpMethod.POST,
                MotionDetails.class, loggedInUserName);
        if (response.getStatusCode().is2xxSuccessful()) {
            log.error("Successfully created motion via trialAdapter service");
            return getUpdatedMotionReponse(response);

        } else {
            final HttpStatus statusCode = (HttpStatus) response.getStatusCode();
            if (statusCode.is4xxClientError()) {
                final String msg = "error occurred create-motion";
                log.error(msg);
                throw new PTABException(statusCode, new ErrorPayload(msg));
            } else if (statusCode.is5xxServerError()) {
                final String msg = "Internal server error occurred while create-motion";
                log.error(msg);
                throw new PTABException(statusCode, new ErrorPayload(msg));
            }
            return null;
        }
    }

    @Transactional
    public RehearingInfo createRehearing(@Valid @NotNull final RehearingInfo rehearingInfo) {

        final String createRehearingUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                TRIALS_CREATE_REHEARING_URL);
        notFoundIfNull(createRehearingUrl, "Create Rehearing details Url");
        final String loggedInUserName = getLoggedInUserId();
        notFoundIfNull(loggedInUserName, LOGGEDIN_USER_MESSAGE);
        log.info("calling trial services for create rehearing");
        updateRehearingArtifactObject(rehearingInfo);
        ResponseEntity<RehearingInfo> response = null;
        response = restServiceClient.callPTABExternalServiceURL(createRehearingUrl, rehearingInfo, HttpMethod.POST,
                RehearingInfo.class, loggedInUserName);
        if (response.getStatusCode().is2xxSuccessful()) {
            log.error("Successfully created rehearing via trialAdapter service");
            return getUpdatedRehearingResponse(response);
        } else {
            final HttpStatus statusCode = (HttpStatus) response.getStatusCode();
            if (statusCode.is4xxClientError()) {
                final String msg = "error occurred create-rehearing";
                log.error(msg);
                throw new PTABException(statusCode, new ErrorPayload(msg));
            } else if (statusCode.is5xxServerError()) {
                final String msg = "Internal server error occurred while create-rehearing";
                log.error(msg);
                throw new PTABException(statusCode, new ErrorPayload(msg));
            }
            return null;
        }
    }

    @Transactional
    public void deleteRehearing(final Long rehearingId) {

        final String endpoint = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                TRIALS_DELETE_REHEARING_URL);
        notFoundIfNull(endpoint, "Delete Rehearing details Url");
        final String loggedInUserName = getLoggedInUserId();
        notFoundIfNull(loggedInUserName, LOGGEDIN_USER_MESSAGE);
        log.info("calling trial services for delete rehearing");
        final String deleteRehearingUrl = String.format(endpoint, rehearingId);
        ResponseEntity<Void> response = null;
        response = restServiceClient.callPTABExternalServiceURL(deleteRehearingUrl, null, HttpMethod.DELETE, Void.class,
                loggedInUserName);
        if (response.getStatusCode().is2xxSuccessful()) {
            log.error("Successfully deleted rehearing {} via trialAdapter service", rehearingId);
        } else {
            final HttpStatus statusCode = (HttpStatus) response.getStatusCode();
            if (statusCode.is4xxClientError()) {
                final String msg = "error occurred delete-rehearing for id " + rehearingId;
                log.error("error occurred delete-rehearing for id {}", rehearingId);
                throw new PTABException(statusCode, new ErrorPayload(msg));
            } else if (statusCode.is5xxServerError()) {
                final String msg = "Internal server error occurred while delete-rehearing";
                log.error(msg);
                throw new PTABException(statusCode, new ErrorPayload(msg));
            }
        }
    }

    private String getLoggedInUserId() {
        final String userIdentifier = (String) httpServletRequest.getAttribute("valid-user");
        if (StringUtils.isEmpty(userIdentifier))
            notFoundIfNull(userIdentifier, USER_ID);
        return userIdentifier;
    }

    @Transactional
    public RehearingInfo updatePartyRehearing(final RehearingInfo rehearingInfo, @NotNull final Long rehearingId) {
        final String endpoint = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                TRIALS_UPDATE_REHEARING_URL);
        notFoundIfNull(endpoint, "updateParty Rehearing details Url");
        final String loggedInUserName = getLoggedInUserId();
        notFoundIfNull(loggedInUserName, LOGGEDIN_USER_MESSAGE);
        log.info("calling trial services for updateParty rehearing");
        updateRehearingArtifactObject(rehearingInfo);
        final String deleteRehearingUrl = String.format(endpoint, rehearingId);
        final ResponseEntity<RehearingInfo> response = restServiceClient.callPTABExternalServiceURL(deleteRehearingUrl,
                rehearingInfo, HttpMethod.PUT, RehearingInfo.class, loggedInUserName);
        if (response.getStatusCode().is2xxSuccessful()) {
            log.error("Successfully updateParty rehearing {} via trialAdapter service", rehearingId);
            return getUpdatedRehearingResponse(response);
        } else {
            final HttpStatus statusCode = (HttpStatus) response.getStatusCode();
            if (statusCode.is4xxClientError()) {
                final String msg = "error occurred updateParty for id " + rehearingId;
                log.error("error occurred updateParty for id {}", rehearingId);
                throw new PTABException(statusCode, new ErrorPayload(msg));
            } else if (statusCode.is5xxServerError()) {
                final String msg = "Internal server error occurred while updateParty";
                log.error(msg);
                throw new PTABException(statusCode, new ErrorPayload(msg));
            }
            return null;
        }
    }

    @Transactional
    public void deleteMotion(final Long motionId) {

        final String endpoint = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                TRIALS_DELETE_MOTION_URL);
        notFoundIfNull(endpoint, "Delete Motion details Url");
        final String loggedInUserName = getLoggedInUserId();
        notFoundIfNull(loggedInUserName, LOGGEDIN_USER_MESSAGE);
        log.info("calling trial services for delete motion");
        final String deleteMotionUrl = String.format(endpoint, motionId);
        ResponseEntity<Void> response = null;
        response = restServiceClient.callPTABExternalServiceURL(deleteMotionUrl, null, HttpMethod.DELETE, Void.class,
                loggedInUserName);
        if (response.getStatusCode().is2xxSuccessful()) {
            log.error("Successfully deleted motion {} via trialAdapter service", motionId);
        } else {
            final HttpStatus statusCode = (HttpStatus) response.getStatusCode();
            if (statusCode.is4xxClientError()) {
                final String msg = "error occurred delete-motion for id " + motionId;
                log.error("error occurred delete-motion for id {}", motionId);
                throw new PTABException(statusCode, new ErrorPayload(msg));
            } else if (statusCode.is5xxServerError()) {
                final String msg = "Internal server error occurred while delete-motion";
                log.error(msg);
                throw new PTABException(statusCode, new ErrorPayload(msg));
            }
        }
    }

    @Transactional
    public MotionDetails updatePartyMotion(final MotionDetails motionDetails, @NotNull final Long motionId) {
        final String endpoint = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                TRIALS_UPDATE_MOTION_URL);
        notFoundIfNull(endpoint, "updateParty Motion details Url");
        final String loggedInUserName = getLoggedInUserId();
        notFoundIfNull(loggedInUserName, LOGGEDIN_USER_MESSAGE);
        log.info("calling trial services for updateParty motion");
        final String deleteMotionUrl = String.format(endpoint, motionId);
        updateMotionArtifactObject(motionDetails);
        final ResponseEntity<MotionDetails> response = restServiceClient.callPTABExternalServiceURL(deleteMotionUrl,
                motionDetails, HttpMethod.PUT, MotionDetails.class, loggedInUserName);
        if (response.getStatusCode().is2xxSuccessful()) {
            getUpdatedMotionReponse(response);
            log.error("Successfully updateParty motion {} via trialAdapter service", motionId);
            return response.getBody();
        } else {
            final HttpStatus statusCode = (HttpStatus) response.getStatusCode();
            if (statusCode.is4xxClientError()) {
                final String msg = "error occurred updateParty for id " + motionId;
                log.error("error occurred updateParty for id {}", motionId);
                throw new PTABException(statusCode, new ErrorPayload(msg));
            } else if (statusCode.is5xxServerError()) {
                final String msg = "Internal server error occurred while updateParty";
                log.error(msg);
                throw new PTABException(statusCode, new ErrorPayload(msg));
            }
            return null;
        }
    }

    @Transactional
    public void submitProceeding(final Petition petition) {

        final String submitProceedingUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                TRIALS_SUBMIT_PROCEEDING_URL);
        notFoundIfNull(submitProceedingUrl, "Create SubmitRehearing details Url");
        final String loggedInUserName = getLoggedInUserId();
        notFoundIfNull(loggedInUserName, LOGGEDIN_USER_MESSAGE);
        log.info("calling SubmitProceeding services for  submit Proceeding");
        final List<PetitionDocument> petitionDocuments = petition.getPetitionDocuments();
        ptabBusinessUtils.setDecryptArtifactIdentifiers(petitionDocuments);
        petition.setPetitionDocuments(petitionDocuments);

        final String proxyUserId = (String) httpServletRequest.getAttribute(PROXY_USER_ID);
        log.error("The proxy internal user id value is {} ", proxyUserId);
        if (StringUtils.isNotBlank(proxyUserId)) {
            petition.setInternalUserSubmitter(proxyUserId);
        }

        ResponseEntity<Void> response = null;
        response = restServiceClient.callPTABExternalServiceURL(submitProceedingUrl, petition, HttpMethod.POST, Void.class,
                loggedInUserName);
        if (response.getStatusCode().is2xxSuccessful()) {
            log.error("Successfully submit Proceeding via trialAdapter service");
        } else {
            final HttpStatus statusCode = (HttpStatus) response.getStatusCode();
            if (statusCode.is4xxClientError()) {
                final String msg = "error occurred submitProceeding";
                log.error(msg);
                throw new PTABException(statusCode, new ErrorPayload(msg));
            } else if (statusCode.is5xxServerError()) {
                final String msg = "Internal server error occurred while submitProceeding";
                log.error(msg);
                throw new PTABException(statusCode, new ErrorPayload(msg));
            }
        }
    }

    private MotionDetails getUpdatedMotionReponse(final ResponseEntity<MotionDetails> response) {
        final MotionDetails updated = response.getBody();
        if (null != updated) {
            final List<PetitionDocument> petitionDocuments = updated.getMotionDocuments();
            ptabBusinessUtils.setEncryptArtifactIdentifiers(petitionDocuments);
            updated.setMotionDocuments(petitionDocuments);
        }
        return updated;
    }

    private void updateMotionArtifactObject(final MotionDetails motionDetails) {
        final List<PetitionDocument> motionDocuments = motionDetails.getMotionDocuments();
        if (CollectionUtils.isNotEmpty(motionDocuments)) {
            ptabBusinessUtils.setDecryptArtifactIdentifiers(motionDocuments);
            motionDetails.setMotionDocuments(motionDocuments);
        }
    }

    private RehearingInfo getUpdatedRehearingResponse(final ResponseEntity<RehearingInfo> response) {
        final RehearingInfo updated = response.getBody();
        if (null != updated) {
            final List<PetitionDocument> petitionDocuments = updated.getRehearingDocuments();
            ptabBusinessUtils.setEncryptArtifactIdentifiers(petitionDocuments);
            updated.setRehearingDocuments(petitionDocuments);
        }
        return updated;
    }

    private void updateRehearingArtifactObject(final RehearingInfo rehearingInfo) {
        final List<PetitionDocument> rehearingDocuments = rehearingInfo.getRehearingDocuments();
        if (CollectionUtils.isNotEmpty(rehearingDocuments)) {
            ptabBusinessUtils.setDecryptArtifactIdentifiers(rehearingDocuments);
            rehearingInfo.setRehearingDocuments(rehearingDocuments);
        }
    }

}