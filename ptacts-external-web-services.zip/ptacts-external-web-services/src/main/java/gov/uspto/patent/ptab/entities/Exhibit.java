package gov.uspto.patent.ptab.entities;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the EXHIBIT database table.
 */
@Entity
@NamedQuery(name = "Exhibit.findAll", query = "SELECT e FROM Exhibit e")
@Table(name = "Exhibit")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Exhibit extends AbstractAuditEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "FK_PROCEEDING_ARTIFACT_ID")
    private long fkProceedingArtifactId;

    @Column(name = "FK_PROCEEDING_ID")
    private long fkProceedingId;

    @Column(name = "EXHIBIT_NO")
    private Long exhibitNo;

    @Column(name = "EXHIBIT_SEQUENCE_NO")
    private Long exhibitSequenceNo;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    @ManyToOne
    @JoinColumn(name = "FK_PROCEEDING_ID", insertable = false, updatable = false)
    private ProceedingEntity proceeding;

    @OneToOne
    @JoinColumn(name = "FK_PROCEEDING_ARTIFACT_ID", insertable = false, updatable = false)
    private ProceedingArtifact proceedingArtifact;
}