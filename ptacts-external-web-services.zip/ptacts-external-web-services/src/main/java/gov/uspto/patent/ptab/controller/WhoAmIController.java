package gov.uspto.patent.ptab.controller;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.patent.ptab.dao.ApplicationUserDao;
import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.PtabUser;
import gov.uspto.patent.ptab.entities.ApplicationUserEntity;
import gov.uspto.patent.ptab.repository.ApplicationUserRepository;
import gov.uspto.patent.ptab.utils.RBACService;
import gov.uspto.rbac.util.AuthenticatedUser;
import lombok.extern.slf4j.Slf4j;

/**
 * Controller to manage RBAC user roles and permissions
 *
 * @author 2020 Development Team
 */
@RestController
@Slf4j
public class WhoAmIController {

    private static final String DEFAULT_USER = "anonymousUser";
    private static final String AT_SYMBOL = "@";
    private static final String ETC_EXTENSION = "-etc";

    @Autowired
    private RBACService rbacService;

    @Autowired
    private ApplicationUserRepository applicationUserRepository;

    @Autowired
    private ApplicationUserDao applicationUserDao;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Value("${auth.kerberos.enabled}")
    private boolean kerberosEnabled;

    /**
     * This method will retrieve user information from security authentication
     *
     * @return - returns PtabUser object information retrieved from authentication
     */
    @GetMapping(produces = "application/json", value = "/kerb/who-am-i")
    public PtabUser listUserDetails() {
        String login = null;
        boolean isAllowedForLoginModal = false;
        if (kerberosEnabled) {
            final Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (null != authentication) {
                login = authentication.getName();
                log.info("Kerberos User Name {} and Principal {} ", login, authentication.getPrincipal());
                if (login.contains(AT_SYMBOL)) {
                    final String[] tokens = login.split(AT_SYMBOL);
                    login = tokens[0];
                }
                if (StringUtils.contains(login, ETC_EXTENSION)) {
                    login = StringUtils.remove(login, ETC_EXTENSION);
                }
                log.info("LoginId for Query {}", login);
                final List<String> ptabLoginModalAccessList = applicationUserDao.getLoginModalAccessByUserId(login);
                isAllowedForLoginModal = CollectionUtils.isNotEmpty(ptabLoginModalAccessList);
            }
        }
        final PtabUser ptabUser = new PtabUser();
        if ((StringUtils.isBlank(login) || StringUtils.equals(DEFAULT_USER, login)) && !kerberosEnabled) {
            log.error("**********Invalid User***********");
            login = codeReferenceDao.findDescriptionByTypeCodeAndValueTx("LOGIN_MODAL", "USER");
            log.error("**********Default User for login modal***********");
            if (null != login) {
                isAllowedForLoginModal = true;
            }
        }
        ptabUser.setUserId(login);
        ptabUser.setPtabLoginModalAccess(isAllowedForLoginModal);
        final ApplicationUserEntity applicationUserEntity = applicationUserRepository.findOneByUserId(login);
        if (null != applicationUserEntity) {
            ptabUser.setEmployeeNumber(applicationUserEntity.getApplicationUserId());
            ptabUser.setFirstName(applicationUserEntity.getFirstNm());
            ptabUser.setLastName(applicationUserEntity.getLastNm());
        }
        return ptabUser;
    }

    /**
     * Service is used to get the RBAC header information.
     *
     * @return - PTI required user information
     */
    @GetMapping(value = "/who-am-i")
    public AuthenticatedUser getUserDetails() {

        return rbacService.getApplicationAcessUserData();
    }
}
