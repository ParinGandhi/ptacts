package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the PROCEEDING_APPEAL database table.
 */
@Entity
@Table(name = "PROCEEDING_APPEAL")
@NamedQuery(name = "ProceedingAppeal.findAll", query = "SELECT p FROM ProceedingAppeal p")
@Getter
@Setter
@NoArgsConstructor
public class ProceedingAppeal extends AbstractAuditEntity implements Serializable {

    private static final long serialVersionUID = -4225388049980206018L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PROCEEDING_APPEAL_SEQ")
    @SequenceGenerator(name = "PROCEEDING_APPEAL_SEQ", sequenceName = "PROCEEDING_APPEAL_SEQ", allocationSize = 1)
    @Column(name = "PROCEEDING_APPEAL_ID")
    private long proceedingAppealId;

    @Temporal(TemporalType.DATE)
    @Column(name = "APPEAL_NOTICE_DT")
    private Date appealNoticeDt;

    @Temporal(TemporalType.DATE)
    @Column(name = "COURT_DECISION_DT")
    private Date courtDecisionDt;

    @Column(name = "COMMENT_TX")
    private String commentTx;

    @Temporal(TemporalType.DATE)
    @Column(name = "COURT_MANDATE_DT")
    private Date courtMandateDt;

    @Column(name = "FK_PROCEEDING_ID")
    private Long fkProceedingId;

    @Column(name = "FK_APPEAL_PARTY_TYPE_ID")
    private Long fkAppealPartyTypeId;

    @Column(name = "FK_APPEAL_STATUS_ID")
    private Long fkAppealStatusId;

    @Column(name = "FK_APPEAL_TYPE_ID")
    private Long fkAppealTypeId;

    @Column(name = "FK_EXTERNAL_COURT_ID")
    private Long fkExternalCourtId;

    @Version
    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    @ManyToOne
    @JoinColumn(name = "FK_APPEAL_PARTY_TYPE_ID", insertable = false, updatable = false)
    private StndPrcdngPartyGroupType stndPrcdngPartyGrpType;

    @OneToMany(mappedBy = "proceedingAppeal")
    private List<PrcdngAplArtfctSubmn> prcdngAplArtfctSubmns;

    @ManyToOne
    @JoinColumn(name = "FK_APPEAL_TYPE_ID", insertable = false, updatable = false)
    private StndAppealType stndAppealType;

    @ManyToOne
    @JoinColumn(name = "FK_APPEAL_STATUS_ID", insertable = false, updatable = false)
    private StndAppealStatus stndAppealStatus;

    @ManyToOne
    @JoinColumn(name = "FK_PROCEEDING_ID", insertable = false, updatable = false)
    private ProceedingEntity proceeding;

}
