package gov.uspto.patent.ptab.controller;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.domain.AppealDetails;
import gov.uspto.patent.ptab.domain.ExternalUserMotion;
import gov.uspto.patent.ptab.domain.ExternalUserRehearing;
import gov.uspto.patent.ptab.domain.TrialsBase;
import gov.uspto.patent.ptab.service.CaseViewerService;
import gov.uspto.patent.ptab.service.ExternalUserDocketService;
import lombok.extern.slf4j.Slf4j;

/**
 * Controller class for Case viewer
 *
 * @author 2020 development team
 *
 */
@Slf4j
@RestController
@RequestMapping("/case-viewer")
public class CaseViewerController {

    @Autowired
    private CaseViewerService caseViewerService;

    @Autowired
    private ExternalUserDocketService exterDocketService;

    /**
     * This end point is used to fetch all the caseBasicDetails for a given
     * proceeding core id
     *
     * @param trialsbase - input serial number and/or case number for processing
     * @return
     */
    @GetMapping(value = "/details")
    public JsonNode getCaseBasicDetails(final TrialsBase trialsbase) {
        log.info("GET getCaseBasicDetails:{}", trialsbase);
        return caseViewerService.getBasicDataDetails(trialsbase);
    }

    /**
     * This method is used to get associated case number details
     *
     * @param searchType
     * @param caseNumber
     * @return
     */
    @GetMapping(value = "/caseNumber-search")
    public JsonNode getCaseData(final String searchType, @Valid @NotNull String caseNumber) {
        log.info("caseNumber search:{}", caseNumber);
        return caseViewerService.getValidCaseData(searchType, caseNumber);
    }

    @GetMapping(value = "/proceeding-number/motions")
    public List<ExternalUserMotion> getMotions(@RequestParam(required = true) String proceedingNumber, String motionStatus,
            boolean excludeArtifacts, Long motionId) {
        return exterDocketService.getMotionsByPrcdNum(proceedingNumber, motionStatus, excludeArtifacts, motionId);
    }

    @GetMapping(value = "/proceeding-number/rehearings")
    public List<ExternalUserRehearing> getRehearings(@RequestParam(required = true) String proceedingNumber,
            String rehearingStatus, Long rehearingId) {
        return exterDocketService.getRehearingsByPrcdNum(proceedingNumber, rehearingStatus, rehearingId);
    }

    @GetMapping(value = "/proceeding-number/appeals")
    public List<AppealDetails> getAppealDetails(@RequestParam(required = true) String proceedingNumber,
            @RequestParam(required = true) String appealStatus) {
        return exterDocketService.getAppealsByPrcdNum(proceedingNumber, appealStatus);
    }
}
