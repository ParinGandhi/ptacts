package gov.uspto.patent.ptab.entities;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the PARTY database table.
 * 
 */
@Entity
@Table(name = "PARTY")
@NamedQuery(name = "Party.findAll", query = "SELECT p FROM Party p")
@Getter
@Setter
public class Party extends AbstractAuditEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PARTY_SEQ")
    @SequenceGenerator(name = "PARTY_SEQ", sequenceName = "PARTY_SEQ", allocationSize = 1)
    @Column(name = "PARTY_ID")
    private Long partyId;

    @Column(name = "FK_PARTY_TYPE_ID")
    private Long fkPartyTypeId;

    @Column(name = "LOCK_CONTROL_NO")
    protected Long lockControlNumber;

    @OneToOne(mappedBy = "party", cascade = CascadeType.REMOVE, orphanRemoval = true)
    private IndividualPartyEntity individualPartyEntity;

    @OneToOne(mappedBy = "party", cascade = CascadeType.REMOVE, orphanRemoval = true)
    private OrganizationPartyEntity organizationPartyEntity;

    @ManyToOne
    @JoinColumn(name = "FK_PARTY_TYPE_ID", insertable = false, updatable = false)
    private StndPartyType stndPartyType;

    @OneToOne(mappedBy = "party")
    @JoinColumn(name = "PARTY_ID", referencedColumnName = "FK_PARTY_ID", insertable = false, updatable = false)
    private ProceedingParty proceedingParty;
}