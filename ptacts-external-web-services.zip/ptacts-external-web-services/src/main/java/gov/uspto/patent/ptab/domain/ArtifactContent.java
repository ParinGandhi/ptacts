package gov.uspto.patent.ptab.domain;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(Include.NON_NULL)
public class ArtifactContent {

    private String documentName;
    private BigDecimal paperNumber;
    private BigDecimal exhibitNumber;

}
