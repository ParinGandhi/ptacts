package gov.uspto.patent.ptab.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.patent.ptab.domain.ProceedingQWithDecision;
import gov.uspto.patent.ptab.domain.ProceedingQWithUserDetails;
import gov.uspto.patent.ptab.domain.ProceedingQualatativeQ;
import gov.uspto.patent.ptab.domain.QualatativeQuestioner;
import gov.uspto.patent.ptab.service.QualitativeQuestionsServices;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping(value = "/ptab/qq")
public class QualitativeQuestionsController {

    @Autowired
    private QualitativeQuestionsServices qqService;

    @Autowired
    private PTABBusinessUtils ptabBusinessUtils;

    @GetMapping(value = "/questions", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<QualatativeQuestioner>> getConfiguredQuestioners() {
        return new ResponseEntity<>(qqService.getCOnfiguredQuestions(), HttpStatus.OK);
    }

    @GetMapping(value = "/questionsWithProceedingNumber", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ProceedingQWithDecision>> getQuestionsBasedOnProceedingNumberAndUserId(String proceedingNumber) {
        String userName = ptabBusinessUtils.getLoggedInUserId();
        log.info("GET call for getQuestionsBasedOnProceedingNumberAndUserId method");
        return new ResponseEntity<>(qqService.getQuestionsBasedOnProceedingNumberAndUserId(userName, proceedingNumber),
                HttpStatus.OK);
    }

    @GetMapping(value = "/questionsWithUserDetails", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ProceedingQWithUserDetails> getQuestionsBasedOnProceedingNumber(String proceedingNumber) {
        log.info("GET call for getQuestionsBasedOnProceedingNumber method:{}");
        String userName = ptabBusinessUtils.getLoggedInUserId();
        return new ResponseEntity<>(qqService.getQuestionsBasedOnProceedingNumber(userName, proceedingNumber), HttpStatus.OK);
    }

    @PostMapping(value = "/create", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<ProceedingQWithDecision> createProceedingQualatative(
            @RequestBody List<ProceedingQualatativeQ> proceedingQualatativeQs) {
        log.info("POST call for createProceedingQualatative method");
        String userName = ptabBusinessUtils.getLoggedInUserId();
        return qqService.createProceedingQualatative(userName, proceedingQualatativeQs);

    }

    @PutMapping(value = "/update")
    public List<ProceedingQWithDecision> updateProceedingQualatative(
            @RequestBody List<ProceedingQualatativeQ> proceedingQualatativeQs) {
        log.info("PUT call for updateProceedingQualatative method");
        String userName = ptabBusinessUtils.getLoggedInUserId();
        return qqService.updateProceedingQualatative(userName, proceedingQualatativeQs, 0);
    }

    @PutMapping(value = "/update-final-answer")
    public List<ProceedingQWithDecision> updateProceedingQualatativeQFinalAnswer(
            @RequestBody List<ProceedingQualatativeQ> proceedingQualatativeQs) {
        log.info("PUT call for updateProceedingQualatative method");
        String userName = ptabBusinessUtils.getLoggedInUserId();
        return qqService.updateProceedingQualatative(userName, proceedingQualatativeQs, 1);
    }

}
