
package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the STND_DOCUMENT_CATEGORY database table.
 * 
 */
@Entity
@Table(name = "STND_DOCUMENT_CATEGORY")
@NamedQuery(name = "StndDocumentCategory.findAll", query = "SELECT c FROM StndDocumentCategory c")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StndDocumentCategory extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "DOCUMENT_CATEGORY_ID")
    private long documentCategoryId;

    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Column(name = "DESCRIPTION_TX")
    private String descriptionTx;

    @Column(name = "DOCUMENT_CATEGORY_CD")
    private String documentCategoryCd;

    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

}