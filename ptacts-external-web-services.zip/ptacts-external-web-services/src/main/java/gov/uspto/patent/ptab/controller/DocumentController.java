package gov.uspto.patent.ptab.controller;

import java.io.IOException;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import gov.uspto.patent.ptab.encrypt.RC4CipherEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import gov.uspto.patent.ptab.domain.DocumentQuery;
import gov.uspto.patent.ptab.domain.DocumentsQuery;
import gov.uspto.patent.ptab.domain.PetitionFile;
import gov.uspto.patent.ptab.service.DocumentService;
import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to store the documents in mount storage and submit the documents into content management system
 *
 * @author 2020 development team
 *
 */
@RestController
@RequestMapping
@Slf4j
public class DocumentController {

    @Autowired
    private DocumentService documentService;

    /**
     * This method is used to store the document into mount location
     *
     * @param proceedingId - petition identifier
     * @param file         - multipart file object to be loaded tin mount
     * @throws IOException
     */
    @PostMapping(value = "/petitions/{petitionId}/documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = {
            MediaType.APPLICATION_JSON_VALUE })
    public PetitionFile storeDocument(@NotNull @PathVariable("petitionId") final Long proceedingId,
            @RequestPart("file") final MultipartFile file, @RequestPart("category") String paperType) throws IOException {
        log.info("The documents stored into mount location for the proceeding id {} ", proceedingId);
        return documentService.storeDocument(proceedingId, file,paperType);
    }

    /**
     * This method is used to get the document from mount location
     *
     * @param proceedingId  - petition identifier
     * @param documentQuery - document query
     * @throws IOException
     *
     */
    @GetMapping(value = "/petitions/{petitionId}/download-documents", produces = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<InputStreamResource> downloadDocument(@NotNull @PathVariable("petitionId") final Long proceedingId,
            @Valid final DocumentQuery documentQuery) throws IOException {

        log.info("The document downloaded using the artifact identifier{} ", documentQuery.getArtifactId());
        String decryptedArtifactId = RC4CipherEntity.decrypt(documentQuery.getArtifactId());
        documentQuery.setArtifactId(decryptedArtifactId);
         return documentService.downloadDocument(proceedingId, documentQuery, false);

    }


    /**
     * This method is used to store the document into mount location
     *
     *
     * @param proceedingId - petition identifier
     * @param file         - multipart file object to be loaded tin mount
     * @throws IOException
     */
    @GetMapping(value = "/petitions/{petitionId}/documents", produces = { MediaType.MULTIPART_FORM_DATA_VALUE,
            MediaType.APPLICATION_OCTET_STREAM_VALUE })
    public ResponseEntity<InputStreamResource> getDocument(@NotNull @PathVariable("petitionId") final Long proceedingId,
            final DocumentsQuery documentsQuery) {
        log.info("get The documents stored in the mount location for the proceeding id {} ", proceedingId);
        return documentService.getDocument(proceedingId, documentsQuery);
    }

}
