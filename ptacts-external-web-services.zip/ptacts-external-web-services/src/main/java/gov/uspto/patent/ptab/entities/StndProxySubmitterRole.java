package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the STND_PROXY_SUBMITTER_ROLE database table.
 * 
 */
@Entity
@Table(name = "STND_PROXY_SUBMITTER_ROLE")
@NamedQuery(name = "StndProxySubmitterRole.findAll", query = "SELECT s FROM StndProxySubmitterRole s")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StndProxySubmitterRole extends AbstractAuditEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "PROXY_SUBMITTER_ROLE_NM")
    private String proxySubmitterRoleNm;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Column(name = "DESCRIPTION_TX")
    private String descriptionTx;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo;

    @Column(name = "DISPLAY_NM")
    private String displayName;

}