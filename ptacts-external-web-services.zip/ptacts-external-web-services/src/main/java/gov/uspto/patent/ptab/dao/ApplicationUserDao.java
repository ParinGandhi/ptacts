package gov.uspto.patent.ptab.dao;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;

/**
 * DAO Implementation for ApplicationUser
 *
 * @author 2020 development team
 *
 */
@SuppressWarnings({ "unchecked" })
@Repository
@Slf4j
public class ApplicationUserDao {

    private static final String USER_ID = "userId";

    @Autowired
    private SessionFactory sessionFactory;

    /**
     * This method is used to validate user id
     *
     * @param userId - unique userId to be validated
     * @return
     */
    @Transactional(readOnly = true)
    public String getValidUserRole(final String userId) {
        log.info("Dao call for getValidUserRole method");
        final Query<?> query = sessionFactory.getCurrentSession().createNamedQuery("getValiedUserRole", Object.class);
        query.setParameter(USER_ID, userId);
        return (String) query.uniqueResult();
    }

    /**
     * This method is used to retrieve RoleDescription
     *
     * @param applicationUserId - input applicationUserId
     * @return
     */
    public String getRoleDescription(final String applicationUserId) {
        log.info("Dao call for getRoleDescription method");
        final Query<?> query = sessionFactory.getCurrentSession().createNamedQuery("getRoleDiscription", Object.class);
        query.setParameter("applicationUserId", applicationUserId);
        return (String) query.uniqueResult();
    }

    /**
     * This method is used to retrieve RoleDescription
     *
     * @param applicationUserId - input applicationUserId
     * @return
     */
    public BigDecimal getRoleId(final String applicationUserId) {
        log.info("Dao call for getRoleId method");
        final Query<?> query = sessionFactory.getCurrentSession().createNamedQuery("getRoleId", Object.class);
        query.setParameter("applicationUserId", applicationUserId);
        return BigDecimal.valueOf((Integer) query.uniqueResult());
    }

    /**
     * This method is used to get user to have login modal
     *
     * @param userId - unique userId to be validated
     * @return
     */
    @Transactional(readOnly = true)
    public List<String> getLoginModalAccessByUserId(final String userId) {
        log.info("Dao call for getLoginModalAccessByUserId method");
        final Query<?> query = sessionFactory.getCurrentSession().createNamedQuery("getLoginModalAccessByUserId",
                Object[].class);
        query.setParameter(USER_ID, userId);
        return (List<String>) query.list();
    }

    /**
     * This method is used to retrieve disciplines for APJ
     *
     * @param firstNm - input first name
     * @return
     */
    public String getDiscipline(final String judgeIdentifier) {
        final Query<?> query = sessionFactory.getCurrentSession().createNamedQuery("getAppealDisciplines", Object.class);
        query.setParameter("judgeIdentifier", judgeIdentifier);
        return (String) query.uniqueResult();
    }

    /**
     * This method is used to validate user id
     *
     * @param userId - unique userId to be validated
     * @return
     */
    @Transactional(readOnly = true)
    public List<String> getConfigurredResourceObjectsByUserId(final String userId) {
        log.info("Dao call for getValidUserRole method");
        final Query<?> query = sessionFactory.getCurrentSession().createNamedQuery("getConfigurredResourceObjectsByUserId",
                Object[].class);
        query.setParameter(USER_ID, userId);
        return (List<String>) query.list();
    }

}