package gov.uspto.patent.ptab.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RuleSetResponse {

    private Long proceedingIdentifier;
    private String proceedingNumber;
    private String patentNumber;
    private String proceedingCategory;
    private Long proceedingStateId;
    private String parentCaseStatusHistoryIdentifier;
    private Long currentStateIdentifier;
    private Long targetStateIdentifier;
    private Long ptabEventIdentifier;
    private Long currentTaskIdentifier;
    private Long targetTaskIdentifier;
    private String targetWorkerId;
    private String targetTaskType;
    private String palmTransaction;
    private String notificationRequireIndicator;
    private String documentUploadRequireIndicator;
    private String dueDateCalculationIndicator;
    private String dueDateCalculationIdentifier;
    private boolean isPalmTrsanctionPosted = false;
    private String userName;
}
