package gov.uspto.patent.ptab.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import gov.uspto.patent.ptab.entities.ProceedingEntity;

/**
 *
 * This is the interface class for ApplicationUser
 *
 * @author 2020 Development Team
 *
 */
@Repository
public interface ProceedingRepository extends JpaRepository<ProceedingEntity, Long> {

    @Query(value = "select proceeding from ProceedingEntity proceeding where proceeding.proceedingNo=(?1)")
    ProceedingEntity getProceedingDetails(final String proceedingNumber);

    @Query(value = "select proceeding from ProceedingEntity proceeding where proceeding.proceedingId=(?1)")
    ProceedingEntity getProceeding(final Long proceedingId);

}