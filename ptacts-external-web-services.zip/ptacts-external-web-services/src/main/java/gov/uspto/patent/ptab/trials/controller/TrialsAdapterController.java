package gov.uspto.patent.ptab.trials.controller;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.patent.ptab.domain.Petition;
import gov.uspto.patent.ptab.trials.domain.MotionDetails;
import gov.uspto.patent.ptab.trials.domain.RehearingInfo;
import gov.uspto.patent.ptab.trials.service.TrialsAdapterService;

/**
 * This class is adapter to invoke trail services.
 *
 * @author 2020 development team
 *
 */
@RestController
@RequestMapping("/trials")
public class TrialsAdapterController {

    @Autowired
    private TrialsAdapterService trialsAdapterService;

    @PostMapping(value = "/motions/create-motion")
    public MotionDetails createMotion(@NotNull @RequestBody final MotionDetails motionDetails) {
        return trialsAdapterService.createMotion(motionDetails);
    }

    @PostMapping(value = "/rehearing-info/create-rehearing")
    public RehearingInfo createRehearing(@RequestBody final RehearingInfo rehearingInfo) {
        return trialsAdapterService.createRehearing(rehearingInfo);
    }

    @DeleteMapping(value = "/rehearing-info/delete-rehearing/{rehearingId}")
    public void deleteRehearing(@NotBlank @PathVariable("rehearingId") final Long rehearingId) {
        trialsAdapterService.deleteRehearing(rehearingId);
    }

    @PutMapping(value = "/rehearing-info/updatepartyrehearing/{rehearingId}")
    public RehearingInfo updatePartyRehearing(@RequestBody final RehearingInfo rehearingInfo,
            @NotNull @PathVariable("rehearingId") final Long rehearingId) {
        return trialsAdapterService.updatePartyRehearing(rehearingInfo, rehearingId);
    }

    @DeleteMapping(value = "/motions/delete-motion/{motionId}")
    public void deleteMotion(@NotBlank @PathVariable("motionId") final Long motionId) {
        trialsAdapterService.deleteMotion(motionId);
    }

    @PutMapping(value = "/motions/updatepartymotion/{motionId}")
    public MotionDetails updatePartyMotion(@RequestBody final MotionDetails motionDetails,
            @NotNull @PathVariable("motionId") final Long motionId) {
        return trialsAdapterService.updatePartyMotion(motionDetails, motionId);
    }

    @PostMapping(value = "/proceeding/submitproceeding")
    public void submitProceeding(@RequestBody @Valid final Petition petition) {
        trialsAdapterService.submitProceeding(petition);
    }
}