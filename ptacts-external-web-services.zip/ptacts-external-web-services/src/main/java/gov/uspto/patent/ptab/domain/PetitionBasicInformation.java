package gov.uspto.patent.ptab.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import gov.uspto.patent.ptab.entities.ExternalUser;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class PetitionBasicInformation {
    private Long proceedingId;
    private String trialType;
    private Long fiscalYear;
    private String submitterEmailAddress;
    private String proceedingNumberText;
    private ApplicationDetails petitionerApplDetails;
    private ApplicationDetails patentOwnerApplDetails;

    @JsonIgnore
    private ExternalUser externalUser;

    @JsonIgnore
    private String userName;
}
