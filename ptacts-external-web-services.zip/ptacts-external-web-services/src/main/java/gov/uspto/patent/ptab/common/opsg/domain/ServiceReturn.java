package gov.uspto.patent.ptab.common.opsg.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is base return object which will be used across the project for all the service calls. This will have error
 * code, reason code and messageDesc which tells the status of service call
 * 
 * @author 2020 Development Team
 *
 */
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class ServiceReturn {

    public enum AlertLevel {
        CRITICAL, MAJOR, MINOR
    }

    private String errorCode;
    private String reasonCode;
    private String messageDesc;
    @JsonIgnore
    private int errorStatus;
    @JsonIgnore
    private List<String> messages;
    @JsonIgnore
    private AlertLevel alertLevel;
    @JsonIgnore
    private String event;
    @JsonIgnore
    private String tierName;

}
