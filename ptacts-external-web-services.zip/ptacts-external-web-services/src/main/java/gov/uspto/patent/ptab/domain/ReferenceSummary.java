package gov.uspto.patent.ptab.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * This class is having the details of the standard reference data
 * 
 * @author 2020 development team
 *
 */
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class ReferenceSummary {

    private Long identifier;
    private String code;
    private String descriptionText;
    private String displayNameText;
}
