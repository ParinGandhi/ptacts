package gov.uspto.patent.ptab.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(Include.NON_NULL)
public class ApplicationDetails {

    private String applicationNumber;
    private String patentNumber;
    private ApplicationBasicInformation applicationBasicInformation;

}
