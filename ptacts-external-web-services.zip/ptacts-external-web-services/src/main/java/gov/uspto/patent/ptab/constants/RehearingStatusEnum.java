package gov.uspto.patent.ptab.constants;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Enum to represent the Rehearing Status. *
 */
public enum RehearingStatusEnum {

    PENDING_REVIEW(1L), GRANTED(2L), DENIED(3L),
    LEGACY_DATA(4L), INITIATED(5L), GRANTED_IN_PART(6L),
    NO_DECISION(7L);

    private final Long rehearingStatusId;

    private RehearingStatusEnum(Long rehearingStatusId) {
        this.rehearingStatusId = rehearingStatusId;
    }

    public Long rehearingStatusId() {
        return rehearingStatusId;
    }

    public static Long getDBRehearingStatus(String rehearingStatus) {
        switch (rehearingStatus) {
            case "PENDING_REVIEW":
                return RehearingStatusEnum.PENDING_REVIEW.rehearingStatusId();
            case "GRANTED":
                return RehearingStatusEnum.GRANTED.rehearingStatusId();
            case "DENIED":
                return RehearingStatusEnum.DENIED.rehearingStatusId();
            case "LEGACY_DATA":
                return RehearingStatusEnum.LEGACY_DATA.rehearingStatusId();
            case "INITIATED":
                return RehearingStatusEnum.INITIATED.rehearingStatusId();
            case "GRANTED_IN_PART":
                return RehearingStatusEnum.GRANTED_IN_PART.rehearingStatusId();
            case "NO_DECISION":
                return RehearingStatusEnum.NO_DECISION.rehearingStatusId();
            default:
                return 0L;
        }
    }

    public static List<Long> getEnumStatusIdValues() {
        return Stream.of(RehearingStatusEnum.values()).map(RehearingStatusEnum::rehearingStatusId).collect(Collectors.toList());
    }

}
