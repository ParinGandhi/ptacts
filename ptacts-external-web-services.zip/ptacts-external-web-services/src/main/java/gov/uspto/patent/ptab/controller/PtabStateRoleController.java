package gov.uspto.patent.ptab.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.patent.ptab.domain.PtabStateRoleDisplayDetails;
import gov.uspto.patent.ptab.service.PtabStateRoleService;

/**
 * THis class is used to handle REST API for ptab-state-role
 * 
 * @author 2020 development team
 *
 */
@RestController
@RequestMapping(path = "/ptab-state-role")
public class PtabStateRoleController {

    @Autowired
    private PtabStateRoleService ptabStateRoleService;

    /**
     * This will return ptab state role deta for given group name
     * 
     * @param caseNumber - unique case Identifier
     * @return
     */
    @GetMapping(produces = "application/json")
    public List<PtabStateRoleDisplayDetails> getStateRoleDisplay(@RequestParam("caseNumber") final String caseNumber) {
        return ptabStateRoleService.getStateRoleDisplay(caseNumber);
    }
}