package gov.uspto.patent.ptab.controller;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.patent.ptab.domain.MandatoryNotice;
import gov.uspto.patent.ptab.domain.ProceedingParties;
import gov.uspto.patent.ptab.service.MandatoryNoticeService;

@RestController
@RequestMapping("/mandatory-notice")
public class MandatoryNoticeController {

    @Autowired
    private MandatoryNoticeService mandatoryNoticeService;

    @PostMapping
    public MandatoryNotice createMandatoryNoticeDetails(@Valid @NotNull @RequestBody final MandatoryNotice mandatoryNotice) {
        return mandatoryNoticeService.createMandatoryNotice(mandatoryNotice);
    }
    
    @PutMapping
    public ProceedingParties updateMandatoryNoticeDetails(
            @Valid @NotNull @RequestBody final ProceedingParties proceedingParties) {
        return mandatoryNoticeService.updateMandatoryNoticeDetails(proceedingParties);
    }
}
