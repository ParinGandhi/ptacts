package gov.uspto.patent.ptab.utils;

import java.io.IOException;

import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RestDefaultErrorHandler implements ResponseErrorHandler {

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.web.client.ResponseErrorHandler#handleError(org.springframework.http.client.
     * ClientHttpResponse)
     */
    @Override
    public void handleError(final ClientHttpResponse response) {
        try {
            log.error("Response error: {} {}", response.getStatusCode(), response.getBody().toString());
        } catch (final IOException ex) {
            log.error(ex.getMessage(), ex);
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.web.client.ResponseErrorHandler#hasError(org.springframework.http.client.ClientHttpResponse)
     */
    @Override
    public boolean hasError(final ClientHttpResponse response) {
        final boolean hasErrorReponse = false;
        try {
            final HttpStatus.Series series = ((HttpStatus) response.getStatusCode()).series();
            return (HttpStatus.Series.CLIENT_ERROR.equals(series) || HttpStatus.Series.SERVER_ERROR.equals(series));
        } catch (final IOException ex) {
            log.error(ex.getMessage(), ex);
        }
        return hasErrorReponse;
    }

}