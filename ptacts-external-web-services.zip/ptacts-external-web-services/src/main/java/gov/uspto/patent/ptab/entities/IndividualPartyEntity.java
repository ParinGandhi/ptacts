package gov.uspto.patent.ptab.entities;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the EXTERNAL_USER database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = "INDIVIDUAL_PARTY")
public class IndividualPartyEntity extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "FK_APPLICATION_USER_ID")
    private Long fkApplicationUserId;

    @Id
    @Column(name = "FK_PARTY_ID")
    private long fkPartyId;

    @Column(name = "FIRST_NM")
    private String firstNm;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo;

    @Column(name = "LAST_NM")
    private String lastNm;

    @Column(name = "MIDDLE_NM")
    private String middleNm;

    @OneToOne
    @JoinColumn(name = "FK_PARTY_ID", referencedColumnName = "PARTY_ID", insertable = false, updatable = false)
    private Party party;
}