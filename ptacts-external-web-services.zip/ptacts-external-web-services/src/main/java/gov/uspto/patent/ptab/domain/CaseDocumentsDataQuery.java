package gov.uspto.patent.ptab.domain;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CaseDocumentsDataQuery {

    private String proceedingNumber;
    private Long typeId;
    private String status;
    private String docType;
    private String caseType;
    private String caseStatus;
    private Long proceedingPartyGroupId;
    private boolean excludeArtifacts;
    private boolean includePetitionerStaffDetails;
    private boolean includePoStaffDetails;

}
