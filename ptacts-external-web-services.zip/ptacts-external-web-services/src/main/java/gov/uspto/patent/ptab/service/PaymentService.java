package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;
import static gov.uspto.patent.ptab.utils.PTABServiceUtils.validateRequest;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.AdhocPayment;
import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.domain.OidcAuthTokenVerificationResponse;
import gov.uspto.patent.ptab.domain.PaymentInformation;
import gov.uspto.patent.ptab.domain.PaymentRequest;
import gov.uspto.patent.ptab.domain.PaymentVO;
import gov.uspto.patent.ptab.encrypt.RC4CipherEntity;
import gov.uspto.patent.ptab.entities.TransactionAuthorizationDetailEntity;
import gov.uspto.patent.ptab.repository.TransactionAuthorizationDetailRepository;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class PaymentService {

    private static final String SUCCESSFUL_PAYMENT_RETURN_CODE = "1";
    private static final String PROCEEDING_SUBMISSION_URL = "PROCEEDING_SUBMISSION_URL";
    private static final String PROCEEDING_ADHOC_PAYMENT_URL = "PROCEEDING_ADHOC_PAYMENT_URL";
    private static final String PROCEEDING_COMPLETE_PAYMENT_URL = "PROCEEDING_COMPLETE_PAYMENT_URL";
    private static final String PROCEEDING_CANCEL_PAYMENT_URL = "PROCEEDING_CANCEL_PAYMENT_URL";
    private static final String PROCEEDING_CREATE_PAYMENT_URL = "PROCEEDING_CREATE_PAYMENT_URL";
    private static final String PROCEEDING_GET_PAYMENT_URL = "PROCEEDING_GET_PAYMENT_URL";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    private static final String USER_NAME_HEADER_KEY = "user-name";
    private static final String OAUTH_USERINFO = "OAUTH_USERINFO";
    private static final String AUTH_TOKEN = "AUTH_TOKEN";
    private static final String HEADER_VALUE_APPL_JSON = "application/json;charset=UTF-8";
    private static final String HEADER_NAME_ACCEPT = "Accept";
    private static final String AUTHORIZATION = "Authorization";
    private static final String BEARER = "Bearer";
    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private PTABBusinessUtils ptabBusinessUtils;

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Autowired
    private ExternalUserService externalUserService;

    @Autowired
    private TransactionAuthorizationDetailRepository authorizationDetailRepository;

    @Autowired
    private HttpServletRequest request;

    @Transactional
    public PaymentVO createPayment(final Long proceedingId, final PaymentRequest paymentRequest) {
        final String createPaymentUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_CREATE_PAYMENT_URL);
        validateRequest(createPaymentUrl, "Create Payment URL is empty");
        final String userId = ptabBusinessUtils.getLoggedInUserId();

        final TransactionAuthorizationDetailEntity authorizationDetailEntity = saveTransactionAuthTables(null);

        log.error("after saving the transaction id :" + authorizationDetailEntity.getTransactionTokenId() + " at "
                + authorizationDetailEntity.getTransactionTimestamp());
        final String encyptedTransactionId = RC4CipherEntity
                .encrypt(authorizationDetailEntity.getTransactionTokenId().toString());
        final String createPaymentFmtUrl = String.format(createPaymentUrl, proceedingId, encyptedTransactionId);
        final ResponseEntity<PaymentVO> response = restServiceClient.callPTABExternalServiceURL(createPaymentFmtUrl,
                paymentRequest, HttpMethod.POST, PaymentVO.class, userId);
        return null != response ? response.getBody() : null;
    }

    @Transactional
    public PaymentVO createAdhocPayment(final Long proceedingId, final JsonNode adhocPayment) {

        final String createPaymentUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_ADHOC_PAYMENT_URL);
        validateRequest(createPaymentUrl, "Create Adhoc Payment URL is empty");
        final String userId = ptabBusinessUtils.getLoggedInUserId();
        final String createPaymentFmtUrl = String.format(createPaymentUrl, proceedingId);

        final ObjectMapper mapper = new ObjectMapper();
        final AdhocPayment adhocPaymentOne = mapper.convertValue(adhocPayment, AdhocPayment.class);

        final TransactionAuthorizationDetailEntity authorizationDetailEntity = saveTransactionAuthTables(adhocPaymentOne);
        log.error("after saving the transaction id in Adhoc payment method:" + authorizationDetailEntity.getTransactionTokenId()
                + " at " + authorizationDetailEntity.getTransactionTimestamp());
        final ResponseEntity<PaymentVO> response = restServiceClient.callPTABExternalServiceURL(createPaymentFmtUrl,
                adhocPaymentOne, HttpMethod.POST, PaymentVO.class, userId);
        return null != response ? response.getBody() : null;
    }

    @Transactional
    public String updateCompletePayment(final long proceedingId, final long paymentId,
            final MultiValueMap<String, String> parameters) {

        final String prcdCompletePaymentUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_COMPLETE_PAYMENT_URL);
        notFoundIfNull(prcdCompletePaymentUrl, PROCEEDING_COMPLETE_PAYMENT_URL);
        final String userId = ptabBusinessUtils.getLoggedInUserId();
        final String prcdCompletePaymentFrmtUrl = String.format(prcdCompletePaymentUrl, proceedingId, paymentId);
        final HttpHeaders headers = getHttpHeaders(userId);
        final ResponseEntity<PaymentVO> paymentResponse = restServiceClient.invokeWebService(prcdCompletePaymentFrmtUrl,
                parameters, HttpMethod.POST, PaymentVO.class, headers);
        String receiptHtmlResponse = null;
        if (paymentResponse.getStatusCode().is2xxSuccessful()) {
            final PaymentVO paymentVO = paymentResponse.getBody();
            if (null != paymentVO) {
                receiptHtmlResponse = paymentVO.getReceiptHtmlResponse();
                log.error("The HTML response value is {} ", receiptHtmlResponse);
                log.error("The  payment return code value is {} ", paymentVO.getReturnCode());
                if (StringUtils.equals(paymentVO.getReturnCode(), SUCCESSFUL_PAYMENT_RETURN_CODE)) {
                    final String submissionUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                            PROCEEDING_SUBMISSION_URL);
                    try {
                        final ResponseEntity<String> submissionResponse = restServiceClient.invokeWebServiceAndCatchError(
                                String.format(submissionUrl, proceedingId, paymentId), parameters, HttpMethod.POST, String.class,
                                headers);
                        if (paymentResponse.getStatusCode().is2xxSuccessful()) {
                            log.error("Documents submitted successfully");
                        } else {
                            log.error("Documents failed to submit and response error code is {} ",
                                    submissionResponse.getStatusCode());
                        }
                    } catch (final Exception ex) {
                        log.error(ex.getMessage(), ex);
                    }
                }
            }

        }
        return receiptHtmlResponse;
    }

    @Transactional
    public String updatePaymentDetails(final long proceedingId, final long paymentId, final String receiptId,
            final String transactionId) {
        String receiptHtmlResponse = null;
        if (StringUtils.isNotEmpty(transactionId)) {
            final String decryptedTransactionId = RC4CipherEntity.decrypt(transactionId);
            log.error("complete transactionId : " + decryptedTransactionId);
            final Optional<TransactionAuthorizationDetailEntity> authorizationDetailEntity = authorizationDetailRepository
                    .findById(new BigDecimal(decryptedTransactionId));
            if ( authorizationDetailEntity.isPresent()) {
                final String authToken = authorizationDetailEntity.get().getServerAuthorizationTokenText();
                if (StringUtils.isNotBlank(authToken)) {
                    log.error("auth Token : " + authToken);
                    receiptHtmlResponse = callProceedingSubmissionAfterAuthVerf(authorizationDetailEntity.get(), authToken,
                            proceedingId, paymentId, receiptId, receiptHtmlResponse);
                }

            }

        }
        return receiptHtmlResponse;
    }

    @Transactional
    public String updateCancelPayment(final long proceedingId, final long paymentId,
            final MultiValueMap<String, String> parameters) {

        final String prcdCancelPaymentUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_CANCEL_PAYMENT_URL);
        notFoundIfNull(prcdCancelPaymentUrl, PROCEEDING_CANCEL_PAYMENT_URL);
        final String userId = ptabBusinessUtils.getLoggedInUserId();
        final String prcdCancelPaymentFrmtUrl = String.format(prcdCancelPaymentUrl, proceedingId, paymentId);
        final HttpHeaders headers = getHttpHeaders(userId);
        final ResponseEntity<String> response = restServiceClient.invokeWebService(prcdCancelPaymentFrmtUrl, parameters,
                HttpMethod.POST, String.class, headers);
        return null != response ? response.getBody() : null;
    }

    @Transactional
    public String updateCancelPayment(final long proceedingId, final String transactionId, final long paymentId) {
        String response = null;
        if (StringUtils.isNotBlank(transactionId)) {
            final String decryptedTransactionId = RC4CipherEntity.decrypt(transactionId);
            log.error("cancel transactionId : " + decryptedTransactionId);
            final Optional<TransactionAuthorizationDetailEntity> authorizationDetailEntity = authorizationDetailRepository
                    .findById(new BigDecimal(decryptedTransactionId));
            if ( authorizationDetailEntity.isPresent()) {
                final String authToken = authorizationDetailEntity.get().getServerAuthorizationTokenText();
                if (StringUtils.isNotBlank(authToken)) {
                    log.error("auth Token : " + authToken);
                    final ResponseEntity<String> responseStr = verifyAuthToken(authToken);
                    String userId = null;
                    if (null != responseStr && responseStr.getStatusCode().is2xxSuccessful()) {
                        userId = getUserIdFromAuthToken(responseStr, userId);
                    } else {
                        userId = authorizationDetailEntity.get().getUserId();
                    }
                    response = callProceedingCancelpaymentUrl(proceedingId, paymentId, userId);
                }
            }
        }
        return response;
    }

    private String callProceedingCancelpaymentUrl(final long proceedingId, final long paymentId, final String userId) {

        log.error("In proceeding cancel call");
        final String prcdCancelPaymentUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_CANCEL_PAYMENT_URL);
        notFoundIfNull(prcdCancelPaymentUrl, PROCEEDING_CANCEL_PAYMENT_URL);
        // final String userId = ptabBusinessUtils.getLoggedInUserId();
        final String prcdCancelPaymentFrmtUrl = String.format(prcdCancelPaymentUrl, proceedingId, paymentId);
        final HttpHeaders headers = getHttpHeaders(userId);
        final ResponseEntity<String> response = restServiceClient.invokeWebService(prcdCancelPaymentFrmtUrl, null,
                HttpMethod.POST, String.class, headers);
        return null != response ? response.getBody() : null;
    }

    @Transactional
    public PaymentVO getPayments(final long proceedingId) {

        final String getPaymentUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_GET_PAYMENT_URL);
        validateRequest(getPaymentUrl, "Get Payment URL is empty");
        final String userId = ptabBusinessUtils.getLoggedInUserId();
        final String getPaymentFmtUrl = String.format(getPaymentUrl, proceedingId);
        final ResponseEntity<PaymentVO> response = restServiceClient.callPTABExternalServiceURL(getPaymentFmtUrl, null,
                HttpMethod.GET, PaymentVO.class, userId);
        return null != response ? response.getBody() : null;
    }

    @Transactional
    public PaymentVO getPayments(final Long proceedingId, final Long paymentId) {

        final String getPaymentUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                "PROCEEDING_PAYMENT_RECEIPT_URL");
        validateRequest(getPaymentUrl, "Get Payment URL is empty");
        final String userId = ptabBusinessUtils.getLoggedInUserId();
        final String getPaymentFmtUrl = String.format(getPaymentUrl, proceedingId, paymentId);
        final ResponseEntity<PaymentVO> response = restServiceClient.callPTABExternalServiceURL(getPaymentFmtUrl, null,
                HttpMethod.GET, PaymentVO.class, userId);
        return null != response ? response.getBody() : null;
    }

    @Transactional
    public List<PaymentInformation> getAllPaymentDetails(final CaseDocumentsDataQuery caseDocumentDataQuery) {

        final String getPaymentUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                "GET_ALL_PAYMENT_DETAILS_URL");
        validateRequest(getPaymentUrl, "Get All Payments Detail URL is empty");
        final String userName = ptabBusinessUtils.getLoggedInUserId();

        final String url = externalServiceUriGenerator.getCaseDocumentDataQueryUrl(caseDocumentDataQuery, getPaymentUrl);
        ResponseEntity<String> response = null;
        response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, String.class, userName);
        List<PaymentInformation> paymentDetails = null;
        if (response.getStatusCode().is2xxSuccessful()) {
            final ObjectMapper mapper = new ObjectMapper();
            try {
                paymentDetails = mapper.readValue(response.getBody(), new TypeReference<List<PaymentInformation>>() {
                });
                String userPartyType = externalUserService
                        .getPrcdPartyGroupType(caseDocumentDataQuery.getProceedingNumber());
                Predicate<? super PaymentInformation> predicate = paymentInfo -> {
                    String party = StringUtils.replace(paymentInfo.getParty(), "\\s", "");
                    return StringUtils.equalsIgnoreCase(party, userPartyType);
                };
                return paymentDetails.stream().filter(predicate).collect(Collectors.toList());
            } catch (JsonProcessingException e) {
                log.error("Error ", e);
            }
        }
        return paymentDetails;
    }

    private TransactionAuthorizationDetailEntity saveTransactionAuthTables(final AdhocPayment adhocPaymentOne) {
        final TransactionAuthorizationDetailEntity authorizationDetailEntity = new TransactionAuthorizationDetailEntity();
        authorizationDetailEntity.setTransactionTokenId(authorizationDetailRepository.getNextId());
        final String authToken = getTokenFromHeader();
        if (StringUtils.isNotBlank(authToken)) {
            authorizationDetailEntity.setServerAuthorizationTokenText(authToken);

            final ResponseEntity<String> responseStr = verifyAuthToken(authToken);
            String userId = null;
            if (null != responseStr && responseStr.getStatusCode().is2xxSuccessful()) {
                log.error("Auth token verification successful");
                userId = getUserIdFromAuthToken(responseStr, userId);
                authorizationDetailEntity.setUserId(userId);
            }
        }
        authorizationDetailEntity.setTransactionTimestamp(new Date());
        authorizationDetailRepository.save(authorizationDetailEntity);

        log.error("save payment transaction details :" + authorizationDetailEntity.getTransactionTokenId());
        if (null != adhocPaymentOne) {
            adhocPaymentOne
                    .setTransactionId(RC4CipherEntity.encrypt(authorizationDetailEntity.getTransactionTokenId().toString()));
        }
        return authorizationDetailEntity;
    }

    private String callProceedingSubmissionAfterAuthVerf(final TransactionAuthorizationDetailEntity authorizationDetailEntity,
            final String authToken, final long proceedingId, final long paymentId, final String receiptId,
            String receiptHtmlResponse) {

        final ResponseEntity<String> responseStr = verifyAuthToken(authToken);
        String userId = null;
        if (null != responseStr && responseStr.getStatusCode().is2xxSuccessful()) {
            log.error("Auth token verification successful");
            userId = getUserIdFromAuthToken(responseStr, userId);
        } else {
            userId = authorizationDetailEntity.getUserId();
        }
        final String prcdCompletePaymentUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_COMPLETE_PAYMENT_URL);

        // String prcdCompletePaymentUrl = "http://localhost:8081/petitions/%1$d/payments/%2$d/complete";

        notFoundIfNull(prcdCompletePaymentUrl, PROCEEDING_COMPLETE_PAYMENT_URL);
        final String prcdCompletePaymentFrmtUrl = String.format(prcdCompletePaymentUrl, proceedingId, paymentId);
        final HttpHeaders headers = getHttpHeaders(userId);
        final ResponseEntity<PaymentVO> paymentResponse = restServiceClient
                .invokeWebService(prcdCompletePaymentFrmtUrl + "/" + receiptId, null, HttpMethod.POST, PaymentVO.class, headers);

        final PaymentVO paymentVO = paymentResponse.getBody();
        if (paymentResponse.getStatusCode().is2xxSuccessful() && null != paymentVO) {
            receiptHtmlResponse = paymentVO.getReceiptHtmlResponse();
            log.error("The HTML response value is {} ", receiptHtmlResponse);
            log.error("The  payment return code value is {} ", paymentVO.getReturnCode());
            callProceedingSubm(paymentVO, proceedingId, paymentId, receiptId, headers, paymentResponse);
        }
        return receiptHtmlResponse;

    }

    private String getUserIdFromAuthToken(final ResponseEntity<String> responseStr, String userId) {
        final String getResponse = responseStr.getBody();
        final ObjectMapper mapper = new ObjectMapper();
        try {
            final OidcAuthTokenVerificationResponse obj = mapper.readValue(getResponse, OidcAuthTokenVerificationResponse.class);
            if (null != obj) {
                userId = obj.getUserLogin();
            }
        } catch (final JsonProcessingException e) {
            log.error("Exception : " + e);
        }
        return userId;
    }

    private void callProceedingSubm(final PaymentVO paymentVO, final long proceedingId, final long paymentId,
            final String receiptId, final HttpHeaders headers, final ResponseEntity<PaymentVO> paymentResponse) {
        if (StringUtils.equals(paymentVO.getReturnCode(), SUCCESSFUL_PAYMENT_RETURN_CODE)) {
            final String submissionUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                    PROCEEDING_SUBMISSION_URL);
            try {
                final ResponseEntity<String> submissionResponse = restServiceClient.invokeWebServiceAndCatchError(
                        String.format(submissionUrl, proceedingId, paymentId) + "/" + receiptId, null, HttpMethod.POST,
                        String.class, headers);
                if (paymentResponse.getStatusCode().is2xxSuccessful()) {
                    log.error("Documents submitted successfully");
                } else {
                    log.error("Documents failed to submit and response error code is {} ",
                            submissionResponse.getStatusCode());
                }
            } catch (final Exception ex) {
                log.error(ex.getMessage(), ex);
            }
        }
    }

    private ResponseEntity<String> verifyAuthToken(final String authToken) {
        /// verify auth token
        final String verifyAuthTokenUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(OAUTH_USERINFO, AUTH_TOKEN);
        notFoundIfNull(verifyAuthTokenUrl, AUTH_TOKEN);

        final HttpHeaders headersToVerifyAuthToken = new HttpHeaders();
        headersToVerifyAuthToken.add(HEADER_NAME_ACCEPT, HEADER_VALUE_APPL_JSON);
        headersToVerifyAuthToken.setBearerAuth(authToken);
        ResponseEntity<String> responseStr = null;

        try {
            responseStr = restServiceClient.invokeWebService(verifyAuthTokenUrl, null, HttpMethod.GET, String.class,
                    headersToVerifyAuthToken);
        } catch (final Exception e) {
            log.error("Auth token verification unsuccessful  with error :" + e);
        }

        /*
         * final String refreshTokenUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(OIDC_REFRESH_TOKEN,
         * REFRESH_AUTH_TOKEN); notFoundIfNull(refreshTokenUrl, REFRESH_AUTH_TOKEN);
         * 
         * HttpHeaders headersToRefreshToken = new HttpHeaders();
         * 
         * headersToRefreshToken.add(HEADER_NAME_ACCEPT, HEADER_VALUE_APPL_JSON);
         * headersToVerifyAuthToken.setBasicAuth(clientId, clientSecret);
         * headersToRefreshToken.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
         * headersToRefreshToken.setCacheControl(CacheControl.noCache());
         * 
         * MultiValueMap<String, String> properties = new LinkedMultiValueMap<String, String>(); properties.add("refresh_token",
         * refreshTokenUrl); properties.add("grant_type", refreshTokenUrl); properties.add("scope", refreshTokenUrl);
         * properties.add("redirect_uri", refreshTokenUrl);
         * 
         * HttpEntity<MultiValueMap<String, String>> requestForRefreshToken = new HttpEntity<>(properties,
         * headersToRefreshToken); ResponseEntity<String> responseStrRefreshToken =
         * restServiceClient.invokeWebService(refreshTokenUrl, requestForRefreshToken, HttpMethod.POST, String.class,
         * headersToRefreshToken);
         * 
         * if (responseStrRefreshToken.getStatusCode().is2xxSuccessful()) { String resp = responseStrRefreshToken.getBody(); if
         * (StringUtils.isNotEmpty(resp)) { ObjectMapper mapper = new ObjectMapper(); try { OidcRefreshTokenResponse
         * oidcRefreshTokenResponse = mapper.readValue(resp, OidcRefreshTokenResponse.class); String authTokenFromRefresh =
         * oidcRefreshTokenResponse.getAccess_token();
         * 
         * } catch (JsonProcessingException e) { // TODO Auto-generated catch block e.printStackTrace(); } } }
         */
        // }

        return responseStr;
    }

    private String getTokenFromHeader() {
        final String authHeader = request.getHeader(AUTHORIZATION);
        if (StringUtils.isNotBlank(authHeader) && authHeader.startsWith(BEARER)) {
            log.error("auth Header:" + authHeader);
            return authHeader.substring(7);
        }
        return null;
    }

    private HttpHeaders getHttpHeaders(final String userId) {
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.add(USER_NAME_HEADER_KEY, userId);
        return headers;
    }
}
