package gov.uspto.patent.ptab.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/geo-region")
@Slf4j
public class GeoLocationInfoController {

    @Value("${geo-region.url}")
    private String serviceUrl;

    @Value("${country-geo-region.url}")
    private String countryServiceUrl;

    @Autowired
    RestServiceClient restServiceClient;

    @GetMapping(path = "/get-countriesinfo/{caseType}", produces = "application/json")
    public ResponseEntity<String> getCountriesInfo(@PathVariable("caseType") final String caseType) {
        try {
            return new ResponseEntity<>(
                    restServiceClient.callExternalServiceURL(countryServiceUrl, null, HttpMethod.GET, String.class), null,
                    HttpStatus.OK);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
    }

    @GetMapping(path = "/get-statesinfo/{caseType}/{countryCode}", produces = "application/json")
    public ResponseEntity<String> getStatesInfo(@PathVariable("caseType") final String caseType,
            @PathVariable("countryCode") final String countryCode) {
        try {
            return new ResponseEntity<>(
                    restServiceClient.callExternalServiceURL(serviceUrl + countryCode, null, HttpMethod.GET, String.class),
                    null, HttpStatus.OK);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
    }

}
