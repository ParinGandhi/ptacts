package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;

import lombok.Getter;
import lombok.Setter;

/**
 * Abstract class for Audit Entity
 * 
 * @author 2020 development team
 *
 */
@MappedSuperclass
@Setter
@Getter
public abstract class AbstractAuditEntity implements Serializable {

    private static final long serialVersionUID = 7211012952736176812L;

    @Column(name = "CREATE_TS", updatable = false)
    protected Date createTs;

    @Column(name = "CREATE_USER_ID", updatable = false)
    protected BigDecimal createUserId;

    @Column(name = "LAST_MOD_TS")
    protected Date lastModTs;

    @Column(name = "LAST_MOD_USER_ID")
    protected BigDecimal lastModUserId;

}