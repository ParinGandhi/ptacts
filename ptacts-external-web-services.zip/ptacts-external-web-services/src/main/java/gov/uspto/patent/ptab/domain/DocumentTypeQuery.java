package gov.uspto.patent.ptab.domain;

import lombok.Data;

@Data
public class DocumentTypeQuery {

    private String rehearingTypeName;
    private String motionTypeName;

}
