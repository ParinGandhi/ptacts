package gov.uspto.patent.ptab.dao;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import gov.uspto.patent.ptab.domain.DocumentTypeCustomAttributes;
import gov.uspto.patent.ptab.domain.ReferenceQuery;
import gov.uspto.patent.ptab.entities.StndDocumentType;
import gov.uspto.patent.ptab.entities.StndMotionType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.stereotype.Repository;

import gov.uspto.patent.ptab.domain.ReferenceType;
import gov.uspto.patent.ptab.entities.StndProceedingType;

/**
 * This class mainly responsible for reading data from standard tables
 * 
 * @author 2020 development team
 *
 */
@Slf4j
@Repository
public class ReferenceDAO {

    private static final String TRIAL_TYPE = "trialType";

    private static final String QRY_TRIAL_TYPES = "SELECT s FROM StndProceedingType s WHERE "
            + "s.proceedingTypeCd in :trialType and " + getEffectiveDateConditionHQL("");

    private static final String QRY_SELECT_DOCUMENT_TYPES = "SELECT d FROM StndDocumentType d WHERE "
            + getEffectiveDateConditionHQL("") + "order by d.displayName asc";

    private static final String QRY_SELECT_DOCUMENT_TYPES_BY_CATEGORY
            = "SELECT d FROM StndDocumentType d WHERE d.fkDocumentCategoryId ";

    private static final String QRY_STND_DOCUMENT_CATEGORY = "in (select "
            + "dc.documentCategoryId from StndDocumentCategory dc"
            + " where documentCategoryCd = :categoryType) ";

    private static final String QRY_SELECT_MOTION_TYPES = "SELECT m FROM StndMotionType m WHERE "
            + getEffectiveDateConditionHQL("");

    @PersistenceContext
    private EntityManager entityManager;

    private static final String getEffectiveDateConditionHQL(final String alias) {
        return getFirstHQL(alias) + getSecondHQL(alias) + getThirdHQL(alias) + getFourthHQL(alias);
    }

    private static String getFirstHQL(final String alias) {
        return "((" + (StringUtils.isNotEmpty(alias) ? (alias + ".") : "") + "beginEffectiveDt != null AND "
                + (StringUtils.isNotEmpty(alias) ? (alias + ".") : "") + "endEffectiveDt = null)";
    }

    private static String getSecondHQL(final String alias) {
        return " OR (" + (StringUtils.isNotEmpty(alias) ? (alias + ".") : "") + "beginEffectiveDt != null AND trunc("
                + (StringUtils.isNotEmpty(alias) ? (alias + ".") : "") + "beginEffectiveDt) <= trunc(current_date()) AND "
                + (StringUtils.isNotEmpty(alias) ? (alias + ".") : "") + "endEffectiveDt = null)";
    }

    private static String getThirdHQL(final String alias) {
        return " OR (" + (StringUtils.isNotEmpty(alias) ? (alias + ".") : "") + "beginEffectiveDt = null AND "
                + (StringUtils.isNotEmpty(alias) ? (alias + ".") : "") + "endEffectiveDt != null AND trunc("
                + (StringUtils.isNotEmpty(alias) ? (alias + ".") : "") + "endEffectiveDt) >= trunc(current_date()))";
    }

    private static String getFourthHQL(final String alias) {
        return " OR (trunc(current_date()) BETWEEN trunc(" + (StringUtils.isNotEmpty(alias) ? (alias + ".") : "")
                + "beginEffectiveDt) AND trunc(" + (StringUtils.isNotEmpty(alias) ? (alias + ".") : "") + "endEffectiveDt)))";
    }


    @SuppressWarnings("unchecked")
    public ReferenceType getTrialTypeDetails(final String trialType) {
        final Query query = entityManager.createQuery(QRY_TRIAL_TYPES);
        query.setParameter(TRIAL_TYPE, trialType);
        final List<StndProceedingType> stndProceedingTypeList = query.getResultList();
        ReferenceType referenceType = null;
        if (CollectionUtils.isNotEmpty(stndProceedingTypeList)) {
            referenceType = new ReferenceType();
            final StndProceedingType stndProceedingType = stndProceedingTypeList.get(0);
            referenceType.setCode(stndProceedingType.getProceedingTypeCd());
            referenceType.setDescriptionText(stndProceedingType.getProceedingTypeDescTx());
            referenceType.setIdentifier(stndProceedingType.getProceedingTypeId());
        }
        return referenceType;
    }

    /**
     * Gets the Document Types
     *
     */
    @SuppressWarnings("unchecked")
    public List<ReferenceType> getDocumentTypes(ReferenceQuery referenceQuery) {
        Query query;
        if(referenceQuery.getCategoryType()!=null){
            query = entityManager.createQuery(QRY_SELECT_DOCUMENT_TYPES_BY_CATEGORY + QRY_STND_DOCUMENT_CATEGORY);
            query.setParameter("categoryType", referenceQuery.getCategoryType());
        }else {
            query = entityManager.createQuery(QRY_SELECT_DOCUMENT_TYPES);
        }
        return  getDocumentTypeDetails(query.getResultList());

    }

    /**
     * Gets the Motion Types
     *
     * @return map of ReferenceTypeVO
     */
    @SuppressWarnings("unchecked")
    public List<ReferenceType> getMotionTypes() {
        final Query query = entityManager.createQuery(QRY_SELECT_MOTION_TYPES);
        return getAllMotionTypes(query.getResultList());
    }

    /**
     * This method convert StndDocumentType into ReferenceType object
     *
     * @param stndDocumentTypeList - document types
     */
    public static List<ReferenceType> getDocumentTypeDetails(final List<StndDocumentType> stndDocumentTypeList) {
        final List<ReferenceType> referenceTypes = new ArrayList<>();
        for (final StndDocumentType stndDocumentType : stndDocumentTypeList) {
            final ReferenceType referenceType = new ReferenceType();
            referenceType.setCode(stndDocumentType.getDocumentTypeCd());
            referenceType.setDescriptionText(stndDocumentType.getDocumentTypeNm());
            referenceType.setIdentifier(stndDocumentType.getDocumentTypeId());
            referenceType.setDisplayNameText(stndDocumentType.getDisplayName());
            referenceType.setSignificantIndicator(stndDocumentType.getSignificantIndicator());
            referenceType.setJoinderCheckIndicator(stndDocumentType.getJoinderCheckInd());
            mapClobCustomAttributesColumn(stndDocumentType, referenceType);
            referenceTypes.add(referenceType);
        }
        return referenceTypes;
    }

    private static void mapClobCustomAttributesColumn(final StndDocumentType stndDocumentType,
                                                      final ReferenceType referenceType) {
        if (stndDocumentType.getCustomAttributes() != null) {
            final String customAttrJson = stndDocumentType.getCustomAttributes();
            final ObjectMapper mapper = new ObjectMapper();
            try {
                final DocumentTypeCustomAttributes customAttrs = mapper.readValue(customAttrJson,
                        DocumentTypeCustomAttributes.class);
                referenceType.setDocumentTypeCustomAttributes(customAttrs);
            } catch (final Exception jse) {
                log.error(jse.getMessage(), jse);
            }
        }
    }

    /**
     * This method convert StndMotionType into ReferenceType object
     *
     * @param stndMotionTypeList - proxy role types
     */
    public static List<ReferenceType> getAllMotionTypes(final List<StndMotionType> stndMotionTypeList) {
        final List<ReferenceType> referenceTypes = new ArrayList<>();

        for (final StndMotionType stndMotionType : stndMotionTypeList) {
            final ReferenceType referenceType = new ReferenceType();
            referenceType.setCode(stndMotionType.getMotionTypeNm());
            referenceType.setDescriptionText(stndMotionType.getDescriptionTx());
            referenceType.setIdentifier(stndMotionType.getMotionTypeId());
            referenceTypes.add(referenceType);
        }

        return referenceTypes;

    }
}
