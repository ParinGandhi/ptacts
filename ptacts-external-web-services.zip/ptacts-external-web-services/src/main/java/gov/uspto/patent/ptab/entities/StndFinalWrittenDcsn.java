package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the STND_FSM_TYPE_STATE database table.
 * 
 */
@Entity
@Table(name = "STND_FINAL_WRITTEN_DCSN")
@NamedQuery(name = "StndFinalWrittenDcsn.findAll", query = "SELECT s FROM StndFinalWrittenDcsn s")
@Getter
@Setter
@RequiredArgsConstructor
public class StndFinalWrittenDcsn implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "FINAL_WRITTEN_DCSN_ID")
    private long finalWrittenDcsnId;

    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Column(name = "DESCRIPTION_TX")
    private String descriptionTx;

    @Column(name = "DISPLAY_ORDER_SEQUENCE_NO")
    private BigDecimal displayOrderSequenceNo;

    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "FINAL_WRITTEN_DCSN_NM")
    private String finalWrittenDcsnNm;

    @OneToMany(mappedBy = "stndFinalWrittenDcsn")
    private List<PrcdngClmStatyGround> prcdngClmStatyGrounds;

    @OneToMany(mappedBy = "stndFinalWrittenDcsn")
    private List<ProceedingClaim> proceedingClaims;

}