package gov.uspto.patent.ptab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.context.annotation.PropertySource;

/**
 * The main entry point and configuration of the application.The Spring ApplicationContext configuration is triggered by
 * the @SpringBootApplication annotation and automatically pulls in all spring elements in this package and its sub packages.
 *
 * @author 2020 Development Team
 *
 */

@SpringBootApplication(exclude = { HibernateJpaAutoConfiguration.class })
@PropertySource("classpath:application.properties")
@PropertySource("classpath:ptab_application_messages.properties")
public class PTABE2EApplication {

    /**
     * The main() method allows you to start the application from your IDE by "running" this class in addition to the traditional
     * JBoss/WAR approach.
     *
     * 
     * @param args - arguments
     */
    public static void main(final String[] args) {
        SpringApplication.run(PTABE2EApplication.class, args);
    }

}
