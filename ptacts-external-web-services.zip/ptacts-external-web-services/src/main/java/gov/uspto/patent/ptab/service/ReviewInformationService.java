package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import java.util.List;
import java.util.stream.Collectors;

import jakarta.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.ReviewInformation;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

/**
 * Service class for payments
 *
 * @author 2020 development team
 *
 */
@Slf4j
@Service
public class ReviewInformationService {

    private static final String POSTING_REFERENCE_TEXT_QUERY_PARAM = "?postingReferenceText=";
    private static final String REVIEW_INFORMATION_URL = "REVIEW_INFORMATION_URL";
    private static final String SYSTEM_USER = "SYSTEM_USER";
    private static final String PTAB_CASE_INIT = "PTAB_CASE_INIT";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private ExternalUserService externalUserService;

    /**
     * Method used to get the review info
     *
     * @param postingReferenceText -posting reference text
     * @throws JsonProcessingException
     * @throws JsonMappingException
     *
     */
    @Transactional
    public List<ReviewInformation> getReviewInformation(String postingReferenceText)
            throws JsonProcessingException {

        final String proceddingPartyType = externalUserService.getPrcdPartyGroupType(postingReferenceText);
        final String referenceDataUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                REVIEW_INFORMATION_URL);
        notFoundIfNull(referenceDataUrl, "review information Url");
        final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(systemUserName, "system user name");
        ResponseEntity<String> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(
                    referenceDataUrl + POSTING_REFERENCE_TEXT_QUERY_PARAM + postingReferenceText, null, HttpMethod.GET,
                    String.class, systemUserName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getMessage()));
        }
        final List<ReviewInformation> list = new ObjectMapper().readValue(response.getBody(),
                new TypeReference<List<ReviewInformation>>() {
                });
        final List<ReviewInformation> reviewInfoList = list.stream()
                .filter(jsonode -> StringUtils.equalsIgnoreCase(proceddingPartyType, jsonode.getParty()))
                .collect(Collectors.toList());
        for (final ReviewInformation reviewInformation : reviewInfoList) {
            if (StringUtils.equals(StringUtils.trim(reviewInformation.getParty()), "PATENTOWNER")) {
                reviewInformation.setParty("Patent Owner");
            }
            if (StringUtils.equals(StringUtils.trim(reviewInformation.getParty()), "PETITIONER")) {
                reviewInformation.setParty("Petitioner");
            }
        }
        return reviewInfoList;
    }

}
