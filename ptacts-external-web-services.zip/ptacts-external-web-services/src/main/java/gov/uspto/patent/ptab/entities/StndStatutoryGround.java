
package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the STND_STATUTORY_GROUND database table.
 * 
 */
@Entity
@Table(name = "STND_STATUTORY_GROUND")
@NamedQuery(name = "StndStatutoryGround.findAll", query = "SELECT s FROM StndStatutoryGround s")
@Data
@EqualsAndHashCode(callSuper = false)
public class StndStatutoryGround extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "STATUTORY_GROUND_ID")
    private long statutoryGroundId;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Column(name = "DISPLAY_ORDER_SEQUENCE_NO")
    private BigDecimal displayOrderSequenceNo;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    @Column(name = "STATUTORY_GROUND_CD")
    private String statutoryGroundCd;

    @Column(name = "DESCRIPTION_TX")
    private String descriptionTx;

    // bi-directional many-to-one association to StndPrcdngCtStatyGround
    @OneToMany(mappedBy = "stndStatutoryGround")
    private List<StndPrcdngCtStatyGround> stndPrcdngCtStatyGrounds;

}