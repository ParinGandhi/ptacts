package gov.uspto.patent.ptab.controller;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fasterxml.jackson.databind.JsonNode;
 import gov.uspto.patent.ptab.domain.FeeCalculationQuery;
import gov.uspto.patent.ptab.service.FeeCalculationService;

@RestController
@RequestMapping("/feeCalculations")
public class FeeCalculationController {

    @Autowired
    private FeeCalculationService feeCalculationService;

    @GetMapping
    public JsonNode getFeeCalculationDetails(@Valid @NotNull final FeeCalculationQuery feeCalculationQuery) {

        return feeCalculationService.getFeeCalculationDetails(feeCalculationQuery);

    }

}
