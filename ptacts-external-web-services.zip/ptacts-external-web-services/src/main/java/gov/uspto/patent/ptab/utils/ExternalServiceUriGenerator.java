package gov.uspto.patent.ptab.utils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.web.util.UriUtils;

import gov.uspto.patent.ptab.common.opsg.domain.ApplicationIdentifierQuery;
import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.domain.DocumentQuery;
import gov.uspto.patent.ptab.domain.DocumentTypeQuery;
import gov.uspto.patent.ptab.domain.DocumentsQuery;
import gov.uspto.patent.ptab.domain.FeeCalculationQuery;
import gov.uspto.patent.ptab.domain.LoginQuery;
import gov.uspto.patent.ptab.domain.PetitionQuery;
import gov.uspto.patent.ptab.domain.ProceedingPartyQuery;
import gov.uspto.patent.ptab.domain.ProceedingQuery;
import gov.uspto.patent.ptab.domain.ReferenceQuery;
import gov.uspto.patent.ptab.domain.TrialsBase;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;

/**
 * External Service UriGenerator class to retrieve and build ServiceURL
 *
 * @author 2020 development team
 */
@Slf4j
@Component
public class ExternalServiceUriGenerator {

    private static final String INCLUDE_PO_STAFF_DETAILS = "includePoStaffDetails";
    private static final String INCLUDE_PETITIONER_STAFF_DETAILS = "includePetitionerStaffDetails";
    private static final String PROCEEDING_NUMBER2 = "proceedingNumber";
    private static final String PATENT_NUM = "patentNum";
    private static final String APPLICATION_NUMBER2 = "applicationNumber";
    private static final String PETITION_IDENTIFIER = "petitionIdentifier";
    private static final String PROCEEDING_NUMBER_TEXT = "proceedingNumberText";
    private static final String UTF_8 = "UTF-8";
    private static final String MOTION_TYPE_NAME = "motionTypeName";
    private static final String REHEARING_TYPE_NAME = "rehearingTypeName";
    private static final String CASE_NUMBER = "caseNumber";
    private static final String FILE_NAME = "fileName";
    private static final String SEARCH_TYPE = "searchType";
    private static final String PROCEEDING_TYPE = "proceedingType";
    private static final String PROCEEDING_SUPPLEMENTARY_ID = "proceedingSupplementaryId";
    private static final String PROCEEDING_CORE_ID = "proceedingCoreId";
    private static final String PROCEEDING_PARTY_GROUP_ID = "proceedingPartyGroupId";
    private static final String DOC_TYPE = "docType";
    private static final String TYPE_ID = "typeId";
    private static final String CASE_TYPE = "caseType";
    private static final String CASE_STATUS = "caseStatus";
    private static final String STATUS = "status";
    private static final String PROCEEDING_PARTY_IDENTIFIER = "proceedingPartyIdentifier";
    private static final String REGISTRATION_NUMBER_TEXT = "registrationNumberText";
    private static final String ARTIFACT_ID = "artifactId";
    private static final String EMAIL_ADDRESS_TEXT = "emailAddressText";
    private static final String PATENT_NUMBER = "patentNumber";
    private static final String APPLICATION_NUMBER = APPLICATION_NUMBER2;
    private static final String IS_PUBLIC = "isPublic";
    private static final String TYPE_CODE = "typeCode";
    private static final String EVENT = "event";
    private static final String IDENTIFIERS = "identifiers";
    private static final String RECIPIENT_TYPE = "recipientType";
    private static final String PROCEEDING_NUMBER = PROCEEDING_NUMBER2;
    private static final String NOTIFICATION_ID = "notificationId";
    private static final String CATEGORY_TYPE = "categoryType";
    private static final String TRIAL_TYPE = "trialType";
    private static final String REGISTRATION_NUMBER = "registrationNumber";
    private static final String EMAIL = "email";
    private static final String IS_MOTION_FEE = "isMotionFeeCalculation";
    private static final String EXCLUDE_ARTIFACTS = "excludeArtifacts";

    /**
     * This method constructs reference data URL.
     *
     * @param referenceDataQuery - Reference data query object to construct query.
     * @param serviceUrl - reference data URL.
     *
     */
    public String constructReferenceDataUrl(final ReferenceQuery referenceDataQuery, final String serviceUrl) {

        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(serviceUrl);

        buildQueryParam(urlEncodeQuery(referenceDataQuery.getCategoryType()), CATEGORY_TYPE, builder);
        buildQueryParam(urlEncodeQuery(referenceDataQuery.getTrialType()), TRIAL_TYPE, builder);
        buildQueryParam(urlEncodeQuery(referenceDataQuery.getNotificationId()), NOTIFICATION_ID, builder);
        buildQueryParam(urlEncodeQuery(referenceDataQuery.getProceedingNumber()), PROCEEDING_NUMBER, builder);
        buildQueryParam(urlEncodeQuery(referenceDataQuery.getRecipientType()), RECIPIENT_TYPE, builder);
        buildQueryParam(urlEncodeQuery(referenceDataQuery.getTypeCode()), TYPE_CODE, builder);
        builder.queryParam(IS_PUBLIC, referenceDataQuery.getIsPublic());
        buildQueryParam(urlEncodeQuery(referenceDataQuery.getEvent()), EVENT, builder);
        buildQueryParam(urlEncodeQuery(referenceDataQuery.getIdentifiers()), IDENTIFIERS, builder);

        return builder.buildAndExpand().toString();
    }

    /**
     * This method constructs ptab state role URL.
     * 
     * @param caseNumber
     * @param userIdentifier
     * @param ptabStateRoleUrl
     * @return
     */
    public String constructPtabStateRoleUrl(final String caseNumber, final String ptabStateRoleUrl) {

        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(ptabStateRoleUrl);

        buildQueryParam(urlEncodeQuery(caseNumber), CASE_NUMBER, builder);

        return builder.buildAndExpand().toString();
    }

    /**
     * This method constructs ptab state role URL.
     * 
     * @param caseNumber
     * @param userIdentifier
     * @param ptabStateRoleUrl
     * @return
     */
    public String constructGetDocumentUrl(final DocumentsQuery documentsQuery, final String getDocumentUrl) {

        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(getDocumentUrl);

        buildQueryParam(urlEncodeQuery(documentsQuery.getFileName()), FILE_NAME, builder);

        return builder.buildAndExpand().toString();
    }

    private String urlEncodeQuery(final String input) {
        if (StringUtils.isNotEmpty(input)) {
            return UriUtils.encodeQuery(input, StandardCharsets.UTF_8);
        } else
            return input;
    }

    /**
     * Method used to add query parameter to the query builder
     */
    private void buildQueryParam(final String identifierQuery, final String constantParam,
            final UriComponentsBuilder builder) {
        if (StringUtils.isNotBlank(identifierQuery)) {
            builder.queryParam(constantParam, identifierQuery);
        }
    }

    /**
     * Method used to get the application info URL
     *
     * @param applicationIdentifierQuery - object containing the query parameter information
     * @param serviceUrl - service URL
     *
     */
    public String applicationInfoUrl(final ApplicationIdentifierQuery applicationIdentifierQuery,
            final String serviceUrl) {

        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(serviceUrl);
        buildQueryParam(applicationIdentifierQuery.getApplicationNumber(), APPLICATION_NUMBER, builder);
        buildQueryParam(applicationIdentifierQuery.getPatentNumber(), PATENT_NUMBER, builder);
        return builder.buildAndExpand().toString();
    }

    /**
     * Method used to get the user details URL
     *
     * @param loginQuery - object containing the query parameter information
     * @param serviceUrl - service URL
     *
     */
    public String userDetailsUrl(final LoginQuery loginQuery, final String serviceUrl) {

        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(serviceUrl);
        buildQueryParam(loginQuery.getEmailAddressText(), EMAIL_ADDRESS_TEXT, builder);
        return builder.buildAndExpand().toString();
    }

    /**
     * Method used to get the download document URL
     *
     * @param documentQuery - object containing the query parameter information
     * @param serviceUrl - service URL
     *
     */
    public String getDownloadDocumentUrl(final DocumentQuery documentQuery, final String serviceUrl) {

        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(serviceUrl);
        if (null != documentQuery.getArtifactId()) {
            builder.queryParam(ARTIFACT_ID, documentQuery.getArtifactId());
        }

        return builder.buildAndExpand().toString();
    }

    /**
     * Method used to get the proceeding party delete URL
     *
     * @param documentQuery - object containing the query parameter information
     * @param serviceUrl - service URL
     *
     */
    public String getProceedingPartyDeleteUrl(final ProceedingPartyQuery proceedingPartyQuery, final String serviceUrl) {

        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(serviceUrl);
        buildQueryParam(proceedingPartyQuery.getEmailAddressText(), EMAIL_ADDRESS_TEXT, builder);
        buildQueryParam(proceedingPartyQuery.getProceedingNumber(), PROCEEDING_NUMBER, builder);
        buildQueryParam(proceedingPartyQuery.getRegistrationNumberText(), REGISTRATION_NUMBER_TEXT, builder);
        if (null != proceedingPartyQuery.getProceedingPartyIdentifier()) {
            builder.queryParam(PROCEEDING_PARTY_IDENTIFIER, proceedingPartyQuery.getProceedingPartyIdentifier());
        }
        return builder.buildAndExpand().toString();
    }

    /**
     * Method used to get the case document query URL
     *
     * @param caseDocumentsDataQuery - object containing the query parameter information
     * @param serviceUrl - service URL
     *
     */
    public String getCaseDocumentDataQueryUrl(final CaseDocumentsDataQuery caseDocumentsDataQuery,
            final String serviceUrl) {

        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(serviceUrl);
        buildQueryParam(caseDocumentsDataQuery.getCaseStatus(), CASE_STATUS, builder);
        if (null != caseDocumentsDataQuery.getCaseType()) {
            buildQueryParam(caseDocumentsDataQuery.getCaseType(), CASE_TYPE, builder);
        }
        if (null != caseDocumentsDataQuery.getDocType()) {
            buildQueryParam(caseDocumentsDataQuery.getDocType(), DOC_TYPE, builder);
        }
        if (null != caseDocumentsDataQuery.getTypeId()) {
            builder.queryParam(TYPE_ID, caseDocumentsDataQuery.getTypeId());
        }
        buildQueryParam(caseDocumentsDataQuery.getProceedingNumber(), PROCEEDING_NUMBER, builder);

        try {
            buildQueryParam(StringUtils.isNotBlank(caseDocumentsDataQuery.getStatus())
                    ? URLEncoder.encode(caseDocumentsDataQuery.getStatus(), UTF_8)
                    : null, STATUS, builder);
        } catch (final UnsupportedEncodingException e) {
            log.error(e.getMessage(), e);
        }
        if (null != caseDocumentsDataQuery.getProceedingPartyGroupId()) {
            builder.queryParam(PROCEEDING_PARTY_GROUP_ID, caseDocumentsDataQuery.getProceedingPartyGroupId());
        }
        if (caseDocumentsDataQuery.isExcludeArtifacts()) {
            builder.queryParam(EXCLUDE_ARTIFACTS, caseDocumentsDataQuery.isExcludeArtifacts());
        }
        if (caseDocumentsDataQuery.isIncludePetitionerStaffDetails()) {
            builder.queryParam(INCLUDE_PETITIONER_STAFF_DETAILS, caseDocumentsDataQuery.isIncludePetitionerStaffDetails());
        }
        if (caseDocumentsDataQuery.isIncludePoStaffDetails()) {
            builder.queryParam(INCLUDE_PO_STAFF_DETAILS, caseDocumentsDataQuery.isIncludePoStaffDetails());
        }
        return builder.buildAndExpand().toString();
    }

    /**
     * Method used to get the case viewer details URL
     *
     * @param trialsbase - object containing the query parameter information
     * @param serviceUrl - service URL
     *
     */
    public String getCaseViewerDetailsUrl(final TrialsBase trialsbase, final String serviceUrl) {

        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(serviceUrl);
        buildQueryParam(trialsbase.getProceedingCoreId(), PROCEEDING_CORE_ID, builder);
        buildQueryParam(trialsbase.getProceedingSupplementaryId(), PROCEEDING_SUPPLEMENTARY_ID, builder);
        buildQueryParam(trialsbase.getProceedingType(), PROCEEDING_TYPE, builder);

        return builder.buildAndExpand().toString();
    }

    /**
     * Method used to get case number search URL
     *
     * @param searchType - search type
     * @param caseNumber - case number
     * @param caseNumberSearchUrl - case number search URL
     *
     */
    public String getCaseNumberSearchUrl(final String searchType, @Valid @NotNull final String caseNumber,
            final String caseNumberSearchUrl) {
        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(caseNumberSearchUrl);
        buildQueryParam(searchType, SEARCH_TYPE, builder);
        buildQueryParam(caseNumber, CASE_NUMBER, builder);

        return builder.buildAndExpand().toString();
    }

    public String getJoinderCaseUrl(@Valid @NotNull final String caseNumber, final String joinderUrl) {
        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(joinderUrl);
        buildQueryParam(caseNumber, CASE_NUMBER, builder);
        return builder.buildAndExpand().toString();
    }

    /**
     * Method used to get case number search URL
     *
     * @param searchType - search type
     * @param caseNumber - case number
     * @param caseNumberSearchUrl - case number search URL
     *
     */
    public String getCodeReferenceTypesUrl(final String typeCode, final String codeReferenceTypesUrl) {
        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(codeReferenceTypesUrl);
        buildQueryParam(typeCode, TYPE_CODE, builder);

        return builder.buildAndExpand().toString();
    }

    /**
     * Method used to construct document types url
     *
     * @param documentTypeQuery -query object
     * @param documentTypesUrl -url
     *
     */
    public String constructDocumentTypesUrl(final DocumentTypeQuery documentTypeQuery, final String documentTypesUrl) {
        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(documentTypesUrl);
        try {
            buildQueryParam(StringUtils.isNotBlank(documentTypeQuery.getMotionTypeName())
                    ? URLEncoder.encode(documentTypeQuery.getMotionTypeName(), UTF_8)
                    : null, MOTION_TYPE_NAME, builder);
        } catch (final UnsupportedEncodingException e) {
            log.error(e.getMessage(), e);
        }
        try {
            buildQueryParam(StringUtils.isNotBlank(documentTypeQuery.getRehearingTypeName())
                    ? URLEncoder.encode(documentTypeQuery.getRehearingTypeName(), UTF_8)
                    : null, REHEARING_TYPE_NAME, builder);
        } catch (final UnsupportedEncodingException e) {
            log.error(e.getMessage(), e);
        }

        return builder.buildAndExpand().toString();
    }

    /**
     * Method used to get petitions details URL
     *
     * @param petitionQuery
     * @param petitionsUrl
     * @return
     */
    public String getPetitonDetailsUrl(final PetitionQuery petitionQuery, final String petitionsUrl) {

        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(petitionsUrl);

        try {
            buildQueryParam(StringUtils.isNotBlank(petitionQuery.getProceedingNumberText())
                    ? URLEncoder.encode(petitionQuery.getProceedingNumberText(), UTF_8)
                    : null, PROCEEDING_NUMBER_TEXT, builder);
        } catch (final UnsupportedEncodingException e) {
            log.error(e.getMessage(), e);
        }
        if (null != petitionQuery.getPetitionIdentifier()) {
            builder.queryParam(PETITION_IDENTIFIER, petitionQuery.getPetitionIdentifier());
        }

        return builder.buildAndExpand().toString();

    }

    public String getProceedingQuery(@Valid @NotNull final ProceedingQuery proceedingQuery,
            final String proceedingDetailsUrl) {
        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(proceedingDetailsUrl);

        try {
            buildQueryParam(StringUtils.isNotBlank(proceedingQuery.getApplicationNumber())
                    ? URLEncoder.encode(proceedingQuery.getApplicationNumber(), UTF_8)
                    : null, APPLICATION_NUMBER2, builder);
        } catch (final UnsupportedEncodingException e) {
            log.error(e.getMessage(), e);
        }

        try {
            buildQueryParam(StringUtils.isNotBlank(proceedingQuery.getPatentNum())
                    ? URLEncoder.encode(proceedingQuery.getPatentNum(), UTF_8)
                    : null, PATENT_NUM, builder);
        } catch (final UnsupportedEncodingException e) {
            log.error(e.getMessage(), e);
        }
        try {
            buildQueryParam(StringUtils.isNotBlank(proceedingQuery.getProceedingNumber())
                    ? URLEncoder.encode(proceedingQuery.getProceedingNumber(), UTF_8)
                    : null, PROCEEDING_NUMBER2, builder);
        } catch (final UnsupportedEncodingException e) {
            log.error(e.getMessage(), e);
        }

        return builder.buildAndExpand().toString();
    }

    public String getProceedingPartyDetailsUrl(final String caseType, final String registrationNumber, final String email,
            final String proceedingPartyDetailsUrl) {
        final UriComponentsBuilder builder = UriComponentsBuilder
                .fromUriString(proceedingPartyDetailsUrl + "/counsels/TRIALS");
        buildQueryParam(registrationNumber, REGISTRATION_NUMBER, builder);
        buildQueryParam(email, EMAIL, builder);

        return builder.buildAndExpand().toString();
    }

    public String getFeeCalculationQuery(final FeeCalculationQuery feeCalculationQuery, final String feeCalculationUrl) {
        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(feeCalculationUrl);
        buildQueryParam(feeCalculationQuery.getProceedingNumber(), PROCEEDING_NUMBER2, builder);
        buildQueryParam(feeCalculationQuery.getIsMotionFeeCalculation().toString(), IS_MOTION_FEE, builder);
        return builder.buildAndExpand().toString();
    }

    public String getCommonPetitionsUrl(final PetitionQuery petitionquery, final String petitionUrl) {
        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(petitionUrl);
        buildQueryParam(petitionquery.getProceedingNumberText(), PROCEEDING_NUMBER_TEXT, builder);
        return builder.buildAndExpand().toString();
    }

    public String getQualitativeQuestionsWithProceedingNumberUrl(final String proceedingNumber,
            final String QualitativeQuestionsUrl) {
        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(QualitativeQuestionsUrl);
        buildQueryParam(proceedingNumber, PROCEEDING_NUMBER2, builder);
        return builder.buildAndExpand().toString();
    }
}
