package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the STND_DOCUMENT_TYPE_ROLE database table.
 * 
 */
@Entity
@Table(name = "STND_DOCUMENT_TYPE_ROLE")
@NamedQuery(name = "StndDocumentTypeRole.findAll", query = "SELECT s FROM StndDocumentTypeRole s")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StndDocumentTypeRole extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "DOCUMENT_TYPE_ROLE_ID")
    private long documentTypeRoleId;

    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Column(name = "DESCRIPTION_TX")
    private String descriptionTx;

    @Column(name = "DISPLAY_ORDER_SEQUENCE_NO")
    private BigDecimal displayOrderSequenceNo;

    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @ManyToOne
    @JoinColumn(name = "FK_DOCUMENT_TYPE_ID")
    private StndDocumentType stndDocumentType;

}