package gov.uspto.patent.ptab.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DecisionOutcomeGroupType {

    private List<DecisionOutComeTypes> decisionOutComeTypes;
}
