package gov.uspto.patent.ptab.entities;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the EXTERNAL_USER database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = "ORGANIZATION_PARTY")
public class OrganizationPartyEntity extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "FK_PARTY_ID")
    private Long fkPartyId;

    @Column(name = "ORGANIZATION_NM")
    private String organizationNm;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo;

    @OneToOne
    @JoinColumn(name = "FK_PARTY_ID", referencedColumnName = "PARTY_ID", insertable = false, updatable = false)
    private Party party;

}