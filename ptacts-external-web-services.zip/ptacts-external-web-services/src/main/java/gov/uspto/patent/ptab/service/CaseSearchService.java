package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

//import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.CaseSearchRequest;
import gov.uspto.patent.ptab.domain.CaseSearchResponse;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.PTABException;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

/**
 * This class is used for case search
 *
 * @author 2020 development team
 *
 */
@Component
@Slf4j
public class CaseSearchService {

    private static final String USER_ID = "User Id";
    private static final String CASE_SEARCH_URL = "CASE_SEARCH_URL";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    private static final String SYSTEM_USER = "SYSTEM_USER";
    private static final String PTAB_CASE_INIT = "PTAB_CASE_INIT";

    private static final String HEADER_VALUE_APPL_JSON = "application/json;charset=UTF-8";
    private static final String HEADER_NAME_ACCEPT = "Accept";
    private static final String USER_NAME_HEADER_KEY = "user-name";

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private HttpServletRequest httpServletRequest;

    @Autowired
    private RestTemplate restTemplate;

    @Transactional
    public List<CaseSearchResponse> getSearchInfo(@Valid final CaseSearchRequest searchRequest, final boolean isPublicAccess)
            throws JsonProcessingException {
        List<CaseSearchResponse> caseSearchResponseList = null;
        final String caseSearchUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL, CASE_SEARCH_URL);
        notFoundIfNull(caseSearchUrl, "case search Url");
        String userIdentifier = null;
        if (!isPublicAccess) {
            userIdentifier = getUserId();
        } else {
            userIdentifier = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
            notFoundIfNull(userIdentifier, "system user name");
        }
        try {
            searchRequest.setIsExternalUser(true);

            final HttpHeaders headers = new HttpHeaders();
            headers.add(HEADER_NAME_ACCEPT, HEADER_VALUE_APPL_JSON);
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.add(USER_NAME_HEADER_KEY, userIdentifier);
            final HttpEntity<CaseSearchRequest> request = new HttpEntity<>(searchRequest, headers);
            final ResponseEntity<List<CaseSearchResponse>> caseSearchResponse = restTemplate.exchange(caseSearchUrl,
                    HttpMethod.POST, request, new ParameterizedTypeReference<List<CaseSearchResponse>>() {
                    });
            if (caseSearchResponse.getStatusCode().is2xxSuccessful() && null != caseSearchResponse.getBody()) {
                caseSearchResponseList = excludeCaseSearchByStatus(caseSearchResponse.getBody());
            } else if (caseSearchResponse.getStatusCode().is4xxClientError()) {
                throw new PTABException(HttpStatus.BAD_REQUEST,
                        new ErrorPayload("Error occurred while calling the case search service"));
            }

            else if (caseSearchResponse.getStatusCode().is5xxServerError()) {
                throw new PTABException(HttpStatus.BAD_REQUEST,
                        new ErrorPayload("Internal server error occurred while calling the case search service"));
            }

        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException((HttpStatus) ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return caseSearchResponseList;
    }

    private List<CaseSearchResponse> excludeCaseSearchByStatus(final List<CaseSearchResponse> caseSearchList) {
        final String exclusionStatus = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue("CASE_SEARCH",
                "CASE_SEARCH_EXCLUSION_STATUS");
        final List<String> exclusionList = Arrays.asList(exclusionStatus.split(","));
        return caseSearchList.stream().filter(caseSearch -> !exclusionList.contains(caseSearch.getStatusDisplay()))
                .collect(Collectors.toList());
    }

    private String getUserId() {
        final String userIdentifier = (String) httpServletRequest.getAttribute("valid-user");
        if (StringUtils.isEmpty(userIdentifier))
            notFoundIfNull(userIdentifier, USER_ID);
        return userIdentifier;
    }
}
