/*******************************************************************************
 * 2016, All rights reserved.
 *******************************************************************************/
package gov.uspto.patent.ptab.common.opsg.domain;

//import jakarta.validation.constraints.Size;

//import jakarta.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * Description of Email used primarily in interested parties.
 * 
 * @author 2020 Development Team
 */
@Data
@JsonInclude(Include.NON_NULL)
public class Email {

    @NotBlank(message = "email cannot be empty")
    @Size(min = 1, max = 129, message = "email should be 1 to 129 chars")
    private String emailAddressText;

    private String webAddressUri;

    private Long emailIdentifier;

    private boolean isDeleteExistingEmail;

}
