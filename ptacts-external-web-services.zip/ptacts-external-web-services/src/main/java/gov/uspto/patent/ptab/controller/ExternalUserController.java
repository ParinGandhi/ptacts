package gov.uspto.patent.ptab.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.patent.ptab.domain.FilingPartyDropDownList;
import gov.uspto.patent.ptab.service.ExternalUserService;

/**
 * Controller class ExternalUserDocketViewController
 */

@RestController
@RequestMapping("/external-user")
public class ExternalUserController {

    @Autowired
    private ExternalUserService externalUserService;

    @GetMapping(value = "/prcdingparty-group-type")
    public String getPrcdPartyGroupType(@RequestParam(required = true) String proceedingNo) {
        return externalUserService.getPrcdPartyGroupType(proceedingNo);
    }
    
    @GetMapping(value = "/dropdownList")
    public FilingPartyDropDownList getDropDownList(@RequestParam(required = true) String proceedingNo) {
        return externalUserService.getDropDownlist(proceedingNo);
    }
}