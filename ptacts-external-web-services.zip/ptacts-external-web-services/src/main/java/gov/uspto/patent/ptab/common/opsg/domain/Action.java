package gov.uspto.patent.ptab.common.opsg.domain;

import lombok.Data;

/**
 * The class is used to invoke action engine service to post transaction
 *
 * @author 2020 Development Team
 */
@Data
public class Action {

    private String applicationNumberText;
    private String postingTransactionCode;
    private Long actionDate;
    private Long mailRoomDate;
    private Audit auditData;
}
