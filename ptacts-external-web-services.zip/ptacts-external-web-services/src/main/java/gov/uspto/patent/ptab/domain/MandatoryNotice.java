package gov.uspto.patent.ptab.domain;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class MandatoryNotice {

    private String petitioner;
    private String patentOwner;
    private String mandatoryNoticeStatus;
    private String patentNumber;
    private Long partyGroupId;

    private String partyGroupType;

    private String caseNumber;

    private List<PetitionDocument> petitionDocuments;

    private Map<String, ProceedingParties> proceedingParties;

    private Audit audit;

    private String internalUserSubmitter;

}
