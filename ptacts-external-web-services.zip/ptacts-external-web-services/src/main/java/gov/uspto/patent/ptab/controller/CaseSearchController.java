package gov.uspto.patent.ptab.controller;

import java.util.List;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gov.uspto.patent.ptab.domain.CaseSearchRequest;
import gov.uspto.patent.ptab.domain.CaseSearchResponse;
import gov.uspto.patent.ptab.service.CaseSearchService;
import lombok.extern.slf4j.Slf4j;

/**
 * Controller class for Case viewer
 *
 * @author srama1
 *
 */
@Slf4j
@RestController
@RequestMapping("/case-search")
public class CaseSearchController {

    @Autowired
    private CaseSearchService caseSearchService;

    /**
     * This method is used to get getCaseSearchInfo details
     *
     * @param searchRequest
     * @return CaseSearchResponse
     * @throws JsonProcessingException
     * @throws JsonMappingException
     */
    @PostMapping
    public List<CaseSearchResponse> getCaseSearchInfo(@Valid @RequestBody final CaseSearchRequest searchRequest)
            throws JsonProcessingException {
        log.info("getSearchInfo :{}", searchRequest);
        return caseSearchService.getSearchInfo(searchRequest, false);
    }

}