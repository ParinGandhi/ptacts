package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the STND_MILESTONE_GROUP_TYPE database table.
 * 
 */
@Entity
@Table(name = "STND_MILESTONE_GROUP_TYPE")
@NamedQuery(name = "StndMilestoneGroupType.findAll", query = "SELECT s FROM StndMilestoneGroupType s")
public class StndMilestoneGroupType implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "MILESTONE_GROUP_TYPE_ID")
    private long milestoneGroupTypeId;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Column(name = "CREATE_TS")
    private Timestamp createTs;

    @Column(name = "CREATE_USER_ID")
    private BigDecimal createUserId;

    @Column(name = "DESCRIPTION_TX")
    private String descriptionTx;

    @Column(name = "DISPLAY_ORDER_SEQUENCE_NO")
    private BigDecimal displayOrderSequenceNo;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Column(name = "LAST_MOD_TS")
    private Timestamp lastModTs;

    @Column(name = "LAST_MOD_USER_ID")
    private BigDecimal lastModUserId;

    @Column(name = "MILESTONE_GROUP_TYPE_NM")
    private String milestoneGroupTypeNm;

    // bi-directional many-to-one association to StndMilestoneType
    @OneToMany(mappedBy = "stndMilestoneGroupType")
    private List<StndMilestoneType> stndMilestoneTypes;

    /**
     * Default constructor
     */
    public StndMilestoneGroupType() {
    }

    public long getMilestoneGroupTypeId() {
        return this.milestoneGroupTypeId;
    }

    public void setMilestoneGroupTypeId(long milestoneGroupTypeId) {
        this.milestoneGroupTypeId = milestoneGroupTypeId;
    }

    /**
     * get Begin Effective Date
     * 
     * @return date
     */
    public Date getBeginEffectiveDt() {
        return null != this.beginEffectiveDt ? (Date) this.beginEffectiveDt.clone() : null;
    }

    /**
     * set Begin Effective Date
     * 
     * @param beginEffectiveDt
     */
    public void setBeginEffectiveDt(Date beginEffectiveDt) {
        this.beginEffectiveDt = null != beginEffectiveDt ? new Date(beginEffectiveDt.getTime()) : null;
    }

    /**
     * get Create Time stamp
     * 
     * @return Timestamp
     */
    public Timestamp getCreateTs() {
        return null != this.createTs ? (Timestamp) this.createTs.clone() : null;
    }

    /**
     * set Create Time stamp
     * 
     * @param createTs
     */
    public void setCreateTs(Timestamp createTs) {
        this.createTs = null != createTs ? new Timestamp(createTs.getTime()) : null;
    }

    /**
     * get Create user id
     * 
     * @return BigDecimal
     */
    public BigDecimal getCreateUserId() {
        return this.createUserId;
    }

    /**
     * set Create user id
     * 
     * @param createUserId
     */
    public void setCreateUserId(BigDecimal createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * get Description Tx
     * 
     * @return String
     */
    public String getDescriptionTx() {
        return this.descriptionTx;
    }

    /**
     * set Description Tx
     * 
     * @param descriptionTx
     */
    public void setDescriptionTx(String descriptionTx) {
        this.descriptionTx = descriptionTx;
    }

    /**
     * get End Effective Date
     * 
     * @return endEffectiveDt
     */
    public Date getEndEffectiveDt() {
        return null != this.endEffectiveDt ? (Date) this.endEffectiveDt.clone() : null;
    }

    /**
     * set End Effective Date
     * 
     * @param endEffectiveDt
     */
    public void setEndEffectiveDt(Date endEffectiveDt) {
        this.endEffectiveDt = null != endEffectiveDt ? new Date(endEffectiveDt.getTime()) : null;
    }

    /**
     * get Last Modified Timestamp
     * 
     * @return lastModTs
     */
    public Timestamp getLastModTs() {
        return null != this.lastModTs ? (Timestamp) this.lastModTs.clone() : null;
    }

    /**
     * set Last Modified Timestamp
     * 
     * @param lastModTs
     */
    public void setLastModTs(Timestamp lastModTs) {
        this.lastModTs = null != lastModTs ? new Timestamp(lastModTs.getTime()) : null;
    }

    /**
     * get Last Modified User Id
     * 
     * @return lastModUserId
     */
    public BigDecimal getLastModUserId() {
        return this.lastModUserId;
    }

    /**
     * set Last Modified User Id
     * 
     * @param lastModUserId
     */
    public void setLastModUserId(BigDecimal lastModUserId) {
        this.lastModUserId = lastModUserId;
    }

    /**
     * get Display Order Sequence No
     * 
     * @return BigDecimal
     */
    public BigDecimal getDisplayOrderSequenceNo() {
        return this.displayOrderSequenceNo;
    }

    /**
     * set Display Order Sequence No
     * 
     * @param displayOrderSequenceNo
     */
    public void setDisplayOrderSequenceNo(BigDecimal displayOrderSequenceNo) {
        this.displayOrderSequenceNo = displayOrderSequenceNo;
    }

    /**
     * get Milestone Group Type Nm
     * 
     * @return String
     */
    public String getMilestoneGroupTypeNm() {
        return this.milestoneGroupTypeNm;
    }

    /**
     * set Milestone Group TypeNm
     * 
     * @param milestoneGroupTypeNm
     */
    public void setMilestoneGroupTypeNm(String milestoneGroupTypeNm) {
        this.milestoneGroupTypeNm = milestoneGroupTypeNm;
    }

    /**
     * get Stnd Milestone Types
     * 
     * @return StndMilestoneType
     */
    public List<StndMilestoneType> getStndMilestoneTypes() {
        return this.stndMilestoneTypes;
    }

    /**
     * set Stnd Milestone Types
     * 
     * @param stndMilestoneTypes
     */
    public void setStndMilestoneTypes(List<StndMilestoneType> stndMilestoneTypes) {
        this.stndMilestoneTypes = stndMilestoneTypes;
    }

    /**
     * add Standard dMile stone Type
     * 
     * @param stndMilestoneType
     * @return
     */
    public StndMilestoneType addStndMilestoneType(StndMilestoneType stndMilestoneType) {
        getStndMilestoneTypes().add(stndMilestoneType);
        stndMilestoneType.setStndMilestoneGroupType(this);

        return stndMilestoneType;
    }

    /**
     * remove Standard Mile stone Type
     * 
     * @param stndMilestoneType
     * @return
     */
    public StndMilestoneType removeStndMilestoneType(StndMilestoneType stndMilestoneType) {
        getStndMilestoneTypes().remove(stndMilestoneType);
        stndMilestoneType.setStndMilestoneGroupType(null);

        return stndMilestoneType;
    }

}
