package gov.uspto.patent.ptab.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MvcConfig implements WebMvcConfigurer {

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        final String forward = "forward:/";
        registry.addViewController("/{spring:\\w+}").setViewName(forward);
        registry.addViewController("/**/{spring:\\w+}").setViewName(forward);
        registry.addViewController("/{spring:\\w+}/**{spring:?!(\\.js|\\.css)$}").setViewName(forward);

    }

}