package gov.uspto.patent.ptab.entities;

import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the REHEARING database table.
 */
@Entity
@NamedQuery(name = "Rehearing.findAll", query = "SELECT r FROM Rehearing r")
@Getter
@Setter
@NoArgsConstructor
public class Rehearing extends AbstractAuditEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "REHEARING_SEQ")
    @SequenceGenerator(name = "REHEARING_SEQ", sequenceName = "REHEARING_SEQ", allocationSize = 1)
    @Column(name = "REHEARING_ID")
    private long rehearingId;

    @Temporal(TemporalType.DATE)
    @Column(name = "DECISION_DT")
    private Date decisionDt;

    @Temporal(TemporalType.DATE)
    @Column(name = "REQUEST_DT")
    private Date requestDt;

    @Version
    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    @Column(name = "COMMENT_TX")
    private String commentTx;

    @OneToMany(mappedBy = "rehearing")
    private List<RehearingArtfctSubmn> rehearingArtfctSubmns;

    @ManyToOne
    @JoinColumn(name = "FK_REHEARING_STATUS_ID")
    private StndRehearingStatus stndRehearingStatus;

    @ManyToOne
    @JoinColumn(name = "FK_PROCEEDING_ID")
    private ProceedingEntity proceeding;

    @ManyToOne
    @JoinColumn(name = "FK_REQUESTOR_TYPE_ID")
    private StndRequestorType stndRequesterType;

    @ManyToOne
    @JoinColumn(name = "FK_REHEARING_TYPE_ID")
    private StndRehearingType stndRehearingType;

}
