package gov.uspto.patent.ptab.common.opsg.domain;



import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Description of ParentContinuity. Used primarily in continuity related services.
 *
 * @author 2020 Development Team
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class ParentContinuity extends ContinuationInformation {

    private String claimParentageType;
    private AuditData audit;

}
