package gov.uspto.patent.ptab.domain;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class PaymentVO {

    private long paymentId;
    private Long proceedingId;
    private String patentNumber;
    private String patentOwner;
    private String trialTypeCd;
    private String trialTypeDesc;
    private String paymentDate;
    private String paymentTypeCode;
    private String paymentStatusCode;
    private Long saleItemCount;
    private BigDecimal totalSalesAmt;
    private BigDecimal paidAmt;
    private BigDecimal dueAmt;
    private Integer quantity;
    private String accountingTransactionId;
    private String accountingDt;
    private String paymentMethodType;
    private String responseCode;
    private String messageTxt;
    private String returnCode;
    private String proceedingNumber;
    private String proceedingPartyGroupTypeCd;
    private String receiptId;
    private BigDecimal createUserId;

    private List<FeeCodeDetails> feeCodes;
    private Map<Integer, TransactionVO> transactionVOs;
    private CaseStateSummary caseStateSummary;
    private InterestedParty interestedParty;
    private String paymentURL;
    private Map<String, String> paymentForm;
    private boolean paymentError;
    private String paymentErrorDesc;
    private String motionViewUrl;
    private String filingParty;
    private String transactionId;
    private String receiptHtmlResponse;

    private Long partyTypeIdentifier;

    @JsonIgnore
    private String authToken;

    @JsonIgnore
    protected BigDecimal lastModUserIdentifier;

    @JsonIgnore
    private String paymentReturnCode;

    @JsonIgnore
    private BigDecimal userIdentifier;

    @JsonIgnore
    private Petition petition;

    @JsonIgnore
    private String notificationEndPoint;

    @JsonIgnore
    private String paymentSuccessEvent;

    @JsonIgnore
    private boolean isPaymentNotificationRequired;

}