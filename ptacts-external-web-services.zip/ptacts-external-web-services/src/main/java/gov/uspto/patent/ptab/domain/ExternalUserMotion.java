package gov.uspto.patent.ptab.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import gov.uspto.patent.ptab.constants.MotionStatusEnum;
import gov.uspto.patent.ptab.utils.PTABConstants;
import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class ExternalUserMotion {
    private Long motionId;
    private Long requestorTypeId;
    private String requestorTypeName;
    private String filedDate;
    private String userDefinedMotionName;
    private Long motionTypeId;
    private String motionTypeNm;
    private Long motionStatusId;
    private String motionStatusName;
    private String motionStatusDate;
    private Long proceedingId;
    private String proceedingNumber;
    private String userPartyGroupType;
    private List<PetitionDocument> motionDocuments;
    private Long parentMotionId;
    private String commentText;
    private String artifactRoleName;

    private List<ArtifactContent> artifactContent = new ArrayList<>();

    @JsonIgnore
    private String documentName;
    @JsonIgnore
    private BigDecimal paperNumber;
    @JsonIgnore
    private BigDecimal exhibitNumber;

    @JsonIgnore
    public boolean removeInitiatedMotionNotSameParty() {
        final boolean isInitiatedCase = motionStatusId.equals(MotionStatusEnum.INITIATED.motionStatusId());
        return !isInitiatedCase || (artifactRoleName.equalsIgnoreCase(userPartyGroupType) && isInitiatedCase);
    }

    @JsonIgnore
    public Long getGroupByMotionId() {
        return parentMotionId == null ? motionId : parentMotionId;
    }

    public static ExternalUserMotion mergePetitionDocuments(final ExternalUserMotion first, final ExternalUserMotion second) {
        List<PetitionDocument> firstMotionDocuments = first.getMotionDocuments();
        List<PetitionDocument> secondMotionDocuments = second.getMotionDocuments();
        if (firstMotionDocuments == null) {
            firstMotionDocuments = new ArrayList<>();
        }
        if (secondMotionDocuments == null) {
            secondMotionDocuments = new ArrayList<>();
        }
        final String secondMotionStatus = second.getMotionStatusName();
        final String firstMotionStatus = first.getMotionStatusName();
        final boolean secondAppendArtifacts = !secondMotionStatus.equalsIgnoreCase(PTABConstants.MOTION_INITIATED_STATUS);
        final boolean firstAppendArtifacts = !firstMotionStatus.equalsIgnoreCase(PTABConstants.MOTION_INITIATED_STATUS);
        if (first.getParentMotionId() == null) {
            if (secondAppendArtifacts) {
                firstMotionDocuments.addAll(secondMotionDocuments);
                first.setMotionDocuments(firstMotionDocuments);
                return first;
            } else {
                return first;
            }
        }
        if (second.getParentMotionId() == null) {
            if (firstAppendArtifacts) {
                secondMotionDocuments.addAll(firstMotionDocuments);
                second.setMotionDocuments(secondMotionDocuments);
                return second;
            } else {
                return second;
            }
        }
        if (first.getParentMotionId() != null && second.getParentMotionId() != null) {
            if (secondAppendArtifacts && firstAppendArtifacts) {
                firstMotionDocuments.addAll(secondMotionDocuments);
                first.setMotionDocuments(firstMotionDocuments);
                return first;
            }
            if (secondAppendArtifacts && !firstAppendArtifacts) {
                return second;
            }
            if (!secondAppendArtifacts && firstAppendArtifacts) {
                return first;
            }
        }
        return null;
    }
}
