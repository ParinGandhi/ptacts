package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the PROCEEDING_PARTY database table.
 */
@Getter
@Setter
@Entity
@Table(name = "PROCEEDING_PARTY")
@NamedQuery(name = "ProceedingParty.findAll", query = "SELECT p FROM ProceedingParty p")
public class ProceedingParty implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "PROCEEDING_PARTY_PROCEEDINGPARTYID_GENERATOR",
            sequenceName = "PROCEEDING_PARTY_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PROCEEDING_PARTY_PROCEEDINGPARTYID_GENERATOR")
    @Column(name = "PROCEEDING_PARTY_ID")
    private Long proceedingPartyId;

    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Temporal(TemporalType.DATE)
    @Column(name = "CREATE_TS")
    private Date createTs;

    @Column(name = "CREATE_USER_ID")
    private BigDecimal createUserId;

    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "FK_AVAILABILITY_CD")
    private String fkAvailabilityCd;

    @Column(name = "FK_PARTY_ID")
    private Long fkPartyId;

    @Column(name = "FK_PRCDNG_PARTY_TYPE_CD")
    private String fkPrcdngPartyTypeCd;

    @Column(name = "FK_PROCEEDING_ID")
    private Long fkProceedingId;

    @Column(name = "FK_PROCEEDING_PARTY_GROUP_ID")
    private Long fkProceedingPartyGroupId;

    @Temporal(TemporalType.DATE)
    @Column(name = "LAST_MOD_TS")
    private Date lastModTs;

    @Column(name = "LAST_MOD_USER_ID")
    private BigDecimal lastModUserId;

    @Column(name = "LOCK_CONTROL_NO")
    private BigDecimal lockControlNo;

    @Column(name = "PRO_SE_IN")
    private String proSeIn;

    @Column(name = "RANK_NO")
    private Long rankNo;

    @OneToMany(mappedBy = "proceedingParty", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private List<PrcdngPartyElectronicAddrEntity> prcdngPartyElctrnAddrs;

    @OneToMany(mappedBy = "proceedingParty", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private List<PrcdngPartyPostalAddress> prcdngPartyPostalAddresses;

    @OneToMany(mappedBy = "proceedingParty", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private List<PrcdngPartyTelecomAddr> prcdngPartyTelecomAddrs;

    @OneToOne(mappedBy = "proceedingParty", cascade = CascadeType.REMOVE, orphanRemoval = true)
    private ProceedingCounselParty proceedingCounselParty;

    @OneToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY, orphanRemoval = true)
    @JoinColumn(name = "FK_PARTY_ID", referencedColumnName = "PARTY_ID", insertable = false, updatable = false)
    private Party party;

    @ManyToOne
    @JoinColumn(name = "FK_PROCEEDING_ID", insertable = false, updatable = false)
    private ProceedingEntity proceeding;

    @ManyToOne
    @JoinColumn(name = "FK_PROCEEDING_PARTY_GROUP_ID", insertable = false, updatable = false)
    private ProceedingPartyGroup proceedingPartyGroup;

    @ManyToOne
    @JoinColumn(name = "FK_PRCDNG_PARTY_TYPE_CD", insertable = false, updatable = false)
    private StndPrcdngPartyType stndPrcdngPartyType;

    @OneToMany(mappedBy = "proceedingParty")
    private List<ProceedingArtifact> proceedingArtifacts;

}