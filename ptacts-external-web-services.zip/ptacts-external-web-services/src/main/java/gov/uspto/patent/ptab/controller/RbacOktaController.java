package gov.uspto.patent.ptab.controller;

import java.util.Arrays;
import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.patent.ptab.domain.ExternalUserDetails;
import gov.uspto.patent.ptab.domain.MyUsptoStatus;
import gov.uspto.patent.ptab.entities.ExternalUser;
import gov.uspto.patent.ptab.service.RbacOktaService;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(value = "/rbac-okta")
@Slf4j
public class RbacOktaController {

    @Autowired
    private RbacOktaService rbacOktaService;
    
    @Autowired
    private HttpServletRequest httpServletRequest;

    /**
     * This end point is used to save registration number for a given email
     * address
     * 
     * @param externalUser
     * @return
     */
    @PutMapping(value = "/update-registration-number")
    public ExternalUser updateRegistrationNumberByEmail(@RequestBody ExternalUserDetails externalUser) {
        log.info("PUT updateRegistrationNumberByEmail:{}");
        return rbacOktaService.updateRegistrationNumberByEmail(externalUser);
    }
    
    @PostMapping(value = "/get-update-externaluser-myuspto")
    public MyUsptoStatus externalAccessBasedOnMyUsptoStatus(String userCt) {
    	String emailId = (String) httpServletRequest.getAttribute("valid-user");
    	if(StringUtils.isNotEmpty(emailId)) {
    	List<String> requestedEmailIds = Arrays.asList(emailId);
        return rbacOktaService.getAndCheckMyUsptoUserDetailsByEmail(userCt, requestedEmailIds);
    }
		return null;
    }
}
