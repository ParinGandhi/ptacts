package gov.uspto.patent.ptab.domain;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class StndDecisionOutComeReferenceType {

    private long decisionOutComeTypeId;
    private String decisionOutComeTypecd;
    private String descriptionText;
    private long displayOrderSeqNumb;
    private Date beginEffectiveDt;

}
