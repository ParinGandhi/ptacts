package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import gov.uspto.patent.ptab.constants.AppealStatusEnum;
import gov.uspto.patent.ptab.constants.MotionStatusEnum;
import gov.uspto.patent.ptab.constants.RehearingStatusEnum;
import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.dao.ExternalUserDocketDao;
import gov.uspto.patent.ptab.dao.ProceedingArtifactDao;
import gov.uspto.patent.ptab.domain.AIAReviewsDocket;
import gov.uspto.patent.ptab.domain.AppealDetails;
import gov.uspto.patent.ptab.domain.ExternalUserMotion;
import gov.uspto.patent.ptab.domain.ExternalUserRehearing;
import gov.uspto.patent.ptab.domain.NotificationDetails;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.entities.ProceedingArtifact;
import gov.uspto.patent.ptab.helper.ProceedingArtifactUtilityHelper;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;

@Component
public class ExternalUserDocketService {

    private static final String USER_ID = "User Id";
    private static final String PROCEEDINGPARTYGROUPSTATEID = "ProceedingPartyGroupStatId";
    private static final String EXTERNALMOTIONS = "ExternalMotions";
    private static final String REQUESTTYPEIDS = "RequestorTypeIds";
    private static final String EXTERNALREHEARINGS = "ExternalRehearings";

    @Autowired
    ExternalUserDocketDao externalUserDocketDao;

    @Autowired
    ProceedingArtifactDao proceedingArtifactDao;

    @Autowired
    ProceedingArtifactUtilityHelper proceedingArtifactUtilityHelper;

    @Autowired
    CodeReferenceDao codeReferenceDao;

    @Autowired
    private HttpServletRequest httpServletRequest;

    @Autowired
    private PTABBusinessUtils ptabBusinessUtils;

    @Transactional
    public List<AIAReviewsDocket> getAIAReviews(final String caseStatus) {
        final String userIdentifier = getUserId();

        final String referenceTypes = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue("ProceedingState", caseStatus);
        final List<Long> stateId = getCommaSeparatedReferenceTypes(referenceTypes);

        final String prcdngPartyGroupStatIdTypes = codeReferenceDao
                .getFirstDescCodeRefByTypeCdAndValue("ExternalAIAReviews", PROCEEDINGPARTYGROUPSTATEID);
        final List<Long> prcdngPartyGroupStatId = getCommaSeparatedReferenceTypes(prcdngPartyGroupStatIdTypes);

        final String aiaUnsubmittedStatus = "ext-aia-unsubmitted";
        if (aiaUnsubmittedStatus.equals(caseStatus)) {
            return externalUserDocketDao.getUnSubmittedAIAReviews(userIdentifier, stateId, prcdngPartyGroupStatId);
        } else {
            return externalUserDocketDao.getAIAReviews(userIdentifier, stateId, prcdngPartyGroupStatId);
        }
    }

    @Transactional
    public List<ExternalUserMotion> getMotions(final String motionStatus, final boolean excludeArtifacts) {
        return getMotions(null, motionStatus, excludeArtifacts, null);
    }

    @Transactional
    public List<ExternalUserMotion> getMotionsByPrcdNum(final String prcdNum, final String motionStatus,
            final boolean excludeArtifacts, final Long motionId) {
        return getMotions(prcdNum, motionStatus, excludeArtifacts, motionId);
    }

    private List<ExternalUserMotion> getMotions(final String prcdNum, final String motionStatus,
            final boolean excludeArtifacts, final Long motionId) {
        final String userIdentifier = getUserId();
        final String prcdngPartyGroupStatIdTypes = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(EXTERNALMOTIONS,
                PROCEEDINGPARTYGROUPSTATEID);
        final List<Long> prcdngPartyGroupStatId = getCommaSeparatedReferenceTypes(prcdngPartyGroupStatIdTypes);

        final String requestorTypeIds = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(EXTERNALMOTIONS,
                REQUESTTYPEIDS);
        final List<Long> requestorTypeId = getCommaSeparatedReferenceTypes(requestorTypeIds);

        List<Long> dbMotionStatusIds = new ArrayList<>();
        if (StringUtils.isEmpty(motionStatus) || "ALL".equals(motionStatus)) {
            final String motionStatusIds = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(EXTERNALMOTIONS,
                    "MotionStatusIds");
            dbMotionStatusIds = getCommaSeparatedReferenceTypes(motionStatusIds);
        } else {
            final Long motionStatusId = MotionStatusEnum.getDBMotionStatus(motionStatus);
            dbMotionStatusIds.add(motionStatusId);
        }

        final List<ExternalUserMotion> motionsFromDB = externalUserDocketDao.getMotions(userIdentifier, dbMotionStatusIds,
                prcdngPartyGroupStatId, requestorTypeId, prcdNum, motionId);
        final List<ExternalUserMotion> motionsDetails = motionsFromDB.stream()
                .filter(ExternalUserMotion::removeInitiatedMotionNotSameParty).collect(Collectors.toList());

        if (excludeArtifacts) {

            List<ExternalUserMotion> updated = motionsDetails.stream().filter(e -> e.getParentMotionId() == null)
                    .collect(Collectors.toList());
            for (ExternalUserMotion externalUserMotion : updated) {
                ptabBusinessUtils.setEncryptArtifactIdentifiers(externalUserMotion.getMotionDocuments());
            }
            return updated;
        } else {
            List<ExternalUserMotion> updated = buildMotionsWithArtifacts(motionsDetails);
            for (ExternalUserMotion externalUserMotion : updated) {
                ptabBusinessUtils.setEncryptArtifactIdentifiers(externalUserMotion.getMotionDocuments());
            }
            return updated;
        }
    }

    private List<ExternalUserMotion> buildMotionsWithArtifacts(final List<ExternalUserMotion> motionsDetails) {
        for (final ExternalUserMotion existing : motionsDetails) {
            final String userPartyGroupType = existing.getUserPartyGroupType();
            final List<ProceedingArtifact> prcdArtifacts = proceedingArtifactDao
                    .getAllProceedingArtifactsForMotions(existing.getMotionId());
            if (CollectionUtils.isNotEmpty(prcdArtifacts)) {
                final List<PetitionDocument> petitionDocumentList = new ArrayList<>();
                proceedingArtifactUtilityHelper.getAllPetitionDocuments(petitionDocumentList, prcdArtifacts);
                if (!existing.getMotionStatusName().equalsIgnoreCase("INITIATED")) {
                    proceedingArtifactUtilityHelper.addFilterToUpdatePetitionDocs(petitionDocumentList,
                            userPartyGroupType);
                }
                existing.setMotionDocuments(petitionDocumentList);
            }
        }
        final Collector<ExternalUserMotion, ?, Map<Long, ExternalUserMotion>> motionDetailsmap = Collectors.toMap(
                ExternalUserMotion::getGroupByMotionId, Function.identity(), ExternalUserMotion::mergePetitionDocuments);
        final Collection<ExternalUserMotion> motionDetailsList = motionsDetails.stream().collect(motionDetailsmap)
                .values();
        return motionDetailsList.stream().filter(e -> e.getParentMotionId() == null).collect(Collectors.toList());
    }

    @Transactional
    public List<AppealDetails> getAppeals(final String appealStatus) {
        return getAppealDetails(appealStatus, null);
    }

    @Transactional
    public List<AppealDetails> getAppealsByPrcdNum(final String prcdNum, final String appealStatus) {
        return getAppealDetails(appealStatus, prcdNum);
    }

    private List<AppealDetails> getAppealDetails(final String appealStatus, final String proceedingNum) {
        final String userIdentifier = getUserId();
        final String externalAppeals = "ExternalAppeals";
        final String prcdngPartyGroupStatIdTypes = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(externalAppeals,
                PROCEEDINGPARTYGROUPSTATEID);
        final List<Long> prcdngPartyGroupStatId = getCommaSeparatedReferenceTypes(prcdngPartyGroupStatIdTypes);
        final String appealTypeIds = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(externalAppeals,
                "AppealTypeIds");
        final List<Long> dbAppealTypeIds = getCommaSeparatedReferenceTypes(appealTypeIds);
        final String prcdPartyGrpTypeIds = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(externalAppeals,
                "ProceedingPartyGroupIds");
        final List<Long> dbPrcdPartyGrpTypeIds = getCommaSeparatedReferenceTypes(prcdPartyGrpTypeIds);
        List<Long> dbAppealStatusIds = new ArrayList<>();

        if (StringUtils.isEmpty(appealStatus) || appealStatus.equals("ALL")) {
            final String appealStatusIds = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(externalAppeals,
                    "AppealStatusIds");
            dbAppealStatusIds = getCommaSeparatedReferenceTypes(appealStatusIds);
        } else {
            final AppealStatusEnum appealStatusEnum = AppealStatusEnum.valueOf(appealStatus);
            dbAppealStatusIds.add(appealStatusEnum.getAppealStatusId());
        }

        final List<AppealDetails> appealsFromDB = externalUserDocketDao.getAppeals(userIdentifier, dbAppealStatusIds,
                prcdngPartyGroupStatId, dbAppealTypeIds, dbPrcdPartyGrpTypeIds, proceedingNum);
        final List<AppealDetails> appeals = appealsFromDB.stream().filter(AppealDetails::removeInitiatedAppealNotSameParty)
                .collect(Collectors.toList());

        for (final AppealDetails existing : appeals) {
            final String userPartyGroupType = existing.getUserPartyGroupType();
            final List<ProceedingArtifact> proceedingArtifactList = proceedingArtifactDao
                    .getAllProceedingArtifactsForAppeals(existing.getProceedingAppealId());
            if (CollectionUtils.isNotEmpty(proceedingArtifactList)) {
                final List<PetitionDocument> petitionDocumentList = new ArrayList<>();
                proceedingArtifactUtilityHelper.getAllPetitionDocuments(petitionDocumentList, proceedingArtifactList);
                if (!existing.getAppealStatusCd().equalsIgnoreCase("INITIATED")) {
                    proceedingArtifactUtilityHelper.addFilterToUpdatePetitionDocs(petitionDocumentList,
                            userPartyGroupType);
                }
                existing.setAppealDocuments(petitionDocumentList);
            }
        }
        for (AppealDetails appealDetails : appeals) {
            ptabBusinessUtils.setEncryptArtifactIdentifiers(appealDetails.getAppealDocuments());
        }
        return appeals;
    }

    @Transactional
    public List<NotificationDetails> getNotifications() {
        final String userIdentifier = getUserId();
        return externalUserDocketDao.getNotifications(userIdentifier);
    }

    @Transactional
    public List<ExternalUserRehearing> getRehearings(final String rehearingStatus) {
        return getRehearings(null, rehearingStatus, null);
    }

    @Transactional
    public List<ExternalUserRehearing> getRehearingsByPrcdNum(final String prcdNum, final String rehearingStatus,
            final Long rehearingId) {
        return getRehearings(prcdNum, rehearingStatus, rehearingId);
    }

    private List<ExternalUserRehearing> getRehearings(final String prcdNum, final String rehearingStatus,
            final Long rehearingId) {
        final String userIdentifier = getUserId();

        final String prcdngPartyGroupStatIdTypes = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(EXTERNALREHEARINGS,
                PROCEEDINGPARTYGROUPSTATEID);
        final List<Long> prcdngPartyGroupStatId = getCommaSeparatedReferenceTypes(prcdngPartyGroupStatIdTypes);

        final String requestorTypeIds = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(EXTERNALREHEARINGS,
                REQUESTTYPEIDS);
        final List<Long> requestorTypeId = getCommaSeparatedReferenceTypes(requestorTypeIds);

        final String rehearingTypeIds = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(EXTERNALREHEARINGS,
                "RehearingTypeIds");
        final List<Long> rehearingTypeId = getCommaSeparatedReferenceTypes(rehearingTypeIds);

        List<Long> dbRehearingStatusIds = new ArrayList<>();
        if (StringUtils.isEmpty(rehearingStatus) || "ALL".equals(rehearingStatus)) {
            final String rehearingStatusIds = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(EXTERNALREHEARINGS,
                    "RehearingStatusIds");
            dbRehearingStatusIds = getCommaSeparatedReferenceTypes(rehearingStatusIds);
        } else {
            final Long rehearingStatusId = RehearingStatusEnum.getDBRehearingStatus(rehearingStatus);
            dbRehearingStatusIds.add(rehearingStatusId);
        }

        final List<ExternalUserRehearing> rehearingsFromDB = externalUserDocketDao.getRehearingsByPrcdNum(userIdentifier,
                dbRehearingStatusIds, prcdngPartyGroupStatId, requestorTypeId, rehearingTypeId, prcdNum, rehearingId);

        List<ExternalUserRehearing> updated = retrieveArtifactsForRehearing(rehearingsFromDB);

        for (ExternalUserRehearing externalUserRehearing : updated) {
            ptabBusinessUtils.setEncryptArtifactIdentifiers(externalUserRehearing.getRehearingDocuments());
        }

        return updated;
    }

    private List<ExternalUserRehearing> retrieveArtifactsForRehearing(final List<ExternalUserRehearing> rehearingsFromDB) {
        final List<ExternalUserRehearing> rehearings = rehearingsFromDB.stream()
                .filter(ExternalUserRehearing::removeInitiatedRehearingNotSameParty).collect(Collectors.toList());

        for (final ExternalUserRehearing existing : rehearings) {
            final String userPartyGroupType = existing.getUserPartyGroupType();
            final List<ProceedingArtifact> proceedingArtifactList = proceedingArtifactDao
                    .getAllProceedingArtifactsForRehearing(existing.getRehearingId());
            if (CollectionUtils.isNotEmpty(proceedingArtifactList)) {
                final List<PetitionDocument> petitionDocumentList = new ArrayList<>();
                proceedingArtifactUtilityHelper.getAllPetitionDocuments(petitionDocumentList, proceedingArtifactList);
                if (!existing.getRehearingStatusName().equalsIgnoreCase("INITIATED")) {
                    proceedingArtifactUtilityHelper.addFilterToUpdatePetitionDocs(petitionDocumentList,
                            userPartyGroupType);
                }
                existing.setRehearingDocuments(petitionDocumentList);
            }
        }
        return rehearings;
    }

    private String getUserId() {
        final String userIdentifier = (String) httpServletRequest.getAttribute("valid-user");
        if (StringUtils.isEmpty(userIdentifier))
            notFoundIfNull(userIdentifier, USER_ID);
        return userIdentifier;
    }

    private List<Long> getCommaSeparatedReferenceTypes(final String referenceTypes) {
        List<Long> commaSeparatedReferences = null;
        if (StringUtils.isNotBlank(referenceTypes)) {
            commaSeparatedReferences = Arrays.stream(referenceTypes.split("~")).map(Long::valueOf)
                    .collect(Collectors.toList());
        }
        return commaSeparatedReferences;
    }

}