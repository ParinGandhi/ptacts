package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the PRCDNG_PARTY_TELECOM_ADDR database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = "PRCDNG_PARTY_TELECOM_ADDR")
@NamedQuery(name = "PrcdngPartyTelecomAddr.findAll", query = "SELECT p FROM PrcdngPartyTelecomAddr p")
public class PrcdngPartyTelecomAddr extends AbstractAuditEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "PRCDNG_PARTY_TELECOM_ADDR_PRCDNGPARTYTELECOMADDRID_GENERATOR",
            sequenceName = "PRCDNG_PARTY_TELECOM_ADDR_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "PRCDNG_PARTY_TELECOM_ADDR_PRCDNGPARTYTELECOMADDRID_GENERATOR")
    @Column(name = "PRCDNG_PARTY_TELECOM_ADDR_ID")
    private Long prcdngPartyTelecomAddrId;

    @Column(name = "EXTENSION_NO")
    private String extensionNo;

    @Column(name = "FK_PROCEEDING_PARTY_ID")
    private BigDecimal fkProceedingPartyId;

    @Column(name = "FK_TELECOM_TYPE_CD")
    private String fkTelecomTypeCd;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo;

    @Column(name = "TELECOM_NO")
    private String telecomNo;

    @ManyToOne
    @JoinColumn(name = "FK_PROCEEDING_PARTY_ID", insertable = false, updatable = false)
    private ProceedingParty proceedingParty;

    @ManyToOne
    @JoinColumn(name = "FK_TELECOM_TYPE_CD", insertable = false, updatable = false)
    private StndTelecomType stndTelecomType;

}