package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import java.util.List;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.trials.domain.MotionDetails;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class MotionService {

    private static final String MOTIONS_URL = "MOTIONS_URL";
    private static final String SYSTEM_USER = "SYSTEM_USER";
    private static final String PTAB_CASE_INIT = "PTAB_CASE_INIT";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    private static final String GET_MOTIONS_URL = "GET_MOTIONS_URL";
    private static final String CREATE_MOTION_URL = "CREATE_MOTION_URL";
    private static final String SYSTEM = "system user name";

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Autowired
    private PTABBusinessUtils ptabBusinessUtils;

    /**
     * Method used to get motions
     *
     * @param caseDocumentsDataQuery
     * @return
     */
    @Transactional
    public JsonNode getAllMotions(@Valid @NotNull CaseDocumentsDataQuery caseDocumentsDataQuery) {
        final String motionDetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL, MOTIONS_URL);
        notFoundIfNull(motionDetailsUrl, "Motion details Url");

        final String userName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(userName, SYSTEM);

        final String url = externalServiceUriGenerator.getCaseDocumentDataQueryUrl(caseDocumentsDataQuery, motionDetailsUrl);
        ResponseEntity<JsonNode> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, JsonNode.class, userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response ? response.getBody() : null;
    }

    /**
     * Method used to get motion details
     *
     * @param motionId
     * @return
     */
    @Transactional
    public JsonNode getMotionDetails(@NotBlank Long motionId) {
        final String motionDetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL, MOTIONS_URL);
        notFoundIfNull(motionDetailsUrl, "Motion details Url");

        final String userName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(userName, SYSTEM);
        ResponseEntity<JsonNode> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(motionDetailsUrl + "/" + motionId, null, HttpMethod.GET,
                    JsonNode.class, userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response ? response.getBody() : null;
    }

    /**
     * This method is used to retrieve all the motion details
     *
     * @param caseDocumentsDataQuery - query object
     */
    @Transactional
    public List<MotionDetails> getMotionDetailsTrials(final CaseDocumentsDataQuery caseDocumentsDataQuery) {
        List<MotionDetails> motionDetails = null;
        final String motionDetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                GET_MOTIONS_URL);
        notFoundIfNull(motionDetailsUrl, "Get Motion details Url");

        final String userName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(userName, SYSTEM);

        final String url = externalServiceUriGenerator.getCaseDocumentDataQueryUrl(caseDocumentsDataQuery, motionDetailsUrl);
        ResponseEntity<String> response = null;

        response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, String.class, userName);
        if (response.getStatusCode().is2xxSuccessful()) {
            final ObjectMapper mapper = new ObjectMapper();
            try {
                motionDetails = mapper.readValue(response.getBody(), new TypeReference<List<MotionDetails>>() {
                });
            } catch (JsonProcessingException e) {
                log.error("Error ", e);
            }
        }
        return motionDetails;
    }

    /**
     * This method is used to create the motion details
     *
     * @param caseDocumentsDataQuery - query object
     */
    @Transactional
    public MotionDetails createMotion(final MotionDetails motionDetails) {
        final String motionDetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                CREATE_MOTION_URL);
        notFoundIfNull(motionDetailsUrl, "Create Motion details Url");

        final String userName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(userName, SYSTEM);
        List<PetitionDocument> motionDocuments = motionDetails.getMotionDocuments();
        if (CollectionUtils.isNotEmpty(motionDocuments)) {
            ptabBusinessUtils.setDecryptArtifactIdentifiers(motionDocuments);
            motionDetails.setMotionDocuments(motionDocuments);
        }
        ResponseEntity<MotionDetails> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(motionDetailsUrl, motionDetails, HttpMethod.POST,
                    MotionDetails.class, userName);
            final MotionDetails updated = response.getBody();
            if (null != updated) {
                List<PetitionDocument> petitionDocuments = updated.getMotionDocuments();
                ptabBusinessUtils.setEncryptArtifactIdentifiers(petitionDocuments);
                updated.setMotionDocuments(motionDocuments);
            }
            return updated;

        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }

    }

}
