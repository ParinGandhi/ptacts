package gov.uspto.patent.ptab.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * The query class is used for various reference retrieval operations
 *
 * @author 2020 Development Team
 */
@Getter
@Setter
public class ReferenceQuery {

    private String typeCode;
    private String proceedingNumber;
    private String recipientType;
    private String categoryType;
    private String notificationId;
    private Boolean isPublic = false;
    private String trialType;
    private String fieldType;
    private String event;
    private String identifiers;
    private Boolean isOtherDocs = false;
}
