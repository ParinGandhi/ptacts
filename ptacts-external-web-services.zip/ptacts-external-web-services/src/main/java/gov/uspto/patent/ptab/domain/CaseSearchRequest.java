package gov.uspto.patent.ptab.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class CaseSearchRequest {

    private String proceedingNumber;
    private String patentNumber;
    private String applicationNumber;
    private String partyName;
    private String apj1Judge;
    private String apjXJudge;
    private String techCenterNum;
    private List<String> trailTypes;
    private String inventionTitle;
    private String casePhase;
    private String artUnit;
    private String proceedingState;
    private List<Long> stateId;
    private Boolean isAllParties = true;
    private Boolean isMilestoneData = true;
    private String partyType;
    private String counselName;
    private String startFilingDate;
    private String endFilingDate;
    private String startInstDecDate;
    private String endInstDecDate;
    private String startTerminationDate;
    private String endTerminationDate;
    private Boolean isExternalUser = false;
    private Boolean isMnNotice = false;
}