package gov.uspto.patent.ptab.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.patent.ptab.domain.AIAReviewsDocket;
import gov.uspto.patent.ptab.domain.AppealDetails;
import gov.uspto.patent.ptab.domain.ExternalUserMotion;
import gov.uspto.patent.ptab.domain.ExternalUserRehearing;
import gov.uspto.patent.ptab.domain.NotificationDetails;
import gov.uspto.patent.ptab.service.ExternalUserDocketService;

/**
 * Controller class ExternalUserDocketViewController
 */
@RestController
@RequestMapping("/external-user-docket")
public class ExternalUserDocketViewController {

    @Autowired
    private ExternalUserDocketService externalDtCaseViewerService;

    /**
     * This end point is used to fetch all the pendig aia reviews for a user
     * 
     * @param
     * @return
     */
    @GetMapping(value = "/aia-reviews")
    public List<AIAReviewsDocket> getAIAReviews(@RequestParam(required = true) String caseStatus) {
        return externalDtCaseViewerService.getAIAReviews(caseStatus);
    }

    @GetMapping(value = "/motions")
    public List<ExternalUserMotion> getMotions(@RequestParam(required = true) String motionStatus,
            boolean excludeArtifacts) {
        return externalDtCaseViewerService.getMotions(motionStatus, excludeArtifacts);
    }

    @GetMapping(value = "/notifications")
    public List<NotificationDetails> getNotifications() {
        return externalDtCaseViewerService.getNotifications();
    }

    @GetMapping(value = "/rehearings")
    public List<ExternalUserRehearing> getRehearings(@RequestParam(required = true) String rehearingStatus) {
        return externalDtCaseViewerService.getRehearings(rehearingStatus);
    }

    @GetMapping(value = "/appeals")
    public List<AppealDetails> getAppeals(@RequestParam(required = true) String appealStatus) {
        return externalDtCaseViewerService.getAppeals(appealStatus);
    }
}