package gov.uspto.patent.ptab.domain;

import java.util.ArrayList;
import java.util.List;

import jakarta.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ProceedingParties extends CaseBase {

    private String identifier;

    private String status;

    @NotNull
    private List<InterestedParty> parties = new ArrayList<>();

    @NotNull
    private Audit audit;

    @JsonIgnore
    private String notificationEndPoint;

    @JsonIgnore
    private String externalUserIndiactor;
}
