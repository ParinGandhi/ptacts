package gov.uspto.patent.ptab.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.service.NotificationService;
import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to retrieve the notification email details
 *
 * @author 2020 development team
 *
 */
@RestController
@RequestMapping
@Slf4j
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    /**
     * Method used to fetch the notification email details
     *
     * @param notificationId - notification id
     * @return
     */
    @GetMapping(value = "/notificationemail/{notificationId}")
    public JsonNode getNotificationEmailDetails(@PathVariable("notificationId") final String notificationId) {
        log.info("executing getNotificationEmailDetails for notificationId : {}", notificationId);
        return notificationService.getNotificationEmailDetails(notificationId);
    }
}
