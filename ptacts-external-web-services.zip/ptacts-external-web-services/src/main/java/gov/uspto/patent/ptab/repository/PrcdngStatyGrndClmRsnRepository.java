package gov.uspto.patent.ptab.repository;

import gov.uspto.patent.ptab.entities.ClaimChallengeReason;
import gov.uspto.patent.ptab.entities.PrcdngStatyGrndClmRsn;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PrcdngStatyGrndClmRsnRepository extends JpaRepository<PrcdngStatyGrndClmRsn, Long> {

    @Query("select DISTINCT(prcdngStatyGrndClmRsn.claimChallengeReason) FROM PrcdngStatyGrndClmRsn prcdngStatyGrndClmRsn "
            + "where prcdngStatyGrndClmRsn.prcdngClmStatyGround.proceedingClaim.fkProceedingId = (?1)")
    List<ClaimChallengeReason> getAllClaims(final Long proceedingId);

    @Query(value = "select prcdngStatyGrndClmRsn from PrcdngStatyGrndClmRsn prcdngStatyGrndClmRsn "
            + "where prcdngStatyGrndClmRsn.fkPrcdgClmStayGroundId=(?1)")
    PrcdngStatyGrndClmRsn getStatyGroundClaims(final Long fkPrcdgClmStayGroundId);

    @Query(value = "select prcdngStatyGrndClmRsn from PrcdngStatyGrndClmRsn prcdngStatyGrndClmRsn "
            + "where prcdngStatyGrndClmRsn.fkPrcdgClmChallengeReasonId=(?1)")
    List<PrcdngStatyGrndClmRsn> getAllClaimsByReasonId(final Long fkPrcdgClmChallengeReasonId);

}
