package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the STND_PRCDNG_PARTY_TYPE database table.
 * 
 */
@Entity
@Table(name = "STND_PRCDNG_PARTY_TYPE")
@NamedQuery(name = "StndPrcdngPartyType.findAll", query = "SELECT s FROM StndPrcdngPartyType s")
@Data
@EqualsAndHashCode(callSuper = false)
public class StndPrcdngPartyType extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "PRCDNG_PARTY_TYPE_CD")
    private String prcdngPartyTypeCd;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Column(name = "DESCRIPTION_TX")
    private String descriptionTx;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    // bi-directional many-to-one association to ProceedingParty
    @OneToMany(mappedBy = "stndPrcdngPartyType")
    private List<ProceedingParty> proceedingParties;

    /**
     * add Proceeding Party
     * 
     * @param proceedingParty
     * @return ProceedingParty
     */
    public ProceedingParty addProceedingParty(final ProceedingParty proceedingParty) {
        getProceedingParties().add(proceedingParty);
        proceedingParty.setStndPrcdngPartyType(this);

        return proceedingParty;
    }

    /**
     * remove Proceeding Party
     * 
     * @param proceedingParty
     * @return ProceedingParty
     */
    public ProceedingParty removeProceedingParty(final ProceedingParty proceedingParty) {
        getProceedingParties().remove(proceedingParty);
        proceedingParty.setStndPrcdngPartyType(null);

        return proceedingParty;
    }

    /**
     * @return the beginEffectiveDt
     */
    public Date getBeginEffectiveDt() {
        return null != this.beginEffectiveDt ? (Date) this.beginEffectiveDt.clone() : null;
    }

    /**
     * @param beginEffectiveDt the beginEffectiveDt to set
     */
    public void setBeginEffectiveDt(final Date beginEffectiveDt) {
        this.beginEffectiveDt = null != beginEffectiveDt ? new Date(beginEffectiveDt.getTime()) : null;
    }

    /**
     * @return the endEffectiveDt
     */
    public Date getEndEffectiveDt() {
        return null != this.endEffectiveDt ? (Date) this.endEffectiveDt.clone() : null;
    }

    /**
     * @param endEffectiveDt the endEffectiveDt to set
     */
    public void setEndEffectiveDt(final Date endEffectiveDt) {
        this.endEffectiveDt = null != endEffectiveDt ? new Date(endEffectiveDt.getTime()) : null;
    }

}