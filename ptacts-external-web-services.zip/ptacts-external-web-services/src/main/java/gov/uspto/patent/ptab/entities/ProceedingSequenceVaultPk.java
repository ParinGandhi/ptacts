package gov.uspto.patent.ptab.entities;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
public class ProceedingSequenceVaultPk implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "CFK_PROCEEDING_TYPE_CD", nullable = false)
    private String cfkProceedingTypeCd;

    @Column(name = "FISCAL_YEAR_NO", nullable = false)
    private Long fiscalYearNo;

}
