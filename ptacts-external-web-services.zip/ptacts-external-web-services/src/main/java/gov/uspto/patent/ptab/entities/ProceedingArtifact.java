package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the PROCEEDING_ARTIFACT database table.
 */
@Entity
@Table(name = "PROCEEDING_ARTIFACT")
@NamedQuery(name = "ProceedingArtifact.findAll", query = "SELECT p FROM ProceedingArtifact p")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ProceedingArtifact extends AbstractAuditEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "PROCEEDING_ARTIFACT_ID")
    private long proceedingArtifactId;

    @Column(name = "FK_ARTIFACT_SUBMISSION_ID")
    private Long fkArtifactSubmissionId;

    @Column(name = "ARTIFACT_NM")
    private String artifactNm;

    @Column(name = "CONTENT_MANAGEMENT_ID")
    private String contentManagementId;

    @Column(name = "FILE_SIZE_CT")
    private String fileSizeCt;

    @Column(name = "FILE_SIZE_QT")
    private BigDecimal fileSizeQt;

    @Column(name = "FILE_NM")
    private String fileName;

    @Column(name = "COMMENT_TX")
    private String comment;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo;

    @Column(name = "PAGE_COUNT_QT")
    private Integer pageCountQt;

    @Column(name = "RELEVANT_IN")
    private String relevantIn;

    @Column(name = "FILING_TS")
    private Date filingTS;

    @Column(name = "FOIA_CONFIDENTIALITY_IN")
    private Date foiaConfidentialityIndicator;

    @Column(name = "FK_AVAILABILITY_CD")
    private String fkAvailabilityCd;

    @Column(name = "FK_DIRECTION_CD")
    private String fkDirectionCd;

    @Column(name = "FK_SUBMIT_USER_ID")
    private BigDecimal fkApplicationUserId;

    @Column(name = "FK_ARTIFACT_TYPE_ID")
    private Long fkArtifactTypeId;

    @Column(name = "FK_MIME_TYPE_ID")
    private Long fkMimeTypeId;

    @Column(name = "FK_PROCEEDING_PARTY_ID")
    private Long fkProceedingPartyId;

    @Column(name = "FK_SUBMITTER_ROLE_NM")
    private String fkProxySubmitterRoleNm;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "FK_ARTIFACT_SUBMISSION_ID", insertable = false, updatable = false)
    private ArtifactSubmission artifactSubmission;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "FK_DIRECTION_CD", insertable = false, updatable = false)
    private StndDirection stndDirection;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "FK_AVAILABILITY_CD", insertable = false, updatable = false)
    private StndAvailability stndAvailability;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "FK_ARTIFACT_TYPE_ID", insertable = false, updatable = false)
    private StndArtifactType stndArtifactType;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "FK_MIME_TYPE_ID", insertable = false, updatable = false)
    private StndMimeType stndMimeType;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "FK_SUBMITTER_ROLE_NM", insertable = false, updatable = false)
    private StndProxySubmitterRole stndProxySubmitterRole;

    @OneToOne(mappedBy = "proceedingArtifact", cascade = CascadeType.REMOVE)
    private Document document;

    @OneToOne(mappedBy = "proceedingArtifact", cascade = CascadeType.REMOVE)
    private Exhibit exhibit;

    @OneToMany(mappedBy = "proceedingArtifact")
    private List<DocumentExternalUpload> documentExternalUploads;

    @OneToMany(mappedBy = "proceedingArtifact")
    private List<ProceedingArtifactStatus> proceedingArtifactStatuses;

    @ManyToOne(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
    @JoinColumn(name = "FK_PROCEEDING_PARTY_ID", insertable = false, updatable = false)
    private ProceedingParty proceedingParty;

}