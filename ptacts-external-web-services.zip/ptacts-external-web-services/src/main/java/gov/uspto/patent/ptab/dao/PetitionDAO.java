package gov.uspto.patent.ptab.dao;

import java.math.BigDecimal;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.stereotype.Component;

@Component
public class PetitionDAO {
    private static final String SELECT_CURRENT_FISCAL_YEAR = "select distinct to_number(to_char(sysdate, 'YYYY')) + "
            + "DECODE(SIGN(TO_CHAR(sysdate, 'MM') - 10), -1, 0, 1) " + "from dual";

    @PersistenceContext
    private EntityManager entityManager;

    public Long getFiscalYear() {
        final Query q = entityManager.createNativeQuery(SELECT_CURRENT_FISCAL_YEAR);
        return ((BigDecimal) q.getSingleResult()).longValue();
    }
}
