package gov.uspto.patent.ptab.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.uspto.patent.ptab.constants.RehearingStatusEnum;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ExternalUserRehearing {
    private Long rehearingId;
    private Long rehearingTypeId;
    private String rehearingTypeNm;
    private Long rehearingStatusId;
    private String rehearingStatusName;
    private String rehearingStatusDisplayName;
    private Long requestorTypeId;
    private String requestorTypeName;
    private String filedDate;
    private String decisionDate;
    private Long proceedingId;
    private String proceedingNumber;
    private String userPartyGroupType;
    private List<PetitionDocument> rehearingDocuments;

    public boolean removeInitiatedRehearingNotSameParty() {
        boolean isInitiatedCase = rehearingStatusId.equals(RehearingStatusEnum.INITIATED.rehearingStatusId());
        return !isInitiatedCase || (requestorTypeName.equalsIgnoreCase(userPartyGroupType) && isInitiatedCase);
    }
}