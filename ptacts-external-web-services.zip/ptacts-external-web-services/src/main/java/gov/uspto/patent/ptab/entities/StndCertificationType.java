package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

/**
 * The persistent class for the STND_CERTIFICATION_TYPE database table.
 * 
 */
@Entity
@Table(name = "STND_CERTIFICATION_TYPE")
@NamedQuery(name = "StndCertificationType.findAll", query = "SELECT s FROM StndCertificationType s")
public class StndCertificationType implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "CERTIFICATION_TYPE_ID")
    private long certificationTypeId;

    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Column(name = "CERTIFICATION_TYPE_NM")
    private String certificationTypeNm;

    @Column(name = "CREATE_TS")
    private Timestamp createTs;

    @Column(name = "CREATE_USER_ID")
    private BigDecimal createUserId;

    @Column(name = "DESCRIPTION_TX")
    private String descriptionTx;

    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "LAST_MOD_TS")
    private Timestamp lastModTs;

    @Column(name = "LAST_MOD_USER_ID")
    private BigDecimal lastModUserId;

    @Column(name = "LOCK_CONTROL_NO")
    private BigDecimal lockControlNo;

    // bi-directional many-to-one association to PrcdngPartyGrpCertif
    @OneToMany(mappedBy = "stndCertificationType")
    private List<PrcdngPartyGrpCertif> prcdngPartyGrpCertifs;

    /**
     * Constructor
     */
    public StndCertificationType() {
    }

    /**
     * 
     * @return
     */
    public long getCertificationTypeId() {
        return this.certificationTypeId;
    }

    /**
     * 
     * @param certificationTypeId
     */
    public void setCertificationTypeId(final long certificationTypeId) {
        this.certificationTypeId = certificationTypeId;
    }

    /**
     * 
     * @return
     */
    public Date getBeginEffectiveDt() {
        return null != this.beginEffectiveDt ? (Date) this.beginEffectiveDt.clone() : null;
    }

    /**
     * 
     * @param beginEffectiveDt
     */
    public void setBeginEffectiveDt(final Date beginEffectiveDt) {
        this.beginEffectiveDt = null != beginEffectiveDt ? new Date(beginEffectiveDt.getTime()) : null;
    }

    /**
     * 
     * @return
     */
    public String getCertificationTypeNm() {
        return this.certificationTypeNm;
    }

    /**
     * 
     * @param certificationTypeNm
     */
    public void setCertificationTypeNm(final String certificationTypeNm) {
        this.certificationTypeNm = certificationTypeNm;
    }

    /**
     * 
     * @return
     */
    public Timestamp getCreateTs() {
        return null != this.createTs ? (Timestamp) this.createTs.clone() : null;
    }

    /**
     * 
     * @param createTs
     */
    public void setCreateTs(final Timestamp createTs) {
        this.createTs = null != createTs ? new Timestamp(createTs.getTime()) : null;
    }

    /**
     * 
     * @return
     */
    public BigDecimal getCreateUserId() {
        return this.createUserId;
    }

    /**
     * 
     * @param createUserId
     */
    public void setCreateUserId(final BigDecimal createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * 
     * @return
     */
    public String getDescriptionTx() {
        return this.descriptionTx;
    }

    /**
     * 
     * @param descriptionTx
     */
    public void setDescriptionTx(final String descriptionTx) {
        this.descriptionTx = descriptionTx;
    }

    /**
     * 
     * @return
     */
    public Date getEndEffectiveDt() {
        return null != this.endEffectiveDt ? (Date) this.endEffectiveDt.clone() : null;
    }

    /**
     * 
     * @param endEffectiveDt
     */
    public void setEndEffectiveDt(final Date endEffectiveDt) {
        this.endEffectiveDt = null != endEffectiveDt ? new Date(endEffectiveDt.getTime()) : null;
    }

    /**
     * 
     * @return
     */
    public Timestamp getLastModTs() {
        return null != this.lastModTs ? (Timestamp) this.lastModTs.clone() : null;
    }

    /**
     * 
     * @param lastModTs
     */
    public void setLastModTs(final Timestamp lastModTs) {
        this.lastModTs = null != lastModTs ? new Timestamp(lastModTs.getTime()) : null;
    }

    /**
     * 
     * @return
     */
    public BigDecimal getLastModUserId() {
        return this.lastModUserId;
    }

    /**
     * 
     * @param lastModUserId
     */
    public void setLastModUserId(final BigDecimal lastModUserId) {
        this.lastModUserId = lastModUserId;
    }

    /**
     * 
     * @return
     */
    public BigDecimal getLockControlNo() {
        return this.lockControlNo;
    }

    /**
     * 
     * @param lockControlNo
     */
    public void setLockControlNo(final BigDecimal lockControlNo) {
        this.lockControlNo = lockControlNo;
    }

    /**
     * 
     * @return
     */
    public List<PrcdngPartyGrpCertif> getPrcdngPartyGrpCertifs() {
        return this.prcdngPartyGrpCertifs;
    }

    /**
     * 
     * @param prcdngPartyGrpCertifs
     */
    public void setPrcdngPartyGrpCertifs(final List<PrcdngPartyGrpCertif> prcdngPartyGrpCertifs) {
        this.prcdngPartyGrpCertifs = prcdngPartyGrpCertifs;
    }

    /**
     * Adds proceeding party group certif
     * 
     * @param prcdngPartyGrpCertif
     * @return
     */
    public PrcdngPartyGrpCertif addPrcdngPartyGrpCertif(final PrcdngPartyGrpCertif prcdngPartyGrpCertif) {
        getPrcdngPartyGrpCertifs().add(prcdngPartyGrpCertif);
        prcdngPartyGrpCertif.setStndCertificationType(this);

        return prcdngPartyGrpCertif;
    }

    /**
     * Removes proceeding party group certif
     * 
     * @param prcdngPartyGrpCertif
     * @return
     */
    public PrcdngPartyGrpCertif removePrcdngPartyGrpCertif(final PrcdngPartyGrpCertif prcdngPartyGrpCertif) {
        getPrcdngPartyGrpCertifs().remove(prcdngPartyGrpCertif);
        prcdngPartyGrpCertif.setStndCertificationType(null);

        return prcdngPartyGrpCertif;
    }
}