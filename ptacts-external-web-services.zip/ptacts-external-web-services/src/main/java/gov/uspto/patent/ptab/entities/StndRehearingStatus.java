package gov.uspto.patent.ptab.entities;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "STND_REHEARING_STATUS")
@NamedQuery(name = "StndRehearingStatus.findAll", query = "SELECT s FROM StndRehearingStatus s")
@Getter
@Setter
@NoArgsConstructor
public class StndRehearingStatus implements Serializable {

    private static final long serialVersionUID = 8734742603139885384L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "REHEARING_STATUS_ID")
    private long rehearingStatusId;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Column(name = "CREATE_TS")
    private Timestamp createTs;

    @Column(name = "CREATE_USER_ID")
    private BigDecimal createUserId;

    @Column(name = "DESCRIPTION_TX")
    private String descriptionTx;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Column(name = "LAST_MOD_TS")
    private Timestamp lastModTs;

    @Column(name = "LAST_MOD_USER_ID")
    private BigDecimal lastModUserId;

    @Column(name = "REHEARING_STATUS_NM")
    private String rehearingStatusNm;

    @OneToMany(mappedBy = "stndRehearingStatus")
    private List<Rehearing> rehearings;

}