package gov.uspto.patent.ptab.common.opsg.domain;

import java.math.BigDecimal;

//import jakarta.validation.Valid;
//import jakarta.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

/**
 * This class is used as return object for the any Transaction call.
 * 
 * @author 2020 DevelopmentTeam
 * 
 */
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class TransactionReturn extends ServiceReturn implements Auditable {

    @JsonProperty("applicationNumberText")
    private String applicationNumber;

    @JsonProperty("examinerNumberText")
    private String examiner;

    @JsonProperty("groupArtUnitNumberText")
    private String gau;

    private String applicationStatus;

    @JsonProperty("referenceIdentifier")
    private BigDecimal secondaryIdentifier;// linked id

    private BigDecimal appealNumber;

    @Valid
    @NotNull(message = "audit cannot be null")
    @JsonProperty("auditData")
    private AuditData audit;

    private LifeCycle lifeCycle;

}
