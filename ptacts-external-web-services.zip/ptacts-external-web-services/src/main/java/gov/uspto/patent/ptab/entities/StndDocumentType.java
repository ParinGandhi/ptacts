package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
//import org.hibernate.annotations.Type;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the STND_DOCUMENT_TYPE database table.
 * 
 */
@Entity
@Table(name = "STND_DOCUMENT_TYPE")
@NamedQuery(name = "StndDocumentType.findAll", query = "SELECT s FROM StndDocumentType s")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StndDocumentType extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "DOCUMENT_TYPE_ID")
    private Long documentTypeId;

    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Column(name = "DOCUMENT_TYPE_CD")
    private String documentTypeCd;

    @Column(name = "DOCUMENT_TYPE_NM")
    private String documentTypeNm;

    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "FILE_SIZE_LIMITATION_QT")
    private BigDecimal fileSizeLimitationQt;

    @Column(name = "FK_DOCUMENT_CATEGORY_ID", insertable = false, updatable = false)
    private BigDecimal fkDocumentCategoryId;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    @Column(name = "PAGE_LIMITATION_QT")
    private BigDecimal pageLimitationQt;

    @Column(name = "SIGNIFICANT_IND")
    private String significantIndicator;

    @Column(name = "PET_FILING_IND")
    private String petFilingInd;

    @Column(name = "EMAIL_DELAYED_IND")
    private String delayedEmailIndicator;

    @Column(name = "DISPLAY_NM")
    private String displayName;

    @Column(name = "JOINDER_CHECK_IND")
    private String joinderCheckInd;

    @Lob
    //TODO: check if needed
//    @Type(type = "text")
    @Column(name = "CUSTOM_ATTRIBUTES")
    private String customAttributes;

    @OneToMany(mappedBy = "stndDocumentType")
    private List<Document> documents;

    @ManyToOne
    @JoinColumn(name = "FK_DOCUMENT_CATEGORY_ID")
    private StndDocumentCategory stndDocumentCategory;

    @OneToMany(mappedBy = "stndDocumentType")
    private List<StndDocumentTypeRole> stndDocumentTypeRoles;

}