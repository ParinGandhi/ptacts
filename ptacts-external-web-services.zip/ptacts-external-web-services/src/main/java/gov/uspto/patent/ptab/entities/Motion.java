package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Version;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the MOTION database table.
 * 
 */
@Entity
@NamedQuery(name = "Motion.findAll", query = "SELECT m FROM Motion m")
@Getter
@Setter
@NoArgsConstructor
public class Motion extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MOTION_SEQ")
    @SequenceGenerator(name = "MOTION_SEQ", sequenceName = "MOTION_SEQ", allocationSize = 1)
    @Column(name = "MOTION_ID")
    private Long motionId;

    @Column(name = "FK_PROCEEDING_ID")
    private Long fkProceedingId;

    @Column(name = "FK_MOTION_TYPE_ID")
    private Long fkMotionTypeId;

    @Column(name = "FK_MOTION_STATUS_ID")
    private Long fkMotionStatusId;

    @Column(name = "FK_REQUESTOR_TYPE_ID")
    private Long fkRequestorId;

    @Column(name = "FK_PARENT_MOTION_ID")
    private Long fkParentMotionId;

    @Column(name = "AUTHORIZATION_CT")
    private String authorizationCt;

    @Column(name = "COMMENT_TX")
    private String commentTx;

    @Column(name = "DN_MOTION_DOCUMENT_ID")
    private BigDecimal dnMotionDocumentId;

    @Column(name = "FILED_TS")
    protected Date filedTs;

    @Version
    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    @Column(name = "MOTION_STATUS_DT")
    private Date motionStatusDt;

    @Column(name = "USER_DEFINED_MOTION_NM")
    private String userDefinedMotionNm;

    @ManyToOne
    @JoinColumn(name = "FK_MOTION_STATUS_ID", insertable = false, updatable = false)
    private StndMotionStatus stndMotionStatus;

    @ManyToOne
    @JoinColumn(name = "FK_MOTION_TYPE_ID", insertable = false, updatable = false)
    private StndMotionType stndMotionType;

    @ManyToOne
    @JoinColumn(name = "FK_REQUESTOR_TYPE_ID", insertable = false, updatable = false)
    private StndRequestorType stndRequestorType;

    @ManyToOne
    @JoinColumn(name = "FK_PROCEEDING_ID", insertable = false, updatable = false)
    private ProceedingEntity proceeding;

    @OneToMany(mappedBy = "motion")
    private List<MotionArtfctSubmn> motionArtfctSubmns;

}
