
package gov.uspto.patent.ptab.common.opsg.domain;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.uspto.patent.ptab.utils.EpochDeserializer;
import gov.uspto.patent.ptab.utils.EpochSerializer;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Description of LifeCycle.
 * 
 * @author 2020 Development Team
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class LifeCycle {
    @JsonSerialize(using = EpochSerializer.class)
    @JsonDeserialize(using = EpochDeserializer.class)
    private Date beginDate;
    @JsonSerialize(using = EpochSerializer.class)
    @JsonDeserialize(using = EpochDeserializer.class)
    private Date endDate;

}
