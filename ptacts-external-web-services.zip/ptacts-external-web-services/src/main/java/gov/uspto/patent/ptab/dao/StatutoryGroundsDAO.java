package gov.uspto.patent.ptab.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import gov.uspto.patent.ptab.domain.StatutoryGround;
import gov.uspto.patent.ptab.entities.StndStatutoryGround;

/**
 * This class is used as a data access layer for Statutory Ground details
 * 
 * @author 2020 development team
 *
 */
@Repository("statutoryGroundsDAO")
public class StatutoryGroundsDAO {

    @Autowired
    private SessionFactory sessionFactory;

    /**
     * Initializing the session factory which will be used for all transactions within business layer
     */
    private Session currentSession() {
        return sessionFactory.getCurrentSession();
    }

    /**
     * This method returns all Statutory ground and is data access layer
     * 
     * @return
     */

    public List<StatutoryGround> getStatutoryGrounds() {
        final Query<StndStatutoryGround> query = currentSession().createNamedQuery("StndStatutoryGround.findAll",
                StndStatutoryGround.class);
        List<StndStatutoryGround> stndStatutoryGrounds = query.getResultList();
        return prepareStatutoryGroundsInfo(stndStatutoryGrounds);
    }

    /**
     * This method will prepare Statutory ground details for response
     * 
     * @param stndStatutoryGrounds
     * @return
     */
    private List<StatutoryGround> prepareStatutoryGroundsInfo(List<StndStatutoryGround> stndStatutoryGrounds) {
        List<StatutoryGround> statutoryGroundsResponse = new ArrayList<>();
        for (StndStatutoryGround stndStatutoryGround : stndStatutoryGrounds) {
            StatutoryGround statutoryGround = new StatutoryGround();
            statutoryGround.setId(stndStatutoryGround.getStatutoryGroundId());
            statutoryGround.setCode(stndStatutoryGround.getStatutoryGroundCd());
            statutoryGround.setDescription(stndStatutoryGround.getDescriptionTx());
            statutoryGroundsResponse.add(statutoryGround);
        }
        return statutoryGroundsResponse;
    }

}
