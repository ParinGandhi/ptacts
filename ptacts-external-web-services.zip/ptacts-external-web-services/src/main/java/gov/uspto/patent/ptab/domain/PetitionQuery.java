package gov.uspto.patent.ptab.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PetitionQuery {
    private Long petitionIdentifier;
    private String proceedingNumberText;
}
