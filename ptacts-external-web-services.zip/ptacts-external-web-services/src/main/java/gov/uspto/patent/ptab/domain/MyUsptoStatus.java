package gov.uspto.patent.ptab.domain;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class MyUsptoStatus {

    private boolean gainAccess;
    private String message;
    private String previousMyUsptoStatus;
    private String currentMyUsptoStatus;
    private String previousPTACTSStatus;
    private String currentPTACTSStatus;
    private ExternalUserDetails externalUserDetails;
}
