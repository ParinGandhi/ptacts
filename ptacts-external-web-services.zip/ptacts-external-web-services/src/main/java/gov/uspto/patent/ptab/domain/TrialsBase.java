package gov.uspto.patent.ptab.domain;

import lombok.Data;

@Data
public class TrialsBase {

    private String proceedingCoreId;
    private String proceedingSupplementaryId;
    private String proceedingType;

}
