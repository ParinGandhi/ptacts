package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the ARTIFACT_SUBMISSION database table.
 */
@Entity
@Table(name = "ARTIFACT_SUBMISSION")
@NamedQuery(name = "ArtifactSubmission.findAll", query = "SELECT a FROM ArtifactSubmission a")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ArtifactSubmission extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "ARTIFACT_SUBMISSION_SEQ", sequenceName = "ARTIFACT_SUBMISSION_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "ARTIFACT_SUBMISSION_SEQ")
    @Column(name = "ARTIFACT_SUBMISSION_ID")
    private Long artifactSubmissionId;

    @Column(name = "FK_PROCEEDING_ID")
    private Long fkProceedingId;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    @OneToMany(mappedBy = "artifactSubmission", cascade = CascadeType.ALL)
    private List<ProceedingArtifact> proceedingArtifacts;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "FK_PROCEEDING_ID", insertable = false, updatable = false)
    private ProceedingEntity proceeding;

    @OneToOne(mappedBy = "artifactSubmission", cascade = CascadeType.ALL)
    private ArtifactSubmissionStatus artifactSubmissionStatuses;

}