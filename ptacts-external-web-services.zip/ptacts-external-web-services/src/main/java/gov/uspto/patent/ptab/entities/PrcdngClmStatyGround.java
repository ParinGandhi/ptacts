package gov.uspto.patent.ptab.entities;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the PRCDNG_CLM_STATY_GROUND database table.
 */
@Entity
@Table(name = "PRCDNG_CLM_STATY_GROUND")
@NamedQuery(name = "PrcdngClmStatyGround.findAll", query = "SELECT p FROM PrcdngClmStatyGround p")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PrcdngClmStatyGround extends AbstractAuditEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PRCDNG_CLM_STATY_GROUND_SEQ")
    @SequenceGenerator(name = "PRCDNG_CLM_STATY_GROUND_SEQ", sequenceName = "PRCDNG_CLM_STATY_GROUND_SEQ", allocationSize = 1)
    @Column(name = "PRCDNG_CLM_STATY_GROUND_ID")
    private Long prcdngClmStatyGroundId;

    @Column(name = "CLAIM_DISPOSITION_CT")
    private String claimDispositionCt;

    @Column(name = "FK_PROCEEDING_CLAIM_ID")
    private long fkProceedingClaimId;

    @Column(name = "FK_STATUTORY_GROUND_ID")
    private long fkStatGroundId;

    @Column(name = "FK_INST_DCSN_TYPE_ID")
    private Long fkInstDcsnTypeId;

    @Column(name = "FK_FINAL_WRITTEN_DCSN_ID")
    private Long fkFinalWrtnDcsnId;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    @ManyToOne
    @JoinColumn(name = "FK_PROCEEDING_CLAIM_ID", insertable = false, updatable = false)
    private ProceedingClaim proceedingClaim;

    @ManyToOne
    @JoinColumn(name = "FK_FINAL_WRITTEN_DCSN_ID", insertable = false, updatable = false)
    private StndFinalWrittenDcsn stndFinalWrittenDcsn;

    @ManyToOne
    @JoinColumn(name = "FK_INST_DCSN_TYPE_ID", insertable = false, updatable = false)
    private StndInstDcsnType stndInstDcsnType;

    @ManyToOne
    @JoinColumn(name = "FK_STATUTORY_GROUND_ID", insertable = false, updatable = false)
    private StndStatutoryGround stndStatutoryGround;

    @OneToMany(mappedBy = "prcdngClmStatyGround")
    private List<PrcdngStatyGrndClmRsn> prcdngStatyGrndClmRsns;

}