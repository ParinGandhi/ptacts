package gov.uspto.patent.ptab.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import gov.uspto.patent.ptab.entities.ProceedingParty;

/**
 * 
 * @author 2020 development team
 *
 */

@Repository
public interface ProceedingPartyRepository extends JpaRepository<ProceedingParty, Long> {

    List<ProceedingParty> findAllByFkProceedingId(BigDecimal proceedingId);

    @Query("select pp from ProceedingParty pp where pp.fkProceedingPartyGroupId = (?1)")
    List<ProceedingParty> getAllPartyDetails(final Long fkProceedingPartyGroupId);

    ProceedingParty findAllByFkProceedingIdAndFkPartyIdAndFkPrcdngPartyTypeCd(BigDecimal proceedingId, BigDecimal fkPartyId,
            String partyTypeCd);

    ProceedingParty findByProceedingPartyIdAndFkProceedingId(Long proceedingPartyId, Long proceedingId);

    ProceedingParty findByProceedingPartyId(Long proceedingId);

    @Query(value = "delete proceeding_party where proceeding_party_id=:identifier", nativeQuery = true)
    void deleteById(@Param("identifier") String identifier);

    @Query(value = "SELECT MAX(pp.rank_no) FROM proceeding_party pp where pp.FK_PROCEEDING_ID = (?1) and "
            + "pp.FK_PRCDNG_PARTY_TYPE_CD = (?2) " + "and pp.FK_PROCEEDING_PARTY_GROUP_ID = (?3)", nativeQuery = true)
    Long getCurrentRankNumber(Long proceedingPartyId, final String partyTypeCode, final Long fkProceedingPartyGroupId);

    @Query("select pp from ProceedingParty pp  "
            + "where pp.proceeding.proceedingId = (?1) and pp.fkProceedingPartyGroupId = (?2) ")
    List<ProceedingParty> getAllPartyDetails(final Long proceedingId, final Long fkProceedingPartyGroupId);

    @Query("select pp from ProceedingParty pp where pp.party.partyId in "
            + "(select ip.fkPartyId from IndividualPartyEntity ip where ip.fkApplicationUserId = (?1)) "
            + "AND pp.proceeding.proceedingId =(?2) " + "AND pp.proceedingPartyGroup.proceedingPartyGroupId = (?3) ")
    List<ProceedingParty> getAllPartyDetailsFromExternalUser(final Long userId, final Long proceedingId,
            final Long fkProceedingPartyGroupId);

}
