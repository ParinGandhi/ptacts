package gov.uspto.patent.ptab.config;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

import gov.uspto.rbac.util.RBACHeaderFilter;

/**
 * This class is used to configure ReloadableResourceBundleMessageSource to read entries from property files
 * 
 * @author 2020 development team
 *
 */
@Configuration
public class MessageSourceConfig {
    /**
     * Configuration bean for message source
     * 
     * @return
     */
    @Bean(name = "messageSource")
    public ReloadableResourceBundleMessageSource reloadableResourceBundleMessageSource() {
        final ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
        messageSource.setBasename("classpath:ptab_application_messages");
        messageSource.setDefaultEncoding("UTF-8");
        return messageSource;
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Bean
    public FilterRegistrationBean rbacHeaderFilter() {
        final FilterRegistrationBean registrationBean = new FilterRegistrationBean();
        registrationBean.setFilter(new RBACHeaderFilter());
        registrationBean.setName("RBACHeaderFilter");
        registrationBean.addUrlPatterns("/*");
        return registrationBean;
    }
}
