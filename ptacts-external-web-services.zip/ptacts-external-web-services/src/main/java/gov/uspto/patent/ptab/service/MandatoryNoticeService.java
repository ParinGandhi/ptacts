package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;
import static org.springframework.http.HttpStatus.BAD_REQUEST;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.MandatoryNotice;
import gov.uspto.patent.ptab.domain.ProceedingParties;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MandatoryNoticeService {

    private static final String MN_NOTICE_UPDATE_ERROR_MESSAGE = "Mandatory notice submission update failed. Please try again or contact P-TACTS Support.";
    private static final String MN_NOTICE_CREATION_ERROR_MESSAGE = "Mandatory notice submission failed. Please try again or contact P-TACTS Support.";
    private static final String MN_NOTICE_CREATE_URL = "MN_NOTICE_CREATE_URL";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    private static final String MANDATORY_NOTICE_URL = "MANDATORY_NOTICE_URL";
    private static final String PROXY_USER_ID = "proxy-user-id";
    private static final String HEADER_VALUE_APPL_JSON = "application/json;charset=UTF-8";
    private static final String HEADER_NAME_ACCEPT = "Accept";
    private static final String USER_NAME_HEADER_KEY = "user-name";

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private PTABBusinessUtils ptabBusinessUtils;

    @Autowired
    private HttpServletRequest httpServletRequest;

    @SuppressWarnings("serial")
    @Transactional
    public MandatoryNotice createMandatoryNotice(@NotNull final MandatoryNotice mandatoryNotice) {

        try {
            final String mnNoticeCreateUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                    MN_NOTICE_CREATE_URL);
            notFoundIfNull(mnNoticeCreateUrl, "mandatory notice create url");
            final String userName = ptabBusinessUtils.getLoggedInUserId();
            final String proxyUserId = (String) httpServletRequest.getAttribute(PROXY_USER_ID);
            log.error("The proxy internal user id value is {} ", proxyUserId);
            final HttpHeaders headers = new HttpHeaders();
            headers.add(HEADER_NAME_ACCEPT, HEADER_VALUE_APPL_JSON);
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.add(USER_NAME_HEADER_KEY, userName);
            if (StringUtils.isNotBlank(proxyUserId)) {
                mandatoryNotice.setInternalUserSubmitter(proxyUserId);
            }

            final ResponseEntity<MandatoryNotice> response = restServiceClient.invokeWebService(mnNoticeCreateUrl,
                    mandatoryNotice, HttpMethod.POST, MandatoryNotice.class, headers);
            if (response.getStatusCode().is2xxSuccessful()) {
                log.error("Documents submitted successfully");
            } else {
                throw new PTABException(BAD_REQUEST, new ErrorPayload(MN_NOTICE_CREATION_ERROR_MESSAGE));
            }
            return response.getBody();

        } catch (final HttpClientErrorException | PTABException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(BAD_REQUEST, new ErrorPayload(MN_NOTICE_CREATION_ERROR_MESSAGE));
        }
    }

    @Transactional
    public ProceedingParties updateMandatoryNoticeDetails(@NotNull final ProceedingParties proceedingParties) {

        final String mnNoticeUpdateUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                MANDATORY_NOTICE_URL);
        notFoundIfNull(mnNoticeUpdateUrl, "mandatory notice create url");
        final String userName = ptabBusinessUtils.getLoggedInUserId();
        try {
            final ResponseEntity<ProceedingParties> response = restServiceClient.callPTABExternalServiceURL(mnNoticeUpdateUrl,
                    proceedingParties, HttpMethod.PUT, ProceedingParties.class, userName);
            if (response.getStatusCode().is2xxSuccessful()) {
                log.error("Documents submitted successfully");
            } else {
                throw new PTABException(BAD_REQUEST, new ErrorPayload(MN_NOTICE_UPDATE_ERROR_MESSAGE));
            }
            return response.getBody();
        } catch (final HttpClientErrorException | PTABException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(BAD_REQUEST, new ErrorPayload(MN_NOTICE_CREATION_ERROR_MESSAGE));
        }

    }
}
