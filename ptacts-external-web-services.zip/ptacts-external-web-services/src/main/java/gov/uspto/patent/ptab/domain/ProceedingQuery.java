package gov.uspto.patent.ptab.domain;

import lombok.Data;

@Data
public class ProceedingQuery {

    private String proceedingNumber;
    private String patentNum;
    private String applicationNumber;

}
