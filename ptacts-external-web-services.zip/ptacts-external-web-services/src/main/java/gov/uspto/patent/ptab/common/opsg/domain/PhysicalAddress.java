/*******************************************************************************
 * 2016, All rights reserved.
 *******************************************************************************/
package gov.uspto.patent.ptab.common.opsg.domain;

//import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * Description of PhysicalAddress used primarily in interested parties.
 *
 * @author 2020 Development Team
 */
@Data
@JsonInclude(Include.NON_NULL)
public class PhysicalAddress {

    private Long addressIdentifier;

    private String nameLineOneText;

    @Size(min = 0, max = 50, message = "NameLineTwo should be 0 to 50 chars")
    private String nameLineTwoText;

    @Size(min = 1, max = 50, message = "StreetLineOne should be 1 to 50 chars")
    private String addressLineOneText;

    @Size(min = 0, max = 50, message = "StreetLineTwo should be 0 to 50 chars")
    private String addressLineTwoText;

    @Size(min = 0, max = 40, message = "City should be 0 to 40 chars")
    private String cityName;

    @Size(min = 0, max = 3, message = "StateCode should be 0 to 3 chars")
    private String geographicRegionCode;

    private String geographicRegionName;

    @Size(min = 0, max = 2, message = "CountryCode should be 0 to 2 chars")
    private String countryCode;

    private String countryName;

    @Size(min = 0, max = 20, message = "Postal code should be 0 to 20 chars")
    private String postalCode;

    private String addressCategory;

    private AuditData audit;

}
