package gov.uspto.patent.ptab.entities;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the PRCDNG_APL_ARTFCT_SUBMN database table.
 * 
 */
@Entity
@Table(name = "PRCDNG_APL_ARTFCT_SUBMN")
@NamedQuery(name = "PrcdngAplArtfctSubmn.findAll", query = "SELECT p FROM PrcdngAplArtfctSubmn p")
@Getter
@Setter
@NoArgsConstructor
public class PrcdngAplArtfctSubmn extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PRCDNG_APL_ARTFCT_SUBMN_SEQ")
    @SequenceGenerator(name = "PRCDNG_APL_ARTFCT_SUBMN_SEQ", sequenceName = "PRCDNG_APL_ARTFCT_SUBMN_SEQ", allocationSize = 1)
    @Column(name = "PRCDNG_APL_ARTFCT_SUBMN_ID")
    private long prcdngAplArtfctSubmnId;

    @ManyToOne
    @JoinColumn(name = "FK_ARTIFACT_SUBMISSION_ID")
    private ArtifactSubmission artifactSubmission;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    @ManyToOne
    @JoinColumn(name = "FK_PROCEEDING_APPEAL_ID")
    private ProceedingAppeal proceedingAppeal;

}