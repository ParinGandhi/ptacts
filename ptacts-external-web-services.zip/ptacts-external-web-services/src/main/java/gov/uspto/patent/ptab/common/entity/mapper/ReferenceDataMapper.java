package gov.uspto.patent.ptab.common.entity.mapper;

import java.util.ArrayList;
import java.util.List;

import gov.uspto.patent.ptab.domain.ReferenceType;
import gov.uspto.patent.ptab.entities.StndProceedingType;

/**
 * The Mapper class for converting JPA entity into Response object
 * 
 * @author 2020 development team
 * 
 */
public final class ReferenceDataMapper {

    /**
     * default private constructor
     */
    private ReferenceDataMapper() {

    }

    /**
     * This method convert TrialTypes into ReferenceType object
     *
     * @param stndProceedingTypeList - trial types
     */
    public static List<ReferenceType> getAllTrialTypes(final List<StndProceedingType> stndProceedingTypeList) {
        final List<ReferenceType> referenceTypes = new ArrayList<>();
        for (final StndProceedingType stndProceedingType : stndProceedingTypeList) {
            final ReferenceType referenceType = new ReferenceType();
            referenceType.setCode(stndProceedingType.getProceedingTypeCd());
            referenceType.setDescriptionText(stndProceedingType.getProceedingTypeDescTx());
            referenceType.setIdentifier(stndProceedingType.getProceedingTypeId());
            referenceTypes.add(referenceType);
        }
        return referenceTypes;
    }

}
