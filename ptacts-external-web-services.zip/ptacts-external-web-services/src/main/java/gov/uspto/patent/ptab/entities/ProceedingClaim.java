package gov.uspto.patent.ptab.entities;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the PROCEEDING_CLAIM_NUM database table.
 */
@Entity
@Table(name = "PROCEEDING_CLAIM")
@NamedQuery(name = "ProceedingClaim.findAll", query = "SELECT p FROM ProceedingClaim p")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ProceedingClaim extends AbstractAuditEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "PROCEEDING_CLAIM_SEQ", sequenceName = "PROCEEDING_CLAIM_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PROCEEDING_CLAIM_SEQ")
    @Column(name = "PROCEEDING_CLAIM_ID")
    private long proceedingClaimId;

    @Column(name = "CLAIM_NO")
    private String claimNo;

    @Column(name = "FINAL_WRITTEN_DCSN_CMNT_TX")
    private String finalWrittenDcsnCmntTx;

    @Column(name = "FK_PROCEEDING_ID")
    private long fkProceedingId;

    @Column(name = "INST_DCSN_CMNT_TX")
    private String instDcsnCmntTx;

    @Column(name = "FK_CLAIM_FINAL_WRITTEN_DCSN_ID")
    private Long fkclaimFinalWrittenDcsnId;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    @OneToMany(mappedBy = "proceedingClaim")
    private List<PrcdngClmStatyGround> prcdngClmStatyGrounds;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "FK_CLAIM_FINAL_WRITTEN_DCSN_ID", insertable = false, updatable = false)
    private StndFinalWrittenDcsn stndFinalWrittenDcsn;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "FK_PROCEEDING_ID", insertable = false, updatable = false)
    private ProceedingEntity proceeding;

}