package gov.uspto.patent.ptab.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import gov.uspto.patent.ptab.constants.AppealStatusEnum;
import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class AppealDetails {

    private Long proceedingAppealId;
    private Long appealTypeId;
    private String appealTypeNm;
    private String requestorTypeName;
    private String userRole;
    private Long appealStatusId;
    private String appealStatusCd;
    private String appealNoticeDt;
    private String courtDecisionDt;
    private String courtMandateDt;
    private String exteralCourtDecisionBy;
    private Long proceedingId;
    private String proceedingNo;
    private String userPartyGroupType;
    private String filingDate;
    private List<PetitionDocument> appealDocuments;

    public boolean removeInitiatedAppealNotSameParty() {
        boolean isInitiatedCase = appealStatusId.equals(AppealStatusEnum.INITIATED.getAppealStatusId());
        return !isInitiatedCase || (requestorTypeName.equalsIgnoreCase(userPartyGroupType) && isInitiatedCase);
    }
}
