package gov.uspto.patent.ptab.utils;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * This class has null check validation methods
 *
 * @author 2020 development team
 *
 */
@Slf4j
public final class InputValidationsUtil {
    /**
     * private constructor to hide the implicit public one
     */
    private InputValidationsUtil(){
        
    }
    
    /**
     * This method is used to check null and trim the input string of Object Type
     *
     * @param inputStr - Input string to be trimmed
     * @return
     */
    public static Object checkNullForObject(final Object inputStr) {
        return null != inputStr ? inputStr : StringUtils.EMPTY;
    }
    
    /**
     * This method is used to check null and trim the input string of Object Type
     *
     * @param inputStr - Input string to be trimmed
     * @return
     */
    public static String checkNullAndTrim(final Object inputStr) {
        return null != inputStr ? String.valueOf(inputStr).trim() : null;
    }

    /**
     * This method splits the input String at the input splitChar into a list of integer
     *
     * @param inputStr - Input String to split
     * @param splitChar - Split char
     * @return
     */
    public static List<Integer> splitStringAsIntListWithoutExitingOnErr(final String inputStr, final String splitChar) {
        List<Integer> returnList = null;
        try {
            if (StringUtils.isNotBlank(inputStr) && StringUtils.isNotBlank(splitChar)) {
                returnList = Arrays.asList(inputStr.split(splitChar)).stream().map(Integer::parseInt)
                        .collect(Collectors.toList());
            }
        } catch (final RuntimeException e) {
            log.error("Error occured while Splitting the input string " + inputStr + " into Integer List", e);
        }
        return returnList;

    }

    /**
     * This method is used to check null and trim the input integer of Object Type
     *
     * @param inputInt- Input integer object to be converted to int
     * @return
     */
    public static Integer checkNullAndFetchInteger(final Object inputInt) {
        return null != inputInt ? Integer.parseInt(inputInt.toString()) : null;
    }

    /**
     * This method is used to check null and trim the input bigDecimal of Object Type
     *
     * @param inputBig - Input BigDecimal object to be converted to BigDecimal
     * @param index - defines the arrayth index.
     * @return
     */
    public static BigDecimal checkNullAndFetchBigDecimal(final Object[] inputBig, final int index) {
        return null != checkNullAndTrim(inputBig[index]) ? (BigDecimal) (inputBig[index]) : null;
    }
    
    /**
     * This method is used to check null and trim the input bigDecimal of Object Type
     *
     * @param inputBig - Input BigDecimal object to be converted to BigDecimal
     * @param index - defines the arrayth index.
     * @return
     */
    public static BigDecimal checkNullAndFetchBigDecimal(final Object inputBig) {
        return null != inputBig ? (BigDecimal) (inputBig) : null;
    }

    /**
     * Method to convert object to date.
     *
     * @param obj - object to be converted to Date
     * @param dateFormat - The format of the date to be considered.
     * @return
     */
    public static Date checkDateNullAndConvert(final Object obj, final String dateFormat) {
        return null == obj ? null : DateUtility.formatStringToDate(dateFormat, String.valueOf(obj));
    }

}
