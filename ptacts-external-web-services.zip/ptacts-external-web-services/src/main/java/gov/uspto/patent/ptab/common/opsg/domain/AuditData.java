
package gov.uspto.patent.ptab.common.opsg.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Description of Audit.
 * 
 * @author 2020 Development Team
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class AuditData {

    private String lastModifiedUser;

    private Long lastModifiedTime;

}
