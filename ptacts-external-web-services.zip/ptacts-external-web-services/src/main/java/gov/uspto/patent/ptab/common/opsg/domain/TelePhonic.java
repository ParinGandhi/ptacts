/*******************************************************************************
 * 2016, All rights reserved.
 *******************************************************************************/
package gov.uspto.patent.ptab.common.opsg.domain;

//import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * Description of TelePhonic primarily used in interested parties.
 * 
 * @author 2020 Development Team
 */
@Data
@JsonInclude(Include.NON_NULL)
public class TelePhonic {

    private Long telephoneIdentifier;

    @Size(min = 1, max = 25, message = "number should be 1 to 25 chars")
    private String telecommunicationNumber;

    @Size(min = 0, max = 5, message = "type should be 0 to 5 chars")
    private String extensionNumber;

    @Size(min = 1, max = 3, message = "type should be 1 to 3 chars")
    private String usageTypeCategory;

    private String cityName;

    private String countryCode;

    private String countryName;

    private boolean isDeleteExistingTelepone;

}
