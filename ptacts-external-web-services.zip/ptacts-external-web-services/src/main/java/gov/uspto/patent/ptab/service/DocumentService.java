package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.DocumentQuery;
import gov.uspto.patent.ptab.domain.DocumentsQuery;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.domain.PetitionFile;
import gov.uspto.patent.ptab.entities.ProceedingEntity;
import gov.uspto.patent.ptab.repository.ProceedingRepository;
import gov.uspto.patent.ptab.utils.DocumentUtils;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;

/**
 * This class is responsible for storing the documents in mount storage using File API's and submit the documents into content
 * management system using the content management API's
 *
 * @author 2020 development team
 *
 */
@Component
@Slf4j
public class DocumentService {

    private static final String USER_IS_NOT_AUTHORIZED_TO_DOWNLOAD_THE_DOCUMENT = "User is not authorized to download the document";
    private static final String DOCUMENT_UPLOAD_URL = "DOCUMENT_UPLOAD_URL";
    private static final String GET_DOCUMENT_URL = "GET_DOCUMENT_URL";
    private static final String DOCUMENT_DOWNLOAD_URL = "DOCUMENT_DOWNLOAD_URL";
    private static final String FILE = "file";
    private static final String USER_NAME = "user-name";
    private static final String SYSTEM_USER = "SYSTEM_USER";
    private static final String PTAB_CASE_INIT = "PTAB_CASE_INIT";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    private static final String ALL_ARTIFACTS_URL_CODE = "ALL_ARTIFACTS_URL_V1";
    private static final String ARTIFACT_RETRIEVE_URL = "artifact retrieve url";
    private static final String PTACTS_FILTER_ATTRIBUTES = "PTACTS_FILTER_ATTRIBUTES";
    private static final String PTACTS_EXCP_MESSAGE = "PTACTS_EXCP_MESSAGE";
    private static final String ALLOWED_FILE_EXTENSIONS = "ALLOWED_FILE_EXTENSIONS_";
    private static final String INVALID_ARTIFACT_MSG = "INVALID_ARTIFACT_MSG_";

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Autowired
    private ProceedingRepository proceedingRepository;

    @Autowired
    private ExternalUserService externalUserService;

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private DocumentUtils docUtils;

    /**
     * This method is used to store the document into mount location
     *
     * @param proceedingId - petition identifier
     * @param file - multipart file object to be loaded tin mount
     * @param paperType
     * @throws IOException
     *
     */
    @Transactional
    public PetitionFile storeDocument(@NotNull final Long proceedingId, final MultipartFile file, final String paperType)
            throws IOException {

        if (!docUtils.checkforPassWordEncrypter(file.getInputStream())) {
            throw new PTABException(HttpStatus.UNPROCESSABLE_ENTITY,
                    new ErrorPayload("The document cannot be encrypted or password-protected."));
        }
        final String allowedFileExtension = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTACTS_FILTER_ATTRIBUTES,
                ALLOWED_FILE_EXTENSIONS + paperType.toUpperCase());

        log.info(StringUtils.substring(file.getOriginalFilename(), file.getOriginalFilename().lastIndexOf(".") + 1));
        log.info(allowedFileExtension);
        if (StringUtils.isNotBlank(allowedFileExtension) && StringUtils.isNotBlank(file.getOriginalFilename())
                && !StringUtils.containsIgnoreCase(allowedFileExtension, StringUtils.substring(file.getOriginalFilename(),
                        file.getOriginalFilename().lastIndexOf(".") + 1))) {
            throw new PTABException(HttpStatus.UNSUPPORTED_MEDIA_TYPE,
                    new ErrorPayload(codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTACTS_EXCP_MESSAGE,
                            INVALID_ARTIFACT_MSG + paperType.toUpperCase())));
        }
        final String documentUploadUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                DOCUMENT_UPLOAD_URL);
        notFoundIfNull(documentUploadUrl, "Document upload Url");

        final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(systemUserName, "system user name");
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.add(USER_NAME, systemUserName);
        final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add(FILE, file.getResource());
        final HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);
        final RestTemplate restTemplate = new RestTemplate();
        log.info("calling common services for storing docuemt");
        ResponseEntity<PetitionFile> response = null;
        try {
            response = restTemplate.postForEntity(String.format(documentUploadUrl, proceedingId), requestEntity,
                    PetitionFile.class);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }

        return null != response ? response.getBody() : null;
    }

    /**
     * This method is used to store the document into mount location
     *
     * @param proceedingId - petition identifier
     * @param documentsQuery - artifact Id of file to be loaded tin mount
     *
     */
    @Transactional
    public ResponseEntity<InputStreamResource> getDocument(final Long proceedingId, final DocumentsQuery documentsQuery) {
        ResponseEntity<InputStreamResource> streamSource = null;
        final String documentUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                GET_DOCUMENT_URL);
        notFoundIfNull(documentUrl, "document url");
        notFoundIfNull(documentsQuery.getFileName(), "document file name");
        final String url = String.format(documentUrl, proceedingId);
        final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(systemUserName, "system user name");
        final RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(StandardCharsets.UTF_8));
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.add(USER_NAME, systemUserName);
        try {
            log.info("calling common services for getting the document");
            final ResponseEntity<Resource> response = restTemplate.exchange(
                    url + "?fileName=" + documentsQuery.getFileName(), HttpMethod.GET, new HttpEntity<>(headers),
                    Resource.class);
            if (response.getStatusCode().is2xxSuccessful()) {
                final MediaType mediaType = response.getHeaders().getContentType();
                final InputStream inputStream = response.getBody().getInputStream();
                final InputStreamResource inputStreamResource = new InputStreamResource(inputStream);
                streamSource = ResponseEntity.ok().contentType(mediaType).body(inputStreamResource);
            } else if (response.getStatusCode().is4xxClientError()) {
                throw new PTABException(HttpStatus.BAD_REQUEST,
                        new ErrorPayload("Error occurred while downloading the document from the mount location"));
            } else if (response.getStatusCode().is5xxServerError()) {
                throw new PTABException(HttpStatus.BAD_REQUEST, new ErrorPayload(
                        "Internal server error occurred while downloading the document from the mount location"));
            }

        } catch (final HttpClientErrorException | IOException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(HttpStatus.BAD_REQUEST, new ErrorPayload(ex.getLocalizedMessage()));
        }
        return streamSource;

    }

    /**
     * Method used to download the documents
     *
     * @param proceedingId - proceeding ID
     * @param documentQuery - document query
     * @throws IOException
     *
     */
    @Transactional
    public ResponseEntity<InputStreamResource> downloadDocument(@NotNull final Long proceedingId,
            final DocumentQuery documentQuery, final boolean isPublicAccess) throws IOException {

        final ProceedingEntity proceedingEntity = proceedingRepository.getProceeding(proceedingId);
        final PetitionDocument petitionDocument = getDocumentAvailability(Long.valueOf(documentQuery.getArtifactId()));
        final String documentAvailabilty = StringUtils.trim(petitionDocument.getAvailability());
        if (!isPublicAccess) {
            final String partyType = externalUserService.getPrcdPartyGroupType(proceedingEntity.getProceedingNo());
            validationForDocumentAvailabilty(partyType, petitionDocument, documentAvailabilty);
        } else {
            if (!StringUtils.equalsIgnoreCase(documentAvailabilty, "Public")) {
                final String partyType = externalUserService.getPrcdPartyGroupType(proceedingEntity.getProceedingNo());
                validationForDocumentAvailabilty(partyType, petitionDocument, documentAvailabilty);

            }
        }
        ResponseEntity<InputStreamResource> streamSource = null;
        final String documentDownloadUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                DOCUMENT_DOWNLOAD_URL);
        notFoundIfNull(documentDownloadUrl, "Document download Url");
        final String extUrl = String.format(documentDownloadUrl, proceedingId);
        final String url = externalServiceUriGenerator.getDownloadDocumentUrl(documentQuery, extUrl);

        final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(systemUserName, "system user name");

        try {
            final RestTemplate restTemplate = new RestTemplate();
            final ResponseEntity<byte[]> fileContentResponse = restTemplate.exchange(url, HttpMethod.GET, null,
                    byte[].class);
            final MediaType mediaType = fileContentResponse.getHeaders().getContentType();
            final InputStreamResource inputStreamResource = new InputStreamResource(
                    new ByteArrayInputStream(fileContentResponse.getBody()));
            streamSource = ResponseEntity.ok().contentType(mediaType).body(inputStreamResource);

        } catch (final HttpClientErrorException | HttpServerErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return streamSource;

    }

    /**
     * Method used to validate document availability
     *
     * @param partyType
     * @param petitionDocument
     * @param documentAvailabilty
     */
    private void validationForDocumentAvailabilty(final String partyType, final PetitionDocument petitionDocument,
            final String documentAvailabilty) {
        if (StringUtils.equals(documentAvailabilty, StringUtils.trim("Board"))) {
            throw new PTABException(HttpStatus.BAD_REQUEST,
                    new ErrorPayload(USER_IS_NOT_AUTHORIZED_TO_DOWNLOAD_THE_DOCUMENT));
        }
        final String filingPArty = StringUtils.replace(petitionDocument.getFilingParty(), "\\s", "");
        if (StringUtils.equals(documentAvailabilty, StringUtils.trim("Filing party and Board"))
                && !StringUtils.equals(StringUtils.trim(partyType), filingPArty)) {
            throw new PTABException(HttpStatus.BAD_REQUEST,
                    new ErrorPayload(USER_IS_NOT_AUTHORIZED_TO_DOWNLOAD_THE_DOCUMENT));
        }
    }

    /**
     * Method used to get the document availability
     *
     * @param artifactId
     * @return
     */
    private PetitionDocument getDocumentAvailability(final Long artifactId) {

        final String externalArtifactGetUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                ALL_ARTIFACTS_URL_CODE);
        notFoundIfNull(externalArtifactGetUrl, ARTIFACT_RETRIEVE_URL);
        return restServiceClient.callExternalServiceURL(String.format(externalArtifactGetUrl, artifactId), null,
                HttpMethod.GET, PetitionDocument.class);

    }

}
