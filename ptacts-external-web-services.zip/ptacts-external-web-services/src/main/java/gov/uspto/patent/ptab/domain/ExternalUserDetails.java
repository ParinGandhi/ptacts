package gov.uspto.patent.ptab.domain;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import lombok.Data;

@Data
public class ExternalUserDetails  {
    private BigDecimal aplicationUserId;
    private Date beginEffectiveDate;
    private Timestamp createTimestamp;
    private BigDecimal createUserId;
    private String emailAddress;
    private Date endEffectiveDt;
    private String firstName;
    private BigDecimal userStatusId;
    private Timestamp lastLoginTimestamp;
    private Timestamp lastMoTimestamp;
    private BigDecimal lastModifiedUserId;
    private String lastName;
    private BigDecimal lockControlNo;
    private String middleName;
    private String organizationName;
    private String passwordHashText;
    private Date passwordResetDate;
    private String registrationNo;
    private String telephoneNo;
    private BigDecimal unsuccessfulLoginCountQt;
    private Timestamp validationTokenExpirationTs;
    private String validationTokenText;
    private BigDecimal myUsptoStatusId;
}
