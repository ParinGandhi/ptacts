package gov.uspto.patent.ptab.entities;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedNativeQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * This class is used to persist Table Proceeding in PTAB DB
 *
 * @author 2020 Development Team
 *
 *         Note: userCt is CHAR(8); cfkPatronId is CHAR(36)
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@NamedNativeQuery(name = "ProceedingEntity.checkIfProceedingExistsByPrcdNo",
        query = "select count(*) from proceeding where proceeding_no= :proceedingNumber")
@Table(name = "PROCEEDING")
public class ProceedingEntity extends AbstractAuditEntity {

    private static final long serialVersionUID = 3366629972686693442L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PROCEEDING_SEQ")
    @jakarta.persistence.SequenceGenerator(name = "PROCEEDING_SEQ", sequenceName = "PROCEEDING_SEQ", allocationSize = 1)
    @Column(name = "PROCEEDING_ID")
    private Long proceedingId;

    @Column(name = "PROCEEDING_NAME_TX")
    private String proceedingNameTx;

    @Column(name = "PATENT_NO")
    private String patentNo;

    @Column(name = "PROCEEDING_NO")
    private String proceedingNo;

    @Column(name = "PATENT_OWNER_NM")
    private String patentOwnerNm;

    @Column(name = "FISCAL_YEAR_NO")
    private Integer fiscalYearNo;

    @Column(name = "CLAIM_LIST_TX")
    private String claimListTx;

    @Column(name = "CHALLENGED_CLAIM_QT")
    private Integer challengedClaimQt;

    @Column(name = "FK_TERMINATION_TYPE_ID")
    private Integer terminationTypeId;

    @Column(name = "CONFIDENTIALITY_IN")
    private String confidentialityIn;

    @Column(name = "CONTENT_MANAGEMENT_PATH_DIR")
    private String contentManagementPathDir;

    @Column(name = "PROCEEDING_HEADER_TX")
    private String proceedingHeaderTx;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo;

    @Column(name = "PRELIMINARY_RESPONSE_FILED_IN")
    private String preliminaryResponseFiledIn;

    @Column(name = "FK_BOARD_OPINION_ID")
    private String fkBoardOpinionId;

    @Column(name = "FK_INST_DCSN_TYPE_ID")
    private String fkInstDcsnTypeId;

    @Column(name = "AUTHORIZE_PAYMENT_IN")
    private String authorizePaymentIn;

    @Column(name = "INSTITUTED_CLAIM_QT")
    private String institutedClaimQt;

    @Column(name = "SOURCE_SYSTEM_CT")
    private String sourceSytemCt;

    @Column(name = "FK_PROCEEDING_TYPE_ID")
    private String fkProceedingTypeId;

    @ManyToOne
    @JoinColumn(name = "FK_TERMINATION_TYPE_ID", insertable = false, updatable = false)
    private StndTerminationType stndTerminationType;

    @ManyToOne
    @JoinColumn(name = "FK_PROCEEDING_TYPE_ID", insertable = false, updatable = false)
    private StndProceedingType stndProceedingType;

    @ManyToOne
    @JoinColumn(name = "FK_BOARD_OPINION_ID", insertable = false, updatable = false)
    private StndBoardOpinion stndBoardOpinion;

    @ManyToOne
    @JoinColumn(name = "FK_INST_DCSN_TYPE_ID", insertable = false, updatable = false)
    private StndInstDcsnType stndInstDcsnType;

    @OneToMany(mappedBy = "proceeding", cascade = CascadeType.ALL)
    private List<ProceedingMilestone> proceedingMileStones;
}
