package gov.uspto.patent.ptab.common.opsg.domain;

import lombok.Data;

/**
 * This class is used to store Role data
 * 
 * @author 2020 development team
 *
 */
@Data
public class Role {

    private String roleCode;
    private String roleDescription;
}
