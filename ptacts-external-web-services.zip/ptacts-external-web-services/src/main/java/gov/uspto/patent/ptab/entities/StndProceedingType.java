package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the STND_PROCEEDING_TYPE database table.
 * 
 */
@Entity
@Table(name = "STND_PROCEEDING_TYPE")
@NamedQuery(name = "StndProceedingType.findAll", query = "SELECT s FROM StndProceedingType s")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StndProceedingType extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "STND_PROCEEDING_TYPE_PROCEEDINGTYPEID_GENERATOR",
            sequenceName = "STND_PROCEEDING_TYPE_PROCEEDINGTYPEID_GENERATOR", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "STND_PROCEEDING_TYPE_PROCEEDINGTYPEID_GENERATOR")
    @Column(name = "PROCEEDING_TYPE_ID")
    private long proceedingTypeId;

    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Column(name = "DISPLAY_ORDER_SEQUENCE_NO")
    private BigDecimal displayOrderSequenceNo;

    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "PROCEEDING_TYPE_CD")
    private String proceedingTypeCd;

    @Column(name = "PROCEEDING_TYPE_DESC_TX")
    private String proceedingTypeDescTx;

    @OneToMany(mappedBy = "stndProceedingType")
    private List<ProceedingEntity> proceedings;

    @OneToMany(mappedBy = "stndProceedingType")
    private List<StndPrcdngCtStatyGround> stndPrcdngCtStatyGrounds;

}
