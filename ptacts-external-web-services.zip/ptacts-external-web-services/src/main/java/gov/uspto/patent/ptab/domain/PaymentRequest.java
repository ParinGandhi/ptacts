package gov.uspto.patent.ptab.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentRequest {

    private Long paymentId;
    private String proceedingNumberText;
    private String attorneyDocketNumber;
}
