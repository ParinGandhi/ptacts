package gov.uspto.patent.ptab.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import gov.uspto.patent.ptab.entities.ProceedingEntity;
import lombok.Getter;
import lombok.Setter;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * This class is having the details of the petition document
 * 
 * @author 2020 development team
 *
 */
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class ProceedingArtifactDetail {

    private Long petitionIdentifier;
    private String patentNumber;
    private String proceedingNumberText;
    private Long documentNumber;
    private String name;
    private String category;
    private String fileName;
    private String filingParty;
    private String availability;
    private Long exhibitNumber;
    private Long documentTypeIdentifier;
    private String documentTypeCode;
    private String documentTypeDescription;
    private Long filingPartyGroupIdentifier;
    private Long sequenceNumber;
    private String mimeType;
    private Integer pageCount;
    private String contentManagementId;
    private String artifactIdentifer;
    private Long artifactSubmissionIdentifier;
    private Long filingDate;
    private String filingDateString;
    private Long proceedingArtifactIdentifier;
    @JsonIgnore
    private byte[] data;
    private String objectId;
    private String objectType;
    private Long lockControlNumber;
    private Long submitterIdentifier;
    private InputStream inputStream;
    private String documentVersionLabel;
    private long fileSize;
    private String commentText;
    private Audit audit;
    private String errorMessage;
    private String documentAction;
    private String documentStatus;
    private String directionCode;
    private DocumentTypeCustomAttributes documentTypeCustomAttributes;
    private List<String> warningMessageList = new ArrayList<>();
    private ReferenceSummary availablitySummary;
    private ReferenceSummary roleSummary;
    private ReferenceSummary artifactSummary;
    private Long outcomeTypeId;
    private String externalUserUploadIndicator;
    private String submitDocumentIndicator;

    @JsonIgnore
    private String panelNotificationIndicator;

    @JsonIgnore
    private String includeUploadUserIndicator;

    @JsonIgnore
    private RuleSetResponse ruleSetResponse;

    private String significantDocumentIndicator;

    @JsonIgnore
    private ProceedingEntity proceeding;

    @JsonIgnore
    private String orginalCaseNumber;

    @JsonIgnore
    private String delayedEmailIndicator;

    @JsonIgnore
    private String userName;
}
