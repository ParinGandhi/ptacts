package gov.uspto.patent.ptab.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import gov.uspto.patent.ptab.entities.OrganizationPartyEntity;

@Repository
public interface OrganizationPartyRepository extends JpaRepository<OrganizationPartyEntity, Long>{

    @Query(value = "select * from organization_party where fk_party_id= :identifier", nativeQuery = true)
    OrganizationPartyEntity findbyFkPartyId(@Param("identifier") String identifier);

    @Query(value = "delete organization_party where fk_party_id=:identifier", nativeQuery = true)
    void deleteByFkPartyId(@Param("identifier") String identifier);

}
