package gov.uspto.patent.ptab.domain;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CaseStateSummary {

    private Long stateId;
    private String stateName;
    private String subStateName;
}
