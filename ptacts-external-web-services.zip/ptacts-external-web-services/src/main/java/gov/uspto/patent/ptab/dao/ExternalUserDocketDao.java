package gov.uspto.patent.ptab.dao;

import static gov.uspto.patent.ptab.utils.PTABConstants.EIGHT;
import static gov.uspto.patent.ptab.utils.PTABConstants.EIGHTEEN;
import static gov.uspto.patent.ptab.utils.PTABConstants.ELEVEN;
import static gov.uspto.patent.ptab.utils.PTABConstants.FIFTEEN;
import static gov.uspto.patent.ptab.utils.PTABConstants.FIVE;
import static gov.uspto.patent.ptab.utils.PTABConstants.FOUR;
import static gov.uspto.patent.ptab.utils.PTABConstants.FOURTEEN;
import static gov.uspto.patent.ptab.utils.PTABConstants.NINE;
import static gov.uspto.patent.ptab.utils.PTABConstants.NINTEEN;
import static gov.uspto.patent.ptab.utils.PTABConstants.ONE;
import static gov.uspto.patent.ptab.utils.PTABConstants.SEVEN;
import static gov.uspto.patent.ptab.utils.PTABConstants.SEVENTEEN;
import static gov.uspto.patent.ptab.utils.PTABConstants.SIX;
import static gov.uspto.patent.ptab.utils.PTABConstants.SIXTEEN;
import static gov.uspto.patent.ptab.utils.PTABConstants.TEN;
import static gov.uspto.patent.ptab.utils.PTABConstants.THIRTEEN;
import static gov.uspto.patent.ptab.utils.PTABConstants.THREE;
import static gov.uspto.patent.ptab.utils.PTABConstants.TWELVE;
import static gov.uspto.patent.ptab.utils.PTABConstants.TWENTY;
import static gov.uspto.patent.ptab.utils.PTABConstants.TWENTY_FIVE;
import static gov.uspto.patent.ptab.utils.PTABConstants.TWENTY_FOUR;
import static gov.uspto.patent.ptab.utils.PTABConstants.TWENTY_ONE;
import static gov.uspto.patent.ptab.utils.PTABConstants.TWENTY_SIX;
import static gov.uspto.patent.ptab.utils.PTABConstants.TWENTY_THREE;
import static gov.uspto.patent.ptab.utils.PTABConstants.TWENTY_TWO;
import static gov.uspto.patent.ptab.utils.PTABConstants.TWO;
import static gov.uspto.patent.ptab.utils.PTABConstants.ZERO;
import static gov.uspto.patent.ptab.utils.PTABServiceUtils.checkNullAndLong;
import static gov.uspto.patent.ptab.utils.PTABServiceUtils.checkNullAndTrim;
import static gov.uspto.patent.ptab.utils.PTABServiceUtils.checkNullBigDecimal;
import static gov.uspto.patent.ptab.utils.PTABServiceUtils.checkNullDate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

import gov.uspto.patent.ptab.domain.AIAReviewsDocket;
import gov.uspto.patent.ptab.domain.AppealDetails;
import gov.uspto.patent.ptab.domain.ArtifactContent;
import gov.uspto.patent.ptab.domain.Audit;
import gov.uspto.patent.ptab.domain.ExternalUserMotion;
import gov.uspto.patent.ptab.domain.ExternalUserRehearing;
import gov.uspto.patent.ptab.domain.NotificationDetails;
import gov.uspto.patent.ptab.utils.DateUtilityHelper;
import gov.uspto.patent.ptab.utils.PTABConstants;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Parameter;
import jakarta.persistence.PersistenceContext;

@Repository
public class ExternalUserDocketDao {

    private static final Map<String, String> UI_USER_PARTY_GROUP_MAP = Map.of("PATENTOWNER", "PATENT OWNER");
    private static final String USERID = "userId";
    private static final String PRCGNGPARTYGROUPSTATEID = "prcdngPartyGroupStatId";
    private static final String REQUESTOR = "requestorTypeId";
    private static final String PROCEEDINGNO = " and p.proceeding_no like ? ";

    @Autowired
    private SessionFactory sessionFactory;

    @PersistenceContext
    private EntityManager entityManager;

    private Session currentSession() {
        return sessionFactory.getCurrentSession();

    }

    public List<AIAReviewsDocket> getAIAReviews(final String userIdentifier, final List<Long> prcdStateId,
            final List<Long> prcdngPartyGroupStatId) {
        Session session = entityManager.unwrap(Session.class);
        final Query<Object[]> query = session.createNamedQuery("getAIAReviews", Object[].class);
        return extractAIAReviews(userIdentifier, prcdStateId, prcdngPartyGroupStatId, query);
    }

    public List<AIAReviewsDocket> getUnSubmittedAIAReviews(final String userIdentifier, final List<Long> prcdStateId,
            final List<Long> prcdngPartyGroupStatId) {

        final Query<Object[]> query = currentSession().createNamedQuery("getUnSubmittedAIAReviews", Object[].class);
        final List<AIAReviewsDocket> unSubAiaList = extractAIAReviews(userIdentifier, prcdStateId, prcdngPartyGroupStatId,
                query);
        final Map<String, AIAReviewsDocket> unSubAiaMap = unSubAiaList.stream()
                .collect(Collectors.toMap(AIAReviewsDocket::getProceedingNo, b -> b,
                        (oldValue, newValue) -> oldValue.getUserRole() == null ? newValue : oldValue));
        return new ArrayList<>(unSubAiaMap.values());
    }

    private List<AIAReviewsDocket> extractAIAReviews(final String userIdentifier, final List<Long> prcdStateId,
            final List<Long> prcdngPartyGroupStatId, final Query<Object[]> query) {
        query.setParameter(USERID, userIdentifier);
        query.setParameter("prcdStateId", prcdStateId);
        query.setParameter(PRCGNGPARTYGROUPSTATEID, prcdngPartyGroupStatId);
        final List<Object[]> userDocketArray = query.list();

        final List<AIAReviewsDocket> externalUserDocketInfos = new ArrayList<>();
        userDocketArray.forEach(userDocket -> {
            final AIAReviewsDocket aiaReviewDocket = new AIAReviewsDocket();
            aiaReviewDocket.setProceedingId(checkNullBigDecimal(userDocket[ZERO]));
            aiaReviewDocket.setProceedingNo(checkNullAndTrim(userDocket[ONE]));
            aiaReviewDocket.setFilingDate(checkNullAndTrim(userDocket[TWO]));
            aiaReviewDocket.setNoticeAccordedFilingDate(checkNullAndTrim(userDocket[THREE]));
            aiaReviewDocket.setPoPreliminaryRespFilingDate(checkNullAndTrim(userDocket[FOUR]));
            aiaReviewDocket.setInstDecisionDate(checkNullAndTrim(userDocket[FIVE]));
            aiaReviewDocket.setTerminationDecisionDate(checkNullAndTrim(userDocket[SIX]));
            aiaReviewDocket.setUserRole(checkNullAndTrim(userDocket[SEVEN]));
            aiaReviewDocket.setPetitionerPatentNumber(checkNullAndTrim(userDocket[EIGHT]));
            aiaReviewDocket.setPoPatentNumber(checkNullAndTrim(userDocket[NINE]));
            aiaReviewDocket.setPetitionerApplicationNumber(checkNullAndTrim(userDocket[TEN]));
            aiaReviewDocket.setPoApplicationNumber(checkNullAndTrim(userDocket[ELEVEN]));
            final String poRealParty = checkNullAndTrim(userDocket[TWELVE]);
            aiaReviewDocket.setPoRealParty(poRealParty == null ? PTABConstants.DOUBLE_HYPHEN : poRealParty);
            final String peRealParty = checkNullAndTrim(userDocket[THIRTEEN]);
            aiaReviewDocket.setPetitionerRealParty(peRealParty == null ? PTABConstants.DOUBLE_HYPHEN : peRealParty);
            aiaReviewDocket.setStatus(checkNullAndTrim(userDocket[FOURTEEN]));
            aiaReviewDocket.setUserPartyGroupType(checkNullAndTrim(userDocket[FIFTEEN]));
            aiaReviewDocket.setPrcdCreatedTs(checkNullAndTrim(userDocket[SIXTEEN]));
            aiaReviewDocket.setLastModifiedTimestamp(checkNullAndTrim(userDocket[SEVENTEEN]));

            final List<String> judges = new ArrayList<>();
            addJudgesIfNotCommaSep(judges, userDocket[EIGHTEEN]);
            addJudgesIfNotCommaSep(judges, userDocket[NINTEEN]);
            addJudgesIfNotCommaSep(judges, userDocket[TWENTY]);
            addJudgesIfNotCommaSep(judges, userDocket[TWENTY_ONE]);
            addJudgesIfNotCommaSep(judges, userDocket[TWENTY_TWO]);
            addJudgesIfNotCommaSep(judges, userDocket[TWENTY_THREE]);
            addJudgesIfNotCommaSep(judges, userDocket[TWENTY_FOUR]);
            aiaReviewDocket.setJudges(judges);
            aiaReviewDocket.setPoTechCenterId(checkNullAndTrim(userDocket[TWENTY_FIVE]));
            aiaReviewDocket.setPetiTechCenterId(checkNullAndTrim(userDocket[TWENTY_SIX]));

            externalUserDocketInfos.add(aiaReviewDocket);
        });
        return externalUserDocketInfos;
    }

    public List<ExternalUserMotion> getMotions(final String userIdentifier, final List<Long> motionStatusIds,
            final List<Long> prcdngPartyGroupStatId, final List<Long> requestorTypeId, final String proceedingNumber,
            final Long motionId) {
        Session session = entityManager.unwrap(Session.class);

        Query<Object[]> query = session.createNamedQuery("getMotions", Object[].class);
        final Map<Integer, Object> params = new ConcurrentHashMap<>();
        params.put(FOUR, userIdentifier);
        params.put(ONE, motionStatusIds);
        params.put(THREE, prcdngPartyGroupStatId);
        params.put(TWO, requestorTypeId);

        final StringBuilder queryBuiulder = new StringBuilder();
        queryBuiulder.append(query.getQueryString());

        if (null != motionId) {
            queryBuiulder.append(" and m.motion_id = ? ");
            params.put(FIVE, motionId);
        }
        if (null != proceedingNumber) {
            queryBuiulder.append(PROCEEDINGNO);
            if (null != motionId) {
                params.put(SIX, proceedingNumber);
            } else {
                params.put(FIVE, proceedingNumber);
            }
        }
        if (queryBuiulder.length() != 0) {
            query = session.createNativeQuery(queryBuiulder.toString(), Object[].class);
        }
        for (final Parameter<?> parameter : query.getParameters()) {
            query.setParameter(parameter.getPosition(), params.get(parameter.getPosition()));
        }
        final Multimap<Long, ExternalUserMotion> motionMultimMap = ArrayListMultimap.create();
        extractMotionInfo(query, motionMultimMap);
        final List<ExternalUserMotion> updated = new ArrayList<>();
        for (Long motion : motionMultimMap.keySet()) {
            final Collection<ExternalUserMotion> externalUserMotionCollections = motionMultimMap.get(motion);
            final List<ExternalUserMotion> externalUserMotionList = new ArrayList<>(externalUserMotionCollections);
            List<ArtifactContent> artifactContentList = new ArrayList<>();
            final ExternalUserMotion externalUserMotion = externalUserMotionList.get(ZERO);
            for (ExternalUserMotion existing : externalUserMotionList) {
                final ArtifactContent artifactContent = new ArtifactContent();
                artifactContent.setDocumentName(existing.getDocumentName());
                artifactContent.setExhibitNumber(existing.getExhibitNumber());
                artifactContent.setPaperNumber(existing.getPaperNumber());
                artifactContentList.add(artifactContent);
            }
            externalUserMotion.setArtifactContent(artifactContentList);
            updated.add(externalUserMotion);

        }

        return updated;
    }

    private List<ExternalUserMotion> extractMotionInfo(final Query<Object[]> query,
            final Multimap<Long, ExternalUserMotion> motionMultimMap) {
        final List<Object[]> motionsForExternalUser = query.getResultList();
        final List<ExternalUserMotion> externalUserMotionDTOs = new ArrayList<>();

        for (final Object[] motion : motionsForExternalUser) {
            final ExternalUserMotion userMotion = new ExternalUserMotion();
            final Long motionId = checkNullAndLong(motion[ONE]);
            userMotion.setMotionId(checkNullAndLong(motion[ONE]));
            userMotion.setRequestorTypeId(checkNullAndLong(motion[TWO]));
            userMotion.setRequestorTypeName(checkNullAndTrim(motion[THREE]));
            userMotion.setFiledDate(checkNullAndTrim(motion[FOUR]));
            userMotion.setUserDefinedMotionName(checkNullAndTrim(motion[FIVE]));
            userMotion.setMotionTypeId(checkNullAndLong(motion[SIX]));
            userMotion.setMotionTypeNm(checkNullAndTrim(motion[SEVEN]));
            userMotion.setMotionStatusId(checkNullAndLong(motion[EIGHT]));
            userMotion.setMotionStatusName(StringUtils.lowerCase(checkNullAndTrim(motion[NINE])));
            userMotion.setMotionStatusDate(checkNullAndTrim(motion[TEN]));
            userMotion.setProceedingId(checkNullAndLong(motion[ELEVEN]));
            userMotion.setProceedingNumber(checkNullAndTrim(motion[TWELVE]));
            userMotion.setUserPartyGroupType(getUIPartyReprType(checkNullAndTrim(motion[THIRTEEN])));
            userMotion.setParentMotionId(checkNullAndLong(motion[FOURTEEN]));
            userMotion.setCommentText(checkNullAndTrim(motion[FIFTEEN]));
            userMotion.setArtifactRoleName(checkNullAndTrim(motion[SIXTEEN]));
            userMotion.setDocumentName(checkNullAndTrim(motion[SEVENTEEN]));
            userMotion.setPaperNumber(checkNullBigDecimal(motion[EIGHTEEN]));
            userMotion.setExhibitNumber(checkNullBigDecimal(motion[NINTEEN]));
            motionMultimMap.put(motionId, userMotion);
            externalUserMotionDTOs.add(userMotion);
        }
        return externalUserMotionDTOs;
    }

    public List<AppealDetails> getAppeals(final String userIdentifier, final List<Long> appealStatusIds,
            final List<Long> prcdngPartyGroupStatId, final List<Long> appealTypeIds, final List<Long> prcdPartyGrpTypeIds,
            final String proceedingNumber) {
        Session session = entityManager.unwrap(Session.class);
        Query<Object[]> query = session.createNamedQuery("getAppeals", Object[].class);
        final Map<Integer, Object> params = new ConcurrentHashMap<>();
        params.put(FIVE, userIdentifier);
        params.put(ONE, prcdPartyGrpTypeIds);
        params.put(THREE, appealStatusIds);
        params.put(FOUR, prcdngPartyGroupStatId);
        params.put(TWO, appealTypeIds);

        final StringBuilder queryBuiulder = new StringBuilder();
        queryBuiulder.append(query.getQueryString());

        if (null != proceedingNumber) {
            queryBuiulder.append(PROCEEDINGNO);
            params.put(SIX, proceedingNumber);
        }
        query = session.createNativeQuery(queryBuiulder.toString(), Object[].class);
        for (final Parameter<?> parameter : query.getParameters()) {
            query.setParameter(parameter.getPosition(), params.get(parameter.getPosition()));
        }
        final List<Object[]> appealsForExternalUser = query.getResultList();
        final List<AppealDetails> appealDetailsDTOs = new ArrayList<>();
        for (final Object[] appeals : appealsForExternalUser) {
            final AppealDetails appealDetails = new AppealDetails();
            appealDetails.setProceedingAppealId(checkNullAndLong(appeals[ZERO]));
            appealDetails.setAppealTypeId(checkNullAndLong(appeals[ONE]));
            appealDetails.setAppealTypeNm(checkNullAndTrim(appeals[TWO]));
            appealDetails.setAppealStatusId(checkNullAndLong(appeals[THREE]));
            appealDetails.setAppealStatusCd(checkNullAndTrim(appeals[FOUR]));
            appealDetails.setRequestorTypeName(getUIPartyReprType(checkNullAndTrim(appeals[FIVE])));
            appealDetails.setAppealNoticeDt(checkNullAndTrim(appeals[SIX]));
            appealDetails.setCourtDecisionDt(checkNullAndTrim(appeals[SEVEN]));
            appealDetails.setProceedingId(checkNullAndLong(appeals[EIGHT]));
            appealDetails.setProceedingNo(checkNullAndTrim(appeals[NINE]));
            appealDetails.setUserPartyGroupType(getUIPartyReprType(checkNullAndTrim(appeals[TEN])));
            appealDetails.setExteralCourtDecisionBy(checkNullAndTrim(appeals[ELEVEN]));
            appealDetails.setUserRole(checkNullAndTrim(appeals[TWELVE]));
            appealDetails.setCourtMandateDt(checkNullAndTrim(appeals[THIRTEEN]));
            appealDetails.setFilingDate(DateUtilityHelper.convertDateToString((Date) appeals[FOURTEEN], "MM/dd/yyyy"));
            appealDetailsDTOs.add(appealDetails);
        }
        return appealDetailsDTOs;
    }

    private static String getUIPartyReprType(final String partyType) {
        if (partyType == null)
            return "";
        final String userReprtType = UI_USER_PARTY_GROUP_MAP.get(partyType) == null ? partyType
                : UI_USER_PARTY_GROUP_MAP.get(partyType);
        return StringUtils.lowerCase(userReprtType);
    }

    public List<NotificationDetails> getNotifications(final String userIdentifier) {
        final Query<Object[]> query = sessionFactory.getCurrentSession().createNamedQuery("getExtUserNotifications",
                Object[].class);
        query.setParameter(USERID, userIdentifier);
        return getNotificationDetails(query.getResultList());
    }

    private List<NotificationDetails> getNotificationDetails(final List<Object[]> notificationDetailsArray) {
        final List<NotificationDetails> notificationDetailsList = new ArrayList<>();
        for (final Object[] obj : notificationDetailsArray) {
            final NotificationDetails notificationDetails = new NotificationDetails();
            notificationDetails.setCaseNo(checkNullAndTrim(obj[ZERO]));
            notificationDetails.setNotificationId(checkNullAndTrim(obj[ONE]));
            notificationDetails.setSendTimeStamp(checkNullDate(obj[TWO]));
            notificationDetails.setSubjectText(checkNullAndTrim(obj[THREE]));
            final Audit audit = new Audit();
            audit.setCreateTimestamp(checkNullDate(obj[FOUR]));
            audit.setCreateUserIdentifier(checkNullAndTrim(obj[FIVE]));
            audit.setLastModifiedTimestamp(checkNullDate(obj[SIX]));
            audit.setLastModifiedUserIdentifier(checkNullAndTrim(obj[SEVEN]));
            notificationDetails.setAudit(audit);
            if (null != obj[NINE]) {
                final List<String> toList = getEmailList(obj[NINE]);
                notificationDetails.setTolist(toList);
            }
            if (null != obj[TEN]) {
                final List<String> ccList = getEmailList(obj[TEN]);
                notificationDetails.setCcList(ccList);
            }

            notificationDetails.setInitiatedBy(checkNullAndTrim(obj[TWELVE]));
            notificationDetails.setNotificationStatus(checkNullAndTrim(obj[THIRTEEN]));

            notificationDetailsList.add(notificationDetails);
        }
        return notificationDetailsList;
    }

    /**
     * This method is to collect the email list
     */
    private List<String> getEmailList(final Object inputStr) {
        final List<String> emailList = Arrays.asList(String.valueOf(inputStr).trim().split("~"));
        if (CollectionUtils.isNotEmpty(emailList)) {
            return emailList.stream().distinct().toList();
        }
        return Collections.emptyList();
    }

    public List<ExternalUserRehearing> getRehearings(final String userIdentifier, final List<Long> rehearingStatusIds,
            final List<Long> prcdngPartyGroupStatId, final List<Long> requestorTypeId, final List<Long> rehearingTypeId) {

        final Query<Object[]> query = currentSession().createNamedQuery("getRehearings", Object[].class);
        query.setParameter(USERID, userIdentifier);
        query.setParameter("rehearingStatusIds", rehearingStatusIds);
        query.setParameter(PRCGNGPARTYGROUPSTATEID, prcdngPartyGroupStatId);
        query.setParameter(REQUESTOR, requestorTypeId);
        query.setParameter("rehearingTypeId", rehearingTypeId);

        return extractRehearingInfo(query);
    }

    public List<ExternalUserRehearing> getRehearingsByPrcdNum(final String userIdentifier,
            final List<Long> rehearingStatusIds, final List<Long> prcdngPartyGroupStatId, final List<Long> requestorTypeId,
            final List<Long> rehearingTypeId, final String proceedingNumber, final Long rehearingId) {
        Session session = entityManager.unwrap(Session.class);
        Query<Object[]> query = session.createNamedQuery("getRehearings", Object[].class);
        final Map<Integer, Object> params = new ConcurrentHashMap<>();
        params.put(THREE, userIdentifier);
        params.put(FIVE, rehearingStatusIds);
        params.put(TWO, prcdngPartyGroupStatId);
        params.put(FOUR, requestorTypeId);
        params.put(ONE, rehearingTypeId);

        final StringBuilder queryBuiulder = new StringBuilder();
        queryBuiulder.append(query.getQueryString());

        if (null != rehearingId) {
            queryBuiulder.append(" and r.rehearing_id = ?");
            params.put(SIX, rehearingId);
        }
        if (null != proceedingNumber) {
            queryBuiulder.append(PROCEEDINGNO);
            if (null != rehearingId) {
                params.put(SEVEN, proceedingNumber);
            } else {
                params.put(SIX, proceedingNumber);
            }
        }
        if (queryBuiulder.length() != ZERO) {
            query = session.createNativeQuery(queryBuiulder.toString(), Object[].class);
        }
        for (final Parameter<?> parameter : query.getParameters()) {
            query.setParameter(parameter.getPosition(), params.get(parameter.getPosition()));
        }
        return extractRehearingInfo(query);
    }

    private List<ExternalUserRehearing> extractRehearingInfo(final Query<Object[]> query) {
        final List<Object[]> rehearingsForExternalUser = query.getResultList();
        final List<ExternalUserRehearing> externalUserRehearingDTOs = new ArrayList<>();
        for (final Object[] rehearing : rehearingsForExternalUser) {

            final ExternalUserRehearing userRehearing = new ExternalUserRehearing();

            userRehearing.setRehearingId(checkNullAndLong(rehearing[ZERO]));
            userRehearing.setRehearingTypeId(checkNullAndLong(rehearing[ONE]));
            userRehearing.setRehearingTypeNm(StringUtils.lowerCase(checkNullAndTrim(rehearing[TWO])));
            userRehearing.setRehearingStatusId(checkNullAndLong(rehearing[THREE]));
            userRehearing.setRehearingStatusName(StringUtils.lowerCase(checkNullAndTrim(rehearing[FOUR])));
            userRehearing.setRehearingStatusDisplayName(StringUtils.lowerCase(checkNullAndTrim(rehearing[FIVE])));
            userRehearing.setRequestorTypeId(checkNullAndLong(rehearing[SIX]));
            userRehearing.setRequestorTypeName(checkNullAndTrim(rehearing[SEVEN]));
            userRehearing.setFiledDate(checkNullAndTrim(rehearing[EIGHT]));
            userRehearing.setDecisionDate(checkNullAndTrim(rehearing[NINE]));
            userRehearing.setProceedingId(checkNullAndLong(rehearing[TEN]));
            userRehearing.setProceedingNumber(checkNullAndTrim(rehearing[ELEVEN]));
            userRehearing.setUserPartyGroupType(getUIPartyReprType(checkNullAndTrim(rehearing[TWELVE])));

            externalUserRehearingDTOs.add(userRehearing);

        }
        return externalUserRehearingDTOs;
    }

    private static void addJudgesIfNotCommaSep(final List<String> judges, final Object objJudgeName) {
        final String judgeName = null != objJudgeName ? String.valueOf(objJudgeName).trim() : null;
        if (null != judgeName && !",".equals(judgeName)) {
            judges.add(judgeName);
        }
    }

}