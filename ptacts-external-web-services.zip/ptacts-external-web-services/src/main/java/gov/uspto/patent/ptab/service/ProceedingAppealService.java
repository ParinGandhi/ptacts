package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import java.util.List;

import jakarta.validation.constraints.NotNull;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.HttpClientErrorException;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.domain.ProceedingAppealInfo;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

/**
 * This service class for ProceedingAppealInfo
 * 
 * @author 2020 development team
 *
 */
@Slf4j
@Component
public class ProceedingAppealService {

    private static final String PROCEEDING_APPEAL_CREATE_URL = "PROCEEDING_APPEAL_CREATE_URL";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private PTABBusinessUtils ptabBusinessUtils;

    @Transactional
    public ProceedingAppealInfo createProceedingAppealInfo(
            @RequestBody @NotNull final ProceedingAppealInfo proceedingAppealInfo) {

        try {
            final String prcdAppealCreateUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                    PROCEEDING_APPEAL_CREATE_URL);
            notFoundIfNull(prcdAppealCreateUrl, "proceeding Appeal create url");
            final String userName = ptabBusinessUtils.getLoggedInUserId();
            setAppealArtifactObject(proceedingAppealInfo);
            final ResponseEntity<ProceedingAppealInfo> response = restServiceClient.callPTABExternalServiceURL(
                    prcdAppealCreateUrl, proceedingAppealInfo, HttpMethod.POST, ProceedingAppealInfo.class, userName);
            final ProceedingAppealInfo updated = response.getBody();
            getUpdatedAppealInfoDetails(updated);
            return updated;
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
    }

    private void getUpdatedAppealInfoDetails(final ProceedingAppealInfo updated) {
        if (null != updated && CollectionUtils.isNotEmpty(updated.getAppealDocuments())) {
            List<PetitionDocument> updatedDocuments = updated.getAppealDocuments();
            ptabBusinessUtils.setEncryptArtifactIdentifiers(updatedDocuments);
            updated.setAppealDocuments(updatedDocuments);
        }
    }

    private void setAppealArtifactObject(final ProceedingAppealInfo proceedingAppealInfo) {
        List<PetitionDocument> appealDocuments = proceedingAppealInfo.getAppealDocuments();
        if (CollectionUtils.isNotEmpty(appealDocuments)) {
            ptabBusinessUtils.setDecryptArtifactIdentifiers(appealDocuments);
            proceedingAppealInfo.setAppealDocuments(appealDocuments);
        }
    }
}