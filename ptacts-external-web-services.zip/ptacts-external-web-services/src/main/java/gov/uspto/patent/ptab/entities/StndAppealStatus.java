package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the STND_APPEAL_STATUS database table.
 * 
 */
@Entity
@Table(name = "STND_APPEAL_STATUS")
@NamedQuery(name = "StndAppealStatus.findAll", query = "SELECT s FROM StndAppealStatus s")
@Getter
@Setter
@NoArgsConstructor
public class StndAppealStatus extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "APPEAL_STATUS_ID")
    private long appealStatusId;

    @Column(name = "APPEAL_STATUS_CD")
    private String appealStatusCd;

    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Column(name = "DESCRIPTION_TX")
    private String descriptionTx;

    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "LOCK_CONTROL_NO")
    private BigDecimal lockControlNo;

    @OneToMany
    private List<ProceedingAppeal> proceedingAppeals;

}