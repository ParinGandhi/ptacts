package gov.uspto.patent.ptab.domain;

import java.util.List;

import lombok.Data;

@Data
public class UserWithProceedingQuestion {

    private ApplicationUser applicationUser;
    private List<ProceedingQualatativeQ> proceedingQualatativeQs;

}
