
package gov.uspto.patent.ptab.common.opsg.domain;

import java.util.ArrayList;
import java.util.List;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.validation.Valid;
import lombok.Data;

/**
 * Description of Address. Used for all interested parties and correspondence address.
 *
 * @author 2020 Development Team
 */
@Data
@JsonInclude(Include.NON_NULL)
public class Address {

    @Valid
    private List<PhysicalAddress> physicalAddress = new ArrayList<>();

    @Valid
    private List<TelePhonic> telecommunication = new ArrayList<>();

    @Valid
    private List<Email> emails = new ArrayList<>();
}
