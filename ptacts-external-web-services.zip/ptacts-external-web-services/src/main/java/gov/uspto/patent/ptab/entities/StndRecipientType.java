package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the STND_RECIPIENT_TYPE database table.
 * 
 */
@Entity
@Table(name = "STND_RECIPIENT_TYPE")
@Getter
@Setter
@NoArgsConstructor
public class StndRecipientType implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "RECIPIENT_TYPE_ID")
    private long recipientTypeId;

    @Column(name = "RECIPIENT_TYPE_CD")
    private String recipientTypeCd;

    @Column(name = "DESCRIPTION_TX")
    private String descriptionTx;

    @Column(name = "DISPLAY_ORDER_SEQUENCE_NO")
    private BigDecimal displayOrderSequenceNo;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Column(name = "CREATE_TS")
    private Timestamp createTs;

    @Column(name = "CREATE_USER_ID")
    private BigDecimal createUserId;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Column(name = "LAST_MOD_TS")
    private Timestamp lastModTs;

    @Column(name = "LAST_MOD_USER_ID")
    private BigDecimal lastModUserId;

    @Version
    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo;

    @OneToMany(mappedBy = "stndRecipientType")
    private List<StndMilestoneType> stndMilestoneTypes;

}