package gov.uspto.patent.ptab.controller;

import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.domain.ClaimComponent;
import gov.uspto.patent.ptab.service.PetitionClaimService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

/**
 * This class is used to retrieve the claims information
 * 
 * @author 2020 development team
 *
 */
@Slf4j
@RestController
@RequestMapping
public class PetitionClaimController {

    public static final String APPLICATION_JSON_UTF8_VALUE = "application/json;charset=UTF-8";

    @Autowired
    private PetitionClaimService claimsInfoService;

    /**
     * It retrieves the claims Information with the case number
     * 
     * @param caseNumber
     * @return it will gives list of claims Inforamation
     */
    @GetMapping(value = "/petition-claims", produces = APPLICATION_JSON_UTF8_VALUE)
    public ClaimComponent getClaimsInfo(@Valid @NotNull final CaseDocumentsDataQuery caseDocumentsDataQuery) {
        final String proceedingNumber = caseDocumentsDataQuery.getProceedingNumber();
        log.info("The claim details retieved for the proceeding number :{}", caseDocumentsDataQuery.getProceedingNumber());
        return claimsInfoService.getAllPetitionClaims(proceedingNumber);
    }

}
