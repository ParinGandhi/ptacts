package gov.uspto.patent.ptab.utils;

import static gov.uspto.patent.ptab.utils.PTABConstants.ZERO;
import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;
import static org.springframework.http.HttpStatus.BAD_REQUEST;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

//import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

import gov.uspto.patent.ptab.dao.AssignmentQueriesDao;
import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.domain.EmployeeDetails;
import gov.uspto.patent.ptab.domain.InterestedParty;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.domain.ProceedingParties;
import gov.uspto.patent.ptab.encrypt.RC4CipherEntity;
import gov.uspto.patent.ptab.entities.ApplicationUserEntity;
import gov.uspto.patent.ptab.entities.ExternalUser;
import gov.uspto.patent.ptab.entities.ProceedingEntity;
import gov.uspto.patent.ptab.repository.ApplicationUserRepository;
import gov.uspto.patent.ptab.repository.ExternalUserRepository;
import gov.uspto.patent.ptab.repository.ProceedingRepository;
import gov.uspto.patent.ptab.service.ExternalUserService;
import gov.uspto.patent.ptab.service.ProceedingPartyService;
import jakarta.servlet.http.HttpServletRequest;

/**
 * This class is for methods that can be reused
 *
 * @author 2020 Development Team
 *
 */
@Component
public class PTABBusinessUtils {

    private static final String SUBMITTER_PETITIONER = "PETITIONER";
    private static final String SUBMITTER_PATENTOWNER = "PATENTOWNER";
    private static final String USER_ID = "User Id";
    private static final String PROCEEDING_TEXT = "proceeding number";
    private static final String REG_EX_DATE_CONVERSION = "\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}.\\d{1}";
    private static final String USER_NAME_ATTRIBUTE_KEY = "valid-user";

    @Autowired
    private AssignmentQueriesDao assignmentQueriesDao;

    @Autowired
    private ApplicationUserRepository applicationUserRepository;

    @Autowired
    private ExternalUserRepository externalUserRepository;

    @Autowired
    private ProceedingRepository proceedingRepository;

    @Autowired
    private HttpServletRequest httpServletRequest;

    @Autowired
    private ExternalUserService externalUserService;

    @Autowired
    private ProceedingPartyService proceedingPartyService;

    /**
     * This method is used to get full name of users
     *
     * @param userId            - unique user identifier
     * @param applicationUserId - unique application identifier
     * @return
     */
    @Cacheable(value = "getUserFullName")
    public String getName(final String userId, final String applicationUserId) {
        final List<EmployeeDetails> name = assignmentQueriesDao.fetchFullNamesOfEmployee(userId, applicationUserId);
        return (CollectionUtils.isNotEmpty(name)) ? PTABServiceUtils.getWorkerFullName(name.get(0)) : StringUtils.EMPTY;
    }

    /**
     * This method is used to get String userIdentifier from a BigDecimal userId
     * 
     * @param userId
     * @return String
     */
    public String getUserId(final BigDecimal userId) {
        final ApplicationUserEntity applicationUserEntity = applicationUserRepository.findOneByApplicationUserId(userId);
        return applicationUserEntity.getUserId();
    }

    /**
     * This method is used to get BigDecimal userIdentifier from a String userId
     * 
     * @param userId
     * @return BigDecimal
     */
    public BigDecimal getUserIdentifier(final String userId) {
        final ApplicationUserEntity applicationUserEntity = applicationUserRepository.findOneByUserId(userId);
        return applicationUserEntity.getApplicationUserId();
    }

    /**
     * This method is used to get BigDecimal userIdentifier from a String userId
     *
     * @param userId
     * @return BigDecimal
     */
    public BigDecimal getExternalUserIdentifier(final String userId) {
        final ExternalUser externalUserEntity = externalUserRepository.findOneByUserId(userId);
        return externalUserEntity.getFkApplicationUserId();
    }

    /**
     * This is to check if there are null values in the get value
     * 
     * @param value
     * @return
     */
    public Object convertDateToString(final Object value) {
        if (null != value) {
            final String returnStr = value.toString();
            if (returnStr.matches(REG_EX_DATE_CONVERSION)) {
                final Date fetchedDate = (Date) value;
                return fetchedDate.getTime();
            } else {
                return returnStr;
            }
        } else {
            return null;
        }
    }

    /**
     * This method is used to get the proceeding number based on petition identifier
     *
     * @param proceedingId - petition identifier
     */
    public ProceedingEntity validateAndGetProceedingInformation(final String proceedingNumberText) {
        final ProceedingEntity existing = proceedingRepository.getProceedingDetails(proceedingNumberText);
        return notFoundIfNull(existing, PROCEEDING_TEXT);
    }

    public String getLoggedInUserId() {
        final String userIdentifier = (String) httpServletRequest.getAttribute(USER_NAME_ATTRIBUTE_KEY);
        if (StringUtils.isBlank(userIdentifier)) {
            notFoundIfNull(userIdentifier, USER_ID);
        }
        return userIdentifier;
    }

    public void validateExternalUserAndStaffDetails(final ProceedingParties proceedingParties,
            final List<InterestedParty> parties) {

        if (CollectionUtils.isNotEmpty(parties)) {
            final String submitterType = externalUserService.getPrcdPartyGroupType(proceedingParties.getCaseNo());
            if (StringUtils.isBlank(submitterType)) {
                throw new PTABException(BAD_REQUEST,
                        new ErrorPayload("The user doesn't have permission to view or add or update or delete staff details."));
            }
        }
    }

    public void validateExternalUserAndStaffDetailsForUpdate(final ProceedingParties proceedingParties,
            final List<InterestedParty> parties) {

        if (CollectionUtils.isNotEmpty(parties)) {
            final String submitterType = externalUserService.getPrcdPartyGroupTypeForStaff(proceedingParties.getCaseNo());
            if (StringUtils.isBlank(submitterType)) {
                throw new PTABException(BAD_REQUEST,
                        new ErrorPayload("The user doesn't have permission to  update or delete staff details."));
            }
        }
    }

    public void validateAndSetStaffTypeDetails(final ProceedingParties proceedingParties, final List<InterestedParty> parties) {

        if (CollectionUtils.isNotEmpty(parties)) {
            final String submitterType = externalUserService.getPrcdPartyGroupTypeForStaff(proceedingParties.getCaseNo());
            if (StringUtils.isNotBlank(submitterType)) {
                final Multimap<String, String> staffMap = getProceedingPartyDetailsAndMultiMap(proceedingParties, submitterType);
                validateStaffCount(submitterType, staffMap);
                setStaffTypeDetails(parties, submitterType);
            } else {
                throw new PTABException(BAD_REQUEST,
                        new ErrorPayload("The user doesn't have permission to add or update or delete staff details."));
            }

        }
    }

    public void setEncryptArtifactIdentifier(final PetitionDocument petitionDocument) {
        if (StringUtils.isNotBlank(petitionDocument.getArtifactIdentifer())) {
            petitionDocument.setArtifactIdentifer(RC4CipherEntity.encrypt(petitionDocument.getArtifactIdentifer()));
        }
    }

    public void setDecryptArtifactIdentifier(final PetitionDocument petitionDocument) {
        if (StringUtils.isNotBlank(petitionDocument.getArtifactIdentifer())) {
            petitionDocument.setArtifactIdentifer(RC4CipherEntity.decrypt(petitionDocument.getArtifactIdentifer()));
        }
    }

    public void setEncryptArtifactIdentifiers(List<PetitionDocument> petitionDocuments) {
        if (CollectionUtils.isNotEmpty(petitionDocuments)) {
            petitionDocuments.forEach(existing -> {
                if (StringUtils.isNotBlank(existing.getArtifactIdentifer())) {
                    existing.setArtifactIdentifer(RC4CipherEntity.encrypt(existing.getArtifactIdentifer()));
                }
            });
        }
    }

    public void setDecryptArtifactIdentifiers(List<PetitionDocument> petitionDocuments) {
        if (CollectionUtils.isNotEmpty(petitionDocuments)) {
            petitionDocuments.forEach(existing -> {
                if (StringUtils.isNotBlank(existing.getArtifactIdentifer())) {
                    existing.setArtifactIdentifer(RC4CipherEntity.decrypt(existing.getArtifactIdentifer()));
                }
            });
        }
    }

    private void validateStaffCount(final String submitterType, final Multimap<String, String> staffMap) {
        final Collection<String> count = staffMap.get(submitterType);
        final ArrayList<String> counselTypeList = new ArrayList<>(count);
        int staffCount = ZERO;
        for (final String type : counselTypeList) {
            if (StringUtils.equals(type, "STAFF")) {
                staffCount++;
            }
        }
        if (staffCount == 3) {
            throw new PTABException(BAD_REQUEST, new ErrorPayload("Fourth, staff cannot be added."));
        }
    }

    private void setStaffTypeDetails(final List<InterestedParty> parties, final String submitterType) {
        for (final InterestedParty interestedParty : parties) {
            interestedParty.setSubmitterType(submitterType);
            interestedParty.setPartyType(PTABConstants.COUNSEL);
            interestedParty.setPartySubType(PTABConstants.STAFF);
        }
    }

    private Multimap<String, String> getProceedingPartyDetailsAndMultiMap(final ProceedingParties proceedingParties,
            final String submitterType) {
        final Multimap<String, String> staffMap = ArrayListMultimap.create();
        final CaseDocumentsDataQuery caseDocumentsDataQuery = new CaseDocumentsDataQuery();
        caseDocumentsDataQuery.setProceedingNumber(proceedingParties.getCaseNo());
        final JsonNode jsonNode = proceedingPartyService.getAllProceedingPartyDetails(caseDocumentsDataQuery);
        if (null != jsonNode) {
            final ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

            if (StringUtils.equals(submitterType, SUBMITTER_PATENTOWNER)) {
                final JsonNode patentOwnerNode = jsonNode.path("poCounsel");
                final ProceedingParties result = mapper.convertValue(patentOwnerNode, new TypeReference<ProceedingParties>() {
                });
                setStaffMap(submitterType, staffMap, result);

            } else if (StringUtils.equals(submitterType, SUBMITTER_PETITIONER)) {
                final JsonNode patentOwnerNode = jsonNode.path("petitionCounsel");
                final ProceedingParties result = mapper.convertValue(patentOwnerNode, new TypeReference<ProceedingParties>() {
                });
                setStaffMap(submitterType, staffMap, result);

            }

        }
        return staffMap;
    }

    private void setStaffMap(final String submitterType, final Multimap<String, String> staffMap,
            final ProceedingParties proceedingParties) {
        final List<InterestedParty> parties = proceedingParties.getParties();
        if (CollectionUtils.isNotEmpty(parties)) {
            buildStaffMultiMap(submitterType, staffMap, parties);
        }
    }

    private void buildStaffMultiMap(final String submitterType, final Multimap<String, String> staffMap,
            final List<InterestedParty> parties) {
        for (final InterestedParty party : parties) {
            if (StringUtils.equals(submitterType, SUBMITTER_PETITIONER)
                    || StringUtils.equals(submitterType, SUBMITTER_PATENTOWNER)
                            && (StringUtils.equals(party.getPartyType(), "COUNSEL")
                                    && StringUtils.equals(party.getPartySubType(), "STAFF"))) {
                staffMap.put(submitterType, party.getPartySubType());
            }

        }
    }

}