package gov.uspto.patent.ptab.domain;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.uspto.patent.ptab.utils.MilliSecEpochDeserializer;
import gov.uspto.patent.ptab.utils.MilliSecEpochSeralizer;
import lombok.Data;

/**
 *
 * This class has data parameters for Related proceedings.
 *
 * @author 2020 Development Team
 *
 */
@Data
@JsonInclude(Include.NON_NULL)
public class RelatedProceeding {

    private String proceedingNo;
    private String joinderType;
    private String relatedProceedingNo;
    private String poRealParty;
    private String petitionerRealParty;
    private String descriptionText;
    private String milestoneDate;
    @JsonSerialize(using = MilliSecEpochSeralizer.class)
    @JsonDeserialize(using = MilliSecEpochDeserializer.class)
    private Date beginEffectiveDate;

    @JsonIgnore
    private String currentStateId;

}
