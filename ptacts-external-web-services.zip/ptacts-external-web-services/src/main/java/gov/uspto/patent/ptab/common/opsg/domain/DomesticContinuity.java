
package gov.uspto.patent.ptab.common.opsg.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Description of DomesticContinuity used primarily used in continuity related services.
 * 
 * @author 2020 Development Team
 */
@Data
@JsonInclude(Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
public class DomesticContinuity extends PatentCaseCommonDomain {

    private List<ParentContinuity> parentContinuity;

    private List<ChildContinuity> childContinuity;

}
