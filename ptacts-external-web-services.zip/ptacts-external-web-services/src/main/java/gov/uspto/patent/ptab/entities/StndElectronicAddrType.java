package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the STND_ELECTRONIC_ADDR_TYPE database table.
 * 
 */
@Entity
@Table(name = "STND_ELECTRONIC_ADDR_TYPE")
@NamedQuery(name = "StndElectronicAddrType.findAll", query = "SELECT s FROM StndElectronicAddrType s")
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class StndElectronicAddrType extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ELECTRONIC_ADDR_TYPE_ID")
    private long electronicAddrTypeId;

    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Column(name = "DESCRIPTION_TX")
    private String descriptionTx;

    @Column(name = "ELECTRONIC_ADDR_TYPE_CD")
    private String electronicAddrTypeCd;

    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    // bi-directional many-to-one association to PrcdngPartyElctrnAddr
    @OneToMany(mappedBy = "stndElectronicAddrType")
    private List<PrcdngPartyElectronicAddrEntity> pcdngPartyElctrnAddrs;

}