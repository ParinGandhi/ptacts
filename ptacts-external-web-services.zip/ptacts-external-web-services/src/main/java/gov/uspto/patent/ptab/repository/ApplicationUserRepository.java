package gov.uspto.patent.ptab.repository;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import gov.uspto.patent.ptab.entities.ApplicationUserEntity;

/**
 *
 * This is the interface class for ApplicationUser
 *
 * @author 2020 Development Team
 *
 */
@Repository
public interface ApplicationUserRepository extends JpaRepository<ApplicationUserEntity, BigDecimal> {

    /**
     * Fetch ApplicationUser from DB using userId
     *
     * @return
     */
    @Query(value = "select entity from ApplicationUserEntity entity where entity.userId=(?1)")
    public ApplicationUserEntity findOneByUserId(final String userId);
    
    /**
     * Fetch ApplicationUser from DB using application userId
     *
     * @return
     */
    public ApplicationUserEntity findOneByApplicationUserId(BigDecimal applicationUserId);
   

}
