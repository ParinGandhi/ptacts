package gov.uspto.patent.ptab.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the PRCDNG_STATY_GRND_CLM_RSN database table.
 */
@Entity
@Table(name = "PRCDNG_STATY_GRND_CLM_RSN")
@NamedQuery(name = "PrcdngStatyGrndClmRsn.findAll", query = "SELECT p FROM PrcdngStatyGrndClmRsn p")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PrcdngStatyGrndClmRsn extends AbstractAuditEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PRCDNG_STATY_GRND_CLM_RSN_SEQ")
    @SequenceGenerator(name = "PRCDNG_STATY_GRND_CLM_RSN_SEQ", sequenceName = "PRCDNG_STATY_GRND_CLM_RSN_SEQ", allocationSize = 1)
    @Column(name = "PRCDNG_STATY_GRND_CLM_RSN_ID")
    private Long prcdngStatyGrndClmRsnId;

    @Column(name = "FK_PRCDNG_CLM_STATY_GROUND_ID")
    private Long fkPrcdgClmStayGroundId;

    @Column(name = "FK_CLAIM_CHALLENGE_REASON_ID")
    private Long fkPrcdgClmChallengeReasonId;

    @ManyToOne
    @JoinColumn(name = "FK_CLAIM_CHALLENGE_REASON_ID", insertable = false, updatable = false)
    private ClaimChallengeReason claimChallengeReason;

    @ManyToOne
    @JoinColumn(name = "FK_PRCDNG_CLM_STATY_GROUND_ID", insertable = false, updatable = false)
    private PrcdngClmStatyGround prcdngClmStatyGround;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

}