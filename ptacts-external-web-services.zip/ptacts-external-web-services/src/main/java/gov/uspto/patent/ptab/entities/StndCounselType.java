package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the STND_COUNSEL_TYPE database table.
 * 
 */
@Entity
@Table(name = "STND_COUNSEL_TYPE")
@NamedQuery(name = "StndCounselType.findAll", query = "SELECT s FROM StndCounselType s")
@NoArgsConstructor
@Getter
@Setter
public class StndCounselType extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "COUNSEL_TYPE_ID")
    private Long counselTypeId;

    @Column(name = "COUNSEL_TYPE_CD")
    private String counselTypeCd;

    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Column(name = "COUNSEL_TYPE_DESC")
    private String counselTypeDesc;

    @Column(name = "DISPLAY_ORDER_SEQUENCE_NO")
    private BigDecimal displayOrderSequenceNo;

    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "LOCK_CONTROL_NO")
    private BigDecimal lockControlNo;

}