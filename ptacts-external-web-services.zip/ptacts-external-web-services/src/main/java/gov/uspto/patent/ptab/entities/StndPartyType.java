package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the STND_PARTY_TYPE database table.
 * 
 */
@Entity
@Table(name = "STND_PARTY_TYPE")
@NamedQuery(name = "StndPartyType.findAll", query = "SELECT s FROM StndPartyType s")
@Getter
@Setter
public class StndPartyType extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "STND_PARTY_TYPE_PARTYTYPEID_GENERATOR", sequenceName = "STND_PARTY_TYPE_PARTYTYPEID_GENERATOR", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "STND_PARTY_TYPE_PARTYTYPEID_GENERATOR")
    @Column(name = "PARTY_TYPE_ID")
    private long partyTypeId;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Column(name = "DISPLAY_ORDER_SEQUENCE_NO")
    private BigDecimal displayOrderSequenceNo;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "PARTY_TYPE_CD")
    private String partyTypeCd;

    @Column(name = "DESCRIPTION_TX")
    private String descriptionTx;

    // bi-directional many-to-one association to Party
    @OneToMany(mappedBy = "stndPartyType")
    private List<Party> parties;

    /**
     * add Party
     * 
     * @param party
     * @return Party
     */
    public Party addParty(final Party party) {
        getParties().add(party);
        party.setStndPartyType(this);

        return party;
    }

    /**
     * remove Party
     * 
     * @param party
     * @return Party
     */
    public Party removeParty(final Party party) {
        getParties().remove(party);
        party.setStndPartyType(null);

        return party;
    }

    /**
     * @return the beginEffectiveDt
     */
    public Date getBeginEffectiveDt() {
        return null != this.beginEffectiveDt ? (Date) this.beginEffectiveDt.clone() : null;
    }

    /**
     * @param beginEffectiveDt the beginEffectiveDt to set
     */
    public void setBeginEffectiveDt(final Date beginEffectiveDt) {
        this.beginEffectiveDt = null != beginEffectiveDt ? new Date(beginEffectiveDt.getTime()) : null;
    }

    /**
     * @return the endEffectiveDt
     */
    public Date getEndEffectiveDt() {
        return null != this.endEffectiveDt ? (Date) this.endEffectiveDt.clone() : null;
    }

    /**
     * @param endEffectiveDt the endEffectiveDt to set
     */
    public void setEndEffectiveDt(final Date endEffectiveDt) {
        this.endEffectiveDt = null != endEffectiveDt ? new Date(endEffectiveDt.getTime()) : null;
    }

}