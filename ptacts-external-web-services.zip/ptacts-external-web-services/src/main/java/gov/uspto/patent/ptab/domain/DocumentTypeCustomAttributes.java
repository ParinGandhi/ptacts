package gov.uspto.patent.ptab.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class DocumentTypeCustomAttributes {
    private Long[] motionTypeIds;
    private Long[] rehearingIds;
    private List<Attributes> attributes;
    private AppealFilter appealFilter;

    @Getter
    @Setter
    @JsonInclude(Include.NON_NULL)
    public static class Attributes {
        private Long id;
        private String label;
        private String dataType;
        private String uielementId;
        private Long outcomeTypeId;
        private String value;
        private boolean mandatory;
        private boolean visibility;
        private String[] rolesForEdit;
        private Userpicklist userpicklist;
    }

    @Getter
    @Setter
    @JsonInclude(Include.NON_NULL)
    public static class AppealFilter {
        private List<String> statusCodes;
    }

    @Getter
    @Setter
    @JsonInclude(Include.NON_NULL)
    public static class Userpicklist {
        private String dataType;
        private String label;
        private String refattribute;
        private List<Values> values;
    }

    @Getter
    @Setter
    @JsonInclude(Include.NON_NULL)
    public static class Values {
        private String id;
        private String text;
    }
}