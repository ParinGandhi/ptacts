package gov.uspto.patent.ptab.entities;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "prcdng_party_elctrn_addr")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PrcdngPartyElectronicAddrEntity extends AbstractAuditEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "prcdng_party_elctrn_addr_PRCDNGPARTYTELECOMADDRID_GENERATOR",
            sequenceName = "PRCDNG_PARTY_ELCTRN_ADDR_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "prcdng_party_elctrn_addr_PRCDNGPARTYTELECOMADDRID_GENERATOR")
    @Column(name = "PRCDNG_PARTY_ELCTRN_ADDR_ID")
    private Long prcdngPartyElectrnAddrId;

    @Column(name = "ELECTRONIC_ADDR_LOCATOR_TX")
    private String emailAddress;

    @Column(name = "FK_PROCEEDING_PARTY_ID")
    private Long fkProceedingPartyId;

    @Column(name = "FK_ELECTRONIC_ADDR_TYPE_ID")
    private Long fkElectronicAddrTypeId;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo;

    @Column(name = "CORRESPONDENCE_ADDRESS_IN")
    private String correspondAddress;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "FK_PROCEEDING_PARTY_ID", insertable = false, updatable = false)
    private ProceedingParty proceedingParty;

    @ManyToOne
    @JoinColumn(name = "FK_ELECTRONIC_ADDR_TYPE_ID", insertable = false, updatable = false)
    private StndElectronicAddrType stndElectronicAddrType;
}
