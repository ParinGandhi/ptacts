package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.ExternalUserDetails;
import gov.uspto.patent.ptab.domain.MyUsptoStatus;
import gov.uspto.patent.ptab.entities.ExternalUser;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.RestServiceClient;

@Service
public class RbacOktaService {

    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    private static final String UPDATE_REGISTRATION_NUMBER = "UPDATE_REGISTRATION_NUMBER";
    private static final String  GET_N_CHECK_USER_DETAILS_URL ="get user details url";
    private static final String UPDATE_REGISTRATION_NUMBER_URL = "registration number url";
    private static final String  GET_N_CHECK_USER_DETAILS ="GET_N_CHECK_USER_DETAILS";

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private PTABBusinessUtils ptabBusinessUtils;

    @Autowired
    private RestServiceClient restServiceClient;

    @Transactional
    public ExternalUser updateRegistrationNumberByEmail(ExternalUserDetails externalUser) {
        final String regNumberUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                UPDATE_REGISTRATION_NUMBER);
        notFoundIfNull(regNumberUrl, UPDATE_REGISTRATION_NUMBER_URL);
        final String userName = ptabBusinessUtils.getLoggedInUserId();
        final ResponseEntity<ExternalUser> response = restServiceClient.callPTABExternalServiceURL(regNumberUrl, externalUser,
                HttpMethod.PUT, ExternalUser.class, userName);
        return response.getBody();
    }
    
    @Transactional
    public MyUsptoStatus getAndCheckMyUsptoUserDetailsByEmail(String userCt, final List<String> requestedEmailIds) {
        String getMyUusptoUserDetails = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
        		GET_N_CHECK_USER_DETAILS);
       
        notFoundIfNull(getMyUusptoUserDetails, GET_N_CHECK_USER_DETAILS_URL);
        if(StringUtils.isNotEmpty(userCt)) {
        	getMyUusptoUserDetails = getMyUusptoUserDetails + "?userCt=" + userCt;
        }
        final String userName = ptabBusinessUtils.getLoggedInUserId();
        final ResponseEntity<MyUsptoStatus> response = restServiceClient.callPTABExternalServiceURL(getMyUusptoUserDetails, requestedEmailIds,
                HttpMethod.POST, MyUsptoStatus.class, userName);
        return response.getBody();
    }
}
