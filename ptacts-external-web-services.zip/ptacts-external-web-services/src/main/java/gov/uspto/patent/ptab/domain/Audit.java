package gov.uspto.patent.ptab.domain;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.uspto.patent.ptab.utils.MilliSecEpochDeserializer;
import gov.uspto.patent.ptab.utils.MilliSecEpochSeralizer;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Description of Audit
 *
 * @author 2020 Development Team
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
@JsonInclude(Include.NON_NULL)
public class Audit {

    @JsonSerialize(using = MilliSecEpochSeralizer.class)
    @JsonDeserialize(using = MilliSecEpochDeserializer.class)
    private Date lastModifiedTimestamp;

    @NotNull(message = "lastModifiedUserId cannot be blank")
    private String lastModifiedUserIdentifier;

    @NotNull(message = "creatorUserId cannot be blank")
    private String createUserIdentifier;

    private String createdUserName;

    private String lastModifiedUserName;

    @JsonSerialize(using = MilliSecEpochSeralizer.class)
    @JsonDeserialize(using = MilliSecEpochDeserializer.class)
    private Date createTimestamp;

    private BigDecimal lockControlNumber;

    private String createdPrefferedName;

    private String lastModifiedPrefferedName;

}
