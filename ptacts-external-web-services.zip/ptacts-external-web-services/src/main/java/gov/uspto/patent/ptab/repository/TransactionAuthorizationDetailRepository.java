package gov.uspto.patent.ptab.repository;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import gov.uspto.patent.ptab.entities.TransactionAuthorizationDetailEntity;

@Repository
public interface TransactionAuthorizationDetailRepository
        extends JpaRepository<TransactionAuthorizationDetailEntity, BigDecimal> {

    @Query(value = "select max(TRANSACTION_TOKEN_ID)+1 from TRANSACTION_AUTHRZN_DTL", nativeQuery = true)
    public BigDecimal getNextId();

}
