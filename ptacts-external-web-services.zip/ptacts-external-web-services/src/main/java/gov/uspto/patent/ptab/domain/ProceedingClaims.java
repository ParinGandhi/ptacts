package gov.uspto.patent.ptab.domain;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ProceedingClaims extends CaseBase {
    private Long caseId;

    private String instCmntTxt;
    private Long finalWrittenDcsnId;
    private String finalCmntTxt;

    @Valid
    @NotNull
    @NotEmpty
    private List<Claims> claims;
    @Valid
    private Audit audit;
    @Valid
    private LifeCycle lifeCycle;
}
