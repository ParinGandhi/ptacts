package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

//import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.Petition;
import gov.uspto.patent.ptab.domain.ProceedingQuery;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABConstants;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ProceedingService {

    private static final String PROCEEDING_BASIC_URL = "PROCEEDING_BASIC_URL";
    private static final String PROCEEDING_URL = "PROCEEDING_URL";
    private static final String SYSTEM_USER = "SYSTEM_USER";
    private static final String PTAB_CASE_INIT = "PTAB_CASE_INIT";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    private static final String SUBMIT_PROCEEDING_URL = "SUBMIT_PROCEEDING_URL";
    private static final String SYSTEM_USER_NAME_MSG = "system user name";
    private static final String PROCEEDING_DETAILS_URL_MSG = "proceeding details Url";
    private static final String PROXY_USER_ID = "proxy-user-id";

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Autowired
    private HttpServletRequest httpServletRequest;

    @Transactional
    public JsonNode getProceeding(@Valid @NotNull final ProceedingQuery proceedingQuery) {
        final String proceedingDetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_URL);
        notFoundIfNull(proceedingDetailsUrl, PROCEEDING_DETAILS_URL_MSG);

        final String userName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(userName, SYSTEM_USER_NAME_MSG);

        final String url = externalServiceUriGenerator.getProceedingQuery(proceedingQuery, proceedingDetailsUrl);
        ResponseEntity<JsonNode> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, JsonNode.class, userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException((HttpStatus) ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response ? response.getBody() : null;
    }

    @Transactional
    public JsonNode getBasicProceedingAndPaymentDetails(@Valid @NotNull final ProceedingQuery proceedingQuery) {
        final String proceedingBasicUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_BASIC_URL);
        notFoundIfNull(proceedingBasicUrl, PROCEEDING_DETAILS_URL_MSG);

        final String userName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(userName, SYSTEM_USER_NAME_MSG);

        final String url = externalServiceUriGenerator.getProceedingQuery(proceedingQuery, proceedingBasicUrl);
        ResponseEntity<JsonNode> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, JsonNode.class, userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException((HttpStatus) ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response ? response.getBody() : null;
    }

    @Transactional
    public void submitProceeding(@Valid @NotNull final Petition petition) {
        final String proceedingDetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                SUBMIT_PROCEEDING_URL);
        notFoundIfNull(proceedingDetailsUrl, PROCEEDING_DETAILS_URL_MSG);

        final String userName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTABConstants.PTAB_CASE_INIT,
                PTABConstants.SYSTEM_USER);
        notFoundIfNull(userName, SYSTEM_USER_NAME_MSG);
        final String proxyUserId = (String) httpServletRequest.getAttribute(PROXY_USER_ID);
        log.error("The proxy internal user id value is {} ", proxyUserId);
        if (StringUtils.isNotBlank(proxyUserId)) {
            petition.setInternalUserSubmitter(proxyUserId);
        }

        ResponseEntity<Void> response = null;

        response = restServiceClient.callPTABExternalServiceURL(proceedingDetailsUrl, petition, HttpMethod.POST, Void.class,
                userName);

        if (response.getStatusCode().is2xxSuccessful()) {
            log.info("Successfully created proceeding number{} via proceeding service", petition.getProceedingNumberText());
        } else {
            final HttpStatus statusCode = (HttpStatus) response.getStatusCode();
            if (statusCode.is4xxClientError()) {
                final String msg = "error occurred while creating the proceeding for id " + petition.getProceedingNumberText();
                log.error(msg);
                throw new PTABException(statusCode, new ErrorPayload(msg));
            } else if (statusCode.is5xxServerError()) {
                final String msg = "Internal server error occurred while creating proceeding";
                log.error(msg);
                throw new PTABException(statusCode, new ErrorPayload(msg));
            }
        }
    }
}
