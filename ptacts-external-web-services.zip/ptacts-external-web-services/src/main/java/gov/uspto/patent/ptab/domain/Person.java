package gov.uspto.patent.ptab.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class Person {

    private String identifier;
    private String firstName;
    private String lastName;
    private String middleInitial;
    private String prefferedName;
    private List<PhysicalAddress> mailingAddress;
    private List<ElectronicAddress> electronicAddress;

    private String activeJudgeIndicator;

}
