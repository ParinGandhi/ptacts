package gov.uspto.patent.ptab.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * The query class is used for various document retrieval operations
 *
 * @author 2020 Development Team
 */
@Getter
@Setter
public class DocumentsQuery {

    private String fileName;
    private String contentManagementId;
    private Long artifactId;

}
