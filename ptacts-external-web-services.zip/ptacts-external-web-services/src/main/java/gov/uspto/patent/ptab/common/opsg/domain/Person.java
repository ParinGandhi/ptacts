/*******************************************************************************
 * 2016, All rights reserved.
 *******************************************************************************/
package gov.uspto.patent.ptab.common.opsg.domain;

//import jakarta.validation.Valid;
//import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * Description of Person PCDM.
 *
 * @author 2020 Development Team
 */
@Data
@JsonInclude(Include.NON_NULL)
public class Person {

    private String namePrefix;

    private String firstName;

    private String middleName;

    private String lastName;

    private String nameSuffix;

    private String identifier;

    private String prefferedName;

    @Size(min = 0, max = 3, message = "citizenship code should be 0 to 3 chars")
    private String citizenship;

    @Valid
    private Address address = new Address();
}
