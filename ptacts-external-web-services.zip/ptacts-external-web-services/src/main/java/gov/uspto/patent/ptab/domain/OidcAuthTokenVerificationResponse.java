package gov.uspto.patent.ptab.domain;

import java.util.List;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Data
public class OidcAuthTokenVerificationResponse {

    private String sub;
    private String userLogin;
    private String lastName;
    private String firstName;
    private String emailAddress;
    private String patronId;
    private String displayName;
    private String accountType;
    private List<String> groups;
    private String middleName;

}
