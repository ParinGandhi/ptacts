package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the EXTERNAL_USER database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = "EXTERNAL_USER")
@NamedQuery(name = "ExternalUser.findAll", query = "SELECT e FROM ExternalUser e")
public class ExternalUser implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "EXTERNAL_USER_FKAPPLICATIONUSERID_GENERATOR")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "EXTERNAL_USER_FKAPPLICATIONUSERID_GENERATOR")
    @Column(name = "FK_APPLICATION_USER_ID")
    private BigDecimal fkApplicationUserId;

    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Column(name = "CREATE_TS")
    private Timestamp createTs;

    @Column(name = "CREATE_USER_ID")
    private BigDecimal createUserId;

    @Column(name = "ELECTRONIC_ADDR_LOCATOR_TX")
    private String electronicAddrLocatorTx;

    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "FIRST_NM")
    private String firstNm;

    @Column(name = "FK_USER_STATUS_ID")
    private BigDecimal fkUserStatusId;

    @Column(name = "LAST_LOGIN_TS")
    private Timestamp lastLoginTs;

    @Column(name = "LAST_MOD_TS")
    private Timestamp lastModTs;

    @Column(name = "LAST_MOD_USER_ID")
    private BigDecimal lastModUserId;

    @Column(name = "LAST_NM")
    private String lastNm;

    @Column(name = "LOCK_CONTROL_NO")
    private BigDecimal lockControlNo;

    @Column(name = "MIDDLE_NM")
    private String middleNm;

    @Column(name = "ORGANIZATION_NM")
    private String organizationNm;

    @Column(name = "PASSWORD_HASH_TX")
    private String passwordHashTx;

    @Temporal(TemporalType.DATE)
    @Column(name = "PASSWORD_RESET_DT")
    private Date passwordResetDt;

    @Column(name = "REGISTRATION_NO")
    private String registrationNo;

    @Column(name = "TELEPHONE_NO")
    private String telephoneNo;

    @Column(name = "UNSUCCESSFUL_LOGIN_COUNT_QT")
    private BigDecimal unsuccessfulLoginCountQt;

    @Column(name = "VALIDATION_TOKEN_EXPIRATION_TS")
    private Timestamp validationTokenExpirationTs;

    @Column(name = "VALIDATION_TOKEN_TX")
    private String validationTokenTx;

    // bi-directional one-to-one association to ApplicationUser
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "FK_APPLICATION_USER_ID", referencedColumnName = "APPLICATION_USER_ID")
    private ApplicationUserEntity applicationUser;

}