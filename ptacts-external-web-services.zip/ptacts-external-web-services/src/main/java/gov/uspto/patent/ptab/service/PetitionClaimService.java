package gov.uspto.patent.ptab.service;

import gov.uspto.patent.ptab.dao.PetitionClaimDao;
import gov.uspto.patent.ptab.domain.ClaimComponent;
import gov.uspto.patent.ptab.domain.ClaimMetaData;
import gov.uspto.patent.ptab.domain.ReferenceSummary;
import gov.uspto.patent.ptab.entities.ClaimChallengeReason;
import gov.uspto.patent.ptab.entities.PrcdngStatyGrndClmRsn;
import gov.uspto.patent.ptab.entities.ProceedingEntity;
import gov.uspto.patent.ptab.entities.StndStatutoryGround;
import gov.uspto.patent.ptab.repository.PrcdngStatyGrndClmRsnRepository;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.util.*;

import static gov.uspto.patent.ptab.utils.PTABConstants.*;
import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNullCollection;

/**
 *
 * Service Implementation for Claims Info
 *
 * @author 2020 Development Team
 */
@Component
@Slf4j
public class PetitionClaimService {

    public static final String COMMA = ",";

    @Autowired
    private PTABBusinessUtils ptabBusinessUtils;

    @Autowired
    private PrcdngStatyGrndClmRsnRepository prcdngStatyGrndClmRsnRepository;

    @Autowired
    private PetitionClaimDao claimsInfoDao;

    /**
     * Thsi service is used to get claims Info List.
     * 
     * @param proceedingNumber
     * @return
     */
    @Transactional
    public ClaimComponent getAllPetitionClaims(@Valid @NotNull final String proceedingNumber) {
        final ClaimComponent claimComponent = new ClaimComponent();
        final ProceedingEntity proceeding = ptabBusinessUtils.validateAndGetProceedingInformation(proceedingNumber);
        final List<ClaimChallengeReason> claimChallengeReasonList = prcdngStatyGrndClmRsnRepository
                .getAllClaims(proceeding.getProceedingId());
        notFoundIfNullCollection(claimChallengeReasonList, "Claims");
        final List<ClaimMetaData> claims = new ArrayList<>();
        claimComponent.setTotalClaims(ZERO);
        final List<Integer> claimNumberList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(claimChallengeReasonList)) {
            for (final ClaimChallengeReason claimChallengeReason : claimChallengeReasonList) {
                final ClaimMetaData existing = buildClaimDetails(claimChallengeReason);
                getFramedCLaimNumbers(existing, claimNumberList);
                claims.add(existing);
            }
        }
        final List<ClaimMetaData> updatedList = new ArrayList<>();
        final Map<Long, String> reasonMap = new HashMap<>();
        final Map<Long, List<ClaimMetaData>> returnClaimsMap = new HashMap<>();
        for (final ClaimMetaData claim : claims) {
            reasonMap.put(claim.getClaimIdentifier(), claim.getChallengedGroupClaimList());
            log.info("The claim identifier is {} ", claim.getClaimIdentifier());
            if (returnClaimsMap.containsKey(claim.getStatutoryGndSummary().getIdentifier())) {
                final List<ClaimMetaData> currentClaims = returnClaimsMap.get(claim.getStatutoryGndSummary().getIdentifier());
                currentClaims.add(claim);
                returnClaimsMap.put(claim.getStatutoryGndSummary().getIdentifier(), currentClaims);

                log.info("The claim Statutory identifier is {} ", claim.getStatutoryGndSummary().getIdentifier());
            } else {
                final List<ClaimMetaData> currentClaims = new ArrayList<>();
                currentClaims.add(claim);
                returnClaimsMap.put(claim.getStatutoryGndSummary().getIdentifier(), currentClaims);
                log.info("The claim Statutory identifier is {} ", claim.getStatutoryGndSummary().getIdentifier());
            }
        }
        returnClaimsMap.forEach((identifier, claimList) -> updatedList.addAll(claimList));
        claimComponent.setClaimMetaData(updatedList);
        claimComponent.setTotalClaims(claimsInfoDao.getTotalClaims(proceedingNumber).intValue());
        return claimComponent;
    }

    public ClaimMetaData buildClaimDetails(final ClaimChallengeReason claimChallengeReason) {
        final ClaimMetaData claim = new ClaimMetaData();
        claim.setClaimIdentifier(claimChallengeReason.getClaimChallengeReasonId());
        final List<String> proceedingClaimList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(claimChallengeReason.getPrcdngStatyGrndClmRsns())) {
            for (final PrcdngStatyGrndClmRsn prcdngStatyGrndClmRsn : claimChallengeReason.getPrcdngStatyGrndClmRsns()) {
                final ReferenceSummary statutoryGndSummary = new ReferenceSummary();
                final StndStatutoryGround stndStatutoryGround = prcdngStatyGrndClmRsn.getPrcdngClmStatyGround()
                        .getStndStatutoryGround();
                statutoryGndSummary.setCode(stndStatutoryGround.getStatutoryGroundCd());
                statutoryGndSummary.setIdentifier(stndStatutoryGround.getStatutoryGroundId());
                statutoryGndSummary.setDescriptionText(stndStatutoryGround.getDescriptionTx());
                claim.setStatutoryGndSummary(statutoryGndSummary);
                claim.setReasonText(prcdngStatyGrndClmRsn.getClaimChallengeReason().getClaimReasonTx());
                proceedingClaimList.add(prcdngStatyGrndClmRsn.getPrcdngClmStatyGround().getProceedingClaim().getClaimNo());
            }
        }
        claim.setClaimNumberList(proceedingClaimList);

        return claim;
    }

    private List<String> sortClaims(final List<String> claims) {
        final List<Integer> intList = new ArrayList<>();
        for (final String claimNo : claims) {
            if (claimNo != null && !claimNo.isEmpty()) {
                intList.add(Integer.valueOf(claimNo));
            }
        }
        Collections.sort(intList);
        claims.clear();
        for (final Integer intValue : intList) {
            claims.add(intValue.toString());
        }
        return claims;
    }

    private List<String> addClaimInt(final List<String> claimList, final Integer cInt) {
        if (!claimList.isEmpty()) {
            if ((cInt - ONE) == Integer.parseInt(claimList.get(claimList.size() - ONE))) {
                claimList.add("-");
                claimList.add(cInt.toString());
            } else {
                claimList.add(",");
                claimList.add(cInt.toString());
            }
        } else {
            claimList.add(cInt.toString());
        }
        return claimList;
    }

    /**
     * Retrieves framed claim numbers
     * 
     */
    public void getFramedCLaimNumbers(final ClaimMetaData claim, final List<Integer> claimNumberList) {
        final List<String> claims = sortClaims(claim.getClaimNumberList());
        final List<String> claimListString = new ArrayList<>();
        for (final String claimsInt : claims) {
            claimNumberList.add(Integer.valueOf(claimsInt));
            addClaimInt(claimListString, Integer.valueOf(claimsInt));
        }
        final List<List<String>> twoDList = destroyStackValuesBlock(claimListString);
        final StringBuilder result = performStepThree(twoDList);
        claim.setChallengedGroupClaimList(result.toString());

    }

    /**
     * This method destroys the value blocks
     */
    private List<List<String>> destroyStackValuesBlock(final List<String> claimListString) {
        final List<List<String>> twoDList = new ArrayList<>();

        int strt = ZERO;
        int stop;
        for (int i = ZERO; i < claimListString.size(); i++) {
            if (COMMA.equals(claimListString.get(i))) {
                stop = i;
                twoDList.add(claimListString.subList(strt, stop));
                strt = i + ONE;
            }
        }
        twoDList.add(claimListString.subList(strt, claimListString.size()));

        return twoDList;
    }

    /**
     * This method separates the claims using comma
     */
    private StringBuilder performStepThree(final List<List<String>> twoDList) {
        final StringBuilder result = new StringBuilder();
        for (int index = ZERO; index < twoDList.size(); index++) {
            separateClaims(result, index, twoDList);
        }
        return result;
    }

    /**
     * This method separates the claims based on size of two deimesional list
     */
    private void separateClaims(final StringBuilder result, final int index, final List<List<String>> twoDList) {
        final List<String> claimList = twoDList.get(index);
        if (claimList.size() == ONE) {
            result.append(claimList.get(ZERO));
            if (index != (twoDList.size() - ONE)) {
                result.append(",");
            }
        }
        if (claimList.size() == THREE) {
            result.append(claimList.get(ZERO)).append(COMMA);
            result.append(claimList.get(TWO));
            if (index != (twoDList.size() - ONE)) {
                result.append(",");
            }
        }
        if (claimList.size() > THREE) {
            result.append(claimList.get(ZERO)).append("-");
            result.append(claimList.get(claimList.size() - ONE));
            if (index != (twoDList.size() - ONE)) {
                result.append(COMMA);
            }
        }
    }

}
