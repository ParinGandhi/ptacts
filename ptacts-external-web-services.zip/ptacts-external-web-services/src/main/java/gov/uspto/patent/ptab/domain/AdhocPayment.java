package gov.uspto.patent.ptab.domain;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdhocPayment {

    private Long paymentId;
    @NotNull
    private Long quantity;
    @NotNull
    private Long motionId;

    private String attorneyDocketNumber;

    private Audit audit;

    private String transactionId;

}
