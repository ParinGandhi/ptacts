package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;
import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNullCollection;
import static gov.uspto.patent.ptab.utils.PTABServiceUtils.validateStringReqest;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import jakarta.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.dao.ReferenceDAO;
import gov.uspto.patent.ptab.domain.CodeReferenceLookup;
import gov.uspto.patent.ptab.domain.CodeReferenceQuery;
import gov.uspto.patent.ptab.domain.DocumentTypeQuery;
import gov.uspto.patent.ptab.domain.ReferenceDataResponse;
import gov.uspto.patent.ptab.domain.ReferenceQuery;
import gov.uspto.patent.ptab.domain.ReferenceType;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

/**
 * Helper class which builds reference data
 *
 * @author 2020 Development Team
 */
@Validated
@Component
@Slf4j
public class ReferenceDataService {

    private static final String REFERENCE_DATA_PN_URL = "REFERENCE_DATA_PN_URL";
    private static final String REFERENCE_DATA_URL = "REFERENCE_DATA_URL";
    private static final String CODE_REFERENCE_TYPES_URL = "CODE_REFERENCE_TYPES_URL";
    private static final String CODE = "code";
    private static final String NO_DATA_FOUND = "no.data.found";

    private static final String SYSTEM_USER = "SYSTEM_USER";
    private static final String PTAB_CASE_INIT = "PTAB_CASE_INIT";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    public static final String REF_DOCUMENT_TYPES = "documentTypes";
    public static final String REF_MOTION_TYPES = "motionTypes";
    private static final String SYSTEM = "system user name";
    private static final String CALLING = "calling common services for fetching reference data";

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Autowired
    private ReferenceDAO referenceDAO;

    /**
     * This method is used to retrieve code reference values
     *
     * @param codeReferenceQuery - query object to retrieve the data
     * @return
     */
    @Transactional(readOnly = true)
    public List<CodeReferenceLookup> getCodeReferenceTypes(@NotNull final CodeReferenceQuery codeReferenceQuery) {

        validateStringReqest(codeReferenceQuery.getTypeCode(), CODE);

        final List<CodeReferenceLookup> referenceTypes = codeReferenceDao
                .fetchCodeReferenceViaTypeCode(codeReferenceQuery.getTypeCode());
        notFoundIfNullCollection(referenceTypes, NO_DATA_FOUND);
        return referenceTypes;
    }

    /**
     * This method is used to retrieve code reference values
     *
     * @param codeReferenceQuery - query object to retrieve the data
     * @return
     */
    @Transactional(readOnly = true)
    public List<CodeReferenceLookup> getCodeReferenceType(@NotNull final CodeReferenceQuery codeReferenceQuery) {
        List<CodeReferenceLookup> codeReferenceLookups = null;
        final String codeReferenceTypesUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                CODE_REFERENCE_TYPES_URL);
        notFoundIfNull(codeReferenceTypesUrl, "code Reference Types Url");
        final String url = externalServiceUriGenerator.getCodeReferenceTypesUrl(codeReferenceQuery.getTypeCode(),
                codeReferenceTypesUrl);
        final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(systemUserName, SYSTEM);

        ResponseEntity<String> response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, String.class,
                systemUserName);
        if (response.getStatusCode().is2xxSuccessful()) {
            final ObjectMapper objectMapper = new ObjectMapper();

            try {
                codeReferenceLookups = objectMapper.readValue(response.getBody(), new TypeReference<List<CodeReferenceLookup>>() {
                });
            } catch (JsonProcessingException e) {
                log.error("Error ", e);
            }
        }

        return codeReferenceLookups;

    }

    /**
     * Gets reference type base on its type.
     *
     * @param referenceQuery
     * @return
     */
    @Transactional
    public List<ReferenceType> getReferenceData(@NotNull ReferenceQuery referenceQuery) {

        final String referenceDataUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                REFERENCE_DATA_URL);
        notFoundIfNull(referenceDataUrl, "reference data Url");

        final String url = externalServiceUriGenerator.constructReferenceDataUrl(referenceQuery, referenceDataUrl);

        final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(systemUserName, SYSTEM);
        log.info(CALLING);
        ResponseEntity<String> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, String.class, systemUserName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response ? new Gson().fromJson(response.getBody(), new ParameterizedTypeReference<List<ReferenceType>>() {
        }.getType()) : null;

    }

    @Transactional
    public List<ReferenceType> getReferenceDataByTypeCode(final ReferenceQuery referenceQuery) {

        if (referenceQuery.getTypeCode().equals(REF_DOCUMENT_TYPES)) {
            return referenceDAO.getDocumentTypes(referenceQuery);
        } else if (referenceQuery.getTypeCode().equals(REF_MOTION_TYPES)) {
            return referenceDAO.getMotionTypes();
        }
        return Collections.emptyList();
    }

    /**
     * Gets reference type base on its type.
     *
     * @param referenceQuery
     * @return
     */
    @Transactional
    public ReferenceDataResponse getReferenceDataWithProceedingNumber(@NotNull ReferenceQuery referenceQuery) {

        final String referenceDataPnUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                REFERENCE_DATA_PN_URL);
        notFoundIfNull(referenceDataPnUrl, "reference data Url");
        final String url = externalServiceUriGenerator.constructReferenceDataUrl(referenceQuery, referenceDataPnUrl);
        final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(systemUserName, SYSTEM);
        log.info(CALLING);
        ResponseEntity<ReferenceDataResponse> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, ReferenceDataResponse.class,
                    systemUserName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        ReferenceDataResponse dataResponse = response.getBody();
        Boolean isOtherDocModal = referenceQuery.getIsOtherDocs();
        if (dataResponse != null && isOtherDocModal) {
            return filterExtPetPatOtherDocTypes(dataResponse);
        }
        return dataResponse;
    }

    private ReferenceDataResponse filterExtPetPatOtherDocTypes(ReferenceDataResponse dataResponse) {

        final String extPetOtherDocTypeDesc = codeReferenceDao.findDescriptionByTypeCodeAndValueTx("EXT_OTHER_DOC_TYPES",
                "PETITIONER_PATOWNER");
        final List<Long> extPetOtherDocTypes = getTildaSeparatedList(extPetOtherDocTypeDesc);
        List<ReferenceType> stateDocumentTypes = dataResponse.getStateDocumentTypes();
        List<ReferenceType> filterStateDocumentTypes = stateDocumentTypes.stream()
                .filter(b -> extPetOtherDocTypes.contains(b.getIdentifier())).collect(Collectors.toList());
        dataResponse.setStateDocumentTypes(filterStateDocumentTypes);
        return dataResponse;
    }

    private List<Long> getTildaSeparatedList(String refernceDesc) {
        List<Long> extPetOtherDocTypes = null;
        if (StringUtils.isNotBlank(refernceDesc)) {
            extPetOtherDocTypes = Arrays.stream(refernceDesc.split("~")).map(Long::valueOf).collect(Collectors.toList());
        }
        return extPetOtherDocTypes;
    }

    /**
     * Method used to get document info
     *
     * @param documentTypeQuery -document type query
     *
     */
    @Transactional
    public JsonNode getDocumentInfo(DocumentTypeQuery documentTypeQuery) {
        final String documentTypesUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                "DOCUMENT_TYPES_URL");
        notFoundIfNull(documentTypesUrl, "document types Url");
        final String url = externalServiceUriGenerator.constructDocumentTypesUrl(documentTypeQuery, documentTypesUrl);

        final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(systemUserName, SYSTEM);
        log.info(CALLING);
        ResponseEntity<JsonNode> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, JsonNode.class, systemUserName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return response.getBody();
    }

    /**
     * Method used to get document info
     *
     * @param documentTypeQuery -document type query
     *
     */
    @Transactional
    public List<ReferenceType> getDocumentDetailsForDirectorReview(ReferenceQuery referenceQuery) {
    	List<ReferenceType>  referenceTypes  = null;
        final String documentTypesUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                "DIRECTOR_REVIEW_DOCUMENT_TYPES_URL");
        notFoundIfNull(documentTypesUrl, "document types Url");
        final String url = externalServiceUriGenerator.constructReferenceDataUrl(referenceQuery, documentTypesUrl);
        final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(systemUserName, SYSTEM);
        log.info(CALLING);
        ResponseEntity<String> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, String.class, systemUserName);
            
            if (response.getStatusCode().is2xxSuccessful()) {
                final ObjectMapper objectMapper = new ObjectMapper();

                try {
                	referenceTypes = objectMapper.readValue(response.getBody(), new TypeReference<List<ReferenceType>>() {
                    });
                } catch (JsonProcessingException e) {
                    log.error("Error ", e);
                }
            }

        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return  referenceTypes;
    }

}
