
package gov.uspto.patent.ptab.common.opsg.domain;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Description of PreGrantpublication PCDM.
 * 
 * @author 2020 Development Team
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class PreGrantpublication extends PatentCaseCommonDomain {

    private String versionType;

    private String publicationStatus;

    private Long publicationStatusDate;

    private String ipOfficeCode;

    private Integer publicationYear;

    private String publicationSequenceNo;

    private String patentDocumentKindCode;

    private Long publicationDate;

}
