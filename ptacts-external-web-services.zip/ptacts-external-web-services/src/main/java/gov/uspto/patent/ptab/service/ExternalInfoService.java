package gov.uspto.patent.ptab.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.google.gson.Gson;

import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ExternalInfoService {


    @Value("${geo-region.url}")
    private String serviceUrl;

    @Value("${country-geo-region.url}")
    private String countryServiceUrl;

    @Autowired
    RestServiceClient restServiceClient;

    public ResponseEntity<String> getCountriesFromICT() {
        ResponseEntity<String> response = null;
        try {
            response = new ResponseEntity<>(
                    restServiceClient.callExternalServiceURL(countryServiceUrl, null, HttpMethod.GET, String.class), null,
                    HttpStatus.OK);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response.getBody()
                ? new Gson().fromJson(response.getBody(), new ParameterizedTypeReference<Map<String, String>>() {
                }.getType())
                : null;
    }

    public ResponseEntity<Object> getStatesFromICT(String countryCode) {
        String responseJson;
        try {
            responseJson = restServiceClient.callExternalServiceURL(serviceUrl + countryCode, null, HttpMethod.GET, String.class);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != responseJson ? new Gson().fromJson(responseJson, new ParameterizedTypeReference<Map<String, String>>() {
        }.getType()) : null;
    }
}
