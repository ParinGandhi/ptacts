package gov.uspto.patent.ptab.helper;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

import static gov.uspto.patent.ptab.utils.PTABConstants.*;

/**
 * This class provides methods for Proceeding claims case
 * 
 * @author 2020 development team
 *
 */
@Component
public class ProceedingCaseHelper {
    /**
     * this method provides input claim numbers from asCaptured to expanded
     * 
     * input: "4","5","6","7","8","12","13","14","15" output: 4-8,12-15
     * 
     * @param claimList
     * @return
     */
    public String prepareAsCaputuredClaimList(List<String> claimList) {
        List<String> claimListString = new ArrayList<>();
        for (String claimsInt : claimList) {
            addClaimInt(claimListString, Integer.valueOf(claimsInt));
        }
        List<List<String>> twoDList = destroyStackValuesBlock(claimListString);

        StringBuilder result = performStepThree(twoDList);
        return result.toString();
    }

    private static List<List<String>> destroyStackValuesBlock(List<String> claimListString) {
        List<List<String>> twoDList = new ArrayList<>();

        int strt = 0;
        int stop;
        for (int i = 0; i < claimListString.size(); i++) {
            if (COMMA.equals(claimListString.get(i))) {
                stop = i;
                twoDList.add(claimListString.subList(strt, stop));

                strt = i + 1;
            }

        }
        twoDList.add(claimListString.subList(strt, claimListString.size()));

        return twoDList;
    }

    private static StringBuilder performStepThree(List<List<String>> twoDList) {
        /*
         * STEP 3
         */
        StringBuilder result = new StringBuilder();
        for (int j = 0; j < twoDList.size(); j++) {
            List<String> t = twoDList.get(j);

            // if ONLY ONE(1) elements in the subarrayList
            performStepThreeOneElement(twoDList, result, j, t);

            // if ONLY TWO(2) elements in the subarrayList
            performStepThreeTwoElement(twoDList, result, j, t);

            // if MORE THE TWO(2) elements in the subarrayList
            performStepThreeThreeElement(twoDList, result, j, t);
        }
        return result;
    }

    private static void performStepThreeThreeElement(List<List<String>> twoDList, StringBuilder result, int j,
            List<String> t) {
        if (t.size() > THREE) {
            result.append(t.get(0)).append(HYPHEN);
            result.append(t.get(t.size() - 1));
            if (j != (twoDList.size() - 1)) {
                result.append(COMMA);
            }
        }
    }

    private static void performStepThreeTwoElement(List<List<String>> twoDList, StringBuilder result, int j,
            List<String> t) {
        if (t.size() == THREE) {
            result.append(t.get(0)).append(COMMA);
            result.append(t.get(TWO));
            if (j != (twoDList.size() - 1)) {
                result.append(",");
            }
        }
    }

    private static void performStepThreeOneElement(List<List<String>> twoDList, StringBuilder result, int j,
            List<String> t) {
        if (t.size() == ONE) {
            result.append(t.get(ZERO));
            if (j != (twoDList.size() - 1)) {
                result.append(",");
            }
        }
    }

    private static List<String> addClaimInt(List<String> claimList, Integer cInt) {
        if (!claimList.isEmpty()) {
            if ((cInt - 1) == Integer.parseInt(claimList.get(claimList.size() - 1))) {
                claimList.add("-");
                claimList.add(cInt.toString());
            } else {
                claimList.add(",");
                claimList.add(cInt.toString());
            }
        } else {
            claimList.add(cInt.toString());
        }
        return claimList;
    }

    /**
     * this method provides list of individual values for given as captured input
     * 
     * input: 1,2,4-6,9-12 output: 1,2,4,5,6,9,10,11,12
     * 
     * @param asCaptured
     * @return
     */
    public List<String> prepareExpandedList(String asCaptured) {
        List<String> out = new ArrayList<>();
        for (String block : asCaptured.split(COMMA)) {
            block = block.trim();
            if (block.contains(HYPHEN)) {
                int begin = Integer.parseInt(block.split(HYPHEN)[0].trim());
                int end = Integer.parseInt(block.split(HYPHEN)[1].trim());
                for (int i = begin; i <= end; i++) {
                    out.add(Integer.toString(i));
                }
            } else {
                out.add(block);
            }
        }
        return out;
    }
}
