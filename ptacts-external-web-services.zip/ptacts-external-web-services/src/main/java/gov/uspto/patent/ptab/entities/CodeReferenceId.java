package gov.uspto.patent.ptab.entities;

import java.io.Serializable;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * This class is used as primary key for Table CodeReference in PTAB DB
 *
 * @author 2020 Development Team
 *
 */

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CodeReferenceId implements Serializable {
    private static final long serialVersionUID = 1L;
    

    private String typeCd;
    private String valueTx;
}
