package gov.uspto.patent.ptab.common.opsg.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * @author 2020 Development Team
 *
 */
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class GenericTransactionReturn extends TransactionReturn {

    private String crfSubmissionCd;
    private String deliveryMode;

}
