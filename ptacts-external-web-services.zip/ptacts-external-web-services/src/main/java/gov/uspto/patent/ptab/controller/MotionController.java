package gov.uspto.patent.ptab.controller;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.service.MotionService;
import gov.uspto.patent.ptab.trials.domain.MotionDetails;

/**
 * This class is used to get/update motion details
 *
 * @author 2020 development team
 *
 */
@RestController
@RequestMapping("/motions")
public class MotionController {

    public static final String APPLICATION_JSON_UTF8_VALUE = "application/json;charset=UTF-8";

    @Autowired
    private MotionService motionService;

    /**
     * Method to get all the motion details
     *
     * @param caseDocumentsDataQuery - query object to be used for getting all the motion details
     */
    @GetMapping(produces = APPLICATION_JSON_UTF8_VALUE)
    public JsonNode getAllMotionDetails(@Valid @NotNull final CaseDocumentsDataQuery caseDocumentsDataQuery) {
        return motionService.getAllMotions(caseDocumentsDataQuery);

    }

    /**
     * This method is used to retrieve the motion details based on motion id
     *
     * @param motionId - motion id
     */
    @GetMapping(value = "/{motionId}", produces = APPLICATION_JSON_UTF8_VALUE)
    public JsonNode getMotionDetails(@NotBlank @PathVariable("motionId") final Long motionId) {
        return motionService.getMotionDetails(motionId);

    }

    /**
     * Method to get all the motion details
     * 
     * @param caseDocumentsDataQuery - query object to be used for getting all the motion details
     */
    @GetMapping(value="/get-motion-details",produces = APPLICATION_JSON_UTF8_VALUE)
    public List<MotionDetails> getMotionDetails(@Valid @NotNull final CaseDocumentsDataQuery caseDocumentsDataQuery) {
        return motionService.getMotionDetailsTrials(caseDocumentsDataQuery);
    }
    

    /**
     * This method is used to create the motion details
     *
     * @param motionDetails - motion object to be updated
     */
    @PostMapping(value = "/create-motion")
    public MotionDetails createMotion(@NotNull @RequestBody final MotionDetails motionDetails) {
        motionService.createMotion(motionDetails);
        return motionDetails;
    }

}
