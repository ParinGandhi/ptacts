package gov.uspto.patent.ptab.dao;

import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;

/**
 * DAO Implementation for ExternalUser
 *
 * @author 2020 development team
 *
 */
@Repository
@Slf4j
public class ProceedingDao {

    private static final String PROCEEDING_NUM = "proceedingNum";

    @Autowired
    private SessionFactory sessionFactory;

    /**
     * This method is used to validate user id
     *
     * @param userId - unique userId to be validated
     * @return
     */
    @Transactional(readOnly = true)
    public String getProceedingState(final String proceedingNum) {
        log.info("Dao call for Current proceedig state method");
        final Query<?> query = sessionFactory.getCurrentSession().createNamedQuery("getProceedingState", Object[].class);

        query.setParameter(PROCEEDING_NUM, proceedingNum);
        var uniqueResult = (Float) query.uniqueResult();
        return String.valueOf(uniqueResult.intValue());
    }

}