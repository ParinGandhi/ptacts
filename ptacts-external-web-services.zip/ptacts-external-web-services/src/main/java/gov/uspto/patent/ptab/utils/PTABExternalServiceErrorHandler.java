package gov.uspto.patent.ptab.utils;

import static org.springframework.http.HttpStatus.Series.CLIENT_ERROR;
import static org.springframework.http.HttpStatus.Series.SERVER_ERROR;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

import com.google.common.io.ByteSource;

import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to capture HTTP status message and response
 * 
 * @author 2020 Development Team
 *
 */
@Slf4j
public class PTABExternalServiceErrorHandler implements ResponseErrorHandler {

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.web.client.ResponseErrorHandler#handleError(org.
     * springframework.http.client. ClientHttpResponse)
     */
    @Override
    public void handleError(final ClientHttpResponse paramClientHttpResponse) {
        log.error("Response status code from  : ExternalServiceErrorHandler is {} ", paramClientHttpResponse);
        final String body = fetchErrorText(paramClientHttpResponse);
        final String errorMessage = fetchErroMessageFromServiceErrorJson(paramClientHttpResponse, body);
        HttpStatus statusCode = HttpStatus.INTERNAL_SERVER_ERROR;
        try {
            statusCode = (HttpStatus) paramClientHttpResponse.getStatusCode();
        } catch (IOException ex) {
            log.error(ex.getMessage(), ex);
        }
        handleRestException(statusCode, errorMessage);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.web.client.ResponseErrorHandler#hasError(org.
     * springframework.http.client.ClientHttpResponse)
     */
    @Override
    public boolean hasError(final ClientHttpResponse paramClientHttpResponse) {

        boolean hasErrorReponse = false;
        try {
            hasErrorReponse = (((HttpStatus) paramClientHttpResponse.getStatusCode()).series() == CLIENT_ERROR)
                    || (((HttpStatus) paramClientHttpResponse.getStatusCode()).series() == SERVER_ERROR);
        } catch (final IOException ex) {
            log.error(ex.getMessage(), ex);
        }
        return hasErrorReponse;
    }

    /**
     * This method throws PTABException wrapped with errorMessage and httpStatus
     */
    private void handleRestException(final HttpStatus statusCode, final String errorMessage) {
        throw new PTABException(statusCode, new ErrorPayload(errorMessage));
    }

    /**
     * This method is used to fetch error message from External Service
     */
    private String fetchErroMessageFromServiceErrorJson(final ClientHttpResponse paramClientHttpResponse, final String body) {
        String errorMessage = body;

        try {
            final JSONObject obj = new JSONObject(body);
            log.info("The status code after calling the service is {}", paramClientHttpResponse.getStatusCode());
            log.error("Error response message from  Service is ===========> {}", obj.toString());
            errorMessage = (String) obj.opt("messageDesc");
            if (null == errorMessage) {
                errorMessage = (String) obj.opt("message");
            }
        } catch (final IOException | JSONException e) {
            log.error("Failed to get Json error message; body:{}; exception:{}", body, e);
        }
        return errorMessage;
    }

    /**
     * This method is used to fetch the error message from HTTP Response
     */
    private String fetchErrorText(final ClientHttpResponse paramClientHttpResponse) {
        String body = "Failed to get REST Call Reason";
        try {
            final InputStream inputStream = paramClientHttpResponse.getBody();
            final ByteSource byteSource = new ByteSource() {
                @Override
                public InputStream openStream() {
                    return inputStream;
                }
            };
            body = byteSource.asCharSource(StandardCharsets.UTF_8).read();
        } catch (final IOException e) {
            log.error("Failed to get REST Call Reason; exception:{}", e);
        }
        return body;
    }
}
