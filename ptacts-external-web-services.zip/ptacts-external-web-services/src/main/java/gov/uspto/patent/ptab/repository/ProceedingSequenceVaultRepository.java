package gov.uspto.patent.ptab.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import gov.uspto.patent.ptab.entities.ProceedingSequenceVault;
import gov.uspto.patent.ptab.entities.ProceedingSequenceVaultPk;

@Repository
public interface ProceedingSequenceVaultRepository extends JpaRepository<ProceedingSequenceVault, ProceedingSequenceVaultPk> {

}
