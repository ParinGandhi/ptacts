package gov.uspto.patent.ptab.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
@JsonInclude(Include.NON_NULL)
public class ClaimMetaData {

    private Long claimIdentifier;
    private String reasonText;
    private ReferenceSummary statutoryGndSummary;
    @JsonIgnore
    private List<String> claimNumberList = new ArrayList<>();
    private String challengedGroupClaimList;

}
