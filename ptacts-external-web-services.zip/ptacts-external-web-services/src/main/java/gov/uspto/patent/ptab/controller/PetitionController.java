package gov.uspto.patent.ptab.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.domain.PaymentRequest;
import gov.uspto.patent.ptab.domain.PaymentVO;
import gov.uspto.patent.ptab.domain.Petition;
import gov.uspto.patent.ptab.domain.PetitionBasicInformation;
import gov.uspto.patent.ptab.domain.PetitionQuery;
import gov.uspto.patent.ptab.service.PaymentService;
import gov.uspto.patent.ptab.service.PetitionService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/petitions")
public class PetitionController {

    @Autowired
    private PetitionService petitionService;

    @Autowired
    private PaymentService paymentService;

    @PostMapping
    public PetitionBasicInformation createPetition(@RequestBody @NotNull final PetitionBasicInformation petition) {
        return petitionService.createPetition(petition);
    }

    @PostMapping("/{petitionId}/payments")
    public ResponseEntity<PaymentVO> createPayment(@Valid @NotNull @PathVariable("petitionId") final Long petitionId,
            @RequestBody final PaymentRequest paymentRequest) {
        return ResponseEntity.ok().body(paymentService.createPayment(petitionId, paymentRequest));
    }

    @PostMapping("/{petitionId}/adhoc-payments")
    public ResponseEntity<PaymentVO> createAdhocPayment(@Valid @NotNull @PathVariable("petitionId") final Long petitionId,
            @Valid @NotNull @RequestBody final JsonNode adhocPayment) {
        final PaymentVO var1 = paymentService.createAdhocPayment(petitionId, adhocPayment);
        final HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", var1.getAuthToken());
        return ResponseEntity.ok().headers(headers).body(var1);

    }

    @GetMapping("/{petitionId}/payments/{paymentId}/receipt")
    public ResponseEntity<PaymentVO> getReceiptPayments(
            @Valid @NotNull @PathVariable("petitionId") final Long proceedingId,
            @Valid @NotNull @PathVariable("paymentId") final Long paymentId) {
        return ResponseEntity.ok().body(paymentService.getPayments(proceedingId, paymentId));
    }

    @GetMapping("/{petitionId}/payments/receipt")
    public ResponseEntity<PaymentVO> getReceiptPayments(
            @Valid @NotNull @PathVariable("petitionId") final Long proceedingId) {
        return ResponseEntity.ok().body(paymentService.getPayments(proceedingId));
    }

    @PostMapping(path = "/{petitionId}/payments/{paymentId}/complete", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE, produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> processCompletePayment(@Valid @NotNull @PathVariable("petitionId") final Long petitionId,
            @Valid @NotNull @PathVariable("paymentId") final Long paymentId,
            @RequestParam final MultiValueMap<String, String> parameters) {
        log.error("The Form param map value is {} ", parameters.toString());
        return ResponseEntity.ok().body(paymentService.updateCompletePayment(petitionId, paymentId, parameters));
    }

    @GetMapping(path = "/{petitionId}/payments/{paymentId}/complete/{receiptId}", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> processCompletePayment(@Valid @NotNull @PathVariable("petitionId") final Long petitionId,
            @Valid @NotNull @PathVariable("paymentId") final Long paymentId,
            @Valid @NotNull @PathVariable("receiptId") final String receiptId) {
        log.error("The receipt id value is {} ", receiptId);
        return ResponseEntity.ok().body(paymentService.updatePaymentDetails(petitionId, paymentId, receiptId, null));
    }

    @GetMapping(path = "/{petitionId}/payments/{paymentId}/transaction/{transactionId}/complete/{receiptId}", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> processCompletePaymentWithTransactionId(
            @Valid @NotNull @PathVariable("petitionId") final Long petitionId,
            @Valid @NotNull @PathVariable("paymentId") final Long paymentId,
            @Valid @NotNull @PathVariable("receiptId") final String receiptId,
            @Valid @NotNull @PathVariable("transactionId") final String transactionId) {
        log.error("The receipt id value is {} ", receiptId);
        return ResponseEntity.ok()
                .body(paymentService.updatePaymentDetails(petitionId, paymentId, receiptId, transactionId));
    }

    @PostMapping(path = "/{petitionId}/payments/{paymentId}/cancel", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE, produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> processCancelPayment(@Valid @NotNull @PathVariable("petitionId") final Long petitionId,
            @Valid @NotNull @PathVariable("paymentId") final Long paymentId,
            @RequestParam final MultiValueMap<String, String> parameters) {
        return ResponseEntity.ok().body(paymentService.updateCancelPayment(petitionId, paymentId, parameters));
    }

    @GetMapping(path = "/{petitionId}/payments/{paymentId}/cancel", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> processCancelPayment(@Valid @NotNull @PathVariable("petitionId") final Long petitionId,
            @Valid @NotNull @PathVariable("paymentId") final Long paymentId) {
        return ResponseEntity.ok().body(paymentService.updateCancelPayment(petitionId, null, paymentId));
    }

    @GetMapping(path = "/{petitionId}/payments/{paymentId}/transaction/{transactionId}/cancel", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> processCancelPaymentWithTransactionId(
            @Valid @NotNull @PathVariable("petitionId") final Long petitionId,
            @Valid @NotNull @PathVariable("paymentId") final Long paymentId,
            @Valid @NotNull @PathVariable("transactionId") final String transactionId) {
        log.error("In cancel payment method for transaction : ", transactionId);
        return ResponseEntity.ok().body(paymentService.updateCancelPayment(petitionId, transactionId, paymentId));
    }

    /**
     * This method is used to retrieve the petition details
     *
     * @param petitionQuery - query object contains petition number or identifier
     */
    @GetMapping
    public Petition getPetitionDetails(final PetitionQuery petitionQuery) {
        return petitionService.getPetitionDetails(petitionQuery);

    }

    /**
     * This method is used to delete the petition details
     * 
     * @param petitionQuery - query object contains petition number or identifier
     */
    @DeleteMapping
    public void deletePetition(final PetitionQuery petitionQuery) {
        petitionService.deletePetitionDetails(petitionQuery);
    }
}
