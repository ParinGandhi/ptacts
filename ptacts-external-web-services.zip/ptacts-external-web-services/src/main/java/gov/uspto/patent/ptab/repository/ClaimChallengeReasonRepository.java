package gov.uspto.patent.ptab.repository;

import gov.uspto.patent.ptab.entities.ClaimChallengeReason;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ClaimChallengeReasonRepository extends JpaRepository<ClaimChallengeReason, Long> {

    @Query("select DISTINCT(prcdngStatyGrndClmRsn.claimChallengeReason) FROM PrcdngStatyGrndClmRsn prcdngStatyGrndClmRsn "
            + "where prcdngStatyGrndClmRsn.prcdngClmStatyGround.proceedingClaim.fkProceedingId = (?1)")
    List<ClaimChallengeReason> getAllClaims(final Long proceedingId);

    @Query(value = "select claimChallengeReason from ClaimChallengeReason claimChallengeReason "
            + "where claimChallengeReason.claimChallengeReasonId=(?1)")
    ClaimChallengeReason getClaimChallengeReason(final Long claimChallengeReasonId);

}
