package gov.uspto.patent.ptab.common.opsg.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.validation.Valid;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Description of ApplicationAddress used in attorney services.
 *
 * @author 2020 Development Team
 */
@Data
@EqualsAndHashCode(callSuper = true)
@JsonInclude(Include.NON_NULL)
public class ApplicationAddress extends PatentCaseCommonDomain {

    private String reasonCode;

    @Valid
    private Address address;

    private String correspondenceOnlyFlag;

    private String action;

    private String stageCategoryCode;

    private String reasonText;

}
