package gov.uspto.patent.ptab.entities;

import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "TRANSACTION_AUTHRZN_DTL")
public class TransactionAuthorizationDetailEntity {

    @Id
    @Column(name = "TRANSACTION_TOKEN_ID", unique = true, nullable = false, precision = 15, scale = 0)
    private BigDecimal transactionTokenId;

    @Column(name = "SERVER_AUTHRZN_TOKEN_TX")
    private String serverAuthorizationTokenText;

    @Column(name = "TRANSACTION_TS")
    private Date transactionTimestamp;

    @Column(name = "USER_ID")
    private String userId;

    @Column(name = "AUTH_TOKEN_UTILIZED_IND")
    private String authTokenUtilizedIndicator;
}
