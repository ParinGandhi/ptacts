package gov.uspto.patent.ptab.dao;

import gov.uspto.patent.ptab.domain.ProceedingClaims;

/**
 * This is an interface for proceeding claims info
 * 
 * @author 2020 development team
 *
 */
public interface ProceedingClaimsInfoDAO {
    public ProceedingClaims getProceedingClaimsInfo(String caseNumber);
    public void createProceedingClaimsInfo(ProceedingClaims proceedingClaims);
}
