package gov.uspto.patent.ptab.entities;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the PROCEEDING_MILESTONE database table.
 * 
 */
@Entity
@Table(name = "PROCEEDING_MILESTONE")
@NamedQuery(name = "ProceedingMilestone.findAll", query = "SELECT p FROM ProceedingMilestone p")
@NoArgsConstructor
@Getter
@Setter
public class ProceedingMilestone extends AbstractAuditEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PROCEEDING_MILESTONE_SEQ")
    @SequenceGenerator(name = "PROCEEDING_MILESTONE_SEQ", sequenceName = "PROCEEDING_MILESTONE_SEQ", allocationSize = 1)
    @Column(name = "PROCEEDING_MILESTONE_ID")
    private long proceedingMilestoneId;

    @Version
    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo;

    @Column(name = "FK_PROCEEDING_ID")
    private Long fkProceedingId;

    @Column(name = "FK_MILESTONE_TYPE_ID")
    private Long fkMilestoneTypeId;

    @Temporal(TemporalType.DATE)
    @Column(name = "MILESTONE_DT")
    private Date milestoneDt;

    @Column(name = "OUTCOME_STATUS")
    private String outcomeStatus;

    @Column(name = "FK_DECISION_OUTCOME_TYPE_ID")
    private Long fkDecisionOutcomeTypeId;

    @ManyToOne
    @JoinColumn(name = "FK_PROCEEDING_ID", insertable = false, updatable = false)
    private ProceedingEntity proceeding;

    @ManyToOne
    @JoinColumn(name = "FK_MILESTONE_TYPE_ID", insertable = false, updatable = false)
    private StndMilestoneType stndMilestoneType;

    @ManyToOne
    @JoinColumn(name = "FK_DECISION_OUTCOME_TYPE_ID", insertable = false, updatable = false)
    private StndDecisionOutcomeType stndDecisionOutcomeType;

}