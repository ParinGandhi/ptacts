package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the STND_PRCDNG_PARTY_GROUP_TYPE database table.
 * 
 */
@Entity
@Table(name = "STND_PRCDNG_PARTY_GROUP_TYPE")
@NamedQuery(name = "StndPrcdngPartyGroupType.findAll", query = "SELECT s FROM StndPrcdngPartyGroupType s")
@Data
@EqualsAndHashCode(callSuper = false)
public class StndPrcdngPartyGroupType extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "PRCDNG_PARTY_GROUP_TYPE_ID")
    private long prcdngPartyGroupTypeId;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Column(name = "DESCRIPTION_TX")
    private String descriptionTx;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    @Column(name = "PRCDNG_PARTY_GROUP_TYPE_CD")
    private String prcdngPartyGroupTypeCd;

    // bi-directional many-to-one association to ProceedingPartyGroup
    @OneToMany(mappedBy = "stndPrcdngPartyGroupType")
    private List<ProceedingPartyGroup> proceedingPartyGroups;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "stndPrcdngPartyGroupType")
    private List<PrcdngInventionDisclosureEntity> prcdngInventionDisclosureEntitys;

}