package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.gson.Gson;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.domain.ProceedingPartyQuery;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to get proceeding party details
 *
 * @author 2020 development team
 *
 */
@Component
@Slf4j
public class ProceedingPartyService {

    private static final String SWITCH_COUNSEL_URL = "SWITCH_COUNSEL_URL";
    private static final String PROCEEDING_PARTY_DETAILS_URL = "PROCEEDING_PARTY_DETAILS_URL";
    private static final String PROCEEDING_PARTY_EXHIBIT_URL = "PROCEEDING_PARTY_EXHIBIT_URL";
    private static final String IS_LEAD_COUNSEL_QUERY_PARAM = "?isLeadCounsel=";
    private static final String PARTY_REPRESENT_INDICATOR_QUERY_PARAM = "?partyRepresentIndicator=";
    private static final String PROCEEDING_NUMBER_QUERY_PARAM = "?proceedingNumber";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    private static final String PROCEEDING_PARTY_URL = "PROCEEDING_PARTY_URL";
    private static final String PROCEEDING_URL = "Proceeding Party details Url";
    private static final String USER_ID = "User Id";
    private static final String USER_NAME_ATTRIBUTE_KEY = "valid-user";

    
    @Autowired
    private HttpServletRequest httpServletRequest;

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Autowired
    private ExternalUserService externalUserService;

    @Autowired
    private PTABBusinessUtils ptabBusinessUtils;

    /**
     * Method used to get the next exhibit number
     *
     * @param proceedingNumber - proceeding number
     * @return
     */
    @Transactional
    public Map<String, String> getNextExhibitNumber(final String proceedingNumber) {

        final String proceedingPartyExhibitUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_PARTY_EXHIBIT_URL);
        notFoundIfNull(proceedingPartyExhibitUrl, "Proceeding Party Exhibit Url");
        final String userName = getLoggedInUserId();
        log.info("calling trail services for fetching next exhibiit number for proceeding number : {}", proceedingNumber);

        ResponseEntity<String> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(
                    proceedingPartyExhibitUrl + PROCEEDING_NUMBER_QUERY_PARAM + StringUtils.trim(proceedingNumber), null,
                    HttpMethod.GET, String.class, userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException((HttpStatus) ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response
                ? new Gson().fromJson(response.getBody(), new ParameterizedTypeReference<Map<String, String>>() {
                }.getType())
                : null;

    }

    /**
     * Method used to save the proceeding party details
     *
     * @param proceedingParties - request object containing the proceeding party details
     * @param partyRepresentIndicator - party represent indicator
     */
    @Transactional
    public void savePartyDetails(@Valid @NotNull final JsonNode proceedingParties, final String partyRepresentIndicator) {

        final String proceedingPartyDetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_PARTY_URL);
        notFoundIfNull(proceedingPartyDetailsUrl, PROCEEDING_URL);
        final String userName = getLoggedInUserId();
        try {
            restServiceClient.callPTABExternalServiceURL(
                    proceedingPartyDetailsUrl + PARTY_REPRESENT_INDICATOR_QUERY_PARAM + partyRepresentIndicator,
                    proceedingParties, HttpMethod.POST, JsonNode.class, userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException((HttpStatus) ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }

    }

    /**
     * Method used to update the proceeding party details
     *
     * @param proceedingParties - request object containing the proceeding party details
     *
     */
    @Transactional
    public void updatePartyDetails(@Valid @NotNull final JsonNode proceedingParties) {

        final String proceedingPartyDetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_PARTY_URL);
        notFoundIfNull(proceedingPartyDetailsUrl, PROCEEDING_URL);
        final String userName = getLoggedInUserId();

        try {
            restServiceClient.callPTABExternalServiceURL(proceedingPartyDetailsUrl, proceedingParties, HttpMethod.PUT,
                    JsonNode.class, userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException((HttpStatus) ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }

    }

    /**
     * Method used to delete proceeding party details
     *
     * @param proceedingPartyQuery - object containing the query parameter information
     * @param userName - user name
     */
    @Transactional
    public void deletePartyDetails(final ProceedingPartyQuery proceedingPartyQuery) {

        final String proceedingPartyDetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_PARTY_URL);
        notFoundIfNull(proceedingPartyDetailsUrl, PROCEEDING_URL);
        final String userName = getLoggedInUserId();

        final String url = externalServiceUriGenerator.getProceedingPartyDeleteUrl(proceedingPartyQuery,
                proceedingPartyDetailsUrl);

        try {
            restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.DELETE, Void.class, userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException((HttpStatus) ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
    }

    /**
     * Method used to perform counsel switch
     *
     * @param proceedingParties - request object containing the proceeding party details
     * @param isLeadCounsel - indicator value holding lead counsel information
     *
     */
    @Transactional
    public JsonNode performCounselSwitch(@Valid @NotNull final JsonNode proceedingParties, final Boolean isLeadCounsel) {

        final String swicthCounselUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                SWITCH_COUNSEL_URL);
        notFoundIfNull(swicthCounselUrl, "Switch Counsel Url");
        final String userName = getLoggedInUserId();
        ResponseEntity<JsonNode> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(
                    swicthCounselUrl + IS_LEAD_COUNSEL_QUERY_PARAM + isLeadCounsel, proceedingParties, HttpMethod.PUT,
                    JsonNode.class, userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException((HttpStatus) ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response ? response.getBody() : null;
    }

    /**
     * Method used to fetch the proceeding party details
     *
     * @param caseDocumentsDataQuery - object containing the query parameter information
     *
     */
    @Transactional
    public JsonNode getAllProceedingPartyDetails(@Valid @NotNull final CaseDocumentsDataQuery caseDocumentsDataQuery) {

        final String proceedingPartyDetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_PARTY_DETAILS_URL);
        notFoundIfNull(proceedingPartyDetailsUrl, PROCEEDING_URL);

        final String userName = getLoggedInUserId();

        final String submitterType = externalUserService
                .getPrcdPartyGroupType(caseDocumentsDataQuery.getProceedingNumber());
        if (StringUtils.equals(submitterType, "PETITIONER")) {
            caseDocumentsDataQuery.setIncludePetitionerStaffDetails(true);
        } else if (StringUtils.equals(submitterType, "PATENTOWNER")) {
            caseDocumentsDataQuery.setIncludePoStaffDetails(true);
        } else {
            caseDocumentsDataQuery.setIncludePoStaffDetails(false);
            caseDocumentsDataQuery.setIncludePetitionerStaffDetails(false);
        }
        final String url = externalServiceUriGenerator.getCaseDocumentDataQueryUrl(caseDocumentsDataQuery,
                proceedingPartyDetailsUrl);
        ResponseEntity<JsonNode> response = null;

        try {
            response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, JsonNode.class, userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException((HttpStatus) ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response ? response.getBody() : null;
    }

    @Transactional
    public JsonNode getPrcdCounselInfo(final String caseType, final String registrationNumber, final String email) {
        final String proceedingPartyDetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PROCEEDING_PARTY_DETAILS_URL);
        notFoundIfNull(proceedingPartyDetailsUrl, PROCEEDING_URL);

        final String userName = getLoggedInUserId();
        final String url = externalServiceUriGenerator.getProceedingPartyDetailsUrl(caseType, registrationNumber, email,
                proceedingPartyDetailsUrl);
        ResponseEntity<JsonNode> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, JsonNode.class, userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException((HttpStatus) ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response ? response.getBody() : null;
    }
    
    public String getLoggedInUserId() {
        final String userIdentifier = (String) httpServletRequest.getAttribute(USER_NAME_ATTRIBUTE_KEY);
        if (StringUtils.isBlank(userIdentifier)) {
            notFoundIfNull(userIdentifier, USER_ID);
        }
        return userIdentifier;
    }
}
