package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.TrialsBase;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to get case viewer details
 *
 * @author 2020 development team
 *
 */
@Component
@Slf4j
public class CaseViewerService {

    private static final String CASE_NUMBER_SEARCH_URL = "CASE_NUMBER_SEARCH_URL";
    private static final String CASE_VIEWER_DETAILS_URL = "CASE_VIEWER_DETAILS_URL";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    private static final String SYSTEM_USER = "SYSTEM_USER";
    private static final String PTAB_CASE_INIT = "PTAB_CASE_INIT";

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    /**
     * Method used to get the case viewer details
     *
     * @param trialsbase - request object containing the query parameter information
     *
     */
    @Transactional
    public JsonNode getBasicDataDetails(TrialsBase trialsbase) {

        final String caseviewerdetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                CASE_VIEWER_DETAILS_URL);
        notFoundIfNull(caseviewerdetailsUrl, "Case Viewer details Url");
        final String url = externalServiceUriGenerator.getCaseViewerDetailsUrl(trialsbase, caseviewerdetailsUrl);
        final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(systemUserName, "system user name");
        ResponseEntity<JsonNode> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, JsonNode.class,
                    systemUserName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response ? response.getBody() : null;
    }

    /**
     * Method used to get the case data
     *
     * @param searchType -search type
     * @param caseNumber - case number
     *
     */
    @Transactional
    public JsonNode getValidCaseData(String searchType, @Valid @NotNull String caseNumber) {

        final String caseNumberSearchUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                CASE_NUMBER_SEARCH_URL);
        notFoundIfNull(caseNumberSearchUrl, "Case number search Url");
        final String url = externalServiceUriGenerator.getCaseNumberSearchUrl(searchType, caseNumber, caseNumberSearchUrl);
        final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(systemUserName, "system user name");
        ResponseEntity<JsonNode> jsonresponse = null;
        try {
            jsonresponse = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, JsonNode.class,
                    systemUserName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != jsonresponse ? jsonresponse.getBody() : null;
    }

}
