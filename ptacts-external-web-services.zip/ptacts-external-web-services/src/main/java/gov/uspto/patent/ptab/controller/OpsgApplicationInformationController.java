package gov.uspto.patent.ptab.controller;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.common.opsg.domain.ApplicationIdentifierQuery;
import gov.uspto.patent.ptab.service.ApplicationInformationService;

/**
 * This class is used to get application general information details
 *
 * @author 2020 development team
 *
 */
@RestController
@RequestMapping("/opsg-application-general-information")
public class OpsgApplicationInformationController {

    @Autowired
    private ApplicationInformationService applicationInformationService;

    /**
     * The method is used to retrieve application general information and set the details into ApplicationInfoResponse
     * object
     *
     * @param applicationIdentifierQuery - query parameters to get address details
     */
    @GetMapping
    public JsonNode getApplicationInfoDetails(
            @Valid @NotNull final ApplicationIdentifierQuery applicationIdentifierQuery) {
        return applicationInformationService.getApplicationInfoDetails(applicationIdentifierQuery);

    }
}
