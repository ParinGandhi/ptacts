package gov.uspto.patent.ptab.domain;

import lombok.Getter;
import lombok.Setter;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Getter
@Setter
@Valid
public class Claims {
    private String identifier;
    @NotNull
    @NotBlank
    private String asCaptured;
    private String expanded;
    private String count;
    @NotNull
    @NotBlank
    private String category;
    @NotNull
    private Long statGroundId;
}
