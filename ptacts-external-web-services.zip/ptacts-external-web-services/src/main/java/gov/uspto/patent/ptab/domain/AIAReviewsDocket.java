package gov.uspto.patent.ptab.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * VO for External User Docket information
 *
 */
@Data
@Setter
@Getter
@JsonInclude(Include.NON_NULL)
public class AIAReviewsDocket implements Serializable {
    private static final long serialVersionUID = -2323296988550880079L;
    private BigDecimal createUserId;
    private BigDecimal proceedingId;
    private BigDecimal proceedingPartyGroupId;
    private String filingDate;
    private String noticeAccordedFilingDate;
    private String poPreliminaryRespFilingDate;
    private String instDecisionDate;
    private String terminationDecisionDate;
    private String userRole;
    private String partyRepresent;
    private String proceedingNo;
    private String proceedingTypeCd;
    private String poPetitionerName;
    private String patentOwnerName;
    private String petitionerPatentNumber;
    private String petitionerApplicationNumber;
    private String poApplicationNumber;
    private String poPatentNumber;
    private String poRealParty;
    private String petitionerRealParty;
    private String status;
    private String userPartyGroupType;
    private String prcdCreatedTs;
    private String lastModifiedTimestamp;
    private List<String> judges;
    private String petiTechCenterId;
    private String poTechCenterId;
}
