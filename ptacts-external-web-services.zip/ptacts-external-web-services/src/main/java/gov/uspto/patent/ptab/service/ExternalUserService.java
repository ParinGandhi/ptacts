package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.dao.ExternalUserDao;
import gov.uspto.patent.ptab.dao.ProceedingDao;
import gov.uspto.patent.ptab.domain.CodeReferenceLookup;
import gov.uspto.patent.ptab.domain.FilingPartyDropDownList;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ExternalUserService {

    private static final String EXTERNAL_USER_URL = "EXTERNAL_USER_URL";
    private static final String USER_ID = "User Id";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    private static final String SYSTEM = "system user name";
    private static final String SYSTEM_USER = "SYSTEM_USER";
    private static final String PTAB_CASE_INIT = "PTAB_CASE_INIT";

    @Autowired
    ExternalUserDao externalUserDao;
    @Autowired
    ProceedingDao proceedingDao;

    @Autowired
    private HttpServletRequest httpServletRequest;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private RestServiceClient restServiceClient;

    @Transactional
    public String getPrcdPartyGroupType(final String proceedingNum) {
        final String userId = getUserId();
        return externalUserDao.getUserPrcdPartyGroupType(userId, proceedingNum);
    }

    @Transactional
    public String getPrcdPartyGroupTypeForStaff(final String proceedingNum) {
        final String userId = getUserId();
        return externalUserDao.getUserPrcdPartyGroupTypeForStaff(userId, proceedingNum);
    }

    @Transactional
    public JsonNode getAllExternalUserDetails() {

        final String externalServiceUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                EXTERNAL_USER_URL);
        notFoundIfNull(externalServiceUrl, "external service url");

        final String userName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(userName, SYSTEM);

        ResponseEntity<JsonNode> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(externalServiceUrl, null, HttpMethod.GET,
                    JsonNode.class, userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException((HttpStatus) ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response ? response.getBody() : null;
    }

    private String getUserId() {
        final String userIdentifier = (String) httpServletRequest.getAttribute("valid-user");
        if (StringUtils.isEmpty(userIdentifier))
            notFoundIfNull(userIdentifier, USER_ID);
        return userIdentifier;
    }

    /**
     * 
     * @param proceedingNo
     * @return
     */
    public FilingPartyDropDownList getDropDownlist(final String proceedingNo) {
        final FilingPartyDropDownList dropdownList = new FilingPartyDropDownList();

        try {
            final String userId = getUserId();
            final List<CodeReferenceLookup> refValues = codeReferenceDao
                    .fetchCodeReferenceViaTypeCode("PARTY_DROP_DOWN_LIST");
            String currentState = proceedingDao.getProceedingState(proceedingNo);
            currentState = "~" + currentState + "~";
            notFoundIfNull(proceedingNo, "Invalid Proceeding Number");
            final String partyType = externalUserDao.getUserPrcdPartyGroupType(userId, proceedingNo);
            if (org.apache.commons.collections.CollectionUtils.isNotEmpty(refValues)) {
                for (final CodeReferenceLookup indCdRfVal : refValues) {
                    if (!indCdRfVal.getDescriptionText().contains(currentState)) {
                        if (StringUtils.equalsIgnoreCase("prelim", indCdRfVal.getValueText())) {
                            dropdownList.setPrelim(false);
                        }
                        if (StringUtils.equalsIgnoreCase("appeal", indCdRfVal.getValueText())) {
                            dropdownList.setAppeal(false);
                        }
                    }
                    if (!proceedingNo.startsWith("DER") && indCdRfVal.getDescriptionText().contains(currentState)) {
                        if (StringUtils.equalsIgnoreCase("directorReview", indCdRfVal.getValueText())) {
                            dropdownList.setDirectorReview(true);
                        }
                    }
                }
            }
            if (!StringUtils.equalsIgnoreCase("PATENTOWNER", partyType)) {
                dropdownList.setPrelim(false);
            }
            dropdownList.setPartyRepresenting(partyType);
        } catch (IllegalArgumentException | SecurityException e) {
            throw new PTABException(HttpStatus.INTERNAL_SERVER_ERROR,
                    new ErrorPayload(" Object Conversion Error" + " " + "Test" + " " + e.getMessage()));
        }
        return dropdownList;
    }

}