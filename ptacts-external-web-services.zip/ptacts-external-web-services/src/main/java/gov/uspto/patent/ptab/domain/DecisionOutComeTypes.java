package gov.uspto.patent.ptab.domain;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class DecisionOutComeTypes {

    private Long identifier;
    private String code;
    private String descriptionText;
    private String displayNameText;
    private Date beginingEffectiveDate;
    private long outComeCategoryType;
    private String outComeCategoryDesc;

}
