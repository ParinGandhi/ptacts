/*******************************************************************************
 * 2016, All rights reserved.
 *******************************************************************************/
package gov.uspto.patent.ptab.common.opsg.domain;

//import jakarta.validation.Valid;
//import jakarta.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Description of Inventor PCDM.
 * 
 * @author 2020 Development Team
 */
@Data
@JsonInclude(Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
public class Inventor extends PatentCaseCommonDomain {

    @Valid
    @NotNull
    private InterestedParty interestedParty = new InterestedParty();

    @Valid
    @NotNull(message = "persons cannot be null")
    private Person persons;

    private boolean isOathDecComplaint = true;
    private String inventorCompliant = "Y";
    private String identifiedProblems = "";
    private String oathDecProblem = "";

}
