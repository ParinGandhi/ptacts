package gov.uspto.patent.ptab.utils;

import java.io.IOException;
import java.util.Date;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

/**
 * This class is used for deserialize Epoch Date
 *
 * @author 2020 Development Team
 *
 */
public class EpochDeserializer extends JsonDeserializer<Date> {

    public static final int DEFAULT_TIME_FOR_SERIALIZE_DESERIALIZSE = 1000;

    /**
     * This method is used for deserialization
     *
     * @param jsonParser - JsonParser for reading json content
     * @param deserializationContext - Context for the process of
     *            deserialization a single root-level value. Used to allow
     *            passing in configuration settings and reusable temporary
     *            objects (scrap arrays, containers).
     * @throws IOException
     */
    @Override
    public Date deserialize(final JsonParser jsonParser, final DeserializationContext deserializationContext) throws IOException {
        return new Date(Long.parseLong(jsonParser.getText()) * DEFAULT_TIME_FOR_SERIALIZE_DESERIALIZSE);
    }

}
