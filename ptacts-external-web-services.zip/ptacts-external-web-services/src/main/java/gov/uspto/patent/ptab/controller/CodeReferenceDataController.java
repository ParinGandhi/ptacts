package gov.uspto.patent.ptab.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.patent.ptab.domain.CodeReferenceLookup;
import gov.uspto.patent.ptab.domain.CodeReferenceQuery;
import gov.uspto.patent.ptab.service.ReferenceDataService;
import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to retrieve the reference data
 *
 * @author 2020 development team
 *
 */
@RestController
@RequestMapping("/reference-data")
@Slf4j
public class CodeReferenceDataController {

    @Autowired
    private ReferenceDataService referenceDataService;

    /**
     * This method is used to retrieve values from code reference table
     *
     * @return
     */
    @GetMapping(value = "/code-reference-types")
    public List<CodeReferenceLookup> getCodeReferenceTypes(final CodeReferenceQuery codeReferenceQuery) {
        log.info("getCodeReferenceTypes: ", codeReferenceQuery);
        return referenceDataService.getCodeReferenceType(codeReferenceQuery);
    }
}
