package gov.uspto.patent.ptab.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * This class is having the details of the standard reference data
 *
 * @author 2020 development team
 *
 */
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class ReferenceType {

    private Long identifier;
    private String code;
    private String descriptionText;
    private String displayNameText;
    private String labelNameText;
    private String significantIndicator;
    private String joinderCheckIndicator;

    private DocumentTypeCustomAttributes documentTypeCustomAttributes;
    private List<DecisionOutcomeGroupType> decisionOutcomeGroupTypes;
    private List<AvailableFilter> availableFilters;

}
