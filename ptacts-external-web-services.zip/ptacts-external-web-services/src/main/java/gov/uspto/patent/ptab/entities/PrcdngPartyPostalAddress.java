package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the PRCDNG_PARTY_POSTAL_ADDRESS database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = "PRCDNG_PARTY_POSTAL_ADDRESS")
@NamedQuery(name = "PrcdngPartyPostalAddress.findAll", query = "SELECT p FROM PrcdngPartyPostalAddress p")
public class PrcdngPartyPostalAddress implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "PRCDNG_PARTY_POSTAL_ADDRESS_PRCDNGPARTYPOSTALADDRESSID_GENERATOR",
            sequenceName = "PRCDNG_PARTY_POSTAL_ADDR_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "PRCDNG_PARTY_POSTAL_ADDRESS_PRCDNGPARTYPOSTALADDRESSID_GENERATOR")
    @Column(name = "PRCDNG_PARTY_POSTAL_ADDRESS_ID")
    private Long prcdngPartyPostalAddressId;

    @Column(name = "ADDRESS_LINE_1_TX")
    private String addressLine1Tx;

    @Column(name = "ADDRESS_LINE_2_TX")
    private String addressLine2Tx;

    @Column(name = "CITY_NM")
    private String cityNm;

    @Column(name = "COUNTRY_CD")
    private String countryCd;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS", timezone = "US/Eastern")
    @Column(name = "CREATE_TS")
    private Date createTs;

    @Column(name = "CREATE_USER_ID")
    private BigDecimal createUserId;

    @Column(name = "FK_ADDRESS_TYPE_ID")
    private BigDecimal fkAddressTypeId;

    @Column(name = "FK_PROCEEDING_PARTY_ID")
    private BigDecimal fkProceedingPartyId;

    @Column(name = "GEOGRAPHIC_REGION_CD")
    private String geographicRegionCd;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS", timezone = "US/Eastern")
    @Column(name = "LAST_MOD_TS")
    private Date lastModTs;

    @Column(name = "LAST_MOD_USER_ID")
    private BigDecimal lastModUserId;

    @Column(name = "LOCK_CONTROL_NO")
    private BigDecimal lockControlNo;

    @Column(name = "OTHER_GEOGRAPHIC_REGION_TX")
    private String otherGeographicRegionTx;

    @Column(name = "POSTAL_CD")
    private String postalCd;

    // bi-directional many-to-one association to ProceedingParty
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "FK_PROCEEDING_PARTY_ID", insertable = false, updatable = false)
    private ProceedingParty proceedingParty;

    @ManyToOne
    @JoinColumn(name = "FK_ADDRESS_TYPE_ID", insertable = false, updatable = false)
    private StndAddressType stndAddressType;

}