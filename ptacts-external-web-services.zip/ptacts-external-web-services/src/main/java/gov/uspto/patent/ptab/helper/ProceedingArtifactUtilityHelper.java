package gov.uspto.patent.ptab.helper;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.DocumentTypeCustomAttributes;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.domain.ProceedingArtifactDetail;
import gov.uspto.patent.ptab.domain.ReferenceSummary;
import gov.uspto.patent.ptab.entities.ArtifactSubmission;
import gov.uspto.patent.ptab.entities.ArtifactSubmissionStatus;
import gov.uspto.patent.ptab.entities.Document;
import gov.uspto.patent.ptab.entities.Exhibit;
import gov.uspto.patent.ptab.entities.ProceedingArtifact;
import gov.uspto.patent.ptab.entities.StndArtifactType;
import gov.uspto.patent.ptab.entities.StndAvailability;
import gov.uspto.patent.ptab.entities.StndDocumentType;
import gov.uspto.patent.ptab.entities.StndProxySubmitterRole;
import gov.uspto.patent.ptab.utils.DateUtilityHelper;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProceedingArtifactUtilityHelper {

    private static final String USER_ROLE_PO = "PATENT OWNER";
    private static final String DASH = "-";
    private static final String UNDER_SCORE = "_";
    private static final String EXPUNGED = "EXPUNGED";
    private static final String DOCUMENT_INITIATED = "INITIATED";
    public static final String PAPER_DOCUMENT_TYPE = "PAPER";
    public static final String EXHIBITS_DOCUMENT_TYPE = "EXHIBIT";
    public static final String USER_ROLE_PETITIONER = "petitioner";
    public static final String USER_ROLE_PATENT_OWNER = "patent owner";
    public static final String ALFRESCO_PATENT_OWNER = "patent_owner";
    public static final String PATENTOWNER_PROXY_ROLE = USER_ROLE_PO;
    public static final String USER_ROLE_BOARD = "board";
    public static final int PETITIONER_EXHIBIT_SEQNO_START = 1001;
    public static final int PETITIONER_EXHIBIT_SEQNO_END = 1999;
    public static final int PATOWNER_EXHIBIT_SEQNO_START = 2001;
    public static final int PATOWNER_EXHIBIT_SEQNO_END = 2999;
    public static final int BOARD_EXHIBIT_SEQNO_START = 3001;
    public static final int BOARD_EXHIBIT_SEQNO_END = 3999;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    public void getAllPetitionDocuments(final List<PetitionDocument> petitionDocumentList,
            final List<ProceedingArtifact> proceedingArtifactList) {
        for (final ProceedingArtifact proceedingArtifact : proceedingArtifactList) {
            final PetitionDocument petitionDocument = new PetitionDocument();

            final ArtifactSubmission artifactSubmission = proceedingArtifact.getArtifactSubmission();
            final Document document = proceedingArtifact.getDocument();
            final Exhibit exhibit = proceedingArtifact.getExhibit();

            petitionDocument.setArtifactSubmissionIdentifier(artifactSubmission.getArtifactSubmissionId());
            petitionDocument.setFilingDate(DateUtilityHelper.convertDateToLong(proceedingArtifact.getFilingTS()));
            if (null != proceedingArtifact.getFilingTS()) {
                petitionDocument.setFilingDateString(
                        DateUtilityHelper.convertDateToString(proceedingArtifact.getFilingTS(), "MM/dd/yyyy"));
            }
            final StndAvailability stndAvailability = proceedingArtifact.getStndAvailability();
            petitionDocument.setAvailability(stndAvailability.getDisplayName());

            final ReferenceSummary availablitySummary = new ReferenceSummary();
            availablitySummary.setCode(stndAvailability.getAvailabilityCd());
            availablitySummary.setDescriptionText(stndAvailability.getDescriptionTx());
            availablitySummary.setDisplayNameText(stndAvailability.getDisplayName());
            petitionDocument.setAvailablitySummary(availablitySummary);

            petitionDocument.setName(proceedingArtifact.getArtifactNm());
            petitionDocument.setFileName(proceedingArtifact.getFileName());
            petitionDocument.setPageCount(proceedingArtifact.getPageCountQt());
            petitionDocument.setDirectionCode(proceedingArtifact.getFkDirectionCd());
            petitionDocument.setArtifactIdentifer(String.valueOf(proceedingArtifact.getProceedingArtifactId()));
            petitionDocument.setContentManagementId(proceedingArtifact.getContentManagementId());
            petitionDocument.setCommentText(proceedingArtifact.getComment());
            if (null != exhibit) {

                final StndArtifactType stndArtifactType = proceedingArtifact.getStndArtifactType();
                final ReferenceSummary artifactSummary = new ReferenceSummary();
                artifactSummary.setCode(stndArtifactType.getArtifactTypeCd());
                artifactSummary.setDescriptionText(stndArtifactType.getDescriptionTx());
                petitionDocument.setArtifactSummary(artifactSummary);

                petitionDocument.setCategory(EXHIBITS_DOCUMENT_TYPE);
                petitionDocument.setExhibitNumber(exhibit.getExhibitNo());
            }
            buildDocumentDetails(petitionDocument, document, proceedingArtifact.getStndArtifactType());
            buildArtifactSubmissionStatusDetails(petitionDocument, proceedingArtifact);
            petitionDocumentList.add(petitionDocument);
        }
    }

    private void buildDocumentDetails(final PetitionDocument petitionDocument, final Document document,
            final StndArtifactType stndArtifactType) {

        if (null != document) {
            petitionDocument.setDocumentNumber(document.getDocumentNo());
            petitionDocument.setCategory(PAPER_DOCUMENT_TYPE);
            final ReferenceSummary artifactSummary = new ReferenceSummary();
            artifactSummary.setCode(stndArtifactType.getArtifactTypeCd());
            artifactSummary.setDescriptionText(stndArtifactType.getDescriptionTx());
            petitionDocument.setArtifactSummary(artifactSummary);
            final StndDocumentType stndDocumentType = document.getStndDocumentType();
            if (null != stndDocumentType) {
                petitionDocument.setDocumentTypeCode(stndDocumentType.getDocumentTypeCd());
                petitionDocument.setDocumentTypeIdentifier(stndDocumentType.getDocumentTypeId());
                petitionDocument.setDocumentTypeCode(stndDocumentType.getDocumentTypeCd());
                petitionDocument.setDocumentTypeDescription(stndDocumentType.getDocumentTypeNm());
                setCustomAttributesToDocument(petitionDocument, stndDocumentType);
            }
        }
    }

    private void setCustomAttributesToDocument(final PetitionDocument petitionDocument,
            final StndDocumentType stndDocumentType) {
        if (StringUtils.isNotEmpty(stndDocumentType.getCustomAttributes())) {
            final String customAttrJson = stndDocumentType.getCustomAttributes();
            final ObjectMapper mapper = new ObjectMapper();
            try {
                final DocumentTypeCustomAttributes customAttrs = mapper.readValue(customAttrJson,
                        DocumentTypeCustomAttributes.class);
                petitionDocument.setDocumentTypeCustomAttributes(customAttrs);
            } catch (final Exception jse) {
                log.error(jse.getMessage(), jse);
            }
        }
    }

    private void buildArtifactSubmissionStatusDetails(final PetitionDocument petitionDocument,
            final ProceedingArtifact proceedingArtifact) {

        final ArtifactSubmissionStatus artifactSubmissionStatus = proceedingArtifact.getArtifactSubmission()
                .getArtifactSubmissionStatuses();
        if (null != artifactSubmissionStatus) {
            final String documentStatus = StringUtils.trim(artifactSubmissionStatus.getFkSubmissionStatusCd());
            petitionDocument.setDocumentStatus(artifactSubmissionStatus.getFkSubmissionStatusCd());
            final StndProxySubmitterRole proxyRole = artifactSubmissionStatus.getStndProxySubmitterRole();
            if (proxyRole != null) {
                final String proxySubmitterRoleNm = proxyRole.getDisplayName();

                petitionDocument.setFilingParty(StringUtils.lowerCase(proxySubmitterRoleNm));

                final ReferenceSummary roleSummary = new ReferenceSummary();
                roleSummary.setCode(proxyRole.getProxySubmitterRoleNm());
                roleSummary.setDescriptionText(proxyRole.getDescriptionTx());
                roleSummary.setDisplayNameText(proxyRole.getDisplayName());
                petitionDocument.setRoleSummary(roleSummary);
            }
            if (StringUtils.equals(documentStatus, EXPUNGED)) {
                petitionDocument.setName(EXPUNGED + UNDER_SCORE + petitionDocument.getName());
                petitionDocument.setAvailability(EXPUNGED + DASH + petitionDocument.getAvailability());
            }
        }
    }

    public void addFilterToUpdatePetitionDocs(final List<PetitionDocument> prcdArtifacts, final String prcdPartyGrpType) {
        final List<PetitionDocument> removePetitions = new ArrayList<>();
        final String dontPubMsgs = codeReferenceDao.findDescriptionByTypeCodeAndValueTx("PTACTS_EXT_AVAILABILITY",
                "DO_NOT_PUBLISH");
        notFoundIfNull(dontPubMsgs, "Do Not Publish message Types is not configured.");
        final List<String> dontPubList = Arrays.asList(dontPubMsgs.split("~"));
        if (CollectionUtils.isNotEmpty(prcdArtifacts)) {
            prcdArtifacts.forEach(p -> {
                if (p.getDocumentStatus() != null && p.getDocumentStatus().equalsIgnoreCase(DOCUMENT_INITIATED)) {
                    return;
                }
                final String availability = getAvailability(p);
                String filingParty = removeSpaceCharacters(p.getFilingParty());
                String nonFinalPrcdPartyGrpType = removeSpaceCharacters(prcdPartyGrpType);
                final boolean canViewDocument = canViewDocument(availability, filingParty, nonFinalPrcdPartyGrpType);
                final boolean isDontPublish = dontPubList.stream().anyMatch(availability::equalsIgnoreCase);
                if (!canViewDocument) {
                    p.setContentManagementId(null);
                    p.setArtifactIdentifer(null);
                }
                if (isDontPublish) {
                    removePetitions.add(p);
                }
            });
            prcdArtifacts.removeAll(removePetitions);
        }
    }

    private boolean canViewDocument(final String availability, String filingParty, String prcdPartyGrpType) {

        final String filingPartyAndBoard = "Filing party and Board";
        final String partiesAndBoard = "Parties and Board";
        final String board = "Board";
        final String publicDoc = "Public";

        final boolean sameFilingParty = prcdPartyGrpType.equalsIgnoreCase(filingParty);
        final boolean isPublicDoc = publicDoc.equalsIgnoreCase(availability);
        final boolean isBoardDocument = board.equalsIgnoreCase(availability);
        final boolean isFilingPartyAndBoard = filingPartyAndBoard.equalsIgnoreCase(availability) && sameFilingParty;
        final boolean isPartiesAndBoard = partiesAndBoard.equalsIgnoreCase(availability)
                && StringUtils.isNotEmpty(prcdPartyGrpType);
        if (isBoardDocument)
            return false;
        return (isPublicDoc || isFilingPartyAndBoard || isPartiesAndBoard);
    }

    private String getAvailability(PetitionDocument p) {
        String availability = p.getAvailability();
        if (StringUtils.isNotEmpty(availability)) {
            availability = availability.trim();
        } else {
            availability = "";
        }
        return availability;
    }

    public String getAvailability(ProceedingArtifactDetail p) {
        String availability = p.getAvailability();
        if (StringUtils.isNotEmpty(availability)) {
            availability = availability.trim();
        } else {
            availability = "";
        }
        return availability;
    }

    private String removeSpaceCharacters(String str) {
        if (StringUtils.isNotEmpty(str)) {
            str = str.trim().replaceAll("\\s", "");
        } else {
            str = "";
        }
        return str;
    }
}
