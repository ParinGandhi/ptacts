
package gov.uspto.patent.ptab.common.opsg.domain;


import lombok.Data;

/**
 * Description of ContinuationInformation which represents both child and parent continuity.
 *
 * @author 2020 Development Team
 */
@Data
public class ContinuationInformation {

    private String parentApplicationNumberText;

    private String childApplicationNumberText;

    private Long filingDate;

    // abandon date
    private Long applicationWithdrawnDate;

    // issue date
    private Long grantDate;

    private String applicationStatusNumber;

    private String applicationStatusDescriptionText;

    // application customer
    private String patronIdentifier;

    private String patentNumber;

    private String applicationTypeCategory;

    private String inventionSubjectMatterCategory;

    private String publicIndicator;

    // renamed for aia indicator
    private String firstInventorToFileIndicator;

    private Integer sequenceNumber;

    private Long internationalFilingDate;

    private String parentApplicationStatus;

    private String attorneyDocketNumber;

    private String inconsistencyIndicator;

}
