package gov.uspto.patent.ptab.dao;

import static gov.uspto.patent.ptab.utils.PTABConstants.ONE;
import static gov.uspto.patent.ptab.utils.PTABConstants.ZERO;
import static gov.uspto.patent.ptab.utils.PTABServiceUtils.checkNullAndTrim;
import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;
import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNullCollection;
import static gov.uspto.patent.ptab.utils.PTABServiceUtils.validateAndThrowExceptionWithMsg;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import gov.uspto.patent.ptab.domain.Claims;
import gov.uspto.patent.ptab.domain.ProceedingClaims;
import gov.uspto.patent.ptab.entities.ClaimChallengeReason;
import gov.uspto.patent.ptab.entities.PrcdngClmStatyGround;
import gov.uspto.patent.ptab.entities.PrcdngStatyGrndClmRsn;
import gov.uspto.patent.ptab.entities.ProceedingClaim;
import gov.uspto.patent.ptab.entities.ProceedingEntity;
import gov.uspto.patent.ptab.helper.ProceedingCaseHelper;
import gov.uspto.patent.ptab.repository.ClaimChallengeReasonRepository;
import gov.uspto.patent.ptab.repository.PrcdngClmStatyGroundRepository;
import gov.uspto.patent.ptab.repository.PrcdngStatyGrndClmRsnRepository;
import gov.uspto.patent.ptab.repository.ProceedingRepository;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.PTABConstants;
import lombok.extern.slf4j.Slf4j;

/**
 * This is data access object for proceeding claims info
 * 
 * @author 2020 development team
 *
 */
@Repository("trialsProceedingClaimsInfoDAO")
@Slf4j
public class TrialsProceedingClaimsInfoDAO implements ProceedingClaimsInfoDAO {

    private static final String NO_DATA_FOUND = "no.data.found";

    @Autowired
    protected SessionFactory sessionFactory;

    @Autowired
    ProceedingCaseHelper proceedingCaseHelper;

    @Autowired
    private ProceedingRepository proceedingRepository;

    @Autowired
    private PrcdngClmStatyGroundRepository prcdngClmStatyGroundRepository;

    @Autowired
    private PrcdngStatyGrndClmRsnRepository prcdngStatyGrndClmRsnRepository;

    @Autowired
    private ClaimChallengeReasonRepository claimChallengeReasonRepository;

    @Autowired
    private PTABBusinessUtils ptabBusinessUtils;

    /**
     * This method provides proceeding claims info based by case number
     */
    @Override
    public ProceedingClaims getProceedingClaimsInfo(String caseNumber) {
        ProceedingClaims proceedingClaims = new ProceedingClaims();
        List<Claims> claims = getClaimsInfo(caseNumber);
        proceedingClaims.setClaims(getClaimNumbers(claims));
        return proceedingClaims;
    }

    /**
     * This method provides claims list based on case number
     * 
     * @param caseNumber
     * @return
     */

    public List<Claims> getClaimsInfo(String caseNumber) {
        final Query<Object[]> query = sessionFactory.getCurrentSession().createNamedQuery("getTrailsClaimsInfo",
                Object[].class);
        query.setParameter("caseNumber", caseNumber);
        return prepareClaimsList(query.list());
    }

    /**
     * This method is used to delete the claims based on the claims ids
     * 
     * @param claimIdsList
     * @return
     */

    public int deleteClaimsByIds(final List<BigDecimal> claimIdsList) {
        log.info("Dao call for deleteClaimsByIds method");
        final Query<BigDecimal> query = sessionFactory.getCurrentSession().createNamedQuery("deleteClaimsByIds",
                BigDecimal.class);
        query.setParameter("claimIds", claimIdsList);
        return query.executeUpdate();
    }

    /**
     * This method prepares claims list object for response
     * 
     * @param claimsInfoList
     * @return
     */
    private List<Claims> prepareClaimsList(final List<Object[]> claimsInfoList) {
        List<Claims> claimsList = null;
        for (Object[] claimsInfo : claimsInfoList) {
            if (claimsList == null)
                claimsList = new ArrayList<>();

            Claims claims = new Claims();
            claims.setIdentifier(checkNullAndTrim(claimsInfo[ZERO]));
            claims.setCategory(checkNullAndTrim(claimsInfo[ONE]));
            claimsList.add(claims);
        }
        return claimsList;
    }

    /**
     * This method provides claim numbers based on the claims list
     * 
     * @param claimsList
     * @return
     */

    public List<Claims> getClaimNumbers(List<Claims> claimsList) {
        if (null == claimsList)
            return Collections.emptyList();
        final Query<String> query = sessionFactory.getCurrentSession().createNamedQuery("getTrailsCapturedClaimsInfo",
                String.class);
        for (Claims claims : claimsList) {
            query.setParameter("claim_reason_id", claims.getIdentifier());
            List<String> response = query.list();

            claims.setAsCaptured(proceedingCaseHelper.prepareAsCaputuredClaimList(response));
            claims.setExpanded(response.toString().replace("[", "").replace("]", ""));
            claims.setCount(Integer.toString(response.size()));
        }
        return claimsList;
    }

    /**
     * This method is used in data access layer to add new claims to the database
     */
    @Override
    public void createProceedingClaimsInfo(ProceedingClaims proceedingClaimsRequest) {
        notFoundIfNull(proceedingClaimsRequest.getCaseNo(), NO_DATA_FOUND);
        notFoundIfNull(proceedingClaimsRequest.getAudit(), NO_DATA_FOUND);
        notFoundIfNull(proceedingClaimsRequest.getAudit().getLastModifiedUserIdentifier(), NO_DATA_FOUND);

        getProceedingDetails(proceedingClaimsRequest);

        BigDecimal userId = ptabBusinessUtils
                .getExternalUserIdentifier(proceedingClaimsRequest.getAudit().getLastModifiedUserIdentifier());
        Claims claimsRequest = proceedingClaimsRequest.getClaims().get(ZERO);

        List<PrcdngClmStatyGround> prcdngClmStatyGrounds = new ArrayList<>();

        List<String> claimNumsExpanded = proceedingCaseHelper.prepareExpandedList(claimsRequest.getAsCaptured());

        setClaimsAndGroundsInfo(proceedingClaimsRequest, userId, claimsRequest, prcdngClmStatyGrounds, claimNumsExpanded);

        setClaimsReasonInfo(userId, claimsRequest, prcdngClmStatyGrounds);

    }

    private void getProceedingDetails(ProceedingClaims proceedingClaimsRequest) {
        ProceedingEntity proceedingEntity = proceedingRepository.getProceedingDetails(proceedingClaimsRequest.getCaseNo());
        validateAndThrowExceptionWithMsg(null == proceedingEntity,
                "Proceeding # or Proceeding core Id entered could not be found", HttpStatus.BAD_REQUEST);
        proceedingClaimsRequest.setCaseId(proceedingEntity.getProceedingId());
    }

    /**
     * This method is used in data access layer to update claims to the database
     */
    public void updateProceedingClaimsInfo(ProceedingClaims proceedingClaimsRequest) {
        notFoundIfNullCollection(proceedingClaimsRequest.getClaims(), NO_DATA_FOUND);
        Claims claimsRequest = proceedingClaimsRequest.getClaims().get(ZERO);
        deleteProceedingClaimsInfo(Long.parseLong(claimsRequest.getIdentifier()));
        createProceedingClaimsInfo(proceedingClaimsRequest);
    }

    /**
     * This method is used in data access layer to delete claims in the database
     */
    public void deleteProceedingClaimsInfo(final Long identifier) {

        final List<PrcdngStatyGrndClmRsn> statyGrndClmRsnList = prcdngStatyGrndClmRsnRepository
                .getAllClaimsByReasonId(identifier);
        validateAndThrowExceptionWithMsg(!CollectionUtils.isNotEmpty(statyGrndClmRsnList), "No records found to delete",
                HttpStatus.BAD_REQUEST);
        List<Long> statyGroundIdsList = statyGrndClmRsnList.stream().map(PrcdngStatyGrndClmRsn::getFkPrcdgClmStayGroundId)
                .collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(statyGrndClmRsnList)) {
            prcdngStatyGrndClmRsnRepository.deleteAll(statyGrndClmRsnList);
            claimChallengeReasonRepository.deleteById(identifier);
        }
        if (CollectionUtils.isNotEmpty(statyGroundIdsList)) {
            final List<PrcdngClmStatyGround> prcdngClmStatyGrounds = prcdngClmStatyGroundRepository
                    .getAllStatyGrounds(statyGroundIdsList);
            prcdngClmStatyGroundRepository.deleteAll(prcdngClmStatyGrounds);
        }
    }

    /**
     * This method is to set the proceeding claims and proceeding grounds info
     */
    private void setClaimsAndGroundsInfo(ProceedingClaims proceedingClaimsRequest, BigDecimal userId, Claims claimsRequest,
            List<PrcdngClmStatyGround> prcdngClmStatyGrounds, List<String> claimNumsExpanded) {
        for (String claimNum : claimNumsExpanded) {
            ProceedingClaim proceedingClaim = new ProceedingClaim();
            proceedingClaim.setFkProceedingId(proceedingClaimsRequest.getCaseId());
            proceedingClaim.setClaimNo(claimNum);
            proceedingClaim.setInstDcsnCmntTx(proceedingClaimsRequest.getInstCmntTxt());
            proceedingClaim.setFkclaimFinalWrittenDcsnId(proceedingClaimsRequest.getFinalWrittenDcsnId());
            proceedingClaim.setFinalWrittenDcsnCmntTx(proceedingClaimsRequest.getFinalCmntTxt());
            proceedingClaim.setCreateUserId(userId);
            proceedingClaim.setCreateTs(new Date());
            proceedingClaim.setLastModUserId(userId);
            proceedingClaim.setLastModTs(new Date());
            sessionFactory.getCurrentSession().persist(proceedingClaim);

            PrcdngClmStatyGround prcdngClmStatyGround = new PrcdngClmStatyGround();
            prcdngClmStatyGround.setFkProceedingClaimId(proceedingClaim.getProceedingClaimId());
            prcdngClmStatyGround.setFkStatGroundId(claimsRequest.getStatGroundId());
            prcdngClmStatyGround.setClaimDispositionCt(PTABConstants.CHALLENGED);
            prcdngClmStatyGround.setCreateUserId(userId);
            prcdngClmStatyGround.setCreateTs(new Date());
            prcdngClmStatyGround.setLastModUserId(userId);
            prcdngClmStatyGround.setLastModTs(new Date());
            prcdngClmStatyGrounds.add(prcdngClmStatyGround);
            sessionFactory.getCurrentSession().persist(prcdngClmStatyGround);

        }
    }

    /**
     * This method is to set the claims reason and staty ground rsn details
     */
    private void setClaimsReasonInfo(BigDecimal userId, Claims claimsRequest,
            List<PrcdngClmStatyGround> prcdngClmStatyGrounds) {
        ClaimChallengeReason claimChallengeReason = new ClaimChallengeReason();
        claimChallengeReason.setClaimReasonTx(claimsRequest.getCategory());
        claimChallengeReason.setCreateUserId(userId);
        claimChallengeReason.setCreateTs(new Date());
        claimChallengeReason.setLastModUserId(userId);
        claimChallengeReason.setLastModTs(new Date());
        sessionFactory.getCurrentSession().persist(claimChallengeReason);

        for (PrcdngClmStatyGround prcdngClmStatyGround : prcdngClmStatyGrounds) {
            PrcdngStatyGrndClmRsn prcdngStatyGrndClmRsn = new PrcdngStatyGrndClmRsn();
            prcdngStatyGrndClmRsn.setFkPrcdgClmChallengeReasonId(claimChallengeReason.getClaimChallengeReasonId());
            prcdngStatyGrndClmRsn.setFkPrcdgClmStayGroundId(prcdngClmStatyGround.getPrcdngClmStatyGroundId());
            prcdngStatyGrndClmRsn.setCreateTs(new Date());
            prcdngStatyGrndClmRsn.setCreateUserId(userId);
            prcdngStatyGrndClmRsn.setLastModTs(new Date());
            prcdngStatyGrndClmRsn.setLastModUserId(userId);
            sessionFactory.getCurrentSession().persist(prcdngStatyGrndClmRsn);
        }
    }

}
