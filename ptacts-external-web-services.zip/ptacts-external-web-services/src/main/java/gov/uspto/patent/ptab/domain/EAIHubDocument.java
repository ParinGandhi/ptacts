package gov.uspto.patent.ptab.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EAIHubDocument {

    private String applicationNumber;
    private String fileName;
    private String responseErrorMessage;
    private String documentCode;
    private int status;
    private String proceedingNumber;
    @JsonIgnore
    private String docUploadReqIndicator;
    @JsonIgnore
    private String eaiHubUploadUrl;

}