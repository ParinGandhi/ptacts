package gov.uspto.patent.ptab.controller;

import java.io.IOException;
import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import gov.uspto.patent.ptab.encrypt.RC4CipherEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;

import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.domain.CaseSearchRequest;
import gov.uspto.patent.ptab.domain.CaseSearchResponse;
import gov.uspto.patent.ptab.domain.CodeReferenceLookup;
import gov.uspto.patent.ptab.domain.CodeReferenceQuery;
import gov.uspto.patent.ptab.domain.DocumentQuery;
import gov.uspto.patent.ptab.domain.Petition;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.domain.PetitionQuery;
import gov.uspto.patent.ptab.domain.ReferenceQuery;
import gov.uspto.patent.ptab.domain.ReferenceType;
import gov.uspto.patent.ptab.service.CaseSearchService;
import gov.uspto.patent.ptab.service.DocumentService;
import gov.uspto.patent.ptab.service.PetitionService;
import gov.uspto.patent.ptab.service.ProceedingArtifactService;
import gov.uspto.patent.ptab.service.ReferenceDataService;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/public-informations")
@Slf4j
public class PublicInformationAccessController {

    public static final String APPLICATION_JSON_UTF8_VALUE = "application/json;charset=UTF-8";

    @Autowired
    private CaseSearchService caseSearchService;

    @Autowired
    private ReferenceDataService referenceDataService;

    @Autowired
    private ProceedingArtifactService proceedingArtifactService;

    @Autowired
    private PetitionService petitionService;

    @Autowired
    private DocumentService documentService;

    @GetMapping(value = "/references")
    public List<ReferenceType> getReferenceType(@NotNull final ReferenceQuery referenceQuery) {
        return referenceDataService.getReferenceData(referenceQuery);
    }

    @PostMapping(value = "/case-search")
    public List<CaseSearchResponse> getCaseSearchInfo(@Valid @RequestBody final CaseSearchRequest searchRequest)
            throws JsonProcessingException {
        log.info("getSearchInfo :{}", searchRequest);
        return caseSearchService.getSearchInfo(searchRequest, true);
    }

    @GetMapping(value = "/proceeding-artifacts", produces = APPLICATION_JSON_UTF8_VALUE)
    public List<PetitionDocument> getAllArtifacts(final CaseDocumentsDataQuery caseDocumentsDataQuery) {
        return proceedingArtifactService.getAllArtifacts(caseDocumentsDataQuery, true);

    }

    @GetMapping(value = "/petitions")
    public Petition getPetitionDetails(final PetitionQuery petitionQuery) {
        return petitionService.getPetitionDetails(petitionQuery);

    }

    /**
     * This method is used to get the document from mount location
     *
     * @param proceedingId - petition identifier
     * @param documentQuery - document query
     * @throws IOException
     *
     */
    @GetMapping(value = "/petitions/{petitionId}/download-documents", produces = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<InputStreamResource> downloadDocument(@NotNull @PathVariable("petitionId") final Long proceedingId,
            @Valid final DocumentQuery documentQuery) throws IOException {

        log.info("The document downloaded using the artifact identifier{} ", documentQuery.getArtifactId());
        String decryptedArtifactId = RC4CipherEntity.decrypt(documentQuery.getArtifactId());
        documentQuery.setArtifactId(decryptedArtifactId);
        return documentService.downloadDocument(proceedingId, documentQuery, true);

    }

    /**
     * This method is used to retrieve values from code reference table
     *
     * @return
     */
    @GetMapping(value = "/code-reference-types")
    public List<CodeReferenceLookup> getCodeReferenceTypes(final CodeReferenceQuery codeReferenceQuery) {
        log.info("getCodeReferenceTypes: ", codeReferenceQuery);
        return referenceDataService.getCodeReferenceType(codeReferenceQuery);
    }
}
