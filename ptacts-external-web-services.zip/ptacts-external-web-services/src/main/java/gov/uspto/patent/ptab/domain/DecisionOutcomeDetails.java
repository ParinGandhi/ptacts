package gov.uspto.patent.ptab.domain;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DecisionOutcomeDetails {

    private String outcomeType;
    private String descriptionText;
}
