package gov.uspto.patent.ptab.domain;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class StatutoryGround {
    private long id;
    private String code;
    private String description;
}
