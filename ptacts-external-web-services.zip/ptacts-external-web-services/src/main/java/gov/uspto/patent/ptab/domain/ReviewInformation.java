package gov.uspto.patent.ptab.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReviewInformation {
    private String party;
    private String transactionDate;
    private String paymentMethod;
    private String description;
    private String feeCode;
    private String quantity;
    private String feeAmount;
    private String feeTotal;
}
