package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.client.HttpClientErrorException;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.LoginQuery;
import gov.uspto.patent.ptab.domain.UserLoginDetails;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABConstants;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

/**
 * Service class used to retrieve the user details
 *
 * @author 2020 development team
 *
 */
@Validated
@Component
@Slf4j
public class LoginService {

    private static final String USER_DETAILS_URL = "USER_DETAILS_URL";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    /**
     * Method used to fetch the user details
     *
     * @param loginQuery - object containing the query parameters
     * @return
     */
    @Transactional
    public UserLoginDetails getUserDetails(LoginQuery loginQuery) {

        final String userDetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL, USER_DETAILS_URL);
        notFoundIfNull(userDetailsUrl, "login details Url");

        final String url = externalServiceUriGenerator.userDetailsUrl(loginQuery, userDetailsUrl);

        final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTABConstants.PTAB_CASE_INIT,
                PTABConstants.SYSTEM_USER);
        notFoundIfNull(systemUserName, "system user name");
        log.info("calling common services for fetching user details");
        ResponseEntity<UserLoginDetails> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, UserLoginDetails.class,
                    systemUserName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response ? response.getBody() : null;
    }

}
