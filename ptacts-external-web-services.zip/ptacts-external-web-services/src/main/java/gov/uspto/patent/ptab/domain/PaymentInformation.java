package gov.uspto.patent.ptab.domain;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentInformation implements Serializable {

    private static final long serialVersionUID = 1L;
    private String party;
    private String transactionDate;
    private String transactionId;
    private String paymentMethod;
    private String description;
    private String feeCode;
    private String quantity;
    private String feeAmount;
    private String feeTotal;
}