package gov.uspto.patent.ptab.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import gov.uspto.patent.ptab.entities.ExternalUser;

@Repository
public interface ExternalUserRepository extends JpaRepository<ExternalUser, Long> {

    @Query(value = "select a.* from"
            + "( select * from  external_user where electronic_addr_locator_tx= :email order by last_mod_ts desc)"
            + "a where rownum=1", nativeQuery = true)
    ExternalUser findAllByEmail(@Param("email") String email);

    @Query(value = "select a.* from"
            + "( select * from  external_user where registration_no= :regNumber order by last_mod_ts desc)"
            + "a where rownum=1", nativeQuery = true)
    ExternalUser findAllByRegistrationNumber(@Param("regNumber") String regNumber);

    /**
     * Fetch ExternalUser from DB using userId
     *
     * @return
     */
    @Query(value = "select * from external_user where electronic_addr_locator_tx= :userId", nativeQuery = true)
    ExternalUser findOneByUserId(@Param("userId") String userId);

}
