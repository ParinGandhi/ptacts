package gov.uspto.patent.ptab.controller;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.domain.ProceedingClaims;
import gov.uspto.patent.ptab.domain.ProceedingIdentifiers;
import gov.uspto.patent.ptab.service.ProceedingClaimsInfoService;
import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to handle REST calls for proceeding claims
 * 
 * @author 2020 development team
 *
 */
@RestController
@Slf4j
@RequestMapping(value = "/pcdng-claims")
public class ProceedingClaimsController {

    public static final String APPLICATION_JSON_UTF8_VALUE = "application/json;charset=UTF-8";

    @Autowired
    private ProceedingClaimsInfoService proceedingClaimsInfo;

    /**
     * This method will provide proceeding claims info
     * 
     * @param caseType
     * @param caseNo
     * @return
     */
    @GetMapping(path = "/{caseType}/{caseNo}", produces = "application/json")
    public JsonNode getProceedingClaimsInfo(@Valid @NotNull @PathVariable("caseType") final String caseType,
            @Valid @NotNull @PathVariable("caseNo") final String caseNo) {
        log.info("getProceedingClaimsInfo: caseType {} , caseNumber {}", caseType, caseNo);
        final ProceedingIdentifiers proceedingIdentifiers = new ProceedingIdentifiers();
        proceedingIdentifiers.setCaseNo(caseNo);
        proceedingIdentifiers.setCaseType(caseType);
        JsonNode proceedingClaims = proceedingClaimsInfo.getProceedingClaims(proceedingIdentifiers);
        notFoundIfNull(proceedingClaims, "claims");
        return proceedingClaims;
    }

    /**
     * This methods returns all Statutory ground details
     *
     * @return
     */
    @GetMapping(path = "/statutory-grounds", produces = APPLICATION_JSON_UTF8_VALUE)
    public JsonNode getStatutoryGrounds() {
        ProceedingClaimsInfoService proceedingClaimsInfoService = proceedingClaimsInfo;
        return proceedingClaimsInfoService.getStatutoryGrounds();
    }

    /**
     * This method create new proceeding claims
     * 
     * @param proceedingClaims
     */
    @PostMapping
    public void createClaim(@RequestBody @Valid @NotNull final ProceedingClaims proceedingClaims) {
        proceedingClaimsInfo.createProceedingClaim(proceedingClaims);
    }

    /**
     * This method update proceeding claims info
     * 
     * @param proceedingClaims
     */
    @PutMapping
    public void updateClaimsInfo(@RequestBody @Valid @NotNull final ProceedingClaims proceedingClaims) {
        proceedingClaimsInfo.updateProceedingClaim(proceedingClaims);
    }

    /**
     * This method delete proceeding claims
     * 
     * @param proceedingClaims
     */
    @DeleteMapping(value = "/{identifier}")
    public void deleteClaimsInfo(@NotNull @PathVariable("identifier") final Long identifier) {
        proceedingClaimsInfo.deleteProceedingClaim(identifier);
    }

}
