package gov.uspto.patent.ptab.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import gov.uspto.patent.ptab.dao.CommonCodeReferenceDao;

@Controller
public class PtactsRouteController {

    private static final String UI_URI_FORWARD_MAP = "UI_URI_FORWARD_MAP";
    private static final String PTAB_UI_ROUTING = "PTAB_UI_ROUTING";

    @Autowired
    private CommonCodeReferenceDao codeReferenceDao;

    @RequestMapping(method = { RequestMethod.OPTIONS, RequestMethod.GET }, path = { "/ui/**" })
    public String forwardAngularPaths() {

        return codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_UI_ROUTING, UI_URI_FORWARD_MAP);
    }
}
