package gov.uspto.patent.ptab.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ReferenceDataResponse {

    private List<ReferenceType> stateDocumentTypes;
    private List<ReferenceType> moreDocumetnTypes;
    private List<StndDecisionOutComeReferenceType> stndDecisonOutcomeType;

}
