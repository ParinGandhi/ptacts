package gov.uspto.patent.ptab.entities;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the CLAIM_CHALLENGE_REASON database table.
 */
@Entity
@Table(name = "CLAIM_CHALLENGE_REASON")
@NamedQuery(name = "ClaimChallengeReason.findAll", query = "SELECT p FROM ClaimChallengeReason p")
@Getter
@Setter
@RequiredArgsConstructor
public class ClaimChallengeReason extends AbstractAuditEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "CLAIM_CHALLENGE_REASON_SEQ", sequenceName = "CLAIM_CHALLENGE_REASON_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CLAIM_CHALLENGE_REASON_SEQ")
    @Column(name = "CLAIM_CHALLENGE_REASON_ID")
    private Long claimChallengeReasonId;

    @Column(name = "CLAIM_REASON_TX")
    private String claimReasonTx;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    @OneToMany(mappedBy = "claimChallengeReason")
    private List<PrcdngStatyGrndClmRsn> prcdngStatyGrndClmRsns;

}