package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "PRCDNG_INVENTION_DISCLOSURE")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PrcdngInventionDisclosureEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PrcdngInvnDisclosureSeqGen")
    @SequenceGenerator(name = "PrcdngInvnDisclosureSeqGen", sequenceName = "PRCDNG_INVENTION_DSCLSR_SEQ", allocationSize = 1)
    @Column(name = "PRCDNG_INVENTION_DSCLSR_ID")
    private Long prcdngInventionDisclosureId;

    @Column(name = "FK_PROCEEDING_ID")
    private BigDecimal fkProceedingId;

    @Column(name = "PATENT_NO")
    private String patentNo;

    @Column(name = "CFK_INVENTION_DISCLOSURE_ID")
    private BigDecimal inventionDisclosureId;

    @Column(name = "INVENTOR_FULL_NM")
    private String inventorFullName;

    @Column(name = "PATENT_OWNER_NM")
    private String patentOwnerName;

    @Column(name = "INVENTION_TITLE_TX")
    private String inventionTitleText;

    @Column(name = "APPLICATION_ID")
    private String applicationId;

    @Column(name = "FILING_DT")
    private Date filingDate;

    @Column(name = "ISSUE_DT")
    private Date issueDate;

    @Column(name = "TECH_CENTER_ID")
    private String techCenterId;

    @Column(name = "STATUS_NM")
    private String statusName;

    @Column(name = "STATUS_TX")
    private String statusText;

    @Column(name = "CLAIM_QT")
    private BigDecimal claimQuantity;

    @Column(name = "CONFIDENTIALITY_IN")
    private Character confidentialityIn;

    @Column(name = "PATENT_EXPIRATION_DT")
    private Date patentExpirationDate;

    @Column(name = "CREATE_USER_ID")
    private BigDecimal createUserId;

    @Column(name = "CREATE_TS")
    private Date createTs;

    @Column(name = "LAST_MOD_USER_ID")
    private BigDecimal lastModUserId;

    @Column(name = "LAST_MOD_TS")
    private Date lastModTs;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo;

    @Column(name = "ART_UNIT_CD")
    private String artUnitCode;

    @Column(name = "FK_PRCDNG_PARTY_GROUP_TYPE_ID")
    private BigDecimal partGroupTypeId;

    @Column(name = "APPLICATION_RANK_NO")
    private BigDecimal applicationRankNo;

    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveTs;

    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveTs;

    @ManyToOne
    @JoinColumn(name = "FK_PRCDNG_PARTY_GROUP_TYPE_ID", insertable = false, updatable = false)
    private StndPrcdngPartyGroupType stndPrcdngPartyGroupType;

}
