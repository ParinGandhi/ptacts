package gov.uspto.patent.ptab.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * This class is having the all the common PTAB proceeding details
 *
 * @author 2020 development team
 *
 */
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class PtabCommonDomain {

    private Long petitionIdentifier;
    private String patentNumber;
    private String proceedingNumberText;
    private LifeCycle lifeCycle;
    private Audit audit;
}
