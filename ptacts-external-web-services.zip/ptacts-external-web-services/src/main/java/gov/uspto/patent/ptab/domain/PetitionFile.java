package gov.uspto.patent.ptab.domain;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.uspto.patent.ptab.utils.EpochDeserializer;
import gov.uspto.patent.ptab.utils.EpochSerializer;
import lombok.Getter;
import lombok.Setter;

/**
 * This class is having the details of the petition file details
 *
 * @author 2020 development team
 *
 */
@Setter
@Getter
@JsonInclude(Include.NON_NULL)
public class PetitionFile extends PtabCommonDomain {

    private String fileName;
    private Integer pageCount;
    @JsonSerialize(using = EpochSerializer.class)
    @JsonDeserialize(using = EpochDeserializer.class)
    private Date filingDate;

}
