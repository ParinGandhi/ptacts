package gov.uspto.patent.ptab.entities;

import java.util.Date;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the PROCEEDING_PARTY_GROUP database table.
 * 
 */
@Entity
@Table(name = "PROCEEDING_PARTY_GROUP")
@NamedQuery(name = "ProceedingPartyGroup.findAll", query = "SELECT p FROM ProceedingPartyGroup p")
@Data
@EqualsAndHashCode(callSuper = false)
public class ProceedingPartyGroup extends AbstractAuditEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PROCEEDING_PARTY_GROUP_SEQ")
    @SequenceGenerator(name = "PROCEEDING_PARTY_GROUP_SEQ", sequenceName = "PROCEEDING_PARTY_GROUP_SEQ", allocationSize = 1)
    @Column(name = "PROCEEDING_PARTY_GROUP_ID")
    private long proceedingPartyGroupId;

    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "FK_PROCEEDING_ID")
    private long fkProceedingId;

    @Column(name = "FK_PRCDNG_PARTY_GROUP_STAT_ID")
    private long fkPrcdngPartyGroupStatId;

    @Column(name = "FK_PRCDNG_PARTY_GROUP_TYPE_ID")
    private long fkPrcdngPartyGroupTypeId;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "STATUS_DT")
    private Date statusDt;

    @OneToMany(mappedBy = "proceedingPartyGroup")
    private List<PrcdngPartyGrpCertif> prcdngPartyGrpCertifs;

    @OneToMany(mappedBy = "proceedingPartyGroup", cascade = CascadeType.ALL)
    private List<ProceedingParty> proceedingParties;

    @ManyToOne
    @JoinColumn(name = "FK_PROCEEDING_ID", insertable = false, updatable = false)
    private ProceedingEntity proceeding;

    @ManyToOne
    @JoinColumn(name = "FK_PRCDNG_PARTY_GROUP_STAT_ID", insertable = false, updatable = false)
    private StndPrcdngPartyGroupStat stndPrcdngPartyGroupStat;

    @ManyToOne
    @JoinColumn(name = "FK_PRCDNG_PARTY_GROUP_TYPE_ID", insertable = false, updatable = false)
    private StndPrcdngPartyGroupType stndPrcdngPartyGroupType;

    @Column(name = "STAT_APPROVED_INDC")
    private Character statusApprovedIndicator;
}