package gov.uspto.patent.ptab.domain;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

/**
 * VO for Meta search response information
 */
@Data
@JsonInclude(Include.NON_NULL)
public class CaseSearchResponse implements Serializable {

    private static final long serialVersionUID = -6349065343033258471L;
    private Long proceedingId;
    private String proceedingNumber;
    private String petiArtUnitcd;
    private String poArtUnitcd;
    private String petiPatentNumber;
    private String poPatentNumber;
    private String petiApplicationId;
    private String poApplicationId;
    private String petiInventionTitleTx;
    private String poInventionTitleTx;
    private String terminationTypeId;
    private String currentPrcdStateId;
    private String petiInventorFullName;
    private String poInventorFullName;
    private String patentOwnerName;
    private String terminationTypeName;
    private String statusDisplay;
    private String poRealParty;
    private String petiRealParty;
    private List<String> judges;
    private String prcdCreatedTs;
    private String petiTechCenterId;
    private String poTechCenterId;
    private String mileStoneDt;
    private String allPartiesInfo;
    private String initiatedUser;
    private String caseConfidentiality;
    private Audit audit;

    private String nofda;
    private String accordedDate;
    private String terminationDate;
    private String institutionDecisionDate;
    private String submittedDate;
    private String finalDecisionDate;
    private String rehearingDecisionDate;
    private String terminationType;
    private String ptabStateName;
    private String ptabSubStateName;
    private String preliminaryResponse;
    private String trialType;
    private String trialTypeDesc;
    private String extUserPrcdPartyGrpType;
}