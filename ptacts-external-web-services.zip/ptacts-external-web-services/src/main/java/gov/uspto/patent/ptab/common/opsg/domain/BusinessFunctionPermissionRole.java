package gov.uspto.patent.ptab.common.opsg.domain;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

//import jakarta.validation.constraints.NotNull;
//import jakarta.validation.constraints.Size;

import lombok.Data;

@Data
public class BusinessFunctionPermissionRole {

    @NotNull(message = "roleName cannot be null")
    @Size(min = 2, max = 50)
    private String roleName;

    @NotNull(message = "roleDescription cannot be null")
    @Size(min = 2, max = 1000)
    private String roleDescription;

    @NotNull(message = "rolePermissionId cannot be null")
    private Long rolePermissionId;

    @NotNull(message = "roleTypeId cannot be null")
    private Long roleTypeId;

    @NotNull(message = "lifeCycle cannot be null")
    private LifeCycle lifeCycle;

    @NotNull(message = "audit cannot be null")
    private Audit audit;

}
