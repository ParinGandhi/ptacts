package gov.uspto.patent.ptab.domain;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class InterestedParty {

    private String identifier;
    private String registrationNo;
    private Long rankNo;
    private String partyType;
    private String partySubType;
    private String partySubTypeDescription;
    private String submitterType;
    private String partyReference;
    private String proseIndicator;
    private List<Person> personType = new ArrayList<>();
    private List<Organization> orgType = new ArrayList<>();
    @JsonIgnore
    private String notificationEventId;

}
