package gov.uspto.patent.ptab.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.patent.ptab.domain.RelatedProceeding;
import gov.uspto.patent.ptab.service.JoinderService;
import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to handle REST calls for Related proceeding services.
 *
 * @author 2020 development team
 */
@RestController
@Slf4j
@RequestMapping("/joinder")
public class JoinderController {

    @Autowired
    private JoinderService joinderService;

    /**
     * This method is to get all related cases
     * 
     * @param caseNumber - input String caseNumber
     * @return
     */
    @GetMapping(value = "/related-cases")
    public List<RelatedProceeding> getRelatedCasesByCaseNumber(final String caseNumber) {
        log.info("getRelatedCasesByCaseNumber method:{}", caseNumber);
        return joinderService.getRelatedCasesByCaseNumber(caseNumber);
    }

    /**
     * This method is to get joinder information
     * 
     * @param caseNumber - input String caseNumber
     * @return
     */
    @GetMapping
    public List<RelatedProceeding> getJoinderInformation(final String caseNumber) {
        log.info("getJoinderInformation method:{}", caseNumber);
        return joinderService.getJoinderInformation(caseNumber);
    }
}
