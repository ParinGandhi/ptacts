package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the PRCDNG_PARTY_GRP_CERTIF database table.
 * 
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "PRCDNG_PARTY_GRP_CERTIF")
@NamedQuery(name = "PrcdngPartyGrpCertif.findAll", query = "SELECT p FROM PrcdngPartyGrpCertif p")
public class PrcdngPartyGrpCertif extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PRCDNG_PARTY_GRP_CERTIF_SEQ")
    @SequenceGenerator(name = "PRCDNG_PARTY_GRP_CERTIF_SEQ", sequenceName = "PRCDNG_PARTY_GRP_CERTIF_SEQ", allocationSize = 1)
    @Column(name = "PRCDNG_PARTY_GRP_CERTIF_ID")
    private long prcdngPartyGrpCertifId;

    @Column(name = "CERTIFICATION_TS")
    private Timestamp certificationTs;

    @Column(name = "CERTIFIED_IN")
    private String certifiedIn;

    @Column(name = "FK_CERTIFIER_USER_ID")
    private Long fkCertifierUserId;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    @ManyToOne
    @JoinColumn(name = "FK_CERTIFICATION_TYPE_ID")
    private StndCertificationType stndCertificationType;

    @ManyToOne(cascade = { CascadeType.MERGE, CascadeType.PERSIST })
    @JoinColumn(name = "FK_PROCEEDING_PARTY_GROUP_ID")
    private ProceedingPartyGroup proceedingPartyGroup;

}