package gov.uspto.patent.ptab.entities;

import lombok.*;

import jakarta.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

/**
 * The persistent class for the STND_REHEARING_TYPE database table.
 * 
 */
@Entity
@Table(name = "STND_REHEARING_TYPE")
@NamedQuery(name = "StndRehearingType.findAll", query = "SELECT s FROM StndRehearingType s")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StndRehearingType implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "REHEARING_TYPE_ID")
    private long rehearingTypeId;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Column(name = "CREATE_TS")
    private Timestamp createTs;

    @Column(name = "CREATE_USER_ID")
    private BigDecimal createUserId;

    @Column(name = "DESCRIPTION_TX")
    private String descriptionTx;

    @Column(name = "DISPLAY_ORDER_SEQUENCE_NO")
    private BigDecimal displayOrderSequenceNo;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Column(name = "LAST_MOD_TS")
    private Timestamp lastModTs;

    @Column(name = "LAST_MOD_USER_ID")
    private BigDecimal lastModUserId;

    @Column(name = "REHEARING_TYPE_NM")
    private String rehearingTypeNm;

}