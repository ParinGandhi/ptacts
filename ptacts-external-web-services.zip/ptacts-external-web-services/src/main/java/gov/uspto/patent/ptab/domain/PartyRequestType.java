package gov.uspto.patent.ptab.domain;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.uspto.patent.ptab.utils.MilliSecEpochDeserializer;
import gov.uspto.patent.ptab.utils.MilliSecEpochSeralizer;
import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class PartyRequestType {

    private Long id;
    private String status;
    private Type type;
    private Audit audit;
    private String eventId;
    private String stateId;
    @JsonSerialize(using = MilliSecEpochSeralizer.class)
    @JsonDeserialize(using = MilliSecEpochDeserializer.class)
    private Date decisionDt;
    private Date filedDate;
    private List<Long> artifactIdentifiers;

    @JsonIgnore
    private boolean isNotificationRequired;

    public enum Type {
        REHEARING, MOTION
    }

    @JsonIgnore
    private String proceedingNumberText;
}