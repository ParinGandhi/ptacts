package gov.uspto.patent.ptab.common.opsg.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * This class contains fields used in JSON response payLoad for resources that represent collections. The class level
 * annotations, @Getter and @Setter are used instead of getter and setter methods
 * 
 * @author 2020 Development Team
 */
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class CollectionPayloadExpo<T> {
    private Object meta;
    private String customerNumber;
    private String registrationNumber;
    private List<T> results;

}
