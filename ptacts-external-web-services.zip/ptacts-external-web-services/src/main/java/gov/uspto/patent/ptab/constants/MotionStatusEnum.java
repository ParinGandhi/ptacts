package gov.uspto.patent.ptab.constants;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Enum to represent the Motion Status. *
 */
public enum MotionStatusEnum {

    PENDING_REVIEW(1L), GRANTED(2L), DENIED(3L), LEGACY_DATA(4L), INITIATED(5L), GRANTED_IN_PART(6L), DISMISSED(7L), NO_DECISION(
            8L);

    private final Long motionStatusId;

    private MotionStatusEnum(Long motionStatusId) {
        this.motionStatusId = motionStatusId;
    }

    public Long motionStatusId() {
        return motionStatusId;
    }

    public static Long getDBMotionStatus(String motionStatus) {
        switch (motionStatus) {
        case "PENDING_REVIEW":
            return MotionStatusEnum.PENDING_REVIEW.motionStatusId();
        case "GRANTED":
            return MotionStatusEnum.GRANTED.motionStatusId();
        case "DENIED":
            return MotionStatusEnum.DENIED.motionStatusId();
        case "LEGACY_DATA":
            return MotionStatusEnum.LEGACY_DATA.motionStatusId();
        case "INITIATED":
            return MotionStatusEnum.INITIATED.motionStatusId();
        case "GRANTED_IN_PART":
            return MotionStatusEnum.GRANTED_IN_PART.motionStatusId();
        case "DISMISSED":
            return MotionStatusEnum.DISMISSED.motionStatusId();
        case "NO_DECISION":
            return MotionStatusEnum.NO_DECISION.motionStatusId();
        default:
            return 0L;
        }
    }

    public static List<Long> getEnumStatusIdValues() {
        return Stream.of(MotionStatusEnum.values()).map(MotionStatusEnum::motionStatusId).collect(Collectors.toList());
    }
}
