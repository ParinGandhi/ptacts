package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.ProceedingQWithDecision;
import gov.uspto.patent.ptab.domain.ProceedingQWithUserDetails;
import gov.uspto.patent.ptab.domain.ProceedingQualatativeQ;
import gov.uspto.patent.ptab.domain.QualatativeQuestioner;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class QualitativeQuestionsServices {

    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    private static final String GET_CONFIGURED_QUESTIONS_URL = "GET_CONFIGURED_QUESTIONS_URL";
    private static final String GET_QUESTIONS_WITH_PROCEEDING_NO_URL = "GET_QUESTIONS_WITH_PROCEEDING_NO_URL";
    private static final String GET_QUESTIONS_WITH_USERDETAILS_URL = "GET_QUESTIONS_WITH_USERDETAILS_URL";
    private static final String CREATE_QQ_URL = "CREATE_QQ_URL";
    private static final String UPDATE_QQ_URL = "UPDATE_QQ_URL";
    private static final String UPDATE_QQ_FINAL_ANSWER_URL = "UPDATE_QQ_FINAL_ANSWER_URL";
    private static final String GET_CONFIGURED_QUESTIONS = "configured questions url";
    private static final String GET_QUESTIONS_WITH_PROCEEDING_NO = "get Questiosn With proceeding no url";
    private static final String GET_QUESTIONS_WITH_USERDETAILS = "get Questiosn With user details url";
    private static final String CREATE_QQ = "create QQ url";
    private static final String UPDATE_QQ = "update QQ url";
    private static final String ERROR = "Error ";

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Transactional
    public List<QualatativeQuestioner> getCOnfiguredQuestions() {
        final String getConfiguredQQUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                GET_CONFIGURED_QUESTIONS_URL);
        notFoundIfNull(getConfiguredQQUrl, GET_CONFIGURED_QUESTIONS);
        final String jsonResponse = restServiceClient.callExternalServiceURL(getConfiguredQQUrl, null, HttpMethod.GET,
                String.class);
        if (StringUtils.isNotBlank(jsonResponse)) {
            final ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            try {
                return mapper.readValue(jsonResponse, new TypeReference<List<QualatativeQuestioner>>() {
                });
            } catch (JsonProcessingException e) {
                log.error(ERROR, e);
            }
        }
        return Collections.emptyList();
    }

    @Transactional
    public List<ProceedingQWithDecision> getQuestionsBasedOnProceedingNumberAndUserId(String userName, String proceedingNumber) {

        final String getQualitativeQuestionsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                GET_QUESTIONS_WITH_PROCEEDING_NO_URL);
        notFoundIfNull(getQualitativeQuestionsUrl, GET_QUESTIONS_WITH_PROCEEDING_NO);
        String url = externalServiceUriGenerator.getQualitativeQuestionsWithProceedingNumberUrl(proceedingNumber,
                getQualitativeQuestionsUrl);
        final ResponseEntity<String> jsonResponse = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET,
                String.class, userName);
        if (null != jsonResponse) {
            final ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            try {
                return mapper.readValue(jsonResponse.getBody(), new TypeReference<List<ProceedingQWithDecision>>() {
                });
            } catch (JsonProcessingException e) {
                log.error(ERROR, e);
            }
        }
        return Collections.emptyList();
    }

    @Transactional
    public ProceedingQWithUserDetails getQuestionsBasedOnProceedingNumber(String userName, String proceedingNumber) {

        final String getQualitativeQuestionsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                GET_QUESTIONS_WITH_USERDETAILS_URL);
        notFoundIfNull(getQualitativeQuestionsUrl, GET_QUESTIONS_WITH_USERDETAILS);
        String url = externalServiceUriGenerator.getQualitativeQuestionsWithProceedingNumberUrl(proceedingNumber,
                getQualitativeQuestionsUrl);
        final ResponseEntity<String> jsonResponse = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET,
                String.class, userName);
        if (null != jsonResponse) {
            final ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            try {
                return mapper.readValue(jsonResponse.getBody(), new TypeReference<ProceedingQWithUserDetails>() {
                });
            } catch (JsonProcessingException e) {
                log.error(ERROR, e);
            }
        }
        return null;
    }

    @Transactional
    public List<ProceedingQWithDecision> createProceedingQualatative(String userName,
            List<ProceedingQualatativeQ> proceedingQualatativeQs) {

        final String createQQUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL, CREATE_QQ_URL);
        notFoundIfNull(createQQUrl, CREATE_QQ);
        ResponseEntity<String> jsonResponse = null;
        try {
            jsonResponse = restServiceClient.callPTABExternalServiceURL(createQQUrl, proceedingQualatativeQs, HttpMethod.POST,
                    String.class, userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        if (null != jsonResponse) {
            final ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            try {
                return mapper.readValue(jsonResponse.getBody(), new TypeReference<List<ProceedingQWithDecision>>() {
                });
            } catch (JsonProcessingException e) {
                log.error(ERROR, e);
            }
        }
        return Collections.emptyList();
    }

    @Transactional
    public List<ProceedingQWithDecision> updateProceedingQualatative(String userName,
            List<ProceedingQualatativeQ> proceedingQualatativeQs, int i) {
        String updateQQUrl = null;
        if (i == 0) {
            updateQQUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL, UPDATE_QQ_URL);
        } else if (i == 1) {
            updateQQUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL, UPDATE_QQ_FINAL_ANSWER_URL);

        }
        notFoundIfNull(updateQQUrl, UPDATE_QQ);
        ResponseEntity<String> jsonResponse = null;
        try {
            jsonResponse = restServiceClient.callPTABExternalServiceURL(updateQQUrl, proceedingQualatativeQs, HttpMethod.PUT,
                    String.class, userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        if (null != jsonResponse) {
            final ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            try {
                return mapper.readValue(jsonResponse.getBody(), new TypeReference<List<ProceedingQWithDecision>>() {
                });
            } catch (JsonProcessingException e) {
                log.error(ERROR, e);
            }
        }
        return Collections.emptyList();
    }
}
