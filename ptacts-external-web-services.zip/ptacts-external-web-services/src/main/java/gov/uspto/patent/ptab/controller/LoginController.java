package gov.uspto.patent.ptab.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.patent.ptab.domain.LoginQuery;
import gov.uspto.patent.ptab.domain.UserLoginDetails;
import gov.uspto.patent.ptab.service.LoginService;
import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to retrieve the user details
 *
 * @author 2020 development team
 *
 */
@RestController
@RequestMapping
@Slf4j
public class LoginController {

    @Autowired
    private LoginService loginService;

    /**
     * Method used to fetch the user details
     *
     * @param loginQuery - object containing the query parameters
     * @return
     */
    @GetMapping(value = "/login-external-user-details")
    public UserLoginDetails getUserDetails(final LoginQuery loginQuery) {
        log.info("Executing getUserDetails");
        return loginService.getUserDetails(loginQuery);

    }

}
