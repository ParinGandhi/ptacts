package gov.uspto.patent.ptab.domain;

import java.math.BigDecimal;
import java.util.List;

import lombok.Data;

/**
 * This class stores user data
 * 
 * @author 2020 Development Team
 *
 */
@Data
public class PtabUser {

    private String userId;

    private String firstName;

    private String lastName;

    private String middleName;

    private String workerNumber;
    
    private BigDecimal employeeNumber;

    private String patronIdentifier;

    private String ptabRole;

    private List<String> ptabModifiers;
    
    private boolean ptabLoginModalAccess;
}
