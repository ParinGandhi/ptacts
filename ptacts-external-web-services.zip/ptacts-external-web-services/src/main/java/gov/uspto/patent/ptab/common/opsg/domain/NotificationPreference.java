package gov.uspto.patent.ptab.common.opsg.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class NotificationPreference {

    private Long eventCatagoryId;
    private String eventCatagoryName;
    private String optOutIndicator;
    private Long userRoleId;
    private String preferenceCategory;
    private String endEffectiveDt;
    private Long userId;
    private Long notificationExclusionId;
}
