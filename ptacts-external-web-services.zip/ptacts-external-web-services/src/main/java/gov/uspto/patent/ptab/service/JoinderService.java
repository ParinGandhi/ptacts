package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.validateRequest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.RelatedProceeding;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

/**
 * This is the Service class for Related proceeding
 *
 * @author 2020 development team
 *
 */
@Slf4j
@Component
public class JoinderService {

    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    private static final String JOINDER_RELATED_BYCASENUMBER = "JOINDER_RELATED_BYCASENUMBER";
    private static final String JOINDER_INFO_BYCASENUMBER = "JOINDER_INFO_BYCASENUMBER";

    @Autowired
    private PTABBusinessUtils ptabBusinessUtils;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    /**
     * This method is to get all related cases
     * 
     * @param caseNumber - input String casesNumber
     * @return
     */
    @Transactional
    public List<RelatedProceeding> getRelatedCasesByCaseNumber(final String caseNumber) {

        final String relatedCasesUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                JOINDER_RELATED_BYCASENUMBER);
        validateRequest(relatedCasesUrl, "Get RelatedCasesByCaseNumber URL is empty");
        String userId = ptabBusinessUtils.getLoggedInUserId();
        final String relatedCasesFmtUrl = externalServiceUriGenerator.getJoinderCaseUrl(caseNumber, relatedCasesUrl);
        final ResponseEntity<String> jsonResponse = restServiceClient.callPTABExternalServiceURL(relatedCasesFmtUrl, null,
                HttpMethod.GET, String.class, userId);
        List<RelatedProceeding> relatedCasesPrcds = null;
        if (jsonResponse.getStatusCode().is2xxSuccessful()) {
            final ObjectMapper mapper = new ObjectMapper();
            try {
                relatedCasesPrcds = mapper.readValue(jsonResponse.getBody(), new TypeReference<List<RelatedProceeding>>() {
                });
            } catch (JsonProcessingException e) {
                log.error("Error ", e);
            }
        } else if (jsonResponse.getStatusCode().is4xxClientError()) {
            throw new PTABException(HttpStatus.BAD_REQUEST,
                    new ErrorPayload("Exception occurred while calling getRelatedCasesByCaseNumber"));
        } else {
            throw new PTABException(HttpStatus.INTERNAL_SERVER_ERROR,
                    new ErrorPayload("Run time Exception occurred while calling getRelatedCasesByCaseNumber"));
        }
        return relatedCasesPrcds;
    }

    /**
     * This method is to get joinder information
     * 
     * @param caseNumber - input String caseNumber
     * @return
     */
    @Transactional
    public List<RelatedProceeding> getJoinderInformation(final String caseNumber) {
        final String joinInfoUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                JOINDER_INFO_BYCASENUMBER);
        validateRequest(joinInfoUrl, "getJoinderInformation URL is empty");
        String userId = ptabBusinessUtils.getLoggedInUserId();

        final String joinderInfoFmtUrl = externalServiceUriGenerator.getJoinderCaseUrl(caseNumber, joinInfoUrl);
        final ResponseEntity<String> jsonResponse = restServiceClient.callPTABExternalServiceURL(joinderInfoFmtUrl, null,
                HttpMethod.GET, String.class, userId);
        List<RelatedProceeding> joinderInfoPrcds = null;
        if (jsonResponse.getStatusCode().is2xxSuccessful()) {
            final ObjectMapper mapper = new ObjectMapper();
            try {
                joinderInfoPrcds = mapper.readValue(jsonResponse.getBody(), new TypeReference<List<RelatedProceeding>>() {
                });
            } catch (JsonProcessingException e) {
                log.error("Error ", e);
            }
        } else if (jsonResponse.getStatusCode().is4xxClientError()) {
            throw new PTABException(HttpStatus.BAD_REQUEST,
                    new ErrorPayload("Exception occurred while calling getJoinderInformation"));
        } else {
            throw new PTABException(HttpStatus.INTERNAL_SERVER_ERROR,
                    new ErrorPayload("Run time Exception occurred while calling getJoinderInformation"));
        }
        return joinderInfoPrcds;

    }
}
