package gov.uspto.patent.ptab.controller;

import java.util.Map;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.domain.ProceedingPartyQuery;
import gov.uspto.patent.ptab.service.ProceedingPartyService;

/**
 * This class is used to get proceeding party details
 *
 * @author 2020 development team
 *
 */
@RestController
@RequestMapping("/proceeding-party-details")
public class ProceedingPartyController {

    @Autowired
    private ProceedingPartyService proceedingPartyService;

    /**
     * Method used to get the next exhibit number
     *
     * @param proceedingNumber - proceeding number
     * @return
     */
    @GetMapping(value = "/exhibit-sequences")
    public Map<String, String> getNextExhibitSequenceDetails(
            @Valid @NotNull final CaseDocumentsDataQuery caseDocumentsDataQuery) {
        return proceedingPartyService.getNextExhibitNumber(caseDocumentsDataQuery.getProceedingNumber());
    }

    @GetMapping
    public JsonNode getAllProceedingPartyDetails(@Valid @NotNull final CaseDocumentsDataQuery caseDocumentsDataQuery) {
        return proceedingPartyService.getAllProceedingPartyDetails(caseDocumentsDataQuery);
    }

    /**
     * Method used to save the proceeding party details
     *
     * @param proceedingParties       - request object containing the proceeding party details
     * @param partyRepresentIndicator - party represent indicator
     */
    @PostMapping
    public JsonNode saveProceedingPartyDetails(@Valid @NotNull @RequestBody final JsonNode proceedingParties,
            @RequestParam(defaultValue = "N") final String partyRepresentIndicator) {
        proceedingPartyService.savePartyDetails(proceedingParties, partyRepresentIndicator);
        return proceedingParties;
    }

    @PutMapping
    public JsonNode updateProceedingPartyDetails(@Valid @NotNull @RequestBody final JsonNode proceedingParties) {
        proceedingPartyService.updatePartyDetails(proceedingParties);
        return proceedingParties;
    }

    @PutMapping(value = "/switch-counsels")
    public JsonNode performCounselSwitch(@Valid @NotNull @RequestBody final JsonNode proceedingParties,
            @RequestParam(defaultValue = "N") final Boolean isLeadCounsel) {
        return proceedingPartyService.performCounselSwitch(proceedingParties, isLeadCounsel);
    }

    /**
     * Method used to delete proceeding party details
     *
     * @param proceedingPartyQuery - object containing the query parameter information
     */
    @DeleteMapping
    public void deleteProceedingPartyDetails(final ProceedingPartyQuery proceedingPartyQuery) {
        proceedingPartyService.deletePartyDetails(proceedingPartyQuery);

    }

    /**
     * This method is used for validatiing proceeding party details
     * 
     * @param caseType
     * @param registrationNumber
     * @param email
     * @return
     */
    @GetMapping(path = "/counsels/{caseType}")
    public JsonNode getPrcdCounselInfo(@PathVariable("caseType") final String caseType,
            @RequestParam(required = false) final String registrationNumber, @RequestParam(required = false) final String email) {
        return proceedingPartyService.getPrcdCounselInfo(caseType, registrationNumber, email);
    }

}
