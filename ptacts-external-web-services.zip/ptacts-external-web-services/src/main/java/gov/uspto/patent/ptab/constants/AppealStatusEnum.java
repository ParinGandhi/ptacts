package gov.uspto.patent.ptab.constants;

/**
 * Enum to represent the Appeal Status.
 * 
 *
 */
public enum AppealStatusEnum {
    INITIATED(5L, "Initiated"), COMPLETED(3L, "Completed"), AWAITING_DECISION(2L, "AWAITING_DECISION");

    private final Long appealStatusId;
    private final String appealStatusNm;

    /**
     * Full Constructor
     * 
     * @param appealStatusId The Appeal Status Id
     */
    private AppealStatusEnum(Long appealStatusId, String appealStatusNm) {
        this.appealStatusId = appealStatusId;
        this.appealStatusNm = appealStatusNm;
    }

    /**
     * Getter for Appeal Status Id
     * 
     * @return Long The Appeal Status Id
     */
    public Long getAppealStatusId() {
        return this.appealStatusId;
    }

    /**
     * Getter for Appeal Status description
     * 
     * @return Long The Appeal Status description
     */
    public String getAppealStatusNm() {
        return this.appealStatusNm;
    }

    /**
     * Gets the Date Type Enum for the given Appeal TypeId
     * 
     * @param appealStatusId
     * @param appealStatus
     * @return
     */
    public static AppealStatusEnum fromValue(Long appealStatusId) {
        for (AppealStatusEnum appealStatus : AppealStatusEnum.values()) {
            if (appealStatus.getAppealStatusId().equals(appealStatusId)) {
                return appealStatus;
            }
        }
        return null;
    }
}