package gov.uspto.patent.ptab.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Data;

/**
 * VO for the transaction information
 */
@Data
public class TransactionVO implements Serializable {

    private static final long serialVersionUID = 7332694816637512680L;
    private String accountingDate;
    private BigDecimal amount;
    private String systemId;
    private String feeCode;
    private String mailRoomDate;
    private String paymentMethod;
    private String postingReferenceIndicator;
    private int sequenceNumber;
    private String feeCodeDescription;
    private BigDecimal feeCodeAmt;
    private int quantity;
    private String prcdngPartyGroupTypeCd;
}