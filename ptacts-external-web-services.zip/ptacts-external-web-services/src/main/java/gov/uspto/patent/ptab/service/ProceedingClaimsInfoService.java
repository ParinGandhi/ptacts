package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.ProceedingClaims;
import gov.uspto.patent.ptab.domain.ProceedingIdentifiers;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to provide service layer for proceeding claims information
 * 
 * @author 2020 development team
 *
 */
@Slf4j
@Service
public class ProceedingClaimsInfoService {
    private static final String GET_CLAIMS_URL = "GET_CLAIMS_URL";
    private static final String SYSTEM_USER = "SYSTEM_USER";
    private static final String PTAB_CASE_INIT = "PTAB_CASE_INIT";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    private static final String GET_STATUTORY_URL = "GET_STATUTORY_URL";
    private static final String CREATE_CLAIM_URL = "CREATE_CLAIM_URL";
    private static final String UPDATE_CLAIM_URL = "UPDATE_CLAIM_URL";
    private static final String DELETE_CLAIM_URL = "DELETE_CLAIM_URL";
    private static final String SYSTEM = "system user name";

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private PTABBusinessUtils ptabBusinessUtils;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    /**
     * This method provides proceeding claims info
     */
    @Transactional
    public JsonNode getProceedingClaims(ProceedingIdentifiers prcdIdentifiers) {
        final String claimsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL, GET_CLAIMS_URL);
        notFoundIfNull(claimsUrl, "Get Claims details Url");

        final String userName = ptabBusinessUtils.getLoggedInUserId();
        final String url = claimsUrl + "/" + prcdIdentifiers.getCaseType() + "/" + prcdIdentifiers.getCaseNo();
        ResponseEntity<JsonNode> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, JsonNode.class, userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response ? response.getBody() : null;
    }

    /**
     * This method returns all Statutory ground details
     * 
     * @return
     */
    @Transactional
    public JsonNode getStatutoryGrounds() {
        final String statutoryUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                GET_STATUTORY_URL);
        notFoundIfNull(statutoryUrl, "Get Statutory details Url");

        final String userName = ptabBusinessUtils.getLoggedInUserId();
        ResponseEntity<JsonNode> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(statutoryUrl, null, HttpMethod.GET, JsonNode.class,
                    userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response ? response.getBody() : null;
    }

    /**
     * This method creates new proceeding claims
     */
    @Transactional
    public void createProceedingClaim(ProceedingClaims proceedingClaims) {
        final String claimUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                CREATE_CLAIM_URL);
        notFoundIfNull(claimUrl, "Create Claims details Url");

        final String userName = ptabBusinessUtils.getLoggedInUserId();
        try {
            restServiceClient.callPTABExternalServiceURL(claimUrl, proceedingClaims, HttpMethod.POST, Void.class,
                    userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
    }

    /**
     * This method is to update proceeding claims
     * 
     */
    @Transactional
    public void updateProceedingClaim(ProceedingClaims proceedingClaims) {
        final String claimUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                UPDATE_CLAIM_URL);
        notFoundIfNull(claimUrl, "Update Claims details Url");

        final String userName = ptabBusinessUtils.getLoggedInUserId();
        try {
            restServiceClient.callPTABExternalServiceURL(claimUrl, proceedingClaims, HttpMethod.PUT, Void.class, userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }

    }

    /**
     * This method is to delete proceeding claims
     */
    @Transactional
    public void deleteProceedingClaim(final Long identifier) {
        final String claimUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                DELETE_CLAIM_URL);
        notFoundIfNull(claimUrl, "Delete Claims details Url");

        final String userName = ptabBusinessUtils.getLoggedInUserId();
        try {
            restServiceClient.callPTABExternalServiceURL(claimUrl + "/" + identifier, null, HttpMethod.DELETE, Void.class,
                    userName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
    }
}
