package gov.uspto.patent.ptab.dao;

import lombok.extern.slf4j.Slf4j;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

/**
 * DAO Implementation for Claims Info
 * 
 * @author 2020 development team
 *
 */

@Slf4j
@Repository
@Transactional
public class PetitionClaimDao {

    private static final String PROCEEDING_NUMBER = "proceeding_no";

    @Autowired
    private SessionFactory sessionFactory;

    /**
     * This method is used to get Claims related information
     * 
     * @param proceedingNumber
     * @return
     */
    public BigDecimal getTotalClaims(final String proceedingNumber) {
        log.info("Dao call for getTotalClaimCount method: proceedingNumber:{}", proceedingNumber);
        final Query<?> qry = sessionFactory.getCurrentSession().createNamedQuery("getTotalClaimCount",Object[].class);
        qry.setParameter(PROCEEDING_NUMBER, proceedingNumber);
        return (BigDecimal) qry.getSingleResult();

    }

}
