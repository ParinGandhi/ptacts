package gov.uspto.patent.ptab.entities;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

/**
 * The primary key class for the STND_PRCDNG_CT_STATY_GROUND database table.
 * 
 */
@Embeddable
@Getter
@Setter
@RequiredArgsConstructor
public class StndPrcdngCtStatyGroundId implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "FK_STATUTORY_GROUND_ID", insertable = false, updatable = false)
    private long fkStatutoryGroundId;

    @Column(name = "FK_PROCEEDING_TYPE_ID", insertable = false, updatable = false)
    private long fkProceedingTypeId;

}