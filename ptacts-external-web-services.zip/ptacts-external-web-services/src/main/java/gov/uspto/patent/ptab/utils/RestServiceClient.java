package gov.uspto.patent.ptab.utils;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import java.net.URI;
import java.nio.charset.StandardCharsets;

//import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to call external rest service and get the response
 *
 * @author 2020 development team
 *
 */
@Component
@Slf4j
public class RestServiceClient {

    private static final String HEADER_VALUE_APPL_JSON = "application/json;charset=UTF-8";
    private static final String HEADER_NAME_ACCEPT = "Accept";
    private static final String USER_NAME_HEADER_KEY = "user-name";
    private static final String REQUEST_FORMAT = "request: serviceUrl:{} ; callType:{}";
    private static final String USER_ID = "User Id";
    private static final String USER_NAME_ATTRIBUTE_KEY = "valid-user";

    @Autowired
    private HttpServletRequest httpServletRequest;

    /**
     * This is a common method to call external REST service. Returns null if
     * the call fails
     *
     * @param serviceUrl - URL of the service
     * @param requestBody - to accept the request.
     * @param callType - Http method -GET,PUT,POST,DELETE .
     * @param responseType response object class
     * @return -returns response object
     */
    public <B, R> R callExternalServiceURL(final String serviceUrl, final B requestBody, final HttpMethod callType,
            final Class<R> responseType) {

        final HttpHeaders headers = new HttpHeaders();
        headers.add(HEADER_NAME_ACCEPT, HEADER_VALUE_APPL_JSON);
        headers.setContentType(MediaType.APPLICATION_JSON);
        String loggedInUser = getLoggedInUserId();
        headers.add(USER_NAME_HEADER_KEY, loggedInUser);
        final RestTemplate restTemplate = getRestTemplate();
        log.info(REQUEST_FORMAT, serviceUrl, callType);
        final HttpEntity<B> request = requestBody == null ? new HttpEntity<>(headers) : new HttpEntity<>(requestBody, headers);
        final ResponseEntity<R> response = restTemplate.exchange(URI.create(serviceUrl), callType, request, responseType);
        return response.getBody();
    }

    private RestTemplate getRestTemplate() {
        final RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(StandardCharsets.UTF_8));
        restTemplate.setErrorHandler(new PTABExternalServiceErrorHandler());
        return restTemplate;
    }

    /**
     * This is a common method to call external REST service. Returns null if
     * the call fails
     *
     * @param serviceEndPointUrl - URL of the service
     * @param applicationIdentifierQuery- build url using
     *            ApplicationIdentifierQuery members
     * @param responseType response object class
     * @return
     */
    public <B, R> ResponseEntity<R> callPTABExternalServiceURL(final String serviceUrl, final B requestBody,
            final HttpMethod callType, final Class<R> responseType, final String userName) {
        final HttpHeaders headers = new HttpHeaders();
        headers.add(HEADER_NAME_ACCEPT, HEADER_VALUE_APPL_JSON);
        headers.setContentType(MediaType.APPLICATION_JSON);
        String loggedInUser = getLoggedInUserId();
        headers.add(USER_NAME_HEADER_KEY, loggedInUser);
        return invokeWebService(serviceUrl, requestBody, callType, responseType, headers);

    }

    /**
     * This is a common method to call external REST service. Returns null if
     * the call fails
     *
     * @param serviceEndPointUrl - URL of the service
     * @param applicationIdentifierQuery- build url using
     *            ApplicationIdentifierQuery members
     * @param responseType response object class
     * @param headers http headers
     * @return
     */
    public <B, R> ResponseEntity<R> invokeWebService(final String serviceUrl, final B requestBody, final HttpMethod callType,
            final Class<R> responseType, final String userName) {
        final HttpHeaders headers = new HttpHeaders();
        headers.add(HEADER_NAME_ACCEPT, HEADER_VALUE_APPL_JSON);
        headers.setContentType(MediaType.APPLICATION_JSON);
        String loggedInUser = getLoggedInUserId();
        headers.add(USER_NAME_HEADER_KEY, loggedInUser);
        final HttpEntity<B> request = requestBody == null ? new HttpEntity<>(headers) : new HttpEntity<>(requestBody, headers);
        final RestTemplate restTemplate = getRestTemplate();
        log.info(REQUEST_FORMAT, serviceUrl, callType);
        final ResponseEntity<R> response = restTemplate.exchange(URI.create(serviceUrl), callType, request, responseType);
        log.debug("response:{}", response);

        return response;
    }

    /**
     * This is a common method to call external REST service. Returns null if
     * the call fails
     *
     * @param serviceEndPointUrl - URL of the service
     * @param applicationIdentifierQuery- build url using
     *            ApplicationIdentifierQuery members
     * @param responseType response object class
     * @param headers http headers
     * @return
     */
    public <B, R> ResponseEntity<R> invokeWebService(final String serviceUrl, final B requestBody, final HttpMethod callType,
            final Class<R> responseType, final HttpHeaders headers) {

        final HttpEntity<B> request = requestBody == null ? new HttpEntity<>(headers) : new HttpEntity<>(requestBody, headers);
        final RestTemplate restTemplate = getRestTemplate();
        log.info(REQUEST_FORMAT, serviceUrl, callType);
        final ResponseEntity<R> response = restTemplate.exchange(URI.create(serviceUrl), callType, request, responseType);
        log.debug("response:{}", response);

        return response;
    }

    /**
     * This is a common method to call external REST service. Returns null if
     * the call fails
     *
     * @param serviceEndPointUrl - URL of the service
     * @param applicationIdentifierQuery- build url using
     *            ApplicationIdentifierQuery members
     * @param responseType response object class
     * @param headers http headers
     * @return
     */
    public <B, R> ResponseEntity<R> invokeWebServiceAndCatchError(final String serviceUrl, final B requestBody,
            final HttpMethod callType, final Class<R> responseType, final HttpHeaders headers) {

        final HttpEntity<B> request = requestBody == null ? new HttpEntity<>(headers) : new HttpEntity<>(requestBody, headers);
        final RestTemplate restTemplate = getRestTemplate();
        log.info(REQUEST_FORMAT, serviceUrl, callType);
        final ResponseEntity<R> response = restTemplate.exchange(URI.create(serviceUrl), callType, request, responseType);
        log.debug("response:{}", response);

        return response;
    }
    public String getLoggedInUserId() {
        final String userIdentifier = (String) httpServletRequest.getAttribute(USER_NAME_ATTRIBUTE_KEY);
        if (StringUtils.isBlank(userIdentifier)) {
            notFoundIfNull(userIdentifier, USER_ID);
        }
        return userIdentifier;
    }
}