package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;
import static gov.uspto.patent.ptab.utils.PTABServiceUtils.validateAndThrowExceptionWithMsg;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.dao.UserPermissionsDao;
import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.domain.Petition;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.entities.ProceedingEntity;
import gov.uspto.patent.ptab.helper.ProceedingArtifactUtilityHelper;
import gov.uspto.patent.ptab.repository.ProceedingRepository;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProceedingArtifactService {

    private static final String ARTIFACT_INTERNAL_URL = "ARTIFACT_CREATE_INTERNAL_URL";
    private static final String INITIATE_PETITION_ARTIFACTS_URL = "INITIATE_PETITION_ARTIFACTS_URL";
    private static final String PROCEEDING_NUMBER_QUERY_PARAM = "?proceedingNumber=";
    private static final String EXPORT_PAPER_EXHIBITS_URL = "EXPORT_PAPER_EXHIBITS_URL";
    private static final String ARTIFACT_UPDATE_URL_TYPE = "ARTIFACT_UPDATE_URL";
    private static final String ARTIFACT_CREATE_URL_TYPE = "ARTIFACT_CREATE_URL";
    private static final String ARTIFACT_UPDATE_URL = "artifact update url";
    private static final String ARTIFACT_CREATE_URL = "artifact create url";
    private static final String ARTIFACT_SEQUENCE_URL = "artifact sequence url";
    private static final String EXHIBITS_SEQUENCE_URL = "artifact sequence url";
    private static final String ARTIFACT_RETRIEVE_URL = "artifact retrieve url";

    private static final String ARTIFACT_SEQ_URL_TYPE = "ARTIFACT_SEQ_URL";
    private static final String EXHIBITS_SEQ_URL_TYPE = "EXHIBITS_SEQ_URL";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    private static final String ALL_ARTIFACTS_URL_CODE = "ALL_ARTIFACTS_URL";
    private static final String ARTIFACT_DELETE_URL = "ARTIFACT_DELETE_URL";
    private static final String SYSTEM_USER = "SYSTEM_USER";
    private static final String PTAB_CASE_INIT = "PTAB_CASE_INIT";

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private PTABBusinessUtils ptabBusinessUtils;

    @Autowired
    private ExternalUserService externalUserService;

    @Autowired
    private ProceedingArtifactUtilityHelper proceedingArtifactUtilityHelper;

    @Autowired
    private UserPermissionsDao userPermissionsDao;

    @Autowired
    private ProceedingRepository proceedingRepository;

    @Autowired
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @SuppressWarnings("serial")
    @Transactional
    public Map<String, String> getNextPaperSequenceIdentifier(
            @Valid @NotNull final CaseDocumentsDataQuery caseDocumentsDataQuery) {
        final String externalArtifactSeqUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                ARTIFACT_SEQ_URL_TYPE);
        notFoundIfNull(externalArtifactSeqUrl, ARTIFACT_SEQUENCE_URL);
        final String jsonResponse = restServiceClient.callExternalServiceURL(
                externalArtifactSeqUrl + caseDocumentsDataQuery.getProceedingNumber(), null, HttpMethod.GET, String.class);
        return new Gson().fromJson(jsonResponse, new TypeToken<Map<String, String>>() {
        }.getType());

    }

    @SuppressWarnings("serial")
    @Transactional
    public List<Long> getExhibitsByProceedingAndTypeId(@Valid @NotNull final CaseDocumentsDataQuery caseDocumentsDataQuery) {
        final String externalArtifactSeqUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                EXHIBITS_SEQ_URL_TYPE);
        notFoundIfNull(externalArtifactSeqUrl, EXHIBITS_SEQUENCE_URL);

        final String exhibtsSeqUrl = externalServiceUriGenerator.getCaseDocumentDataQueryUrl(caseDocumentsDataQuery,
                externalArtifactSeqUrl);
        final String jsonResponse = restServiceClient.callExternalServiceURL(exhibtsSeqUrl, null, HttpMethod.GET, String.class);
        return new Gson().fromJson(jsonResponse, new TypeToken<List<Long>>() {
        }.getType());

    }

    @SuppressWarnings("serial")
    @Transactional
    public List<PetitionDocument> getAllArtifacts(final CaseDocumentsDataQuery caseDocumentsDataQuery,
            final boolean isPublicAccess) {

        final String userName = ptabBusinessUtils.getLoggedInUserId();
        final String proceedingNumber = caseDocumentsDataQuery.getProceedingNumber();
        final ProceedingEntity proceedingEntity = proceedingRepository.getProceedingDetails(proceedingNumber);
        validateAndThrowExceptionWithMsg(null == proceedingEntity,
                "Proceeding # or Proceeding core Id entered could not be found", HttpStatus.BAD_REQUEST);
        final String confidentialityIn = proceedingEntity.getConfidentialityIn();
        if (confidentialityIn.equals("Y")) {
            final String permissionPrcd = userPermissionsDao.checkProceedingByEmail(userName, proceedingNumber);
            if (permissionPrcd == null) {
                return new ArrayList<>();
            }
        }

        final String externalArtifactGetUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                ALL_ARTIFACTS_URL_CODE);
        notFoundIfNull(externalArtifactGetUrl, ARTIFACT_RETRIEVE_URL);
        final String jsonResponse = restServiceClient.callExternalServiceURL(externalArtifactGetUrl + proceedingNumber, null,
                HttpMethod.GET, String.class);
        final List<PetitionDocument> prcdArtifacts = new Gson().fromJson(jsonResponse, new TypeToken<List<PetitionDocument>>() {
        }.getType());

        String prcdPartyGrpType = "";
        if (!isPublicAccess) {
            prcdPartyGrpType = externalUserService.getPrcdPartyGroupType(proceedingNumber);
        }
        proceedingArtifactUtilityHelper.addFilterToUpdatePetitionDocs(prcdArtifacts, prcdPartyGrpType);

        ptabBusinessUtils.setEncryptArtifactIdentifiers(prcdArtifacts);
        return prcdArtifacts;
    }

    @SuppressWarnings("serial")
    @Transactional
    public List<PetitionDocument> getInitiatePetitionArtifacts(final CaseDocumentsDataQuery caseDocumentsDataQuery) {

        final String initiatePetitionArtifactUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                INITIATE_PETITION_ARTIFACTS_URL);
        notFoundIfNull(initiatePetitionArtifactUrl, ARTIFACT_RETRIEVE_URL);
        final String proceedingNumber = caseDocumentsDataQuery.getProceedingNumber();
        final String jsonResponse = restServiceClient.callExternalServiceURL(initiatePetitionArtifactUrl + proceedingNumber, null,
                HttpMethod.GET, String.class);
        final List<PetitionDocument> petitonDocuments = new Gson().fromJson(jsonResponse,
                new TypeToken<List<PetitionDocument>>() {
                }.getType());

        final String partyType = externalUserService.getPrcdPartyGroupType(proceedingNumber);
        proceedingArtifactUtilityHelper.addFilterToUpdatePetitionDocs(petitonDocuments, partyType);
        ptabBusinessUtils.setEncryptArtifactIdentifiers(petitonDocuments);
        return petitonDocuments;
    }

    @Transactional
    public Petition createProceedingArtifactForExternal(@RequestBody final Petition petition) {

        final String externalArtifactCreateUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                ARTIFACT_CREATE_URL_TYPE);
        notFoundIfNull(externalArtifactCreateUrl, ARTIFACT_CREATE_URL);
        final String userName = ptabBusinessUtils.getLoggedInUserId();
        final ResponseEntity<Petition> response = restServiceClient.callPTABExternalServiceURL(externalArtifactCreateUrl,
                petition, HttpMethod.POST, Petition.class, userName);
        final Petition updated = response.getBody();
        if (null != updated) {
            List<PetitionDocument> petitionDocuments = updated.getPetitionDocuments();
            ptabBusinessUtils.setEncryptArtifactIdentifiers(petitionDocuments);
            updated.setPetitionDocuments(petitionDocuments);

        }
        return updated;
    }

    @Transactional
    public Petition createProceedingArtifact(@RequestBody final Petition petition) {

        final String artifactCreateUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                ARTIFACT_INTERNAL_URL);
        notFoundIfNull(artifactCreateUrl, ARTIFACT_CREATE_URL);
        final String userName = ptabBusinessUtils.getLoggedInUserId();
        final ResponseEntity<Petition> response = restServiceClient.callPTABExternalServiceURL(artifactCreateUrl, petition,
                HttpMethod.POST, Petition.class, userName);
        final Petition updated = response.getBody();
        if (null != updated) {
            List<PetitionDocument> petitionDocuments = updated.getPetitionDocuments();
            ptabBusinessUtils.setEncryptArtifactIdentifiers(petitionDocuments);
            updated.setPetitionDocuments(petitionDocuments);

        }
        return updated;
    }

    @Transactional
    public PetitionDocument updateProceedingArtifact(final Long artifactId, final PetitionDocument petitionDocument) {
        final String externalArtifactUpdateUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                ARTIFACT_UPDATE_URL_TYPE);
        notFoundIfNull(externalArtifactUpdateUrl, ARTIFACT_UPDATE_URL);
        final String userName = ptabBusinessUtils.getLoggedInUserId();
        ptabBusinessUtils.setDecryptArtifactIdentifier(petitionDocument);
        final ResponseEntity<PetitionDocument> response = restServiceClient.callPTABExternalServiceURL(
                String.format(externalArtifactUpdateUrl, artifactId), petitionDocument, HttpMethod.PUT, PetitionDocument.class,
                userName);
        final PetitionDocument updated = response.getBody();
        if (null != updated) {
            ptabBusinessUtils.setEncryptArtifactIdentifier(updated);
        }
        return updated;
    }

    @Transactional
    public void deleteProceedingArtifact(@NotBlank @PathVariable("artifactId") final Long artifactId) {
        final String externalArtifactDeleteUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                ARTIFACT_DELETE_URL);
        notFoundIfNull(String.format(externalArtifactDeleteUrl, artifactId), "artifact delete url");
        final String userName = ptabBusinessUtils.getLoggedInUserId();
        final ResponseEntity<String> response = restServiceClient.callPTABExternalServiceURL(
                String.format(externalArtifactDeleteUrl, artifactId), null, HttpMethod.DELETE, String.class, userName);
        if (response.getStatusCode().is2xxSuccessful()) {
            log.info("Artifact Successfully deleted");
        }

    }

    /**
     * Method used to export paper exhibits
     *
     * @param proceedingNumber
     * @return
     */
    @Transactional
    public ResponseEntity<Resource> exportPaperAndExhibitsAsExcel(final CaseDocumentsDataQuery caseDocumentsDataQuery) {

        final String exportPaperExhibitsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                EXPORT_PAPER_EXHIBITS_URL);
        notFoundIfNull(exportPaperExhibitsUrl, "Export Paper Exhibits Url");
        final String proceedingNumber = caseDocumentsDataQuery.getProceedingNumber();
        final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(systemUserName, "system user name");
        try {
            final RestTemplate restTemplate = new RestTemplate();
            return restTemplate.exchange(exportPaperExhibitsUrl + PROCEEDING_NUMBER_QUERY_PARAM + proceedingNumber,
                    HttpMethod.GET, null, Resource.class);
        } catch (final HttpClientErrorException | HttpServerErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }

    }
}
