package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

/**
 * service used to retrieve the notification email details
 *
 * @author 2020 development team
 *
 */
@Slf4j
@Component
public class NotificationService {

    private static final String NOTIFICATION_EMAIL_DETAILS_URL = "NOTIFICATION_EMAIL_DETAILS_URL";
    private static final String SYSTEM_USER = "SYSTEM_USER";
    private static final String PTAB_CASE_INIT = "PTAB_CASE_INIT";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    /**
     * Method used to fetch the notification email details
     *
     * @param notificationId - notification id
     * @return
     */
    @Transactional
    public JsonNode getNotificationEmailDetails(final String notificationId) {

        final String notificationEmailDetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                NOTIFICATION_EMAIL_DETAILS_URL);
        notFoundIfNull(notificationEmailDetailsUrl, "Notification details Url");

        final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(systemUserName, "system user name");

        log.info("calling common services for fetching notification email details for notification id : {}", notificationId);

        ResponseEntity<JsonNode> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(
                    notificationEmailDetailsUrl + StringUtils.trim(notificationId), null, HttpMethod.GET, JsonNode.class,
                    systemUserName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response ? response.getBody() : null;
    }
}
