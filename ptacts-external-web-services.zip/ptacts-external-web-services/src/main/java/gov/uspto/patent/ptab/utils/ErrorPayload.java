package gov.uspto.patent.ptab.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * This class contains fields used in JSON response payload for error conditions. The class level
 * annotations, @Getter, @Setter, @AllArgsConstructor is used instead of getter and setter methods and constructor.
 * 
 * @JsonSerialize includes only those fields that have been initialized to non-null values.
 * 
 * @author 2020 Development Team
 * 
 */
@Getter
@Setter
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class ErrorPayload {

    private String message;
    private String systemMessage;
    private Integer errorCode;
    private Integer reasonCode;

    /**
     * Constructor initializes error message
     * 
     * 
     * @param message - error message
     */
    public ErrorPayload(final String message) {
        this.message = message;
    }

    /**
     * Constructor initializes error message with error code and reason code
     * 
     * @param message    - error message
     * @param errorCode  - error code
     * @param reasonCode - reason code
     */
    public ErrorPayload(final String message, final Integer errorCode, final Integer reasonCode) {
        this.message = message;
        this.errorCode = errorCode;
        this.reasonCode = reasonCode;
    }
}
