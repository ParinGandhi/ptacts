package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the DOCUMENT database table.
 */
@Entity
@NamedQuery(name = "Document.findAll", query = "SELECT d FROM Document d")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Document extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "FK_PROCEEDING_ARTIFACT_ID")
    private long fkProceedingArtifactId;

    @Temporal(TemporalType.DATE)
    @Column(name = "DECISION_DT")
    private Date decisionDt;

    @Column(name = "DOCUMENT_NO")
    private Long documentNo;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    @Column(name = "FK_DOCUMENT_TYPE_ID")
    private Long fkDocumentTypeId;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "FK_PROCEEDING_ARTIFACT_ID", insertable = false, updatable = false)
    private ProceedingArtifact proceedingArtifact;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "FK_DOCUMENT_TYPE_ID", insertable = false, updatable = false)
    private StndDocumentType stndDocumentType;

}