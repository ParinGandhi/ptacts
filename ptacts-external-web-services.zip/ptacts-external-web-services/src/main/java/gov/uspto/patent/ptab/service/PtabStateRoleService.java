package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;

import java.util.List;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.google.gson.Gson;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.PtabStateRoleDisplayDetails;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

/**
 * This service class for ptab state role
 * 
 * @author 2020 development team
 *
 */
@Component
@Slf4j
public class PtabStateRoleService {

    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";
    private static final String PTAB_STATE_ROLE_URL = "PTAB_STATE_ROLE_URL";
    private static final String SYSTEM_USER = "SYSTEM_USER";
    private static final String PTAB_CASE_INIT = "PTAB_CASE_INIT";
    private static final String SYSTEM = "system user name";
    private static final String CALLING = "calling Trials services for fetching Ptab state role data";

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Autowired
    private RestServiceClient restServiceClient;

    @Transactional
    public List<PtabStateRoleDisplayDetails> getStateRoleDisplay(final String caseNumber) {

        final String ptabStateRoleUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                PTAB_STATE_ROLE_URL);
        notFoundIfNull(ptabStateRoleUrl, "ptab state role Url");

        final String url = externalServiceUriGenerator.constructPtabStateRoleUrl(caseNumber, ptabStateRoleUrl);

        final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(systemUserName, SYSTEM);
        log.info(CALLING);
        ResponseEntity<String> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, String.class, systemUserName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response
                ? new Gson().fromJson(response.getBody(), new ParameterizedTypeReference<List<PtabStateRoleDisplayDetails>>() {
                }.getType())
                : null;

    }
}