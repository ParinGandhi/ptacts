package gov.uspto.patent.ptab.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import gov.uspto.patent.ptab.domain.EmployeeDetails;
import lombok.extern.slf4j.Slf4j;

/**
 * DAO Implementation for AssignmentQueries
 * 
 * @author 2020 development team
 *
 */
@Repository
@SuppressWarnings({ "unchecked" })
@Slf4j
public class AssignmentQueriesDao {

    private static final String SLASH = "\'";
    private static final String APPLICATION_USER_ID = "APPLICATION_USER_ID='";
    private static final String USER_ID = "USER_ID='";
    private static final String GET_NAME = "SELECT FIRST_NM as \"firstName\"";
    private static final String GET_MIDDLE_NAME = " ,MIDDLE_NM as \"middleName\",LAST_NM as \"lastName\"";
    private static final String GET_USER_CT = " ,USER_CT as \"userCt\"";
    private static final String FROM_TABLE = " FROM APPLICATION_USER WHERE ";

    @Autowired
    private SessionFactory sessionFactory;

    /**
     * This method is used to get the employee full name based on id
     *
     * @param userId - unique input userId
     * @param applicationUserId - unique input applicationUserId
     * 
     * @return
     */
    public List<EmployeeDetails> fetchFullNamesOfEmployee(final String userId, final String applicationUserId) {
        log.info("Dao call for getName method; userId:{},applicationUserId:{}", userId, applicationUserId);
        final List<EmployeeDetails> listEmployeeDetails = new ArrayList<>();
        final List<String> listWhereCondition = new ArrayList<>();
        final StringBuilder queryBuilder = new StringBuilder(GET_NAME + GET_MIDDLE_NAME + GET_USER_CT + FROM_TABLE);
        if (StringUtils.isNotEmpty(userId)) {
            listWhereCondition.add(USER_ID + StringUtils.trim(userId) + SLASH);
        }
        if (StringUtils.isNumeric(StringUtils.trim(applicationUserId))) {
            listWhereCondition.add(APPLICATION_USER_ID + StringUtils.trim(applicationUserId) + SLASH);
        }
        if (CollectionUtils.isNotEmpty(listWhereCondition)) {
            queryBuilder.append(StringUtils.join(listWhereCondition, " or "));

            final Query<EmployeeDetails> qry = sessionFactory.getCurrentSession().createQuery(queryBuilder.toString(),
                    EmployeeDetails.class);
            // listEmployeeDetails.addAll(qry.setr.setResultTransformer(Transformers.aliasToBean(EmployeeDetails.class)).list());
            listEmployeeDetails.addAll((Collection<? extends EmployeeDetails>) qry);
        }
        return listEmployeeDetails;
    }

}