package gov.uspto.patent.ptab.common.opsg.domain;

import java.util.Date;

//import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.uspto.patent.ptab.utils.EpochDeserializer;
import gov.uspto.patent.ptab.utils.EpochSerializer;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

/**
 * The audit data contains last modified user information and is related to action engine service call
 * 
 * @author 2020 Development Team
 */
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class Audit {

    @Size(min = 0, max = 20)
    private String lastModifiedUserIdentifier;

    @Size(min = 0, max = 20, message = "createUserIdentifier must be from 0 to 20 chars")
    private String createUserIdentifier;
    @JsonSerialize(using = EpochSerializer.class)
    @JsonDeserialize(using = EpochDeserializer.class)
    private Date lastModifiedDateTime;
    @JsonSerialize(using = EpochSerializer.class)
    @JsonDeserialize(using = EpochDeserializer.class)
    private Date createDateTime;
}
