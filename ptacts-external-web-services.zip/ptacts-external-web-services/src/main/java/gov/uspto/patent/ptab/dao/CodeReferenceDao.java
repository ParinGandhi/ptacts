package gov.uspto.patent.ptab.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import gov.uspto.patent.ptab.domain.CodeReferenceLookup;
import gov.uspto.patent.ptab.entities.CodeReferenceEntity;
import gov.uspto.patent.ptab.entities.CodeReferenceId;
import gov.uspto.patent.ptab.repository.CodeReferenceRepository;
import lombok.extern.slf4j.Slf4j;

/**
 * DAO Implementation for CodeReference
 *
 * @author 2020 development team
 *
 */
@Slf4j
@Component
public class CodeReferenceDao {

    @Autowired
    private CodeReferenceRepository codeReferenceRepository;

    /**
     * fetch code_reference for tasks
     *
     * @param valueTx - input Value Text
     * @param typeCode - input type code
     * @return
     */
    @Cacheable(value = "findDescriptionByTypeCodeAndValueTx")
    public String findDescriptionByTypeCodeAndValueTx(final String typeCd, final String valueTx) {

        final CodeReferenceEntity codeReferenceEntity = codeReferenceRepository.findDescriptionByTypeCdAndValueTx(typeCd,
                valueTx);
        return null == codeReferenceEntity ? "" : codeReferenceEntity.getDescriptionTx();
    }

    /**
     * This method is used to get codeReference Desc based on typeCode value
     *
     * @param typeCode - input type code
     * @param valueTx - input value code
     * @return
     */
    public String getFirstDescCodeRefByTypeCdAndValue(final String typeCode, final String valueTx) {
        final Optional<CodeReferenceEntity> codeReferenceEntity = codeReferenceRepository
                .findById(new CodeReferenceId(typeCode, valueTx));
        if (codeReferenceEntity.isPresent()) {
            return codeReferenceEntity.get().getDescriptionTx();
        }
        return "";
    }

    /**
     * This method is used to fetch code reference via type code
     * 
     * @param typeCode - unique typeCode
     * @return
     */
    public List<CodeReferenceLookup> fetchCodeReferenceViaTypeCode(final String typeCode) {
        log.info("Dao call for fetchFeeCodeForImport method");
        final List<CodeReferenceLookup> listCodeReferenceLookup = new ArrayList<>();
        final List<CodeReferenceEntity> listCodeReferenceEntity = codeReferenceRepository
                .findAllByTypeCdOrderByValueTx(typeCode);

        if (CollectionUtils.isNotEmpty(listCodeReferenceEntity)) {
            for (final CodeReferenceEntity codeReferenceEntity : listCodeReferenceEntity) {
                final CodeReferenceLookup codeReferenceLookup = new CodeReferenceLookup();
                codeReferenceLookup.setValueText(codeReferenceEntity.getValueTx());
                codeReferenceLookup.setDescriptionText(codeReferenceEntity.getDescriptionTx());
                listCodeReferenceLookup.add(codeReferenceLookup);
            }
        }
        return listCodeReferenceLookup;
    }

}
