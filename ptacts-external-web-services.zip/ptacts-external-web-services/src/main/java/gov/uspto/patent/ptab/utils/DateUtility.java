package gov.uspto.patent.ptab.utils;

import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.http.HttpStatus;

import lombok.extern.slf4j.Slf4j;

/**
 * This is a Utility class which helps in converting String to Date or Date to String..etc. There are utility methods to do date
 * calculation also.
 *
 * @author 2020 Development Team
 */
@Slf4j
public final class DateUtility {

    /**
     * Private constructor to hide implicit public constructor.
     */
    private DateUtility() {

    }

    /**
     * This method converts a given String to a Date object.
     *
     * @param dateFormat - A valid SimpleDateFormat format.
     * @param strDate - A valid Date String.
     * @return Date - returns date
     *
     */
    public static Date formatStringToDate(final String dateFormat, final Object strDate) {
        if (null != strDate) {
            try {
                return DateUtils.parseDateStrictly(String.valueOf(strDate), dateFormat);
            } catch (final ParseException pe) {
                log.error("Exception occurred while formatting date", pe);
                throw new PTABException(HttpStatus.BAD_REQUEST,"Error occurred while parsing date");
            }
        }
        return null;
    }
}
