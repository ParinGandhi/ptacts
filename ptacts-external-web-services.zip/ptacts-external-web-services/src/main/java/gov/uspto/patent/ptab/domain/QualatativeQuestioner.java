package gov.uspto.patent.ptab.domain;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class QualatativeQuestioner {

    private BigDecimal qualatativeQId;
    private String question;
    private BigDecimal displaySequenceNumber;
    @JsonProperty("answerTypes")
    private JsonNode answerTypes;
    private String comments;
    private List<String> references;
    private String instruction;
    private String outcomeText;
    private String questionStatus;
    private String decisionCategory;
}
