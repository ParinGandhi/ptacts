package gov.uspto.patent.ptab.common.opsg.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * This class models Claims
 *
 * @author 2020 Development Team
 */
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class ApplicationClaimData {

    private String multipleDependentClaimCode;
    private Integer effectiveClaimTotalQuantity;
    private Integer independentClaimTotalQuantity;
    private Integer claimTotalQuantity;
    private AuditData audit;

}
