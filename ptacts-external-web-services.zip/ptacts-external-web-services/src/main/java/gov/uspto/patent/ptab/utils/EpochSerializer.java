package gov.uspto.patent.ptab.utils;

import java.io.IOException;
import java.util.Date;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

/**
 * This class is used for Serialize Epoch Date
 *
 * @author 2020 Development Team
 *
 */
public class EpochSerializer extends JsonSerializer<Date> {

    public static final int DEFAULT_TIME_FOR_SERIALIZE_DESERIALIZSE = 1000;

    /**
     * This method is used for serialization
     *
     * @param utilDate - date to be serialized
     * @param jsonGenerator - JsonGenerator for writing json content
     * @param serializerProvider - SerializerProvider to obtain serializers
     *            capable of serializing instances of specific types
     * @throws IOException
     */
    @Override
    public void serialize(final Date utilDate, final JsonGenerator jsonGenerator, final SerializerProvider serializerProvider)
            throws IOException {
        jsonGenerator.writeString(String.valueOf(utilDate.getTime() / DEFAULT_TIME_FOR_SERIALIZE_DESERIALIZSE));
    }

}
