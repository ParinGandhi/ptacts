package gov.uspto.patent.ptab.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class PhysicalAddress {

    private String identifier;
    private String name;
    private String streetLineOneText;
    private String streetLineTwoText;
    private String city;
    private String state;
    private String zipCode;
    private String country;
    private String addressType;

}
