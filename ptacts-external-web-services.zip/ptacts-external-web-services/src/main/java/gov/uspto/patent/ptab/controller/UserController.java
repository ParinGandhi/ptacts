package gov.uspto.patent.ptab.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.service.ExternalUserService;
import gov.uspto.patent.ptab.service.InternalUserService;

@RestController
@RequestMapping(value = "/users")
public class UserController {

    @Autowired
    private InternalUserService internalUserService;

    @Autowired
    private ExternalUserService externalUserService;

    @GetMapping(value = "/internal-users")
    public JsonNode getAllInternalUserDetails() {
        return internalUserService.getAllExternalUserDetails();
    }

    @GetMapping(value = "/external-users")
    public JsonNode getAllExternalUserDetails() {
        return externalUserService.getAllExternalUserDetails();
    }

}
