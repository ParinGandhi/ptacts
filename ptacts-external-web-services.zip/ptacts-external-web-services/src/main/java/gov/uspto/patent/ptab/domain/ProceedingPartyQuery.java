package gov.uspto.patent.ptab.domain;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ProceedingPartyQuery {

    private String proceedingNumber;
    private Long proceedingPartyIdentifier;
    private String registrationNumberText;
    private String emailAddressText;
}
