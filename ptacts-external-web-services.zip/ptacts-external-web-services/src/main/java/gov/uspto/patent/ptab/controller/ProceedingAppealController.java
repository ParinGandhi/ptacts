package gov.uspto.patent.ptab.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.patent.ptab.domain.ProceedingAppealInfo;
import gov.uspto.patent.ptab.service.ProceedingAppealService;
import jakarta.validation.Valid;

/**
 * THis class is used to handle REST API for proceeding-appeal
 *
 * @author 2020 development team
 *
 */
@RestController
@RequestMapping(path = "/proceeding-appeal")
@Validated
public class ProceedingAppealController {

    @Autowired
    private ProceedingAppealService proceedingAppealService;

    @PostMapping
    public ProceedingAppealInfo createProceedingAppealInfo(
            @RequestBody @Valid final ProceedingAppealInfo proceedingAppealInfo) {
        return proceedingAppealService.createProceedingAppealInfo(proceedingAppealInfo);

    }
}
