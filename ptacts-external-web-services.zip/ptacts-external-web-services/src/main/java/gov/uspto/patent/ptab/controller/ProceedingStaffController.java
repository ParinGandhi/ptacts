package gov.uspto.patent.ptab.controller;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.domain.ProceedingParties;
import gov.uspto.patent.ptab.domain.ProceedingPartyQuery;
import gov.uspto.patent.ptab.service.ProceedingPartyService;
import gov.uspto.patent.ptab.service.ProceedingPartyStaffService;

@RestController
@RequestMapping("/proceeding-staff-details")
public class ProceedingStaffController {

    @Autowired
    private ProceedingPartyStaffService proceedingPartyStaffService;

    @Autowired
    private ProceedingPartyService proceedingPartyService;

    @GetMapping
    public JsonNode getAllProceedingPartyAndStaffDetails(@Valid @NotNull final CaseDocumentsDataQuery caseDocumentsDataQuery) {
        return proceedingPartyService.getAllProceedingPartyDetails(caseDocumentsDataQuery);
    }

    @PostMapping
    public JsonNode saveProceedingStaffPartyDetails(@Valid @NotNull @RequestBody final ProceedingParties proceedingParties,
            @RequestParam(defaultValue = "N") final String partyRepresentIndicator) {
        return proceedingPartyStaffService.savePartyStaffDetails(proceedingParties, partyRepresentIndicator);
    }

    /**
     * Method used to update the proceeding party details
     *
     * @param proceedingParties - request object containing the proceeding party details
     *
     */
    @PutMapping
    public JsonNode updateProceedingStaffPartyDetails(@Valid @NotNull @RequestBody final ProceedingParties proceedingParties) {
        return proceedingPartyStaffService.updatePartyStaffDetails(proceedingParties);
    }

    /**
     * Method used to delete proceeding party details
     *
     * @param proceedingPartyQuery - object containing the query parameter information
     */
    @DeleteMapping
    public void deleteProceedingPartyDetails(final ProceedingPartyQuery proceedingPartyQuery) {
        proceedingPartyStaffService.deleteStaffDetails(proceedingPartyQuery);

    }

}
