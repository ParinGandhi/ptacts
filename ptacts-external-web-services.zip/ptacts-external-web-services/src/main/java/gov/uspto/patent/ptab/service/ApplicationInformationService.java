package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;
import static org.springframework.http.HttpStatus.BAD_REQUEST;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.patent.ptab.common.opsg.domain.ApplicationIdentifierQuery;
import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to get application general information details
 *
 * @author 2020 development team
 *
 */
@Validated
@Component
@Slf4j
public class ApplicationInformationService {

    private static final String APPLICATION_INFO_DETAILS_URL = "APPLICATION_INFO_DETAILS_URL";
    private static final String SYSTEM_USER = "SYSTEM_USER";
    private static final String PTAB_CASE_INIT = "PTAB_CASE_INIT";
    private static final String PTACTS_EXTERNAL_URL = "PTACTS_EXTERNAL_URL";

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    /**
     * The method is used to retrieve application general information and set the details into ApplicationInfoResponse
     * object
     *
     * @param applicationIdentifierQuery - query parameters to get address details
     */
    @Transactional
    public JsonNode getApplicationInfoDetails(@Valid @NotNull ApplicationIdentifierQuery applicationIdentifierQuery) {

        final String applicationInfoDetailsUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTACTS_EXTERNAL_URL,
                APPLICATION_INFO_DETAILS_URL);
        notFoundIfNull(applicationInfoDetailsUrl, "Application details Url");
        final String url = externalServiceUriGenerator.applicationInfoUrl(applicationIdentifierQuery,
                applicationInfoDetailsUrl);
        final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(systemUserName, "system user name");
        log.info("calling common services for fetching application Information");
        ResponseEntity<String> response = null;
        try {
            response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, String.class,
                    systemUserName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        if (null != response && null != response.getBody()) {
            final ObjectMapper mapper = new ObjectMapper();
            try {
                return mapper.readTree(response.getBody());
            } catch (final JsonProcessingException e) {
                log.error(e.getMessage(), e);
                throw new PTABException(BAD_REQUEST,
                        new ErrorPayload("Exception  occurred while retriveing application information"));
            }
        }
        return null;
    }

}
