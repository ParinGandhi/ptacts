package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the PROCEEDING_COUNSEL_PARTY database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = "PROCEEDING_COUNSEL_PARTY")
@NamedQuery(name = "ProceedingCounselParty.findAll", query = "SELECT p FROM ProceedingCounselParty p")
public class ProceedingCounselParty implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "FK_PROCEEDING_PARTY_ID")
    private long fkProceedingPartyId;

    @Column(name = "CREATE_TS")
    private Date createTs;

    @Column(name = "CREATE_USER_ID")
    private BigDecimal createUserId;

    @Column(name = "FK_APPLICATION_USER_ID")
    private BigDecimal fkApplicationUserId;

    @Column(name = "FK_COUNSEL_TYPE_ID")
    private Long fkCounselTypeId;

    @Column(name = "LAST_MOD_TS")
    private Date lastModTs;

    @Column(name = "LAST_MOD_USER_ID")
    private BigDecimal lastModUserId;

    @Column(name = "LOCK_CONTROL_NO")
    private BigDecimal lockControlNo;

    @Column(name = "PRO_HAC_IN")
    private String proHacIn;

    @Column(name = "REGISTRATION_NO")
    private String registrationNo;

    @ManyToOne
    @JoinColumn(name = "FK_COUNSEL_TYPE_ID", insertable = false, updatable = false)
    private StndCounselType stndCounselType;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "FK_PROCEEDING_PARTY_ID")
    private ProceedingParty proceedingParty;

}