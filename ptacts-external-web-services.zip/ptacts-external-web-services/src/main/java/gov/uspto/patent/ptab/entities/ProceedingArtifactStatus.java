package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the PROCEEDING_ARTIFACT_STATUS database table.
 */
@Entity
@Table(name = "PROCEEDING_ARTIFACT_STATUS")
@NamedQuery(name = "ProceedingArtifactStatus.findAll", query = "SELECT p FROM ProceedingArtifactStatus p")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ProceedingArtifactStatus extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "PROCEEDING_ARTIFACT_STATUS_SEQ",
            sequenceName = "PROCEEDING_ARTIFACT_STATUS_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PROCEEDING_ARTIFACT_STATUS_SEQ")
    @Column(name = "PROCEEDING_ARTIFACT_STATUS_ID")
    private long proceedingArtifactStatusId;

    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    @Column(name = "STATUS_DT")
    private Timestamp statusDt;

    @Column(name = "FK_PROXY_SUBMITTER_ROLE_NM")
    private String fkProxySubmitterRoleNm;

    @Column(name = "FK_PROCEEDING_ARTIFACT_ID")
    private long fkProceedingArtifactId;

    @Column(name = "FK_SUBMISSION_STATUS_CD")
    private String fkSubmissionStatusCd;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "FK_PROCEEDING_ARTIFACT_ID", insertable = false, updatable = false)
    private ProceedingArtifact proceedingArtifact;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "FK_PROXY_SUBMITTER_ROLE_NM", insertable = false, updatable = false)
    private StndProxySubmitterRole stndProxySubmitterRole;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "FK_SUBMISSION_STATUS_CD", insertable = false, updatable = false)
    private StndSubmissionStatus stndSubmissionStatus;

}