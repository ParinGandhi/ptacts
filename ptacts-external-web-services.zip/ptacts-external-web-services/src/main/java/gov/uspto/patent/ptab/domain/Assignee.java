package gov.uspto.patent.ptab.domain;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import gov.uspto.patent.ptab.common.opsg.domain.Role;
import lombok.Getter;
import lombok.Setter;

/**
 * This class is used to store information about Assignee information
 * 
 * @author 2020 development team
 *
 */
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class Assignee {
    private String assigneeNumberText;
    private String assigneeFullNameText;
    private Integer activeCaseCount;
    private String assigneeStatus;
    private List<Role> userRoles;
    private String workerNumber;
    private BigDecimal rankId;
    private BigDecimal applicationUserId;
}
