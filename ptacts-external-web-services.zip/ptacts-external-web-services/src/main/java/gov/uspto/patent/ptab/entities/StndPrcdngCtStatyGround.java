package gov.uspto.patent.ptab.entities;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the STND_PRCDNG_CT_STATY_GROUND database table.
 * 
 */
@Entity
@Table(name = "STND_PRCDNG_CT_STATY_GROUND")
@NamedQuery(name = "StndPrcdngCtStatyGround.findAll", query = "SELECT s FROM StndPrcdngCtStatyGround s")
@Getter
@Setter
@RequiredArgsConstructor
public class StndPrcdngCtStatyGround extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private StndPrcdngCtStatyGroundId id;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "BEGIN_EFFECTIVE_DT")
    private Date beginEffectiveDt;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "END_EFFECTIVE_DT")
    private Date endEffectiveDt;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo = 1L;

    @ManyToOne
    @JoinColumn(name = "FK_PROCEEDING_TYPE_ID", insertable = false, updatable = false)
    private StndProceedingType stndProceedingType;

    @ManyToOne
    @JoinColumn(name = "FK_STATUTORY_GROUND_ID", insertable = false, updatable = false)
    private StndStatutoryGround stndStatutoryGround;

}