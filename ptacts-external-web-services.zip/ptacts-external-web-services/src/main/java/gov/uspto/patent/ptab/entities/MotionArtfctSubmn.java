package gov.uspto.patent.ptab.entities;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the MOTION_ARTFCT_SUBMN database table.
 * 
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "MOTION_ARTFCT_SUBMN")
@NamedQuery(name = "MotionArtfctSubmn.findAll", query = "SELECT m FROM MotionArtfctSubmn m")

public class MotionArtfctSubmn extends AbstractAuditEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MOTION_ARTFCT_SUBMN_SEQ")
    @SequenceGenerator(name = "MOTION_ARTFCT_SUBMN_SEQ", sequenceName = "MOTION_ARTFCT_SUBMN_SEQ", allocationSize = 1)
    @Column(name = "MOTION_ARTFCT_SUBMN_ID")
    private long motionArtfctSubmnId;

    @Column(name = "LOCK_CONTROL_NO")
    private static final Long LOCK_CONTROL_NO = 1L;

    @ManyToOne
    @JoinColumn(name = "FK_ARTIFACT_SUBMISSION_ID")
    private ArtifactSubmission artifactSubmission;

    @ManyToOne
    @JoinColumn(name = "FK_MOTION_ID")
    private Motion motion;

}
