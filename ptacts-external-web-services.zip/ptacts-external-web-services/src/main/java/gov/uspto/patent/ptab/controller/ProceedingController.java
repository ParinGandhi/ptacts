package gov.uspto.patent.ptab.controller;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;

import gov.uspto.patent.ptab.domain.Petition;
import gov.uspto.patent.ptab.domain.ProceedingQuery;
import gov.uspto.patent.ptab.service.ProceedingService;

@RestController
@RequestMapping("/proceeding")
@Validated
public class ProceedingController {

    @Autowired
    private ProceedingService proceedingService;

    @GetMapping(produces = "application/json")
    public JsonNode getProceeding(final ProceedingQuery proceedingQuery) {
        return proceedingService.getProceeding(proceedingQuery);
    }

    @GetMapping(value = "/basic-petition-details", produces = "application/json")
    public JsonNode getBasicProceedingAndPaymentDetails(final ProceedingQuery proceedingQuery) {
        return proceedingService.getBasicProceedingAndPaymentDetails(proceedingQuery);
    }

    @PostMapping(value = "/submitproceeding", produces = "application/json", consumes = "application/json")
    public void submitProceeding(@RequestBody @Valid final Petition petition) {
        proceedingService.submitProceeding(petition);
    }

}
