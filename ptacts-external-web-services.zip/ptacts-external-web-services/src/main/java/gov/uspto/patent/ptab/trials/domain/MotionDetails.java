package gov.uspto.patent.ptab.trials.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jakarta.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.uspto.patent.ptab.domain.Petition;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.domain.PtabCommonDomain;
import gov.uspto.patent.ptab.utils.MilliSecEpochDeserializer;
import gov.uspto.patent.ptab.utils.MilliSecEpochSeralizer;
import gov.uspto.patent.ptab.utils.PTABConstants;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class MotionDetails extends PtabCommonDomain {

    private Long motionId;

    @JsonSerialize(using = MilliSecEpochSeralizer.class)
    @JsonDeserialize(using = MilliSecEpochDeserializer.class)
    private Date submittedDate;
    @JsonSerialize(using = MilliSecEpochSeralizer.class)
    @JsonDeserialize(using = MilliSecEpochDeserializer.class)
    private Date motionStatusDate;
    private String motionType;
    private String motionFilingParty;
    @NotNull
    private String motionStatus;
    private String motionStatusDisplayName;
    private String submittedDateString;
    private List<PetitionDocument> motionDocuments;
    private Long motionStatusIdentifier;
    private String notificationRequiredIndicator;
    private String requestorType;
    private String proceedingNumber;
    private Long parentMotionId;

    @JsonIgnore
    private Petition petition;

    @JsonIgnore
    public Long getGroupByMotionId() {
        return parentMotionId == null ? motionId : parentMotionId;
    }

    public static MotionDetails mergePetitionDocuments(final MotionDetails first, final MotionDetails second) {
        List<PetitionDocument> firstMotionDocuments = first.getMotionDocuments();
        List<PetitionDocument> secondMotionDocuments = second.getMotionDocuments();
        if (firstMotionDocuments == null) {
            firstMotionDocuments = new ArrayList<>();
        }
        if (secondMotionDocuments == null) {
            secondMotionDocuments = new ArrayList<>();
        }
        final String secondMotionStatus = second.getMotionStatus();
        final String firstMotionStatus = first.getMotionStatus();
        final boolean secondAppendArtifacts = !secondMotionStatus.equalsIgnoreCase(PTABConstants.MOTION_INITIATED_STATUS);
        final boolean firstAppendArtifacts = !firstMotionStatus.equalsIgnoreCase(PTABConstants.MOTION_INITIATED_STATUS);
        if (first.getParentMotionId() == null) {
            if (secondAppendArtifacts) {
                firstMotionDocuments.addAll(secondMotionDocuments);
                first.setMotionDocuments(firstMotionDocuments);
                return first;
            } else {
                return first;
            }
        }
        if (second.getParentMotionId() == null) {
            if (firstAppendArtifacts) {
                secondMotionDocuments.addAll(firstMotionDocuments);
                second.setMotionDocuments(secondMotionDocuments);
                return second;
            } else {
                return second;
            }
        }
        if (first.getParentMotionId() != null && second.getParentMotionId() != null) {
            if (secondAppendArtifacts && firstAppendArtifacts) {
                firstMotionDocuments.addAll(secondMotionDocuments);
                first.setMotionDocuments(firstMotionDocuments);
                return first;
            }
            if (secondAppendArtifacts && !firstAppendArtifacts) {
                return second;
            }
            if (!secondAppendArtifacts && firstAppendArtifacts) {
                return first;
            }
        }
        return null;
    }
}