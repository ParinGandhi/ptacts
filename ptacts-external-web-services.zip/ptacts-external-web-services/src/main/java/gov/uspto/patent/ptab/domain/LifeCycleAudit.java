package gov.uspto.patent.ptab.domain;

import jakarta.validation.Valid;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.ToString;

/**
 * Class is used to provide the business audit information.
 * 
 * @author 2020 Development Team
 *
 */
@Data
@ToString
@JsonInclude(Include.NON_NULL)
public class LifeCycleAudit {
    @Valid
    private LifeCycle lifeCycle;

    @Valid
    private Audit audit;
}
