package gov.uspto.patent.ptab.service;

import static gov.uspto.patent.ptab.utils.PTABServiceUtils.notFoundIfNull;
import static gov.uspto.patent.ptab.utils.PTABServiceUtils.validateRequest;

import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.HttpClientErrorException;

import gov.uspto.patent.ptab.dao.CodeReferenceDao;
import gov.uspto.patent.ptab.domain.Petition;
import gov.uspto.patent.ptab.domain.PetitionBasicInformation;
import gov.uspto.patent.ptab.domain.PetitionQuery;
import gov.uspto.patent.ptab.entities.ExternalUser;
import gov.uspto.patent.ptab.repository.ExternalUserRepository;
import gov.uspto.patent.ptab.utils.ErrorPayload;
import gov.uspto.patent.ptab.utils.ExternalServiceUriGenerator;
import gov.uspto.patent.ptab.utils.PTABBusinessUtils;
import gov.uspto.patent.ptab.utils.PTABException;
import gov.uspto.patent.ptab.utils.RestServiceClient;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class PetitionService {

    private static final String SYSTEM_USER = "SYSTEM_USER";
    private static final String PTAB_CASE_INIT = "PTAB_CASE_INIT";
    public static final Integer PROCEEDINGID_PAD = 5;
    private static final String PTAB_COMMON_MAIN_URL = "PTAB_COMMON_MAIN_URL";
    private static final String PETITIONS_URL = "PETITIONS_URL";

    @Value("${petition.url}")
    private String petitionUrl;

    @Autowired
    private RestServiceClient restServiceClient;

    @Autowired
    private ExternalUserRepository externalUserRepository;

    @Autowired
    private CodeReferenceDao codeReferenceDao;

    @Autowired
    private ExternalServiceUriGenerator externalServiceUriGenerator;

    @Autowired
    private PTABBusinessUtils ptabBusinessUtils;

    @Transactional
    public PetitionBasicInformation createPetition(
            @RequestBody @NotNull final PetitionBasicInformation petitionBasicInformation) {
            final ExternalUser externalUser = externalUserRepository
                .findAllByEmail(ptabBusinessUtils.getLoggedInUserId());
            validateRequest(externalUser, "Invalid external user");

            petitionBasicInformation.setSubmitterEmailAddress(ptabBusinessUtils.getLoggedInUserId());
            final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
            notFoundIfNull(systemUserName, "system user name");
            final ResponseEntity<PetitionBasicInformation> response = restServiceClient.callPTABExternalServiceURL(petitionUrl,
            petitionBasicInformation, HttpMethod.POST, PetitionBasicInformation.class, systemUserName);
            PetitionBasicInformation updated = null;
            if (response.getStatusCode().is2xxSuccessful() && null != response.getBody()) {
            updated = response.getBody();
            }
            return updated;
    }

    @Transactional
    public Petition getPetitionDetails(final PetitionQuery petitionQuery) {
        ResponseEntity<Petition> response = null;
        final String externalArtifactGetUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTAB_COMMON_MAIN_URL,
                PETITIONS_URL);
        notFoundIfNull(externalArtifactGetUrl, PETITIONS_URL);
        final String url = externalServiceUriGenerator.getCommonPetitionsUrl(petitionQuery, externalArtifactGetUrl);
        final String systemUserName = codeReferenceDao.findDescriptionByTypeCodeAndValueTx(PTAB_CASE_INIT, SYSTEM_USER);
        notFoundIfNull(systemUserName, "system user name");
        try {
            response = restServiceClient.callPTABExternalServiceURL(url, null, HttpMethod.GET, Petition.class, systemUserName);
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null != response ? response.getBody() : null;
    }

    /**
     * This method is used to retrieve the petition details from proceeding
     * table based on petition number or identifier
     * 
     * @param petitionQuery - query object contains petition number or
     *            identifier
     */
    @Transactional
    public String deletePetitionDetails(final PetitionQuery petitionQuery) {
        final String petitionCommonServiceUrl = codeReferenceDao.getFirstDescCodeRefByTypeCdAndValue(PTAB_COMMON_MAIN_URL,
                PETITIONS_URL);
        notFoundIfNull(petitionCommonServiceUrl, PETITIONS_URL);
        final String userName = ptabBusinessUtils.getLoggedInUserId();
        try {
            final ResponseEntity<String> response = restServiceClient.invokeWebService(
                    petitionCommonServiceUrl + "?proceedingNumberText=" + petitionQuery.getProceedingNumberText(), null,
                    HttpMethod.DELETE, String.class, userName);
            if (response.getStatusCode().is2xxSuccessful()) {
                return "Successfully deleted the case details";
            } else if (response.getStatusCode().is4xxClientError()) {
                throw new PTABException(HttpStatus.BAD_REQUEST,
                        new ErrorPayload("Error ocuured while deleting the case details."));
            } else if (response.getStatusCode().is5xxServerError()) {
                throw new PTABException(HttpStatus.BAD_REQUEST,
                        new ErrorPayload("Internal server error ocuured while deleting the case details."));
            }
        } catch (final HttpClientErrorException ex) {
            log.error(ex.getMessage(), ex);
            throw new PTABException(ex.getStatusCode(), new ErrorPayload(ex.getLocalizedMessage()));
        }
        return null;
    }
}
