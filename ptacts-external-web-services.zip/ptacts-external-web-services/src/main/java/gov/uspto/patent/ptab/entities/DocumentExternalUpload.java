package gov.uspto.patent.ptab.entities;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the DOCUMENT_EXTERNAL_UPLOAD database table.
 */
@Entity
@Table(name = "DOCUMENT_EXTERNAL_UPLOAD")
@NamedQuery(name = "DocumentExternalUpload.findAll", query = "SELECT d FROM DocumentExternalUpload d")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DocumentExternalUpload extends AbstractAuditEntity {

    private static final long serialVersionUID = 5158460235702556873L;

    @Id
    @SequenceGenerator(name = "DOCUMENT_EXTERNAL_UPLOAD_SEQ", sequenceName = "DOCUMENT_EXTERNAL_UPLOAD_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOCUMENT_EXTERNAL_UPLOAD_SEQ")
    @Column(name = "DOCUMENT_EXTERNAL_UPLOAD_ID")
    private long documentExternalUploadId;

    @Column(name = "EXTERNAL_REPOSITORY_NM")
    private String externalRepoNm;

    @Column(name = "UPLOAD_STATUS_CT")
    private String uploadStatusNm;

    @Column(name = "LOCK_CONTROL_NO")
    private Long lockControlNo;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.DATE)
    @Column(name = "UPLOAD_DT")
    private Date uploadDt;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "FK_PROCEEDING_ARTIFACT_ID")
    private ProceedingArtifact proceedingArtifact;

}