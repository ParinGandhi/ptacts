package gov.uspto.patent.ptab.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import gov.uspto.patent.ptab.entities.ProceedingPartyGroup;

@Repository
public interface ProceedingPartyGroupRepository extends JpaRepository<ProceedingPartyGroup, Long> {

}
