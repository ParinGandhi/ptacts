package gov.uspto.patent.ptab.controller;

import java.util.List;
import java.util.Map;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.patent.ptab.domain.CaseDocumentsDataQuery;
import gov.uspto.patent.ptab.domain.Petition;
import gov.uspto.patent.ptab.domain.PetitionDocument;
import gov.uspto.patent.ptab.encrypt.RC4CipherEntity;
import gov.uspto.patent.ptab.service.ProceedingArtifactService;

@RestController
@RequestMapping("/proceeding-artifacts")
public class ProceedingArtifactController {

    public static final String APPLICATION_JSON_UTF8_VALUE = "application/json;charset=UTF-8";

    @Autowired
    private ProceedingArtifactService proceedingArtifactService;

    @GetMapping(value = "/sequences")
    public Map<String, String> getNextPaperSequenceIdentifier(
            @Valid @NotNull final CaseDocumentsDataQuery caseDocumentsDataQuery) {
        return proceedingArtifactService.getNextPaperSequenceIdentifier(caseDocumentsDataQuery);

    }

    @GetMapping(value = "/exhibit-sequences")
    public List<Long> getExhibtSequenceIdentifiers(@Valid @NotNull final CaseDocumentsDataQuery caseDocumentsDataQuery) {
        return proceedingArtifactService.getExhibitsByProceedingAndTypeId(caseDocumentsDataQuery);
    }

    @GetMapping(produces = APPLICATION_JSON_UTF8_VALUE)
    public List<PetitionDocument> getAllArtifacts(final CaseDocumentsDataQuery caseDocumentsDataQuery) {
        return proceedingArtifactService.getAllArtifacts(caseDocumentsDataQuery, false);

    }

    /**
     * This method is used to create proceeding artifact components
     *
     * @param petition - petition object
     */
    @PostMapping
    public Petition createProceedingArtifact(@RequestBody final Petition petition) {
        return proceedingArtifactService.createProceedingArtifact(petition);
    }

    /**
     * This method is used to retrieve all the artifact details
     *
     * @param caseDocumentsDataQuery - query object contains the proceeding number information
     */
    @GetMapping(value = "/initiate-petitions", produces = APPLICATION_JSON_UTF8_VALUE)
    public List<PetitionDocument> getInitiatePetitionArtifacts(final CaseDocumentsDataQuery caseDocumentsDataQuery) {
        return proceedingArtifactService.getInitiatePetitionArtifacts(caseDocumentsDataQuery);

    }

    @PutMapping(value = "/{artifactId}")
    public PetitionDocument updateProceedingArtifact(@RequestBody final PetitionDocument petitionDocument,
            @NotBlank @PathVariable("artifactId") final String artifactId) {
        String decryptedArtifactId = RC4CipherEntity.decrypt(artifactId);
        return proceedingArtifactService.updateProceedingArtifact(Long.valueOf(decryptedArtifactId), petitionDocument);
    }

    @PostMapping(value = "/external-documents")
    public Petition createProceedingArtifactForExternal(@RequestBody final Petition petition) {
        return proceedingArtifactService.createProceedingArtifactForExternal(petition);
    }

    @DeleteMapping(value = "/external-documents/{artifactId}")
    public void deleteProceedingArtifact(@NotBlank @PathVariable("artifactId") final String artifactId) {
        String decryptedArtifactId = RC4CipherEntity.decrypt(artifactId);
        proceedingArtifactService.deleteProceedingArtifact(Long.valueOf(decryptedArtifactId));
    }

    /**
     * This method is used to export as CSV for all the artifact details
     *
     * @param caseDocumentsDataQuery - query object contains the proceeding number information
     */
    @GetMapping(value = "/exportpaperexhibits-excel", produces = "application/x-msexcel")
    @ResponseBody
    public ResponseEntity<Resource> exportPaperAndExhibitsAsExcel(final CaseDocumentsDataQuery caseDocumentsDataQuery) {
        return proceedingArtifactService.exportPaperAndExhibitsAsExcel(caseDocumentsDataQuery);

    }

}
