package gov.uspto.patent.ptab.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AvailableFilter {

    private String code;
    private String description;

}
