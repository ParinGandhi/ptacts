package gov.uspto.patent.ptab.domain;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PtabStateRoleDisplayDetails {

    private String nameText;
    private String descriptionText;

}
