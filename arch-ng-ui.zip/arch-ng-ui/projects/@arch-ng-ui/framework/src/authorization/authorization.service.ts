import { CsrfService } from './csrf/csrf.service';
import { LogService } from './../log/log.service';
import { Inject, Injectable } from '@angular/core';
import { RestClient, Request } from '../rest-client/public-api';
import { CacheService } from '../cache/public-api';
import { DOCUMENT } from '@angular/common';
import { StateService } from '../state/state.service';
import { StateServiceDefaultKeys } from '../state/state-default-keys';
import { Router } from '@angular/router';
import { SessionService } from './session/session.service';
import { lastValueFrom } from 'rxjs';

/**
 * An authorization service is to be invoked in ensuring user
 * has proper permission to access a route.
 *
 * @author theanh.ha
 */
@Injectable({
  providedIn: 'root',
})
export class AuthorizationService {
  private window: Window | null;
  unauthorizedUrl: string = '/';

  constructor(
    @Inject('environment') private environment: any,
    @Inject('AppConfig') private AppConfig: any,
    @Inject(DOCUMENT) private document: Document,
    private restClient: RestClient,
    private logService: LogService,
    private stateService: StateService,
    private readonly router: Router,
    private csrfService: CsrfService,
    private readonly sessionService: SessionService
  ) {
    this.window = document.defaultView;
  }

  /**
   * call backend and compare passed component against user roles, and roles allowed to access component
   * the backend returns -
   *  {
        "isAuthorized": boolean,
        "userId": string
      }
   * @param  {string} componentName component or route to be authorized
   * @returns Promise boolean has access
   */
  authorize(componentName: string): Promise<boolean> {
    const endpoint = `${this.environment?.bffUri}/auth`;
    const payload = {
      component: componentName,
    };

    return lastValueFrom(
      this.restClient.post<any, any>(
        new Request<any>(
          payload,
          endpoint,
          undefined,
          this.addCSRFToHeaders(this.AppConfig.serviceHeaders)
        )
      )
    )
      .then((response: any) => {
        if (
          response &&
          response.body &&
          response.body.resultType === 'SUCCESS' &&
          response.body.result &&
          response.body.result.isAuthorized
        ) {
          this.stateService.setData(StateServiceDefaultKeys.USER_ID, response.body.result.userId);
          return true;
        }
        return false;
      })
      .catch((err: any) => {
        this.logService.error('Error requesting authorization: ', err, 'AuthorizationService', 83);
        return false;
      });
  }

  /**
   * logout signed in user
   */
  logout() {
    // clear all cache
    CacheService.getInstance().clearCache();
    // clear all data
    this.stateService.clearData();
    // clear user name from header
    // this.headerService.setUserName('');
    this.sessionService.clearLocalSession();
    this.clearCookies();

    if (
      this.environment?.oauthUri?.length &&
      this.environment?.logoutRedirectUri?.length &&
      this.environment?.logoutRedirectFromUri?.length
    ) {
      const rdUri = `${this.environment?.logoutRedirectUri}?fromURI=${this.environment?.logoutRedirectFromUri}`;
      const rdUriEncoded = encodeURIComponent(rdUri);
      const endpoint = `${this.environment?.oauthUri}?rd=${rdUriEncoded}`;
      // call signout at oauth proxy
      if (this.window) {
        this.window.location.href = endpoint;
      }
    } else {
      setTimeout(() => {
        this.sessionService.clearSession();
      }, 500);
    }
  }

  /**
   * clear all cookies for domain
   */
  private clearCookies() {
    const cookies = this.document.cookie.split(';');

    cookies.forEach((cookie) => {
      const eqPos = cookie.indexOf('=');
      const name = eqPos > -1 ? cookie.substring(0, eqPos) : cookie;
      this.document.cookie =
        name +
        '=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=' +
        this.window?.location.hostname;
    });
  }

  private clearCookie(name: string) {
    this.document.cookie =
      name +
      '=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=' +
      this.window?.location.hostname;
  }

  /**
   * Redirect Unauthorized
   */
  redirectUnauthorized() {
    this.router.navigateByUrl(this.unauthorizedUrl);
  }

  /**
   * add CSRF to headers
   */
  public addCSRFToHeaders(headers: any): Record<string, string | string[]> {
    let updatedHeaders = {
      ...headers,
      'X-Csrf-Token': this.csrfService.getCSRFToken(),
    };
    return updatedHeaders;
  }
}
