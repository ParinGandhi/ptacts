import { DOCUMENT } from '@angular/common';
import { Inject, Injectable } from '@angular/core';
import { RestClient } from '../../rest-client/rest-client';
import { Request } from '../../rest-client/request';
import { LogService } from '../../log/log.service';
import { StateServiceDefaultKeys } from '../../state/state-default-keys';
import { StateService } from '../../state/state.service';
import { lastValueFrom } from 'rxjs';

export interface Session {
  id: string;
  ttl: number;
  added: number;
}

/**
 * Service used to retrieve a session from browser and to request a new session
 */
@Injectable({
  providedIn: 'root',
})
export class SessionService {
  private session?: Session;
  private window: Window | null;

  constructor(
    @Inject('environment') private environment: any,
    @Inject('AppConfig') private AppConfig: any,
    @Inject(DOCUMENT) private document: Document,
    private restClient: RestClient,
    private readonly logService: LogService,
    private readonly stateService: StateService
  ) {
    this.window = document.defaultView;
  }

  checkSessionCookie(name: string): boolean {
    if (this.getActiveSession() || this.isSessionFlag()) {
      return true;
    }
    return false;
  }

  private getSessionCookie(): string | null {
    return this.getCookie('X-Session-Id');
  }

  private getCookie(name: string): string | null {
    let dc = this.document.cookie;
    let prefix = name + '=';
    let begin = dc.indexOf('; ' + prefix);
    let end;
    if (begin == -1) {
      begin = dc.indexOf(prefix);
      if (begin != 0) return null;
    } else {
      begin += 2;
      end = this.document.cookie.indexOf(';', begin);
      if (end == -1) {
        end = dc.length;
      }
    }
    return decodeURI(dc.substring(begin + prefix.length, end));
  }

  private setCookie(name: string, value: string, days?: number) {
    let expires = '';
    if (days) {
      let date = new Date();
      date.setDate(date.getDate() + days);
      expires = '; expires=' + date.toUTCString();
    } else {
      let date = new Date();
      date.setHours(date.getHours() + 8);
      expires = '; expires=' + date.toUTCString();
    }
    this.document.cookie = name + '=' + (value || '') + expires + '; path=/';
  }

  private clearCookie(name: string) {
    this.document.cookie =
      name +
      '=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=' +
      this.window?.location.hostname;
  }

  getNewSessionCookie(): Promise<boolean> {
    let bffUri = this.environment?.bffUri;
    let domainSplit = bffUri.split('/');
    let baseDomain;
    if (domainSplit.length > 1) {
      baseDomain = bffUri.split(domainSplit[domainSplit.length - 1])[0];
    } else {
      baseDomain = bffUri + '/';
    }

    const endpoint = `${baseDomain}session`;
    return lastValueFrom(
      this.restClient.get<any>(
        new Request<null>(null, endpoint, undefined, this.AppConfig.serviceHeaders)
      )
    )
      .then((response: any) => {
        if (
          response &&
          response.body &&
          response.body.resultType === 'SUCCESS' &&
          response.body.result &&
          response.body.result.session
        ) {
          this.storeSession(response.body);
          this.stateService.setData(
            StateServiceDefaultKeys.CSRF_TOKEN,
            response.body.result.csrfToken.value
          );
          this.setEncryptionKey(response.body.result.csrfToken.value);
          return true;
        }
        this.clearLocalSession();
        return false;
      })
      .catch((err: any) => {
        this.logService.error('Error requesting session: ', err, 'SessionService', 121);
        this.clearLocalSession();
        return false;
      });
  }

  clearLocalSession() {
    this.setCookie('SessionFlag', 'false');
    this.clearCookie('SessionFlag');
    this.session = undefined;
    localStorage.removeItem('its');
  }

  clearSession() {
    this.clearLocalSession();
    let bffUri = this.environment?.bffUri;
    const endpoint = `${bffUri}/logout`;
    if (this.window) {
      this.window.location.href = endpoint;
    }
  }

  private storeSession(res: any) {
    this.session = <Session>res.result.session;
    this.session.added = new Date().getTime();
    this.setCookie('SessionFlag', 'true');
  }

  private getActiveSession(): string | null {
    if (this.session?.id && this.session?.ttl) {
      let expiry = this.session.added + this.session.ttl * 1000;
      let now = new Date().getTime();
      if (now < expiry) {
        return this.session.id;
      }
    }
    return null;
  }

  private isSessionFlag(): boolean {
    if (this.getCookie('SessionFlag') && this.getCookie('SessionFlag') === 'true') {
      return true;
    }
    return false;
  }

  private setEncryptionKey(token: string): void {
    this.stateService.setData(
      StateServiceDefaultKeys.EK,
      new Date().getMonth() + token.replace(/-/g, '') + new Date().getFullYear()
    );
  }
}
