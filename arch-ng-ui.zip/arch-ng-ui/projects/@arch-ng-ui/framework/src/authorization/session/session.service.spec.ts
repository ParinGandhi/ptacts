import { expect, test, describe, vi, beforeEach } from 'vitest';
import 'zone.js/testing';
import { TestBed } from '@angular/core/testing';
import { SessionService } from './session.service';
import { StateService } from '../../state/state.service';

describe('SessionService', () => {
  let service: SessionService;

  let envMock = {
    production: false,
    debug: false,
    bffUri: 'http://localhost:9999/api',
    oauthUri: '',
    logoutRedirectUri: '',
    logoutRedirectFromUri: '',
  };

  let appConfigMock = {
    serviceHeaders: {
      'role-id': 'pm',
      'source-system-name': 'FFM_PM',
      'user-id': 'testUser',
    },
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: 'environment', useValue: envMock },
        { provide: 'AppConfig', useValue: appConfigMock },
        StateService,
      ],
    });
    service = TestBed.inject(SessionService);
  });

  test('should be created', () => {
    expect(service).toBeTruthy();
  });
});
