import { expect, test, describe, vi } from 'vitest';
import { StateService } from '../state/state.service';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBed } from '@angular/core/testing';
import { AuthorizationService } from './authorization.service';
import { RestClient, Response } from '../rest-client/public-api';

describe('AuthorizationService', () => {
  let service: AuthorizationService;
  let stateService: StateService;

  let envMock = {
    production: false,
    debug: false,
    bffUri: 'http://localhost:9999/api',
    oauthUri: '',
    logoutRedirectUri: '',
    logoutRedirectFromUri: '',
  };

  let appConfigMock = {
    serviceHeaders: {
      'role-id': 'pm',
      'source-system-name': 'FFM_PM',
      'user-id': 'testUser',
    },
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        { provide: 'environment', useValue: envMock },
        { provide: 'AppConfig', useValue: appConfigMock },
      ],
    });
    service = TestBed.inject(AuthorizationService);
    stateService = TestBed.inject(StateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should authorize', (done) => {
    let postSpy = spyOn(Post.prototype, 'execute').and.returnValue(
      new Promise((resolve) => {
        resolve(
          new Response({}, 200, 'Ok', {}, {}).withBody({
            resultType: 'SUCCESS',
            result: {
              isAuthorized: true,
              userId: 'test001',
            },
          })
        );
      })
    );
    service.authorize('sample').then((result: any) => {
      expect(postSpy).toHaveBeenCalled();
      expect(result).toBeTrue();
      done();
    });
  });

  it('should not authorize', (done) => {
    let postSpy = spyOn(Post.prototype, 'execute').and.returnValue(
      new Promise((resolve) => {
        resolve(
          new Response({}, 200, 'Ok', {}, {}).withBody({
            resultType: 'SUCCESS',
            result: {
              isAuthorized: false,
              userId: 'test001',
            },
          })
        );
      })
    );
    service.authorize('sample3').then((result: any) => {
      expect(postSpy).toHaveBeenCalled();
      expect(result).toBeFalse();
      done();
    });
  });
});
