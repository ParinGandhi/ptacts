import { expect, test, describe, vi } from 'vitest';
import { SessionService } from './session/session.service';
import { AuthorizationService } from './authorization.service';
import { TestBed } from '@angular/core/testing';
import { ComponentGuard } from './component-guard.service';
import { RouterTestingModule } from '@angular/router/testing';
import { Injectable } from '@angular/core';
import { RouterStateSnapshot, UrlSegment, ActivatedRoute } from '@angular/router';
import { RestClient, Response } from '../rest-client/public-api';
import { CsrfService } from './csrf/csrf.service';

@Injectable()
class AuthorizationServiceMock extends AuthorizationService {
  authorize(componentName: string): Promise<boolean> {
    return Promise.resolve(true);
  }
}

let envMock = {
  production: false,
  debug: false,
  bffUri: 'http://localhost:9999/api',
};

let appConfigMock = {
  serviceHeaders: {
    'role-id': 'pm',
    'source-system-name': 'FFM_PM',
    'user-id': 'testUser',
  },
};

describe('ComponentGuardService', () => {
  let service: ComponentGuard;
  let activatedRouteSpy: any;
  let routerStateSpy: any;
  let routeSpy: any;

  beforeEach(async () => {
    activatedRouteSpy = {
      url: [new UrlSegment('/', {})],
      data: {
        componentName: 'SampleComponent',
      },
    };
    routerStateSpy = {};
    routeSpy = {
      data: {
        componentName: 'SampleComponent',
      },
    };

    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        { provide: AuthorizationService, useClass: AuthorizationServiceMock },
        { provide: ActivatedRoute, useValue: activatedRouteSpy },
        { provide: RouterStateSnapshot, useValue: routerStateSpy },
        { provide: 'environment', useValue: envMock },
        { provide: 'AppConfig', useValue: appConfigMock },
      ],
    });
    service = TestBed.inject(ComponentGuard);

    let getSpy = spyOn(Get.prototype, 'execute').and.returnValue(
      new Promise((resolve) => {
        resolve(
          new Response({}, 200, 'Ok', {}, {}).withBody({
            resultType: 'SUCCESS',
            result: {
              csrfToken: {
                value: 'sample-token',
              },
            },
          })
        );
      })
    );

    let sessionSpy = spyOn(SessionService.prototype, 'checkSessionCookie').and.returnValue(true);
    let csrfSpy = spyOn(CsrfService.prototype, 'checkCSRF').and.returnValue(true);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('canActivate should be true', async () => {
    expect(await service.canActivate(activatedRouteSpy, routerStateSpy)).toBe(true);
  });

  it('canMatch should be true', async () => {
    expect(await service.canMatch(routeSpy, [])).toBe(true);
  });
});
