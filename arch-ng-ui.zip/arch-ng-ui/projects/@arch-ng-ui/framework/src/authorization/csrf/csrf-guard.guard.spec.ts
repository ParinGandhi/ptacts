import { expect, test, describe, vi, beforeEach } from 'vitest';
import 'zone.js/testing';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CsrfGuard } from './csrf-guard.guard';
import { SessionService } from '../session/session.service';
import { AuthorizationService } from '../authorization.service';
import { CsrfService } from './csrf.service';

describe('CsrfGuardGuard', () => {
  let guard: CsrfGuard;
  vi.mock('../session/');

  let envMock = {
    production: false,
    debug: false,
    bffUri: 'http://localhost:9999/api',
    oauthUri: '',
    logoutRedirectUri: '',
    logoutRedirectFromUri: '',
  };

  let appConfigMock = {
    serviceHeaders: {
      'role-id': 'pm',
      'source-system-name': 'FFM_PM',
      'user-id': 'testUser',
    },
  };

  beforeEach(() => {
    guard = new CsrfGuard(
      SessionService.prototype,
      CsrfService.prototype,
      AuthorizationService.prototype
    );
  });

  test('should be created', () => {
    expect(guard).toBeTruthy();
  });

  test('CanActivate invalid session cookie', () => {});
  test('CanActivate invalid session cookie - error getting new session', () => {});
  test('CanActivate invalid session cookie - ', () => {});
});
