import { expect, test, describe, vi, beforeEach, afterEach } from 'vitest';
import 'zone.js';
import 'zone.js/testing';
import { CsrfService } from './csrf.service';
import { RestClient, Response } from '../../rest-client/public-api';
import { LogService } from '../../log/public-api';
import { StateService } from '../../state/public-api';
import { BehaviorSubject, of } from 'rxjs';

// setup mocks
vi.mock('../../rest-client/public-api');
vi.mock('../../log/public-api');
vi.mock('../../state/public-api');

describe('CsrfService', () => {
  let service: CsrfService;
  let restClient: RestClient;
  let stateService: StateService;
  let logService: LogService;

  let envMock = {
    production: false,
    debug: false,
    bffUri: 'http://localhost:9999/api',
    oauthUri: '',
    logoutRedirectUri: '',
    logoutRedirectFromUri: '',
  };

  let appConfigMock = {
    serviceHeaders: {
      'role-id': 'pm',
      'source-system-name': 'FFM_PM',
      'user-id': 'testUser',
    },
  };

  beforeEach(() => {
    restClient = RestClient.prototype;
    logService = LogService.prototype;
    stateService = StateService.prototype;
    service = new CsrfService(envMock, appConfigMock, restClient, logService, stateService);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  test('should be created', () => {
    expect(service).toBeTruthy();
  });

  test('csrf token should not exist', () => {
    stateService.dataSubject = new BehaviorSubject('');
    expect(service.checkCSRF()).toBe(false);
  });

  test('csrf should be sample-token', () => {
    vi.spyOn(restClient, 'get').mockReturnValue(
      of(
        new Response<any>(
          200,
          'Ok',
          {},
          {
            resultType: 'SUCCESS',
            result: {
              csrfToken: {
                value: 'sample-token',
              },
            },
          }
        )
      )
    );
    stateService.dataSubject = new BehaviorSubject('');
    service.getNewCSRFToken().then(() => {
      expect(service.checkCSRF()).toBe(true);
      expect(service.getCSRFToken()).toEqual('sample-token');
    });
  });
});
