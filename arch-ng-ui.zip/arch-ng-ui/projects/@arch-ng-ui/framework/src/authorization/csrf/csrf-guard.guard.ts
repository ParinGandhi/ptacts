import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { CsrfService } from './csrf.service';
import { Observable } from 'rxjs';
import { SessionService } from '../session/session.service';
import { AuthorizationService } from '../authorization.service';

@Injectable({
  providedIn: 'root',
})
export class CsrfGuard {
  constructor(
    private readonly sessionService: SessionService,
    private readonly csrfService: CsrfService,
    private readonly authService: AuthorizationService
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if (this.sessionService.checkSessionCookie('X-Session-Id')) {
      if (this.csrfService.checkCSRF()) {
        return true;
      } else {
        // Get new CSRF token
        return this.csrfService
          .getNewCSRFToken()
          .then((result) => {
            return true;
          })
          .catch((err) => {
            // Error getting CSRF token
            this.authService.logout();
            return false;
          });
      }
    } else {
      // Get new Session cookie
      return this.sessionService
        .getNewSessionCookie()
        .then((result) => {
          if (result) {
            return true;
          } else {
            // Error getting Session cookie
            this.authService.logout();
            return false;
          }
        })
        .catch((err) => {
          // Error getting Session cookie
          this.authService.logout();
          return false;
        });
    }
  }
}
