import { Inject, Injectable } from '@angular/core';
import { StateService, StateServiceDefaultKeys } from '../../state/public-api';
import { Request, RestClient } from '../../rest-client/public-api';
import { LogService } from '../../log/public-api';
import { lastValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CsrfService {
  constructor(
    @Inject('environment') private environment: any,
    @Inject('AppConfig') private AppConfig: any,
    private restClient: RestClient,
    private readonly logService: LogService,
    private readonly stateService: StateService
  ) {}

  checkCSRF(): boolean {
    if (this.getCSRFToken()) {
      return true;
    }
    return false;
  }

  getCSRFToken(): string | null {
    return this.stateService.dataSubject.value[StateServiceDefaultKeys.CSRF_TOKEN];
  }

  getNewCSRFToken(): Promise<string> {
    let bffUri = this.environment?.bffUri;
    let domainSplit = bffUri.split('/');
    let baseDomain;
    if (domainSplit.length > 1) {
      baseDomain = bffUri.split(domainSplit[domainSplit.length - 1])[0];
    } else {
      baseDomain = bffUri + '/';
    }

    const endpoint = `${baseDomain}csrf`;

    return lastValueFrom(
      this.restClient.get<any>(
        new Request<null>(null, endpoint, undefined, this.AppConfig.serviceHeaders)
      )
    )
      .then((response: any) => {
        response;
        response.body;
        if (
          response &&
          response.body &&
          response.body.resultType === 'SUCCESS' &&
          response.body.result &&
          response.body.result.csrfToken &&
          response.body.result.csrfToken.value
        ) {
          this.stateService.setData(
            StateServiceDefaultKeys.CSRF_TOKEN,
            response.body.result.csrfToken.value
          );
          this.setEncryptionKey(response.body.result.csrfToken.value);
          return response.body.result.csrfToken.value;
        }
        return undefined;
      })
      .catch((err: any) => {
        this.logService.error('Error requesting csrf token: ', err, 'CsrfService', 58);
        return undefined;
      });
  }

  private setEncryptionKey(token: string): void {
    this.stateService.setData(
      StateServiceDefaultKeys.EK,
      new Date().getMonth() + token.replace(/-/g, '') + new Date().getFullYear()
    );
  }
}
