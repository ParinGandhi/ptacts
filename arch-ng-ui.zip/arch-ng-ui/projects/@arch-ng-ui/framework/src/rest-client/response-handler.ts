import { HttpResponse } from '@angular/common/http';
import { Response } from './response';

//todo: change this to a proper interceptor once angular is properly integrated
export function handleResponse<Body>(httpResponse: HttpResponse<Body>): Response<Body | null> {
  const headers: Record<string, string[]> = {};
  httpResponse.headers.keys().forEach((element) => {
    headers[element] = httpResponse.headers.getAll(element) ?? [];
  });

  if (httpResponse.status >= 200 && httpResponse.status < 300) {
    return new Response(httpResponse.status, httpResponse.statusText, headers, httpResponse.body);
  } else if (httpResponse.status == 301 || httpResponse.status == 302) {
    return new Response(httpResponse.status, httpResponse.statusText, headers, httpResponse.body);
  } else {
    //todo: refactor this once angular is integrated properly
    throw new Error(
      `HTTP call finished with error: status[${httpResponse.status}] and body[${httpResponse.body}]`
    );
  }
}
