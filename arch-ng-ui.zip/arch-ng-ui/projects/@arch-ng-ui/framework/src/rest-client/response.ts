/**
 * A standard REST response
 */
export class Response<Body> {
  constructor(
    public readonly status: number,
    public readonly statusText: string,
    public readonly headers: Record<string, string[]>,
    public readonly body?: Body
  ) {}

  /**
   * Map this Response to another type
   * @param f
   */
  map<U>(f: (value: Response<Body>) => U): U {
    return f(this);
  }
}
