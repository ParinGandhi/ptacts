import { HttpHeaders } from '@angular/common/http';
import { v7 } from 'uuid';

/**
 * A standard REST request
 */
export class Request<Body> {
  private readonly DEFAULT_HEADERS: Record<string, string | string[]> = {
    'x-correlation-id': v7(),
  }; // todo: determine the rest of the values that should be here

  constructor(
    readonly body: Body,
    readonly baseURL: string,
    readonly queryParams: Record<string, string> | undefined,
    readonly headers: Record<string, string | string[]> | undefined
  ) {}

  buildHeaders(): HttpHeaders {
    let mergedHeaders = this.DEFAULT_HEADERS;
    const headers: Record<string, string | string[]> = this.headers ?? {};
    if (Object.getOwnPropertyNames(headers).length > 0) {
      for (const key of Object.getOwnPropertyNames(headers)) {
        mergedHeaders[key] = headers[key];
      }
    }
    return new HttpHeaders(mergedHeaders);
  }

  buildUrl(): string {
    let url = this.baseURL;
    const params: Record<string, string> = this.queryParams ?? {};
    const propNames: string[] = Object.getOwnPropertyNames(params ?? {});
    if (propNames.length > 0) {
      url += '?';
      for (const prop of Object.getOwnPropertyNames(params)) {
        url += prop + '=' + params[prop as string] + '&';
      }
      url = url.slice(0, -1); // remove the extra ampersand
    }
    return url;
  }

  /**
   * Copy constructor to allow creating a new request with the same type of body
   * @returns new Request
   */
  copy(
    body?: Body,
    baseURL?: string,
    queryParams?: Record<string, string>,
    headers?: Record<string, string | string[]>
  ): Request<Body> {
    return new Request<Body>(
      body ?? this.body,
      baseURL ?? this.baseURL,
      queryParams ?? this.queryParams,
      headers ?? this.headers
    );
  }
}
