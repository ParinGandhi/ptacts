import { expect, test, describe, vi } from 'vitest';
import { Request } from './request';

const nil_uuid = '00000000-0000-0000-0000-000000000000';
vi.mock('uuid', () => ({
  v7: () => nil_uuid,
}));

describe('Constructor ', () => {
  test('returns valid request instance when all parameters provided', () => {
    const body = {};
    const url = 'https://www.example.com';
    const queryParams = { test: 'value' };
    const headers = {
      fake: 'fake',
      'fake-arr': ['test', 'test2'],
    };
    const actual = new Request<unknown>(body, url, queryParams, headers);
    expect(actual).toBeTruthy();
    expect(actual.body).toBe(body);
    expect(actual.baseURL).toBe(url);
    expect(actual.queryParams).toBe(queryParams);
    expect(actual.headers).toBe(headers);
  });
  test('returns valid request instance when no query parameters are provided', () => {
    const body = {};
    const url = 'https://www.example.com';
    const queryParams = undefined;
    const headers = {
      fake: 'fake',
      'fake-arr': ['test', 'test2'],
    };
    const actual = new Request<unknown>(body, url, queryParams, headers);
    expect(actual).toBeTruthy();
    expect(actual.body).toBe(body);
    expect(actual.baseURL).toBe(url);
    expect(actual.queryParams).toBe(queryParams);
    expect(actual.headers).toBe(headers);
  });
  test('returns valid request instance when no headers are provided', () => {
    const body = {};
    const url = 'https://www.example.com';
    const queryParams = { test: 'value' };
    const headers = undefined;
    const actual = new Request<unknown>(body, url, queryParams, headers);
    expect(actual).toBeTruthy();
    expect(actual.body).toBe(body);
    expect(actual.baseURL).toBe(url);
    expect(actual.queryParams).toBe(queryParams);
    expect(actual.headers).toBe(headers);
  });
});

describe('buildHeaders() ', () => {
  test('returns correct headers when no custom headers are provided', () => {
    const body = {};
    const url = 'https://www.example.com';
    const queryParams = { test: 'value' };
    const headers = undefined;
    const newHeaders = { 'x-correlation-id': nil_uuid };
    const actual = new Request<unknown>(body, url, queryParams, headers).buildHeaders();
    expect(actual.keys()).toHaveLength(1);
    expect(actual.getAll('x-correlation-id')).toEqual([nil_uuid]);
  });
  test('returns correct headers when custom headers are provided', () => {
    const body = {};
    const url = 'https://www.example.com';
    const queryParams = { test: 'value' };
    const headers = { test: 'test' };
    const newHeaders = { 'x-correlation-id': nil_uuid, test: 'test' };
    const actual = new Request<unknown>(body, url, queryParams, headers).buildHeaders();
    expect(actual.keys()).toHaveLength(2);
    expect(actual.getAll('x-correlation-id')).toEqual([nil_uuid]);
    expect(actual.getAll('test')).toEqual(['test']);
  });
});

describe('buildUrl()', () => {
  test('buildUrl returns url in correct format', () => {
    const body = {};
    const url = 'https://www.example.com';
    const queryParams = { test: 'value', test2: 'value2' };
    const headers = undefined;
    const actual = new Request<unknown>(body, url, queryParams, headers).buildUrl();
    expect(actual).toEqual('https://www.example.com?test=value&test2=value2');
  });
  test('buildUrl returns url in correct format when no queryParams', () => {
    const body = {};
    const url = 'https://www.example.com';
    const queryParams = undefined;
    const headers = undefined;
    const actual = new Request<unknown>(body, url, queryParams, headers).buildUrl();
    expect(actual).toEqual(url);
  });
});

describe('Copy()', () => {
  test('copy constructor returns clone of request when no params passed', () => {
    const body = {};
    const url = 'https://www.example.com';
    const queryParams = { test: 'value' };
    const headers = undefined;
    const request = new Request<unknown>(body, url, queryParams, headers);
    const actual = request.copy();
    expect(actual).not.toBe(request);
    expect(actual).toEqual(request);
  });
  test('copy constructor returns clone of request with new body', () => {
    const body = {};
    const newBody = { test: 'prop' };
    const url = 'https://www.example.com';
    const queryParams = { test: 'value' };
    const headers = undefined;
    const request = new Request<unknown>(body, url, queryParams, headers);
    const actual = request.copy(newBody);
    expect(actual).not.toBe(request);
    expect(actual.body).toEqual(newBody);
    expect(actual.baseURL).toEqual(request.baseURL);
  });
  test('copy constructor returns clone of request with new headers', () => {
    const body = {};
    const url = 'https://www.example.com';
    const queryParams = { test: 'value' };
    const headers = undefined;
    const newHeaders = { test: 'prop' };
    const request = new Request<unknown>(body, url, queryParams, headers);
    const actual = request.copy(undefined, undefined, undefined, newHeaders);
    expect(actual).not.toBe(request);
    expect(actual.headers).toEqual(newHeaders);
    expect(actual.body).toEqual(request.body);
  });
});
