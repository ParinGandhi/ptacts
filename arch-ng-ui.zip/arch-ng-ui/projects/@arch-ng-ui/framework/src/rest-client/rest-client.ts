import { HttpClient, provideHttpClient } from '@angular/common/http';
import { Injectable, Inject } from '@angular/core';
import { Request } from './request';
import { Response } from './response';
import { handleResponse } from './response-handler';
import { Observable, map } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RestClient {
  // make sure http client is available by default
  static {
    provideHttpClient()
  }
  constructor(
    @Inject(HttpClient) private readonly client: HttpClient
  ) {}

  public put<request, response>(request: Request<request>): Observable<Response<response | null>> {
    return this.client
      .put<response>(request.buildUrl(), request.body, {
        headers: request.buildHeaders(),
        observe: 'response',
        withCredentials: true,
      })
      .pipe(map(handleResponse));
  }

  public get<response>(request: Request<null>): Observable<Response<response | null>> {
    return this.client
      .get<response>(request.buildUrl(), {
        headers: request.buildHeaders(),
        observe: 'response',
        withCredentials: true,
      })
      .pipe(map(handleResponse));
  }

  public post<request, response>(request: Request<request>): Observable<Response<response | null>> {
    return this.client
      .post<response>(request.buildUrl(), request.body, {
        headers: request.buildHeaders(),
        observe: 'response',
        withCredentials: true,
      })
      .pipe(map(handleResponse));
  }

  public delete<response>(request: Request<null>): Observable<Response<response | null>> {
    return this.client
      .delete<response>(request.buildUrl(), {
        headers: request.buildHeaders(),
        observe: 'response',
        withCredentials: true,
      })
      .pipe(map(handleResponse));
  }
}
