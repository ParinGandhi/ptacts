import { LogService } from '../log/log.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ErrorHandler, Injectable, NgZone } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ErrorHandlerService implements ErrorHandler {
  constructor(
    private logService: LogService,
    // private headerService: HeaderService,
    private zone: NgZone
  ) {}

  handleError(error: any) {
    if (!(error instanceof HttpErrorResponse) && error.rejection) {
      error = error.rejection;
    }
    this.zone.run(() => {
      this.logService.error(error?.message, error?.name, error?.status, 'ErrorHandlerService', 16);
      console.error(error);
      console.error(error.stack);
      // this.headerService.addAlert(error?.message ? error?.message : 'Undefined client error', undefined, 'error');
    });
  }
}
