import { expect, test, describe, vi } from 'vitest';
import { TestBed } from '@angular/core/testing';
import { LogService } from './log.service';

describe('LogService', () => {
  let service: LogService;

  let envMock = {
    production: true,
    debug: false,
    logLevel: 0,
    logWithDate: true,
    logRemote: false,
    logUri: '',
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [{ provide: 'environment', useValue: envMock }],
    }).compileComponents();
    service = TestBed.inject(LogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
