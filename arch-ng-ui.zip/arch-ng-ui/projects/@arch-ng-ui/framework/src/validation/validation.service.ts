import { Injectable } from '@angular/core';
import { UntypedFormGroup, AbstractControl } from '@angular/forms';

@Injectable({
  providedIn: 'root',
})
export class ValidationService {
  constructor() {
    // This is intentional
  }

  public regex = {
    email: '^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$',
    pin: '^[0-9]{6}$',
  };

  matchItems(controlName: string, secondControlName: string) {
    return (controls: AbstractControl) => {
      const control = controls.get(controlName);
      const secondControl = controls.get(secondControlName);

      if (!control || !secondControl) {
        return null;
      }
      if (secondControl.errors && !secondControl.errors['mismatch']) {
        return null;
      }
      if (control.value !== secondControl.value) {
        return secondControl.setErrors({ mismatch: true });
      } else {
        return;
      }
    };
  }

  allChecked(controlNames: string[]) {
    return (controls: AbstractControl) => {
      var result = true;
      controlNames.forEach((name) => {
        if (controls.get(name)?.value !== true) {
          result = false;
        }
      });

      const control = controls.get(controlNames[0]);
      if (!result) {
        return control!.setErrors({ notAllChecked: true });
      } else {
        return;
      }
    };
  }

  requireCheckboxesToBeChecked(minRequired: number = 1) {
    return (formGroup: UntypedFormGroup) => {
      let checked = 0;

      Object.keys(formGroup.controls).forEach((key) => {
        const control = formGroup.controls[key];
        if (control.value === true) {
          checked++;
        }
      });

      if (checked < minRequired) {
        return { notAllChecked: true };
      }
      return null;
    };
  }

  isAValidDate() {
    return (formGroup: UntypedFormGroup) => {
      var month = '';
      var day = '';
      var year = '';
      Object.keys(formGroup.controls).forEach((key) => {
        const control = formGroup.controls[key];
        if ([key].indexOf('Month') > -1) {
          month = control.value;
        } else if ([key].indexOf('Day') > -1) {
          day = control.value;
        } else if ([key].indexOf('Year') > -1) {
          year = control.value;
        }
      });
      const newDate = new Date(parseInt(year), parseInt(month), parseInt(day));
      if (newDate instanceof Date && !isNaN(newDate.getTime())) {
        return null;
      } else {
        return { notValidDate: true };
      }
    };
  }

  getValidationErrors(group: UntypedFormGroup, validationMessages: Record<string, any>): any {
    var formErrors: Record<string, any> = {};

    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);

      formErrors[key] = '';
      if (
        abstractControl &&
        !abstractControl.valid &&
        (abstractControl.touched || abstractControl.dirty)
      ) {
        const messages = validationMessages[key];
        for (const errorKey in abstractControl.errors) {
          if (errorKey) {
            formErrors[key] += messages[errorKey] + ' ';
          }
        }
      }

      if (abstractControl instanceof UntypedFormGroup) {
        let groupError = this.getValidationErrors(abstractControl, validationMessages);
        formErrors = { ...formErrors, ...groupError };
      }
    });
    return formErrors;
  }
}

// interface / type to declare error Array
type ValidationErrors = {
  [key: string]: any;
};
