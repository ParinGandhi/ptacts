import { CacheService } from './cache-service';
import { CacheStorageType } from './cache-storage-type';

interface ICacheOptions {
  storageType: CacheStorageType;
  ttl: number;
  domain: string;
  encryption?: boolean;
}

type CacheMethod = (...args: any[]) => any;
/**
 * Cacheable decorater which enables caching for a function
 * @param  {(this:T)=>ICacheOptions} optionsHandler
 * Options available: storageType: Session or Local, ttl: time to live in seconds,
 * domain: grouping of cached items, encryption: to encrypt or not
 */
export function Cacheable<T extends Record<string, any>>(
  optionsHandler: (this: T) => ICacheOptions
) {
  return (
    target: T,
    methodName: string,
    descriptor: TypedPropertyDescriptor<CacheMethod>
  ): TypedPropertyDescriptor<CacheMethod> => {
    const cacheKeyPrefix = `${target.constructor.name}_${methodName}`;
    const originalMethod = descriptor.value;

    descriptor.value = function (...args: any[]): any {
      const cache: CacheService = CacheService.getInstance();
      const { storageType, ttl, domain, encryption = false } = optionsHandler.call(this as any);
      const key = `${cacheKeyPrefix}_${JSON.stringify(args)}`;
      return cache.getItem(key, storageType, domain, encryption).then((cachedResult) => {
        if (cachedResult) {
          return cachedResult;
        }

        let methodResult = originalMethod?.apply(this, args);

        cache.setItem(key, methodResult, storageType, ttl, domain, encryption);

        return methodResult;
      });
    };
    return descriptor;
  };
}
