export enum CacheStorageType {
  Local,
  Session,
}
