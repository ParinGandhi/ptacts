import { localit as store } from 'localit';
import { CacheStorageType } from './cache-storage-type';
import { lastValueFrom, Observable, of } from 'rxjs';

export class CacheService {
  private static instance: CacheService;

  private readonly keySize = 256;
  private readonly iterations = 100;
  private encryptionKey: Uint8Array;
  private iv: Uint8Array;
  private salt: Uint8Array;
  private formedEncryptionKey?: CryptoKey;

  private readonly typeMap = new Map<string, string>();

  constructor() {
    this.encryptionKey = window.crypto.getRandomValues(new Uint8Array(16));
    this.iv = window.crypto.getRandomValues(new Uint8Array(16));
    this.salt = window.crypto.getRandomValues(new Uint8Array(16));
  }

  public static getInstance(): CacheService {
    if (!CacheService.instance) {
      CacheService.instance = new CacheService();
    }

    return CacheService.instance;
  }
  /**
   * returns new encryption key
   * @returns Promise<CryptoKey>
   */
  private createEncryptionKey = async (): Promise<CryptoKey> => {
    if (this.formedEncryptionKey) {
      return this.formedEncryptionKey;
    }
    let derivedKey = await window.crypto.subtle.importKey(
      'raw',
      this.encryptionKey,
      {
        name: 'PBKDF2',
      },
      false,
      ['deriveKey', 'deriveBits']
    );
    this.formedEncryptionKey = await window.crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        hash: 'SHA-256',
        salt: this.salt,
        iterations: this.iterations,
      },
      derivedKey,
      { name: 'AES-GCM', length: this.keySize },
      false,
      ['encrypt', 'decrypt']
    );
    return this.formedEncryptionKey;
  };
  /**
   * Store data in cache
   * @param  {string} key cache key
   * @param  {any} item data to be cached
   * @param  {CacheStorageType} storageType Session or Local
   * @param  {number} ttl time to live in seconds
   * @param  {string} domain grouping of cached items
   * @param  {boolean} encryption to encrypt flag
   * @returns Promise
   */
  async setItem(
    key: string,
    item: any,
    storageType: CacheStorageType,
    ttl: number,
    domain: string,
    encryption: boolean
  ): Promise<void> {
    if (encryption == true && storageType != CacheStorageType.Session) {
      throw Error(`Storage encryption is only available to sessionStorage`);
    }

    this.setStorageType(storageType);
    this.setDomain(domain);

    let itemType: string = typeof item;
    if (itemType == 'object') {
      [item, itemType] = await this.handleObjectType(item);
    }

    if (itemType == 'reject') return;

    this.setItemType(key, itemType, domain);
    let convertedTime: string = this.convertTime(ttl);

    if (storageType == CacheStorageType.Session && encryption == true) {
      [key, item] = await this.encryptKeyValue(key, JSON.stringify(item));
    }

    store.set(key, JSON.stringify(item), convertedTime);
  }
  /**
   * Retrive data from cache
   * @param  {string} key cache key
   * @param  {CacheStorageType} storageType Session or Local
   * @param  {string} domain grouping of cached items
   * @param  {boolean} encryption is data encrypted
   * @returns any
   */
  async getItem(
    key: string,
    storageType: CacheStorageType,
    domain: string,
    encryption: boolean
  ): Promise<any | undefined> {
    if (encryption == true && storageType != CacheStorageType.Session) {
      throw Error(`Storage encryption is only available to sessionStorage`);
    }

    this.setStorageType(storageType);
    this.setDomain(domain);

    if (storageType == CacheStorageType.Session && encryption == true) {
      key = await this.encrypt(key);
    }

    let value = store.get(key);

    if (value == null) {
      return undefined;
    }

    if (storageType == CacheStorageType.Session && encryption == true) {
      let itemType = this.getItemType(await this.decrypt(key), domain);
      value = this.checkItemType(itemType, this.decrypt(value));
      return value;
    }

    let itemType = this.getItemType(key, domain);
    value = this.checkItemType(itemType, value);
    return value;
  }
  /**
   * Remove date from cache
   * @param  {string} key cache key
   * @param  {CacheStorageType} storageType Session or Local
   * @param  {string} domain grouping of cached items
   * @param  {boolean=false} encryption is data encrypted
   * @returns void
   */
  async clearItem(
    key: string,
    storageType: CacheStorageType,
    domain: string,
    encryption: boolean = false
  ): Promise<void> {
    let item = await this.getItem(key, storageType, domain, encryption);
    if (item) {
      store.remove(item);
    }
  }
  /**
   * Removing grouping of cached items
   * @param  {string} domainName name of group
   * @param  {CacheStorageType} storageType Session or local
   */
  clearDomain(domainName: string, storageType: CacheStorageType) {
    this.setStorageType(storageType);
    store.clearDomain(domainName);
  }
  /**
   * Clear all cache, Session and Local storage
   */
  clearCache() {
    this.setStorageType(CacheStorageType.Local);
    store.bust();
    this.setStorageType(CacheStorageType.Session);
    store.bust();
  }

  private setStorageType(storageType: CacheStorageType): void {
    if (storageType == CacheStorageType.Session) {
      store.config({ type: 'sessionStorage' });
    } else {
      store.config({ type: 'localStorage' });
    }
  }

  private setDomain(domainName: string) {
    store.setDomain(domainName);
  }

  private convertTime(ttl: number): string {
    return ttl.toString() + 's';
  }

  private encrypt = async (val: string): Promise<string> => {
    if (!this.formedEncryptionKey) {
      await this.createEncryptionKey();
    }
    let encoded = new TextEncoder().encode(val);
    let cipher = await window.crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv: this.iv,
      },
      this.formedEncryptionKey!,
      encoded
    );
    return this.bufferToBase64(cipher);
  };

  private encryptKeyValue = async (key: string, value: string): Promise<[string, string]> => {
    key = await this.encrypt(key);
    value = await this.encrypt(value);
    return [key, value];
  };

  private decrypt = async (value: string): Promise<string> => {
    if (!this.formedEncryptionKey) {
      await this.createEncryptionKey();
    }
    let cipher = this.base64ToBytes(value);
    let decrypted = await window.crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: this.iv,
      },
      this.formedEncryptionKey!,
      cipher
    );
    return new TextDecoder('utf8').decode(decrypted);
  };

  private setItemType(key: string, itemType: any, domain: string) {
    let combinedKey: string = domain + '_' + key;
    this.typeMap.set(combinedKey, itemType);
  }

  private getItemType(key: string, domain: string): string | undefined {
    let combinedKey: string = domain + '_' + key;
    return this.typeMap.get(combinedKey);
  }

  private checkItemType(type: string | undefined, value: any): any {
    // if boolean value stored as string, convert back to boolean
    if (value == 'true' || value == 'false') {
      value = value == 'true';
    }

    if (type == 'promise') {
      return Promise.resolve(value);
    } else if (type == 'observable') {
      return of(value);
    } else {
      return value;
    }
  }

  private async handleObjectType(item: any): Promise<[any, string]> {
    if (item instanceof Promise) {
      try {
        item = await item;
        return [item, 'promise'];
      } catch {
        return [item, 'reject'];
      }
    } else if (item instanceof Observable) {
      item = await lastValueFrom(item);
      return [item, 'observable'];
    } else {
      return [item, 'object'];
    }
  }
  /**
   * converts buffer into string
   * @param  {ArrayBuffer} buffer
   * @returns string
   */
  private bufferToBase64(buffer: ArrayBuffer): string {
    let bytes = new Uint8Array(buffer);
    let binary = '';
    let len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }
  /**
   * converts string into buffer
   * @param  {string} base64
   * @returns Uint8Array
   */
  private base64ToBytes(base64: string): Uint8Array {
    let binary_string = window.atob(base64);
    let len = binary_string.length;
    let bytes = new Uint8Array(len);
    for (var i = 0; i < len; i++) {
      bytes[i] = binary_string.charCodeAt(i);
    }
    return bytes;
  }
}
