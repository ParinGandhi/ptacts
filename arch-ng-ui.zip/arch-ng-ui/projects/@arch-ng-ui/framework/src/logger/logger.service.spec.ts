import { NgxLoggerLevel } from "ngx-logger";
import { LoggerService } from "./logger.service";
import { expect, test, describe, vi } from "vitest";
import { TestBed } from "@angular/core/testing";

describe("Constructor", () => {
  // let loggerService: LoggerService;

  // beforeEach(() => {
  //   TestBed.configureTestingModule({
  //     providers: [LoggerService],
  //   });
  //   loggerService = TestBed.inject(LoggerService);
  // });
  test("service should be created", () => {
    const environment = {
      logLevel: NgxLoggerLevel.TRACE,
    };
    const loggerService = new LoggerService(environment);
    expect(loggerService).toBeDefined();
  });
  test("reads log level from environment", () => {
    const logLevel = NgxLoggerLevel.TRACE;
    const environment = {
      logLevel: NgxLoggerLevel.TRACE,
    };
    const loggerService = new LoggerService(environment);
    expect(loggerService.logLevel).toBe(logLevel);
  });
});
describe("log", () => {
  test("logs the proper message to the console", () => {
    const logLevel = NgxLoggerLevel.TRACE;
    const message = "Test message";
    const optionalParams = ["Param1", "Params2", "Param3"];
    const environment = {
      logLevel: NgxLoggerLevel.TRACE,
    };
    const loggerService = new LoggerService(environment);
    expect(loggerService).toBeTruthy();
    expect(loggerService.logLevel).toBe(logLevel);
    expect(loggerService.log(logLevel, message, optionalParams)).toBeCalled();
  });
});
