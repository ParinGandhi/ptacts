// import { LoggerModule, NgxLoggerLevel } from "ngx-logger";

export * from "./logger.service";
// export { LoggerModule, NgxLoggerLevel };
