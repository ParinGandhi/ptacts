import { NgxLoggerLevel } from "ngx-logger";

export type AllowedValues = string | number | boolean | NgxLoggerLevel;
export type EnvironmentType = {
  [key: string]: AllowedValues;
};
