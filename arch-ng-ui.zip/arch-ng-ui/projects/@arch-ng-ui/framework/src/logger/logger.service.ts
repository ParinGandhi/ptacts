import { Injectable, Inject } from "@angular/core";
import { NGXLogger, NgxLoggerLevel } from "ngx-logger";
import { AllowedValues, EnvironmentType } from "./environment.type";

@Injectable({
  providedIn: "root",
})
export class LoggerService {
  private readonly logger = Inject(NGXLogger);
  logLevel: AllowedValues = NgxLoggerLevel.WARN;

  constructor(@Inject("environment") private environment: EnvironmentType) {
    this.logLevel = this.environment?.["logLevel"];
  }

  log(
    logLevel: NgxLoggerLevel,
    message: string,
    ...optionalParams: Array<string | Object>
  ): void {
    const formattedOutput = this.constructLog(
      logLevel,
      message,
      optionalParams
    );

    if (
      this.logLevel === NgxLoggerLevel.ERROR ||
      this.logLevel === NgxLoggerLevel.FATAL
    ) {
      this.logger.error(formattedOutput);
    } else {
      this.logger.log(formattedOutput);
    }

    /** Reduce switch statement */

    // switch (logLevel) {
    //   case NgxLoggerLevel.TRACE:
    //     this.logger.trace(formattedOutput);
    //     break;
    //   case NgxLoggerLevel.DEBUG:
    //     this.logger.debug(formattedOutput);
    //     break;
    //   case NgxLoggerLevel.INFO:
    //     this.logger.info(formattedOutput);
    //     break;
    //   case NgxLoggerLevel.LOG:
    //     this.logger.log(formattedOutput);
    //     break;
    //   case NgxLoggerLevel.WARN:
    //     this.logger.warn(formattedOutput);
    //     break;
    //   case NgxLoggerLevel.ERROR:
    //     this.logger.error(formattedOutput);
    //     break;
    //   case NgxLoggerLevel.FATAL:
    //     this.logger.fatal(formattedOutput);
    //     break;
    //   default:
    //     break;
    // }
  }

  private constructLog(
    logLevel: NgxLoggerLevel,
    message: string,
    ...optionalParams: Array<string | Object>
  ) {
    let result: string = `Type ${NgxLoggerLevel[logLevel]} - Message: ${message}`;

    // result += "Type: " + NgxLoggerLevel[logLevel];
    // result += " - Message: " + message;

    if (optionalParams.length) {
      result += " - Additional Info: " + this.formatParams(optionalParams);
    }

    return result;
  }

  private formatParams(optionalParams: Array<string | Object>): string {
    let ret: string = optionalParams.join(",");

    // Is there at least one object in the array?
    if (optionalParams.some((p) => typeof p == "object")) {
      ret = "";

      // Build comma-delimited string
      for (let item of optionalParams) {
        ret += JSON.stringify(item) + ",";
      }
    }

    return ret;
  }
}
