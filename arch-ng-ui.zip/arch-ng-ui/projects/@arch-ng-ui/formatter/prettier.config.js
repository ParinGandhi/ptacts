module.exports = {
  singleQuote: true,
  tabWidth: 2,
  printWidth: 100,
  trailingComma: 'es5',
  bracketSameLine: false,
};
