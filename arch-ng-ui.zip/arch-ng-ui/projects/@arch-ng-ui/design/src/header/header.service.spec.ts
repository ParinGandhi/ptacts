import { TestBed } from '@angular/core/testing';

import { HeaderService } from './header.service';

describe('HeaderService', () => {
  let service: HeaderService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HeaderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('alert should have been added', () => {
    service.addAlert('Body of alert', 'Heading of alert', 'warn');
    expect(service.alerts.length).toBeGreaterThan(0);
  });

  it('alert should have been removed', () => {
    let alertId = service.addAlert('Body of alert', 'Heading of alert', 'warn');
    expect(service.alerts.length).toBeGreaterThan(0);
    service.removeAlert(alertId);
    expect(service.alerts.length).toBe(0);
  });

  it('expect username to have changed', () => {
    service.setUserName('John Smith');
    expect(service.userName).toEqual('John Smith');
  });

  it('expect title to have changed', () => {
    service.setTitle('New Title');
    expect(service.title).toEqual('New Title');
  });
});
