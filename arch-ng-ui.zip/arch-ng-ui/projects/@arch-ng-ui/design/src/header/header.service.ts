import { Subject } from 'rxjs';
import { DOCUMENT } from '@angular/common';
import { Inject, Injectable } from '@angular/core';
import { AlertProps, AlertVariation } from '../components/alert/alert.component';
import { StateService } from '@arch-ng-ui/framework';
import { HeaderLinks } from './header.component';
import * as _ from "lodash";

@Injectable({
  providedIn: 'root'
})
export class HeaderService {

  title: string = '';
  userName: string = '';
  routes: HeaderLinks[] = [];
  hasContent: boolean = true;

  alerts: AlertProps[] = [];

  $bannerHidden: Subject <boolean> = new Subject();

  private window: Window | null;


  constructor(@Inject(DOCUMENT) private document: Document, private stateService: StateService) {
    this.window = document.defaultView;
    this.$bannerHidden.next(true);
  }

  /**
   * Will display an alert below the header
   * @param  {string} body body text
   * @param  {string} heading heading text
   * @param  {AlertVariation} variation variation type error | warn | success
   * @param  {number} time max time alert is shown in milliseconds, default 10 seconds
   * * @returns string id
   */
  addAlert(body?: string, heading?: string, variation?: AlertVariation, time?: number): string {
    let headingId = _.uniqueId('heading_alert_');

    let alert: AlertProps = { headingId: headingId, variation: variation, heading: heading, body: body, canClose: true };
    this.alerts.push(alert);

    setTimeout(() => {
      this.removeAlert(headingId);
    }, time ? time : 10000);

    return headingId;
  }
  /**
   * hides alert below the header
   */
  removeAlert(headingId: string) {
    this.alerts?.splice(this.alerts.findIndex((elem: AlertProps) => elem.headingId === headingId), 1);
  }
  /**
   * change the username being shown in header
   * @param  {string} name
   */
  setUserName(name: string) {
    if (this.userName !== name) {
      this.userName = name;
    }
  }
  /**
   * change the title being shown in the header
   * @param  {string} title
   */
  setTitle(title: string) {
    if (this.title !== title) {
      this.title = title;
    }
  }
}
