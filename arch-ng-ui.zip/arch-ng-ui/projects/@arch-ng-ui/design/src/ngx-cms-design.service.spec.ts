import { TestBed } from '@angular/core/testing';

import { CmsDesignService } from './ngx-cms-design.service';

describe('NgxFfmStylingService', () => {
  let service: CmsDesignService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CmsDesignService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
