import { CommonModule } from '@angular/common';
import { HeaderService } from './header/header.service';
import { LogService } from '@arch-ng-ui/framework';
import { ModuleWithProviders, NgModule } from '@angular/core';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { CmsDesignModule } from './ngx-cms-design.module';
import { RouterModule } from '@angular/router';
import { FooterService } from './footer/footer.service';
import { HeaderDropdownMenuComponent } from './header-dropdown-menu/header-dropdown-menu.component';


@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent,
    HeaderDropdownMenuComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    CmsDesignModule
  ],
  exports: [
    HeaderComponent,
    FooterComponent,
  ]
})
export class FFMUIComponentsModule {
  public static forRoot(environment: any, AppConfig: any): ModuleWithProviders<FFMUIComponentsModule> {
    return {
      ngModule: FFMUIComponentsModule,
      providers: [
        LogService,
        {
          provide: 'environment',
          useValue: environment
        },
        {
          provide: 'AppConfig',
          useValue: AppConfig
        },
        HeaderService,
        FooterService,
        {
          provide: Window,
          useValue: window
        }
      ]
    };
  }
}
