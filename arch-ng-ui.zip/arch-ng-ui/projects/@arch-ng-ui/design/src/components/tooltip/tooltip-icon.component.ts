import { Component, Input, OnInit } from '@angular/core';
import classNames from 'classnames';
import { IconCommonProps } from '../icons/svg-icon.component';

export interface TooltipIconProps extends IconCommonProps {
  /*
   * Renders inversed version of icon
   */
  inversed?: boolean;
}

@Component({
  selector: 'cms-tooltip-icon',
  template: `<span class="ds-c-tooltip-icon__container">
    <cms-info-circle-icon-thin [className]="classes"
    [ariaHidden]="ariaHidden"
    [description]="description"
    [id]="id"
    [inversed]="inversed"
    [title]="title"
    [viewBox]="viewBox"></cms-info-circle-icon-thin>
    </span>`,
  styles: []
})
export class TooltipIconComponent implements OnInit {

  @Input() ariaHidden?: boolean;
  @Input() className?: string;
  @Input() description?: string;
  @Input() id?: string;
  @Input() inversed?: boolean;
  @Input() title?: string;
  @Input() viewBox?: string;

  classes?: string;

  ngOnInit(): void {
    this.classes = classNames('ds-c-tooltip-icon', {
      'ds-c-tooltip-icon--inverse': this.inversed,
    },
    this.className);
  }
}
