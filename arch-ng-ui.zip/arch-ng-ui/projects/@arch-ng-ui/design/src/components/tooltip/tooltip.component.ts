import { DOCUMENT } from '@angular/common';
import {
  animate,
  state,
  style,
  transition,
  trigger,
} from '@angular/animations';
import {
  Component,
  Input,
  OnInit,
  ElementRef,
  ViewChild,
  AfterViewInit,
  Renderer2,
  OnDestroy,
  Inject,
  ViewEncapsulation,
} from '@angular/core';
import { createPopper, Placement } from '@popperjs/core';
import classNames from 'classnames';
import { uniqueId } from 'lodash';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

export interface TooltipProps {
  /**
   * Classes applied to the tooltip trigger when the tooltip is active
   */
  activeClassName?: string;
  /**
   * Helpful description of the tooltip for screenreaders
   */
  ariaLabel?: string;
  /**
   * Classes applied to the tooltip trigger
   */
  className?: string;
  /**
   * Configurable text for the aria-label of the tooltip's close button
   */
  closeButtonLabel?: string;
  /**
   * When provided, will render the passed in component for the tooltip trigger. Typically will be a `button`, `a`, or rarely an `input` element.
   */
  component?: HTMLInputElement | any | ((...args: any[]) => any);
  /**
   * Heading for the tooltip content. This will show above 'title' content and inline with 'closeButton' if closeButton is set
   */
  contentHeading?: string;

  /**
   * Allow the dialog implementation to use hover as well
   */
  dialogHover?: boolean;
  /**
   * Tooltip that behaves like a dialog, i.e. a tooltip that only appears on click, traps focus, and contains interactive content. For more information, see Deque's [tooltip dialog documentation](https://dequeuniversity.com/library/aria/tooltip-dialog)
   */
  dialog?: boolean;
  /**
   * `id` applied to tooltip body container element. If not provided, a unique id will be automatically generated and used.
   */
  id?: string;
  /**
   * Sets the size of the invisible border around interactive tooltips that prevents it from immediately hiding when the cursor leaves the tooltip.
   */
  interactiveBorder?: number;
  inversed?: boolean;
  /**
   * Applies `skidding` and `distance` offsets to the tooltip relative to the trigger. See the [`popperjs` docs](https://popper.js.org/docs/v2/modifiers/popper-offsets/) for more info.
   */
  offset?: [number, number];
  /**
   * Called when the tooltip is hidden
   */
  onClose?: () => any;
  /**
   * Called when the tooltip is shown
   */
  onOpen?: () => any;
  /**
   * Placement of the tooltip body relative to the trigger. See the [`popperjs` docs](https://popper.js.org/docs/v2/constructors/#options) for more info.
   */
  placement?: Placement;
  /**
   * `maxWidth` styling applied to the tooltip body
   */
  maxWidth?: string;
  /**
   * Determines if close button is shown in tooltip. It is recommended that the close button is only used if `dialog=true`
   */
  showCloseButton?: boolean;
  /**
   * Content inside the tooltip body or popover. If contains interactive elements use the `dialog` prop.
   */
  toolTipContent: string | SafeHtml;
  /**
   * Duration of the `react-transition-group` CSSTransition. See the [`timeout` option](http://reactcommunity.org/react-transition-group/transition#Transition-prop-timeout) for more info.
   */
  transitionDuration?: number;
  /**
   * `zIndex` styling applied to the tooltip body
   */
  zIndex?: number;
}

@Component({
  selector: 'cms-tooltip',
  templateUrl: './tooltip.component.html',
  styleUrls: ['./tooltip.component.css'],
  animations: [
    trigger('openClose', [
      state(
        'open',
        style({
          opacity: 1,
          visibility: 'visible',
        })
      ),
      state(
        'closed',
        style({
          opacity: 0,
          visibility: 'hidden',
        })
      ),
      transition('open<=>closed', [animate('0.5s')]),
    ]),
  ],
  encapsulation: ViewEncapsulation.None,
})
export class TooltipComponent implements OnInit, AfterViewInit, OnDestroy {
  @Input() activeClassName: string = '';
  @Input() ariaLabel?: string;
  @Input() className?: string;
  @Input() closeButtonLabel?: string;
  @Input() component?: HTMLInputElement | any | ((...args: any[]) => any) =
    'button';
  @Input() contentHeading?: string;
  @Input() dialog?: boolean = false;
  @Input() dialogHover?: boolean = false;
  @Input() id?: string;
  @Input() interactiveBorder?: number = 15;
  @Input() inversed?: boolean;
  @Input() offset?: [number, number] = [0, 5];
  @Input() onClose?: () => any;
  @Input() onOpen?: () => any;
  @Input() placement?: Placement = 'top';
  @Input() maxWidth?: string = '300px';
  @Input() showCloseButton?: boolean;
  @Input() toolTipContent?: string | SafeHtml;
  @Input() transitionDuration?: number = 250;
  @Input() zIndex?: number = 9999;

  @ViewChild('triggerComponent') triggerElement?: ElementRef;
  @ViewChild('tooltipElement') tooltipElement?: ElementRef;
  @ViewChild('tooltipContainer') tooltipContainer?: ElementRef;
  active: boolean = false;
  isHover: boolean = false;
  isMobile: boolean = false;
  triggerClasses?: string;
  tooltipClasses?: string;
  headingClasses?: string;
  interactiveBorderStyle?: any;
  popperInstance?: any;
  dialogOpen: boolean = false;

  constructor(
    private renderer: Renderer2,
    @Inject(DOCUMENT) private document: Document,
    private domSanitizer: DomSanitizer
  ) {}

  private setActive(value: boolean) {
    let prevValue = this.active;
    this.active = value;
    if (value) {
      this.document?.addEventListener('mousedown', this.handleClickOutside);
      this.document?.addEventListener('keydown', this.handleEscapeKey);
      if (this.dialog) {
        setTimeout(() => {
          this.enableTooltipTabbing();
          this.tooltipElement?.nativeElement.focus();
        });
      }
      this.showPopper();
      this.onOpen && this.onOpen();

    } else {
      this.hidePopper();
      if (this.dialog) {
        this.disableTooltipTabbing();
        this.triggerElement?.nativeElement.focus();
      }

      if (prevValue && (this.dialog || this.isMobile) && this.showCloseButton) {
        if (this.triggerElement) {
          this.triggerElement.nativeElement.focus();
        }
      }
      this.onClose && this.onClose();
      this.document?.removeEventListener('keydown', this.handleEscapeKey);
      this.document?.removeEventListener('mousedown', this.handleClickOutside);
    }
  }

  private setIsMobile(value: boolean) {
    this.isMobile = value;
  }

  private setIsHover(value: boolean) {
    this.isHover = value;
  }

  ngOnInit(): void {
    this.id = this.id || uniqueId('trigger_');
    this.triggerClasses = classNames(
      'ds-base',
      'ds-c-tooltip__trigger',
      this.className,
      {
        [this.activeClassName]: this.active,
        'ds-c-tooltip__trigger--inverse': this.inversed,
      }
    );
    this.tooltipClasses = classNames(
      'ds-c-tooltip',
      {
        'ds-c-tooltip--inverse': this.inversed,
      },
      'custom-tooltip'
    );
    this.headingClasses = classNames('ds-c-tooltip__header', {
      'ds-c-tooltip__header--right': !this.contentHeading,
    });
    this.interactiveBorderStyle = {
      left: `-${this.interactiveBorder}px`,
      top: `-${this.interactiveBorder}px`,
      border: `${this.interactiveBorder}px solid transparent`,
      zIndex: -999, // ensures interactive border doesnt cover tooltip content
    };

    if (this.dialog && this.toolTipContent) {
      this.toolTipContent = this.domSanitizer.bypassSecurityTrustHtml(
        this.toolTipContent as string
      );
    }
  }

  ngAfterViewInit(): void {
    if (this.triggerElement) {
      this.triggerElement.nativeElement.addEventListener(
        'touchstart',
        this.handleTouch
      );
    }

    // Regular tooltip container
    if (this.tooltipContainer && !this.dialog) {
      this.tooltipContainer.nativeElement.addEventListener(
        'mouseenter',
        (e: MouseEvent) => {
          if (!this.isMobile) {
            this.setIsHover(true);
            this.setActive(true);
          }
        }
      );
      this.tooltipContainer.nativeElement.addEventListener(
        'mouseleave',
        (e: MouseEvent) => {
          if (!this.isMobile) {
            this.setIsHover(false);
            this.setActive(false);
          }
        }
      );
    }

    this.popperInstance = createPopper(
      this.triggerElement?.nativeElement,
      this.tooltipElement?.nativeElement,
      {
        placement: this.placement,
        modifiers: [
          {
            name: 'offset',
            options: { offset: this.offset },
          },
        ],
      }
    );
    setTimeout(() => {
      this.popperInstance?.forceUpdate();
    }, 400);

    // Dialog Container for interactive tooltip
    if (this.dialog) {
      // Want dialog element to be hoverable
      if (this.dialogHover) {
        // Leaving the trigger element
        this.triggerElement?.nativeElement.addEventListener(
          'mouseleave',
          (e: MouseEvent) => {
            if (!this.isMobile) {
              // Keep dialog open when clicked and mouse leave the trigger
              if (this.dialogOpen) {
                this.setIsHover(true);
                this.setActive(true);
              } else {
                this.setIsHover(false);
                this.setActive(false);
              }
            }
          }
        );
        // When the tooltip is clicked open/closed
        this.triggerElement?.nativeElement.addEventListener(
          'click',
          (e: any) => {
            this.dialogOpen = !this.dialogOpen;
            this.setIsHover(this.dialogOpen);
            this.setActive(this.dialogOpen);
          }
        )
        // Entering the trigger element
        this.triggerElement?.nativeElement.addEventListener(
          'mouseenter',
          (e: MouseEvent) => {
            if (!this.isMobile) {
              this.setIsHover(true);
              this.setActive(true);
            }
          }
        );
        // Event when mouse leaves dialog, closes it
        this.tooltipElement?.nativeElement.addEventListener(
          'mouseleave',
          (e: MouseEvent) => {
            // Closing the dialog when the mouse leaves unless it has a close button
            if (!this.isMobile && !this.showCloseButton) {
              this.setIsHover(false);
              this.setActive(false);
              this.dialogOpen = false;
            }
          }
        );
      }
      this.disableTooltipTabbing();
    }
  }

  ngOnDestroy(): void {
    if (this.triggerElement) {
      this.triggerElement?.nativeElement?.removeEventListener(
        'touchstart',
        this.handleTouch
      );
    }
    if (this.tooltipContainer) {
      this.tooltipContainer?.nativeElement?.removeEventListener(
        'mouseenter',
        (e: MouseEvent) => {}
      );
      this.tooltipContainer?.nativeElement?.removeEventListener(
        'mouseleave',
        (e: MouseEvent) => {}
      );
    }


    if (!this.popperInstance) {
      return;
    }
    this.popperInstance.destroy();
    this.popperInstance = null;
  }

  handleEscapeKey = (event: KeyboardEvent) => {
    const ESCAPE_KEY = 'Escape';
    if (this.active && event.code === ESCAPE_KEY) {
      this.setActive(false);
    }
  };

  handleClickOutside = (event: MouseEvent) => {
    if (this.active && (this.dialog || this.isMobile)) {
      let clickedTrigger = this.triggerElement?.nativeElement?.contains(
        event.target
      );
      let clickedTooltip = this.tooltipElement?.nativeElement?.contains(
        event.target
      );
      if (!clickedTooltip && !clickedTrigger) {
        this.setActive(false);
        // Clicked outside with a close button
        if (this.showCloseButton && this.dialogHover) {
          this.dialogOpen = false;
        }
      }
    }
  };

  handleCloseButtonClick = () => {
    if (this.active && (this.dialog || this.isMobile)) {
      this.setActive(false);
      // Setting dialog closed when close button clicked
      if (this.showCloseButton && this.dialogHover) {
        this.dialogOpen = false;
      }
    }
  };

  handleBlur = (event: FocusEvent) => {
    setTimeout(() => {
      let focusedInsideTrigger = this.triggerElement?.nativeElement?.contains(
        event.target
      );
      let focusedInsideTooltip = this.tooltipElement?.nativeElement?.contains(
        event.target
      );
      if (!this.dialog && !focusedInsideTooltip && !this.isHover) {
        this.setActive(false);
      } else if (
        !focusedInsideTooltip &&
        !focusedInsideTrigger &&
        !this.isHover
      ) {
        this.setActive(false);
      }
    }, 10);
  };

  handleTouch = () => {
    // On mobile, touch -> mouseenter -> click events can all be fired simultaneously
    // `isMobile` flag is used inside onClick and onMouseEnter handlers, so touch events can be used in isolation on mobile
    // https://stackoverflow.com/a/65055198
    this.setIsMobile(true);
    this.setActive(!this.active);
  };

  onClick = () => {
    if (this.dialog && !this.dialogHover) {
      if (!this.isMobile) {
        this.setActive(!this.active);
      }
    } else {
      if (!this.isMobile) {
        this.setActive(!this.active);
      }
    }
  };

  onFocus = () => {
    if (!this.dialog) {
      this.setActive(true);
    }
  };

  showPopper = () => {
    setTimeout(() => {
      this.popperInstance?.forceUpdate();
    });
  };

  hidePopper = () => {};

  disableTooltipTabbing = () => {
    [...this.tooltipElement?.nativeElement
      .querySelectorAll('button')].forEach((button: HTMLElement) => {
        this.renderer.setAttribute(button, 'tabindex', '-1');
      });

    [...this.tooltipElement?.nativeElement
      .querySelectorAll('a')].forEach((a: HTMLElement) => {
        this.renderer.setAttribute(a, 'tabindex', '-1');
      });
  }

  enableTooltipTabbing = () => {
    [...this.tooltipElement?.nativeElement
      .querySelectorAll('button')].forEach((button: HTMLElement) => {
        this.renderer.setAttribute(button, 'tabindex', '0');
      });

    [...this.tooltipElement?.nativeElement
      .querySelectorAll('a')].forEach((a: HTMLElement) => {
        this.renderer.setAttribute(a, 'tabindex', '0');
      });
  }
}
