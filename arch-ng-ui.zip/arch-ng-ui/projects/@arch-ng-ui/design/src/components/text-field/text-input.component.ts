import { MaskComponent } from './mask.component';
import { Component, Input, OnInit, ElementRef, Renderer2, ViewContainerRef, Injector, Self, Optional, OnChanges, SimpleChanges, ViewChild, AfterViewInit, ViewEncapsulation } from '@angular/core';
import classNames from 'classnames';
import * as _ from "lodash";
import { ControlContainer, ControlValueAccessor, UntypedFormGroup, FormGroupDirective, NgControl } from '@angular/forms';

/**
 * <TextInput> is an internal component used by <TextField>, which wraps it and handles shared form UI like labels, error messages, etc
 * <TextInput> is also exported for advanced design system use cases, where the internal component can be leveraged to build custom form components
 * As an internal component, it's subject to more breaking changes. Exercise caution using <TextInput> outside of those special cases
 */

export type TextInputDefaultValue = string | number;
export type TextInputMask = 'currency' | 'phone' | 'ssn' | 'zip';
export type TextInputRows = number | string;
export type TextInputSize = 'small' | 'medium';
export type TextInputValue = string | number;
export type TextInputErrorPlacement = 'top' | 'bottom';
export type MultilineValue = boolean | undefined;

const ariaAttributes: string[] = ['aria-autocomplete',
  'aria-checked',
  'aria-disabled',
  'aria-errormessage',
  'aria-expanded',
  'aria-haspopup',
  'aria-hidden',
  'aria-invalid',
  'aria-label',
  'aria-labelledby',
  'aria-describedby',
  'aria-level',
  'aria-modal',
  'aria-multiline',
  'aria-multiselectable',
  'aria-orientation',
  'aria-placeholder',
  'aria-pressed',
  'aria-readonly',
  'aria-required',
  'aria-selected',
  'aria-sort',
  'aria-valuemax',
  'aria-valuemin',
  'aria-valuenow',
  'aria-valuetext'
];

export const InputAttributes: string[] = [
  'accept', 'alt', 'autocomplete', 'autofocus', 'checked', 'dirname', 'disabled', 'form', 'formaction', 'formenctype', 'formmethod',
  'formnovalidate', 'formtarget', 'height', 'list', 'max', 'maxlength', 'min', 'minlength', 'multiple', 'placeholder', 'readonly',
  'required', 'src', 'step', 'width', ...ariaAttributes
];

export const TextAreaAttributes: string[] = [
  'autofocus', 'cols', 'dirname', 'disabled', 'form', 'maxlength', 'placeholder', 'readonly', 'required', 'wrap', ...ariaAttributes
];

export const NOOP_VALUE_ACCESSOR: ControlValueAccessor = {
  writeValue(): void { },
  registerOnChange(): void { },
  registerOnTouched(): void { },
};

@Component({
  selector: 'cms-text-input',
  templateUrl: './text-input.component.html',
  styleUrls: ['./text-input.component.css'],
  viewProviders: [
    {
      provide: ControlContainer,
      useExisting: FormGroupDirective,
    },
  ],
  encapsulation: ViewEncapsulation.None,
})
export class TextInputComponent implements OnInit, OnChanges, AfterViewInit {
  /**
   * Apply an `aria-label` to the text field to provide additional
   * context to assistive devices.
   */
  @Input() ariaLabel?: string;

  /**
   * Apply an `aria-labelledby` to the text field to provide additional
   * context to assistive devices.
   */
  @Input() ariaLabelledby?: string;

  /**
   * Apply an `aria-description` to the text field to provide additional
   * context to assistive devices.
   */
  @Input() ariaDescription?: string;

  /**
   * Apply an `aria-describedby` to the text field to provide additional
   * context to assistive devices.
   */
  @Input() ariaDescribedby?: string;
  /**
   * Apply an `aria-required` to the text field to provide additional
   * context to assistive devices.
   */
  @Input() ariaRequired?: boolean;
  /**
   * Sets the initial value. Use this for an uncontrolled component; otherwise,
   * use the `value` property.
   */
  @Input() defaultValue?: TextInputDefaultValue;
  @Input() disabled?: boolean;

  /**
   * The ID of the error message applied to the Select field.
   */
  @Input() errorId?: string;
  @Input() errorMessage?: any;

  /**
   * Location of the error message relative to the field input
   */
  @Input() errorPlacement?: TextInputErrorPlacement;

  /**
   * Additional classes to be added to the field element
   */
  @Input() fieldClassName?: string;

  /**
   * A unique `id` to be used on the text field.
   */
  @Input() id?: string;

  /**
   * Applies the "inverse" UI theme
   */
  @Input() inversed?: boolean;

  /**
   * Apply formatting to the field that's unique to the value
   * you expect to be entered. Depending on the mask, the
   * field's appearance and functionality may be affected.
   */
  @Input() mask?: TextInputMask;

  /**
   * Whether or not the text field is a multiline text field
   */
  @Input() multiline?: MultilineValue;
  @Input() name?: string;

  /**
   * Sets `inputMode`, `type`, and `pattern` to improve accessibility and consistency for number fields. Use this prop instead of `type="number"`, see [here](https://technology.blog.gov.uk/2020/02/24/why-the-gov-uk-design-system-team-changed-the-input-type-for-numbers/) for more information.
   */
  @Input() numeric?: boolean;
  @Input() onBlur?: (event: Event) => any;
  @Input() onInputHandler?: (event: Event) => any;
  @Input() onChange?: (event: Event) => any;
  @Input() onFocus?: (event: Event) => any;

  /**
   * @hide-prop HTML `input` [pattern](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#htmlattrdefpattern).
   */
  @Input() pattern?: string;

  /**
   * Optionally specify the number of visible text lines for the field. Only
   * applicable if this is a multiline field.
   */
  @Input() rows?: TextInputRows;

  /**
   * Set the max-width of the input either to `'small'` or `'medium'`.
   */
  @Input() size?: TextInputSize;

  /**
   * HTML `input` [type](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#<input>_types) attribute. If you are using `type=number` please use the numeric prop instead.
   */
  @Input() type?: string;

  /**
   * Sets the input's `value`. Use this in combination with `onChange`
   * for a controlled component; otherwise, set `defaultValue`.
   */
  @Input() value?: TextInputValue;

  /**
   * @param  {any[];} parentAttributes?
   * @returns any
   */
  @Input() parentAttributes?: any[];

  /**
   * Used in conjunction with formGroup to associate angular form
   * @param  {string;} formControlName?
   * @returns string
   */
  @Input() formControlName?: string | number | null;
  @Input() parentGroup?: UntypedFormGroup;
  @Input() isCalendarInput?: boolean = false;
  @ViewChild('inputRoot', { read: ElementRef }) inputRoot?: ElementRef;

  classes?: string = '';
  maskElem?: HTMLElement;
  ComponentType = '';
  formGroup?: UntypedFormGroup;

  constructor(
    @Self() @Optional() public ngControl: NgControl,
    private elementRef: ElementRef,
    private renderer: Renderer2,
    private vcr: ViewContainerRef,
    private injector: Injector
  ) {
    if (this.ngControl) {
      // Note: we provide the value accessor through here, instead of
      // the `providers` to avoid running into a circular import.
      // And we use NOOP_VALUE_ACCESSOR so TextField doesn't do anything with NgControl
      this.ngControl.valueAccessor = NOOP_VALUE_ACCESSOR;
    }
  }

  ngOnInit(): void {
    type OmitProps = 'size' | 'ref';

    let inputType = this.type;
    if (this.numeric) {
      inputType = 'text';
    } else if (this.multiline) {
      inputType = undefined;
    }

    this.ComponentType = this.multiline ? 'textarea' : 'input';
    const numberRows: number | undefined =
      typeof this.rows === 'string' ? parseInt(this.rows) : this.rows;

    if (this.defaultValue && !this.value) {
      this.value = this.defaultValue;
    }

    if (this.value == undefined) {
      this.value = '';
    }

    if (this.multiline && numberRows) {
      this.rows = numberRows;
    }

    if (this.numeric && !this.pattern) {
      this.pattern = '[0-9]+';
    }

    if (inputType) {
      this.type = inputType;
    }

    this.ariaDescription = (this.ariaDescription && !this.ariaDescribedby) ? this.ariaDescription : undefined;
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.updateErrorMessage();

      this.parentAttributes?.forEach((attr: any) => {
        this.renderer.setAttribute(
          this.inputRoot?.nativeElement,
          attr.name,
          attr.value
        );
      });

      //TODO: onCopyCapture not implemented
      // @ts-ignore: The ClipboardEventHandler for textareas and inputs are incompatible, and TS
      // is failing to infer which one is being used here based on ComponentType.

      if (this.mask) {
        // Mask used, insantiate mask component and pass field as child
        console.log('mask exists, wrap field');
        this.maskElem = this.getMask(this.inputRoot?.nativeElement);
        this.renderer.appendChild(this.elementRef.nativeElement, this.maskElem);
      } else {
        // Mask not used, append listeners to field
        this.renderer.listen(this.inputRoot?.nativeElement, 'input', (event) =>
          this.handleInput(event)
        );
        this.renderer.listen(this.inputRoot?.nativeElement, 'change', (event) =>
          this.handleChange(event)
        );
        this.renderer.listen(this.inputRoot?.nativeElement, 'blur', (event) =>
          this.handleBlur(event)
        );
        this.renderer.listen(this.inputRoot?.nativeElement, 'focus', (event) =>
          this.handleFocus(event)
        );
      }
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['errorMessage']) {
      this.updateErrorMessage();
    }
  }

  updateErrorMessage() {
    if (this.inputRoot) {
      this.classes = classNames(
        'ds-c-field',
        {
          'ds-c-field--error': this.errorMessage,
          'ds-c-field--inverse': this.inversed,
        },
        this.mask && `ds-c-field--` + this.mask,
        this.size && `ds-c-field--` + this.size,
        this.fieldClassName
      );

      const attributes = this.elementRef.nativeElement.attributes;
      if (attributes['aria-invalid'] || this.errorMessage) {
        this.renderer?.setAttribute(
          this.inputRoot.nativeElement,
          'aria-invalid',
          attributes['aria-invalid']
            ? attributes['aria-invalid']
            : !!this.errorMessage
        );
      } else {
        this.renderer?.setAttribute(
          this.inputRoot.nativeElement,
          'aria-invalid',
          'false'
        );
      }

      if (this.errorMessage) {
        this.renderer?.setAttribute(
          this.inputRoot.nativeElement,
          'aria-describedby',
          classNames(attributes['aria-describedby'], this.errorId)
        );
      }
      else if (!this.ariaDescribedby) {
        this.renderer?.removeAttribute(this.inputRoot.nativeElement,
          'aria-describedby');
      }
    }
  }

  getMask(field: HTMLElement): HTMLElement | undefined {
    const maskRef = this.vcr.createComponent(MaskComponent, {
      injector: this.injector,
    });
    maskRef.instance.field = this.elementRef;
    maskRef.instance.fieldElem = field;
    const elem = maskRef.location.nativeElement;
    return elem;
  }

  handleChange(event: any): void {
    if (!this.disabled && this.onChange) {
      this.onChange(event);
    }
  }

  handleInput(event: any): void {
    if (!this.disabled && this.onInputHandler) {
      this.onInputHandler(event);
    }
  }

  handleBlur(event: any): void {
    if (!this.disabled && this.onBlur) {
      this.onBlur(event);
    }
  }

  handleFocus(event: any): void {
    if (!this.disabled && this.onFocus) {
      this.onFocus(event);
    }
  }
}
