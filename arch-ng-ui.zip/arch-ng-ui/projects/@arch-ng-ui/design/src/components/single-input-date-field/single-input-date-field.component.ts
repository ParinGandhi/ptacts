import { Component, Input, Self, Optional, ViewChild, Renderer2 } from '@angular/core';
import * as _ from "lodash";
import { UntypedFormGroup, NgControl, NgModel } from '@angular/forms';
import { TextFieldErrorPlacement, TextFieldComponent } from '../text-field/text-field.component';
import { NOOP_VALUE_ACCESSOR } from '../text-field/text-input.component';

export interface SingleInputDateFieldProps {
  /**
   * Additional classes to be added to the root element.
   */
  className?: string;
  /**
   * Location of the error message relative to the field input
   */
  errorPlacement?: 'top' | 'bottom';
  /**
   * Label for the field.
   */
  label: string;
  /**
   * Additional classes to be added to the field label
   */
  labelClassName?: string;
  /**
   * A unique `id` to be used on the field label. If one isn't provided, a unique ID
   * will be generated.
   */
  labelId?: string;
  /**
   * The `input` field's `name` attribute
   */
  name: string;
  /**
   * Called anytime any date input is blurred
   */
  onBlur?: (event: any) => any;
  /**
   * Called anytime any date input is changed. This function is called with two arguments.
   * The first argument should be used to update whatever state your application uses to
   * supply back to this component's `value` prop in a _controlled component_ pattern.
   *
   * @param updatedValue - The input's new value
   * @param formattedValue - The input's new value with date formatting applied, included
   *   for convenience. Do not use this value as the component's `value` prop. An appropriate
   *   use for this value would be to run date-validation checks against it.
   */
  onChange: (updatedValue: string, formattedValue: string) => any;
  /**
   * Sets the input's `value`. Use in combination with an `onChange` handler to implement
   * a _controlled component_ pattern. This component expects the `value` to match
   * whatever string the user types (i.e., the first argument provided to your `onChange`
   * handler).
   */
  value?: string;

  // From DayPicker
  // -------------------------
  /**
   * The initial month to show in the calendar picker. If not provided, defaults to the
   * month of the currently selected date.
   */
  defaultMonth?: Date;
  /**
   * Earliest day to start month navigation in the calendar picker.
   * (This does not restrict dates entered manually.)
   */
  fromDate?: Date;
  /**
   * Earliest month to start month navigation in the calendar picker.
   * (This does not restrict dates entered manually.)
   */
  fromMonth?: Date;
  /**
   * Earliest year to start month navigation in the calendar picker.
   * (This does not restrict dates entered manually.)
   */
  fromYear?: number;
  /**
   * Latest day to end month navigation in the calendar picker.
   * (This does not restrict dates entered manually.)
   */
  toDate?: Date;
  /**
   * Latest month to end month navigation in the calendar picker.
   * (This does not restrict dates entered manually.)
   */
  toMonth?: Date;
  /**
   * Latest year to end month navigation in the calendar picker.
   * (This does not restrict dates entered manually.)
   */
  toYear?: number;
  formControlName?: string | number | null;
  parentGroup?: UntypedFormGroup;
  formGroupName?: string;
}

export const digitPattern: RegExp = /^[0-9]$/;

@Component({
  selector: 'cms-single-input-date-field',
  templateUrl: './single-input-date-field.component.html',
  styleUrls: ['./single-input-date-field.component.css']
})
export class SingleInputDateFieldComponent {

  @Input() className?: string;
  @Input() ariaLabel?: string;
  @Input() ariaLabelledby?: string;
  @Input() ariaDescribedby?: string;
  @Input() defaultValue?: string;
  @Input() disabled: boolean = false;
  @Input() errorMessage?: any;
  @Input() errorMessageClassName?: string;
  @Input() errorPlacement?: TextFieldErrorPlacement;
  @Input() fieldClassName?: string;
  @Input() focusTrigger?: boolean;
  @Input() hint?: any;
  @Input() id?: string;
  @Input() requirementLabel?: any;
  @Input() inversed?: boolean;
  @Input() label: any;
  @Input() labelClassName?: string;
  @Input() labelId?: string;
  @Input() name: string = '';
  @Input() onBlur?: (...args: any[]) => any;
  @Input() pattern?: string;
  @Input() formControlName?: string | number | null;
  @Input() parentGroup?: UntypedFormGroup;

  @ViewChild('singleDateField') textFieldComponent?: TextFieldComponent;
  @ViewChild('singleDateField', {read: Element}) element?: Element;

  dateStringValue: string = '';

  constructor(@Self() @Optional() public ngControl: NgControl, private renderer: Renderer2) {
    if (this.ngControl) {
      // Note: we provide the value accessor through here, instead of)
      // the `providers` to avoid running into a circular import.
      // And we use NOOP_VALUE_ACCESSOR so TextField doesn't do anything with NgControl
      this.ngControl.valueAccessor = NOOP_VALUE_ACCESSOR;
    }
  }

  ngAfterViewInit() {
    if(this.ngControl) {
     this.renderer.setProperty(this.textFieldComponent?.inputComponent?.inputRoot?.nativeElement, 'value', this.ngControl.value);
    }
    else if(this.defaultValue) {
      this.renderer.setProperty(this.textFieldComponent?.inputComponent?.inputRoot?.nativeElement, 'value', this.defaultValue);
    }
  }

  handleBlur = (event: any): void => {
    let data: string = '';
    if (!this.disabled && this.onBlur) {
      if(this.ngControl?.value) {
        data = this.ngControl.value;
      }
      else {
        data = this.textFieldComponent?.inputComponent?.inputRoot?.nativeElement.value;
      }
      this.onBlur(data);
    }
  }

  handleInput = (event: any) => {
    let dateStringValue: string = '';
    if (this.ngControl?.value) {
      dateStringValue = this.ngControl.value;
    }
    else {
      dateStringValue = this.textFieldComponent?.inputComponent?.inputRoot?.nativeElement.value;
    }

    if(event.data && digitPattern.test(event.data) && dateStringValue.length < 11) {
      if(dateStringValue.length == 2 || dateStringValue.length == 5) {
        dateStringValue = dateStringValue.concat('/');
      }
    }
    else if(event.inputType === 'insertText') {
      dateStringValue = dateStringValue.substring(0, dateStringValue.length - 1);
    }

    if (this.ngControl?.value) {
      this.ngControl.control?.setValue(dateStringValue);
    }
    else {
      this.renderer.setProperty(this.textFieldComponent?.inputComponent?.inputRoot?.nativeElement, "value", dateStringValue);
    }
  }
}
