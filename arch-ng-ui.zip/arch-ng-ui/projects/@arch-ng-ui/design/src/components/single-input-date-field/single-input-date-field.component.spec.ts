import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CmsDesignModule } from 'ngx-cms-design';

import { SingleInputDateFieldComponent } from './single-input-date-field.component';

describe('SingleInputDateFieldComponent', () => {
  let component: SingleInputDateFieldComponent;
  let fixture: ComponentFixture<SingleInputDateFieldComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule(
      {imports: [ CmsDesignModule ],
      declarations: [ SingleInputDateFieldComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SingleInputDateFieldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
