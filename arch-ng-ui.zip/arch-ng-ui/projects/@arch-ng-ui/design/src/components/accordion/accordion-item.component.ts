import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import classNames from 'classnames';
import * as _ from 'lodash';

export interface AccordionItemProps {
  /**
   * Class to be applied to the header `<button>` of an accordion item.
   */
  buttonClassName?: string;

  /**
   * Class to be applied to the content `<div>` tag of an accordion item.
   */
  contentClassName?: string;
  /**
   * Boolean to expand the accordion.
   */
  defaultOpen?: boolean;
  /**
   * Text for the accordion item heading.
   */
  heading: string;
  /**
   *  Heading type to override default `<h2>`.
   */
  headingLevel?: '1' | '2' | '3' | '4' | '5' | '6';
  /**
   *  If not provided, a unique id will be automatically generated and used.
   */
  id?: string;
  /**
   * Sets the accordion panel's open state. Use this in combination with `onChange`
   * for a controlled accordion; otherwise, set `defaultOpen`.
   */
  isControlledOpen?: boolean;
  /**
   * A callback function that's invoked when a controlled accordion panel is selected or deselected.
   */
  onChange?: () => void;

  disabled?: boolean;

  /**
   * Sets the tabindex property of the header
   */
  headingTabIndex?: string;
}

export interface AccordionItemState {
  isOpen?: boolean;
}

@Component({
  selector: 'cms-accordion-item',
  templateUrl: './accordion-item.component.html',
  styleUrls: ['./accordion-item.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class AccordionItemComponent implements OnInit {
  @Input() buttonClassName?: string;
  @Input() contentClassName?: string;
  @Input() defaultOpen?: boolean;
  @Input() heading?: string;
  @Input() headingLevel?: '1' | '2' | '3' | '4' | '5' | '6' = '2';
  @Input() id?: string;
  @Input() isControlledOpen?: boolean;
  @Input() onChange?: () => void;
  @Input() disabled?: boolean = false;
  @Input() headingTabIndex?: string;
  // non-expandable accordion items have no content
  @Input() isExpandable: boolean = true;
  // set accordion item open or closed
  @Input() isOpen?: boolean;

  buttonId?: string;
  contentId?: string;
  isControlled?: boolean;
  contentClasses?: string;
  buttonClasses?: string;

  constructor() {}

  ngOnInit(): void {
    this.isControlled = !!this.onChange;
    this.handleClick = this.handleClick.bind(this);
    this.contentId = this.id ?? _.uniqueId('accordionItem_');
    this.buttonId = this.contentId + '-button';

    if (this.isOpen == undefined && !this.isControlled) {
      this.isOpen = !!this.defaultOpen;
    }

    this.updateClasses();
  }

  updateClasses() {
    this.contentClasses = classNames(
      'ds-c-accordion__content',
      'ds-c-accordion__max-height-fit',
      'ds-u-margin-bottom--4',
      this.contentClassName
    );
    this.buttonClasses = classNames(
      'ds-c-accordion__button',
      'ds-u-focus',
      !this.isExpandable && 'ds-c-accordion__width-inherit',
      !this.isOpen && 'ds-u-margin-bottom--4',
      this.disabled && 'ds-c-accordion__disabled',
      this.buttonClassName
    );
  }

  // Set the state for opening and closing an accordion item
  handleClick(): void {
    if (!this.disabled) {
      if (this.isControlled && this.onChange) {
        this.onChange();
      } else {
        this.isOpen = !this.isOpen;
      }
      this.updateClasses();
    }
  }

  isItemOpen(): boolean | undefined {
    return this.isControlled ? this.isControlledOpen : this.isOpen;
  }
}
