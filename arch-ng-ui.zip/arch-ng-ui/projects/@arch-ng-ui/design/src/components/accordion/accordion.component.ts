import { Component, Input, OnInit } from '@angular/core';
import classNames from 'classnames';

export interface AccordionProps {
  /**
   * Applies a border to the accordion content.
   */
  bordered?: boolean;
  /**
   * Class to be applied to the outer `<div>` that contains all accordion items.
   */
  className?: string;
}

@Component({
  selector: 'cms-accordion',
  template: `<div (keydown)="handleKeyDown($event)" [class]="classes"><ng-content></ng-content></div>`,
  styleUrls: ['./accordion.component.css']
})
export class AccordionComponent implements OnInit {

  DOWN_ARROW = 'ArrowDown';
  UP_ARROW = 'ArrowUp';
  classes?: string;

  @Input() bordered?: boolean = true;
  @Input() className?: string;

  constructor() {
    // This is intentional
  }

  ngOnInit(): void {
    this.classes = classNames('ds-c-accordion',
    this.bordered && 'ds-c-accordion--bordered',
    this.className);
  }

  handleKeyDown = (e: any) => {
    const target = e.target;
    const accordionElement = e.currentTarget;

    if (e.key === this.DOWN_ARROW || e.key === this.UP_ARROW) {
      const triggers = Array.prototype.slice.call(
        accordionElement.querySelectorAll('.ds-c-accordion__button')
      );
      const direction = e.key === this.DOWN_ARROW ? 1 : -1;
      const index = triggers.indexOf(target);
      const length = triggers.length;
      const newIndex = (index + length + direction) % length;

      triggers[newIndex].focus();
      e.preventDefault();
    }
  };
}
