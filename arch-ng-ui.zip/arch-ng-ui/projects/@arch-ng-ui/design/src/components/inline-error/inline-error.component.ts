import { Component, ElementRef, Input, OnInit, Renderer2 } from '@angular/core';
import classNames from 'classnames';

//TODO: import AlertCircleIcon

/**
 * <InlineError> is an internal component used by <FormLabel> and <FormControl>
 * <InlineError> is also exported for advanced design system use cases, where the internal component can be leveraged to build custom form components
 */

@Component({
  selector: 'cms-inline-error',
  template: `<span [class]="classes" [id]="id" role="alert" *ngIf="errorMessage">
    <cms-alert-circle-icon [viewBox]="viewbox"></cms-alert-circle-icon>
    <span class="ds-u-visibility--screen-reader">Error:</span>
    {{errorMessage}}
    </span>`,
  styleUrls: ['./inline-error.component.css']
})
export class InlineErrorComponent implements OnInit {

  @Input() className?: string;
  @Input() id?: string;
  @Input() inversed?: boolean;
  @Input() errorMessage?: string;

  classes?: string = '';
  viewbox = '36 -12 186 186';

  constructor(private elementRef: ElementRef, private renderer: Renderer2) { }

  ngOnInit(): void {
    const inverseClass = this.inversed && 'ds-c-field__error-message--inverse';
    this.classes = classNames('ds-c-inline-error', 'ds-c-field__error-message',
     inverseClass, this.className);
  }
}
