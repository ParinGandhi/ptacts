import { Subscription } from 'rxjs';
import { NOOP_VALUE_ACCESSOR } from './../text-field/text-input.component';
import { NgControl, FormGroupDirective, UntypedFormGroup, Validators } from '@angular/forms';
import { Component, Input, OnDestroy, OnInit, ElementRef, Renderer2, ViewContainerRef, Injector, AfterViewInit, Self, Optional, ViewChild, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import classNames from 'classnames';
import * as _ from "lodash";

export type ChoiceSize = 'small';
export type ChoiceType = 'checkbox' | 'radio';
export type ChoiceValue = number | string;

export interface ChoiceProps {
  checked?: boolean;
  checkedChildred?: any;
  uncheckedChildren?: any;
  className?: string;
  inputClassName?: string;
  label?: any;
  labelClassName?: string;
  defaultChecked?: boolean;
  disabled?: boolean;
  hint?: any;
  id?: string;
  requirementLabel?: any;
  isRequired?: boolean;
  inversed?: boolean;
  size?: string;
  name?: string;
  onBlur?: (...args: any[]) => any;
  onChange?: (choice: any, event: any) => any;
  type?: ChoiceType;
  value: ChoiceValue;
  formControlName?: string;
  anticipatoryText?: string;
}

@Component({
  selector: 'cms-choice',
  templateUrl: './choice.component.html',
  styleUrls: ['./choice.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ChoiceComponent implements OnInit, OnDestroy, AfterViewInit {

  /**
   * Sets the input's `checked` state. Use this in combination with `onChange`
   * for a controlled component; otherwise, set `defaultChecked`.
   */
  @Input() checked?: boolean;
  /**
   * Content to be shown when the choice is checked. See
   * **Checked children and the expose within pattern** on
   * the Guidance tab for detailed instructions.
   */
  @Input() checkedChildren?: any;
  /**
   * Content to be shown when the choice is not checked
   */
  @Input() uncheckedChildren?: any;
  /**
   * Additional classes to be added to the root `div` element.
   */
  @Input() className?: string;
  /**
   * Additional classes to be added to the `input` element.
   */
  @Input() inputClassName?: string;
  /**
   * Label text or HTML.
   */
  @Input() label?: any;
  /**
   * Additional classes to be added to the `FormLabel`.
   */
  @Input() labelClassName?: string;
  /**
   * Sets the initial `checked` state. Use this for an uncontrolled component;
   * otherwise, use the `checked` property.
   */
  @Input() defaultChecked?: boolean;
  @Input() disabled?: boolean;
  /**
   * Additional hint text to display below the choice's label
   */
  @Input() hint?: any;
  /**
   * A unique ID to be used for the input field, as well as the label's
   * `for` attribute. A unique ID will be generated if one isn't provided.
   */
  @Input() id?: string;
  /**
   * Text showing the requirement ("Required", "Optional", etc.). See [Required and Optional Fields]({{root}}/guidelines/forms/#required-and-optional-fields).
   */
  @Input() requirementLabel?: any;
  @Input() isRequired?: boolean;
  @Input() ariaRequired?: boolean;
  /**
   * Applies the "inverse" UI theme
   */
  @Input() inversed?: boolean;
  @Input() size?: ChoiceSize;
  /**
   * The `input` field's `name` attribute
   */
  @Input() name?: string;
  @Input() onBlur?: (...args: any[]) => any;
  @Input() onChange?: (choice: any, event: any) => any;
  /**
   * Sets the type to render `checkbox` fields or `radio` buttons
   */
  @Input() type?: ChoiceType;
  /**
   * The `input` `value` attribute
   */
  @Input() value?: ChoiceValue;
  @Input() anticipatoryText?: String;

  /**
 * Used in conjunction with formGroup to associate angular form
 * @param  {string;} formControlName?
 * @returns string
 */
  @Input() formControlName?: string;
  @Input() formGroupName?: string;
  @Input() parentGroup?: UntypedFormGroup;
  @ViewChild('choiceInput', { read: ElementRef }) inputRef?: ElementRef;
  @ViewChild('rootChoiceDiv', { read: ElementRef }) divRef?: ElementRef;

  isRequiredAria: boolean = false;
  isControlled: boolean = false;
  uncheckEventName?: string;
  checkedSpanElem?: HTMLElement;
  formGroup?: UntypedFormGroup;
  changesSub$?: Subscription;
  statusSub$?: Subscription;

  constructor(@Self() @Optional() public ngControl: NgControl, private elementRef: ElementRef, private renderer: Renderer2,
    private vcr: ViewContainerRef, private injector: Injector, private cdr: ChangeDetectorRef,
    @Optional() private formGroupDirective?: FormGroupDirective) {
    if (this.ngControl) {
      // Note: we provide the value accessor through here, instead of
      // the `providers` to avoid running into a circular import.
      // And we use NOOP_VALUE_ACCESSOR so checkbox doesn't do anything with NgControl
      this.ngControl.valueAccessor = NOOP_VALUE_ACCESSOR;
      this.statusSub$ = this.ngControl.statusChanges?.subscribe(status => {
        setTimeout(() => {
          if (this.inputRef) {
            this.renderer.setProperty(
              this.inputRef.nativeElement,
              'disabled',
              status === 'DISABLED'
            );
          }
        });
      });
    }
    else if (this.formGroupDirective) {
      this.formGroup = this.formGroupDirective.form;
    }
  }

  ngOnInit(): void {
    type OmitProps = 'size' | 'type' | 'value' | 'label' | 'checked'
      | 'defaultChecked' | 'onBlur' | 'onChange' | 'name' | 'id' | 'className' | 'disabled';

    this.id = this.id || _.uniqueId(this.type + '_' + this.name + '_');

    if (this.formGroup && this.formControlName && this.formGroupName && this.formGroup.get([this.formGroupName, this.formControlName])) {
      let control = this.formGroup.get([this.formGroupName, this.formControlName]);
      if (this.type === 'checkbox') {
        this.checked = control?.value;
        this.changesSub$ = control?.valueChanges.subscribe(changes => {
          this.checked = control?.value;
        });
      }
      else {
        this.checked = (control?.value === this.value);
        this.changesSub$ = control?.valueChanges.subscribe(changes => {
          if (this.inputRef?.nativeElement) {
            if (this.value === changes) {
              this.renderer.setAttribute(this.inputRef?.nativeElement, 'checked', '');
              this.checked = true;
            }
            else {
              this.renderer.removeAttribute(this.inputRef?.nativeElement, 'checked');
              this.checked = false;
            }
          }
        });
      }

      if (control?.hasValidator(Validators.required) || control?.hasValidator(Validators.requiredTrue)) {
        if (this.isRequired === undefined) {
          this.isRequired = true;
        }
        this.isRequiredAria = true;
      }
      this.statusSub$ = control?.statusChanges?.subscribe((status) => {
        setTimeout(() => {
          if (this.inputRef) {
            this.renderer.setProperty(
              this.inputRef.nativeElement,
              'disabled',
              status === 'DISABLED'
            );
          }
        });
      });
    }
    else if (this.parentGroup && this.formControlName && this.parentGroup.controls[this.formControlName]) {
      let control = this.parentGroup.get([this.formControlName]);
      if (this.type === 'checkbox') {
        this.checked = control?.value;
        this.changesSub$ = control?.valueChanges.subscribe(changes => {
          this.checked = control?.value;
        });
      }
      else {
        this.checked = (control?.value === this.value);
        this.changesSub$ = control?.valueChanges.subscribe(changes => {
          if (this.inputRef?.nativeElement) {
            if (this.value === changes) {
              this.renderer.setAttribute(this.inputRef?.nativeElement, 'checked', '');
              this.checked = true;
            }
            else {
              this.renderer.removeAttribute(this.inputRef?.nativeElement, 'checked');
              this.checked = false;
            }
          }
        });
      }

      if (control?.hasValidator(Validators.required) || control?.hasValidator(Validators.requiredTrue)) {
        if (this.isRequired === undefined) {
          this.isRequired = true;
        }
        this.isRequiredAria = true;
      }
      this.statusSub$ = control?.statusChanges?.subscribe((status) => {
        setTimeout(() => {
          if (this.inputRef) {
            this.renderer.setProperty(
              this.inputRef.nativeElement,
              'disabled',
              status === 'DISABLED'
            );
          }
        });
      });
    }
    else if (this.formGroup && this.formControlName && this.formGroup.controls[this.formControlName]) {
      let control = this.formGroup.controls[this.formControlName];
      if (this.type === 'checkbox') {
        this.checked = control?.value;
        this.changesSub$ = control?.valueChanges.subscribe(changes => {
          this.checked = control?.value;
        });
      }
      else {
        this.checked = (control?.value === this.value);
        this.changesSub$ = control?.valueChanges.subscribe(changes => {
          if (this.inputRef?.nativeElement) {
            if (this.value === changes) {
              this.renderer.setAttribute(this.inputRef?.nativeElement, 'checked', '');
              this.checked = true;
            }
            else {
              this.renderer.removeAttribute(this.inputRef?.nativeElement, 'checked');
              this.checked = false;
            }
          }
        });
      }

      if (control?.hasValidator(Validators.required) || control?.hasValidator(Validators.requiredTrue)) {
        if (this.isRequired === undefined) {
          this.isRequired = true;
        }
        this.isRequiredAria = true;
      }
      this.statusSub$ = control?.statusChanges?.subscribe((status) => {
        setTimeout(() => {
          if (this.inputRef) {
            this.renderer.setProperty(
              this.inputRef.nativeElement,
              'disabled',
              status === 'DISABLED'
            );
          }
        });
      });
    }
    else if (this.ngControl && this.ngControl.value) {
      if (this.type === 'checkbox') {
        this.checked = this.ngControl.value;
        this.changesSub$ = this.ngControl.valueChanges?.subscribe(change => {
          this.checked = this.ngControl.value;
        });
      }
      else {
        this.checked = (this.ngControl.value === this.value);
      }
      if (this.ngControl?.control?.hasValidator(Validators.required) || this.ngControl?.control?.hasValidator(Validators.requiredTrue)) {
        if (this.isRequired === undefined) {
          this.isRequired = true;
        }
        this.isRequiredAria = true;
      }
    }

    if (typeof this.checked === 'undefined') {
      this.isControlled = false;
    }
    else {
      this.isControlled = true;
    }
    this.updateInput();
  }

  ngAfterViewInit(): void {
    if (!this.isControlled && this.inputRef?.nativeElement) {
      if (this.defaultChecked) {
        this.renderer.setAttribute(this.inputRef?.nativeElement, 'checked', 'true');
        this.renderer.setProperty(this.inputRef?.nativeElement, 'checked', true);
      }
      else {
        this.renderer.setAttribute(this.inputRef?.nativeElement, 'checked', 'false');
        this.renderer.setProperty(this.inputRef?.nativeElement, 'checked', false);
      }
    }

    if (this.isControlled) {
      this.updateCheckBoxView();
    }

    this.updateCheckedChildren();
  }

  getChildFormGroup(): UntypedFormGroup {
    return this.parentGroup?.get(this.formGroupName!) as UntypedFormGroup;
  }

  inputClasses = '';
  updateInput() {
    this.inputClasses = classNames(this.inputClassName, 'ds-c-choice', {
      'ds-c-choice--inverse': this.inversed,
      'ds-c-choice--small': this.size === 'small',
    });

    // const elem = this.renderer.createElement('input');
    //TODO: add passed down attributes / properties

    this.renderer.listen(this.elementRef.nativeElement, 'change', (event) => this.handleChange(event));
    this.renderer.listen(this.elementRef.nativeElement, 'blur', (event) => this.handleBlur(event));
  }

  updateCheckedChildren() {
    if (this.checkedSpanElem) {
      this.renderer.removeChild(this.divRef?.nativeElement, this.checkedSpanElem);
    }
    if (this.isChecked() && this.checkedChildren) {
      this.checkedSpanElem = this.renderer.createElement('span');
      const textElem = this.renderer.createText(this.checkedChildren);
      this.renderer.appendChild(this.checkedSpanElem, textElem);
      this.renderer.appendChild(this.divRef?.nativeElement, this.checkedSpanElem)
    }
    else if (!this.isChecked() && this.uncheckedChildren) {
      this.checkedSpanElem = this.renderer.createElement('span');
      const textElem = this.renderer.createText(this.uncheckedChildren);
      this.renderer.appendChild(this.checkedSpanElem, textElem);
      this.renderer.appendChild(this.divRef?.nativeElement, this.checkedSpanElem)
    }
  }

  ngOnDestroy(): void {
    this.changesSub$?.unsubscribe();
    this.statusSub$?.unsubscribe();
  }

  isChecked(): boolean {
    if (this.isControlled) {
      return this.checked ? this.checked : false;
    }
    return this.inputRef?.nativeElement.getAttribute('checked') !== null;
  }

  /**
   * A radio button doesn't receive an onChange event when it is unchecked,
   * so we fire an "uncheck" event when any radio option is selected. This
   * allows us to check each radio options' checked state.
   * @param {String} checkedId - ID of the checked radio option
   */
  handleUncheck(checkedId: string): void {
    let checkedAttr = this.inputRef?.nativeElement.getAttribute('checked') !== null;
    if (checkedId !== this.id && checkedAttr) {
      this.checked = false;
      this.inputRef?.nativeElement.removeAttribute('checked');
      this.ngControl?.control?.setValue(false);
      this.ngControl?.control?.markAsDirty();
    }
    this.updateCheckedChildren();
  }

  handleChange(evt: any): void {
    if (this.ngControl) {
      if (this.type === 'checkbox') {
        this.ngControl.control?.setValue(evt.target.checked);
      }
      else {
        this.ngControl.control?.setValue(this.value);
      }
      this.ngControl.control?.markAsDirty();
    }
    else if (this.formGroup && this.formControlName && this.formGroupName &&
      this.formGroup.get([this.formGroupName, this.formControlName])) {
      const control = this.formGroup.get([this.formGroupName, this.formControlName]);
      if (this.type === 'checkbox') {
        this.formGroup.patchValue({
          [this.formGroupName]: {
            [this.formControlName]: evt.target.checked
          }
        });
      }
      else {
        control?.setValue(this.value);
      }
      control?.markAsDirty();
    }
    else if (this.parentGroup && this.formControlName &&
      this.parentGroup.controls[this.formControlName]) {
      if (this.type === 'checkbox') {
        this.parentGroup.patchValue({
          [this.formControlName]: evt.target.checked
        });
      }
      else {
        this.parentGroup.get(this.formControlName)?.setValue(this.value);
      }
      this.parentGroup.controls[this.formControlName].markAsDirty();
    }
    else if (this.formGroup && this.formControlName &&
      this.formGroup.controls[this.formControlName]) {
      if (this.type === 'checkbox') {
        this.formGroup.patchValue({
          [this.formControlName]: evt.target.checked
        });
      }
      else {
        this.formGroup.get(this.formControlName)?.setValue(this.value);
      }
      this.formGroup.controls[this.formControlName].markAsDirty();
    }

    if (this.onChange) {
      this.onChange({ id: this.id, name: this.name, value: this.value }, evt);
    }
    if (!this.isControlled && this.inputRef?.nativeElement) {
      if (evt.target.checked) {
        this.inputRef?.nativeElement.setAttribute('checked', '');
      }
      else {
        this.inputRef?.nativeElement.removeAttribute('checked');
      }
    }
    this.updateCheckedChildren();
  }

  handleBlur(evt: any): void {
    if (this.ngControl) {
      this.ngControl.control?.markAsTouched();
    }
    else if (this.formGroup && this.formControlName && this.formGroupName &&
      this.formGroup.get([this.formGroupName, this.formControlName])) {
      const control = this.formGroup.get([this.formGroupName, this.formControlName]);
      control?.markAsTouched();
    }
    else if (this.formGroup && this.formControlName &&
      this.formGroup.controls[this.formControlName]) {
      this.formGroup.controls[this.formControlName].markAsTouched();
    }
    if (this.onBlur) {
      this.onBlur(evt);
    }
  }

  updateCheckBoxView() {
    if (this.inputRef?.nativeElement) {
      if (this.checked) {
        this.renderer?.setAttribute(this.inputRef?.nativeElement, 'checked', '');
      }
      else {
        this.renderer?.removeAttribute(this.inputRef?.nativeElement, 'checked');
      }
    }
  }
}
