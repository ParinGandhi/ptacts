import { ChangeDetectorRef, Component, Input, OnChanges, Output, SimpleChanges, EventEmitter, Renderer2, ElementRef } from '@angular/core';
import classNames from 'classnames';
import * as _ from "lodash";
import { AlertProps } from '../alert/alert.component';

@Component({
  selector: 'cms-alerts',
  templateUrl: './alerts.component.html',
  styleUrls: ['./alerts.component.css']
})
export class AlertsComponent implements OnChanges {

  @Input() className?: string;
  @Input() alerts?: AlertProps[] = [];
  @Output() closeEmitter = new EventEmitter<string>();

  public classes?: string;

  constructor(
    private cdr: ChangeDetectorRef, 
    private renderer: Renderer2, 
    private el: ElementRef
  ) { }

  ngOnInit(): void {
    this.classes = classNames(
      this.className
    );
    const hasRoleAttribute = this.el.nativeElement.hasAttribute('role');
    if (!hasRoleAttribute) {
      this.renderer.setAttribute(this.el.nativeElement, 'role', 'alert');
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.alerts?.forEach((alert) => {
      if (!alert.headingId) {
        alert.headingId = _.uniqueId('alerts_alert_');
      }
      if (!alert.autoFocus) {
        alert.autoFocus = false;
      }
    });
  }
  /**
   * remove alert by headingId
   * @param  {string} id
   */
  removeAlert(id: string) {
    this.alerts?.splice(this.alerts.findIndex((elem: AlertProps) => elem.headingId === id), 1);
    this.cdr.detectChanges();
    this.closeEmitter.emit(id);
  }
}
