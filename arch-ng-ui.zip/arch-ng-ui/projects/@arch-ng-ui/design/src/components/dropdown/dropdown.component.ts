import { NOOP_VALUE_ACCESSOR } from './../text-field/text-input.component';
import { NgControl, UntypedFormGroup, AbstractControl } from '@angular/forms';
import {
  Component,
  Input,
  OnInit,
  ElementRef,
  AfterViewInit,
  OnChanges,
  SimpleChanges,
  Self,
  Optional,
  ViewChild,
  ChangeDetectorRef,
  AfterContentInit,
} from '@angular/core';
import {
  FormControlComponent,
  FormControlPropKeys,
} from '../form-control/form-control.component';
import { SelectComponent } from './select.component';
import { errorPlacementDefault } from '../flags';
import * as _ from 'lodash';

export type DropdownDefaultValue = number | string;
export interface DropdownOptions {
  label: any;
  value: number | string;
  ariaLabel?: string; 
}
export type DropdownSize = 'small' | 'medium';
export type DropdownValue = number | string;
export type DropdownErrorPlacement = 'top' | 'bottom';

@Component({
  selector: 'cms-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css'],
})
export class DropdownComponent
  implements OnInit, AfterViewInit, OnChanges, AfterContentInit
{
  /**
   * Adds `aria-label` attribute. When using `aria-label`, `label` should be empty string.
   */
  @Input() ariaLabel?: string;

  /**
   * Adds `aria-labelledby` attribute.
   */
  @Input() ariaLabelledby?: string;

  /**
   * Adds `aria-describedby` attribute.
   */
  @Input() ariaDescribedby?: string;

  /**
   * Adds `aria-required` attribute.
   */
   @Input() ariaRequired?: boolean;

  /**
   * Additional classes to be added to the root element.
   */
  className?: string;

  /**
   * Sets the initial selected state. Use this for an uncontrolled component;
   * otherwise, use the `value` property.
   */
  @Input() defaultValue?: DropdownDefaultValue;

  /**
   * Disables the entire field.
   */
  @Input() disabled?: boolean;
  @Input() errorMessage?: any;

  /**
   * Additional classes to be added to the error message
   */
  @Input() errorMessageClassName?: string;

  /**
   * Location of the error message relative to the field input
   */
  @Input() errorPlacement?: DropdownErrorPlacement;

  /**
   * Additional classes to be added to the select element
   */
  @Input() fieldClassName?: string;

  /**
   * Used to focus `select` on `componentDidMount()`
   */
  @Input() focusTrigger?: boolean;

  /**
   * Additional hint text to display
   */
  @Input() hint?: any;

  /**
   * A unique ID to be used for the dropdown field. If one isn't provided, a unique ID will be generated.
   */
  @Input() id?: string;

  /**
   * Applies the "inverse" UI theme
   */
  @Input() inversed?: boolean;

  /**
   * Label for the field. If using `Dropdown` without a label, provide an empty string for `label` and use the `ariaLabel` prop instead.
   */
  @Input() label?: any;

  /**
   * Additional classes to be added to the `FormLabel`.
   */
  @Input() labelClassName?: string;

  /**
   * The field's `name` attribute
   */
  @Input() name?: string;

  /**
   * The list of options to be rendered. Provide an empty list if using custom options via the `children` prop.
   */
  @Input() options?: DropdownOptions[];
  @Input() onBlur?: (...args: any[]) => any;
  @Input() onChange?: (...args: any[]) => any;

  /**
   * Text showing the requirement ("Required", "Optional", etc.). See [Required and Optional Fields]({{root}}/guidelines/forms/#required-and-optional-fields).
   */
  @Input() requirementLabel?: any;
  @Input() isRequired?: boolean;

  /**
   * If the component renders a select, set the max-width of the input either to `'small'` or `'medium'`.
   */
  @Input() size?: DropdownSize;

  /**
   * Sets the field's `value`. Use this in combination with `onChange`
   * for a controlled component; otherwise, set `defaultValue`.
   */
  @Input() value?: DropdownValue;

  /**
   * Used in conjunction with formGroup to associate angular form
   * @param  {string;} formControlName?
   * @returns string
   */
  @Input() formControlName?: string;
  @Input() parentGroup?: UntypedFormGroup;

  @ViewChild('formRef') formComponent?: FormControlComponent;
  @ViewChild('dropdownSelectRef') selectComponent?: SelectComponent;
  @ViewChild('dropdownSelectRef', { read: ElementRef }) selectRef?: ElementRef;

  content?: string;
  formControlElem?: HTMLElement;
  selectElem?: HTMLElement;
  containerProps: any[] = [];
  inputOnlyProps: any[] = [];

  constructor(
    @Self() @Optional() public ngControl: NgControl,
    private cdr: ChangeDetectorRef
  ) {
    if (this.ngControl) {
      // Note: we provide the value accessor through here, instead of
      // the `providers` to avoid running into a circular import.
      // And we use NOOP_VALUE_ACCESSOR so TextField doesn't do anything with NgControl
      this.ngControl.valueAccessor = NOOP_VALUE_ACCESSOR;
    }
  }

  ngOnInit(): void {
    // Sort attributes in component
    const OmitProps = [
      'size',
      'value',
      'label',
      'className',
      'children',
      'defaultValue',
      'disabled',
      'id',
      'name',
      'onBlur',
      'onChange',
    ];

    this.errorPlacement = this.errorPlacement || errorPlacementDefault();

    this.updateFormControl();
    this.updateSelect();

    if (this.ngControl) {
      setTimeout(() => {
        this.checkIfIsRequired();
      });
    }
  }

  ngAfterViewInit(): void {
    if (this.formComponent) {
      setTimeout(() => {
        if (this.selectRef?.nativeElement) {
          this.formComponent?.labelRef?.labelRoot?.nativeElement.after(
            this.selectRef.nativeElement
          );
          if (
            this.errorPlacement === 'bottom' &&
            this.formComponent?.bottomErrorRef?.nativeElement
          ) {
            this.selectRef.nativeElement.after(
              this.formComponent?.bottomErrorRef?.nativeElement
            );
          }
        }
      });
    }
  }

  ngAfterContentInit(): void {
    this.cdr.detectChanges();
  }

  checkIfIsRequired() {
    if (this.isRequired === undefined && this.ngControl?.control?.validator) {
      let validator = this.ngControl.control.validator({} as AbstractControl);
      if (validator && validator['required']) {
        this.isRequired = true;
      } else {
        this.isRequired = false;
      }
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['value'] && this.selectComponent) {
      this.selectComponent.value = changes['value'].currentValue;
    }
    if (changes['options'] && this.selectComponent) {
      this.selectComponent.options = changes['options'].currentValue;
    }
  }

  updateFormControl() {
    const containerProps: any = _.pick(this, FormControlPropKeys);

    if (this.formComponent) {
      Object.entries(containerProps).forEach(([key, value]) => {
        Object.assign(this.formComponent!, { [key]: value });
      });
    }
  }

  updateSelect() {
    const SelectOmitProps = [
      'vcr',
      'elementRef',
      'renderer',
      'injector',
      '__ngContext__',
      'inputOnlyProps',
      'containerProps',
    ];
    const inputOnlyProps = _.omit(this, [
      ...FormControlPropKeys,
      ...SelectOmitProps,
    ]);

    if (this.selectComponent) {
      Object.entries(inputOnlyProps).forEach(([key, value]) => {
        Object.assign(this.selectComponent!, { [key]: value });
      });
    }
    if (this.formControlName && this.selectComponent) {
      this.selectComponent.formControlName = this.formControlName;
    }
  }
}
