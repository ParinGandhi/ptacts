import { Component, Input, OnInit } from '@angular/core';
import classNames from 'classnames';

@Component({
  selector: 'cms-image-icon',
  template: `<cms-svg-icon [className]="iconCssClasses" [ariaHidden]="ariaHidden"
                [description]="description"
                [id]="id"
                [inversed]="inversed"
                [title]="title"
                [viewBox]="viewBox">
              <svg:path
                d="M15 0c.555 0 1 .445 1 1v10c0 .555-.445 1-1 1H1c-.555 0-1-.445-1-1V1c0-.555.445-1 1-1h14zM3.5 2C2.664 2 2 2.664 2 3.5S2.664 5 3.5 5 5 4.336 5 3.5 4.336 2 3.5 2zM14 10l-4-6-3.664 4.664L4 7l-2 3h12z"
                fillRule="nonzero" />
            </cms-svg-icon>`,
  styles: []
})
export class ImageIconComponent implements OnInit {

  @Input() ariaHidden?: boolean;
  @Input() className?: string;
  @Input() description?: string;
  @Input() id?: string;
  @Input() inversed?: boolean;
  @Input() title?: string = 'Image';
  @Input() viewBox?: string = '0 0 16 12';

  iconCssClasses?: string;

  constructor() {
      // This is intentional
  }

  ngOnInit(): void {
    this.iconCssClasses = classNames('ds-c-icon--image', this.className);
  }
}
