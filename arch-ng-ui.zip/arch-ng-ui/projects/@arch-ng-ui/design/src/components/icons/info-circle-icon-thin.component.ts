import { Component, Input, OnInit } from '@angular/core';
import classNames from 'classnames';

@Component({
  selector: 'cms-info-circle-icon-thin',
  template: `<cms-svg-icon [className]="iconCssClasses" [ariaHidden]="ariaHidden"
                [description]="description"
                [id]="id"
                [inversed]="inversed"
                [title]="title"
                [viewBox]="viewBox">
              <svg:path
                d="M8 16c-4.4 0-8-3.6-8-8s3.6-8 8-8 8 3.6 8 8-3.6 8-8 8zm1-3.7V6.4H7v5.9h2zM7 4.9c0 .6.3.9 1 .9s1-.3 1-.9c0-.3-.1-.5-.2-.7-.2-.1-.5-.2-.8-.2-.3 0-.6.1-.8.2-.1.2-.2.4-.2.7z"
                fillRule="nonzero" />
            </cms-svg-icon>`,
  styles: []
})
export class InfoCircleIconThinComponent implements OnInit {

  @Input() ariaHidden?: boolean;
  @Input() className?: string;
  @Input() description?: string;
  @Input() id?: string;
  @Input() inversed?: boolean;
  @Input() title?: string = 'Information';
  @Input() viewBox?: string = '0 0 16 16';

  iconCssClasses?: string;

  constructor() {
      // This is intentional
  }

  ngOnInit(): void {
    this.iconCssClasses = classNames('ds-c-icon--info-circle-thin', this.className);
  }
}
