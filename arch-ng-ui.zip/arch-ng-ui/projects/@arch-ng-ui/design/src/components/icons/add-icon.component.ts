import { Component, Input, OnInit } from '@angular/core';
import classNames from 'classnames';

@Component({
  selector: 'cms-add-icon',
  template: `<cms-svg-icon [className]="iconCssClasses" [ariaHidden]="ariaHidden"
                [description]="description"
                [id]="id"
                [inversed]="inversed"
                [title]="title"
                [viewBox]="viewBox">
              <svg:path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" />
            </cms-svg-icon>`,
  styles: []
})
export class AddIconComponent implements OnInit {

  @Input() ariaHidden?: boolean;
  @Input() className?: string;
  @Input() description?: string;
  @Input() id?: string;
  @Input() inversed?: boolean;
  @Input() title?: string = 'Add';
  @Input() viewBox?: string = '3 3 18 18';

  iconCssClasses?: string;

  constructor() {
    // This is intentional
  }

  ngOnInit(): void {
    this.iconCssClasses = classNames('ds-c-icon--add', this.className);
  }
}
