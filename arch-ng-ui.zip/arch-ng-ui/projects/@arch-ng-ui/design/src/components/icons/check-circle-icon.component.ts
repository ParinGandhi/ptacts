import { Component, Input, OnInit } from '@angular/core';
import classNames from 'classnames';

@Component({
  selector: 'cms-check-circle-icon',
  template: `<cms-svg-icon [className]="iconCssClasses" [ariaHidden]="ariaHidden"
                [description]="description"
                [id]="id"
                [inversed]="inversed"
                [title]="title"
                [viewBox]="viewBox">
                  <svg:path
                    d="M162.18 41.592c-5.595-9.586-13.185-17.176-22.771-22.771-9.588-5.595-20.055-8.392-31.408-8.392-11.352 0-21.822 2.797-31.408 8.392-9.587 5.594-17.177 13.184-22.772 22.771-5.596 9.587-8.393 20.057-8.393 31.408 0 11.352 2.798 21.82 8.392 31.408 5.595 9.585 13.185 17.176 22.772 22.771 9.587 5.595 20.056 8.392 31.408 8.392s21.822-2.797 31.408-8.392c9.586-5.594 17.176-13.185 22.771-22.771 5.594-9.587 8.391-20.057 8.391-31.408 0-11.352-2.797-21.822-8.39-31.408zm-13.608 21.876l-44.239 44.239c-1.032 1.032-2.281 1.549-3.748 1.549-1.412 0-2.634-.517-3.666-1.549L67.425 78.215c-.977-.979-1.466-2.199-1.466-3.666 0-1.521.488-2.771 1.466-3.749l7.414-7.332c1.033-1.032 2.254-1.548 3.667-1.548s2.635.516 3.667 1.548l18.413 18.413 33.241-33.16c1.032-1.032 2.254-1.548 3.666-1.548 1.411 0 2.635.516 3.666 1.548l7.414 7.333c.979.977 1.467 2.226 1.467 3.747 0 1.467-.488 2.689-1.468 3.667z" />
            </cms-svg-icon>`,
  styles: []
})
export class CheckCircleIconComponent implements OnInit {

  @Input() ariaHidden?: boolean;
  @Input() className?: string;
  @Input() description?: string;
  @Input() id?: string;
  @Input() inversed?: boolean;
  @Input() title?: string = 'Checkmark in circle';
  @Input() viewBox?: string = '38 7 135 135';

  iconCssClasses?: string;

  constructor() {
      // This is intentional
  }

  ngOnInit(): void {
    this.iconCssClasses = classNames('ds-c-icon--check-circle', this.className);
  }
}
