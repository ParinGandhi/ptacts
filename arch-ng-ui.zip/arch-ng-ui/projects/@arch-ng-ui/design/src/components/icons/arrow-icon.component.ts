import { Component, Input, OnInit } from '@angular/core';
import classNames from 'classnames';

export type ArrowIconDirectionType = 'up' | 'down' | 'left' | 'right';

@Component({
  selector: 'cms-arrow-icon',
  template: `<cms-svg-icon [className]="iconCssClasses" [ariaHidden]="ariaHidden"
                [description]="description"
                [id]="id"
                [inversed]="inversed"
                [title]="title"
                [viewBox]="viewBox">
              <svg:path fill="currentColor"
        d="M285.476 272.971L91.132 467.314c-9.373 9.373-24.569 9.373-33.941 0l-22.667-22.667c-9.357-9.357-9.375-24.522-.04-33.901L188.505 256 34.484 101.255c-9.335-9.379-9.317-24.544.04-33.901l22.667-22.667c9.373-9.373 24.569-9.373 33.941 0L285.475 239.03c9.373 9.372 9.373 24.568.001 33.941z" />
            </cms-svg-icon>`,
  styles: []
})
export class ArrowIconComponent implements OnInit {

  @Input() ariaHidden?: boolean;
  @Input() className?: string;
  @Input() description?: string;
  @Input() id?: string;
  @Input() inversed?: boolean;
  @Input() title?: string = 'arrow';
  @Input() viewBox?: string = '0 0 320 512';
  @Input() direction?: ArrowIconDirectionType = 'right';

  iconCssClasses?: string;

  constructor() {
      // This is intentional
  }

  ngOnInit(): void {
    this.iconCssClasses = classNames('ds-c-icon--arrow','ds-c-icon--arrow-' + this.direction, this.className);
    this.title = this.direction + ' arrow';
  }
}
