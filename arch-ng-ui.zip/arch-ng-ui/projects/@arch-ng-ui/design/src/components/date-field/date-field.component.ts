import { DateInputComponent } from './date-input.component';
import { defaultDateFormatter } from './defaultDateFormatter';
import { UntypedFormGroup, NgControl } from '@angular/forms';
import { FormControlComponent } from './../form-control/form-control.component';
import {
  Component,
  Input,
  OnInit,
  Optional,
  Self,
  ViewChild,
  ElementRef,
  ComponentRef,
  AfterViewInit,
  AfterContentInit,
  ChangeDetectorRef,
} from '@angular/core';
import classNames from 'classnames';
import { FormControlPropKeys } from '../form-control/form-control.component';
import * as _ from 'lodash';
import { errorPlacementDefault } from '../flags';
import { NOOP_VALUE_ACCESSOR } from '../text-field/text-input.component';

export type DateFieldDayDefaultValue = string | number;
export type DateFieldDayValue = string | number;
export type DateFieldMonthDefaultValue = string | number;
export type DateFieldMonthValue = string | number;
export type DateFieldYearDefaultValue = string | number;
export type DateFieldYearValue = string | number;
export type DateFieldErrorPlacement = 'top' | 'bottom';

export interface DateFieldProps {
  /**
   * Adds `autocomplete` attributes `bday-day`, `bday-month` and `bday-year` to the corresponding `<DateField>` inputs
   */
  autoComplete?: boolean;
  /**
   * Additional classes to be added to the root fieldset element
   */
  className?: string;
  /**
   * Optional method to format the `input` field values. If this
   * method is provided, the returned value will be passed as a second argument
   * to the `onBlur` and `onChange` callbacks. This method receives an object as
   * its only argument, in the shape of: `{ day, month, year }`
   *
   * By default `dateFormatter` will be set to the `defaultDateFormatter` function, which prevents days/months more than 2 digits & years more than 4 digits.
   */
  dateFormatter?: (...args: any[]) => any;
  disabled?: boolean;
  errorMessage?: any;
  /**
   * Additional classes to be added to the error message
   */
  errorMessageClassName?: string;
  /**
   * Location of the error message relative to the field input
   */
  errorPlacement?: DateFieldErrorPlacement;
  /**
   * Additional hint text to display above the individual month/day/year fields
   */
  hint?: any;
  /**
   * Applies the "inverse" UI theme
   */
  inversed?: boolean;
  /**
   * The primary label, rendered above the individual month/day/year fields
   */
  label?: any;
  /**
   * A unique ID to be used for the DateField label. If one isn't provided, a unique ID will be generated.
   */
  labelId?: string;
  /**
   * Text showing the requirement ("Required", "Optional", etc.). See [Required and Optional Fields]({{root}}/guidelines/forms/#required-and-optional-fields).
   */
  requirementLabel?: any;
  /**
   * Called anytime any date input is blurred
   */
  onBlur?: (...args: any[]) => any;
  /**
   * Called when any date input is blurred and the focus does not land on one
   * of the other date inputs inside this component (i.e., when the whole
   * component loses focus)
   */
  onComponentBlur?: (...args: any[]) => any;
  /**
   * Called anytime any date input is changed
   */
  onChange?: (...args: any[]) => any;
  /**
   * Label for the day field
   */
  dayLabel?: any;
  /**
   * `name` for the day `input` field
   */
  dayName?: string;
  /**
   * Initial value for the day `input` field. Use this for an uncontrolled
   * component; otherwise, use the `dayValue` property.
   */
  dayDefaultValue?: DateFieldDayDefaultValue;
  /**
   * Access a reference to the day `input`
   */
  dayFieldRef?: (...args: any[]) => any;
  /**
   * Apply error styling to the day `input`
   */
  dayInvalid?: boolean;
  /**
   * Sets the day input's `value`. Use this in combination with `onChange`
   * for a controlled component; otherwise, set `dayDefaultValue`.
   */
  dayValue?: DateFieldDayValue;
  /**
   * Label for the month field
   */
  monthLabel?: any;
  /**
   * `name` for the month `input` field
   */
  monthName?: string;
  /**
   * Initial value for the month `input` field. Use this for an uncontrolled
   * component; otherwise, use the `monthValue` property.
   */
  monthDefaultValue?: DateFieldMonthDefaultValue;
  /**
   * Access a reference to the month `input`
   */
  monthFieldRef?: (...args: any[]) => any;
  /**
   * Apply error styling to the month `input`
   */
  monthInvalid?: boolean;
  /**
   * Sets the month input's `value`. Use this in combination with `onChange`
   * for a controlled component; otherwise, set `monthDefaultValue`.
   */
  monthValue?: DateFieldMonthValue;
  /**
   * Initial value for the year `input` field. Use this for an uncontrolled
   * component; otherwise, use the `yearValue` property.
   */
  yearDefaultValue?: DateFieldYearDefaultValue;
  /**
   * Access a reference to the year `input`
   */
  yearFieldRef?: (...args: any[]) => any;
  /**
   * Apply error styling to the year `input`
   */
  yearInvalid?: boolean;
  /**
   * Label for the year `input` field
   */
  yearLabel?: any;
  /**
   * `name` for the year field
   */
  yearName?: string;
  /**
   * Sets the year input's `value`. Use this in combination with `onChange`
   * for a controlled component; otherwise, set `yearDefaultValue`.
   */
  yearValue?: DateFieldYearValue;
}

@Component({
  selector: 'cms-date-field',
  templateUrl: './date-field.component.html',
  styleUrls: ['./date-field.component.css'],
})
export class DateFieldComponent
  implements OnInit, AfterViewInit, AfterContentInit
{
  @Input() autoComplete?: boolean;
  @Input() className?: string;
  @Input() dateFormatter?: (...args: any[]) => any = defaultDateFormatter;
  @Input() disabled?: boolean;
  @Input() errorMessage?: any;
  @Input() errorMessageClassName?: string;
  @Input() errorPlacement?: DateFieldErrorPlacement;
  @Input() hint?: any = 'For example 4 / 28 / 1986';
  @Input() inversed?: boolean;
  @Input() label?: any = 'Date';
  @Input() labelId?: string;
  @Input() requirementLabel?: any;
  @Input() isRequired?: boolean;
  @Input() onBlur?: (...args: any[]) => any;
  @Input() onComponentBlur?: (...args: any[]) => any;
  @Input() onChange?: (...args: any[]) => any;
  @Input() dayLabel?: any = 'Day';
  @Input() dayName: string = 'day';
  @Input() dayDefaultValue?: DateFieldDayDefaultValue;
  @Input() dayInvalid?: boolean;
  @Input() dayValue?: DateFieldDayValue;
  @Input() monthLabel?: any = 'Month';
  @Input() monthName: string = 'month';
  @Input() monthDefaultValue?: DateFieldMonthDefaultValue;
  @Input() monthInvalid?: boolean;
  @Input() monthValue?: DateFieldMonthValue;
  @Input() yearDefaultValue?: DateFieldYearDefaultValue;
  @Input() yearInvalid?: boolean;
  @Input() yearLabel?: string = 'Year';
  @Input() yearName: string = 'year';
  @Input() yearValue?: DateFieldYearValue;
  @Input() name?: string;
  @Input() formControlPrefix?: string;
  @Input() formGroupName?: string;
  @Input() parentGroup?: UntypedFormGroup;
  @ViewChild('formRef') formComponent?: FormControlComponent;
  @ViewChild('inputRef', { read: ElementRef }) inputElemRef?: ElementRef;
  @ViewChild('inputRef') inputComponent?: ComponentRef<DateInputComponent>;

  constructor(
    @Self() @Optional() public ngControl: NgControl,
    private cdr: ChangeDetectorRef
  ) {
    if (this.ngControl) {
      this.ngControl.valueAccessor = NOOP_VALUE_ACCESSOR;
    }
  }

  ngOnInit(): void {
    this.errorPlacement = this.errorPlacement || errorPlacementDefault();
    this.updateFormControl();
  }

  ngAfterViewInit(): void {
    // This is intentional
  }

  ngAfterContentInit(): void {
    this.cdr.detectChanges();
  }

  containerClasses = '';
  updateFormControl() {
    const containerProps: any = _.pick(this, FormControlPropKeys);

    this.containerClasses = classNames(
      'ds-u-clearfix', // fixes issue where the label's margin is collapsed
      this.className
    );

    if (this.formComponent) {
      Object.entries(containerProps).forEach(([key, value]) => {
        Object.assign(this.formComponent as any, { [key]: value });
      });
    }
  }
}
