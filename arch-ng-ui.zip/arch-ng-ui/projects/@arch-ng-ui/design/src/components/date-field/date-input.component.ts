import { UntypedFormGroup } from '@angular/forms';
import { TextFieldComponent } from './../text-field/text-field.component';
import { Component, Input, OnInit, ViewChild, ElementRef, OnChanges, SimpleChanges } from '@angular/core';
import { DateObject } from './defaultDateFormatter';
import classNames from 'classnames';

export type DateInputDayDefaultValue = string | number;
export type DateInputDayValue = string | number;
export type DateInputMonthDefaultValue = string | number;
export type DateInputMonthValue = string | number;
export type DateInputYearDefaultValue = string | number;
export type DateInputYearValue = string | number;

export interface DateInputProps {
  /**
   * Adds `autocomplete` attributes `bday-day`, `bday-month` and `bday-year` to the corresponding `<DateInput>` inputs
   */
  autoComplete?: boolean;
  /**
   * Additional classes to be added to the root fieldset element
   */
  className?: string;
  /**
   * Optional method to format the `input` field values. If this
   * method is provided, the returned value will be passed as a second argument
   * to the `onBlur` and `onChange` callbacks. This method receives an object as
   * its only argument, in the shape of: `{ day, month, year }`
   * By default `dateFormatter` will be set to the `defaultDateFormatter` function, which prevents days/months more than 2 digits & years more than 4 digits.
   */
  dateFormatter?: (...args: any[]) => any;
  /**
   * Disables all three input fields.
   */
  disabled?: boolean;
  /**
   * Applies the "inverse" UI theme
   */
  inversed?: boolean;
  /**
   * A unique ID applied to the DateField label.
   */
  labelId: string;
  /**
   * Called anytime any date input is blurred
   */
  onBlur?: (...args: any[]) => any;
  /**
   * Called when any date input is blurred and the focus does not land on one
   * of the other date inputs inside this component (i.e., when the whole
   * component loses focus)
   */
  onComponentBlur?: (...args: any[]) => any;
  /**
   * Called anytime any date input is changed
   */
  onChange?: (...args: any[]) => any;
  /**
   * Label for the day field
   */
  dayLabel: any;
  /**
   * `name` for the day `input` field
   */
  dayName: string;
  /**
   * Initial value for the day `input` field. Use this for an uncontrolled
   * component; otherwise, use the `dayValue` property.
   */
  dayDefaultValue?: DateInputDayDefaultValue;
  /**
   * Access a reference to the day `input`
   */
  dayFieldRef?: (...args: any[]) => any;
  /**
   * Apply error styling to the day `input`
   */
  dayInvalid?: boolean;
  /**
   * Sets the day input's `value`. Use this in combination with `onChange`
   * for a controlled component; otherwise, set `dayDefaultValue`.
   */
  dayValue?: DateInputDayValue;
  /**
   * Label for the month field
   */
  monthLabel: any;
  /**
   * `name` for the month `input` field
   */
  monthName: string;
  /**
   * Initial value for the month `input` field. Use this for an uncontrolled
   * component; otherwise, use the `monthValue` property.
   */
  monthDefaultValue?: DateInputMonthDefaultValue;
  /**
   * Access a reference to the month `input`
   */
  monthFieldRef?: (...args: any[]) => any;
  /**
   * Apply error styling to the month `input`
   */
  monthInvalid?: boolean;
  /**
   * Sets the month input's `value`. Use this in combination with `onChange`
   * for a controlled component; otherwise, set `monthDefaultValue`.
   */
  monthValue?: DateInputMonthValue;
  /**
   * Initial value for the year `input` field. Use this for an uncontrolled
   * component; otherwise, use the `yearValue` property.
   */
  yearDefaultValue?: DateInputYearDefaultValue;
  /**
   * Access a reference to the year `input`
   */
  yearFieldRef?: (...args: any[]) => any;
  /**
   * Apply error styling to the year `input`
   */
  yearInvalid?: boolean;
  /**
   * Label for the year `input` field
   */
  yearLabel: any;
  /**
   * `name` for the year field
   */
  yearName: string;
  /**
   * Sets the year input's `value`. Use this in combination with `onChange`
   * for a controlled component; otherwise, set `yearDefaultValue`.
   */
  yearValue?: DateInputYearValue;
}

@Component({
  selector: 'cms-date-input',
  templateUrl: './date-input.component.html',
  styleUrls: ['./date-input.component.css']
})
export class DateInputComponent implements OnInit {

  @Input() autoComplete?: boolean;
  @Input() className?: string;
  @Input() dateFormatter?: (...args: any[]) => any;
  @Input() disabled?: boolean;
  @Input() inversed?: boolean;
  @Input() labelId?: string;
  @Input() onBlur?: (...args: any[]) => any;
  @Input() onComponentBlur?: (...args: any[]) => any;
  @Input() onChange?: (...args: any[]) => any;
  @Input() dayLabel?: any;
  @Input() dayName: string = 'day';
  @Input() dayDefaultValue?: DateInputDayDefaultValue;
  @Input() dayInvalid?: boolean;
  @Input() dayValue?: DateInputDayValue;
  @Input() monthLabel?: any;
  @Input() monthName: string = 'month';
  @Input() monthDefaultValue?: DateInputMonthDefaultValue;
  @Input() monthInvalid?: boolean;
  @Input() monthValue?: DateInputMonthValue;
  @Input() yearDefaultValue?: DateInputYearDefaultValue;
  @Input() yearInvalid?: boolean;
  @Input() yearLabel?: string;
  @Input() yearName: string = 'year';
  @Input() yearValue?: DateInputYearValue;
  @Input() name?: string;
  @Input() parentGroup?: UntypedFormGroup;
  @Input() formGroupName?: string | null;
  @Input() formControlPrefix?: string = '';
  @Input() isRequired?: boolean;

  @ViewChild('monthFieldRef') monthInput?: TextFieldComponent;
  @ViewChild('monthFieldRef', { read: Element }) monthElement?: Element;
  @ViewChild('dayFieldRef') dayInput?: TextFieldComponent;
  @ViewChild('dayFieldRef', { read: Element }) dayElement?: Element;
  @ViewChild('yearFieldRef') yearInput?: TextFieldComponent;
  @ViewChild('yearFieldRef', { read: Element }) yearElement?: Element;

  constructor() {
    this.handleBlur = this.handleBlur.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  ngOnInit(): void {
    // This is intentional
  }

  buildFormControlName(fieldName: string) {
    if (this.formControlPrefix) {
      return this.formControlPrefix + fieldName;
    }
    else {
      return fieldName;
    }
  }

  getClasses(type: 'day' | 'month' | 'year') {
    return classNames('ds-c-field--' + type, {
      'ds-c-field--error': this[`${type}Invalid`]
    })
  }

  getAutocomplete(type: 'day' | 'month' | 'year') {
    return this.autoComplete && `bday-${type}`;
  }

  getInvalid(type: 'day' | 'month' | 'year') {
    return this[`${type}Invalid`];
  }

  formatDate(): DateObject | undefined {
    if (this.dateFormatter && this.monthInput && this.dayInput && this.yearInput) {
      const values = {
        month: this.monthInput.inputComponent?.inputRoot?.nativeElement.value,
        day: this.dayInput.inputComponent?.inputRoot?.nativeElement.value,
        year: this.yearInput.inputComponent?.inputRoot?.nativeElement.value
      };
      const updatedValues = this.dateFormatter(values);
      // Update the value displayed in the view if formatter has corrected values
      if (updatedValues.month !== this.monthInput.inputComponent?.inputRoot?.nativeElement.value) {
        this.monthInput.inputComponent!.inputRoot!.nativeElement.value = updatedValues.month;
        if (this.monthInput.ngControl) {
          this.monthInput.ngControl.control?.setValue(updatedValues.month);
        }
      }
      if (updatedValues.day !== this.dayInput.inputComponent?.inputRoot?.nativeElement.value) {
        this.dayInput.inputComponent!.inputRoot!.nativeElement.value = updatedValues.day
        if (this.dayInput.ngControl) {
          this.dayInput.ngControl.control?.setValue(updatedValues.day);
        }
      }
      if (updatedValues.year !== this.yearInput.inputComponent?.inputRoot?.nativeElement.value) {
        this.yearInput.inputComponent!.inputRoot!.nativeElement.value = updatedValues.year
        if (this.yearInput.ngControl) {
          this.yearInput.ngControl.control?.setValue(updatedValues.year);
        }
      }
      return updatedValues;
    }
    return;
  }

  handleBlur(evt: any): void {
    if (this.onBlur) {
      this.onBlur(evt, this.formatDate());
    }

    if (this.onComponentBlur) {
      this.handleComponentBlur(evt);
    }
  }

  handleChange(evt: any): void {
    if (this.onChange) {
      this.onChange(evt, this.formatDate());
    }
  }

  handleComponentBlur(evt: any): void {
    // The active element is always the document body during a focus
    // transition, so in order to check if the newly focused element
    // is one of our other date inputs, we're going to have to wait
    // a bit.
    setTimeout(() => {
      if (
        document.activeElement !== this.dayElement &&
        document.activeElement !== this.monthElement &&
        document.activeElement !== this.yearElement
      ) {
        if (this.onComponentBlur) {
          this.onComponentBlur(evt, this.formatDate());
        }
      }
    }, 20);
  }
}
