import { Input, Component, EventEmitter, OnInit, Output, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'cms-banner',
  templateUrl: './banner.component.html',
  styleUrls: ['./banner.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class BannerComponent implements OnInit {

  @Input()  hidden?: boolean = true
  announceToggleBannerEvent: string = "";
  @Output() stateChanged = new EventEmitter<boolean>();

  constructor() {
    // This is intentional
  }

  ngOnInit(): void {
    // This is intentional
  }

  toggleBanner(event: any) {
    this.hidden = !this.hidden;
    this.stateChanged.emit(this.hidden);
  }

}
