import {
  Component,
  OnInit,
  Input,
  ElementRef,
  AfterContentInit,
  ChangeDetectorRef,
} from '@angular/core';
import classNames from 'classnames';
import * as _ from 'lodash';

export interface CardProps {
  /**
   * Additional classes to be added to the root card element.
   */
  className?: string;
  /**
   * A unique `id`, to be used on the rendered card element.
   */
  id: string;
  /**
   * Text to be shown as header, if not set header is removed
   */
  headerLabel?: string;
  /**
   * Location for the error, top of card or after media
   */
  headerPlacement?: 'top' | 'middle';
  /**
   * Text to be shown in button, within footer, if not set button is removed
   */
  buttonLabel?: string;
  /**
   * Called when the card button is clicked, with the following arguments:
   * [`SyntheticEvent`](https://facebook.github.io/react/docs/events.html),
   */
  onClick?: (...args: any[]) => any;
  /**
   * Sets the `href` attribute used for the media. If not set media is not displayed
   */
  mediaHref?: string;
  //TODO: media aria labels
  //TODO: card aria labels
  //TODO: button aria labels
}

@Component({
  selector: 'cms-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css'],
})
export class CardComponent implements OnInit, AfterContentInit {
  @Input() className?: string;
  @Input() id?: string;
  @Input() headerLabel?: string;
  @Input() headerPlacement?: string;
  @Input() buttonLabel?: string;
  @Input() onClick?: (...args: any[]) => any;
  @Input() mediaHref?: string;

  classes: string = '';

  constructor(private elementRef: ElementRef, private cdr: ChangeDetectorRef) {}

  ngOnInit(): void {
    this.id = this.id || _.uniqueId('card_');

    this.headerPlacement = this.headerPlacement || 'middle';
    const classes = classNames(this.className);
    this.elementRef.nativeElement.setAttribute('class', classes);
  }

  ngAfterContentInit(): void {
    this.cdr.detectChanges();
  }

  handleClick = (event: any): void => {
    event.preventDefault();
    if (this.onClick) {
      this.onClick(event);
    }
  };
}
