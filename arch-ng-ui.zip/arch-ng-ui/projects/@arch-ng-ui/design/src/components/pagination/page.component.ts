import { Component, Input, OnInit, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';

export interface PageProps {
  /**
   * Defines the page number.
   */
  index: number;
  /**
   * Renders current page if true, other links if false.
   */
  isActive: boolean;
    /**
   * Focuses on current page if true.
   */
  focusPage: boolean;
  /**
   * A callback function used to handle state changes.
   */
  onPageChange?: (page: number, evt: any) => void;
  /**
   * Defines application-specific routing in url for links.
   */
  href: string;
}

@Component({
  selector: 'cms-page',
  template: `<li #liElem>
                <span *ngIf="isActive"
                  class="ds-c-button ds-c-button--transparent ds-c-pagination__current-page"
                  [attr.tabindex]="0"
                  aria-current="true">
                    <span class="ds-u-visibility--screen-reader">{{ariaLabelPrefix ? 'page ' + index + ' for ' + ariaLabelPrefix : 'page ' + index}}</span>
                    <span aria-hidden="true">{{index}}</span>
                </span>
                <cms-button *ngIf="!isActive"
                  variation="transparent"
                  [href]=href
                  [onClick]="handleClick"
                  [ariaLabel]="ariaLabelPrefix ? 'page ' + index + ' for ' + ariaLabelPrefix : 'page ' + index">
                  <span aria-hidden="true">{{index}}</span>
                </cms-button>
            </li>`,
  styleUrls: ['./page.component.css']
})
export class PageComponent implements OnInit {

  @Input() index!: number;
  @Input() isActive?: boolean;
  @Input() focusPage?: boolean;
  @Input() href?: string;
  @Input() ariaLabelPrefix?: string = '';
  @ViewChild('liElem') liElem?: ElementRef<HTMLElement>;
  @Output() onPageChange = new EventEmitter<number>();

  constructor() {
      // This is intentional
  }

  ngOnInit(): void {
      // This is intentional
  }

  ngAfterViewInit(): void {
    if (this.isActive && this.focusPage) {
      let focusEl = this.liElem?.nativeElement.querySelector<HTMLInputElement>('span');
      focusEl?.focus();
    }
  }

  handleClick = (event: any) => {
    this.onPageChange.emit(this.index);
  }
}
