import { CalendarIconComponent } from './components/icons/calendar-icon.component';
import { NgModule } from '@angular/core';
import { CloseIconMediumComponent } from './components/icons/close-icon-medium.component';
import { RouterModule } from '@angular/router';
import { SearchBarComponent } from './components/search-bar/search-bar.component';
import { TrashIconComponent } from './components/icons/trash-icon.component';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { A11yModule } from '@angular/cdk/a11y';
import { CmsDesign } from './ngx-cms-design.component';
import { TableModule } from 'ngx-easy-table';
import { OverlayModule } from '@angular/cdk/overlay';

import { WhiteHouseLogoComponent } from './components/icons/white-house-logo.component';
import { WarningIconComponent } from './components/icons/warning-icon.component';
import { UsaLogoIconComponent } from './components/icons/usa-logo-icon.component';
import { UsaFlagIconComponent } from './components/icons/usa-flag-icon.component';
import { StarIconComponent } from './components/icons/star-icon.component';
import { PdfIconComponent } from './components/icons/pdf-icon.component';
import { NextIconComponent } from './components/icons/next-icon.component';
import { MenuIconComponent } from './components/icons/menu-icon.component';
import { LockIconComponent } from './components/icons/lock-icon.component';
import { LockCircleIconComponent } from './components/icons/lock-circle-icon.component';
import { InfoCircleIconThinComponent } from './components/icons/info-circle-icon-thin.component';
import { InfoCircleIconComponent } from './components/icons/info-circle-icon.component';
import { ImageIconComponent } from './components/icons/image-icon.component';
import { HhsLogoComponent } from './components/icons/hhs-logo.component';
import { ExternalLinkIconComponent } from './components/icons/external-link-icon.component';
import { DownloadIconComponent } from './components/icons/download-icon.component';
import { Download2IconComponent } from './components/icons/download2-icon.component';
import { CloseIconThinComponent } from './components/icons/close-icon-thin.component';
import { CloseIconComponent } from './components/icons/close-icon.component';
import { CheckIconComponent } from './components/icons/check-icon.component';
import { CheckCircleIconComponent } from './components/icons/check-circle-icon.component';
import { BuildingCircleIconComponent } from './components/icons/building-circle-icon.component';
import { ArrowsStackedComponent } from './components/icons/arrows-stacked.component';
import { ArrowIconComponent } from './components/icons/arrow-icon.component';
import { AlertCircleIconComponent } from './components/icons/alert-circle-icon.component';
import { BadgeComponent } from './components/badge/badge.component';
import { AlertComponent } from './components/alert/alert.component';
import { AlertsComponent } from './components/alerts/alerts.component';
import { ButtonComponent } from './components/button/button.component';
import { DropdownComponent } from './components/dropdown/dropdown.component';
import { SelectComponent } from './components/dropdown/select.component';
import { FormControlComponent } from './components/form-control/form-control.component';
import { FormLabelComponent } from './components/form-label/form-label.component';
import { InlineErrorComponent } from './components/inline-error/inline-error.component';
import { TextFieldComponent } from './components/text-field/text-field.component';
import { TextInputComponent } from './components/text-field/text-input.component';
import { MaskComponent } from './components/text-field/mask.component';
import { ChoicelistComponent } from './components/choicelist/choicelist.component';
import { ChoiceComponent } from './components/choicelist/choice.component';
import { TabsComponent } from './components/tabs/tabs.component';
import { TabComponent } from './components/tabs/tab.component';
import { TabPanelComponent } from './components/tabs/tab-panel.component';
import { CardComponent } from './components/card/card.component';
import { AccordionComponent } from './components/accordion/accordion.component';
import { AccordionItemComponent } from './components/accordion/accordion-item.component';
import { SvgIconComponent } from './components/icons/svg-icon.component';
import { AddIconComponent } from './components/icons/add-icon.component';
import { RemoveIconComponent } from './components/icons/remove-icon.component';
import { MenuIconThinComponent } from './components/icons/menu-icon-thin.component';
import { BreadcrumbComponent } from './components/breadcrumb/breadcrumb.component';
import { PaginationComponent } from './components/pagination/pagination.component';
import { PageComponent } from './components/pagination/page.component';
import { EllipsesComponent } from './components/pagination/ellipses.component';
import { TableComponent } from './components/table/table.component';
import { BannerComponent } from './components/banner/banner.component';
import { DateFieldComponent } from './components/date-field/date-field.component';
import { DateInputComponent } from './components/date-field/date-input.component';
import { AutocompleteComponent } from './components/autocomplete/autocomplete.component';
import { FilterPipe } from './components/autocomplete/filter.pipe';
import { MultiDropdownComponent } from './components/multi-dropdown/multi-dropdown.component';
import { TrimWhitespacePipe } from './components/multi-dropdown/trim-whitespace.pipe';
import { NgSelectModule } from '@ng-select/ng-select';
import { DropdownMenuComponent } from './components/dropdown-menu/dropdown-menu.component';
import { SingleInputDateFieldComponent } from './components/single-input-date-field/single-input-date-field.component';
import { TooltipComponent } from './components/tooltip/tooltip.component';
import { TooltipIconComponent } from './components/tooltip/tooltip-icon.component';
import { CustomDayPickerComponent } from './components/date-field/custom-day-picker.component';

@NgModule({
  declarations: [
    CmsDesign,
    TableComponent,
    BadgeComponent,
    AlertComponent,
    AlertsComponent,
    ButtonComponent,
    DropdownComponent,
    SelectComponent,
    FormControlComponent,
    FormLabelComponent,
    InlineErrorComponent,
    TextFieldComponent,
    TextInputComponent,
    MaskComponent,
    ChoicelistComponent,
    ChoiceComponent,
    TabsComponent,
    TabComponent,
    TabPanelComponent,
    CardComponent,
    AccordionComponent,
    AccordionItemComponent,
    AddIconComponent,
    SvgIconComponent,
    RemoveIconComponent,
    AlertCircleIconComponent,
    ArrowIconComponent,
    ArrowsStackedComponent,
    BuildingCircleIconComponent,
    CheckCircleIconComponent,
    CheckIconComponent,
    CloseIconComponent,
    CloseIconThinComponent,
    CloseIconMediumComponent,
    DownloadIconComponent,
    Download2IconComponent,
    ExternalLinkIconComponent,
    HhsLogoComponent,
    ImageIconComponent,
    InfoCircleIconComponent,
    InfoCircleIconThinComponent,
    LockCircleIconComponent,
    LockIconComponent,
    MenuIconComponent,
    MenuIconThinComponent,
    NextIconComponent,
    PdfIconComponent,
    StarIconComponent,
    UsaFlagIconComponent,
    UsaLogoIconComponent,
    WarningIconComponent,
    TrashIconComponent,
    CalendarIconComponent,
    WhiteHouseLogoComponent,
    BreadcrumbComponent,
    PaginationComponent,
    PageComponent,
    EllipsesComponent,
    BannerComponent,
    DateFieldComponent,
    DateInputComponent,
    AutocompleteComponent,
    FilterPipe,
    MultiDropdownComponent,
    TrimWhitespacePipe,
    DropdownMenuComponent,
    SearchBarComponent,
    SingleInputDateFieldComponent,
    TooltipComponent,
    TooltipIconComponent,
    CustomDayPickerComponent,
  ],
  imports: [
    CommonModule,
    TableModule,
    ReactiveFormsModule,
    OverlayModule,
    NgSelectModule,
    RouterModule.forChild([]),
    A11yModule,
  ],
  providers: [],
  exports: [
    CmsDesign,
    TableComponent,
    BadgeComponent,
    AlertComponent,
    AlertsComponent,
    ButtonComponent,
    SelectComponent,
    FormControlComponent,
    InlineErrorComponent,
    FormLabelComponent,
    DropdownComponent,
    TextFieldComponent,
    TextInputComponent,
    MaskComponent,
    ChoiceComponent,
    ChoicelistComponent,
    TabsComponent,
    TabComponent,
    TabPanelComponent,
    CardComponent,
    AccordionComponent,
    AccordionItemComponent,
    AddIconComponent,
    SvgIconComponent,
    RemoveIconComponent,
    AlertCircleIconComponent,
    ArrowIconComponent,
    ArrowsStackedComponent,
    BuildingCircleIconComponent,
    CheckCircleIconComponent,
    CheckIconComponent,
    CloseIconComponent,
    CloseIconThinComponent,
    CloseIconMediumComponent,
    DownloadIconComponent,
    Download2IconComponent,
    ExternalLinkIconComponent,
    HhsLogoComponent,
    ImageIconComponent,
    InfoCircleIconComponent,
    InfoCircleIconThinComponent,
    LockCircleIconComponent,
    LockIconComponent,
    MenuIconComponent,
    MenuIconThinComponent,
    NextIconComponent,
    PdfIconComponent,
    StarIconComponent,
    UsaFlagIconComponent,
    UsaLogoIconComponent,
    WarningIconComponent,
    TrashIconComponent,
    WhiteHouseLogoComponent,
    BreadcrumbComponent,
    PageComponent,
    PaginationComponent,
    EllipsesComponent,
    BannerComponent,
    DateInputComponent,
    DateFieldComponent,
    AutocompleteComponent,
    MultiDropdownComponent,
    DropdownMenuComponent,
    SearchBarComponent,
    SingleInputDateFieldComponent,
    TooltipComponent,
    TooltipIconComponent,
    CustomDayPickerComponent,
    RouterModule,
  ],
})
export class CmsDesignModule {}
