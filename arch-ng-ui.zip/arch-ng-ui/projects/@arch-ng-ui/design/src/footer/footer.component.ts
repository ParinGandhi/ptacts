import { HeaderService } from '../header/header.service';
import { Component, Inject, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { FooterService } from './footer.service';
import { DOCUMENT } from '@angular/common';

export interface FooterLink {
  label: string;
  url: string;
}

export interface FooterLinkGroup {
  header: string;
  links: FooterLink[];
}

/**
 * This component represents the common footer which is included with
 * every page. Take a look at `app.component.html` to see how it's done
 *
 * @author theanh.ha
 */
@Component({
  selector: 'ffm-ui-footer',
  templateUrl: 'footer.component.html',
  styleUrls: ['footer.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FooterComponent implements OnInit {
  private window: Window | null;

  constructor(private router: Router, public headerService: HeaderService, public footerService: FooterService,
    @Inject(DOCUMENT) private document: Document) {
    this.window = this.document.defaultView;
  }

  ngOnInit(): void {
      // This is intentional
  }

  /**
   * Checks if the path passed in is the active one
   * @param path the URL path to be checked
   */
  isActive(path: string): boolean {
    const splitHref = this.window?.location.href.split('/');
    if (splitHref) {
      const toCompare = splitHref[3];
      if (path === toCompare) {
        return true;
      }
    }

    return false;
  }

  backToTop(): void {
    const element = document.querySelector('.ds-c-skip-nav') as HTMLElement;
    if (element) {
      element.style.top = '0px';
      element.scrollIntoView({ behavior: 'smooth' });
      element.focus();
    }
  }
}
