import { defineConfig } from 'vitest/config';

export default defineConfig(({ mode }) => ({
  test: {
    globals: false,
    setupFiles: [import.meta.dirname + '/vitest.setup.ts'],
    environment: 'jsdom',
    include: ['src/**/*.{test,spec}.{js,ts}'],
    reporters: ['default', 'junit'],
    retry: 0,
    bail: 0,
    watch: false,
    coverage: {
      enabled: true,
      provider: 'istanbul',
      reportOnFailure: true,
      reportsDirectory: './reports/coverage',
    },
    outputFile: {
      junit: './reports/tests.xml',
    },
  },
  define: {
    'import.meta.vitest': mode !== 'production',
  },
}));
