# arch-ng-ui
## Package listing
- arch-ng-ui - root package. not deployed. use this for running sonar
- projects/@arch-ng-ui/formatter - eslint and prettier configs
- projects/@arch-ng-ui/framework - UI framework. angular based
- projects/@arch-ng-ui/testing - vitest config
- projects/@arch-ng-ui/design - UI design / layout code. angular based
