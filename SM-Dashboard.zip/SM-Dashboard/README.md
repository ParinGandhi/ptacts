# FFE-API-Dashboard 3.0


## New release branch creation
- Branch name format: release/x.x
- Submit a request for creating a new release branch in Ansible playbook repo with the name branch name format
- Update the npm version in package.json for in web and lambda according to release branch version. Otherwise, build job will not pass the version guard

## CICD
- Deployment only supports release branches.
- There's an option to deploy ffe-api-config along with dashboard. Default to No. Manually supply the artifact version if deployment needed

## Npmrc file usage in Dev-VM

Removed the hardcoded nexus URL'S in .npmrc file, When testing in Dev-VM need to uncomment the registry. Once testing is complete comment back the registry url & commit to git.

   ```
   registry=http://nxrm.devarch-sspr.mp.cmscloud.local:8080/repository/ffm-npm-all/
   ```
 
## Notes on build (to be added)
