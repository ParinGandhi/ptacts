# Request Templating Design

* Backend needs to ensure request is authenticated/authorized and request is sent to correct endpoint
* How does the request get sent, because it's not being sent directly to the service, but via the backend?
* The backend exposes an endpoint:
    ```
    POST /sm-request
    Payload:
    {
        "application": "DSRS",
        "service": "Get Document Metadata",
        "path": "/document/1234/metadata",
        "headers": [
            "Content-Type: application/json",
            "Foo: Bar"
        ],
        "body": "
            {"foo":"bar"}
        "
    }
    ```
* The backend gets the URL and HTTP method from dynamodb based on the application and service
* The backend adds any required headers like API key, source system name, and request ID
* The backend then forwards the request and passes the response back to the client

Expose the full URL to the UI, or only the service name and request path?
* https://dsrs.example.com/document/metadata
* service: dsrs, path: /document/metadata    <--- use this

Take form fields and request template to prepare request url,headers,body

As long as each dynamodb record/row is <400kb we are good

What the form looks like:
```
Application ID: [_1234___]

Year: [_2020__]

Related App Ids:
    * App Id:      [_2222_____]    [-]
    * App Id:      [_3333_____]    [-]
    *                              [+]

Members:
    * Member:                      [-]
        Name:      [_John Doe_]
        Member ID: [_1________]
    * Member:                      [-]  <-- button to remove member
        Name:      [_Jane Doe_]
        Member ID: [_2________]
    *                              [+]  <-- button to add member
```

Request description:
```
{
    "form": {
        "applicationId": {
            "title": "Application ID",
            "type": "string",
            "required": true,
        },
        "year": {
            "title": "Year",
            "type": "number",
            "required": false,
            "default": "2020"
        },
        "relatedAppIds": {
            "title": "Related App IDs",
            "type": "array",
            "required": false, // true means relatedAppIds must be defined, false means it is optional
            "items": {
                "title": "App ID",
                "type": "string",
                "required": false // true means at least 1 array item, false means can be empty array
            }
        },
        "members": {
            "title": "Members",
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "name": {
                        "title": "Name",
                        "type": "string",
                        "required": true
                    },
                    "memberId": {
                        "title": "Member ID",
                        "type": "number",
                        "required": true
                    }
                }
            },
            "template":
                "
                <% _.map(items, function(item) { %>{"name":"<%- item.name %>","memberId":<%- item.memberId %>}<% }).join(','); %>
                " // something like that
        }
    },
    "headers": [
        "X-User-Id: ${}
    ],
    "body": 
        "
        {
            "applicationId": "${applicationid}",
            "year": ${year},
            "application": {
                "members": [
                    ${members}
                ],
                "plan": ${some.plan.variable}
            }
        }
        ",
    "dereferenceLink": "document.url"
}
```

The template output looks like:
```
{
    "applicationId": "1234",
    "year": 2020,
    "relatedAppIds": {
        "items": ["2222","3333"]
    },

    // IF NO template PROPERTY ON MEMBERS:
    "members": [
        {
            "name": "John Doe",
            "memberId": 1
        },
        {
            "name": "Jane Doe",
            "memberId": 2
        }
    ],

    // IF THERE IS A template PROPERTY ON MEMBERS:
    "members": "{"name":"John Doe","memberId":1},{"name":"Jane Doe","mebmerId":2}"
}
```

* If the request description form item has a template property, use that to generate the template output for that form item
* If the request description form does not have a template property, just use toString on the property (useful for numbers/strings)


Template output gets substituted into request template

