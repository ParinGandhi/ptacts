
# Design

## REST Services

* GET /sm-services
* POST /sm-request

### GET /sm-services
```
{
    "applications": [
        {
            "name": "DSRS",
            "services": [
                {
                    "name": "Get Metadata",
                    "path": "/document/${documentId}/metadata"
                    "template": {...} // Request description as parsed JSON object (see design_template.md)
                },
                { ... }
            ]
        },
        { ... }
    ]
}
```

### POST /sm-request
```
{
    "application": "DSRS",
    "service": "Get Document Metadata",
    "path": "/document/1234/metadata",
    "headers": [
        "Content-Type: application/json",
        "Foo: Bar"
    ],
    "body": "
        {"foo":"bar"}
    "
}
```

## DynamoDB

Table name: sm-dashboard-services

| application | service | root_url | path_regex | path | method | template |
| ----------- | ------- | -------- | ---------- | ---- | ------ | -------- |
| DSRS | Get Metadata | http://dsrs | ^/document/[^/]*/metadata$ | /document/${documentId}/metadata | GET | {...} |

root_url, path_regex, and  method are not sent to the client  
path IS sent to the client  
In order to prevent security vulnerabilites, server should compare path to path_regex

Server combines root_url + path to create final request URL

```
Malicious path sent by client: ../../../etc/passwd
Server creates url: root_url + path
Server creates url: http://dsrs/../../../../etc/passwd
DSRS vulnerability!
Fix:
Server validates path against path_regex: no match - 400 bad request response
```

## Creating the request from the dashboard

When we do string interpolation with the form description, every value is templated into url, request_template.headers, and request_template.body

url is a templated/interpolated string  
All strings in request_template are templated with all values from form_description.

What does a form look like if the template can have a variable number of items in an array? (see design_template.md)


* When we click on submit, how do the values in the form get templated into the request?
* Does the request need any pre-processing before being submitted?
    * (like a request to prepare the state)
    * For example, if the user really cares about request C, but you need to send request A and B first to create the state for C
* For now: only 1 form per endpoint, and only 1 request at a time.
* Future: maybe multiple requests for 1 form (prepare A B C requests), and maybe multiple requests at once (get multiple documents at once on same page)

Request generation requirements:

* Headers
    * Content-type
    * API key
    * User
* Method
* Path (+ query parameters)
    * With optional components, do we want to generate query parameters or template variables into a string?
    * For example:
        ```
        $.get('/application/${appid}/members', {query: {a: 1, b: 2}}) generates /application/1234/mebmers?a=1&b=2
        '/foo/bar?a=${a}&b=${b}' templates to /foo/bar?a=1&b=2
        {query: {a: [1, 2, 3]}} could generate:
            * ?a[]=1&a[]=2&a[]=3
            * ?a=1&a=2&a=3
            * ?a=[1,2,3]
        ```
* Body

_.template (lodash.js template)
Questions: How do we template optional values that haven't been set?


## Displaying the response in the dashboard

Process the response or just display the raw response?
* Just display the raw response, based on the response content-type
* Headers (expand group)
* Body (textarea if text, pretty json/xml if json/xml, img tag if image, pdf.js if pdf, download if other)
    * http://summerstyle.github.io/jsonTreeViewer/
    * https://mozilla.github.io/pdf.js/
    * (find tool for browsing XML in web browser component)


Is there a tool we can use that already has a json form description that can serialize/template the fields into a request?
* Looked at https://github.com/jsonform/jsonform but decided against:
    * Can't use jsonform because it only creates a form, but we need to extend our form with templating features
        * See design_template.md


