import history from 'connect-history-api-fallback';
import express from 'express';
import { createServer } from 'http';
import cors from 'cors';
import pkg from 'body-parser';

const app = express({
  mergeParams: true
});
const port = 8081;
const server = createServer(app);

const allowedHeaders = [
  'Origin',
  'X-Message-Id',
  'Associate-Correlation-Id',
  'Client-Correlation-Id',
  'X-Service-Id',
  'X-Requested-With',
  'Content-Type',
  'Accept',
  'associate-ip-address',
  'appname',
  'appversion',
  'Device',
  'log-level',
  'profileReferenceId',
  'customerReferenceId',
  'channel-type',
  'interactionId',
  'Interaction-Id',
  'operatorid',
  'ssoid',
  'Customer-Reference-Id',
  'Api-Key',
  'Customer-Country',
  'Customer-IP-Address',
  'teller-id',
  'Operator',
  'Initiating-Application',
  'profile_ref_id'
];
app.options('*', cors())
app.use(
  cors({
    allowedHeaders: allowedHeaders,
    exposedHeaders: allowedHeaders,
    origin: '*',
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
    credentials: true,
    preflightContinue: true
  })
);

import capabilities from './cms/capabilities.routes.js';
app.use('/capabilities', capabilities);

import services from './cms/services.routes.js';
app.use('/services', services);

import environment from './cms/environment.routes.js';
app.use('/environment', environment);

import appconfig from './cms/appconfig.routes.js';
app.use('/app_config_services', appconfig);

import s3folderitems from './cms/s3folderitems.routes.js';
app.use('/s3_folder_items', s3folderitems);

import s3filedata from './cms/s3filedata.routes.js';
app.use('/s3_file_data', s3filedata);

import tlSearch from './cms/tl-search.routes.js';
app.use('/tl-search', tlSearch);

app.use(history());
server.listen(port, () => console.log(`Running on ${port}...`));