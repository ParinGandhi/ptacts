import express from 'express'
import pkg from 'body-parser';
import cors from 'cors';
import fs from 'fs'

const { json } = pkg;
const router = express.Router();

var corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200 
}
router.use(pkg.text({type:"*/*"}));

const searchJsonStr = fs.readFileSync("./cms/tl-search.json");
const searchJson = JSON.parse(searchJsonStr);
const resp = searchJson

router.post('/', cors(corsOptions), async (req, res) => {
  setTimeout(() => {
    console.log(new Date(), 'Request received tl-search: ------------------> ', req.baseUrl)
    res.status(200).contentType('application/json').send({
      ...resp
    });
  }, 500);
});

export default router;