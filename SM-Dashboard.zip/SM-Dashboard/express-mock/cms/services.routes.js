import express from 'express'
import pkg from 'body-parser';
import cors from 'cors';
import fs from 'fs'

const { json } = pkg;
const router = express.Router();
const response = {
    "applications": [
        {
            "name": "EE",
            "services": [
                {
                    "name": "Get Benchmark Plans",
                    "path": "/ee-rest/v1/plans/get-benchmark-plans",
                    "body": "{ \"benchmarkCriteria\":[{ \"familyRelationships\": <%= JSON.stringify(familyRelationships) %>,\"legalRelationships\": <%= JSON.stringify(legalRelationships) %>,\"insuranceApplicationIdentifier\": <%= JSON.stringify(insuranceApplicationIdentifier) %>,\"members\": <%= JSON.stringify(members) %>,\"groupCoverageEffectiveStartDate\": <%= JSON.stringify(groupCoverageEffectiveStartDate) %>}]}",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-Id: <%= roleId %>",
                        "<%= partnerId ? \"partner-id: \" + partnerId : \"\"%>",
                        "user-Id: <%= userId %>",
                        "Content-Type:application/json",
                        "x-correlation-id: <%= correlationId %>"
                    ],
                    "formSchema": [
                        {
                            "default": "FFM_SES",
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "SES",
                            "id": "roleId",
                            "title": "Role ID",
                            "type": "string",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "title": "Partner ID",
                            "type": "string",
                            "required": false
                        },
                        {
                            "id": "userId",
                            "title": "User ID",
                            "type": "string",
                            "required": true
                        },
                        {
                            "default": "3b40f6b0-c1b4-11ec-8134-cfb10f58648c",
                            "id": "correlationId",
                            "title": "X-Correlation ID",
                            "type": "correlationId",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "title": "Insurance Application Identifier",
                            "type": "string",
                            "required": true
                        },
                        {
                            "id": "groupCoverageEffectiveStartDate",
                            "title": "Group Coverage Effective Start Date",
                            "type": "string",
                            "required": true
                        },
                        {
                            "item": {
                                "title": "familyRelationships",
                                "type": "object",
                                "items": [
                                    {
                                        "title": "Subordinate Member",
                                        "type": "string",
                                        "id": "subordinateMember"
                                    },
                                    {
                                        "title": "Relationship Type",
                                        "type": "string",
                                        "id": "relationshipType"
                                    },
                                    {
                                        "title": "Superordinate Member",
                                        "type": "string",
                                        "id": "superordinateMember"
                                    }
                                ],
                                "required": true
                            },
                            "id": "familyRelationships",
                            "title": "familyRelationships",
                            "type": "array",
                            "required": true
                        },
                        {
                            "item": {
                                "title": "legalRelationships",
                                "type": "object",
                                "items": [
                                    {
                                        "title": "Subordinate Member",
                                        "type": "string",
                                        "id": "subordinateMember"
                                    },
                                    {
                                        "title": "Relationship Type",
                                        "type": "string",
                                        "id": "relationshipType"
                                    },
                                    {
                                        "title": "Superordinate Member",
                                        "type": "string",
                                        "id": "superordinateMember"
                                    }
                                ],
                                "required": true
                            },
                            "id": "legalRelationships",
                            "title": "legalRelationships",
                            "type": "array",
                            "required": true
                        },
                        {
                            "item": {
                                "title": "Members",
                                "type": "object",
                                "items": [
                                    {
                                        "title": "Application Member Identifier",
                                        "type": "string",
                                        "id": "applicationMemberIdentifier"
                                    },
                                    {
                                        "title": "Contact Requesting Coverage Indicator",
                                        "type": "boolean",
                                        "id": "contactRequestingCoverageIndicator"
                                    },
                                    {
                                        "title": "Sex",
                                        "type": "string",
                                        "id": "sex"
                                    },
                                    {
                                        "title": "Benchmark Type",
                                        "type": "string",
                                        "id": "benchmarkType"
                                    },
                                    {
                                        "id": "residencyAddress",
                                        "title": "Residency Address",
                                        "type": "object",
                                        "items": [
                                            {
                                                "title": "Residency Address Source Type",
                                                "type": "string",
                                                "id": "residencyAddressSourceType"
                                            },
                                            {
                                                "title": "Street Name 1",
                                                "type": "string",
                                                "id": "streetName1"
                                            },
                                            {
                                                "default": "null",
                                                "id": "streetName2",
                                                "title": "Street Name 2",
                                                "type": "string"
                                            },
                                            {
                                                "title": "State Code",
                                                "type": "string",
                                                "id": "stateCode"
                                            },
                                            {
                                                "title": "City Name",
                                                "type": "string",
                                                "id": "cityName"
                                            },
                                            {
                                                "title": "Zip Code",
                                                "type": "string",
                                                "id": "zipCode"
                                            },
                                            {
                                                "title": "County Name",
                                                "type": "string",
                                                "id": "countyName"
                                            },
                                            {
                                                "title": "County Fips Code",
                                                "type": "string",
                                                "id": "countyFipsCode"
                                            }
                                        ],
                                        "required": true
                                    },
                                    {
                                        "title": "Birth Date",
                                        "type": "string",
                                        "id": "birthDate"
                                    },
                                    {
                                        "title": "Coverage Effective Start Date",
                                        "type": "string",
                                        "id": "coverageEffectiveStartDate"
                                    }
                                ],
                                "required": true
                            },
                            "id": "members",
                            "title": "members",
                            "type": "array",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Get Benefits",
                    "path": "/ee-rest/v1/plans/plan-benefits?date=<%=date%>&plans=<%= (planIds.join('%')) %>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-Id: <%= roleId %>",
                        "<%= partnerId ? \"partner-id: \" + partnerId : \"\"%>",
                        "user-Id: <%= userId %>",
                        "x-correlation-id: <%= correlationId %>"
                    ],
                    "formSchema": [
                        {
                            "default": "FFM_SES",
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "SES",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": false
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "default": "3b40f6b1-c1b4-11ec-8134-cfb10f58648c",
                            "id": "correlationId",
                            "type": "correlationId",
                            "title": "X-Correlation ID",
                            "required": true
                        },
                        {
                            "id": "date",
                            "type": "string",
                            "title": "Date",
                            "required": true
                        },
                        {
                            "item": {
                                "type": "string",
                                "title": "Plan Id",
                                "items": [
                                    {
                                        "id": "planId",
                                        "type": "string",
                                        "title": "planId",
                                        "required": true
                                    }
                                ],
                                "required": true
                            },
                            "id": "planIds",
                            "type": "array",
                            "title": "Plan Ids",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Get Eligible Plans",
                    "path": "/ee-rest/v1/plans/get-eligible-plans",
                    "body": "{\"planTypes\":<%=JSON.stringify(planTypes) %>,\"planIdStatusesMap\": [],\"planIds\":<%=JSON.stringify(planIds) %>,\"childOnlyRequest\":<%=childOnlyRequest %>,\"requestType\":<%=JSON.stringify(requestType) %>,\"metalTypes\":<%=JSON.stringify(metalTypes) %>,\"planTypes\":<%=JSON.stringify(planTypes) %>,\"qualifiedMembersGroup\":{\"effectiveDate\":<%=JSON.stringify(effectiveDate) %>,\"enrollees\": <%= JSON.stringify(enrollees) %>,\"enrolleeAssociations\": <%= JSON.stringify(enrolleeAssociations) %>}}",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-Id: <%= roleId %>",
                        "<%= partnerId ? \"partner-id: \" + partnerId : \"\"%>",
                        "user-Id: <%= userId %>",
                        "Content-Type:application/json",
                        "x-correlation-id: <%= correlationId %>"
                    ],
                    "formSchema": [
                        {
                            "default": "FFM_SES",
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "SES",
                            "id": "roleId",
                            "title": "Role ID",
                            "type": "string",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "title": "Partner ID",
                            "type": "string",
                            "required": false
                        },
                        {
                            "id": "userId",
                            "title": "User ID",
                            "type": "string",
                            "required": true
                        },
                        {
                            "default": "3b40f6b2-c1b4-11ec-8134-cfb10f58648c",
                            "id": "correlationId",
                            "title": "X-Correlation ID",
                            "type": "correlationId",
                            "required": true
                        },
                        {
                            "item": {
                                "title": "Plan Type",
                                "type": "string",
                                "items": [
                                    {
                                        "id": "planTypes",
                                        "title": "Plan Types",
                                        "type": "string",
                                        "required": false
                                    }
                                ],
                                "required": true
                            },
                            "id": "planTypes",
                            "title": "Plan Types",
                            "type": "array",
                            "required": true
                        },
                        {
                            "item": {
                                "title": "Plan Id",
                                "type": "string",
                                "items": [
                                    {
                                        "id": "planIds",
                                        "title": "Plan Ids",
                                        "type": "string",
                                        "required": false
                                    }
                                ],
                                "required": true
                            },
                            "id": "planIds",
                            "title": "Plan Id",
                            "type": "array",
                            "required": true
                        },
                        {
                            "id": "childOnlyRequest",
                            "title": "Child Only Request",
                            "type": "boolean",
                            "required": true
                        },
                        {
                            "id": "requestType",
                            "title": "Request Type",
                            "type": "string",
                            "required": true
                        },
                        {
                            "item": {
                                "title": "Metal types",
                                "type": "string",
                                "items": [
                                    {
                                        "id": "metalTypes",
                                        "title": "Metal types",
                                        "type": "string",
                                        "required": false
                                    }
                                ],
                                "required": true
                            },
                            "id": "metalTypes",
                            "title": "Metal types",
                            "type": "array",
                            "required": true
                        },
                        {
                            "id": "effectiveDate",
                            "title": "Effective Date",
                            "type": "string",
                            "required": true
                        },
                        {
                            "item": {
                                "title": "enrollees",
                                "type": "object",
                                "items": [
                                    {
                                        "title": "Member Id",
                                        "type": "string",
                                        "id": "memberId"
                                    },
                                    {
                                        "title": "Relationship Code",
                                        "type": "string",
                                        "id": "relationshipCode"
                                    },
                                    {
                                        "title": "Is Filer",
                                        "type": "boolean",
                                        "id": "isFiler"
                                    },
                                    {
                                        "title": "Birth Date",
                                        "type": "string",
                                        "id": "birthDate"
                                    },
                                    {
                                        "title": "Gender Type Code",
                                        "type": "string",
                                        "id": "genderTypeCode"
                                    },
                                    {
                                        "title": "Zip Code",
                                        "type": "string",
                                        "id": "zipCode"
                                    },
                                    {
                                        "title": "County Name",
                                        "type": "string",
                                        "id": "countyName"
                                    },
                                    {
                                        "title": "Fips Code",
                                        "type": "string",
                                        "id": "fipsCode"
                                    },
                                    {
                                        "title": "In Household Indicator",
                                        "type": "boolean",
                                        "id": "inHouseholdInd"
                                    },
                                    {
                                        "title": "Street Name 1",
                                        "type": "string",
                                        "id": "streetName1"
                                    },
                                    {
                                        "title": "Street Name 2",
                                        "type": "string",
                                        "id": "streetName2"
                                    },
                                    {
                                        "title": "City Name",
                                        "type": "string",
                                        "id": "cityName"
                                    },
                                    {
                                        "title": "State",
                                        "type": "string",
                                        "id": "state"
                                    },
                                    {
                                        "title": "Coverage Start Date",
                                        "type": "string",
                                        "id": "coverageStartDate"
                                    },
                                    {
                                        "title": "Coverage End Date",
                                        "type": "string",
                                        "id": "coverageEndDate"
                                    }
                                ],
                                "required": true
                            },
                            "id": "enrollees",
                            "title": "enrollees",
                            "type": "array",
                            "required": true
                        },
                        {
                            "item": {
                                "title": "enrolleeAssociations",
                                "type": "object",
                                "items": [
                                    {
                                        "title": "Superordinate Member Id",
                                        "type": "string",
                                        "id": "superordinateMemberId"
                                    },
                                    {
                                        "title": "Subordinate Member Id",
                                        "type": "string",
                                        "id": "subordinateMemberId"
                                    },
                                    {
                                        "title": "Relationship Type Code",
                                        "type": "string",
                                        "id": "relationshipTypeCode"
                                    },
                                    {
                                        "title": "Association Role Type Code",
                                        "type": "string",
                                        "id": "associationRoleTypeCode"
                                    }
                                ],
                                "required": true
                            },
                            "id": "enrolleeAssociations",
                            "title": "enrolleeAssociations",
                            "type": "array",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Get Exemptions",
                    "path": "/ee-rest/v1/exemptions?insuranceApplicationId=<%=appId%>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-Id: <%= roleId %>",
                        "<%= partnerId ? \"partner-id: \" + partnerId : \"\"%>",
                        "user-Id: <%= userId %>",
                        "x-correlation-id: <%= correlationId %>"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "title": "Role ID",
                            "type": "string",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "title": "Partner ID",
                            "type": "string",
                            "required": false
                        },
                        {
                            "id": "userId",
                            "title": "User ID",
                            "type": "string",
                            "required": true
                        },
                        {
                            "default": "3b40f6b3-c1b4-11ec-8134-cfb10f58648c",
                            "id": "correlationId",
                            "title": "X-Correlation ID",
                            "type": "correlationId",
                            "required": true
                        },
                        {
                            "id": "appId",
                            "title": "App ID",
                            "type": "string",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Get Plan Information",
                    "path": "/ee-rest/v1/plans/plan-information?date=<%=date%>&plans=<%= (planIds.join('%')) %>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-Id: <%= roleId %>",
                        "<%= partnerId ? \"partner-id: \" + partnerId : \"\"%>",
                        "user-Id: <%= userId %>",
                        "x-correlation-id: <%= correlationId %>"
                    ],
                    "formSchema": [
                        {
                            "default": "FFM_SES",
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "SES",
                            "id": "roleId",
                            "title": "Role ID",
                            "type": "string",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "title": "Partner ID",
                            "type": "string",
                            "required": false
                        },
                        {
                            "id": "userId",
                            "title": "User ID",
                            "type": "string",
                            "required": true
                        },
                        {
                            "default": "3b40f6b4-c1b4-11ec-8134-cfb10f58648c",
                            "id": "correlationId",
                            "title": "X-Correlation ID",
                            "type": "correlationId",
                            "required": true
                        },
                        {
                            "id": "date",
                            "title": "Date",
                            "type": "string",
                            "required": true
                        },
                        {
                            "item": {
                                "title": "Plan Id",
                                "type": "string",
                                "items": [
                                    {
                                        "id": "planId",
                                        "title": "planId",
                                        "type": "string",
                                        "required": true
                                    }
                                ],
                                "required": true
                            },
                            "id": "planIds",
                            "title": "Plan Ids",
                            "type": "array",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Get Rates",
                    "path": "/ee-rest/v1/plans/get-rates",
                    "body": "{\"planSearchBusCriteria\":{\"zipcode\":<%= JSON.stringify(zipCode) %>, \"effectiveDate\":<%= JSON.stringify(effectiveDate) %>,\"planLevelType\":[<%= JSON.stringify(planLevelType) %>], \"requestType\":<%= JSON.stringify(requestType) %>, \"enrollees\":  <%= JSON.stringify(enrollees) %> , \"FipsCode\": <%= JSON.stringify(fipsCode) %>, \"childOnlyRequestIndicator\":<%= JSON.stringify(childOnlyRequestIndicator) %>, \"issuerIds\":<%= JSON.stringify(issuerIds) %>, \"planIds\":<%= JSON.stringify(planIds) %>, \"planTypes\":<%= JSON.stringify(planTypes) %>, \"forceCahePut\":<%= JSON.stringify(forceCachePut) %>, \"suppressionStatus\":<%= JSON.stringify(supressionStatus) %>}}",
                    "headers": [
                        "Content-Type: application/json",
                        "role-id: <%= roleId %>",
                        "user-id: <%= userId %>",
                        "source-system-name: <%= sourceSystemName %>",
                        "x-correlation-id: <%= correlationId %>"
                    ],
                    "formSchema": [
                        {
                            "default": "FFM_SES",
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "SES",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "default": "3b40f6b5-c1b4-11ec-8134-cfb10f58648c",
                            "id": "correlationId",
                            "type": "correlationId",
                            "title": "X-Correlation ID",
                            "required": true
                        },
                        {
                            "id": "issuerIds",
                            "type": "string",
                            "title": "Issuer Ids",
                            "required": true
                        },
                        {
                            "id": "zipCode",
                            "type": "string",
                            "title": "Zip Code",
                            "required": true
                        },
                        {
                            "id": "effectiveDate",
                            "type": "string",
                            "title": "Effective Date",
                            "required": true
                        },
                        {
                            "id": "planLevelType",
                            "type": "string",
                            "title": "Plan Level Type",
                            "required": true
                        },
                        {
                            "id": "metalTypes",
                            "type": "select",
                            "title": "Metal types",
                            "items": [
                                "BRONZE",
                                "SILVER",
                                "GOLD",
                                "PLATINUM",
                                "CATASTROPHIC",
                                "HIGH",
                                "LOW"
                            ],
                            "required": false
                        },
                        {
                            "id": "requestType",
                            "type": "select",
                            "title": "Request type",
                            "items": [
                                "EE_ENROLLMENT",
                                "EE_NON_ENROLLMENT",
                                "PM_ISSUER_VALIDATION",
                                "EE_PLAN_PREVIEW"
                            ],
                            "required": true
                        },
                        {
                            "item": {
                                "type": "object",
                                "title": "enrollees",
                                "items": [
                                    {
                                        "id": "dateOfBirth",
                                        "type": "string",
                                        "title": "date of birth",
                                        "resuired": true
                                    },
                                    {
                                        "id": "relationshipType",
                                        "type": "object",
                                        "title": "Relationship Type",
                                        "items": [
                                            {
                                                "id": "enrolleeType",
                                                "type": "select",
                                                "title": "Enrollee Type",
                                                "items": [
                                                    "SELF",
                                                    "SPOUSE",
                                                    "CHILD",
                                                    "FATHER_MOTHER",
                                                    "GRANDFATHER_GRANDMOTHER",
                                                    "UNCLE_AUNT",
                                                    "NEPHEW_NIECE",
                                                    "COUSIN",
                                                    "ADOPTED_CHILD",
                                                    "FOSTER_CHILD",
                                                    "SON_IN_LAW_DAUGHTER_IN_LAW",
                                                    "BROTHER_IN_LAW_SISTER_IN_LAW",
                                                    "MOTHER_IN_LAW_FATHER_IN_LAW",
                                                    "BROTHER_SISTER",
                                                    "WARD",
                                                    "STEPPARENT",
                                                    "STEPSON_STEPDAUGHTER",
                                                    "SPONSORED_DEPENDENT",
                                                    "EX_SPOUSE",
                                                    "GUARDIAN",
                                                    "COURT_APPOINTED_GUARDIAN",
                                                    "COLLATERAL_DEPENDENT",
                                                    "LIFE_PARTNER",
                                                    "ANNULTANT",
                                                    "TRUSTEE",
                                                    "OTHER_RELATIONSHIP",
                                                    "OTHER_RELATIVE"
                                                ]
                                            },
                                            {
                                                "type": "boolean",
                                                "title": "In Household Ind",
                                                "id": "inHouseholdInd"
                                            },
                                            {
                                                "id": "enrolleeTypeCode",
                                                "type": "select",
                                                "title": "Enrollee Type Code",
                                                "items": [
                                                    "1",
                                                    "1 = Spouse",
                                                    "2 = Father or Mother",
                                                    "3 = Grandfather or Grandmother",
                                                    "4 = Grandson or Granddaughter",
                                                    "5 = Uncle or Aunt",
                                                    "6 = Nephew or Niece",
                                                    "7 = Cousin",
                                                    "8 = Adopted Child",
                                                    "9 = Foster Child",
                                                    "10 = Son",
                                                    "11 = Brother",
                                                    "12 = Mother",
                                                    "13 = Brother or Sister",
                                                    "14 = Ward",
                                                    "15 = Stepparent",
                                                    "16 = Stepson or Stepdaughter",
                                                    "17 = Self",
                                                    "18 = Child",
                                                    "19 = Sponsored Dependent",
                                                    "20 = Dependent of a Minor Dependent",
                                                    "21 = Ex",
                                                    "22 = Guardian",
                                                    "23 = Court Appointed Guardian",
                                                    "24 = Collateral Dependent",
                                                    "25 = Life Partner",
                                                    "26 = Annuitant",
                                                    "27 = Trustee",
                                                    "28 = Other Relationship",
                                                    "29 = Other Relative"
                                                ],
                                                "required": true
                                            }
                                        ]
                                    },
                                    {
                                        "id": "gender",
                                        "type": "select",
                                        "title": "Gender",
                                        "items": [
                                            "MALE",
                                            "FEMALE",
                                            "UNDEFINED"
                                        ]
                                    },
                                    {
                                        "type": "string",
                                        "title": "Member Effective Date",
                                        "id": "memberEffectiveDate"
                                    },
                                    {
                                        "type": "number",
                                        "title": "Tabacco Last Used In Months",
                                        "id": "tobaccoLastUsedInMonths"
                                    }
                                ],
                                "required": true
                            },
                            "id": "enrollees",
                            "type": "array",
                            "title": "enrollees",
                            "required": true
                        },
                        {
                            "id": "fipsCode",
                            "type": "string",
                            "title": "Fips Code",
                            "required": false
                        },
                        {
                            "default": false,
                            "id": "childOnlyRequestIndicator",
                            "type": "boolean",
                            "title": "Child Only Request Indicator",
                            "required": false
                        },
                        {
                            "id": "planIds",
                            "type": "string",
                            "title": "Plan Ids",
                            "required": false
                        },
                        {
                            "id": "planTypes",
                            "type": "select",
                            "title": "Plan types",
                            "items": [
                                "HEALTHCARE",
                                "DENTAL"
                            ],
                            "required": false
                        },
                        {
                            "id": "forceCachePut",
                            "type": "boolean",
                            "title": "Force Cache Put",
                            "required": false
                        },
                        {
                            "id": "supressionStatus",
                            "type": "select",
                            "title": "Supression Status",
                            "items": [
                                "AVAILABLE",
                                "CLOSED",
                                "SUSPENDED",
                                "NOT APPLICABLE"
                            ],
                            "required": false
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Get System User",
                    "path": "/ee-rest/v1/system-user?userLogin=<%=user%>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-Id: <%= roleId %>",
                        "<%= partnerId ? \"partner-id: \" + partnerId : \"\"%>",
                        "user-Id: <%= userId %>",
                        "x-correlation-id: <%= correlationId %>"
                    ],
                    "formSchema": [
                        {
                            "default": "FFM_SES",
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "SES",
                            "id": "roleId",
                            "title": "Role ID",
                            "type": "string",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "title": "Partner ID",
                            "type": "string",
                            "required": false
                        },
                        {
                            "id": "userId",
                            "title": "User ID",
                            "type": "string",
                            "required": true
                        },
                        {
                            "default": "3b40f6b6-c1b4-11ec-8134-cfb10f58648c",
                            "id": "correlationId",
                            "title": "X-Correlation ID",
                            "type": "correlationId",
                            "required": true
                        },
                        {
                            "id": "user",
                            "title": "User Id",
                            "type": "string",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Get slcsp",
                    "path": "/ee-rest/v1/plans/get-slcsp",
                    "body": "{\"enrollmentGroup\":{\"effectiveDate\":<%= JSON.stringify(effectiveDate) %>,\"enrollees\": <%= JSON.stringify(enrollees) %>, \"enrolleeAssociations\": <%= JSON.stringify(enrolleeAssociations) %>},\"planIdStatusesMap\": [],\"useLegacyDeterminationIndicator\":<%=useLegacyDetermination %>}",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-Id: <%= roleId %>",
                        "<%= partnerId ? \"partner-id: \" + partnerId : \"\"%>",
                        "user-Id: <%= userId %>",
                        "Content-Type:application/json",
                        "x-correlation-id: <%= correlationId %>"
                    ],
                    "formSchema": [
                        {
                            "default": "FFM_SES",
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "SES",
                            "id": "roleId",
                            "title": "Role ID",
                            "type": "string",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "title": "Partner ID",
                            "type": "string",
                            "required": false
                        },
                        {
                            "id": "userId",
                            "title": "User ID",
                            "type": "string",
                            "required": true
                        },
                        {
                            "default": "3b40f6b7-c1b4-11ec-8134-cfb10f58648c",
                            "id": "correlationId",
                            "title": "X-Correlation ID",
                            "type": "correlationId",
                            "required": true
                        },
                        {
                            "id": "effectiveDate",
                            "title": "Effective Date",
                            "type": "string",
                            "required": true
                        },
                        {
                            "id": "useLegacyDetermination",
                            "title": "UseLegacy Determination",
                            "type": "boolean",
                            "required": true
                        },
                        {
                            "item": {
                                "title": "enrollees",
                                "type": "object",
                                "items": [
                                    {
                                        "title": "Member Id",
                                        "type": "string",
                                        "id": "memberId"
                                    },
                                    {
                                        "title": "Relationship Code",
                                        "type": "string",
                                        "id": "relationshipCode"
                                    },
                                    {
                                        "title": "Is Filer",
                                        "type": "boolean",
                                        "id": "isFiler"
                                    },
                                    {
                                        "title": "Birth Date",
                                        "type": "string",
                                        "id": "birthDate"
                                    },
                                    {
                                        "title": "Gender Type Code",
                                        "type": "string",
                                        "id": "genderTypeCode"
                                    },
                                    {
                                        "title": "Zip Code",
                                        "type": "string",
                                        "id": "zipCode"
                                    },
                                    {
                                        "title": "County Name",
                                        "type": "string",
                                        "id": "countyName"
                                    },
                                    {
                                        "title": "Fips Code",
                                        "type": "string",
                                        "id": "fipsCode"
                                    },
                                    {
                                        "title": "In Household Indicator",
                                        "type": "boolean",
                                        "id": "inHouseholdInd"
                                    },
                                    {
                                        "title": "streetName1",
                                        "type": "string",
                                        "id": "streetName1"
                                    },
                                    {
                                        "title": "streetName2",
                                        "type": "string",
                                        "id": "streetName2"
                                    },
                                    {
                                        "title": "City Name",
                                        "type": "string",
                                        "id": "cityName"
                                    },
                                    {
                                        "title": "State",
                                        "type": "string",
                                        "id": "state"
                                    },
                                    {
                                        "title": "Coverage Start Date",
                                        "type": "string",
                                        "id": "coverageStartDate"
                                    },
                                    {
                                        "title": "Coverage End Date",
                                        "type": "string",
                                        "id": "coverageEndDate"
                                    }
                                ],
                                "required": true
                            },
                            "id": "enrollees",
                            "title": "enrollees",
                            "type": "array",
                            "required": true
                        },
                        {
                            "item": {
                                "title": "enrolleeAssociations",
                                "type": "object",
                                "items": [
                                    {
                                        "title": "Superordinate Member Id",
                                        "type": "string",
                                        "id": "superordinateMemberId"
                                    },
                                    {
                                        "title": "Subordinate Member Id",
                                        "type": "string",
                                        "id": "subordinateMemberId"
                                    },
                                    {
                                        "title": "Relationship Type Code",
                                        "type": "string",
                                        "id": "relationshipTypeCode"
                                    },
                                    {
                                        "title": "Association Role Type Code",
                                        "type": "string",
                                        "id": "associationRoleTypeCode"
                                    }
                                ],
                                "required": true
                            },
                            "id": "enrolleeAssociations",
                            "title": "enrolleeAssociations",
                            "type": "array",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                }
            ]
        },
        {
            "name": "DSRS",
            "services": [
                {
                    "name": "Get Document",
                    "path": "/v1/document/<%=dsrsId%>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "dsrsId",
                            "type": "string",
                            "title": "DSRS ID",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Get Document Metadata",
                    "path": "/v1/metadata/<%=dsrsId%>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "dsrsId",
                            "type": "string",
                            "title": "DSRS ID",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Search Metadata",
                    "path": "/v1/search-metadata",
                    "body": "<% var object = _({insuranceApplicationIdentifier: insuranceApplicationIdentifiers, personTrackingNumbers: personTrackingNumbers, documentCategoryCode: documentCategoryCodes, coverageYear: coverageYears }).toPairs().map(p => [p[0], _.reject(p[1] || [], _.isEmpty)]).reject(k => _.isEmpty(k[1])).fromPairs().value(); if (_.isEmpty(object)) {throw new ReferenceError('At least 1 search value must be set')} if (object.insuranceApplicationIdentifier) { object.insuranceApplicationIdentifier = _.map(object.insuranceApplicationIdentifier, _.parseInt) } %><%= JSON.stringify(object) %>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>",
                        "content-type: application/json"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "dsrs-default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "item": {
                                "type": "string",
                                "title": "Person Tracking Number",
                                "required": true
                            },
                            "id": "personTrackingNumbers",
                            "type": "array",
                            "title": "Person Tracking Numbers",
                            "required": true
                        },
                        {
                            "item": {
                                "type": "number",
                                "title": "Insurance Application Identifier",
                                "required": true
                            },
                            "id": "insuranceApplicationIdentifiers",
                            "type": "array",
                            "title": "Insurance Application Identifiers",
                            "required": true
                        },
                        {
                            "item": {
                                "type": "string",
                                "title": "Document Category Code",
                                "required": true
                            },
                            "id": "documentCategoryCodes",
                            "type": "array",
                            "title": "Document Category Codes",
                            "required": true
                        },
                        {
                            "item": {
                                "type": "number",
                                "title": "Coverage Year",
                                "required": true
                            },
                            "id": "coverageYears",
                            "type": "array",
                            "title": "Coverage Years",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                }
            ]
        },
        {
            "name": "PDV",
            "services": [
                {
                    "name": "BAR Opt Out",
                    "path": "/v1/pdv/enrollment",
                    "body": "{\"insuranceApplicationIdentifier\": \"<%= insuranceApplicationIdentifier %>\", \"enrollmentActions\":[{ \"actionType\": \"BAR_OPT_OUT\", \"policy\":{\"exchangeAssignedPolicyIdentifier\": \"<%= exchangeAssignedPolicyIdentifier %>\"}}]}",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>"
                    ],
                    "formSchema": [
                        {
                            "default": "FFM_SM",
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "SM_READ",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        },
                        {
                            "id": "exchangeAssignedPolicyIdentifier",
                            "type": "string",
                            "title": "Exchange Assigned Policy ID",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        },
                        {
                            "env": "testpe1",
                            "label": "test PE1"
                        }
                    ]
                },
                {
                    "name": "Cancel",
                    "path": "/v1/pdv/enrollment",
                    "body": "{\"insuranceApplicationIdentifier\": \"<%= insuranceApplicationIdentifier %>\", \"enrollmentActions\":[{ \"actionType\": \"CANCEL\", \"policy\":{\"exchangeAssignedPolicyIdentifier\": \"<%= exchangeAssignedPolicyIdentifier %>\"}}]}",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>"
                    ],
                    "formSchema": [
                        {
                            "default": "FFM_SM",
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "SM_READ",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        },
                        {
                            "id": "exchangeAssignedPolicyIdentifier",
                            "type": "string",
                            "title": "Exchange Assigned Policy ID",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        },
                        {
                            "env": "testpe1",
                            "label": "test PE1"
                        }
                    ]
                },
                {
                    "name": "Effectuate",
                    "path": "/v1/pdv/enrollment",
                    "body": "<% var policy = {exchangeAssignedPolicyIdentifier: exchangeAssignedPolicyIdentifier}; if (lastPremiumPaidDate) { policy.lastPremiumPaidDate = lastPremiumPaidDate }; %><%= JSON.stringify({insuranceApplicationIdentifier: insuranceApplicationIdentifier, enrollmentActions: [{actionType: \"EFFECTUATE\", policy: policy}]}) %>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>"
                    ],
                    "formSchema": [
                        {
                            "default": "FFM_SM",
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "SM_READ",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        },
                        {
                            "id": "exchangeAssignedPolicyIdentifier",
                            "type": "string",
                            "title": "Exchange Assigned Policy ID",
                            "required": true
                        },
                        {
                            "type": "string",
                            "title": "Last Premium Paid Date",
                            "id": "lastPremiumPaidDate"
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        },
                        {
                            "env": "testpe1",
                            "label": "test PE1"
                        }
                    ]
                },
                {
                    "name": "End Coverage",
                    "path": "/v1/pdv/enrollment",
                    "body": "{\"insuranceApplicationIdentifier\": \"<%= insuranceApplicationIdentifier %>\", \"enrollmentActions\":[{ \"actionType\": \"END_COVERAGE\", \"actionEffectiveDate\": \"<%= actionEffectiveDate %>\", \"policy\":{\"exchangeAssignedPolicyIdentifier\": \"<%= exchangeAssignedPolicyIdentifier %>\"}}]}",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>"
                    ],
                    "formSchema": [
                        {
                            "default": "FFM_SM",
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "SM_READ",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        },
                        {
                            "id": "actionEffectiveDate",
                            "type": "string",
                            "title": "Action Effective Date",
                            "required": true
                        },
                        {
                            "id": "exchangeAssignedPolicyIdentifier",
                            "type": "string",
                            "title": "Exchange Assigned Policy ID",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        },
                        {
                            "env": "testpe1",
                            "label": "test PE1"
                        }
                    ]
                },
                {
                    "name": "Terminate",
                    "path": "/v1/pdv/enrollment",
                    "body": "{\"insuranceApplicationIdentifier\": \"<%= insuranceApplicationIdentifier %>\", \"enrollmentActions\":[{ \"actionType\": \"TERMINATE\", \"actionEffectiveDate\": \"<%= actionEffectiveDate %>\", \"policy\":{\"exchangeAssignedPolicyIdentifier\": \"<%= exchangeAssignedPolicyIdentifier %>\"}}]}",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>"
                    ],
                    "formSchema": [
                        {
                            "default": "FFM_SM",
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "SM_READ",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        },
                        {
                            "id": "actionEffectiveDate",
                            "type": "string",
                            "title": "Action Effective Date",
                            "required": true
                        },
                        {
                            "id": "exchangeAssignedPolicyIdentifier",
                            "type": "string",
                            "title": "Exchange Assigned Policy ID",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        },
                        {
                            "env": "testpe1",
                            "label": "test PE1"
                        }
                    ]
                },
                {
                    "name": "Update Issuer ID",
                    "path": "/v1/pdv/enrollment",
                    "body": "<% var policy = {exchangeAssignedPolicyIdentifier: exchangeAssignedPolicyIdentifier}; if (issuerAssignedPolicyIdentifier) { policy.issuerAssignedPolicyIdentifier = issuerAssignedPolicyIdentifier }; if (exchangeAssignedInsuredMemberIdentifier) { policy.exchangeAssignedInsuredMemberIdentifier = exchangeAssignedInsuredMemberIdentifier }; if (issuerAssignedInsuredMemberIdentifier) { policy.issuerAssignedInsuredMemberIdentifier = issuerAssignedInsuredMemberIdentifier }; %><%= JSON.stringify({insuranceApplicationIdentifier: insuranceApplicationIdentifier, enrollmentActions: [{actionType: \"UPDATE_ISSUER_ASSIGNED_IDS\", policy: policy}]}) %>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>"
                    ],
                    "formSchema": [
                        {
                            "default": "FFM_SM",
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "SM_READ",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        },
                        {
                            "id": "exchangeAssignedPolicyIdentifier",
                            "type": "string",
                            "title": "Exchange Assigned Policy ID",
                            "required": true
                        },
                        {
                            "type": "string",
                            "title": "Issuer Assigned Policy ID",
                            "id": "issuerAssignedPolicyIdentifier"
                        },
                        {
                            "type": "string",
                            "title": "Exchange Assigned Insured Member ID",
                            "id": "exchangeAssignedInsuredMemberIdentifier"
                        },
                        {
                            "type": "string",
                            "title": "Issuer Assigned Insured Member ID",
                            "id": "issuerAssignedInsuredMemberIdentifier"
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        },
                        {
                            "env": "testpe1",
                            "label": "test PE1"
                        }
                    ]
                },
                {
                    "name": "Update Policies",
                    "path": "/v1/pdv/update-policies",
                    "body": "{\"insuranceApplicationIdentifiers\": <%= JSON.stringify(insuranceApplicationIdentifier) %>,  \"actionType\": \"<%= actionType %>\", \"actionEffectiveDate\": \"<%= actionEffectiveDate %>\" }",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "<%= testRequestTime ? 'testRequestTime: ' + testRequestTime : ''%>"
                    ],
                    "formSchema": [
                        {
                            "default": "FFM_SM",
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "SM_READ",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": false
                        },
                        {
                            "default": "3b40f6b8-c1b4-11ec-8134-cfb10f58648c",
                            "id": "correlationId",
                            "type": "string",
                            "title": "Correlation ID",
                            "required": true
                        },
                        {
                            "id": "testRequestTime",
                            "type": "string",
                            "title": "Test Request Time",
                            "required": false
                        },
                        {
                            "id": "actionEffectiveDate",
                            "type": "string",
                            "title": "Action Effective Date",
                            "required": false
                        },
                        {
                            "id": "actionType",
                            "type": "select",
                            "title": "Action Type",
                            "items": [
                                "END_COVERAGE_VOLUNTARY_WITHDRAWAL",
                                "BAR_OPT_OUT_VOLUNTARY_WITHDRAWAL",
                                "UPDATE_ISSUER_ASSIGNED_ID_MAINTENANCE",
                                "EFFECTUATE_POLICY_ACTIVATED",
                                "CANCEL_NON_PAYMENT",
                                "CANCEL_FREE_LOOK_EXPIRATION",
                                "CANCEL_HICS",
                                "CANCEL_FRAUD",
                                "CANCEL_ANTIDUPLICATION",
                                "CANCEL_OUT_OF_AREA",
                                "CANCEL_OTHER_REASON",
                                "CANCEL_RESCIND",
                                "TERMINATE_NON_PAYMENT",
                                "TERMINATE_ANTIDUPLICATION",
                                "TERMINATE_OTHER_REASON",
                                "TERMINATE_HICS",
                                "CANCEL_CARRYFORWARD"
                            ],
                            "required": true
                        },
                        {
                            "item": {
                                "type": "string",
                                "title": "App ID",
                                "required": true
                            },
                            "id": "insuranceApplicationIdentifier",
                            "type": "array",
                            "title": "App Ids",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        },
                        {
                            "env": "testpe1",
                            "label": "test PE1"
                        }
                    ]
                }
            ]
        },
        {
            "name": "SES",
            "services": [
                {
                    "name": "Get App All Versions",
                    "path": "/v1/applications/<%= insuranceApplicationIdentifier %>/versions",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "roleId: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Get App Details",
                    "path": "/v1/applications/<%=insuranceApplicationIdentifier%>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "roleId: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Get App Summary by PTN",
                    "path": "/v1/applications?q=summary&ptn=<%= ptn %>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "roleId: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "ptn",
                            "type": "string",
                            "title": "Person Tracking Number",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Get App Version Details",
                    "path": "/v1/applications/<%= insuranceApplicationIdentifier %>/versions/<%= appVersion %>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "roleId: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        },
                        {
                            "id": "appVersion",
                            "type": "string",
                            "title": "Insurance Application Version",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Get App by Coverage Year",
                    "path": "/v1/applications?linkedToAppId=<%=appId%>&startCoverageYear=<%= coverageYear ? + coverageYear : ''%>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "roleId: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "userId: <%= userId %>",
                        "x-correlation-id: <%= correlationId %>"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": false
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "default": "3b40f6b9-c1b4-11ec-8134-cfb10f58648c",
                            "id": "correlationId",
                            "type": "correlationId",
                            "title": "X-Correlation ID",
                            "required": true
                        },
                        {
                            "id": "appId",
                            "type": "string",
                            "title": "App Id",
                            "required": true
                        },
                        {
                            "id": "coverageYear",
                            "type": "string",
                            "title": "Coverage Year (leave blank for all years)",
                            "required": false
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Get Permission",
                    "path": "/v1/permission?appId=<%=insuranceApplicationIdentifier%>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "roleId: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>",
                        "Content-Type: application/json",
                        "originating-role-id: <%= originatingRoleId %>"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "default": "AGENT_BROKER",
                            "id": "originatingRoleId",
                            "type": "string",
                            "title": "Originating Role ID",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Get Reference Data",
                    "path": "/v1/reference-data/states<%= stateCode ? '/'+ stateCode : ''%>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "roleId: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "userId: <%= userId %>",
                        "x-correlation-id: <%= correlationId %>"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": false
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "default": "3b40f6ba-c1b4-11ec-8134-cfb10f58648c",
                            "id": "correlationId",
                            "type": "correlationId",
                            "title": "X-Correlation ID",
                            "required": true
                        },
                        {
                            "id": "stateCode",
                            "type": "string",
                            "title": "State Code (leave blank for all States)",
                            "required": false
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                }
            ]
        },
        {
            "name": "MCR",
            "services": [
                {
                    "name": "Consumer Flags",
                    "path": "/v1/flags",
                    "body": "{\"personTrackingNumber\": \"<%=personTrackingNumber%>\"}",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>",
                        "content-type: application/json"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "personTrackingNumber",
                            "type": "string",
                            "title": "Person Tracking Number",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "DMI Task Status (App ID)",
                    "path": "/v1/dmi/information",
                    "body": "{\"insuranceApplicationIdentifier\": <%= insuranceApplicationIdentifier %>}",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>",
                        "content-type: application/json"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "DMI Task Status (PTN)",
                    "path": "/v1/dmi/information",
                    "body": "{\"personTrackingNumbers\": <%= JSON.stringify(personTrackingNumbers) %>, \"beginYear\": <%=beginYear%>, \"endYear\": <%=endYear%>}",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>",
                        "content-type: application/json"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "beginYear",
                            "type": "string",
                            "title": "Begin Year",
                            "required": true
                        },
                        {
                            "id": "endYear",
                            "type": "string",
                            "title": "End Year",
                            "required": true
                        },
                        {
                            "item": {
                                "type": "string",
                                "title": "Person Tracking Number",
                                "required": true
                            },
                            "id": "personTrackingNumbers",
                            "type": "array",
                            "title": "Person Tracking Numbers",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Document Information",
                    "path": "/v1/documents/information",
                    "body": "{\"personTrackingNumbers\": <%= JSON.stringify(personTrackingNumbers) %>}",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>",
                        "content-type: application/json"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "item": {
                                "type": "string",
                                "required": true
                            },
                            "id": "personTrackingNumbers",
                            "type": "array",
                            "title": "Person Tracking Numbers"
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Enrollments Information",
                    "path": "/v1/enrollments/information",
                    "body": "{\"personTrackingNumber\": <%= personTrackingNumber %>, \"insuranceApplicationIdentifier\": <%= insuranceApplicationIdentifier %>, \"marketplaceGroupPolicyIdentifier\": <%= marketplaceGroupPolicyIdentifier %>, \"allVersions\": <%=allVersions%>}",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>",
                        "content-type: application/json"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "default": "null",
                            "id": "marketplaceGroupPolicyIdentifier",
                            "type": "string",
                            "title": "MGPID",
                            "required": true
                        },
                        {
                            "default": "null",
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        },
                        {
                            "default": "null",
                            "id": "personTrackingNumber",
                            "type": "string",
                            "title": "Person Tracking Number",
                            "required": true
                        },
                        {
                            "default": false,
                            "id": "allVersions",
                            "type": "boolean",
                            "title": "All Versions",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Get Mailing Address",
                    "path": "/v1/persons/<%=ptn%>/mailingAddress?appId=<%=appId%>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-Id: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-Id: <%= userId %>",
                        "x-correlation-id: <%= correlationId %>"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": false
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "default": "3b40f6bb-c1b4-11ec-8134-cfb10f58648c",
                            "id": "correlationId",
                            "type": "correlationId",
                            "title": "X-Correlation ID",
                            "required": true
                        },
                        {
                            "id": "ptn",
                            "type": "string",
                            "title": "PTN",
                            "required": true
                        },
                        {
                            "id": "appId",
                            "type": "string",
                            "title": "App ID",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Get Policies (EDE)",
                    "path": "/v1/get-policies",
                    "body": "{\"insuranceApplicationIdentifier\": <%= insuranceApplicationIdentifier %>}",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>",
                        "content-type: application/json",
                        "password: <%= password %>"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Journal Read",
                    "path": "/v1/journals",
                    "body": "{\"personTrackingNumber\": <%= personTrackingNumber %>, \"insuranceApplicationIdentifier\": <%= insuranceApplicationIdentifier %>, \"journalFromDate\": <%= journalFromDate %>, \"journalToDate\": <%= journalToDate %>}",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>",
                        "content-type: application/json"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "default": "null",
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        },
                        {
                            "default": "null",
                            "id": "personTrackingNumber",
                            "type": "string",
                            "title": "Person Tracking Number",
                            "required": true
                        },
                        {
                            "default": "null",
                            "id": "journalFromDate",
                            "type": "string",
                            "title": "Journal From Date",
                            "required": true
                        },
                        {
                            "default": "null",
                            "id": "journalToDate",
                            "type": "string",
                            "title": "Journal To Date",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Person Search",
                    "path": "/v1/persons",
                    "body": "<%= JSON.stringify({firstName: firstName, lastName: lastName, birthDate: birthDate || undefined}) %>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>",
                        "content-type: application/json"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "firstName",
                            "type": "string",
                            "title": "First Name",
                            "required": true
                        },
                        {
                            "id": "lastName",
                            "type": "string",
                            "title": "Last Name",
                            "required": true
                        },
                        {
                            "id": "birthDate",
                            "type": "string",
                            "title": "Date Of Birth",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Person Search Partial",
                    "path": "/v1/persons/partial",
                    "body": "<% if (!firstName && !lastName) {throw new ReferenceError(\"firstName or lastName must be defined\") } firstName = firstName || undefined; lastName = lastName || undefined; birthDate = birthDate || undefined %> <%= JSON.stringify({\"firstName\": firstName, \"lastName\": lastName, \"birthDate\": birthDate}) %>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>",
                        "content-type: application/json"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "firstName",
                            "type": "string",
                            "title": "First Name",
                            "required": true
                        },
                        {
                            "id": "lastName",
                            "type": "string",
                            "title": "Last Name",
                            "required": true
                        },
                        {
                            "id": "birthDate",
                            "type": "string",
                            "title": "Date Of Birth",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "SVI Information (App ID)",
                    "path": "/v1/svi/information",
                    "body": "{\"insuranceApplicationIdentifier\": <%= insuranceApplicationIdentifier %>}",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>",
                        "content-type: application/json"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "SVI Information (PTN)",
                    "path": "/v1/svi/information",
                    "body": "{\"personTrackingNumber\": <%= personTrackingNumber %>, \"beginYear\": <%=beginYear%>, \"endYear\": <%=endYear%>}",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>",
                        "content-type: application/json"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "personTrackingNumber",
                            "type": "string",
                            "title": "Person Tracking Number",
                            "required": true
                        },
                        {
                            "id": "beginYear",
                            "type": "string",
                            "title": "Begin Year",
                            "required": true
                        },
                        {
                            "id": "endYear",
                            "type": "string",
                            "title": "End Year",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Trusted Source Data (TDS)",
                    "path": "/v1/trusted-source-data?appId=<%= insuranceApplicationIdentifier %>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-id: <%= roleId %>",
                        "<%= partnerId ? 'partner-id: ' + partnerId : ''%>",
                        "user-id: <%= userId %>"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                }
            ]
        },
        {
            "name": "IES",
            "services": [
                {
                    "name": "Get Enrollments",
                    "path": "/v1/enrollments?type=<%=type%>&<%= field %>=<%= input %>",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "roleId: <%= roleId %>",
                        "<%= partnerId ? \"partner-id:\" + partnerId : \"\"%>",
                        "user-id: <%= userId %>"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "field",
                            "type": "select",
                            "title": "Search By",
                            "items": [
                                "exchangeAssignedPolicyId",
                                "appId"
                            ],
                            "required": true
                        },
                        {
                            "default": "EDH",
                            "id": "type",
                            "title": "Type",
                            "type": "select",
                            "items": [
                                "EDH",
                                "enrollmentRecordAndEDH",
                                "enrollmentRecord"
                            ],
                            "required": true
                        },
                        {
                            "id": "input",
                            "type": "string",
                            "title": "Input",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "Get Policies",
                    "path": "/v1/get-policies",
                    "body": "{\"insuranceApplicationIdentifier\": <%= insuranceApplicationIdentifier %>, \"beginYear\": <%=beginYear%>, \"endYear\": <%=endYear%>, \"includePpsIndicator\" : <%=includePpsIndicator%>   }",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "roleId: <%= roleId %>",
                        "<%= partnerId ? \"partner-id:\" + partnerId : \"\"%>",
                        "user-id: <%= userId %>"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        },
                        {
                            "id": "beginYear",
                            "type": "string",
                            "title": "Begin Year",
                            "required": true
                        },
                        {
                            "id": "endYear",
                            "type": "string",
                            "title": "End Year",
                            "required": true
                        },
                        {
                            "id": "includePpsIndicator",
                            "type": "boolean",
                            "title": "Include PPS",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                }
            ]
        },
        {
            "name": "EE-PC2",
            "services": [
                {
                    "name": "Retrieve QHP Payment Portal Data",
                    "path": "/ee-rest/api-auth/<%=state%>/en_US/PlanCompare/retrieveQHPPaymentPortalData",
                    "body": "{\"applicationId\": <%= JSON.stringify(insuranceApplicationIdentifier) %>}",
                    "headers": [
                        "clientSystemId: <%= sourceSystemName %>",
                        "role: <%= roleId %>",
                        "<%= partnerId ? \"partner-id: \" + partnerId : \"\"%>",
                        "userId: <%= userId %>",
                        "x-correlation-id: <%= correlationId %>",
                        "Content-Type:application/json"
                    ],
                    "formSchema": [
                        {
                            "default": "APP3.0",
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "plancompare2.0",
                                "pc2.0",
                                "INDIVIDUAL_APPLICATION",
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "Consumer_UI",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": false
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "default": "3b40f6bc-c1b4-11ec-8134-cfb10f58648c",
                            "id": "correlationId",
                            "type": "correlationId",
                            "title": "X-Correlation ID",
                            "required": true
                        },
                        {
                            "id": "state",
                            "type": "string",
                            "title": "State",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "App Id",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                },
                {
                    "name": "SVI Information",
                    "path": "/ee-rest/api-auth/en_US/SepVerificationApi/v1/ffmRetrieveSVIInformation",
                    "body": "{\"insuranceApplicationIdentifier\": <%= insuranceApplicationIdentifier %>}",
                    "headers": [
                        "roleId: <%= roleId %>",
                        "source-system-name: <%= sourceSystemName %>",
                        "user-Id: <%= userId %>",
                        "Content-Type: application/json"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "id": "userId",
                            "title": "User ID",
                            "type": "string",
                            "required": true
                        },
                        {
                            "default": "SES",
                            "id": "roleId",
                            "title": "Role ID",
                            "type": "string",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "title": "Insurance Application ID",
                            "type": "string",
                            "required": true
                        }
                    ],
                    "environments": [
                        {
                            "env": "test0",
                            "label": "Test 0"
                        },
                        {
                            "env": "test1",
                            "label": "Test 1"
                        },
                        {
                            "env": "test2",
                            "label": "Test 2"
                        },
                        {
                            "env": "test3",
                            "label": "Test 3"
                        },
                        {
                            "env": "test4",
                            "label": "Test 4"
                        },
                        {
                            "env": "test5",
                            "label": "Test 5"
                        }
                    ]
                }
            ]
        }
    ]
}

var corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200 
}
router.use(json());

router.get('/', cors(corsOptions), async (req, res) => {
  setTimeout(() => {
    console.log(new Date(), 'Request received get services: ------------------> ', req.baseUrl)
    res.status(200).contentType('application/json').send({
      ...response
    });
  }, 300);
});

export default router;