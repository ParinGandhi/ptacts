import express from 'express'
import pkg from 'body-parser';
import cors from 'cors';
import fs from 'fs'

const { json } = pkg;
const router = express.Router();
const response = {}

var corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200 
}
router.use(pkg.text({type:"*/*"}));

router.post('/', cors(corsOptions), async (req, res) => {
  let jsonStr = ''
  if(req.body && JSON.stringify(req.body).includes('Green')) {
    jsonStr = fs.readFileSync("./cms/s3folderitemsgreen.json");
  } else {
    jsonStr = fs.readFileSync("./cms/s3folderitemsblue.json");
  }
  setTimeout(() => {
    console.log(new Date(), 'Request received get s3folderitems: ------------------> ', req.baseUrl)
    res.status(200).contentType('application/json').send({
      ...JSON.parse(jsonStr)
    });
  }, 400);
});

export default router;