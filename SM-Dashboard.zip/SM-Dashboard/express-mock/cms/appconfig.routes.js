import express from 'express'
import pkg from 'body-parser';
import cors from 'cors';
import fs from 'fs'

const { json } = pkg;
const router = express.Router();


const jsonStr = fs.readFileSync("./cms/appconfig.json");
const response = JSON.parse(jsonStr);

var corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200 
}
router.use(json());

router.get('/', cors(corsOptions), async (req, res) => {
  setTimeout(() => {
    console.log(new Date(), 'Request received get app config: ------------------> ', req.baseUrl)
    res.status(200).contentType('application/json').send({
      ...response
    });
  }, 300);
});

export default router;