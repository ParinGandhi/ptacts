import express from 'express'
import pkg from 'body-parser';
import cors from 'cors';
import fs from 'fs'

const { json } = pkg;
const router = express.Router();
const response = {
  "name": "Test",
  "type": "test"
}

var corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200 
}
router.use(json());

router.get('/', cors(corsOptions), async (req, res) => {
  setTimeout(() => {
    console.log(new Date(), 'Request received get environment: ------------------> ', req.baseUrl)
    res.status(200).contentType('application/json').send({
      ...response
    });
  }, 200);
});

export default router;