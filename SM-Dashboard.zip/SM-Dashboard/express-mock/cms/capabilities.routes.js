import express from 'express'
import pkg from 'body-parser';
import cors from 'cors';
import fs from 'fs'

const { json } = pkg;
const router = express.Router();
const response = {
  "capabilityList": [
      {
          "name": "api_request_capability",
          "label": "FFE API Invocations",
          "description": "Call FFE APIs",
          "path": "/dashboard.html",
          "role": "dashboard",
          "status": "ON"
      },
      {
          "name": "app_config_management_capability",
          "label": "FFE Application Configuration Management",
          "description": "Manage Application Configuration Files",
          "path": "/appconfig.html",
          "role": "appconfig",
          "status": "ON"
      },
      {
          "name": "ref_data_browsing_capability",
          "label": "Reference Data Browsing",
          "description": "Reference Data Endpoints",
          "path": "/refdataviewer.html",
          "role": "refdata",
          "status": "ON"
      },
      {
          "name": "transaction_log_search_capability",
          "label": "Transaction Logs Search",
          "description": "Inspect Logs by Correlation ID",
          "path": "/logviewer.html",
          "role": "logs",
          "status": "ON"
      }
  ]
}

var corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200 
}
router.use(json());

router.get('/', cors(corsOptions), async (req, res) => {
  setTimeout(() => {
    console.log(new Date(), 'Request received get capabilities: ------------------> ', req.baseUrl)
    res.status(200).contentType('application/json').send({
      ...response
    });
  }, 200);
});

export default router;