#Install nodemon globally & start server 
npm install nodemon -g
nodemon ./server.js

#Kill runnng port if needed
lsof -i -P -n | grep 8081
kill -9 xxxxx