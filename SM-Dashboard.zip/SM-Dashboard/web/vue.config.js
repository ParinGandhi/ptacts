// const VuetifyLoaderPlugin = require('vuetify-loader/lib/plugin')
const { VuetifyPlugin } = require('webpack-plugin-vuetify')
module.exports = {
  chainWebpack: (config) => {
    // config.resolve.alias.set('vue', '@vue/compat')
    config.resolve.alias.set('vue')
    config.module
      .rule('vue')
      .use('vue-loader')
      .tap((options) => {
        return {
          ...options,
          // compilerOptions: {
          //   compatConfig: {
          //     MODE: 2
          //   }
          // }
        }
      })
  },
  pages: {
    index: 'src/index/main.js',
    dashboard: 'src/dashboard/main.js',
    editor: 'src/editor/main.js',
    menu: 'src/menu/main.js',
    logviewer: 'src/logviewer/main.js',
    refdataviewer: 'src/refdataviewer/main.js',
    appconfig: 'src/appconfig/main.js'
  },
  configureWebpack: {
    devtool: 'source-map',
    plugins: [
      // new VuetifyLoaderPlugin()
      new VuetifyPlugin({ autoImport: true }), // Enabled by default
    ]
  },
  devServer: {
    proxy: {
      '/api/*': {
        target: 'http://localhost:8080/',
        changeOrigin: true,
        pathRewrite: {
          '^/api': ''
        }
      }
    }
  },
};

