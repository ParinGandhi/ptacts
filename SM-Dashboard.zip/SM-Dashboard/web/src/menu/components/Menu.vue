<template>
  <div class="fad-menu">
    <Header v-bind:username="username"
            v-bind:environment="environment"
            v-bind:resourceUrls="resourceUrls"/>
    <h2 class="fad-menu-title" v-show="!noRoles || isLoading">Main Menu</h2>
    <div style="margin: auto;width:100%; height:100%;text-align:center;" v-show="noRoles && !isLoading">
      <v-sheet style="background-color: #055072;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);" class="pa-3">
          <h3 class="fad-menu-title" >You do not have permission to access the application specific functionalities. Please contact support team.</h3>
      </v-sheet>
    </div>
    <v-sheet style="background-color: #055072; margin-top: 40px" v-show="isLoading"
      class="pa-3"
    >
      <v-skeleton-loader
        class="mx-auto custom-skeleton-btn-width"
        max-width="470"
        width="470"
        type="button@4"
      ></v-skeleton-loader>
    </v-sheet>
    <div class="fad-center-menu-services btn-group-vertical" v-show="!isLoading">
      <button class="fad-menu-button btn btn-default"
              type="button"
              v-for="item in menuItems"
              v-bind:key="item.name"
              v-on:click="menuItemClick(item)"
              v-show="shouldShowMenuButton(item)">
        {{ item.label }}
        <span class="fad-service-path text-muted">{{ item.description }}</span>
      </button>
    </div>
  </div>
</template>

<script>
  import {redirectToIndex, redirectToIndexIfNoAccessToken} from "../../utils/RedirectToIndex";
  import MenuItems from '../assets/menuItems'
  import jwtDecode from "jwt-decode";
  import Header from '../../dashboard/components/Header';


  export default {
    name: 'Menu',
    components: {
      Header,
    },
    data: function () {
      return {
        isLoading:true,
        environment: {},
        userDropdownOpen: false,
        menuItems: [],
        noRoles: true
      }
    },
    async created() {
    },
    watch: {
      menuItems: function () {
      }
    },
    methods: {
      environmentClass: function () {
        return {
          'fad-environment-cell-prod': this.environment.type === 'prod'
        }
      },
      logout: function () {
        fetch(this.resourceUrls.logout, {
          method: 'POST',
          headers: {
            'access-token': sessionStorage.getItem('accessToken')
          },
        })
          .finally(redirectToIndex)
      },
      menuItemClick: function (menuItem) {
        window.location.href = menuItem.path;
      },
      shouldShowMenuButton: function (menuItem) {
        //eventually we can compare the user role to the menuItem role to show the button to the user
        return true;
      }
    },
    computed: {
      username: function () {
        try {
          return jwtDecode(sessionStorage.getItem('idToken'))['custom:uid'];
        } catch (err) {
          return 'User';
        }
      },
    },
    props: {
      resourceUrls: Object,
    },
    mounted:async function () {
      await fetch(this.resourceUrls.capabilities, {
        headers: {
          'access-token': sessionStorage.getItem('accessToken')
        }
      })
        .then(response => response.json())
        .then(json => {
          this.isLoading = false
          this.menuItems = json.capabilityList
          if(json.capabilityList && json.capabilityList.length > 0) {
            this.noRoles = false
          }
        })
        .catch(redirectToIndexIfNoAccessToken)

      fetch(this.resourceUrls.environment, {
        headers: {
          'access-token': sessionStorage.getItem('accessToken')
        }
      })
        .then(response => response.json())
        .then(json => this.environment = json)
        .catch(redirectToIndexIfNoAccessToken)
    },
  }
</script>
<style>

.custom-skeleton-btn-width .v-skeleton-loader__button{
  width: 470px !important;
}
</style>

<style scoped>


  .fad-menu {
    display: flex;
    flex-direction: column;
    height: 100%;
    background-color: #055072;
  }

  .fad-nav-selections > li {
    cursor: pointer;
    display: flex;
    flex-basis: 115px;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }

  .fad-nav-selections > li > a {
    display: flex;
    width: 100%;
    align-items: center;
    justify-content: center;
    min-width: 70px;
  }

  .fad-menu-title {
    height: 10%;
    color: #cfe2ea;
    width: 100%;
    text-align: center;
    margin: 0;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .fad-center-menu-services {
    width: 25%;
    padding-top: 20px;
    margin: 0 auto;
  }

  .fad-service-path {
    display: block;
    font-size: 10px;
    letter-spacing: -.5px;
    font-family: "Fira Mono", monospace;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .fad-menu-button {
    margin: 10px 0;
  }
</style>
