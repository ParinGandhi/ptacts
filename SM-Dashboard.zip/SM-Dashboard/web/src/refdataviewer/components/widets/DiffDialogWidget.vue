<template>
  <v-dialog v-model="showDiffDialog" scrollable transition="dialog-bottom-transition">
    <v-card tile>
      <v-toolbar dark color="primary" dense>
        <v-row>
          <v-col cols="6">
            <v-row>
              <v-btn
                icon
                dark
                @click="showDiffDialog = false">
                <v-icon>mdi-close</v-icon>
              </v-btn>
              <v-toolbar-title style="padding: 10px 0px 0px 30px; font-weight: bolder">Original</v-toolbar-title>
            </v-row>
          </v-col>
          <v-col cols="6">
            <v-row>
              <v-toolbar-title style="padding: 10px 0px 0px 30px; font-weight: bolder">Updated</v-toolbar-title>
              <v-spacer></v-spacer>
              <v-btn style="margin: 5px" class="elevation-2"
                     text
                     @click="showDiffDialog = false">
                Cancel
              </v-btn>
              <v-divider vertical/>
              <v-btn style="margin: 5px" class="elevation-4"
                     text
                     @click="executeDownload">
                Extract
              </v-btn>
            </v-row>
          </v-col>
        </v-row>
      </v-toolbar>
      <v-card-text>
        <v-row style="width: 100%;padding:0px 10px 0px 50px">
          <v-col cols="6">
            <v-list width="100%">
              <template v-for="(service, index) in selectedServices" :value="service.name">
                <v-card v-if="service" :key="index">
                  <v-row>
                    <v-col cols="10">
                      <div style="padding: 0px 0px 0px 20px">
                        {{ service.name }}
                      </div>
                      <div style="padding: 0px 0px 0px 20px">
                        {{ service.templatePath }}
                      </div>
                    </v-col>
                    <v-col cols="2">
                    </v-col>
                  </v-row>
                  <v-card-text style="padding: 0px">
                    <v-list-item style="width: 100%; margin-left: 0px; margin-right: 0px; padding-bottom: 10px">
                      <v-list-item-content style="padding-bottom: 0px">
                        <RefDataModeledForm :key="`localForm-${index}`"
                                            v-bind:readOnly="readOnly"
                                            v-bind:service="service"
                                            v-bind:schema="service.refDataFormSchema"
                                            v-bind:filteredResults="service.filteredResults"
                                            v-model="service.formModelOriginal"/>
                      </v-list-item-content>
                    </v-list-item>
                  </v-card-text>
                </v-card>
                <v-divider
                  v-if="index < selectedServices.length - 1"
                  :key="`key-${index}`"
                ></v-divider>
              </template>
            </v-list>
          </v-col>
          <v-col cols="6">
            <v-list width="100%">
              <template v-for="(service, index) in selectedServices" :value="service.name">
                <v-card v-if="service" :key="index">
                  <v-row>
                    <v-col cols="10">
                      <div style="padding: 0px 0px 0px 20px">
                        {{ service.name }}
                      </div>
                      <div style="padding: 0px 0px 0px 20px">
                        {{ service.templatePath }}
                      </div>
                    </v-col>
                    <v-col cols="2">
                      <v-card-actions style="width: 50px; margin-left: auto" v-show="service.showError">
                        <v-tooltip bottom>
                          <template v-slot:activator="{ on, attrs }">
                            <v-icon v-bind="attrs" color="red darken-3"
                                    v-on="on">
                              mdi-alert-outline
                            </v-icon>
                          </template>
                          <span><strong>"{{ service.localWidgetVal }}"</strong> failed RegEx validation</span>
                        </v-tooltip>
                      </v-card-actions>
                    </v-col>
                  </v-row>
                  <v-card-text style="padding: 0px">
                    <v-list-item style="width: 100%; margin-left: 0px; margin-right: 0px; padding-bottom: 10px">
                      <v-list-item-content style="padding-bottom: 0px">
                        <RefDataModeledForm :key="`localForm2-${index}`"
                                            v-bind:readOnly="readOnly"
                                            v-bind:service="service"
                                            v-bind:schema="service.refDataFormSchema"
                                            v-bind:applyDiffCls="true"
                                            v-model="service.formModel"
                                            v-on:formValidated="updateValidationIcon"/>
                      </v-list-item-content>
                    </v-list-item>
                  </v-card-text>
                </v-card>
                <v-divider
                  v-if="index < selectedServices.length - 1"
                  :key="`key-${index}`"
                ></v-divider>
              </template>
            </v-list>
          </v-col>
        </v-row>
      </v-card-text>
    </v-card>
  </v-dialog>
</template>

<script>

import _ from "lodash";
import download from "downloadjs"
import uuid from "uuid"
import RefDataModeledForm from "@/refdataviewer/components/modeledform/RefDataModeledForm";
import {redirectToIndexIfNoAccessToken, redirectToIndexIfUnauthenticated} from "@/utils/RedirectToIndex";

export default {
  name: 'diffDialogWidget',
  components: {
    RefDataModeledForm
  },
  props: {
    //service: Object,
    selectedServices: Array
  },
  data: function () {
    return {
      // formModel: {}
      readOnly: true,
      showError: false,
      localWidgetVal: ''
    }
  },
  async created() {

  },
  watch: {
    formModel: function (newPath, oldPath) {
      let self = this;
      try {
        self.service.templatePath = _.template(self.service.path)(self.formModel);
      } catch (err) {
        console.log(err)
      }
    }
  },
  computed: {
    showDiffDialog: {
      get() {
        return this.$store.state.applicationData.showDiffDialog
      },
      set(value) {
        this.$store.dispatch('applicationData/setNewShowDiffDialog', value)
      }
    }
  },
  methods: {
    executeDownload: function () {
      this.$store.dispatch('applicationData/setNewActionStatusDialog', true)
      let self = this;
      let templateStr = "";
      let queryFormModel = {}
      for (let service of this.selectedServices) {
        try {
          let templateObj = _.cloneDeep(service.filteredResults)
          queryFormModel[service.name] = templateObj
          let templatedValue = ''
          templatedValue = _.template(service.refDataValueTemplate)(service.formModel);
          _.forEach(this.$store.state.modeledformData.separators, function (entry, key) {//strip out any separators
            let regex = new RegExp(entry.separator, 'gi');
            templatedValue = templatedValue.replace(regex, entry.value);
          });
          if (!new RegExp(service.valueRegex).test(templatedValue)) {
            templatedValue = templateObj['value']
          }
          templateObj.value = templatedValue;
        } catch (e) {
          //console.log('error extracting value for ' + service.name + ': ' + e)
        }
      }
      let requestObj = {
        application: self.$store.state.applicationData.selectedApplication.name,
        serviceEnv: self.$store.state.applicationData.selectedEnvironment,
        queryFormModel: queryFormModel
      };
      let responsePromise = fetch(this.$store.state.applicationData.resourceUrls.refDataTemplatedQueryRequest, {
        method: 'POST',
        headers: {
          'access-token': sessionStorage.getItem('accessToken')
        },
        body: JSON.stringify(requestObj),
      });
      responsePromise
        .then(response => {
          this.$store.dispatch('applicationData/setNewActionStatusDialog', false)
          redirectToIndexIfUnauthenticated(response);
          return response;
        })
        .then(async response => {
          response.fadRequestProxy = true;
          if (response.status === 200) {
            let parsedResponse = await response.json()
            download(parsedResponse.templatedQuery, "refDataTemplate.txt", "text/plain");
          } else {

          }
        })
        .catch(reason => {
          this.$store.dispatch('applicationData/setNewActionStatusDialog', false)
          redirectToIndexIfNoAccessToken();
          self.fetchStatus = reason.toString();
          self.requestBusy = false;
        })
    },
    updateValidationIcon: function (val, result, service) {
      service.localWidgetVal = result
      service.showError = !val
    }
  }
}
</script>

<style>
.btn {
  /*padding: 6px 12px 3px;*/
}
</style>
