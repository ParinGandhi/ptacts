<template>
  <div style="border: 1px solid #ccc; margin-bottom: 0px; background-image: linear-gradient(to bottom, #fff 0%, #e0e0e0 100%)" class="elevation-1">
    <v-list-item style="margin-left: 50px; height: 60px" v-if="localService.formSchema.length == 0"
                 :key="localService.name" active-class="">
      <template v-slot:default="{}">
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <v-list-item-icon style="margin-right: 2px"
                              v-bind="attrs"
                              v-on="on">
              <v-icon :class="selectedCls">mdi-information</v-icon>
            </v-list-item-icon>
          </template>
          <v-row style="max-width: 700px">
            <v-col v-if="localService.legend">
              <h3>Legend</h3>
              <ul>
                <li v-for="(legend ,index) in localService.legend" v-bind:key="index">
                  <span v-html="legend"></span>
                </li>
              </ul>
            </v-col>
            <v-col v-if="localService.notes">
              <h3>Notes</h3>
              <ul class="">
                <li v-for="(note ,index) in localService.notes" v-bind:key="index">
                  <span v-html="note"></span>
                </li>
              </ul>
            </v-col>
          </v-row>
        </v-tooltip>
        <v-list-item-content>
          <v-list-item-title :class="selectedCls" style="font-size: 15px"
                             v-text="localService.name"></v-list-item-title>
          <v-list-item-subtitle :class="selectedCls" v-text="templatePath"></v-list-item-subtitle>
        </v-list-item-content>
        <v-list-item-action>
          <v-icon @click="inputClicked($event)"
                  v-if="!checked"
                  color="black blue darken-3"
          >
            mdi-checkbox-blank-outline
          </v-icon>

          <v-icon @click="inputClicked($event)" :class="selectedCls"
                  v-else
                  color="darken-3"
          >
            mdi-checkbox-marked-outline
          </v-icon>
        </v-list-item-action>
      </template>
    </v-list-item>
    <v-list-group
      :key="localService.name"
      @click.prevent="listGroupClicked"
      :value="expandHeader"
      sub-group
      :ripple="false"
      v-else-if="localService.formSchema.length > 0">
      <template v-slot:activator>
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <v-list-item-icon style="margin-right: 2px"
                              v-bind="attrs"
                              v-on="on">
              <v-icon :class="selectedCls">mdi-information</v-icon>
            </v-list-item-icon>
          </template>
          <v-row style="max-width: 700px">
            <v-col>
              <h3>Legend</h3>
              <ul>
                <li v-for="(legend ,index) in localService.legend" v-bind:key="index">
                  <span v-html="legend"></span>
                </li>
              </ul>
            </v-col>
            <v-col>
              <h3>Notes</h3>
              <ul class="">
                <li v-for="(note ,index) in localService.notes" v-bind:key="index">
                  <span v-html="note"></span>
                </li>
              </ul>
            </v-col>
          </v-row>
        </v-tooltip>
        <v-list-item style="padding: 0px 0px 0px 0px">
          <v-list-item-content style="height: 60px; width: 100px">
            <v-list-item-title :class="selectedCls" v-text="localService.name"
                               style="font-size: 15px"></v-list-item-title>
            <v-list-item-subtitle :class="selectedCls" v-text="templatePath"></v-list-item-subtitle>
          </v-list-item-content>
          <v-list-item-action>
            <v-icon @click="subGroupInputClicked($event)" v-show="!showRequired"
                    v-if="!checked"
                    color="black blue darken-3">
              mdi-checkbox-blank-outline
            </v-icon>
            <v-icon @click="subGroupInputClicked($event)" v-show="!showRequired" :class="selectedCls"
                    v-else>
              mdi-checkbox-marked-outline
            </v-icon>
            <v-tooltip bottom>
              <template v-slot:activator="{ on, attrs }">
                <v-icon v-bind="attrs"
                        color="red darken-3" v-show="showRequired"
                        v-on="on">
                  mdi-alert-outline
                </v-icon>
              </template>
              <span>Complete required fields</span>
            </v-tooltip>
          </v-list-item-action>
        </v-list-item>
      </template>
      <v-list-item class="pl-10">
        <v-list-item-content>
          <RefDataFormWidget v-model="localService.templatePath"
                             v-bind:service="localService"
                             v-bind:templatePath="localService.templatePath"
                             v-on:templatePathChanged="updateTemplatePath"/>
        </v-list-item-content>
      </v-list-item>
    </v-list-group>
  </div>
</template>

<script>

import _ from "lodash";
import RefDataFormWidget from "@/refdataviewer/components/widets/RefDataFormWidget"

export default {
  name: 'serviceSelectionCheckboxWidget',
  components: {
    RefDataFormWidget
  },
  props: {
    service: Object,
    serviceChecked: {
      type: Boolean,
      required: true
    },
    serviceCheckedProxy: {//needed to monitor check all/uncheck all events
      type: Boolean,
      required: true
    }
  },
  data: function () {
    return {
      count: 5,
      selectedCls: '',
      templatePath: '',
      checked: false,
      expandHeader: false,
      templated: false,
      showRequired: false
    }
  },
  async created() {
  },
  mounted: function () {
    this.templatePath = this.service.templatePath
  },
  updated() {
  },
  methods: {
    listGroupClicked: function (event) {
      this.expandHeader = false
      event.preventDefault()
    },
    subGroupInputClicked: function () {
      if (this.templated) {
        if (this.checked) {
          this.selectedCls = ''
        } else {
          this.selectedCls = 'fad-selection-service-selected'
        }
        this.checked = !this.checked
      } else {
        this.showRequired = true
      }
      this.expandHeader = !this.expandHeader
      this.$emit('checkBoxChanged', this.checked, this.service);
    },
    inputClicked: function (event, service) {
      if (this.checked) {
        this.selectedCls = ''
      } else {
        this.selectedCls = 'fad-selection-service-selected'
      }
      this.checked = !this.checked
      this.$emit('checkBoxChanged', this.checked, this.service);
    },
    updateTemplatePath: function (path) {
      this.templatePath = path
      this.templated = true
      this.showRequired = false
      this.checked = true
      this.selectedCls = 'fad-selection-service-selected'
      this.$emit('templatePathChanged', path, this.checked, this.service);
    }
  },
  watch: {
    serviceChecked: {//updates the checkbox when this value changes outside this component
      handler(newPath, oldPath) {
        let self = this;
        if (this.serviceChecked) {
          this.selectedCls = 'fad-selection-service-selected'
          this.checked = true
        } else {
          this.selectedCls = ''
          this.checked = false
        }
      },
      deep: true
    },
    serviceCheckedProxy: {
      handler(newPath, oldPath) {
        let self = this;
        if (this.checked == this.serviceCheckedProxy) {
          return
        }
        if (this.localService.formSchema.length == 0) {
          this.inputClicked()
        } else {
          this.subGroupInputClicked()
        }
      },
      deep: true
    }
  },
  computed: {
    localService: {
      get() {
        return this.service
      },
      set(value) {
        let self = this;
      }
    }
  }
}
</script>

<style>
.fad-selection-service-selected {
  color: #1C8222 !important;
}
</style>
