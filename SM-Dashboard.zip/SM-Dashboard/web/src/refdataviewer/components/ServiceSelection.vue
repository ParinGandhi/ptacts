<template>
  <v-container class="grey lighten-5" fluid
               style="padding: 0px; margin: 0px 0px 0px 0px; background-color: #d5d5d5 !important;" fill-height
               align-start>
    <v-row no-gutters align="start" align-self="start" style="height: 100%;">
      <v-col v-if="selectedApplication"
             style="padding: 0px; background-color: #d5d5d5; height: 100%; margin: 12px 0px 0px 0px" cols="3">
        <v-row style="padding:  0px 13px 0px 10px; height: 54px" align="start">
          <v-card height="53px" flat width="100%" style="background-color: #d5d5d5">
             <span class="fad-dropdown-refdata nav navbar-nav navbar-left" style="padding-left: 22px; height: 40px">
                <span class="dropdown fad-dropdown-refdata-li"
                      v-on:click="envDropdownOpen = !envDropdownOpen"
                      v-click-outside="closeEnvDropdown"
                      v-bind:class="{open: envDropdownOpen}">
                    <div class="dropdown-toggle fad-dropdown-refdata-li" data-toggle="dropdown" role="button"
                         aria-haspopup="true"
                         v-bind:aria-expanded="envDropdownOpen.toString()">
                          <h2>Environments: &nbsp;{{ this.$store.state.applicationData.selectedEnvironment.label }}
                            <span class="caret"/>
                          </h2>
                    </div>
                    <ul class="dropdown-menu" style="padding-left: 0px">
                        <li v-for="envItem in environments" v-bind:key="envItem.env">
                          <a href="#" v-on:click="updateEnvServices(envItem)">
                            <span>{{ envItem.label }}</span>
                          </a>
                        </li>
                    </ul>
                </span>
             </span>
            <v-tooltip left v-model="showCheckTooltip">
              <template v-slot:activator="{ on, attrs }">
                <v-hover v-model="checkBoxHover">
                <v-checkbox @click="serviceCheckedProxy = !serviceCheckedProxy"
                            style="width: 25px; margin-left: auto; margin-right: 27px"
                            v-bind="attrs"
                            @focus="on">
                </v-checkbox>
                </v-hover>
              </template>
              <span>{{checkAllText}}</span>
            </v-tooltip>
          </v-card>
        </v-row>
        <v-row style="padding:  0px 13px 0px 0px; overflow: hidden; height: 100%; min-height: 50px; background-color: #ECEFF1"
          align="start" align-self="start">
          <ResizableServiceSelectionContainer style="width: 100%">
            <template v-slot:resizer="styles">
              <v-list
                dense
                flat
                :style="styles.styleProp">
                <v-list-group class="elevation-4"
                              :value="true"
                              v-for="item in groupedServices"
                              active-class=""
                              :key="item.title">
                  <template v-slot:activator>
                    <v-list-item-content style="height: 60px">
                      <v-list-item-title v-text="item.title" style="font-size: 18px; margin: 0px 0px 0px 15px; font-weight: bolder"></v-list-item-title>
                    </v-list-item-content>
                  </template>
                  <v-list-item-group class="elevation-3" style="background-color: #ECEFF1" active-class="">
                    <template v-for="(child) in item.items">
                      <ServiceSelectionCheckboxWidget
                        v-if="child"
                        v-bind:key="'serviceCheckbox'+child.name"
                        v-bind:service="child"
                        v-bind:serviceChecked="child.checked"
                        v-bind:selectedServices="selectedServices"
                        v-bind:serviceCheckedProxy="serviceCheckedProxy"
                        v-on:templatePathChanged="updateTemplatePath"
                        v-on:checkBoxChanged="checkBoxChanged"/>
                    </template>
                  </v-list-item-group>
                </v-list-group>
                <v-divider></v-divider>
                <v-list-item-group class="elevation-4"
                                   active-class=""
                                   color="primary">
                  <template v-for="child in unGroupedServices">
                    <ServiceSelectionCheckboxWidget
                      v-if="child"
                      v-bind:key="'serviceCheckbox'+child.name"
                      v-bind:service="child"
                      v-bind:serviceChecked="child.checked"
                      v-bind:selectedServices="selectedServices"
                      v-bind:serviceCheckedProxy="serviceCheckedProxy"
                      v-on:templatePathChanged="updateTemplatePath"
                      v-on:checkBoxChanged="checkBoxChanged"/>
                  </template>
                </v-list-item-group>
              </v-list>
            </template>
          </ResizableServiceSelectionContainer>
        </v-row>
      </v-col>
      <v-col style="padding: 0px; height: 100%; margin: 12px 0px 0px 0px" cols="9">
        <div v-if="!selectedApplication" class="fad-service-widget-blank">
          <div v-if="this.$store.state.applicationData.applications.length === 0" class="fad-service-widget-blank">
            <h1>There are no applications with approved environments configured</h1>
          </div>
          <div v-if="this.$store.state.applicationData.applications.length > 0" class="fad-service-widget-blank"
               style="margin: 0px 0px 0px 100px">
            <h1>Select an application to get started.</h1>
          </div>
        </div>
        <ResponseView v-if="selectedApplication"
                      v-bind:selectedServices="selectedServices"
                      v-bind:application="selectedApplication"
                      v-bind:requestUrl="requestUrl"
                      v-on:removeService="removeService"/>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import {prettyPathNotation} from '../../dashboard/filters'
import _ from "lodash";
import ServiceWidget from "./ServiceWidget"
import ResponseView from "@/refdataviewer/components/ResponseView";
import ServiceSelectionCheckboxWidget from "@/refdataviewer/components/widets/ServiceSelectionCheckboxWidget"
import vClickOutside from 'v-click-outside';
import ModeledForm from "../../dashboard/components/modeledform/ModeledForm";
import ResizableServiceSelectionContainer from "@/refdataviewer/components/ResizableServiceSelectionContainer";

export default {
  name: 'ServiceSelection',
  components: {
    ResizableServiceSelectionContainer,
    ServiceSelectionCheckboxWidget,
    ResponseView
  },
  data: function () {
    return {
      envDropdownOpen: false,
      tab: null,
      serviceCheckedProxy: false,//all child items listen to the property for check all/uncheck all events
      showCheckTooltip: false,
      checkBoxHover: false,
      checkAllText: 'Check All'
    }
  },
  watch: {
    checkBoxHover: function(){
      this.checkAllText = this.serviceCheckedProxy ? 'Uncheck All' : 'Check All'
      if(this.checkBoxHover){
        this.showCheckTooltip = true
      }else{
        this.showCheckTooltip = false
      }
    },
    services: function () {
      this.$store.dispatch('serviceData/setNewSelectedService', null)
    }
  },
  methods: {
    updateEnvServices: function (envItem) {
      this.selectedServices.splice(0, this.selectedServices.length);
      this.$store.dispatch('applicationData/setNewSelectedEnvironment', envItem)
      let filteredList = []
      _.forEach(this.$store.state.applicationData.selectedApplication.services, service => {
        if (envItem && _.find(service.environments, env => env.env == envItem.env)) {
          service.standardFormModel = {}
          filteredList.push(service)
        }
      })
      this.$store.dispatch('serviceData/setNewFilteredServices', filteredList)

      let groupedServices = _.groupBy(filteredList, item => {
        let key = null;
        if (item['groupInfo'] && item.groupInfo['groupId']) {
          key = item.groupInfo['groupId'];
        } else {
          return "unGrouped"
        }
        return key;
      });
      let groupedList = []
      let groupIds = _.keys(groupedServices);
      for (const groupId of groupIds) {
        if (groupId != "unGrouped") {
          let svc = groupedServices[groupId]
          let gTitle = groupId
          try {
            gTitle = svc[0].groupInfo.title
          }catch (e) {
          }
          groupedList.push({
            title: gTitle,
            items: svc
          })
        }
      }
      this.$store.dispatch('serviceData/setNewFilteredGroupedServices', []).then(() => {
        this.$store.dispatch('serviceData/setNewFilteredGroupedServices', groupedList)
      })
      this.$store.dispatch('serviceData/setNewUnGroupedFilteredServices', []).then(() => {
        this.$store.dispatch('serviceData/setNewUnGroupedFilteredServices', groupedServices["unGrouped"])
      })
    },
    closeEnvDropdown: function () {
      this.envDropdownOpen = false;
    },
    updateTemplatePath: function (path, isChecked, service) {
      if (isChecked) {
        let p = new Promise((resolve, reject) => {
          let foundSvc = _.find(this.selectedServices, svc => svc.name == service.name)
          if (foundSvc) {
            this.selectedServices.splice(_.indexOf(this.selectedServices, foundSvc), 1);
          }
          resolve()
        }).then(() => {
          service.templatePath = path
          this.selectedServices.splice(_.sortedIndexBy(this.selectedServices, service, 'name'), 0, service);
        })
        service.checked = true
      } else {
        service.templatePath = path
      }
    },
    removeService: function (isChecked, service) {
      let foundSvc = _.find(this.selectedServices, svc => svc.name == service.name)
      if (foundSvc) {
        this.selectedServices.splice(_.indexOf(this.selectedServices, foundSvc), 1);
        service.checked = false
      }
    },
    checkBoxChanged: function (isChecked, service) {
      if (isChecked) {
        service.formModel = {}
        if (_.find(this.selectedServices, svc => svc.name == service.name)) {
          let foundSvc = _.find(this.selectedServices, svc => svc.name == service.name)
          if (foundSvc) {
            this.selectedServices.splice(_.indexOf(this.selectedServices, foundSvc), 1);
          }
        } else {
          this.selectedServices.splice(_.sortedIndexBy(this.selectedServices, service, 'name'), 0, service);
        }
        service.checked = true
      } else {
        let foundSvc = _.find(this.selectedServices, svc => svc.name == service.name)
        if (foundSvc) {
          this.selectedServices.splice(_.indexOf(this.selectedServices, foundSvc), 1);
        }
        service.checked = false
      }
    }
  },
  directives: {
    clickOutside: vClickOutside.directive,
  },
  props: {
    selectedApplication: String,
    requestUrl: String
  },
  filters: {
    prettyPathNotation,
  },
  computed: {
    services: {
      get() {
        return this.$store.state.serviceData.filteredServices
      },
      set(value) {
      }
    },
    groupedServices: {
      get() {
        return this.$store.state.serviceData.filteredGroupedServices
      },
      set(value) {
      }
    },
    unGroupedServices: {
      get() {
        return this.$store.state.serviceData.unGroupedFilteredServices
      },
      set(value) {
      }
    },
    selectedService: {
      get() {
        return this.$store.state.serviceData.selectedService
      },
      set(value) {
      }
    },
    selectedServices: {
      get() {
        return this.$store.state.serviceData.selectedServices
      },
      set(value) {
        this.$store.dispatch('serviceData/setNewSelectedServices', value)
      }
    },
    environments: {
      get() {
        return this.$store.state.applicationData.environments
      },
      set(value) {
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.fad-service-selection {
  display: flex;
  flex-direction: row;
  flex: 1;
  -ms-flex: 1 1 auto;
  height: 100%;
}

.fad-left-menu {
  background-color: #fbfbfb;
  color: #444;
  box-shadow: inset 0 0 80px #d5d5d5;

  -ms-flex-negative: 0; /* Fix IE shrinking too thin */
  width: 225px;
  padding-top: 20px;
}

.fad-left-menu-services {
  width: 100%;
  padding-left: -15px;
  padding-right: -15px;
}

.fad-right-menu {
  background-color: #fbfbfb;
  color: #444;
  box-shadow: inset 0 0 80px #d5d5d5;

  -ms-flex-negative: 0; /* Fix IE shrinking too thin */
  width: 225px;
  font-family: inherit;
}

.fad-nav-service.nav {
  margin: 0;
}

.fad-dropdown-refdata.nav {
  margin: 0;
  padding-bottom: 0px;
}

.fad-dropdown-refdata-li {
  position: relative !important;
  display: block !important;
  padding: 0px 0px !important;
}

.fad-dropdown-refdata-li h2 {
  white-space: nowrap;
  font-size: 18px;
  font-weight: 500;
  padding-bottom: 0px;
}

.fad-dropdown-refdata-li h2:hover {
  color: black;
}

.btn-group-vertical .btn {
  border-radius: 0 !important;
  height: 60px;
  font-size: 15px;
  text-align: left;
}

.btn-group-vertical .btn.active {
  background-color: #d8effb;
}

.fad-service-path {
  display: block;
  font-size: 10px;
  letter-spacing: -.5px;
  font-family: "Fira Mono", monospace;
  overflow: hidden;
  text-overflow: ellipsis;
}

.fad-service-widget-blank {
  display: flex;
  flex: 1;
  -ms-flex: 1 1 100%;
  color: #cfe2ea;
  background-color: #055072;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.fad-service-widget-blank h1 {
  margin-top: 200px;
  padding: 0;
  display: table-cell;
  text-align: center;
  vertical-align: middle;
}
</style>

<style>
.fad-service-selection h2 {
  font-size: 25px;
  margin-top: 5px;
  margin-bottom: 20px;
}
</style>
