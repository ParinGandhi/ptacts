<template>
  <v-row :class="diffCls">
    <v-col v-show="!showStandardText">
      <v-menu
        v-model="menu1"
        :close-on-content-click="false"
        :nudge-right="40"
        transition="scale-transition"
        offset-y
        min-width="auto">
        <template v-slot:activator="{ on, attrs }">
          <v-text-field
            v-bind="attrs"
            :value="computedDateFormattedMomentjs"
            :label="schema.title"
            prepend-icon="mdi-calendar"
            readonly
            v-on="on"
          ></v-text-field>
        </template>
        <v-date-picker
          v-model="date"
          @input="updateValue"
          :readonly="readOnly"
        ></v-date-picker>
      </v-menu>
    </v-col>
    <v-col v-if="schema.timeParseInfo" cols="4" v-show="!showStandardText">
      <v-menu
        ref="menu"
        v-model="menu2"
        :close-on-content-click="false"
        :nudge-right="40"
        :return-value="time"
        transition="scale-transition"
        offset-y
        max-width="290px"
        min-width="290px">
        <template v-slot:activator="{ on, attrs }">
          <v-text-field
            v-bind="attrs"
            v-model="time"
            readonly
            v-on="on"></v-text-field>
        </template>
        <v-time-picker
          v-if="menu2"
          v-model="time"
          format="24hr"
          use-seconds
          full-width
          :readonly="readOnly"
          @click:second="$refs.menu.save(time)"></v-time-picker>
      </v-menu>
    </v-col>
    <v-col cols="11" v-show="showStandardText">
      <v-text-field :class="diffCls" v-show="showStandardText"
                    label="Value"
                    v-model="textValParseFail"
                    v-bind:aria-required="schema.required"
                    :readonly="readOnly"
      ></v-text-field>
    </v-col>
    <v-col v-show="regexError" cols="1" style="padding: 40px 0px 0px 0px">
      <v-tooltip bottom>
        <template v-slot:activator="{ on, attrs }">
          <v-icon v-bind="attrs" color="red darken-3"
                  v-on="on">
            mdi-alert-outline
          </v-icon>
        </template>
        <span>{{ localWidgetVal }} failed RegEx validation</span>
      </v-tooltip>
    </v-col>
  </v-row>
</template>

<script>
import moment from "moment";

export default {
  name: "RefDataModeledFormDate",
  props: {
    service: Object,
    value: String,
    schema: Object,
    filteredResults: Object,
    applyDiffCls: Boolean,
    readOnly: Boolean
  },
  data: () => ({
    time: "00:00:00",
    dateLocal: null,
    menu1: false,
    menu2: false,
    showMenu2: false,
    diffCls: "",
    parseFailed: false,
    showStandardText: false,
    regexError: false,
    textValParseFail: '',
    localWidgetVal: ''
  }),
  mounted: function () {
    this.dateLocal = this.date;
    if (!this.value && this.schema.default) {//set the default if value not already set
      if (new RegExp(this.schema.dateParseInfo.matchDatePattern).test(this.schema.default)) {
        this.setDateTimeValue(this.schema.default)
      } else {
        this.$refs.box.value = this.schema.default;
        this.$emit('input', this.schema.default)
      }
    } else if (this.filteredResults != null && this.filteredResults['value']) {//set the filtered values if available

      if (new RegExp(this.schema.dateParseInfo.matchDatePattern).test(this.filteredResults['value'])) {
        this.setDateTimeValue(this.filteredResults['value'])
      } else {
        this.$emit('input', this.filteredResults['value'])
      }
    } else {
      if (this.value) {//set the formModel value if provided
        if (this.schema.timeParseInfo) {
          let timeDateArr = this.value.split(this.$store.state.modeledformData.separators.dateTimeSeparators.separator)
          this.dateLocal = moment(timeDateArr[0], this.schema.dateParseInfo.dateFormat).format('YYYY-MM-DD')
          this.time = timeDateArr[1]
          this.$emit('input', timeDateArr[0] + this.$store.state.modeledformData.separators.dateTimeSeparators.separator + timeDateArr[1]);
          if (this.dateLocal == 'Invalid date') {
            this.parseFailed = true
          }
        } else {
          this.dateLocal = moment(this.value, this.schema.dateParseInfo.dateFormat).format('YYYY-MM-DD')
          this.$emit('input', this.value);
          if (this.dateLocal == 'Invalid date') {
            this.parseFailed = true
          }
        }
      }
    }
    if (this.service) {//apply the diff style
      let updatedVal = this.service.formModel[this.schema.id]
      let originalVal = this.service.formModelOriginal[this.schema.id]
      if (this.applyDiffCls && updatedVal != null && updatedVal.localeCompare(originalVal, undefined, {sensitivity: 'accent'}) !== 0) {
        this.diffCls = "diffCls"
      }
      if (this.readOnly && this.parseFailed) {
        this.textValParseFail = this.value
        this.showStandardText = true
      }
    }
  },
  watch: {
    time: function () {
      let dateVal = moment(this.dateLocal, 'yyyy-MM-DD').format(this.schema.dateParseInfo.dateFormat)
      dateVal = this.schema.dateParseInfo.toUpperCase ? dateVal.toUpperCase() : dateVal
      this.$emit('input', dateVal + this.$store.state.modeledformData.separators.dateTimeSeparators.separator + this.time)
    }
  },
  methods: {
    updateValue: function () {
      this.menu1 = false
      this.menu2 = false
      let dateVal = moment(this.dateLocal, 'yyyy-MM-DD').format(this.schema.dateParseInfo.dateFormat)
      dateVal = this.schema.dateParseInfo.toUpperCase ? dateVal.toUpperCase() : dateVal
      if (this.schema.timeParseInfo) {
        this.$emit('input', dateVal + this.$store.state.modeledformData.separators.dateTimeSeparators.separator + this.time)
      } else {
        this.$emit('input', dateVal)
      }
    },
    setDateTimeValue(filteredResult) {
      let regexStr = this.schema.dateParseInfo.matchDatePattern
      let regex = new RegExp(regexStr);
      let resultArr = regex.exec(filteredResult);
      if (resultArr && resultArr.length > 0) {
        let value = resultArr[this.schema.dateParseInfo.matchGroup]
        this.dateLocal = moment(value, this.schema.dateParseInfo.dateFormat).format('YYYY-MM-DD')
        if (this.schema.timeParseInfo) {
          this.time = resultArr[this.schema.timeParseInfo.matchGroup]
          this.$emit('input', value + this.$store.state.modeledformData.separators.dateTimeSeparators.separator + this.time);
        } else {
          this.$emit('input', value);
        }
      }
    }
  },
  computed: {
    computedDateFormattedMomentjs() {
      return this.dateLocal ? moment(this.dateLocal, 'yyyy-MM-DD').format(this.schema.dateParseInfo.dateFormat) : ''
    },
    date: {
      get() {
        let val = this.value && this.value != 'Invalid date' ? moment(this.value, this.schema.dateParseInfo.dateFormat).format('yyyy-MM-DD') : null//moment(new Date(), this.schema.dateParseInfo.dateFormat).format('yyyy-MM-DD')
        return val == 'Invalid date' ? '' : val
        //return val
      },
      set(value) {
        this.dateLocal = value
      }
    }
  }
}
</script>

<style scoped>
.diffCls {
  background-color: lightyellow !important;
}

.errorCls {
  background-color: lightcoral !important;
}
</style>
