<template>
  <v-container class="grey lighten-5">
    <v-row
      v-for="item in schema"
      :key="item.id">
      <v-col md="12">
        <v-card style="padding: 0px 4px 0px 4px !important;"
          class="pa-2"
          outlined
          tile>
          <form v-on:submit="$emit('submit', $event)">
          <component
            v-bind:key="`component-${item.id}`"
            v-bind:is="getComponent(item.type)"
            v-bind:service="service"
            v-bind:schema="item"
            v-bind:value="value[item.id]"
            v-bind:filteredResults="filteredResults"
            v-bind:applyDiffCls="applyDiffCls"
            v-bind:readOnly="readOnly"
            v-on:input="update($event, item)"/>
          </form>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import {getComponent} from "./ref-data-modeled-form-utils";
import RefDataModeledFormSelect from "./RefDataModeledFormSelect";
import RefDataModeledFormText from "./RefDataModeledFormText";
import RefDataModeledFormDate from "./RefDataModeledFormDate";
import RefDataModeledFormSwitch from "./RefDataModeledFormSwitch";

import _ from "lodash";

export default {
  name: "RefDataModeledForm",
  props: {
    service: Object,
    value: Object, // model
    schema: Array,
    filteredResults: Object,
    applyDiffCls:Boolean,
    readOnly: Boolean
  },
  components: {
    RefDataModeledFormSelect,
    RefDataModeledFormText,
    RefDataModeledFormDate,
    RefDataModeledFormSwitch
  },
  watch: {
    schema: function (newValue, oldValue) {
      const newIds = _.map(newValue, item => item.id);
      _.map(oldValue, item => item.id)
        .filter(id => !newIds.includes(id))
        .forEach(removedId => this.$delete(this.value, removedId));
    }
  },
  methods: {
    getComponent: getComponent,
    update: function (newValue, item) {
      this.value[item.id] = newValue;
      this.$emit('input', Object.assign({}, this.value));
      this.validateValue();
    },
    validateValue:function(){
      try {
        let templatedValue = ''
        templatedValue = _.template(this.service.refDataValueTemplate)(this.value);
        _.forEach(this.$store.state.modeledformData.separators, function (entry, key) {//strip out any separators
          let regex = new RegExp(entry.separator, 'gi');
          templatedValue = templatedValue.replace(regex, entry.value);
        });
        if (!new RegExp(this.service.valueRegex).test(templatedValue)) {
          this.service.localWidgetVal = templatedValue
          this.service.showError = true
          this.$emit('formValidated', false, templatedValue, this.service);
        }else{
          this.service.localWidgetVal = templatedValue
          this.service.showError = false
          this.$emit('formValidated', true, templatedValue, this.service);
        }
      } catch (e) {
        //console.log('error extracting value for ' + this.service.name + ': ' + e)
      }
    }
  },
}
</script>

<style>
.form-control {
  border-radius: 0 !important;
}

.btn {
  border-radius: 0 !important;
}

.modeled-form fieldset {
  border: 1px solid;
  padding: 10px;
}

.modeled-form legend {
  padding: 0 10px;
  margin: 0;
  width: auto;
  border: 0;
}

.required:before {
  content: "* ";
  color: #f2adad; /* Choosing this color because it has the proper contrast with the background*/
}
</style>
