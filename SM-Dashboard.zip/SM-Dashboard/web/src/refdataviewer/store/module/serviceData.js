const state = () => ({
  selectedService: null,
  serviceResetSwitch:false,
  selectedServices: [],
  filteredServices: [],
  filteredGroupedServices: [],
  unGroupedFilteredServices: [],
  refDataRequestUrl:''
})

const getters = {
  getSelectedApplication: (state) => {
    return state.selectedService;
  },
  getServiceResetSwitch: (state) => {
    return state.serviceResetSwitch;
  },
  getSelectedServices: (state) => {
    return state.selectedServices;
  },
  getFilteredServices: (state) => {
    return state.filteredServices;
  },
  getFilteredGroupedServices: (state) => {
    return state.filteredGroupedServices;
  },
  getUnGroupedFilteredServices: (state) => {
    return state.unGroupedFilteredServices;
  },
  getRefDataRequestUrl: (state) => {
    return state.refDataRequestUrl;
  }
}

const mutations = {
  setSelectedService(state, svc) {
    state.selectedService = svc;
  },
  setSelectedServices(state, svc) {
    state.selectedServices = svc;
  },
  setServiceResetSwitch(state, svc) {
    state.serviceResetSwitch = svc;
  },
  setFilteredServices(state, svc) {
    state.filteredServices = svc;
  },
  setFilteredGroupedServices(state, svc) {
    state.filteredGroupedServices = svc;
  },
  setUnGroupedFilteredServices(state, svc) {
    state.unGroupedFilteredServices = svc;
  },
  setRefDataRequestUrl(state, svc) {
    state.refDataRequestUrl = svc;
  }
}

const actions = {
  setNewSelectedService({commit}, svc) {
    return new Promise((resolve, reject) => {
      commit('setSelectedService', svc)
      resolve()
    })
  },
  setNewSelectedServices({commit}, svc) {
    return new Promise((resolve, reject) => {
      commit('setSelectedServices', svc)
      resolve()
    })
  },
  setNewServiceResetSwitch({commit}, svc) {
    return new Promise((resolve, reject) => {
      commit('setServiceResetSwitch', svc)
      resolve()
    })
  },
  setNewFilteredServices({commit}, svc) {
    return new Promise((resolve, reject) => {
      commit('setFilteredServices', svc)
      resolve()
    })
  },
  setNewFilteredGroupedServices({commit}, svc) {
    return new Promise((resolve, reject) => {
      commit('setFilteredGroupedServices', svc)
      resolve()
    })
  },
  setNewUnGroupedFilteredServices({commit}, svc) {
    return new Promise((resolve, reject) => {
      commit('setUnGroupedFilteredServices', svc)
      resolve()
    })
  },
  setNewRefDataRequestUrl({commit}, svc) {
    return new Promise((resolve, reject) => {
      commit('setRefDataRequestUrl', svc)
      resolve()
    })
  }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
