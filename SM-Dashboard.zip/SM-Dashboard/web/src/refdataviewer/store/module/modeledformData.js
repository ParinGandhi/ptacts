const state = () => ({
  separators: {
    dateTimeSeparators: {
      separator: '####',
      value: ':'
    }
  },
})

const getters = {
  getSeparators: (state) => {
    return state.separators;
  }
}

const mutations = {
  setSeparators(state, newInput) {
    state.separators = newInput;
  }
}

const actions = {
  setNewSeparators({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setSeparators', app)
      resolve()
    })
  }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
