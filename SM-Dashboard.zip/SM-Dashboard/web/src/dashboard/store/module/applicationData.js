const state = () => ({
  applications: [],
  selectedApplication: {},
  selectedEnvironment: {},
  environments: [],
  resourceUrls:{}
})

const getters = {
  getSelectedApplication: (state) => {
    return state.selectedApplication;
  }, getSelectedEnvironment: (state) => {
    return state.selectedEnvironment;
  }, getEnvironments: (state) => {
    return state.environments;
  }, getResourceUrls: (state) => {
    return state.resourceUrls;
  }
}

const mutations = {
  setApplications(state, apps) {
    state.applications = apps
  },
  setSelectedApplication(state, app) {
    state.selectedApplication = app
  },
  setSelectedEnvironment(state, app) {
    state.selectedEnvironment = app
  },
  setEnvironments(state, app) {
    state.environments = app
  },
  setResourceUrls(state, app) {
    state.resourceUrls = app
  }
}

const actions = {
  setNewApplications({commit}, apps) {
    commit('setApplications', apps)
  },
  setNewSelectedApplication({commit}, app) {
    return new Promise((resolve, reject) => {
        commit('setSelectedApplication', app)
        resolve()
    })
  },
  setNewSelectedEnvironment({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setSelectedEnvironment', app)
      resolve()
    })
  },
  setNewEnvironments({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setEnvironments', app)
      resolve()
    })
  },
  setNewResourceUrls({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setResourceUrls', app)
      resolve()
    })
  }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
