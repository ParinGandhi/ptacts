<template>
  <div class="fad-service-selection">
    <div class="fad-left-menu col-sm-12 col-md-2 col-lg-2" v-if="selectedApplication">
       <div class="fad-dropdown-envselect">
        <span class="dropdown fad-dropdown-envselect-li"
              v-on:click="envDropdownOpen = !envDropdownOpen"
              v-click-outside="closeEnvDropdown"
              v-bind:class="{open: envDropdownOpen}">
          <div class="dropdown-toggle fad-dropdown-envselect-li" data-toggle="dropdown" role="button" aria-haspopup="true"
               v-bind:aria-expanded="envDropdownOpen.toString()">
            <h2>Environments: &nbsp;{{ this.$store.state.applicationData.selectedEnvironment.label }} <span
              class="caret"/></h2>
          </div>
          <ul class="dropdown-menu" style="padding-left: 0px">
            <li v-for="envItem in environments" v-bind:key="envItem.env">
              <a href="#" v-on:click="updateEnvServices(envItem)">
                <span>{{ envItem.label }}</span>
              </a>
            </li>
          </ul>
        </span>
      </div>
      <div class="row">
        <div class="fad-left-menu-services btn-group-vertical">
          <button v-for="service in services"
                  v-bind:key="service.name"
                  v-bind:class="{active: service === selectedService}"
                  v-on:click="selectService(service)"
                  class="btn btn-default"
                  type="button">
            {{ service.name }}
            <!-- <span class="fad-service-path text-muted">{{ service.path | prettyPathNotation }}</span> -->
            <span class="fad-service-path text-muted">{{ newFilters }}</span>
          </button>
        </div>
      </div>
    </div>
    <service-widget
      v-if="selectedService"
      v-bind:key="selectedApplication + selectedService.name"
      v-bind:service="selectedService"
      v-bind:application="selectedApplication"
      v-bind:requestUrl="requestUrl"/>
    <div v-if="!selectedService" class="fad-service-widget-blank">
      <div v-if="this.$store.state.applicationData.applications.length === 0" class="fad-service-widget-blank">
        <h1>There are no applications with approved environments configured</h1>
      </div>
      <div v-if="this.$store.state.applicationData.applications.length > 0" class="fad-service-widget-blank">
        <h1>Select an application and a service to get started.</h1>
      </div>
    </div>
    <div class="fad-right-menu col-sm-12 col-md-2 col-lg-2">
      <HistoryView v-bind:historyRequestUrl="historyUrl"/>
    </div>
  </div>
</template>

<script>
import ServiceWidget from "./ServiceWidget"
import vClickOutside from 'v-click-outside'
import {prettyPathNotation} from '../filters'
import HistoryView from './HistoryView';
import _ from "lodash";

export default {
  name: 'ServiceSelection',
  components: {
    ServiceWidget,
    HistoryView
  },
  data: function () {
    return {
      envDropdownOpen: false
    }
  },
  watch: {
    services: function () {
      // this.selectedService = null;
      this.$store.dispatch('serviceData/setNewSelectedService', null)
    }
  },
  methods: {
    selectService: function (service) {
      // this.selectedService = service;
      if (this.selectedService == null || this.selectedService.name != service.name) {
        this.$store.dispatch('modeledformData/setNewFormModel', {})
        this.$store.dispatch('serviceData/setNewSelectedService', service)
        this.$store.dispatch('modeledformData/setNewCurrentInput', 'formInput')
        this.$store.dispatch('modeledformData/setNewRawInputPath', prettyPathNotation(service.path))
        this.$store.dispatch('modeledformData/setNewRawInputHeaders', service.headers.join('\n'))
        this.$store.dispatch('modeledformData/setNewRawInputBody', service.body)
      }
    },
    updateEnvServices: function (envItem) {
      this.$store.dispatch('applicationData/setNewSelectedEnvironment', envItem)
      let filteredList = []
      _.forEach(this.$store.state.applicationData.selectedApplication.services, service => {
        if (envItem && _.find(service.environments, env => env.env == envItem.env)) {
          filteredList.push(service)
        }
      })
      this.$store.dispatch('serviceData/setNewFilteredServices', filteredList)
    },
    closeEnvDropdown: function () {
      this.envDropdownOpen = false;
    }
  },
  directives: {
    clickOutside: vClickOutside.directive,
  },
  props: {
    //services: Array,
    selectedApplication: String,
    requestUrl: String,
    historyUrl: String,
  },
  filters: {
    prettyPathNotation,
  },
  computed: {
    services: {
      get() {
        return this.$store.state.serviceData.filteredServices
      },
      set(value) {
      }
    },
    selectedService: {
      get() {
        return this.$store.state.serviceData.selectedService
      },
      set(value) {
        //this.$store.dispatch('serviceData/setNewSelectedService', value)
      }
    },
    environments: {
      get() {
        return this.$store.state.applicationData.environments
      },
      set(value) {
        //this.$store.dispatch('serviceData/setNewSelectedService', value)
      }
    },
    newFilters: {
      prettyServicePath(servicePath) {
        return prettyPathNotation(servicePath)
    }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.fad-service-selection {
  display: flex;
  flex-direction: row;
  flex: 1;
  -ms-flex: 1 1 auto;
  height: 100%;
}

.fad-left-menu {
  background-color: #fbfbfb;
  color: #444;
  box-shadow: inset 0 0 80px #d5d5d5;

  -ms-flex-negative: 0; /* Fix IE shrinking too thin */
  width: 225px;
  padding-top: 20px;
}

.fad-left-menu-services {
  width: 100%;
  padding-left: -15px;
  padding-right: -15px;
}

.fad-dropdown-envselect.nav {
  margin: 0;
  padding-bottom: 0px;
}

.fad-dropdown-envselect-li{
  position: relative !important;
  display: block !important;
  padding: 0px 0px !important;
}

.fad-dropdown-envselect-li h2{
  white-space: nowrap;
  font-size: 19px;
  font-weight: 500;
  padding-bottom: 0px;
}

.fad-dropdown-envselect-li h2:hover{
  color:black;
}

.fad-right-menu {
  background-color: #fbfbfb;
  color: #444;
  box-shadow: inset 0 0 80px #d5d5d5;

  -ms-flex-negative: 0; /* Fix IE shrinking too thin */
  width: 225px;
  font-family: inherit;
}

.btn-group-vertical .btn {
  border-radius: 0 !important;
  height: 60px;
  font-size: 15px;
  text-align: left;
}

.btn-group-vertical .btn.active {
  background-color: #d8effb;
}

.fad-service-path {
  display: block;
  font-size: 10px;
  letter-spacing: -.5px;
  font-family: "Fira Mono", monospace;
  overflow: hidden;
  text-overflow: ellipsis;
}

.fad-service-widget-blank {
  display: flex;
  flex: 1;
  -ms-flex: 1 1 100%;

  color: #cfe2ea;
  background-color: #055072;
  justify-content: center;
  padding: 20px;
}

.fad-service-widget-blank h1 {
  margin-top: 200px;
  padding: 0;
  display: table-cell;
  text-align: center;
  vertical-align: middle;
}
</style>

<style>
.fad-service-selection h2 {
  font-size: 25px;
  margin-top: 5px;
  margin-bottom: 20px;
}
</style>
