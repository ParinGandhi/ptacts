<template>
  <div class="fad-response-view">
    <AceXmlEditor v-if="['xml', 'text', 'html'].includes(responseType)"
                  v-model="responseBody"
                  v-on:init="editorInit"
                  v-bind:lang="editorLang"
                  v-bind:options="editorOptions"
                  class="fad-ace-container"/>
    <div v-if="responseType === 'json'" class="fad-ace-container">
      <v-jsoneditor v-model="responseBody" v-bind:options="vJsonEditorOptions"/>
    </div>
    <div v-if="responseType === 'image'" class="fad-code transparent-background-pattern">
      <img v-bind:src="responseImageBlob" alt="Response image"/>
    </div>
    <div v-show="responseType === 'pdf'" class="fad-code transparent-background-pattern">
      <canvas id="fad-pdf-canvas" ref="fadcanvas"/>
    </div>
    <div v-if="responseType === 'blob'" class="fad-code">
      Binary response:
      <button type="button" class="btn btn-block btn-default"
              v-on:click="downloadResponse"
              v-bind:disabled="downloaded">
        Download
      </button>
    </div>
    <div v-if="responseType === 'empty'" class="fad-code">
      The response body was empty.
    </div>
    <div v-if="responseHeaders">
      <h3>Response Headers</h3>
      <div class="fad-code form-control">{{ responseHeaders }}</div>
    </div>
  </div>
</template>

<script>
  import AceXmlEditor from "./AceXmlEditor";
  import VJsoneditor from "v-jsoneditor";
  import download from "downloadjs";
  import {pd} from "pretty-data";

  require('brace/mode/json'); // Preload JSON mode for vJsonEditor to prevent HTTP request at runtime

  import pdfjs from 'pdfjs-dist/webpack';

  export default {
    name: 'ResponseView',
    components: {
      AceXmlEditor,
      VJsoneditor,
    },
    props: {
      response: [
        Response,
        Object, // Fake Response object from internal request endpoint handler
      ],
      requestUrl: String,
    },
    data: function () {
      return {
        responseHeaders: null,
        responseBody: '',
        downloaded: false,
        aceMaximized: false,
        editorLang: 'text',
        responseType: '',
        responseImageBlob: 'data:image/svg+xml;utf8,<svg width="100" height="100" viewBox="0 0 26.458 26.458" xmlns="http://www.w3.org/2000/svg"><g transform="translate(0 -270.54)"><path fill="none" stroke="#000" stroke-width="1.323" d="M1.323 278.48h23.812v15.875H1.323z"/><circle cx="13.229" cy="273.19" r="1.323"/><g fill="none" stroke="#000"><circle cx="13.229" cy="286.42" r="5.292" stroke-width="1.323"/><path d="M17.198 282.45l-7.938 7.938" stroke-linejoin="round" stroke-width="1.323"/><path d="M7.938 278.48l5.291-5.292 5.292 5.292" stroke-width=".794"/></g></g></svg>',
        vJsonEditorOptions: {
          mode: "code",
          onEditable: function () {
            return false;
          },
        },
        editorOptions: {
          // mode: "code",
          readOnly: true,
        },
      };
    },
    mounted: async function () {
      const self = this;
      var response = self.response;
      self.editorLang = 'text';
      var headers = []
      for (var pair of response.headers.entries()) {
        headers.push(pair[0] + ': ' + pair[1])
      }
      self.responseHeaders = headers.join('\n')
      let contentType = response.headers.get('content-type');
      if (contentType == null) {
        contentType = ''; // TODO make better
      }
      if (response.headers.get('content-length') === 0) {
        // TODO stream blob body to determine length, then parse content type
        self.responseType = 'empty';
        self.responseBody = '';
      } else if (contentType.startsWith('image/')) {
        self.responseType = 'image';

        response.arrayBuffer().then(function (buffer) {
          var base64Flag = 'data:' + contentType + ';base64,';
          var imageStr = arrayBufferToBase64(buffer);

          self.responseImageBlob = base64Flag + imageStr;
        });
      } else if (contentType.includes('json')) {
        response.json().then(json => {
          self.responseBody = json;
          self.responseType = 'json';
          self.editorLang = 'json';
        })
      } else if (contentType.includes('xml')) {
        response.text().then(text => {
          self.responseBody = text;
          self.editorLang = 'xml';
          self.responseType = 'xml';
          self.originalEditorContent = text;
        })
      } else if (contentType.includes('html')) {
        response.text().then(text => {
          self.responseBody = text;
          self.editorLang = 'html';
          self.responseType = 'html';
          self.originalEditorContent = text;
        })
      } else if (contentType.includes('text')) {
        response.text().then(text => {
          self.responseBody = text;
          self.responseType = 'json';
          self.editorLang = 'text';
        })
      } else if (contentType.includes('pdf')) {
        self.responseType = 'pdf';
        self.responseBody = '';
        self.responseLang = 'text'; // TODO this is wrong, but what is this supposed to be?
        response.arrayBuffer().then(function (buffer) {
          // var base64Flag = 'data:' + contentType + ';base64,';
          // var imageStr = arrayBufferToBase64(buffer);
          // self.responseImageBlob = base64Flag + imageStr;
          pdfjs.getDocument({data: buffer}).promise.then(function (pdf) {
            pdf.getPage(1).then(function (page) {
              const viewport = page.getViewport({scale: 1});

              const canvas = self.$refs['fadcanvas'];
              const context = canvas.getContext('2d');

              canvas.height = viewport.height;
              canvas.width = viewport.width;

              const renderContext = {
                canvasContext: context,
                viewport: viewport
              };
              const renderTask = page.render(renderContext);

            })
          })
        });
      } else if (response.fadRequestProxy) {
        response.json().then(json => {
          self.responseType = 'json';
          self.responseBody = json;
        })
      } else {
        self.responseType = 'blob';
        self.responseBody = response;
      }
    },
    methods: {
      downloadResponse: function () {
        var self = this;
        if (!self.downloaded) {
          self.response.blob()
            .then(blob => {
              download(blob, 'response', 'application/octet-stream');
            })
            .catch(err => {
              self.downloaded = false;
            })
        }
        self.downloaded = true;
      },
      toggleAceMaximized: function () {
        this.aceMaximized = !this.aceMaximized;
        if (this.aceMaximized) {
          document.documentElement.classList.add('fad-html-ace-maximized')
        } else {
          document.documentElement.classList.remove('fad-html-ace-maximized')
        }
        var self = this;
        self.$nextTick(function () {
          window.ace.edit(self.$refs.aceEditor.$el).resize();
        });
      },
      editorInit: function () {
        // require('brace/ext/language_tools') //language extension prerequsite...
        require('brace/mode/html')
        require('brace/mode/xml')
        require('brace/mode/text')
        require('brace/mode/json')
        require('brace/mode/plain_text')
        require('brace/mode/javascript')
        require('brace/theme/chrome')
        // require('brace/snippets/javascript') //snippet
      },
      formatXml: function () {
        this.responseBody = pd.xml(this.responseBody);
      },
      compactXml: function () {
        this.responseBody = pd.xmlmin(this.responseBody, true);
      },
      restoreOriginalXml: function () {
        this.responseBody = this.originalEditorContent;
      },
    },
  }

  function arrayBufferToBase64(buffer) {
    var binary = '';
    var bytes = [].slice.call(new Uint8Array(buffer));

    bytes.forEach((b) => binary += String.fromCharCode(b));

    return window.btoa(binary);
  }

</script>


<style scoped>
  .fad-response-view {
    flex: 1;
    display: flex;
    flex-direction: column;
  }

  .fad-ace-container {
    flex: 1;
    background-color: white;
    display: flex;
    flex-direction: column;
  }

  .fad-output textarea {
    resize: vertical;
    min-height: 3em;
  }

  .fad-code.form-control {
    cursor: text;
    white-space: pre-wrap;
    word-break: break-all;
    height: auto;
    min-height: 34px;
    border-radius: 0;
  }


  h3 {
    font-size: 18px;
  }
</style>

<style>
  html.fad-html-ace-maximized {
    overflow: hidden;
  }

  .max-btn {
    right: 10px !important;
  }

  .jsoneditor-poweredBy {
    display: none;
  }

  .jsoneditor-container {
    height: 100%;
  }

  /*.ace_editor div, .ace_editor span { font-size: 22px !important; }*/
  /*.ace_editor, .ace_editor div { font-variant-ligatures: none !important; }*/
  /*html {*/
  /*  word-spacing: 1px;*/
  /*  -ms-text-size-adjust: 100%;*/
  /*  -webkit-text-size-adjust: 100%;*/
  /*  -moz-osx-font-smoothing: grayscale;*/
  /*  -webkit-font-smoothing: antialiased;*/
  /*}*/

  .transparent-background-pattern {
    background-color: #fff;
    background-image: linear-gradient(45deg, #ccc 25%, transparent 25%, transparent 75%, #ccc 75%, #ccc),
    linear-gradient(45deg, #ccc 25%, transparent 25%, transparent 75%, #ccc 75%, #ccc);
    background-size: 10px 10px;
    background-position: 0 0, 5px 5px;
  }

  .fad-code.transparent-background-pattern {
    padding: 10px;
    text-align: center;
    margin: 0 auto;
    width: 100%;
    box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
    border: 1px solid #ccc;
  }
</style>
