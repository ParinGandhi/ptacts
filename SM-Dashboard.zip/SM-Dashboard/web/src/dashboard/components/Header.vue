<template>
  <header class="fad-topnav navbar-default" role="banner">
    <div class="fad-navbar-brand">
      <div class="fad-navbar-brand-center-cell">
        <a href="/menu.html" title="Visit the main menu page">
          <img class="fad-nav-logo" src="../../../public/hcgov-logo-api-dashboard.svg" alt="Logo"/>
        </a>
      </div>
    </div>
    <slot>
      <div class="fad-header-spacer"></div>
    </slot>
    <div class="fad-environment-table">
      <div class="fad-environment-cell"
           v-bind:class="environmentClass"
           v-if="environment">{{ environment.name }}
      </div>
    </div>
    <ul class="fad-nav-profile nav navbar-nav navbar-right" style="padding-left: 0px">
      <li class="dropdown"
          v-on:click="userDropdownOpen = !userDropdownOpen"
          v-click-outside="closeUserDropdown"
          v-bind:class="{open: userDropdownOpen}">
        <a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
           v-bind:aria-expanded="userDropdownOpen.toString()"><span
          style="white-space: nowrap"><span class="glyphicon glyphicon-user"/> Hello, </span>
          <wbr/>
          <span style="white-space: nowrap">{{ username }} <span class="caret"/></span>
        </a>
        <ul class="dropdown-menu" style="padding-left: 0px">
          <li><a href="#" v-on:click.stop="mainMenuButtonClick">Main Menu</a></li>
          <li><a href="#" v-on:click="logout">Log out</a></li>
        </ul>
      </li>
    </ul>
  </header>
</template>

<script>
  import _ from 'lodash';
  import {redirectToIndex} from "../../utils/RedirectToIndex";
  import vClickOutside from 'v-click-outside';
  import {setFlash as setIndexFlash} from '../../index/flash';

  const LAST_ACTIVE_TIME_KEY = 'lastActiveTime';

  export default {
    name: "Header",
    props: {
      username: String,
      environment: Object,
      resourceUrls: Object,
    },
    data: function () {
      return {
        userDropdownOpen: false,
        historyDropdownOpen: false,
      }
    },
    created: function () {
      this.setupInactiveSessionLogout();
    },
    methods: {
      setupInactiveSessionLogout: function() {
        this.updateLastActiveTime();
        const debouncedUpdateLastActiveTime = _.debounce(this.updateLastActiveTime, 1000, {maxWait: 1000});
        document.addEventListener('keyup', debouncedUpdateLastActiveTime, true);
        document.addEventListener('mousemove', debouncedUpdateLastActiveTime, true);
        const _1_MINUTE_MS = 1000 * 60;
        const _15_MINUTE_MS = 1000 * 60 * 15;
        const logoutCheckInterval = _1_MINUTE_MS;
        const inactiveSessionExpireDuration = _15_MINUTE_MS;
        let logoutIntervalId = setInterval(() => {
          try {
            let inactiveSessionExpireTime = JSON.parse(localStorage.getItem(LAST_ACTIVE_TIME_KEY)) + inactiveSessionExpireDuration;
            let inactiveSessionIsExpired = inactiveSessionExpireTime < new Date().getTime();
            if (inactiveSessionIsExpired) {
              setIndexFlash('You have been logged out due to session inactivity.')
              this.logout();
              clearInterval(logoutIntervalId);
            }
          } catch (e) {
            setIndexFlash('You have been logged out due to an error determining session activity.')
            this.logout();
            clearInterval(logoutIntervalId);
          }
        }, logoutCheckInterval);
      },
      updateLastActiveTime: function (e) {
        localStorage.setItem(LAST_ACTIVE_TIME_KEY, JSON.stringify(new Date().getTime()));
      },
      logout: function () {
        try {
          localStorage.removeItem(LAST_ACTIVE_TIME_KEY);
        } catch (e) {
          // do nothing
        }
        fetch(this.resourceUrls.logout, {
          method: 'POST',
          headers: {
            'access-token': sessionStorage.getItem('accessToken')
          },
        })
          .finally(redirectToIndex)
      },
      mainMenuButtonClick: function () {
        window.location.href = "/menu.html";
      },
      environmentClass: function () {
        return {
          'fad-environment-cell-prod': this.environment.type === 'prod'
        }
      },
      closeUserDropdown: function() {
        this.userDropdownOpen = false;
      }
    },
    directives: {
      clickOutside: vClickOutside.directive,
    },
  }
</script>

<style scoped>
  .fad-topnav {
    display: flex;
    flex-direction: row;
    height: 70px;
    flex: none;
    border-radius: 0;
  }

  .fad-navbar-brand {
    height: 100%;
    display: table;
    width: 263px;
    min-width: 263px;
    box-shadow: inset 0 0 65px #eaeaea;
    background: #fff;
  }

  .fad-navbar-brand a {
    padding: 15px 0;
  }

  .fad-navbar-brand div {
    display: table-cell;
    height: 100%;
    width: 100%;
    vertical-align: middle;
    text-align: center;
    padding: 15px;
  }

  .fad-navbar-brand img {
    max-width: 100%;
    max-height: 100%;
    width: 170px;
    height: 32px;
  }

  .fad-nav-profile.nav {
    margin: 0;
  }

  .fad-environment-table {
    float: right;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    margin: 0 10px;
  }

  .fad-environment-cell {
    border: 1px solid #ccc;
    padding: 10px;
  }

  .fad-environment-cell-prod {
    color: #e81212;
    border-color: #e81212;
  }

  .fad-nav-profile.nav li a {
    padding: 0 10px;
  }

  .nav, .nav li, .nav li a {
    height: 100%;
  }

  .fad-nav-selections > li {
    cursor: pointer;
    display: flex;
    flex-basis: 115px;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }

  .fad-nav-selections > li > a {
    display: flex;
    width: 100%;
    align-items: center;
    justify-content: center;
    min-width: 70px;
  }

  .dropdown {
    display: table;
  }

  .dropdown > a {
    display: table-cell;
    text-align: center;
    vertical-align: middle;
  }

  .fad-nav-profile .dropdown-menu li {
    width: 100%;
  }

  .fad-nav-profile .dropdown-menu > li > a {
    padding: 3px 20px;
  }

  .fad-nav-profile .dropdown > a {
    cursor: pointer;
  }

  .navbar-nav .open .dropdown-menu {
    position: absolute !important;
    background-color: white !important;
    border: 1px solid rgba(0, 0, 0, .15) !important;
    box-shadow: 0 6px 12px rgba(0, 0, 0, .175) !important;
    right: 0 !important;
  }

  .dropdown-menu {
    right: 0 !important;
    left: auto !important;
  }

  .fad-header-spacer {
    display: flex;
    flex-direction: row;
    flex: 1;
    -ms-flex: 1 1 auto;
  }

</style>
