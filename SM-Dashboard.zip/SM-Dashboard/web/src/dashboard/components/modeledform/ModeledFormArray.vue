<template>
  <fieldset>
    <legend>{{ schema.title }}</legend>
    <div
      class="form-group"
      v-for="(item, index) in value"
      v-bind:key="index"
    >
      <component
        v-bind:is="getComponent(schema.item.type)"

        v-bind:schema="schema.item"
        v-model="value[index]"
      />
    </div>
    <button v-on:click.prevent="removeItem(value.length - 1)" v-if="value && value.length > 0"
            class="btn btn-default pull-left arrayBtnCls"
            type="button"
    >Remove Item</button>
    <button v-on:click.prevent="addItem()"
            class="btn btn-default pull-right arrayBtnCls"
            type="button"
    >Add Item</button>
  </fieldset>
</template>

<script>
  import {getComponent} from "./modeled-form-utils";
  import ModeledFormObject from "./ModeledFormObject";
  import ModeledFormText from "./ModeledFormText";
  import ModeledFormPassword from "./ModeledFormPassword";
  import ModeledFormNumber from "./ModeledFormNumber";
  import ModeledFormCheckbox from "./ModeledFormCheckbox";
  import ModeledFormSelect from "./ModeledFormSelect";
  import ModeledFormUnknown from "./ModeledFormUnknown";
  import ModeledFormCorrelationId from "./ModeledFormCorrelationId";

  export default {
    name: "ModeledFormArray",
    props: {
      value: {
        type: Array,
        // Default doesn't propagate value to parent, but created does.
        // default: function() {
        //   return [];
        // },
      },
      schema: Object
    },
    created() {
      if (this.value == null) {
        this.$emit('input', []);
      }
    },
    components: {
      ModeledFormObject,
      ModeledFormText,
      ModeledFormPassword,
      ModeledFormNumber,
      ModeledFormCheckbox,
      ModeledFormSelect,
      ModeledFormUnknown,
      ModeledFormCorrelationId,
    },
    methods: {
      getComponent: getComponent,
      addItem: function () {
        this.$emit('input', (this.value || []).concat(
          null
        ))
      },
      removeItem: function (index) {
        // TODO fix bug where text input does not update to reflect
        //      changed model when removing items in the middle
        var mutatedArray = this.value.slice();
        mutatedArray.splice(index, 1);
        this.$emit('input', mutatedArray)
      }
    },
  }
</script>

<style>
  input.form-control {
    width: 100%;
  }
  .arrayBtnCls{
    color: black !important;
  }
</style>
