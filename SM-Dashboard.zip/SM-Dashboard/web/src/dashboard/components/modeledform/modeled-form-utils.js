import _ from "lodash";

function getComponent(type) {
  const typeMap = {
    string: 'ModeledFormText',
    password: 'ModeledFormPassword',
    number: 'ModeledFormNumber',
    boolean: 'ModeledFormCheckbox',
    array: 'ModeledFormArray',
    object: 'ModeledFormObject',
    select: 'ModeledFormSelect',
    correlationId: 'ModeledFormCorrelationId',
  };
  return _.defaultTo(typeMap[type], 'ModeledFormUnknown');
}

function getDefaultValue(type) {
  const typeMap = {

  }
}

export {
  getComponent
}
