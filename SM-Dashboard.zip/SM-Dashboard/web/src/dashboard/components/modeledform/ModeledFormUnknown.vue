<template>
  <div>
    ModeledFormUnknown
    {{ value && value.title }}
  </div>

</template>

<script>
  export default {
    name: "ModeledFormUnknown",
    props: {
      value: Object
    }
  }
</script>

<style scoped>

</style>
