<template>
  <div class="custom-select">
    <label v-bind:class="{required: schema.required}">
      {{ schema.title }}
      <select ref="box"
             class="form-control"
             v-bind:value="value"
             v-on:input="updateValue"
             v-bind:aria-required="schema.required"
      >
        <option
          v-for="(item, index) in schema.items"
          v-bind:key="index"
        >{{ item }}</option>
      </select>
    </label>
  </div>
</template>

<script>
  export default {
    name: "ModeledFormSelect",
    props: {
      value: String,
      schema: Object
    },
    mounted: function() {
      if (this.schema.default) {
        this.$refs.box.value = this.schema.default;
        this.$emit('input', this.schema.default)
      }
    },
    methods: {
      updateValue: function () {
        this.$emit('input', this.$refs.box.value)
      }
    }
  }
</script>

<style scoped>


.custom-select select {
  display: inline-block;
  max-width: 100%;
  padding: .375rem 1.75rem .375rem .75rem;
  line-height: 1.25;
  color: #464a4c;
  vertical-align: middle;
  background: #fff url(../../../../public/br_down.svg) no-repeat right .75rem center !important;
  background-size: auto;
  -webkit-background-size: 8px 10px;
  background-size: 8px 10px;
  border: 1px solid rgba(0,0,0,.15);
  border-radius: .25rem;
  -moz-appearance: none;
  -webkit-appearance: none;
}

/* Style the arrow inside the select element: */
.custom-select select:after {
  position: absolute;
  content: "";
  top: 14px;
  right: 10px;
  width: 0;
  height: 30px;
  border: 6px solid transparent;
  border-color: #fff transparent transparent transparent;
}

</style>
