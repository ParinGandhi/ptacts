<template>
  <div>
    <label v-bind:class="{required: schema.required}">
      {{ schema.title }}
      <input type="text" ref="box"
             class="form-control"
             v-bind:value="value"
             v-bind:aria-required="schema.required"
             v-on:input="updateValue"/>
    </label>
  </div>
</template>
<script>
  const correlationIdPrefix = "dashboard-";
  const stringDiff = (firstString, secondString) => firstString.split(secondString).join('');
  export default {
    name: "ModeledFormCorrelationId",
    props: {
      value: String,
      schema: Object
    },
    mounted: function () {
      if (this.schema.default) {
        this.$refs.box.value = this.schema.default;
        if (this.$refs.box.value.includes(correlationIdPrefix)) {
          this.$emit('input', this.schema.default)
        } else {
          this.$emit('input', correlationIdPrefix + this.schema.default)
        }
      } else {
        //this.$emit('input', undefined);
      }
    },
    methods: {
      updateValue: function () {
        if (this.$refs.box.value.includes(correlationIdPrefix)) {
          this.$emit('input', this.$refs.box.value);
        } else if (correlationIdPrefix.startsWith(this.$refs.box.value)) {
          //If the user tried to delete the "dashboard-" partially, this will fire
          //Get the difference between "dashboard-" and the input, this will give us
          //the value we need to add to the input to replace what the user deleted
          let newValue = this.$refs.box.value + stringDiff(correlationIdPrefix, this.$refs.box.value);
          this.$refs.box.value = newValue;
          this.$emit('input', newValue);
        } else {
          this.$emit('input', correlationIdPrefix + this.$refs.box.value);
        }
      }
    },
  }
</script>
<style scoped>
</style>
