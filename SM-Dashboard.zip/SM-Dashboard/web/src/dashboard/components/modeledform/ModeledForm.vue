<!--
Usage:
<modeled-form
  v-model={}
  v-bind:schema="formSchema"/>
-->

<template>
  <form v-on:submit="$emit('submit', $event)" class="modeled-form">
    <div class="required" v-if="schema.length != 0">Indicates a required field</div>
    <component
      v-for="item in schema"
      v-bind:key="item.id"

      v-bind:is="getComponent(item.type)"

      v-bind:schema="item"
      v-bind:value="value[item.id]"
      v-on:input="update($event, item)"
    />
  </form>
</template>

<script>
  import {getComponent} from "./modeled-form-utils";
  import ModeledFormArray from "./ModeledFormArray";
  import ModeledFormObject from "./ModeledFormObject";
  import ModeledFormText from "./ModeledFormText";
  import ModeledFormPassword from "./ModeledFormPassword";
  import ModeledFormNumber from "./ModeledFormNumber";
  import ModeledFormCheckbox from "./ModeledFormCheckbox";
  import ModeledFormSelect from "./ModeledFormSelect";
  import ModeledFormUnknown from "./ModeledFormUnknown";
  import ModeledFormCorrelationId from "./ModeledFormCorrelationId";

  import _ from "lodash";

  export default {
    name: "ModeledForm",
    props: {
      value: Object, // model
      schema: Array
    },
    components: {
      ModeledFormArray,
      ModeledFormObject,
      ModeledFormText,
      ModeledFormPassword,
      ModeledFormNumber,
      ModeledFormCheckbox,
      ModeledFormSelect,
      ModeledFormUnknown,
      ModeledFormCorrelationId,
    },
    watch: {
      schema: function (newValue, oldValue) {
        const newIds = _.map(newValue, item => item.id);
        _.map(oldValue, item => item.id)
          .filter(id => !newIds.includes(id))
          .forEach(removedId => this.$delete(this.value, removedId));
      }
    },
    methods: {
      getComponent: getComponent,
      update: function (newValue, item) {
        this.value[item.id] = newValue;
        this.$emit('input', Object.assign({}, this.value));
      }
    },
  }
</script>

<style>
  .form-control {
    border-radius: 0 !important;
  }

  .btn {
    border-radius: 0 !important;
  }
  .modeled-form fieldset {
    border: 1px solid;
    padding: 10px;
  }
  .modeled-form legend {
    padding: 0 10px;
    margin: 0;
    width: auto;
    border: 0;
  }
  .required:before {
    content:"* ";
    color: #f2adad; /* Choosing this color because it has the proper contrast with the background*/
  }
</style>
