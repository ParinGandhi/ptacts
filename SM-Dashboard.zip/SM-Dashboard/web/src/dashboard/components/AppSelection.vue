<template>
  <div class="fad-app-selection">
    <Header v-bind:username="username"
            v-bind:environment="environment"
            v-bind:resourceUrls="resourceUrls">
      <v-sheet style="background-color: transparent; padding: 1px; margin-top: 0px" v-show="this.$store.state.applicationData.applications.length === 0"

      >
        <v-skeleton-loader
          class="mx-auto custom-skeleton-btn-width"
          max-width="100"
          width="100"
          type="button"
        ></v-skeleton-loader>
      </v-sheet>
      <ul class="fad-nav-selections nav navbar-nav" style="padding-left: 0px">
        <li v-for="application in applications"
            v-bind:key="application.name"
            v-on:click="selectApplication(application)"
            v-bind:class="{active: application === selectedApplication}"
        >
          <a>{{ application.name }}</a>
        </li>
      </ul>
    </Header>
    <service-selection v-bind:services="selectedApplication.services"
                       v-bind:selected-application="selectedApplication.name"
                       v-bind:request-url="resourceUrls.request"
                       v-bind:historyUrl="resourceUrls.history"/>
  </div>
</template>

<script>
  import ServiceSelection from "./ServiceSelection";
  import {redirectToIndex, redirectToIndexIfNoAccessToken} from "../../utils/RedirectToIndex";
  import jwtDecode from 'jwt-decode';
  import Header from './Header';
  import moment from "moment";
  import _ from "lodash";

  export default {
    name: 'AppSelection',
    components: {
      ServiceSelection,
      Header
    },
    methods: {
      selectApplication: function (application) {
        let envList = []
        _.map(application.services, service => {
          if(service.environments)
          envList = _.concat(envList, service.environments)
        })
        if(envList.length < 1) {
          console.log("no environments configured for app services")
          return
        }
        envList =_.uniqBy(envList, env => env.env)
        let filteredList = []
        _.forEach(application.services, service => {
          if(service.environments && envList[0] && _.find(service.environments, env => env.env == envList[0].env)){
            filteredList.push(service)
          }
        })
        this.$store.dispatch('applicationData/setNewSelectedEnvironment', envList[0])
        this.$store.dispatch('applicationData/setNewEnvironments', envList)
        this.$store.dispatch('serviceData/setNewFilteredServices', filteredList)
        this.$store.dispatch('applicationData/setNewSelectedApplication', application)
      },
    },
    data: function () {
      return {
        environment: {},
        userDropdownOpen: false
      }
    },
    computed: {
      username: function () {
        try {
          return jwtDecode(sessionStorage.getItem('idToken'))['custom:uid'];
        } catch (err) {
          return 'User';
        }
      },
      selectedApplication: function () {
        return this.$store.state.applicationData.selectedApplication
      }
    },
    props: {
      applications: Array,
      resourceUrls: Object,
    },
    mounted: function () {
      fetch(this.resourceUrls.environment, {
        headers: {
          'access-token': sessionStorage.getItem('accessToken')
        }
      })
        .then(response => response.json())
        .then(json => this.environment = json)
        .catch(redirectToIndexIfNoAccessToken)
    },
  }
</script>
<style>
.custom-skeleton-btn-width .v-skeleton-loader__button{
  width: 100px !important;
  height: 68px !important;
}
</style>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .fad-app-selection {
    display: flex;
    flex-direction: column;
    height: 100%;
  }

  .fad-nav-selections {
    display: flex;
    flex-direction: row;
    flex: 1;
    -ms-flex: 1 1 auto;
    font-size: 20px;
  }

  .fad-nav-selections.nav {
    margin: 0;
  }

  .fad-nav-selections.nav li a {
    padding: 0 10px;
  }

  .fad-nav-selections > li {
    cursor: pointer;
    display: flex;
    flex-basis: 115px;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }

  .fad-nav-selections > li > a {
    display: flex;
    width: 100%;
    align-items: center;
    justify-content: center;
    min-width: 70px;
  }

  .fad-nav-history.nav {
    margin: 0;
  }

  .fad-nav-history.nav li a {
    padding: 0 10px;
  }

  .nav, .nav li, .nav li a {
    height: 100%;
  }

  .dropdown {
    display: table;
  }

  .dropdown > a {
    display: table-cell;
    text-align: center;
    vertical-align: middle;
  }

  .fad-nav-history .dropdown-menu li {
    width: 100%;
    padding: 3px;
  }

  .fad-nav-history .dropdown-menu > li > a {
    padding: 3px 20px;
  }

  .fad-nav-history .dropdown > a {
    cursor: pointer;
  }

  .navbar-nav .open .dropdown-menu {
    position: absolute !important;
    background-color: white !important;
    border: 1px solid rgba(0, 0, 0, .15) !important;
    box-shadow: 0 6px 12px rgba(0, 0, 0, .175) !important;
    right: 0 !important;
  }

  .dropdown-menu {
    right: 0 !important;
    left: auto !important;
    width: max-content;
  }

</style>
