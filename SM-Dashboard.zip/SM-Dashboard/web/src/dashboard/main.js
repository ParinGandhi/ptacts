// import Vue from 'vue'
import { createApp, h } from 'vue'
import App from './App.vue'
import store from './store'
// import vuetify from '@/plugins/vuetify'
import { createVuetify } from 'vuetify/lib/framework.mjs'
import 'vuetify/styles'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'
import { defaults as vuetifyDefaults } from 'vuetify';

// Vue.config.productionTip = false

// new Vue({
//   vuetify,
//   render: h => h(App),
//   store,
// }).$mount('#app')


const app = createApp({
  render: ()=>h(App)
})

const vuetify = createVuetify({
  ssr: true,
  components,
  directives,
  defaults: vuetifyDefaults,
  opts: {
      theme: { dark: false },
      icons: {
       iconfont: 'mdi'
      }
    }
})

app.use(vuetify)
app.use(store)
app.mount('#app')