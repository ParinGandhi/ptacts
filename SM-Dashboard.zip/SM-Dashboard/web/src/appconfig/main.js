import 'bootstrap/dist/css/bootstrap.css'

import { createApp, h } from 'vue'
// import Vue from 'vue'
import App from './App.vue'
// import vuetify from 'vuetify'
import { createVuetify } from 'vuetify/lib/framework.mjs'
import 'vuetify/styles'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'
import { defaults as vuetifyDefaults } from 'vuetify';

import store from './store'

// Vue.config.productionTip = false

// new Vue({
//   vuetify,
//   store,
//   render: h => h(App)
// }).$mount('#app')

const app = createApp({
  render: ()=>h(App)
})


const vuetify = createVuetify({
  ssr: true,
  components,
  directives,
  defaults: vuetifyDefaults,
  opts: {
      theme: { dark: false },
      icons: {
       iconfont: 'mdi'
      }
    }
})


app.config.productionTip = false
app.use(vuetify)
app.use(store)
app.mount('#app')
