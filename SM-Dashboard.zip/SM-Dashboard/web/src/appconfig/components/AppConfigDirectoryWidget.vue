<template>
  <v-container fluid style="padding: 0px; height: 100%;" fill-height>
    <span class="fad-dropdown-refdata nav navbar-nav navbar-left" style="padding-left: 22px; height: 40px">
        <span class="dropdown fad-dropdown-refdata-li"
              v-on:click="envDropdownOpen = !envDropdownOpen"
              v-click-outside="closeEnvDropdown"
              v-bind:class="{open: envDropdownOpen}">
          <div class="dropdown-toggle fad-dropdown-refdata-li" data-toggle="dropdown" role="button" aria-haspopup="true"
               v-bind:aria-expanded="envDropdownOpen.toString()">
            <h2>Environments: &nbsp;{{ this.$store.state.applicationData.selectedEnvironment.label }} <span
              class="caret"/></h2>
          </div>
          <ul class="dropdown-menu" style="padding-left: 0px">
            <li v-for="envItem in environments" v-bind:key="envItem.env">
              <a href="#" v-on:click="updateEnvServices(envItem)">
                <span>{{ envItem.label }}</span>
              </a>
            </li>
          </ul>
        </span>
    </span>
    <v-row align="start"
           style="margin-left: 5px; margin-right: -6px; margin-bottom: 5px; border:1px solid darkgray; overflow: hidden; height: 92%; min-height: 50px">
      <ResizableTreeViewContainer style="width: 100%">
        <template v-slot:table="tableProps">
          <v-treeview
            :key="treeId"
            :ref="treeId"
            v-model="treeModel"
            :active="activeItems"
            :load-children="fetchSubFolders"
            :open="initiallyOpen"
            dense
            hoverable
            :items="items"
            :value="treeValues"
            :style="tableProps.tableHeight"
            class="treeViewDefaultCls"
            activatable
            return-object
            item-key="id"
            item-children="subFolders"
            transition
            @update:open="folderOpened"
            @update:active="treeItemSelected"
          >
            <template v-slot:prepend="{ item, open }">
              <v-icon v-if="item.subFolders" @dblclick="processItemDoubleClick(item)">
                {{ open ? 'mdi-folder-open' : 'mdi-folder' }}
              </v-icon>
              <v-icon v-else @dblclick="processItemDoubleClick(item)">
                {{ files[item.fileType] ? files[item.fileType] : 'mdi-file-document-outline' }}
              </v-icon>
            </template>
            <template slot="label" slot-scope="{ item }">
            <span v-if="!item.subFolders" @dblclick="processItemDoubleClick(item)" style="cursor: pointer !important;" @contextmenu="(e)=>showRightClickMenu(e,item)">{{
                item.name
              }}
              <v-menu
                v-model="showMenu"
                :position-x="x"
                :position-y="y"
                absolute
                offset-y>
                <v-list>
                  <v-list-item  @click="diffItem()">
                    <v-list-item-title><v-icon style="margin-right:10px;">mdi-compare-horizontal</v-icon>{{compareLabel}}</v-list-item-title>
                  </v-list-item>
                </v-list>
              </v-menu>
            </span>
            <span v-else @dblclick="processItemDoubleClick(item)" style="cursor: pointer !important;">{{item.name}}</span>
            </template>
            <template slot="append" slot-scope="{ item }">
              <v-tooltip left>
                <template v-slot:activator="{ on, attrs }">
                  <v-icon v-if="item.activeBucket" v-bind="attrs" color="green darken-2"
                          :elevation="10"
                          v-on="on"
                  >
                    mdi-radiobox-marked
                  </v-icon>
                </template>
                <span>Active Bucket</span>
              </v-tooltip>
            </template>
          </v-treeview>
        </template>
      </ResizableTreeViewContainer>
    </v-row>
  </v-container>
</template>

<script>
import vClickOutside from 'v-click-outside';
import _ from "lodash";
import uuidv1 from "uuid/v1"
import ResizableTreeViewContainer from "@/appconfig/components/ResizableTreeViewContainer";


export default {
  name: "AppConfigDirectoryWidget",
  data: function () {
    return {
      environment: {},
      envDropdownOpen: false,
      files: {
        html: 'mdi-language-html5',
        css: 'mdi-language-css3',
        js: 'mdi-language-javascript',
        json: 'mdi-code-json',
        md: 'mdi-language-markdown',
        pdf: 'mdi-file-pdf',
        xml: 'mdi-xml',
        png: 'mdi-file-image',
        txt: 'mdi-file-document-outline',
        xls: 'mdi-file-excel',
      },
      lastSelectedTreeItem: {},
      headers: [
        {
          text: 'File Name',
          align: 'start',
          value: 'name',
        },
        {text: 'Type', value: 'fileType'},
        {text: 'Last Modified', value: 'lastModified'},
        {text: 'Size', value: 'size'},
      ],
      showMenu: false,
      x: 0,
      y: 0,
      selectedMenuItem: null
    };
  },
  components: {
    ResizableTreeViewContainer
  },
  props: {
    resourceUrls: Object,
  },
  computed: {
    environments: {
      get() {
        return this.$store.state.applicationData.environments
      },
      set(value) {
        //this.$store.dispatch('serviceData/setNewSelectedService', value)
      }
    },
    items: {
      get() {
        return this.$store.state.directoryData.folderTree
      },
      set(value) {
        //this.$store.dispatch('serviceData/setNewSelectedService', value)
      }
    },
    treeModel: {
      get() {
        return this.$store.state.directoryData.treeModel
      },
      set(value) {
        //this.$store.dispatch('serviceData/setNewSelectedService', value)
      }
    },
    activeItems: {
      get() {
        return this.$store.state.directoryData.treeActiveItems
      },
      set(value) {
        this.$store.dispatch('directoryData/setNewTreeActiveItems', value)
      }
    },
    initiallyOpen: {
      get() {
        return this.$store.state.directoryData.treeOpenItems
      },
      set(value) {
        this.$store.dispatch('directoryData/setNewTreeOpenItems', value)
      }
    },
    treeValues: {
      get() {
        return this.$store.state.directoryData.treeValuesItems
      },
      set(value) {
        this.$store.dispatch('directoryData/setNewTreeValuesItems', value)
      }
    },
    treeId: {
      get() {
        return this.$store.state.directoryData.treeViewId
      },
      set(value) {
        this.$store.dispatch('directoryData/setNewTreeViewId', value)
      },
    },
    compareLabel: {
      get() {
        let serviceName = this.$store.state.directoryData.dataTableTitle
        if(serviceName && serviceName === 'Green' ) {
          return 'Compare to Blue'
        } else {
          return 'Compare to Green'
        }
      }
    }
  },
  mounted: function () {
  },
  methods: {
    diffItem: function () {
      this.$store.dispatch('directoryData/setNewSelectedDiffItem', null)
      this.$store.dispatch('directoryData/setNewSelectedDiffItem', this.selectedMenuItem)
    },
    showRightClickMenu (e, item) {
      e.preventDefault()
      this.showMenu = false
      this.x = e.clientX
      this.y = e.clientY
      this.selectedMenuItem = item
      this.$nextTick(() => {
        this.showMenu = true
      })
    },
    processItemDoubleClick: function (item) {
      let foundSvc = _.find(this.initiallyOpen, svc => svc == item)
      if (foundSvc) {
        this.initiallyOpen.splice(_.indexOf(this.initiallyOpen, foundSvc), 1);
        return
      }
      if (item.subFolders) {
        this.initiallyOpen.push(item)
      } else {
        this.$store.dispatch('directoryData/setNewSelectedItem', item)
      }
    },
    updateEnvServices: function (envItem) {
      this.$store.dispatch('directoryData/setNewEditorViewActive', false)
      this.$store.dispatch('directoryData/setNewMergeViewActive', false)
      this.$store.dispatch('directoryData/setNewDataTableSlideNumber', 1)
      this.$store.dispatch('directoryData/setNewTreeViewId', uuidv1())

      this.$store.dispatch('directoryData/setNewTreeActiveItems', [])
      this.$store.dispatch('directoryData/setNewTreeOpenItems', [])
      this.$store.dispatch('directoryData/setNewTreeValuesItems', [])
      this.$store.dispatch('applicationData/setNewSelectedEnvironment', envItem)
      let filteredList = []
      _.forEach(this.$store.state.applicationData.selectedApplication.services, service => {
        service.subFolders = []
        if (envItem && _.find(service.environments, env => env.env == envItem.env)) {
          filteredList.push(service)
          if (service.s3BucketName.includes(envItem.active_bucket_color)) {
            service.activeBucket = true
          } else {
            service.activeBucket = false
          }
        }
      })
      this.$store.dispatch('directoryData/setNewFilteredServices', filteredList)
      this.$store.dispatch('directoryData/setNewFolderTree', _.cloneDeep(filteredList))
      this.$store.dispatch('directoryData/setNewDataTableTitle', "")
      this.$store.dispatch('directoryData/setNewSelectedFolderItems', [])
    },
    closeEnvDropdown: function () {
      this.envDropdownOpen = false;
    },
    async fetchSubFolders(item) {
      const cItem = item
      if(cItem.isLoading){
        return
      }
      this.$store.dispatch('directoryData/setNewDataTableLabelLoading', true)
      item.isLoading = true
      let self = this
      let requestObj = {
        application: self.$store.state.applicationData.selectedApplication.name,
        service: item['serviceName'],
        serviceEnv: self.$store.state.applicationData.selectedEnvironment,
        bucketName: item['s3BucketName'],
        prefix: item['prefix']
      };
      return fetch(this.$store.state.applicationData.resourceUrls.s3FolderItems, {
        method: 'POST',
        headers: {
          'access-token': sessionStorage.getItem('accessToken')
        },
        body: JSON.stringify(requestObj),
      })
        .then(res => res.json())
        .then(json => {
          this.$store.dispatch('directoryData/setNewDataTableLabelLoading', false)
          cItem.isLoading = false
          if (json.folderItems) {
            let fileArray = json.folderItems
            this.$store.dispatch('directoryData/setNewDataTableTitle', item["name"])
            this.$store.dispatch('directoryData/setNewSelectedFolderItems', fileArray)
            item.subFolders = fileArray;
          }
        })
        .catch(err => {
            this.$store.dispatch('directoryData/setNewDataTableLabelLoading', false)
            cItem.isLoading = false
            console.warn(err)
          }
        )
    },
    folderOpened: function (items) {
     //
    },
    treeItemSelected: function (activeArray) {
      let lastActive = activeArray[0];
      if (_.isEmpty(activeArray) && !_.isEmpty(this.lastSelectedTreeItem)) {//perform a check to disable deselecting tree items
        this.activeItems.push(this.lastSelectedTreeItem)
        return
      }

      this.lastSelectedTreeItem = lastActive
      if (lastActive && lastActive.subFolders && (lastActive.subFolders["length"] > 0)) {//if selected item is a loaded folder, add children to data table
        this.$store.dispatch('directoryData/setNewDataTableLabelLoading', true)
        .then(this.$store.dispatch('directoryData/setNewDataTableTitle', lastActive["name"]))
        .then(this.$store.dispatch('directoryData/setNewSelectedFolderItems', lastActive["subFolders"]))
        .then(this.$store.dispatch('directoryData/setNewDataTableLabelLoading', false))

      } else if (lastActive && lastActive.subFolders && (lastActive.subFolders["length"] == 0) && !lastActive.isLoading) {
        this.fetchSubFolders(lastActive)
      }else if(lastActive.isLoading){
        //still loading
      }
    }
  },
  watch: {
  },
  directives: {
    clickOutside: vClickOutside.directive,
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.treeViewDefaultCls {
  padding: 1px !important;
  width: 100% !important;
  overflow: auto !important;
}

.fad-dropdown-refdata.nav {
  margin: 0;
  padding-bottom: 0px;
}

.fad-dropdown-refdata-li {
  position: relative !important;
  display: block !important;
  padding: 0px 0px !important;
}

.fad-dropdown-refdata-li h2 {
  white-space: nowrap;
  font-size: 18px;
  font-weight: 500;
  padding-bottom: 0px;
  font-family: "Fira Sans", sans-serif;
  margin-top: 6px;
}

.fad-dropdown-refdata-li h2:hover {
  color: black
}
</style>
