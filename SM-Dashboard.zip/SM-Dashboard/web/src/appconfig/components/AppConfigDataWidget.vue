<template>
  <v-container style="padding-bottom: 0px;" fluid>
    <v-row style="padding-bottom: 1px; padding-left: 11px; padding-right: 24px">
      <v-card :elevation="10" class="rounded-0 elevation-10" style="width: 100%;">
        <v-toolbar dense>
          <div style="width: 40px">
            <v-fab-transition>
              <v-btn
                :elevation="10"
                v-show="editorViewActive || mergeViewActive"
                color="primary"
                fab
                x-small
                dark
                @click="backToDataTable"
              >
                <v-icon>mdi-arrow-left</v-icon>
              </v-btn>
            </v-fab-transition>
          </div>
          <v-toolbar-title v-show="!editorViewActive && !mergeViewActive"
          >{{ this.$store.state.directoryData.dataTableTitle }}
          </v-toolbar-title>
          <v-toolbar-title v-show="editorViewActive || mergeViewActive"
          >{{ dataTableContentTitle }}
          </v-toolbar-title>

          <v-spacer></v-spacer>
          <v-text-field
            v-model="search"
            v-show="!editorViewActive && !mergeViewActive"
            append-icon="mdi-magnify"
            label="Filter"
            single-line
            hide-details
          ></v-text-field>
          <v-tooltip left>
            <template v-slot:activator="{ on, attrs }">
              <v-btn
                v-bind="attrs"
                :elevation="10"
                v-show="editorViewActive && writeAccess"
                color="primary"
                fab
                x-small
                dark
                v-on="on"
                :disabled="isSaving"
                @click="saveCurrentItem"
              >
                <v-icon>mdi-content-save</v-icon>
              </v-btn>
            </template>
            <span>Save File</span>
          </v-tooltip>
          <span class="font-weight-bold" v-show="mergeViewActive"><v-icon>mdi-compare-horizontal</v-icon>&nbsp;&nbsp;{{diffCount}} Differences</span>
          <v-spacer v-show="mergeViewActive"></v-spacer>
          <v-tooltip left >
            <template v-slot:activator="{ on, attrs }">
              <v-btn
                v-bind="attrs"
                :elevation="10"
                v-show="mergeViewActive"
                color="primary"
                fab
                x-small
                dark
                v-on="on"
                @click="gotoPreviousDiff"
                style="margin-left:10px;"
              >
                <v-icon>mdi-arrow-left-circle</v-icon>
              </v-btn>
            </template>
            <span>Previous diff</span>
          </v-tooltip>
          <v-tooltip left>
            <template v-slot:activator="{ on, attrs }">
              <v-btn
                v-bind="attrs"
                :elevation="10"
                v-show="mergeViewActive"
                color="primary"
                fab
                x-small
                dark
                v-on="on"
                @click="gotoNextDiff"
                style="margin-left:10px;"
              >
                <v-icon>mdi-arrow-right-circle</v-icon>
              </v-btn>
            </template>
            <span>Next diff</span>
          </v-tooltip>

          <v-menu
            bottom
            left
            offset-y
            :close-on-click="closeOnClick"
            :close-on-content-click="closeOnContentClick"
          >
            <template v-slot:activator="{ on, attrs }"
            >
            <v-app-bar-nav-icon
                v-bind="attrs"
                color="primary"
                dark
                v-on="on" v-show="editorViewActive || mergeViewActive"
              >
              </v-app-bar-nav-icon>
            </template>
            <v-list>
              <v-list-item>
                <v-list-item-action>
                  <v-switch
                    @change="matcherChanged"
                    v-model="matcher"
                    color="purple"
                  ></v-switch>
                </v-list-item-action>
                <v-list-item-title>Pointer Match</v-list-item-title>
              </v-list-item>
              <v-list-item>
                <v-list-item-action>
                  <v-switch
                    @change="wrapLine"
                    v-model="wrapper"
                    color="purple"
                  ></v-switch>
                </v-list-item-action>
                <v-list-item-title>Line Wrap</v-list-item-title>
              </v-list-item>
              <v-divider></v-divider>
              <v-list-group
                :value="false"
                prepend-icon="mdi-format-indent-increase"
              >
                <template v-slot:activator>
                  <v-list-item-title>Parsers</v-list-item-title>
                </template>
                <v-list-item>
                  <v-radio-group
                    v-model="parseType"
                    hide-details
                  >
                    <v-radio
                      value="json"
                      label="JSON"
                    ></v-radio>
                    <v-radio
                      value="xml"
                      label="XML"
                    ></v-radio>
                    <v-radio
                      value="shell"
                      label="Shell"
                    ></v-radio>
                    <v-radio
                      value="properties"
                      label="Properties"
                    ></v-radio>
                    <v-radio
                      value="yaml"
                      label="Yaml"
                    ></v-radio>
                    <v-radio
                      value="html"
                      label="HTML"
                    ></v-radio>
                    <v-radio
                      value="javascript"
                      label="JavaScript"
                    ></v-radio>
                    <v-radio
                      value="text"
                      label="Text"
                    ></v-radio>
                  </v-radio-group>
                </v-list-item>
              </v-list-group>
            </v-list>
          </v-menu>
        </v-toolbar>
      </v-card>
    </v-row>
    <v-row style="padding-bottom: 1px; padding-left: 11px; padding-right: 24px"  v-show="mergeViewActive">
      <v-card :elevation="10" class="rounded-0 elevation-10" style="width: 100%;"> 
        <v-toolbar dense>
          <v-spacer></v-spacer>
          <v-toolbar-title>{{leftPanelColor}}
          </v-toolbar-title>
          <v-spacer></v-spacer>
          <v-toolbar-title>{{rightPanelColor}}
          </v-toolbar-title>
          <v-spacer></v-spacer>
        </v-toolbar>
      </v-card>
    </v-row>
    <v-row align="stretch" style="height: 100%; width: 100%; padding-left: 11px" class="dialogAttachTarget">
      <v-window v-model="dataTableSlideNumber" style="height: 100%; width: 100%" v-resize="resizeCodemirror">
        <v-window-item :value="1" style="height: 100%">
          <ResizableDataTableContainer>
            <template v-slot:table="tableProps">
              <v-data-table
                :headers="headers"
                :items="fileDataItems"
                :items-per-page="dataTablePageItems"
                :footer-props="{ itemsPerPageOptions: [20, 30, 50] }"
                :search="search"
                hide-default-footer
                class="elevation-1 rounded-0"
                fixed-header
                :height="tableProps.tableHeight"
                @contextmenu:row="tableContextMenu"
                :loading="tableLoading"
                loading-text="Loading... Please wait"
              >
                <template v-slot:[`item.name`]="{ item }">
                  <v-icon v-if="item.subFolders">
                    {{ 'mdi-folder' }}
                  </v-icon>
                  <v-icon v-else>
                    {{ files[item.fileType] ? files[item.fileType] : 'mdi-file-document-outline' }}
                  </v-icon>
                  <a v-if="!item.subFolders" @click="dataTableItemClicked(item)" style="padding-left: 5px" @contextmenu="(e)=>showRightClickMenu(e,item)">
                    {{ item.name }}
                    <v-menu
                      v-model="showMenu"
                      :position-x="x"
                      :position-y="y"
                      absolute
                      offset-y
                    >
                      <v-list>
                        <v-list-item  @click="diffItem()">
                          <v-list-item-title><v-icon style="margin-right:10px;">mdi-compare-horizontal</v-icon>{{ compareLabel }}</v-list-item-title>
                        </v-list-item>
                      </v-list>
                    </v-menu>
                  </a>
                  <a v-else @click="dataTableItemClicked(item)" style="padding-left: 5px">{{ item.name }}</a>
                </template>
                <template v-slot:[`item.lastModified`]="{ item }">
                  {{ formatDate(item) }}
                </template>
                <template v-slot:[`item.size`]="{ item }">
                  {{ formatSize(item) }}
                </template>
              </v-data-table>
            </template>
          </ResizableDataTableContainer>
        </v-window-item>
        <v-window-item :value="3" style="height: auto;" eager>
            <div id="diff_view" ref="diff_view" style="height: auto;"></div>
        </v-window-item>
        <v-window-item :value="2" style="height: 99%;" eager>
            <textarea id="editor" style="height: auto;">
            </textarea>

          <v-dialog
            v-model="actionStatusDialog"
            hide-overlay
            persistent
            width="300"
            attach=".dialogAttachTarget"
            content-class="statusDialogCls"
          >
            <v-card
              color="primary"
              dark
            >
              <v-card-text>
                {{ actionStatusMsg }}
                <v-progress-linear
                  indeterminate
                  color="white"
                  class="mb-0"
                ></v-progress-linear>
              </v-card-text>
            </v-card>
          </v-dialog>

        </v-window-item>
      </v-window>
    </v-row>
    <v-snackbar
      v-model="saveSnackBar"
      :timeout="saveSnackBarTimeout"
      top
      vertical
      width="340"
    >
      <div style="padding-bottom: 3px">
        <v-icon>{{ actionStatusIcon }}</v-icon>
        <span style="font-weight: bold !important;; padding-left: 5px !important;">{{ actionStatusTitle }}</span>
      </div>
      <div>
        <div>
          {{ actionStatusMsg }}
        </div>
      </div>
      <template v-slot:action="{ attrs }">
        <v-btn
          v-bind="attrs"
          color="blue"
          text
          @click="saveSnackBar = false"
        >
          Close
        </v-btn>
      </template>
    </v-snackbar>
  </v-container>
</template>

<script>
import 'codemirror/lib/codemirror.css'
import 'codemirror/addon/fold/foldgutter.css'
import 'codemirror/addon/dialog/dialog.css'
import 'codemirror/addon/search/matchesonscrollbar.css'
import ResizableDataTableContainer from "@/appconfig/components/ResizableDataTableContainer";
import jQuery from 'jquery'
import _ from 'lodash';
import moment from "moment";
import filesize from "filesize";
import CodeMirror from 'codemirror'
import 'codemirror/addon/merge/merge.css';
import 'codemirror/addon/merge/merge.js';
import DiffMatchPatch from 'diff-match-patch';
import 'codemirror/mode/javascript/javascript'
import 'codemirror/mode/xml/xml'
import 'codemirror/mode/htmlmixed/htmlmixed'
import 'codemirror/mode/shell/shell'
import 'codemirror/mode/properties/properties'
import 'codemirror/mode/yaml/yaml'
import "codemirror/addon/fold/brace-fold"
import "codemirror/addon/fold/comment-fold"
import "codemirror/addon/fold/foldcode"
import "codemirror/addon/fold/foldgutter"
import "codemirror/addon/fold/indent-fold"
import "codemirror/addon/fold/markdown-fold"
import "codemirror/addon/fold/xml-fold"
import "codemirror/addon/dialog/dialog"
import "codemirror/addon/search/search"
import "codemirror/addon/search/jump-to-line"
import "codemirror/addon/search/match-highlighter"
import "codemirror/addon/search/matchesonscrollbar"
import "codemirror/addon/search/searchcursor"
import "codemirror/addon/scroll/annotatescrollbar"
import "codemirror/addon/edit/matchbrackets"
import "codemirror/addon/edit/closebrackets"
import "codemirror/addon/search/match-highlighter"

window.DIFF_EQUAL= 0;
window.DIFF_DELETE= -1;
window.DIFF_INSERT= 1;
window.diff_match_patch = DiffMatchPatch;


export default {
  name: "AppConfigDataWidget",
  data: function () {
    return {
      treeViewStyles: {
        height: '620px'
      },
      dataTableContentTitle: "",
      resizeDiff: 190,
      editorResizeDiff: 142,
      writeAccess: true,
      isSaving: false,
      closeOnContentClick: false,
      closeOnClick: true,
      parseType: "json",
      saveSnackBar: false,
      saveSnackBarTimeout: 3000,
      matcher: false,
      wrapper: false,
      search: '',
      open: {},
      // step: 1,
      dataTablePageItems: 50,
      //editorViewActive: false,
      environment: {},
      userDropdownOpen: false,
      files: {
        html: 'mdi-language-html5',
        css: 'mdi-language-css3',
        js: 'mdi-language-javascript',
        json: 'mdi-code-json',
        md: 'mdi-language-markdown',
        pdf: 'mdi-file-pdf',
        xml: 'mdi-xml',
        png: 'mdi-file-image',
        txt: 'mdi-file-document-outline',
        xls: 'mdi-file-excel',
      },
      initiallyOpen: ['public'],
      tree: [],
      headers: [
        {
          text: 'File Name',
          align: 'start',
          value: 'name',
        },
        {text: 'Type', value: 'fileType'},
        {text: 'Last Modified', value: 'lastModified'},
        {text: 'Size', value: 'size'},
      ],
      showMenu: false,
      x: 0,
      y: 0,
      selectedMenuItem: null,
      mergeView: null,
      diffCount: 0,
      leftPanelColor: '',
      rightPanelColor: ''
    };
  },
  components: {
    ResizableDataTableContainer
  },
  props: {
    resourceUrls: Object,
  },
  computed: {
    fileDataItems: {
      get() {
        return this.$store.state.directoryData.selectedFolderItems
      },
      set(value) {
        //this.$store.dispatch('serviceData/setNewSelectedService', value)
      }
    },
    selectedItem: {
      get() {
        return this.$store.state.directoryData.selectedItem
      },
      set(value) {
        this.$store.dispatch('directoryData/setNewSelectedItem', value)
      }
    },
    selectedDiffItem: {
      get() {
        return this.$store.state.directoryData.selectedDiffItem
      },
      set(value) {
        this.$store.dispatch('directoryData/setNewSelectedDiffItem', value)
      }
    },
    dataTableSlideNumber: {
      get() {
        return this.$store.state.directoryData.dataTableSlideNumber
      },
      set(value) {
        this.$store.dispatch('directoryData/setNewDataTableSlideNumber', value)
      }
    },
    editorViewActive: {
      get() {
        return this.$store.state.directoryData.editorViewActive
      },
      set(value) {
        this.$store.dispatch('directoryData/setNewEditorViewActive', value)
      }
    },
    mergeViewActive: {
      get() {
        return this.$store.state.directoryData.mergeViewActive
      },
      set(value) {
        this.$store.dispatch('directoryData/setNewMergeViewActive', value)
      }
    },
    actionStatusIcon: {
      get() {
        return this.$store.state.directoryData.dataTableActionStatusIcon
      },
      set(value) {
        this.$store.dispatch('directoryData/setNewDataTableActionStatusIcon', value)
      }
    },
    actionStatusTitle: {
      get() {
        return this.$store.state.directoryData.dataTableActionStatusTitle
      },
      set(value) {
        this.$store.dispatch('directoryData/setNewDataTableActionStatusTitle', value)
      }
    },
    actionStatusMsg: {
      get() {
        return this.$store.state.directoryData.dataTableActionStatusMsg
      },
      set(value) {
        this.$store.dispatch('directoryData/setNewDataTableActionStatusMsg', value)
      }
    },
    actionStatusDialog: {
      get() {
        return this.$store.state.directoryData.dataTableActionStatusDialog
      },
      set(value) {
        this.$store.dispatch('directoryData/setNewDataTableActionStatusDialog', value)
      }
    },
    tableLoading: {
      get() {
        return this.$store.state.directoryData.dataTableLabelLoading
      },
      set(value) {
        this.$store.dispatch('directoryData/setNewDataTableLabelLoading', value)
      }
    },
    compareLabel: {
      get() {
        let serviceName = this.$store.state.directoryData.dataTableTitle
        if(serviceName && serviceName === 'Green' ) {
          return 'Compare to Blue'
        } else {
          return 'Compare to Green'
        }
      }
    },
  },
  mounted: function () {
    let self = this;
    self.codeMirrorEditor = CodeMirror.fromTextArea(document.getElementById("editor"), {
      lineNumbers: true,
      // mode: "htmlmixed",
      viewportMargin: Infinity,
      autoCloseBrackets: true,
      matchBrackets: true,
      foldGutter: true,
      gutters: ["CodeMirror-linenumbers", "CodeMirror-foldgutter"],
    });
    self.codeMirrorEditor.setSize("100%", window.innerHeight - self.editorResizeDiff);
  },
  created: function () {
  },
  watch: {
    parseType: function (value) {
      let self = this
      if (value == 'json') {
        self.codeMirrorEditor.setOption("mode", {
          name: "javascript",
          jsonld: true,
          statementIndent: 2
        })
        self.setMergeViewMode('javascript')
      } else if (value == 'javascript') {
        self.codeMirrorEditor.setOption("mode", {
          name: "javascript",
          jsonld: true,
          statementIndent: 2
        })
        self.setMergeViewMode('javascript')
      } else if (value == 'xml') {
        self.codeMirrorEditor.setOption("mode", 'xml')
        self.setMergeViewMode('xml')
      } else if (value == 'html') {
        self.codeMirrorEditor.setOption("mode", 'htmlmixed')
        self.setMergeViewMode('htmlmixed')
      } else if (value == 'shell') {
        self.codeMirrorEditor.setOption("mode", 'shell')
        self.setMergeViewMode('shell')
      } else if (value == 'properties') {
        self.codeMirrorEditor.setOption("mode", 'properties')
        self.setMergeViewMode('properties')
      } else if (value == 'yaml') {
        self.codeMirrorEditor.setOption("mode", 'yaml')
        self.setMergeViewMode('yaml')
      }else {
        self.codeMirrorEditor.setOption("mode", null)
        self.setMergeViewMode('xml')
      }
      self.resetGutterCss()
    },
    selectedItem: async function (item) {
      this.codeMirrorEditor.setValue("")
      let self = this;
      self.dataTableContentTitle = item["name"]
      if (item["subFolders"]) {
        this.$store.dispatch('directoryData/setNewDataTableSlideNumber', 1)
        this.$store.dispatch('directoryData/setNewTreeActiveItems', [item])
      } else {
        this.$store.dispatch('directoryData/setNewDataTableActionStatusMsg', "Retrieving file")
          .then(this.$store.dispatch('directoryData/setNewDataTableActionStatusDialog', true))
          .then(() => {
            self.codeMirrorEditor.setValue("")
            self.dataTableContentTitle = item["name"]
          })
          .then(this.$store.dispatch('directoryData/setNewDataTableSlideNumber', 2))
          .then(() => {
            let requestObj = {
              application: self.$store.state.applicationData.selectedApplication.name,
              service: item['serviceName'],
              serviceEnv: self.$store.state.applicationData.selectedEnvironment,
              bucketName: item['s3BucketName'],
              s3Key: item['s3Key']
            };
            return fetch(this.resourceUrls.s3FileData, {//TODO: REMOVE DEBUG
              method: 'POST',
              headers: {
                'access-token': sessionStorage.getItem('accessToken')
              },
              body: JSON.stringify(requestObj),
            })
              .then(async response => {
                const parsedResponse = await response.json();
                self.tableLoading = false
                if (response.status === 200) {
                  self.writeAccess = parsedResponse.fileData["writeAccess"]
                  self.codeMirrorEditor.setValue(parsedResponse.fileData['data'])
                  self.parseType = self.determineFileType(parsedResponse)
                  this.$store.dispatch('directoryData/setNewEditorViewActive', true)
                    .then(this.$store.dispatch('directoryData/setNewMergeViewActive', false))
                    .then(this.$store.dispatch('directoryData/setNewDataTableActionStatusMsg', ""))
                    .then(this.$store.dispatch('directoryData/setNewDataTableActionStatusDialog', false))
                }
                else if(response.status === 403){
                  this.$store.dispatch('directoryData/setNewEditorViewActive', false)
                    .then(this.$store.dispatch('directoryData/setNewMergeViewActive', false))
                    .then(this.$store.dispatch('directoryData/setNewDataTableActionStatusDialog', false))
                    .then(this.$store.dispatch('directoryData/setNewDataTableSlideNumber', 1))
                    .then(() => {
                      self.updateStatusProperties("mdi-alert-circle-outline",parsedResponse.status,parsedResponse.message)
                      this.saveSnackBar = true
                    })
                }
                else {//
                  this.$store.dispatch('directoryData/setNewEditorViewActive', false)
                    .then(this.$store.dispatch('directoryData/setNewMergeViewActive', false))
                    .then(this.$store.dispatch('directoryData/setNewDataTableActionStatusDialog', false))
                    .then(this.$store.dispatch('directoryData/setNewDataTableSlideNumber', 1))
                    .then(() => {
                      self.updateStatusProperties("mdi-alert-circle-outline",parsedResponse.status,parsedResponse.message)
                      this.saveSnackBar = true
                    })
                }

              })
              .catch(err => {
                this.$store.dispatch('directoryData/setNewDataTableActionStatusMsg', "")
                  .then(this.$store.dispatch('directoryData/setNewDataTableActionStatusDialog', false))
                console.warn(err)
              })
          })
          .catch(err => {
            this.$store.dispatch('directoryData/setNewDataTableActionStatusMsg', "")
              .then(this.$store.dispatch('directoryData/setNewDataTableActionStatusDialog', false))
            console.warn(err)
          })
      }

    },
    selectedDiffItem: async function (item) {
      let messageColor = ''
      this.$refs.diff_view.innerHTML = "";
      let self = this;
      self.dataTableContentTitle = item["name"]
      this.$store.dispatch('directoryData/setNewDataTableActionStatusMsg', "Retrieving files")
      .then(this.$store.dispatch('directoryData/setNewDataTableActionStatusDialog', true))
      .then(this.$store.dispatch('directoryData/setNewDataTableSlideNumber', 3))
      .then(async ()=> {
        let requestObjOriginal = {
          application: self.$store.state.applicationData.selectedApplication.name,
          service: item['serviceName'],
          serviceEnv: {...self.$store.state.applicationData.selectedEnvironment},
          bucketName: item['s3BucketName'],
          s3Key: item['s3Key']
        };
        if(item['serviceName']==='Green') {
          messageColor = 'Blue'
          self.leftPanelColor = 'Blue'
          self.rightPanelColor = 'Green'
        } else {
          messageColor = 'Green'
          self.leftPanelColor = 'Green'
          self.rightPanelColor = 'Blue'
        }
        let requestObjCompare = {
          application: self.$store.state.applicationData.selectedApplication.name,
          service: item['serviceName']==='Green'? 'Blue': 'Green',
          serviceEnv: {...self.$store.state.applicationData.selectedEnvironment},
          bucketName: item['s3BucketName'],
          s3Key: item['s3Key']
        };
        const res = await Promise.all([
          fetch(this.resourceUrls.s3FileData, {
            method: 'POST',
            headers: {'access-token': sessionStorage.getItem('accessToken')},
            body: JSON.stringify(requestObjOriginal),
          }),
          fetch(this.resourceUrls.s3FileData, {
            method: 'POST',
            headers: {'access-token': sessionStorage.getItem('accessToken')},
            body: JSON.stringify(requestObjCompare),
          })
        ]);
        if(!_.every(res, ['status', 200])) throw Error("File fetching failed");
        const data = await Promise.all(res.map(r => r.json()))
        self.tableLoading = false
        
        let orig2 = data[0].fileData['data']
        let value = data[1].fileData['data']
            
        var mergeView = CodeMirror.MergeView(this.$refs.diff_view, {
          value: value,
          origLeft: null,
          orig: orig2,
          lineNumbers: true,
          showDifferences: true,
          collapseIdentical: false,
          connect: 'align',
          revertButtons: false,
          allowEditingOriginals: false,
          viewportMargin: Infinity,
        });
        self.mergeView = mergeView
        var height = window.innerHeight - self.resizeDiff;
        if (mergeView.leftOriginal())
          mergeView.leftOriginal().setSize(null, height);
        mergeView.editor().setSize(null, height);
        if (mergeView.rightOriginal())
          mergeView.rightOriginal().setSize(null, height);
        mergeView.wrap.style.height = height + "px";
        self.parseType = ''
        setTimeout(()=>{
            self.parseType = self.determineFileType(data[0])
            self.diffCount = self.countDifferences(orig2, value)
          }, 500)
            
        this.$store.dispatch('directoryData/setNewEditorViewActive', false)
          .then(this.$store.dispatch('directoryData/setNewMergeViewActive', true))
          .then(this.$store.dispatch('directoryData/setNewDataTableActionStatusMsg', ""))
          .then(this.$store.dispatch('directoryData/setNewDataTableActionStatusDialog', false))
      })
      .catch(err => {
        console.log(err)
        this.$store.dispatch('directoryData/setNewEditorViewActive', false)
        .then(this.$store.dispatch('directoryData/setNewMergeViewActive', false))
        .then(this.$store.dispatch('directoryData/setNewDataTableActionStatusDialog', false))
        .then(this.$store.dispatch('directoryData/setNewDataTableSlideNumber', 1))
        .then(() => {
          self.updateStatusProperties("mdi-alert-circle-outline","There is no file in the corresponding " + messageColor + " folder to compare against.")
          this.saveSnackBar = true
          self.tableLoading = false
        })
      });
    }
  },
  methods: {
    countDifferences(left, right) {
      var dmp = new DiffMatchPatch();
      var diff = dmp.diff_main(left, right);
      dmp.diff_cleanupSemantic(diff);
      return diff.filter(l => l[0] === -1).length
    },
    determineFileType(parsedResponse) {
      var fileType
      if (parsedResponse.fileData["fileType"].includes('json') || parsedResponse.fileData["fileExtension"].includes('json')) {
        fileType = "json"
      } else if (parsedResponse.fileData["fileType"].includes('js') || parsedResponse.fileData["fileType"].includes('javascript') || parsedResponse.fileData["fileExtension"].includes('js')) {
        fileType = "javascript"
      } else if (parsedResponse.fileData["fileType"].includes('xml') || parsedResponse.fileData["fileExtension"].includes('xml')) {
        fileType = "xml"
      } else if (parsedResponse.fileData["fileType"].includes('html') || parsedResponse.fileData["fileExtension"].includes('html')) {
        fileType = "html"
      } else if (parsedResponse.fileData["fileType"].includes('sh') || parsedResponse.fileData["fileExtension"].includes('sh')) {
        fileType = "shell"
      } else if (parsedResponse.fileData["fileType"].includes('properties') || parsedResponse.fileData["fileExtension"].includes('properties')) {
        fileType = "properties"
      } else if (parsedResponse.fileData["fileType"].includes('yaml') || parsedResponse.fileData["fileExtension"].includes('yaml') || parsedResponse.fileData["fileType"].includes('yml') || parsedResponse.fileData["fileExtension"].includes('yml')) {
        fileType = "yaml"
      } else if (parsedResponse.fileData["fileType"].includes('conf') || parsedResponse.fileData["fileExtension"].includes('conf')) {
        fileType = "shell"
      }else {
        fileType = "text"
      }
      return fileType
    },
    setMergeViewMode(mode) {
      let self = this
      if(self.mergeView) {
        if (self.mergeView.leftOriginal())
          self.mergeView.leftOriginal().setOption("mode",mode)
        self.mergeView.editor().setOption("mode",mode)
        if (self.mergeView.rightOriginal())
          self.mergeView.rightOriginal().setOption("mode",mode)
      }
    },
    diffItem() {
      this.$store.dispatch('directoryData/setNewSelectedDiffItem', null)
      this.$store.dispatch('directoryData/setNewSelectedDiffItem', this.selectedMenuItem)
    },
    showRightClickMenu (e, item) {
      e.preventDefault()
      this.showMenu = false
      this.x = e.clientX
      this.y = e.clientY
      this.selectedMenuItem = item
      this.$nextTick(() => {
        this.showMenu = true
      })
    },
    resetGutterCss: function () {//workaround to reset the gutter css when the language mode is changed
      let tmp = this.codeMirrorEditor.getValue()
      this.codeMirrorEditor.setValue("")
      this.codeMirrorEditor.setValue(tmp)
      this.codeMirrorEditor.refresh()
    },
    resizeCodemirror: function () {
      let self = this;
      window.innerHeight - self.resizeDiff
      this.treeViewStyles = {
        height: `${window.innerHeight - self.resizeDiff}px`
      }
      try {
        window.clearTimeout(self.timer1)
        self.timer1 = window.setTimeout(function () {
          self.codeMirrorEditor.setSize("100%", window.innerHeight - self.editorResizeDiff);
          if(self.mergeView) {
            var height = window.innerHeight - self.resizeDiff;
            if (self.mergeView.leftOriginal())
              self.mergeView.leftOriginal().setSize(null, height);
            self.mergeView.editor().setSize(null, height);
            if (self.mergeView.rightOriginal())
              self.mergeView.rightOriginal().setSize(null, height);
            self.mergeView.wrap.style.height = height + "px";
          }
        }, 100);
      } catch (e) {
      }
    },
    wrapLine: function (switchStatus) {
      if (switchStatus) {
        this.codeMirrorEditor.setOption("lineWrapping", true)
      } else {
        this.codeMirrorEditor.setOption("lineWrapping", false)
      }
    },
    matcherChanged: function (switchStatus) {
      if (switchStatus) {
        this.codeMirrorEditor.setOption("highlightSelectionMatches", {showToken: /\w/, annotateScrollbar: true})
      } else {
        this.codeMirrorEditor.setOption("highlightSelectionMatches", false)
      }
    },
    formatDate: function (item) {
      try {
        if (item.lastModified && item.lastModified != "") {
          return moment(item.lastModified).format('YYYY-MM-DD HH:mm:ss')
        } else {
          return ""
        }
      } catch (e) {
        return ""
      }
    },
    formatSize: function (item) {
      try {
        if (item.size && item.size != 0) {
          return filesize(item.size)
        } else {
          return ""
        }
      } catch (e) {
        return ""
      }
    },
    tableContextMenu: function (item) {
    },
    dataTableItemClicked: function (item) {
      this.$store.dispatch('directoryData/setNewSelectedItem', null)
      this.$store.dispatch('directoryData/setNewSelectedItem', item)
    },
    backToDataTable: function () {
      this.$store.dispatch('directoryData/setNewEditorViewActive', false)
      this.$store.dispatch('directoryData/setNewMergeViewActive', false)
      this.$store.dispatch('directoryData/setNewDataTableSlideNumber', 1)
    },
    updateStatusProperties: function (icon, titleMsg, bodyMsg) {
      this.$store.dispatch('directoryData/setNewDataTableActionStatusIcon', icon)
        .then(this.$store.dispatch('directoryData/setNewDataTableActionStatusTitle', titleMsg))
        .then(this.$store.dispatch('directoryData/setNewDataTableActionStatusMsg', bodyMsg))
    },
    saveCurrentItem: function () {
      this.isSaving = true
      this.$store.dispatch('directoryData/setNewDataTableActionStatusMsg', "Saving File")
        .then(this.$store.dispatch('directoryData/setNewDataTableActionStatusDialog', true))
      let self = this
      let item = self.$store.state.directoryData.selectedItem
      let requestObj = {
        application: self.$store.state.applicationData.selectedApplication.name,
        service: item['serviceName'],
        serviceEnv: self.$store.state.applicationData.selectedEnvironment,
        bucketName: item['s3BucketName'],
        s3Key: item['s3Key'],
        fileData: self.codeMirrorEditor.getValue()
      };
      return fetch(this.resourceUrls.s3UpdateFileData, {
        method: 'POST',
        headers: {
          'access-token': sessionStorage.getItem('accessToken')
        },
        body: JSON.stringify(requestObj),
      })
        .then(async response => {
          this.isSaving = false
          if (response.status === 200) {
            this.updateStatusProperties("mdi-check-circle-outline","Files Saved","File saved successfully to s3 bucket.")
            } else {
            let parsedResponse = await response.json()
            self.updateStatusProperties("mdi-alert-circle-outline",parsedResponse.status,parsedResponse.message)
          }
          this.$store.dispatch('directoryData/setNewDataTableActionStatusDialog', false)
          this.saveSnackBar = true
        })
        .catch(err => {
            this.isSaving = false
              this.$store.dispatch('directoryData/setNewDataTableActionStatusDialog', false)
              .then(() => {
                self.updateStatusProperties("mdi-close-circle-outline",err.name,err.message)
                this.saveSnackBar = true
              })
            console.warn(err)
          }
        )
    },
    gotoNextDiff: function () {
      this.mergeView.edit.execCommand("goNextDiff");
    },
    gotoPreviousDiff: function () {
      this.mergeView.edit.execCommand("goPrevDiff");
    }
  }
};
</script>

<style>
  .CodeMirror-focused .cm-matchhighlight {
    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAYAAABytg0kAAAAFklEQVQI12NgYGBgkKzc8x9CMDAwAAAmhwSbidEoSQAAAABJRU5ErkJggg==);
    background-position: bottom;
    background-repeat: repeat-x;
  }

  .cm-matchhighlight {
    background-color: lightgreen
  }

  .CodeMirror-selection-highlight-scrollbar {
    background-color: green
  }

  .statusDialogCls {
    margin-left: 400px !important;
  }
</style>
<style scoped>


</style>

<style scoped>
.fad-log-viewer-header h1 {
  text-align: center;
}

.fad-ace-container {
  flex: 1;
  background-color: white;
  display: flex;
  flex-direction: column;
  height: 100%;
}
</style>

<style scoped>
html.fad-html-ace-maximized {
  overflow: hidden;
}

.max-btn {
  right: 10px !important;
}

.jsoneditor-poweredBy {
  display: none;
}

.jsoneditor-container {
  height: 100%;
}

.transparent-background-pattern {
  background-color: #fff;
  background-image: linear-gradient(45deg, #ccc 25%, transparent 25%, transparent 75%, #ccc 75%, #ccc),
  linear-gradient(45deg, #ccc 25%, transparent 25%, transparent 75%, #ccc 75%, #ccc);
  background-size: 10px 10px;
  background-position: 0 0, 5px 5px;
}

.fad-code.transparent-background-pattern {
  padding: 10px;
  text-align: center;
  margin: 0 auto;
  width: 100%;
  box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
  border: 1px solid #ccc;
}

.fad-focused {
  display: flex;
  flex-direction: row;
  margin-bottom: 1px;
  flex-wrap: wrap;
}

.fad-focused h3 {
  margin-top: 3px;
  margin-bottom: 1px;
  text-align: center;
  margin-left: 5px;
  font-size: 22px;
  font-weight: 400
}
</style>
