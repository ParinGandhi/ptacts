<template>
  <div style="padding: 0px; margin: 0px">
    <Header v-bind:username="username"
            v-bind:environment="environment"
            v-bind:resourceUrls="resourceUrls">
      <v-sheet style="background-color: transparent; padding: 1px; margin-top: 0px" v-show="this.$store.state.applicationData.applications.length === 0"

      >
        <v-skeleton-loader
          class="mx-auto custom-skeleton-btn-width"
          max-width="100"
          width="100"
          type="button"
        ></v-skeleton-loader>
      </v-sheet>
      <ul class="fad-nav-selections nav navbar-nav" style="padding-left: 0px">
        <li v-for="application in applications"
            v-bind:key="application.name"
            v-on:click="selectApplication(application)"
            v-bind:class="{active: application === selectedApplication}"
        >
          <a>{{ application.name }}</a>
        </li>
      </ul>
    </Header>
    <v-main class="" role="main">
      <v-container class="" fluid style="padding: 0px" fill-height>
        <v-row align="stretch" style="">
          <v-col
            style="background-color: #055072; margin: 12px 0px 0px 0px"
            v-if="!selectedApplication"
          >
            <v-container fluid style="padding: 0px; height: 100%;" fill-height>
              <div class="fad-service-widget-blank">
                <div v-if="this.$store.state.applicationData.applications.length === 0"
                     class="fad-service-widget-blank">
                  <h1>There are no applications with approved environments configured</h1>
                </div>
                <div v-if="this.$store.state.applicationData.applications.length > 0" class="fad-service-widget-blank">
                  <h1>Select an application and to get started.</h1>
                </div>
              </div>
            </v-container>
          </v-col>

          <v-col
            cols="6"
            md=3
            style="background-color: #d5d5d5; padding-bottom: 1px; margin: 12px 0px -10px 0px"
            v-if="selectedApplication"
          >
            <app-config-directory-widget
              v-bind:environment="environment"
              v-bind:resourceUrls="resourceUrls"
            >

            </app-config-directory-widget>

          </v-col>
          <v-col
            cols="12"
            md="9"
            style="background-color: #055072; padding: 0px; margin: 23px 0px 0px 0px"
            v-if="selectedApplication"
          >
            <app-config-data-widget
              v-bind:environment="environment"
              v-bind:resourceUrls="resourceUrls"
            >
            </app-config-data-widget>
          </v-col>
        </v-row>
      </v-container>
    </v-main>
  </div>
</template>

<script>
import Header from "../../dashboard/components/Header";
import AppConfigDirectoryWidget from "@/appconfig/components/AppConfigDirectoryWidget";
import AppConfigDataWidget from "@/appconfig/components/AppConfigDataWidget";
import jwtDecode from "jwt-decode";
import {redirectToIndexIfNoAccessToken} from "../../utils/RedirectToIndex";
import _ from "lodash";
import uuidv1 from "uuid/v1"

export default {
  name: "AppConfigViewer",
  data: function () {
    return {
      step: 1,
      environment: {},
      userDropdownOpen: false
    };
  },
  components: {
    Header,
    AppConfigDirectoryWidget,
    AppConfigDataWidget
  },
  methods: {
    selectApplication: function (application) {
      let envList = []
      _.map(application.services, service => {
        if (service.environments)
          envList = _.concat(envList, service.environments)
      })
      if (envList.length < 1) {
        console.log("no environments configured for app services")
        return
      }
      envList = _.uniqBy(envList, env => env.env)
      let filteredList = []
      _.forEach(application.services, service => {
        if (service.environments && envList[0] && _.find(service.environments, env => env.env == envList[0].env)) {
          filteredList.push(service)
          if(service.s3BucketName.includes(envList[0].active_bucket_color))
          {
            service.activeBucket = true
          }else{
            service.activeBucket = false
          }
        }
      })
      this.$store.dispatch('directoryData/setNewEditorViewActive', false)
      this.$store.dispatch('directoryData/setNewMergeViewActive', false)
      this.$store.dispatch('directoryData/setNewDataTableSlideNumber', 1)
      this.$store.dispatch('directoryData/setNewDataTableTitle', "")
      this.$store.dispatch('applicationData/setNewSelectedEnvironment', envList[0])
      this.$store.dispatch('applicationData/setNewEnvironments', envList)
      this.$store.dispatch('applicationData/setNewSelectedApplication', application)
      this.$store.dispatch('directoryData/setNewTreeModel', [])
      this.$store.dispatch('directoryData/setNewTreeViewId', uuidv1())
      this.$store.dispatch('directoryData/setNewTreeActiveItems', [])
      this.$store.dispatch('directoryData/setNewTreeOpenItems', [])
      this.$store.dispatch('directoryData/setNewTreeValuesItems', [])
      this.$store.dispatch('directoryData/setNewFolderTree', _.cloneDeep(filteredList))
      this.$store.dispatch('directoryData/setNewSelectedFolderItems', [])
    }
  },
  props: {
    applications: Array,
    resourceUrls: Object,
  },
  computed: {
    username: function () {
      try {
        return jwtDecode(sessionStorage.getItem('idToken'))['custom:uid'];
      } catch (err) {
        return 'User';
      }
    },
    selectedApplication: function () {
      return this.$store.state.applicationData.selectedApplication
    }
  },
  mounted: function () {
    fetch(this.resourceUrls.environment, {
      headers: {
        "access-token": sessionStorage.getItem("accessToken")
      }
    })
      .then(response => response.json())
      .then(json => (this.environment = json))
      .catch(redirectToIndexIfNoAccessToken)
  }
};
</script>
<style>
.custom-skeleton-btn-width .v-skeleton-loader__button{
  width: 100px !important;
  height: 68px !important;
}
</style>
<style scoped>

.fad-app-selection {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.fad-nav-selections {
  display: flex;
  flex-direction: row;
  flex: 1;
  -ms-flex: 1 1 auto;
  font-size: 20px;
}

.fad-nav-selections.nav {
  margin: 0;
}

.fad-nav-selections.nav li a {
  padding: 0 10px;
}

.fad-nav-selections > li {
  cursor: pointer;
  display: flex;
  flex-basis: 115px;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.fad-nav-selections > li > a {
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: center;
  min-width: 70px;
}

.nav, .nav li, .nav li a {
  height: 100%;
}

.dropdown {
  display: table;
}

.dropdown > a {
  display: table-cell;
  text-align: center;
  vertical-align: middle;
}

.navbar-nav .open .dropdown-menu {
  position: absolute !important;
  background-color: white !important;
  border: 1px solid rgba(0, 0, 0, .15) !important;
  box-shadow: 0 6px 12px rgba(0, 0, 0, .175) !important;
  right: 0 !important;
}

.dropdown-menu {
  right: 0 !important;
  left: auto !important;
  width: max-content;
}

.fad-service-widget-blank {
  display: flex;
  flex: 1;
  -ms-flex: 1 1 100%;

  color: #cfe2ea;
  background-color: #055072;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.fad-service-widget-blank h1 {
  margin-top: 200px;
  padding: 0;
  display: table-cell;
  text-align: center;
  vertical-align: middle;
}

.fad-nav-selections.nav li a {
  padding: 0 10px;
}

.fad-nav-selections > li {
  cursor: pointer;
  display: flex;
  flex-basis: 115px;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.fad-nav-selections > li > a {
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: center;
  min-width: 70px;
}

.dropdown > a {
  display: table-cell;
  text-align: center;
  vertical-align: middle;
}
</style>

<style>
html {
  height: 100%;
  overflow: hidden;
}
</style>
