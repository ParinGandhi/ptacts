const state = () => ({
  dataTableActionStatusIcon: "",
  dataTableActionStatusTitle: "",
  dataTableActionStatusMsg: "",
  dataTableActionStatusDialog: false,
  dataTableLabelLoading: false,
  editorViewActive: false,
  mergeViewActive: false,
  dataTableSlideNumber:1,
  activeS3Bucket: "",
  dataTableTitle: "",
  selectedItem:{},
  selectedDiffItem:{},
  selectedFolder: null,
  selectedFolderItems: [],
  folderTree: [],
  treeModel: [],
  treeViewId: 1,
  treeActiveItems: [],
  treeOpenItems: [],
  treeValuesItems: [],
  filteredServices: []
})

const getters = {
  getEditorViewActive: (state) => {
    return state.editorViewActive;
  },
  getMergeViewActive: (state) => {
    return state.mergeViewActive;
  },
  getDataTableActionStatusIcon: (state) => {
    return state.dataTableActionStatusIcon;
  },
  getDataTableActionStatusTitle: (state) => {
    return state.dataTableActionStatusTitle;
  },
  getDataTableActionStatusMsg: (state) => {
    return state.dataTableActionStatusMsg;
  },
  getDataTableActionStatusDialog: (state) => {
    return state.dataTableActionStatusDialog;
  },
  getDataTableLabelLoading: (state) => {
    return state.dataTableLabelLoading;
  },
  getDataTableSlideNumber: (state) => {
    return state.dataTableSlideNumber;
  },
  getActiveS3Bucket: (state) => {
    return state.activeS3Bucket;
  },
  getDataTableTitle: (state) => {
    return state.dataTableTitle;
  },
  getSelectedItem: (state) => {
    return state.selectedItem;
  },
  getSelectedDiffItem: (state) => {
    return state.selectedDiffItem;
  },
  getSelectedFolder: (state) => {
    return state.selectedFolder;
  },
  getSelectedFolderItems: (state) => {
    return state.selectedFolderItems;
  },
  getFolderTree: (state) => {
    return state.folderTree;
  },
  getTreeModel: (state) => {
    return state.treeModel;
  },
  getTreeViewId: (state) => {
    return state.treeViewId;
  },
  getTreeActiveItems: (state) => {
    return state.treeActiveItems;
  },
  getTreeOpenItems: (state) => {
    return state.treeOpenItems;
  },
  getTreeValuesItems: (state) => {
    return state.treeValuesItems;
  },
  getFilteredServices: (state) => {
    return state.filteredServices;
  }
}

const mutations = {
  setEditorViewActive(state, apps) {
    state.editorViewActive = apps
  },
  setMergeViewActive(state, apps) {
    state.mergeViewActive = apps
  },
  setDataTableActionStatusIcon(state, apps) {
    state.dataTableActionStatusIcon = apps
  },
  setDataTableActionStatusTitle(state, apps) {
    state.dataTableActionStatusTitle = apps
  },
  setDataTableActionStatusMsg(state, apps) {
    state.dataTableActionStatusMsg = apps
  },
  setDataTableActionStatusDialog(state, apps) {
    state.dataTableActionStatusDialog = apps
  },
  setDataTableLabelLoading(state, apps) {
    state.dataTableLabelLoading = apps
  },
  setDataTableSlideNumber(state, apps) {
    state.dataTableSlideNumber = apps
  },
  setActiveDirectory(state, apps) {
    state.activeDirectory = apps
  },
  setDataTableTitle(state, apps) {
    state.dataTableTitle = apps
  },
  setSelectedItem(state, apps) {
    state.selectedItem = apps
  },
  setSelectedDiffItem(state, apps) {
    state.selectedDiffItem = apps
  },
  setSelectedFolder(state, apps) {
    state.selectedFolder = apps
  },
  setSelectedFolderItems(state, apps) {
    state.selectedFolderItems = apps
  },
  setFolderTree(state, apps) {
    state.folderTree = apps
  },
  setTreeModel(state, apps) {
    state.treeModel = apps
  },
  setTreeViewId(state, apps) {
    state.treeViewId = apps
  },
  setTreeActiveItems(state, apps) {
    state.treeActiveItems = apps
  },
  setTreeOpenItems(state, apps) {
    state.treeOpenItems = apps
  },
  setTreeValuesItems(state, apps) {
    state.treeValuesItems = apps
  },
  setFilteredServices(state, svc) {
    state.filteredServices = svc;
  }
}

const actions = {
  setNewEditorViewActive({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setEditorViewActive', app)
      resolve()
    })
  },
  setNewMergeViewActive({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setMergeViewActive', app)
      resolve()
    })
  },
  setNewDataTableActionStatusIcon({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setDataTableActionStatusIcon', app)
      resolve()
    })
  },
  setNewDataTableActionStatusTitle({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setDataTableActionStatusTitle', app)
      resolve()
    })
  },
  setNewDataTableActionStatusMsg({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setDataTableActionStatusMsg', app)
      resolve()
    })
  },
  setNewDataTableActionStatusDialog({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setDataTableActionStatusDialog', app)
      resolve()
    })
  },
  setNewDataTableLabelLoading({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setDataTableLabelLoading', app)
      resolve()
    })
  },
  setNewDataTableSlideNumber({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setDataTableSlideNumber', app)
      resolve()
    })
  },
  setNewActiveS3Bucket({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setActiveDirectory', app)
      resolve()
    })
  },
  setNewDataTableTitle({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setDataTableTitle', app)
      resolve()
    })
  },
  setNewSelectedItem({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setSelectedItem', app)
      resolve()
    })
  },
  setNewSelectedDiffItem({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setSelectedDiffItem', app)
      resolve()
    })
  },
  setNewSelectedFolder({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setSelectedFolder', app)
      resolve()
    })
  },
  setNewSelectedFolderItems({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setSelectedFolderItems', app)
      resolve()
    })
  },
  setNewFolderTree({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setFolderTree', app)
      resolve()
    })
  },
  setNewTreeModel({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setTreeModel', app)
      resolve()
    })
  },
  setNewTreeViewId({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setTreeViewId', app)
      resolve()
    })
  },
  setNewTreeActiveItems({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setTreeActiveItems', app)
      resolve()
    })
  },
  setNewTreeOpenItems({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setTreeOpenItems', app)
      resolve()
    })
  },
  setNewTreeValuesItems({commit}, app) {
    return new Promise((resolve, reject) => {
      commit('setTreeValuesItems', app)
      resolve()
    })
  },
  setNewFilteredServices({commit}, svc) {
    return new Promise((resolve, reject) => {
      commit('setFilteredServices', svc)
      resolve()
    })
  }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
