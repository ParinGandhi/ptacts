<template>
<v-app>
  <div id="app">
    <Logviewer v-if="resourceUrls"
          v-bind:resourceUrls="resourceUrls"/>
  </div>
</v-app>
</template>

<script>
  import 'bootstrap/dist/css/bootstrap.css'
  import 'bootstrap/dist/css/bootstrap-theme.css'
  import 'promise-polyfill/src/polyfill'
  import 'abortcontroller-polyfill'
  import 'whatwg-fetch'
  import Logviewer from './components/Logviewer'
  import capabilities from '../utils/CapabilityTypes'
  import _ from 'lodash';
  import {redirectToIndexIfNoAccessToken, redirectToIndexIfUnauthenticated} from "../utils/RedirectToIndex";


  export default {
    name: 'app',
    data: function () {
      return {
        resourceUrls: null,
      }
    },
    components: {
      Logviewer,
    },
    async created() {
      redirectToIndexIfNoAccessToken();
      const self = this;
      await fetch('/resourceUrls.json')
        .then(response => response.json())
        .then(json => {
          self.resourceUrls = json;
          return fetch(json.services, {
            headers: {
              'access-token': sessionStorage.getItem('accessToken')
            },
          })
            .then(response => {
              redirectToIndexIfUnauthenticated(response);
              return response;
            })
            .catch(redirectToIndexIfNoAccessToken)
        })
        .then(response => response.json())
        .catch(redirectToIndexIfNoAccessToken)

      await fetch(this.resourceUrls.capabilities, {
        headers: {
          'access-token': sessionStorage.getItem('accessToken')
        }
      })
        .then(response => response.json())
        .then(json => {
          if(!_.find(json.capabilityList, (o => {return o.name === capabilities.transaction_log_search_capability.name}))){
            window.location.href = '/menu.html';
          }
        })
        .catch(redirectToIndexIfNoAccessToken)
    },
  }
</script>

<style>

  @import url('https://fonts.googleapis.com/css?family=Fira+Mono|Fira+Sans&display=swap');

  html, body, #app {
    width: 100%;
    height: 100%;
    display: flex;
    flex: 1;
    flex-direction: column;
    overflow-y: auto;
  }

  body {
    font-family: "Fira Sans", sans-serif;
  }

  .badge {
    background-color: #6c6c6c;
  }
</style>
