import 'bootstrap/dist/css/bootstrap.css'

import { createApp, h } from 'vue'
// import Vue from 'vue'
import App from './App.vue'
// import vuetify from '@/plugins/vuetify'
import { createVuetify } from 'vuetify/lib/framework.mjs'
import 'vuetify/styles'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'
import { defaults as vuetifyDefaults } from 'vuetify';


// if (process.env.NODE_ENV !== 'production') {
//   Vue.use(require('vue-axe').default);
// }
// Vue.config.productionTip = false

// new Vue({
//   vuetify,
//   render: h => h(App),
// }).$mount('#app')

const app = createApp({
    render: ()=>h(App)
})

const vuetify = createVuetify({
    ssr: true,
    components,
    directives,
    defaults: vuetifyDefaults,
    opts: {
        theme: { dark: false },
        icons: {
         iconfont: 'mdi'
        }
      }
  })


// app.render(h => h(App))

if (process.env.NODE_ENV !== 'production') {
  app.use(require('vue-axe').default);
}
app.config.productionTip = false


app.use(vuetify)
app.mount('#app')