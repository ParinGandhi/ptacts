<template>
  <div class="fad-log-viewer-search">
    <div class="fad-log-viewer-search-input">
      <div class="fad-log-viewer-search-input-form">
        <form v-on:submit.prevent="searchCorrelationID">
          <div class="form-group">
            <label class="fad-tl-required">
              Correlation ID
              <input class="form-control"
                     type="text"
                     size="36"
                     v-model="correlationID"
                     placeholder="Correlation ID"
                     aria-required="true"
              />
            </label>
          </div>
          <input type="submit"
                 class="btn btn-default fad-search-button"
                 value="Search"
                 v-bind:disabled="requestBusy || correlationID.length === 0"/>
        </form>
        <div class="fad-log-viewer-result-record-count" v-if="logs.length !== 0">
          Result record count: {{logs.length}}
        </div>
      </div>
    </div>
    <div class="fad-log-viewer-search-output">
      <div v-if="logs.length > 0">
       <v-btn block color="#dee5ee" large v-on:click="viewDiagram" >
         {{displayTitle}}
         </v-btn>
      <LogviewerOutput v-bind:logs="logs" v-if="!diagramView"/>
      <LogviewerVisualization v-bind:logs="logs" v-if="diagramView"/>
      </div>
      <div class="fad-tl-error" v-if="error">
        {{error}}
      </div>
      <div v-if="lastQuery !== '' && !requestBusy && logs.length === 0">No results</div>
      <div v-if="lastQuery === ''">
        <h2>Perform a search to get started.</h2>
      </div>
    </div>
  </div>
</template>

<script>
  import LogviewerOutput from "./LogviewerOutput";
  import LogviewerVisualization from "./visualization/LogviewerVisualization.vue";
  import "whatwg-fetch";
  import {redirectToIndexIfNoAccessToken} from "../../utils/RedirectToIndex";

  export default {
    name: "LogviewerSearch",

    data: function () {
      return {
        logs: [],
        error: '',
        correlationID: '', // svi_serco_latency
        lastQuery: '',
        requestBusy: false,
        diagramView: false,
        displayTitle: 'Click here to View Logs Visualization'
      };
    },

    components: {
      LogviewerOutput,
      LogviewerVisualization
    },

    methods: {
      viewDiagram: function() {
        this.diagramView = !this.diagramView;
        if (this.diagramView)
           this.displayTitle = 'Click here to View Logs List'
        else  
           this.displayTitle = 'Click here to View Logs Visualization'

      },
      searchCorrelationID: async function () {
        if (this.requestBusy || this.correlationID === "") {
          return;
        }
        this.requestBusy = true;
        this.lastQuery = this.correlationID;
        this.logs = [];
        this.error = '';
        this.diagramView =false;

        const responsePromise = fetch(this.requestUrl, {
          method: 'POST',
          headers: {
            'access-token': sessionStorage.getItem('accessToken')
          }, 
          body: JSON.stringify({
          correlationId: this.correlationID,
          }),
        });
        return responsePromise
          .then(response => response.json())
          .then(response => {
            if (response.logs) {
              this.logs = response.logs;
              this.error = '';
            } else {
              this.logs = [];
              this.error = JSON.stringify(response.error, null, 2);
            }
            this.requestBusy = false;
          })
          .catch(ex => {
            redirectToIndexIfNoAccessToken();
            this.logs = [];
            this.error = JSON.stringify(ex.message, null, 2);
            this.requestBusy = false;
          });
      }
    },

    props: {
      requestUrl: String,
    },
  };
</script>

<style scoped>
  .fad-log-viewer-search {
    /*padding: 10px 0;*/
    height: 100%;
    display: flex;
    flex-direction: column;
  }
  .fad-log-viewer-search-input {
    color: #cfe2ea;
    background-color: #055072;
    padding: 0;
    margin: 0;
  }
  .fad-log-viewer-search-input-form {
    padding: 10px;
    border: 1px solid white;
    display: table;
    margin: 10px auto;

  }
  .fad-log-viewer-search-input-form input {
    display: block;
    color: #333;
    border-radius: 0;
  }
  .fad-tl-required:before {
    content: "* ";
    color: #f2adad; /* Choosing this color because it has the proper contrast with the background*/
  }
  .fad-log-viewer-result-record-count {
    margin-top: 10px;
  }
  .fad-log-viewer-search-output {
    height: 100%;
    background-color: #dfdfdf;
  }
  .fad-log-viewer-search-output h2 {
    text-align: center;
  }
  .fad-tl-error {
    overflow: auto;
    white-space: pre-wrap;
    padding: 10px;
  }
</style>
