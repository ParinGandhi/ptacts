<template>
   <div id="svg-diagram-show-area" class="scrollXY" ref="field">
    <LogviewerModal 
    v-for="nodeItem in nodesPayload"
    :key="nodeItem.id"
    :payload="nodeItem.payload"
    :selected="nodeItem.id === selectedNode"
    v-model="showModal"
    />
    <Diagram
      :width="svgWidth"
      :height="svgHeight"
      :background="bg"
      :nodes="nodes"
      :nodeNum="nodesNum"
      :nodesPayload="nodesPayload"
      :links="links"
      @nodeClicked="nodeclicked($event)"
      ></Diagram>
  </div>
</template>

<script>
import Diagram from "./Diagram";
import LogviewerModal from "./LogviewerModal";
import data from "../../assets/externalCalls.json";
export default {
  name: "LogviewerVisualization",
  components: {
    Diagram,
    LogviewerModal
  },
  props: {
    logs: Array
  },
  data() {
    return {
      bg: 'white',//#dfdfdf',
      nodes: [],
      nodesNum: [],
      nodesPayload: [],
      links: [],
      svgWidth:2000,
      svgHeight:2000,
      selectedNode:'id',
      showModal:false,
      externalCalls: [],
    };
  },

  mounted() {
    this.externalCalls = data.externalCalls;
    this.nodes = this.dataLog.nodes;
    this.links = this.dataLog.links;
    this.nodesNum = this.dataLog.nodeNum   
    this.nodesPayload = this.dataLog.nodesPayload
    
    let svgHeight = 0
    if(this.nodesNum && this.nodesNum.length > 0) {
      svgHeight = this.nodesNum.length * 105
      if(svgHeight > 2000) {
        this.svgHeight = svgHeight
      }
    }
  },
  computed:{   
      dataLog: function() {
       let sortedLogs = this.logs;
       sortedLogs.sort((a, b) => parseFloat(a.timestamp) - parseFloat(b.timestamp))       
       let name=[], req=[], resp=[], nodes = [], nodeNum= [],nodesPayload=[], links = [],reqServerLogs=[], row=0,np=0;
       const nodeWidth = 200, nodeHeight = 50, link= 600, x0=500, y0=50;

        for (let i=0; i < sortedLogs.length; ++i) {     
          try{
          if(Object.prototype.hasOwnProperty.call(sortedLogs[i], 'request') && sortedLogs[i].tags["span.kind"] === 'client') {
            req[0] = sortedLogs[i];
            name[0] = req[0].name;

            resp[0] = sortedLogs.slice(i,sortedLogs.length)
                      .filter(log => !Object.prototype.hasOwnProperty.call(log, 'request') && log.tags["span.kind"] === 'client')
                      .find(_respClientLog => (req[0].name === _respClientLog.name && req[0].tags["request.id"] === _respClientLog.tags["request.id"]));            
            
            req[1] = sortedLogs.slice(i,sortedLogs.length)
                    .filter(log => Object.prototype.hasOwnProperty.call(log, 'request') && log.tags["span.kind"] === 'server')
                    .find(_reqServerLog => (req[0].request.url.includes(_reqServerLog.request.path)));
            
            if (req[1]){
              name[1] = req[1].name;
              resp[1] = sortedLogs.slice(i,sortedLogs.length)
                        .filter(log => !Object.prototype.hasOwnProperty.call(log, 'request') && log.tags["span.kind"] === 'server')
                        .find(_respServerLog => (req[1].name === _respServerLog.name && req[1].tags["request.id"] === _respServerLog.tags["request.id"]));
              reqServerLogs.push(req[1]);              
              if(resp[1] && Object.prototype.hasOwnProperty.call(resp[1], 'response')) { 
                if(resp[1].response.statusCode)
                  resp[1].response = {"status_code":resp[1].response.statusCode};     
              }
              else if(Object.prototype.hasOwnProperty.call(resp[1], 'logs'))
                resp[1] = {"response":{"status_code":"error"}}; 
              }
            else {
              req[1] = {"request":"NA"};
              name[1] = this.externalCalls.find(extCall => extCall.endpoints.some(endpoint => req[0].request.url.includes(endpoint)));
              if(name[1])
                name[1] = name[1].service
              else
                 name[1] = 'other';  
              resp[1] = {"response":{"status_code":"NA"}};    
            } 
            if(req[0].request.path === '')        
                  req[0].request.path = req[0].request.url.replace("https:","") ;                 
            
            if(resp[0] === undefined || Object.prototype.hasOwnProperty.call(resp[0], 'logs'))
              resp[0] = {"response":{"status_code":resp[1].response.status_code}};
            else{
            if(resp[0].response.statusCode)
              resp[0].response = {"status_code":resp[0].response.statusCode};       
            }
            if (Object.prototype.hasOwnProperty.call(resp[0], 'logs') && resp[0].response.status_code === "NA")
              resp[0].response = {"status_code":"error"};
          }
          else if(Object.prototype.hasOwnProperty.call(sortedLogs[i], 'request') && sortedLogs[i].tags["span.kind"] === 'server') {
            if(reqServerLogs.includes(sortedLogs[i]))
              continue;
            else {
              name = [sortedLogs[i].request.headers["source-system-name"], sortedLogs[i].name];
              req = [{"request":{"path":sortedLogs[i].request.path, "method":sortedLogs[i].request.method}}, sortedLogs[i]];
              resp[1] = sortedLogs.slice(i,sortedLogs.length).filter(log => !Object.prototype.hasOwnProperty.call(log, 'request') && log.tags["span.kind"] === 'server')
                        .find(_respServerLog => (req[1].name === _respServerLog.name && req[1].tags["request.id"] === _respServerLog.tags["request.id"]));
              //respServerLogs.find(_respServerLog => (req[1].name === _respServerLog.name && req[1].tags["request.id"] === _respServerLog.tags["request.id"]))
              resp[0] = {"response":{"status_code":resp[1].response.status_code}};
          }}
          
          else continue;
          
        }

      catch(error) {
              console.log("Error:"+i+ "  " +error);
            }

          for (let col = 0; col < 2; ++col) { 
            nodes[row*2+col] = {
              "id": "node"+(row*2+col),
              "content": {
              "text": name[col].toUpperCase(),
              "fontSize": 18,
              "fontColor": "white",
              "color": "#315d8a"             
              },
              "width": nodeWidth,
              "height": nodeHeight,
              "stroke": "#315d8a",
              "point": {
                "x": col * (nodeWidth + link) + x0,
                "y": row * (2*nodeHeight) + y0
              },
              "shape": "rectangle",
            "payload": {
              "request": req[col],
              "response": resp[col]  
              }  

          }; 
          if (req[col].name){
          nodesPayload[np] = {
              "id": "payload"+(row*2+col),
              "content": {
              "text": "View Logs",
              "fontSize": 10,
              "color": "silver"             
              },
              "width": nodeWidth/3,
              "height": nodeHeight/2,
              "stroke": "black",
              "point": {
                "x": col * (nodeWidth + link) + x0 ,
                "y": row * (2*nodeHeight) + y0 + nodeHeight
              },
              "shape": "rectangle",
            "payload": {
              "request": req[col],
              "response": resp[col]  
              }  };
              np++;
          }
          }
           nodeNum[row] = {
            "id": "num"+(row),
            "content": {
              "text" : row+1,
              "fontSize": "20",
              "fontColor": "black",
              "color": "white" //"#dee5ee"//"#eef2f9"
            },
            "width": nodeWidth/5,
            "height": nodeHeight,
            "stroke": "#315d8a",
            "strokeWeight": "2",
            "point": {
              "x": x0* 3/4,
              "y": row * (nodeHeight * 2) + y0 
            },
            "shape": "circle", 
        };

          links[row] = {
            "id": "Link"+row ,
            "source": "node"+row*2,
            "destination": "node"+(row*2+1),
            "point": {
              "x": nodeWidth + x0,
              "y": row * (nodeHeight * 2) + y0 + nodeHeight/2
            },
            "color": "#315d8a",
            "pattern": "solid",
            "arrow": "dest",
            "path": req[0].request.method+" "+req[0].request.path,
            "statuscode": resp[0].response.status_code
          };
          row++;
            }
            return {nodes, links, nodeNum, nodesPayload};
        }},

  methods: {      
   
    nodeclicked: function(id) {
      this.selectedNode = id;
      this.showModal = true;
    },

  }
};
</script>
