<template>
  <g>
    <ellipse
      v-if="node.shape === 'ellipse'"
      :cx="x + node.width / 2"
      :cy="y + node.height / 2"
      :width="node.width"
      :height="node.height"
      :rx="node.width / 2"
      :ry="node.height / 2"
      :fill="content.color || '#ecf0f1'"
      :stroke-width="node.strokeWeight"
      :stroke="node.stroke"
      @touchstart="mousedown"
      @mousedown="mousedown"
    />
     <circle
      v-if="node.shape === 'circle'"
      :cx="x + node.width / 2"
      :cy="y + node.height / 2"
      :width="node.width"
      :height="node.height"
      :r="node.height / 2"
      :fill="content.color || '#ecf0f1'"
      :stroke-width="node.strokeWeight"
      :stroke="node.stroke"
      @touchstart="mousedown"
      @mousedown="mousedown"
    />
    <rect
      v-else
      :x="x"
      :y="y"
      :width="node.width"
      :height="node.height"
      rx="5"
      ry="3"
      :fill="content.color || '#ecf0f1'"
      :stroke-width="node.strokeWeight"
      :stroke="node.stroke"
      @touchstart="mousedown"
      @mousedown="mousedown"
    />
     <text
        :x="x + node.width / 2"
        :y="y + node.height / 2"
        font-family="Meiryo UI, sans-serif"
        :font-size="content.fontSize"
        text-anchor="middle"
        dominant-baseline="middle"
        :fill="content.fontColor"
        @touchstart="mousedown"
        @mousedown="mousedown"
      >
        {{ content.text }}
      </text>
  
  </g>
</template>
<script>
import mouseLocation from "diagram-vue/src/mouseLocation";
export default {
  mixins: [mouseLocation],
  props: {
    node: {
      width: Number,
      height: Number,
      id: String,
      point: {
        type: Object,
        default: {
          x: 0,
          y: 0
        }
      },
      content: {
        text: String,
        fontSize:Number,
        url: String,
        color: String
      },
      shape: {
        type: String,
        default: "rectangle"
      },
      stroke: String,
      strokeWeight: Number
    },
    selected: Boolean,
    labels: Object,
    scale: String,
    rWidth: Number,
    rHeight: Number,
  },
  watch: {
    node() {
      this.x = this.node.point.x;
      this.y = this.node.point.y;
    }
  },
  data() {
    return {
      id: this.node.id,
      x: this.node.point.x,
      y: this.node.point.y,
      content: this.node.content
    };
  },
  methods: {
    mousedown(e) {
      this.$emit("click", this.id);
    },

  }
};
</script>
<style lang="scss" scoped>
.shadow {
  filter: drop-shadow(1px 1px 3px rgba(0, 0, 0, 0.3));
  -webkit-filter: drop-shadow(1px 1px 3px rgba(0, 0, 0, 0.3));
  -moz-filter: drop-shadow(1px 1px 3px rgba(0, 0, 0, 0.3));
}
.button {
  cursor: pointer;
}
</style>
