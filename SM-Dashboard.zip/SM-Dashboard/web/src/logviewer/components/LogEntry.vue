<template>
  <div class="fad-log-entry-root"><!-- Do not put collapsed on the root tag; parent CSS may override collapsed styles -->
    <div class="fad-log-entry" v-bind:class="{'fad-log-entry-collapsed': collapsed}" v-bind:aria-expanded="(!collapsed).toString()">
      <div tabindex="0" v-on:click="toggleCollapse()" v-on:keyup.enter="toggleCollapse()" class="fad-log-entry-collapse-gutter">
        <div v-if="collapsed" class="fad-log-entry-collapse-gutter-icon">
<!--          &#x203a;-->
          <span class="glyphicon glyphicon-chevron-right" aria-label="expand"></span>
        </div>
        <div v-if="!collapsed" class="fad-log-entry-collapse-gutter-icon">
<!--          &#x2304;-->
          <span class="glyphicon glyphicon-chevron-down" aria-label="contract"></span>
        </div>
      </div>
      <div tabindex="-1" class="fad-log-entry-content">
        <div tabindex="0" class="fad-log-entry-collapsed-shadow" v-on:click="toggleCollapse()" v-on:keyup.enter="toggleCollapse()"></div>
        <div class="fad-log-entry-header">
          <div class="fad-log-entry-tags">
            <span class="badge">{{_get(logEntry, 'timestamp') | timestamp | tagPrefix('timestamp')}}</span>
            <span
              class="fad-log-entry-toggleable-tag badge"
              v-for="tag in tags"
              v-bind:key="tag"
              v-bind:class="{'fad-log-entry-filter-tag-active':activeTags[tag]}"
              tabindex="0"
              v-on:click="toggleTag(tag)"
              v-on:keyup.enter="toggleTag(tag)"
            >{{tag}}</span>
          </div>
          <div class="fad-log-entry-summary">
            <div class="fad-log-entry-code" v-if="logEntry.hasOwnProperty('request')">
              <div>{{ _get(logEntry, 'request.method') }} {{ _get(logEntry, 'request.url') }}</div>
            </div>
          </div>
          <div class="fad-log-entry-summary">
            <div class="fad-log-entry-code" v-if="logEntry.hasOwnProperty('response') && _get(logEntry, 'response.url')">
              <div>URL {{ _get(logEntry, 'response.url') }}</div>
            </div>
          </div>
        </div>
        <div class="fad-log-entry-body fad-log-entry-code">
          <div v-if="logEntry.hasOwnProperty('request')">
            <div class="">Headers</div>
            <div class="fad-code-quote">{{ JSON.stringify(logEntry.request.headers, null, 2) }}</div>
            <div class="">Body</div>
            <div class="fad-code-quote">{{ logEntry.request.body }}</div>
          </div>
          <div v-if="logEntry.hasOwnProperty('response')">
            <div class="">Status code: {{ logEntry.response.status_code }}</div>
            <div class="">Headers</div>
            <div class="fad-code-quote">{{ JSON.stringify(logEntry.response.headers, null, 2) }}</div>
            <div class="">Body</div>
            <div class="fad-code-quote">{{ logEntry.response.body }}</div>
          </div>
          <div v-if="logEntry.hasOwnProperty('logs')">
            <div>Logs</div>
            <div class="fad-code-quote" v-for="(log, index) in logEntry.logs" v-bind:key="index">
              <template v-if="log.hasOwnProperty('event') && log.event === 'error'">
                <div v-if="log.hasOwnProperty('event')">{{ log.event }}</div>
                <div v-if="log.hasOwnProperty('message')">{{ log.message }}</div>
                <div v-if="log.hasOwnProperty('error.kind')">{{ log['error.kind'] }}</div>
                <div v-if="log.hasOwnProperty('stack')">{{ log['stack'] }}</div>
                <template v-if="Object.keys(_(log).omit(['event', 'message', 'error.kind', 'stack']).value()).length > 0">
                  <div>Other Logs:</div>
                  <div>{{ JSON.stringify(_(log).omit(['event', 'message', 'error.kind', 'stack']).value()) }}</div>
                </template>
              </template>
              <div v-else>
                {{JSON.stringify(log)}}
              </div>
            </div>
          </div>
          <div>
            <div>Other</div>
            <div class="fad-code-quote">{{ JSON.stringify(_(logEntry).omit(['name', 'request', 'response', 'logs']).value()) }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import _ from "lodash";
  import moment from 'moment';

  export default {
    name: 'LogEntry',
    props: {
      logEntry: Object,
      tags: Array,
      activeTags: Object,
      isCollapsed: Boolean
    },
    data: function () {
      return {
        collapsed: this.isCollapsed,
      };
    },
    methods: {
      _: function (object) {
        return _(object);
      },
      _get: _.get,
      toggleCollapse: function () {
        this.collapsed = !this.collapsed;
      },
      toggleTag: function (tag) {
        this.$emit('toggleTag', tag);
      },
      expandLogEntryIfCollapsed: function () {
        if (this.collapsed) {
          this.collapsed = false;
        }
      },
    },
    computed: {
      collapseText: function () {
        if (this.collapsed) {
          return '\u203a';
        } else {
          return '\u2304';
        }
      },
    },
    filters: {
      tagPrefix: function (text, prefix) {
        if (text) {
          return prefix + ':' + text;
        }
      },
      timestamp: function (timestamp) {
        return moment(timestamp).format();
      },
    },
  }
</script>

<style scoped>
  .fad-log-entry-root {
    margin: 0 3px;
  }
  .fad-log-entry {
    display: flex;
    color: black;
    position: relative; /* Enables position:absolute below */
    /*border: 1px solid #aaa;*/
  }

  .fad-log-entry-collapse-gutter {
    padding: 10px 5px;
    flex: 0 0 20px;
    overflow: hidden;
    cursor: pointer;
    border-right: 1px solid #aaa;
  }

  .fad-log-entry-collapse-gutter div {
    overflow: hidden;
  }

  .fad-log-entry-collapse-gutter-icon {
    cursor: pointer;
    font-size: 9px;
  }

  .fad-log-entry-collapse-gutter:focus {
    outline-offset: 1px;
    outline: 1px dotted #1d1a65;
  }

  .fad-log-entry-content {
    outline: 0;
    flex-grow: 1;
    overflow-x: auto;
    overflow-y: hidden;
    white-space: pre-wrap;
    overflow-wrap: break-word;
    word-break: break-all;
    padding: 5px;
  }
  .fad-log-entry-content > .fad-log-entry-collapsed-shadow {
    margin: 0 -5px;
  }
  .fad-log-entry-header {
    margin: 0 -5px;
    border-bottom: 1px solid #aaa;
    padding: 2px 5px;
  }

  .fad-log-entry-tags {
    padding: 0 0 5px;
  }

  .fad-log-entry-code {
    font-family: "Fira Mono", monospace;
    font-size: 12px;
  }

  .fad-log-entry-collapsed {
    overflow: hidden;
  }
  .fad-log-entry-collapsed-shadow {
    display: none;
  }
  .fad-log-entry-collapsed .fad-log-entry-collapsed-shadow {
    position: absolute;
    display: block;
    height: 45px;
    bottom: 0;
    width: 100%;
    opacity: 50%;
    /*background: linear-gradient(0deg, rgba(0, 0, 0, 0.48) 0%, rgba(0, 0, 0, 0.24) 33%, rgba(0, 0, 0, 0.06) 66%, rgba(0, 0, 0, 0) 100%);*/
    background: linear-gradient(0deg, rgba(0, 0, 0, 0.48) 0%, rgba(0, 0, 0, 0.24) 16%, rgba(0, 0, 0, 0.06) 32%, rgba(0, 0, 0, 0) 48%);
    background-position-y: 1px;
    background-repeat: no-repeat;
    border-bottom: 1px dashed black;
  }

  .fad-log-entry-collapsed .fad-log-entry-body {
    max-height: 40px;
  }

  .fad-log-entry-toggleable-tag {
    cursor: pointer;
  }

  .fad-log-entry-toggleable-tag:focus {
    outline-offset: 1px;
    outline: 1px dotted #1d1a65;
  }

  .fad-log-entry-collapsed-shadow {
    cursor: pointer;
  }
  .badge {
    margin: 1px;
  }
  .fad-log-entry-filter-tag-active {
    background-color: #0594ea;
  }
  .fad-code-quote {
    margin-left: 10px;
    padding-left: 10px;
    border-left: 2px solid grey;
  }
</style>
