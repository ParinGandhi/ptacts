<template>
  <div class="fad-login">
    <div class="fad-login-banner">
      <img src="../../../public/hcgov-logo-api-dashboard.svg" alt="Logo"/>
    </div>
    <div style="margin: auto;width:100%; height:100%;text-align:center;">
      <v-sheet style="background-color: #055072;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);" class="pa-3">
          <v-skeleton-loader
            class="mx-auto custom-skeleton-btn-width"
            max-width="470"
            width="470"
            type="button@4"
          ></v-skeleton-loader>
      </v-sheet>
    </div>
  </div>
</template>

<script>
  import _ from 'lodash';
  import {redirectToIndex} from "../../utils/RedirectToIndex";

  export default {
    name: 'Login',
    data: function () {
      return {
        screen: 'login',
        screens: {
          login: 'login',
        },
        resourceUrlsPromise: fetch('/resourceUrls.json').then(response => response.json())
      }
    },
    created() {
      if (sessionStorage.getItem('accessToken') && sessionStorage.getItem('idToken')) {
        window.location.href = '/menu.html';
        return
      }
      var idToken = this.getParameterByName("id_token");
      var accessToken = this.getParameterByName("access_token");
      var cognitoError = this.getParameterByName("error");

      const urlParams = new URLSearchParams(window.location.search);
      const userlogout = urlParams.get('userlogout');
      if(!userlogout && !idToken) {
          redirectToIndex()
      } else if (cognitoError !== null && cognitoError !== "") {
          console.log(this.getParameterByName("error_description"));
          setTimeout(redirectToIndex, 3000)
      } else {
          if (idToken === null || idToken === "") {
            this.loginUser();
          } else {
            sessionStorage.setItem('accessToken', accessToken)
            sessionStorage.setItem('idToken', idToken)
            window.location.href = '/menu.html';
          }
      }
    },
    methods: {
      loginUser() { 
        this.resourceUrlsPromise
        .then(env => {
          window.location.href = env.login
        })
      },
      getParameterByName(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[[]]/g, "\\$&");
        var regex = new RegExp("[?#&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
      }
    }
  }
</script>

<style>
  .custom-skeleton-btn-width .v-skeleton-loader__button{
    width: 470px !important;
  }
</style>
<style scoped>
  .fad-login {
    background-color: #055072;
    color: #CFE2EA;
    width: 100%;
    height: 100%;
  }

  .fad-login-banner {
    background-color: white;
    width: 100%;
    text-align: center;
  }

  .fad-login-banner img {
    margin: 30px 0;
    width: 400px;
  }
  
  h1 {
    padding-bottom: 15px;
  }

  label {
    width: 100%;
  }
</style>
