import 'bootstrap/dist/css/bootstrap.css'

import { createApp, h } from 'vue'
import jQuery from 'jquery'
window.$ = window.jQuery = jQuery

// import Vue from 'vue'
import App from './App.vue'

// Vue.config.productionTip = false

// new Vue({
//   render: h => h(App),
// }).$mount('#app')

const app = createApp({
  render: ()=>h(App)
})
// app.render(h => h(App))
app.mount('#app')