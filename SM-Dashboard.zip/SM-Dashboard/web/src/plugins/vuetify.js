import '@mdi/font/css/materialdesignicons.css'
// import Vue from 'vue'
// import Vuetify from 'vuetify/lib'
import { createVuetify } from 'vuetify/lib/framework.mjs'
import 'vuetify/styles'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'
import { defaults as vuetifyDefaults } from 'vuetify';


// Vue.use(Vuetify)

// const opts = {
//   theme: { dark: false },
//   icons: {
//    iconfont: 'mdi'
//   }
// }
// export default new Vuetify(opts)

export default createVuetify({
  ssr: true,
  components,
  directives,
  defaults: vuetifyDefaults,
  opts: {
      theme: { dark: false },
      icons: {
       iconfont: 'mdi'
      }
    }
})
