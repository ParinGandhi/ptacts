# FFE API Dashboard Backend

## Deployment

First, install dependencies:
```
npm install
```

Then, bundle the application:
```
npm pack
```

Then, export the correct environment variables, and execute:
```
./deploy.sh
```

The deploy script will print an error and exit before deploying if one of the required environment variables is not defined.
