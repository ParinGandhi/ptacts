#!/usr/bin/env bash

# Strict mode; prevent deployment with missing variable
set -euo pipefail
set -x

export FAD_ENV_NAME="$FAD_ENV_NAME" # Like POC or Prod
export FAD_ENV_TYPE="$FAD_ENV_TYPE" # Like poc or prod
export FAD_API_ALLOW_IPS_CIDR_BLOCKS="$FAD_API_ALLOW_IPS_CIDR_BLOCKS" # Comma-separated strings. Like "10.0.1.2","10.23.45.0/24"
export FAD_LAMBDA_ROLE="$FAD_LAMBDA_ROLE" # Like arn:aws:iam::000000000000:role/lambda-role
export FAD_LAMBDA_ARTIFACT_BUCKET="$FAD_LAMBDA_ARTIFACT_BUCKET" # Like fad-poc-lambda
export FAD_LAMBDA_REGION="${FAD_LAMBDA_REGION:-us-east-1}" # Like us-east-1
export FAD_COGNITO_POOL_ID="$FAD_COGNITO_POOL_ID" # Like us-east-1_CcCcCcCcC
export FAD_COGNITO_APP_CLIENT_ID="$FAD_COGNITO_APP_CLIENT_ID" # Like 10101010101010101010101010
export FAD_DYNAMODB_TABLE_SERVICES="$FAD_DYNAMODB_TABLE_SERVICES" # Like sm_dashboard_poc_services
export FAD_DYNAMODB_TABLE_LOGS="$FAD_DYNAMODB_TABLE_LOGS" # Like sm_dashboard_poc_logs
export FAD_CORS_ALLOW_ORIGIN="$FAD_CORS_ALLOW_ORIGIN" # Like *
export FAD_CORS_ALLOW_HEADERS="$FAD_CORS_ALLOW_HEADERS" # Like *
export FAD_CORS_EXPOSE_HEADERS="$FAD_CORS_EXPOSE_HEADERS" # Like *
export FAD_SSM_API_KEY_FORMAT="$FAD_SSM_API_KEY_FORMAT" # Like /smdashboard/poc/apiKey/%s
export FAD_VPC_SECURITY_GROUP_IDS="${FAD_VPC_SECURITY_GROUP_IDS}" # Comma-separated strings. Like "sg-00000000000000000"
export FAD_VPC_SUBNET_IDS="${FAD_VPC_SUBNET_IDS}" # Comma-separated strings. Like "subnet-00000000"
export FAD_TL_BUCKET_NAME="${FAD_TL_BUCKET_NAME}" # Like e1-dev-tx-log-processed
export FAD_TL_DIRECTORY="${FAD_TL_DIRECTORY}" # Like processed
export FAD_SSM_OAUTH_FORMAT="$FAD_SSM_OAUTH_FORMAT" # Like /smdashboard/poc/oauth/%s

fad_env_name_lowercase="$(printf %s "$FAD_ENV_NAME" | tr '[:upper:]' '[:lower:]')"
package_template_file="api-dashboard-package.${fad_env_name_lowercase}.template"
deploy_template_file="build/api-dashboard-deploy.${fad_env_name_lowercase}.yaml"
stack_name="api-dashboard-${fad_env_name_lowercase}"

mkdir -p build

envsubst $'
$FAD_ENV_NAME
$FAD_ENV_TYPE
$FAD_API_ALLOW_IPS_CIDR_BLOCKS
$FAD_LAMBDA_ROLE
$FAD_COGNITO_POOL_ID
$FAD_COGNITO_APP_CLIENT_ID
$FAD_DYNAMODB_TABLE_SERVICES
$FAD_DYNAMODB_TABLE_LOGS
$FAD_CORS_ALLOW_ORIGIN
$FAD_CORS_ALLOW_HEADERS
$FAD_CORS_EXPOSE_HEADERS
$FAD_SSM_API_KEY_FORMAT
$FAD_VPC_SECURITY_GROUP_IDS
$FAD_VPC_SUBNET_IDS
$FAD_TL_BUCKET_NAME
$FAD_TL_DIRECTORY
$FAD_SSM_OAUTH_FORMAT
' <serverless.template.envsubst.json >"$package_template_file"

aws cloudformation package --template-file "$package_template_file" --s3-bucket "$FAD_LAMBDA_ARTIFACT_BUCKET" --output-template-file "$deploy_template_file"
aws cloudformation deploy --template-file "$deploy_template_file" --stack-name "$stack_name" --capabilities CAPABILITY_IAM --region "$FAD_LAMBDA_REGION"
aws cloudformation describe-stacks --stack-name "$stack_name" --region "$FAD_LAMBDA_REGION"
