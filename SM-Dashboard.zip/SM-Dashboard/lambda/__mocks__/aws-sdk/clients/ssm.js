
const getParameterFN = jest.fn().mockImplementation((query) => {
    let param1 = query
    return {
        promise: jest.fn().mockReturnValue(Promise.resolve({
            Parameter: {
                Value: data[param1['Name']]
            }
        }))
    }
});

class SSM {
    getParameter = getParameterFN
};

module.exports.SSM = SSM

const data = {
    "/smdashboard/POC/allowed/environments": "test,test0,test1,test2,test3,test4,test5",
    "/smdashboard/POC/capabilities/api_request":
    '{"allowedRoles":["APP_CONFIG_MANAGEMENT_RO","APP_CONFIG_MANAGEMENT_WO","API_INVOKE_RO"]}'
}
