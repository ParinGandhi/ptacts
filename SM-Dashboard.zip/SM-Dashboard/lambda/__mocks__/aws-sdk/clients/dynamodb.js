let _ = require("lodash")

const putFn = jest.fn().mockImplementation(() => ({
    promise: () => {
        return Promise.resolve(true)
    }
}));

const updateFn = jest.fn().mockImplementation((query) => {
    let param1 = query
    if (param1.Key.id == undefined)
    {
      return {
        promise: jest.fn().mockReturnValue(Promise.reject(false))
    }}
    else {
      return {
        promise: jest.fn().mockReturnValue(Promise.resolve(true))
    }
    }
  });

const getFn = jest.fn().mockImplementation((query) => {
    let param1 = query
    return {
        promise: jest.fn().mockReturnValue(Promise.resolve(
            data[resolveParamForDataKey(param1)]
        ))
    }
  });

const scanFn = jest.fn().mockImplementation((query) => {
    let param1 = query
    return {
        promise: jest.fn().mockReturnValue(Promise.resolve(
            data[resolveParamForDataKey(param1)]
        ))
    }
});
const queryFn = jest.fn().mockImplementation((query) => {
    let param1 = query
    return {
        promise: jest.fn().mockReturnValue(Promise.resolve(
            data[resolveParamForDataKey(param1)]
        ))
    }
});

class DocumentClient {
    get = getFn;
    put = putFn;
    scan = scanFn; 
    query = queryFn; 
    update = updateFn; 
}

const DynamoDB = {
    DocumentClient
};


function resolveParamForDataKey(param) {
    if (_.isEqual(param, {
        "TableName": "sm_dashboard_poc_services",
        "ProjectionExpression": "application, service, #pt, template, environments, allowed_roles",
        "FilterExpression": "#st = :a_s",
        "ExpressionAttributeNames": {
            "#st": "service_type",
            "#pt": "path"
        },
        "ExpressionAttributeValues": {
            ":a_s": "api_service"
        }
    })) {
        return "allServices"
    } else if (_.isEqual(param, {
        "TableName": "sm_dashboard_poc_services",
        "ProjectionExpression": "application, service, #md, #pt, root_url, template, #st, environments, legend, notes, filtered_values, allowed_roles, label",
        "FilterExpression": "#st = :a_s",
        "ExpressionAttributeNames": {
            "#st": "service_type",
            "#pt": "path",
            "#md": "method"
        },
        "ExpressionAttributeValues": {
            ":a_s": "ref_data_service"
        }
    })) {
        return "refServices"
    } else if (_.isEqual(param, {
        "TableName": "sm_dashboard_poc_services",
        "IndexName": "user-logType_creationDateTime-index",
        "KeyConditionExpression": '#u = :user AND begins_with(logType_creationDateTime, :log_type)',
        "ExpressionAttributeNames": {
            '#u': "user"
        },
        "ExpressionAttributeValues": {
            ':user': "JohnDoe",
            ':log_type': "api_request"
        },
        "Limit": 20,
        "ScanIndexForward": "false"
    })) {
        console.log("returning correctly");
        return "queryHistory"
    } else if (_.isEqual(param, {
        "TableName": "sm_dashboard_poc_services",
        "Key": {
            "application": "DSRS",
            "service": "Get Document Metadata"
        }
    })) {
        return "getDocumentMetadata"
    } else if (_.isEqual(param, {
        "TableName": "sm_dashboard_poc_services",
        "ProjectionExpression": "application, service, s3_bucket_name, #st, environments, allowed_roles",
        "FilterExpression": "#st = :a_s",
        "ExpressionAttributeNames": {
            "#st": "service_type"
        },
        "ExpressionAttributeValues": {
            ":a_s": "app_config_management_request"
        }
    })) {
        return "allAppConfigServices"
    } else {
        console.log("key not found")
        return "Key Not Found"
    }
}

const data = {
    "allServices": {
        "Items": [
            {
                "service": "Get Benchmark Plans",
                "environments": [
                    {
                        "env": "test0",
                        "label": "Test 0"
                    },
                    {
                        "env": "test1",
                        "label": "Test 1"
                    },
                    {
                        "env": "test2",
                        "label": "Test 2"
                    },
                    {
                        "env": "test3",
                        "label": "Test 3"
                    },
                    {
                        "env": "test4",
                        "label": "Test 4"
                    },
                    {
                        "env": "test5",
                        "label": "Test 5"
                    }
                ],
                "application": "EE",
                "path": "/ee-rest/v1/plans/get-benchmark-plans",
                "template": {
                    "body": "{ \"benchmarkCriteria\":[{ \"familyRelationships\": <%= JSON.stringify(familyRelationships) %>,\"legalRelationships\": <%= JSON.stringify(legalRelationships) %>,\"insuranceApplicationIdentifier\": <%= JSON.stringify(insuranceApplicationIdentifier) %>,\"members\": <%= JSON.stringify(members) %>,\"groupCoverageEffectiveStartDate\": <%= JSON.stringify(groupCoverageEffectiveStartDate) %>}]}",
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "role-Id: <%= roleId %>",
                        "<%= partnerId ? \"partner-id: \" + partnerId : \"\"%>",
                        "user-Id: <%= userId %>",
                        "Content-Type:application/json",
                        "x-correlation-id: <%= correlationId %>"
                    ],
                    "formSchema": [
                        {
                            "default": "FFM_SES",
                            "id": "sourceSystemName",
                            "title": "Source System Name",
                            "type": "select",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "SES",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": false
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "correlationId",
                            "type": "correlationId",
                            "title": "X-Correlation ID",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application Identifier",
                            "required": true
                        },
                        {
                            "id": "groupCoverageEffectiveStartDate",
                            "type": "string",
                            "title": "Group Coverage Effective Start Date",
                            "required": true
                        },
                        {
                            "item": {
                                "type": "object",
                                "title": "familyRelationships",
                                "items": [
                                    {
                                        "type": "string",
                                        "title": "Subordinate Member",
                                        "id": "subordinateMember"
                                    },
                                    {
                                        "type": "string",
                                        "title": "Relationship Type",
                                        "id": "relationshipType"
                                    },
                                    {
                                        "type": "string",
                                        "title": "Superordinate Member",
                                        "id": "superordinateMember"
                                    }
                                ],
                                "required": true
                            },
                            "id": "familyRelationships",
                            "type": "array",
                            "title": "familyRelationships",
                            "required": true
                        },
                        {
                            "item": {
                                "type": "object",
                                "title": "legalRelationships",
                                "items": [
                                    {
                                        "type": "string",
                                        "title": "Subordinate Member",
                                        "id": "subordinateMember"
                                    },
                                    {
                                        "type": "string",
                                        "title": "Relationship Type",
                                        "id": "relationshipType"
                                    },
                                    {
                                        "type": "string",
                                        "title": "Superordinate Member",
                                        "id": "superordinateMember"
                                    }
                                ],
                                "required": true
                            },
                            "id": "legalRelationships",
                            "type": "array",
                            "title": "legalRelationships",
                            "required": true
                        },
                        {
                            "item": {
                                "type": "object",
                                "title": "Members",
                                "items": [
                                    {
                                        "type": "string",
                                        "title": "Application Member Identifier",
                                        "id": "applicationMemberIdentifier"
                                    },
                                    {
                                        "type": "boolean",
                                        "title": "Contact Requesting Coverage Indicator",
                                        "id": "contactRequestingCoverageIndicator"
                                    },
                                    {
                                        "type": "string",
                                        "title": "Sex",
                                        "id": "sex"
                                    },
                                    {
                                        "type": "string",
                                        "title": "Benchmark Type",
                                        "id": "benchmarkType"
                                    },
                                    {
                                        "id": "residencyAddress",
                                        "type": "object",
                                        "title": "Residency Address",
                                        "items": [
                                            {
                                                "type": "string",
                                                "title": "Residency Address Source Type",
                                                "id": "residencyAddressSourceType"
                                            },
                                            {
                                                "type": "string",
                                                "title": "Street Name 1",
                                                "id": "streetName1"
                                            },
                                            {
                                                "default": "null",
                                                "id": "streetName2",
                                                "type": "string",
                                                "title": "Street Name 2"
                                            },
                                            {
                                                "type": "string",
                                                "title": "State Code",
                                                "id": "stateCode"
                                            },
                                            {
                                                "type": "string",
                                                "title": "City Name",
                                                "id": "cityName"
                                            },
                                            {
                                                "type": "string",
                                                "title": "Zip Code",
                                                "id": "zipCode"
                                            },
                                            {
                                                "type": "string",
                                                "title": "County Name",
                                                "id": "countyName"
                                            },
                                            {
                                                "type": "string",
                                                "title": "County Fips Code",
                                                "id": "countyFipsCode"
                                            }
                                        ],
                                        "required": true
                                    },
                                    {
                                        "type": "string",
                                        "title": "Birth Date",
                                        "id": "birthDate"
                                    },
                                    {
                                        "type": "string",
                                        "title": "Coverage Effective Start Date",
                                        "id": "coverageEffectiveStartDate"
                                    }
                                ],
                                "required": true
                            },
                            "id": "members",
                            "type": "array",
                            "title": "members",
                            "required": true
                        }
                    ]
                }
            },
            {
                "service": "Get Enrollments",
                "environments": [
                    {
                        "env": "test0",
                        "label": "Test 0"
                    },
                    {
                        "env": "test1",
                        "label": "Test 1"
                    },
                    {
                        "env": "test2",
                        "label": "Test 2"
                    },
                    {
                        "env": "test3",
                        "label": "Test 3"
                    },
                    {
                        "env": "test4",
                        "label": "Test 4"
                    },
                    {
                        "env": "test5",
                        "label": "Test 5"
                    }
                ],
                "application": "IES",
                "path": "/v1/enrollments?<%= field %>=<%= input %>",
                "template": {
                    "headers": [
                        "source-system-name: <%= sourceSystemName %>",
                        "roleId: <%= roleId %>",
                        "<%= partnerId ? \"partner-id:\" + partnerId : \"\"%>",
                        "user-id: <%= userId %>"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "default": "default",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "partnerId",
                            "type": "string",
                            "title": "Partner ID",
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "id": "field",
                            "type": "select",
                            "title": "Search By",
                            "items": [
                                "exchangeAssignedPolicyId",
                                "appId"
                            ],
                            "required": true
                        },
                        {
                            "id": "input",
                            "type": "string",
                            "title": "Input",
                            "required": true
                        }
                    ]
                }
            },
            {
                "service": "SVI Information",
                "environments": [
                    {
                        "env": "test0",
                        "label": "Test 0"
                    },
                    {
                        "env": "test1",
                        "label": "Test 1"
                    },
                    {
                        "env": "test2",
                        "label": "Test 2"
                    },
                    {
                        "env": "test3",
                        "label": "Test 3"
                    },
                    {
                        "env": "test4",
                        "label": "Test 4"
                    },
                    {
                        "env": "test5",
                        "label": "Test 5"
                    }
                ],
                "application": "EE-PC2",
                "path": "/ee-rest/api-auth/en_US/SepVerificationApi/v1/ffmRetrieveSVIInformation",
                "template": {
                    "body": "{\"insuranceApplicationIdentifier\": <%= insuranceApplicationIdentifier %>}",
                    "headers": [
                        "roleId: <%= roleId %>",
                        "source-system-name: <%= sourceSystemName %>",
                        "user-Id: <%= userId %>",
                        "Content-Type: application/json"
                    ],
                    "formSchema": [
                        {
                            "id": "sourceSystemName",
                            "type": "select",
                            "title": "Source System Name",
                            "items": [
                                "FFM_SM",
                                "FFM_EE",
                                "FFM_MCR",
                                "FFM_DSRS",
                                "FFM_IES",
                                "FFM_SES",
                                "FFM_PM",
                                "FFM_CORRESPONDENCE",
                                "NGD",
                                "ESS",
                                "DSH",
                                "APP3.0",
                                "CERRS",
                                "ESDCU",
                                "EACMS"
                            ],
                            "required": true
                        },
                        {
                            "id": "userId",
                            "type": "string",
                            "title": "User ID",
                            "required": true
                        },
                        {
                            "default": "SES",
                            "id": "roleId",
                            "type": "string",
                            "title": "Role ID",
                            "required": true
                        },
                        {
                            "id": "insuranceApplicationIdentifier",
                            "type": "string",
                            "title": "Insurance Application ID",
                            "required": true
                        }
                    ]
                }
            }
        ],
        "Count": 3,
        "ScannedCount": 50
    },
    "refServices": {
        "Items": [
            {
                "service": "AB Search Toggle",
                "allowed_roles": [
                    "REF_DATA_BROWSING_RO",
                    "REF_DATA_BROWSING_WO"
                ],
                "path": "/FindPersonNgAccessEnablement",
                "root_url": "https://<%=env%>.healthcare.gov/base-rest/global/en_US/ReferenceCode",
                "template": {
                    "headers": [],
                    "formSchema": []
                },
                "notes": [
                    "Currently set to false (OFF) in production.",
                    "When OFF, the search is routed through Legacy Person Search, otherwise SES API."
                ],
                "environments": [
                    {
                        "env": "test",
                        "env_cookies": "/smdashboard/poc0/cookies",
                        "label": "Test 0"
                    },
                    {
                        "env": "aws-test1",
                        "env_cookies": "/smdashboard/poc1/cookies",
                        "label": "Test 1"
                    },
                    {
                        "env": "test2",
                        "env_cookies": "/smdashboard/poc2/cookies",
                        "label": "Test 2"
                    },
                    {
                        "env": "test3",
                        "env_cookies": "/smdashboard/poc3/cookies",
                        "label": "Test 3"
                    },
                    {
                        "env": "test5",
                        "env_cookies": "/smdashboard/poc5/cookies",
                        "label": "Test 5"
                    }
                ],
                "application": "EE",
                "filtered_values": [
                    "codeGroup.referenceTypeName",
                    "value"
                ],
                "service_type": "ref_data_service",
                "method": "GET",
                "legend": [
                    "false=OFF",
                    "true=ON"
                ]
            },
            {
                "service": "Custom Entry",
                "path": "/<%=customEntry%>",
                "root_url": "https://<%=env%>.healthcare.gov/base-rest/global/en_US/ReferenceCode",
                "template": {
                    "headers": [],
                    "formSchema": [
                        {
                            "id": "customEntry",
                            "type": "string",
                            "title": "Custom Params",
                            "required": true
                        }
                    ]
                },
                "environments": [
                    {
                        "env": "test",
                        "env_cookies": "/smdashboard/poc0/cookies",
                        "label": "Test 0"
                    },
                    {
                        "env": "aws-test1",
                        "env_cookies": "/smdashboard/poc1/cookies",
                        "label": "Test 1"
                    },
                    {
                        "env": "test2",
                        "env_cookies": "/smdashboard/poc2/cookies",
                        "label": "Test 2"
                    },
                    {
                        "env": "test3",
                        "env_cookies": "/smdashboard/poc3/cookies",
                        "label": "Test 3"
                    },
                    {
                        "env": "test5",
                        "env_cookies": "/smdashboard/poc5/cookies",
                        "label": "Test 5"
                    }
                ],
                "application": "EE",
                "filtered_values": [
                    "codeGroup.referenceTypeName",
                    "value"
                ],
                "service_type": "ref_data_service",
                "method": "GET"
            },
            {
                "service": "Date Shift",
                "path": "/AnnualOpenEnrollmentPeriodDates/<%=oePeriod%>",
                "root_url": "https://<%=env%>.healthcare.gov/base-rest/global/en_US/ReferenceCode",
                "template": {
                    "headers": [],
                    "formSchema": [
                        {
                            "id": "oePeriod",
                            "type": "select",
                            "title": "OE period",
                            "items": [
                                "2014",
                                "2015",
                                "2016",
                                "2017",
                                "2018",
                                "2019",
                                "2020",
                                "2021"
                            ],
                            "required": true
                        }
                    ]
                },
                "notes": [
                    "E.g.\"01-NOV-2020:00:00:00|16-DEC-2020:02:59:59\"",
                    "Specifies OE period for 2020"
                ],
                "environments": [
                    {
                        "env": "test",
                        "env_cookies": "/smdashboard/poc0/cookies",
                        "label": "Test 0"
                    },
                    {
                        "env": "aws-test1",
                        "env_cookies": "/smdashboard/poc1/cookies",
                        "label": "Test 1"
                    },
                    {
                        "env": "test2",
                        "env_cookies": "/smdashboard/poc2/cookies",
                        "label": "Test 2"
                    },
                    {
                        "env": "test3",
                        "env_cookies": "/smdashboard/poc3/cookies",
                        "label": "Test 3"
                    },
                    {
                        "env": "test5",
                        "env_cookies": "/smdashboard/poc5/cookies",
                        "label": "Test 5"
                    }
                ],
                "application": "EE",
                "filtered_values": [
                    "codeGroup.referenceTypeName",
                    "value"
                ],
                "service_type": "ref_data_service",
                "method": "GET",
                "legend": [
                    "Inside OE if today's date is between the start and end dates for this refdata."
                ]
            }
        ],
        "Count": 3,
        "ScannedCount": 50
    },
    "queryHistory": {
        "Items": [
            {
                "logType_creationDateTime": "api_request#2021-03-30T18:05:08.885Z",
                "response_time": 107.31748399999924,
                "request_formmodel": {
                    "sourceSystemName": "FFM_SM",
                    "partnerId": "1212",
                    "userId": "121212",
                    "dsrsId": "1212",
                    "roleId": "default"
                },
                "user": "JohnDoe",
                "response_status": 403,
                "request_headers": {
                    "partner-id": "1212",
                    "role-id": "default",
                    "source-system-name": "FFM_SM",
                    "user-id": "121212"
                },
                "url": "https://api.test0.dsrs-test.mp.cmscloud.local:8443/v1/document/1212",
                "response_headers": {
                    "date": "Tue, 30 Mar 2021 18:05:09 GMT",
                    "content-length": "386",
                    "server": "Layer7-API-Gateway",
                    "content-type": "application/json;charset=UTF-8",
                    "connection": "close"
                },
                "method": "GET",
                "service": "Get Document",
                "request_environment": "test0",
                "creationDateTime": "2021-03-30T18:05:08.885Z",
                "application": "DSRS",
                "request_body": null,
                "id": "76bdac50-9182-11eb-9615-21c10e909d19",
                "log_type": "api_request"
            },
            {
                "logType_creationDateTime": "api_request#2021-03-17T17:23:25.692Z",
                "request_formmodel": {
                    "sourceSystemName": "FFM_EE",
                    "correlationId": "dashboard-63e83e72-8745-11eb-88c8-65c49b297b39",
                    "partnerId": "123123123",
                    "userId": "123123123",
                    "roleId": "default",
                    "appId": "123123123123"
                },
                "user": "JohnDoe",
                "request_headers": {
                    "partner-id": "123123123",
                    "x-correlation-id": "dashboard-63e83e72-8745-11eb-88c8-65c49b297b39",
                    "role-id": "default",
                    "source-system-name": "FFM_EE",
                    "user-id": "123123123"
                },
                "url": "http://api.test3.ee-test.mp.cmscloud.local:8080/ee-rest/v1/exemptions?insuranceApplicationId=123123123123",
                "method": "GET",
                "service": "Get Exemptions",
                "request_environment": "test3",
                "creationDateTime": "2021-03-17T17:23:25.692Z",
                "application": "EE",
                "request_body": null,
                "id": "7b59fbc0-8745-11eb-abe6-3bf106980ede",
                "log_type": "api_request"
            },
            {
                "logType_creationDateTime": "api_request#2021-02-23T22:20:45.284Z",
                "response_time": 35.87448499997845,
                "request_formmodel": {
                    "coverageYear": null,
                    "roleId": "default",
                    "appId": "565656",
                    "sourceSystemName": "FFM_MCR",
                    "correlationId": "dashboard-30f45ac7-7625-11eb-a614-e715eb1cd419",
                    "partnerId": "343434",
                    "userId": "454545"
                },
                "user": "JohnDoe",
                "response_status": 400,
                "request_headers": {
                    "partner-id": "343434",
                    "x-correlation-id": "dashboard-30f45ac7-7625-11eb-a614-e715eb1cd419",
                    "source-system-name": "FFM_MCR",
                    "userid": "454545",
                    "roleid": "default"
                },
                "url": "https://api.test3.ses-test.mp.cmscloud.local:8443/v1/applications?linkedToAppId=565656&startCoverageYear=",
                "response_headers": {
                    "date": "Tue, 23 Feb 2021 22:20:45 GMT",
                    "x-correlation-id": "dashboard-30f45ac7-7625-11eb-a614-e715eb1cd419",
                    "content-length": "286",
                    "server": "Layer7-API-Gateway",
                    "content-type": "application/json",
                    "connection": "close"
                },
                "method": "GET",
                "service": "Get App by Coverage Year",
                "request_environment": "test3",
                "creationDateTime": "2021-02-23T22:20:45.284Z",
                "application": "SES",
                "request_body": null,
                "id": "5f7d3240-7625-11eb-bbe8-597984e44542",
                "log_type": "api_request"
            }
        ]
    },
    "getDocumentMetadata": {
        "Item": {
            "api_key_name": "FFM_SM",
            "service": "Get Document Metadata",
            "template": {
                "headers": [
                    "source-system-name: <%= sourceSystemName %>",
                    "role-Id: <%= roleId %>",
                    "<%= partnerId ? \"partner-id: \" + partnerId : \"\"%>",
                    "user-Id: <%= userId %>",
                    "Content-Type:application/json",
                    "x-correlation-id: <%= correlationId %>"
                ],
                "formSchema": [
                    {
                        "id": "sourceSystemName",
                        "type": "select",
                        "title": "Source System Name",
                        "items": [
                            "FFM_SM",
                            "FFM_EE",
                            "FFM_MCR",
                            "FFM_DSRS",
                            "FFM_IES",
                            "FFM_SES",
                            "FFM_PM",
                            "FFM_CORRESPONDENCE",
                            "NGD",
                            "ESS",
                            "DSH",
                            "APP3.0",
                            "CERRS",
                            "ESDCU",
                            "EACMS"
                        ],
                        "required": true
                    },
                    {
                        "default": "default",
                        "id": "roleId",
                        "type": "string",
                        "title": "Role ID",
                        "required": true
                    },
                    {
                        "id": "partnerId",
                        "type": "string",
                        "title": "Partner ID",
                        "required": true
                    },
                    {
                        "id": "userId",
                        "type": "string",
                        "title": "User ID",
                        "required": true
                    },
                    {
                        "id": "dsrsId",
                        "type": "string",
                        "title": "DSRS ID",
                        "required": true
                    }
                ]
            },
            "root_url": "https://api.poc.dsrs-test.mp.cmscloud.local:8443",
            "path": "/v1/metadata/<%=dsrsId%>",
            "path_regex": "^/v1/metadata/[a-zA-Z0-9_-]+$",
            "environments": [
                {
                    "env": "test0",
                    "label": "Test 0"
                },
                {
                    "env": "test1",
                    "label": "Test 1"
                },
                {
                    "env": "test2",
                    "label": "Test 2"
                },
                {
                    "env": "test3",
                    "label": "Test 3"
                },
                {
                    "env": "test4",
                    "label": "Test 4"
                },
                {
                    "env": "test5",
                    "label": "Test 5"
                }
            ],
            "application": "DSRS",
            "service_type": "api_service",
            "method": "GET"
        }
    },
    "allAppConfigServices": {
        "Items": [
            {
                "service": "Blue",
                "allowed_roles": [
                    "APP_CONFIG_MANAGEMENT_RO",
                    "APP_CONFIG_MANAGEMENT_RW"
                ],
                "environments": [
                    {
                        "env": "test0",
                        "label": "Test 0"
                    },
                    {
                        "env": "test1",
                        "label": "Test 1"
                    },
                    {
                        "env": "test2",
                        "label": "Test 2"
                    },
                    {
                        "env": "test3",
                        "label": "Test 3"
                    },
                    {
                        "env": "test4",
                        "label": "Test 4"
                    },
                    {
                        "env": "test5",
                        "label": "Test 5"
                    }
                ],
                "s3_bucket_name": "hc-ies-poc-blue-config",
                "application": "IES",
                "service_type": "app_config_management_request"
            },
            {
                "service": "Green",
                "allowed_roles": [
                    "APP_CONFIG_MANAGEMENT_RO",
                    "APP_CONFIG_MANAGEMENT_RW"
                ],
                "environments": [
                    {
                        "env": "test0",
                        "label": "Test 0"
                    },
                    {
                        "env": "test1",
                        "label": "Test 1"
                    },
                    {
                        "env": "test2",
                        "label": "Test 2"
                    },
                    {
                        "env": "test3",
                        "label": "Test 3"
                    },
                    {
                        "env": "test4",
                        "label": "Test 4"
                    },
                    {
                        "env": "test5",
                        "label": "Test 5"
                    }
                ],
                "s3_bucket_name": "hc-ies-poc-blue-config",
                "application": "IES",
                "service_type": "app_config_management_request"
            }
        ],
        "Count": 2,
        "ScannedCount": 50
    }
}
module.exports.DynamoDB = DynamoDB
