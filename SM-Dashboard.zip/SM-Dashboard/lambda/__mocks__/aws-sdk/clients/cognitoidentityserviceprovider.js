/* cognitoIdentityServiceProvider mock service
* @param { UserPoolId, Username}
* @return Congnito Group Names array
*
* @author mohamed.h.osman
*/

let _ = require("lodash")

const adminListGroupsForUserFn = jest.fn().mockImplementation((param) => {
    let data = {
      "johnDoe": [
        {GroupName: "API_INVOKE_RW"},
        {GroupName: "APP_CONFIG_MANAGEMENT_WO"},
        {GroupName: "APP_CONFIG_MANAGEMENT_RW"}
      ]}
    return {
        promise: jest.fn().mockReturnValue(Promise.resolve({
            Groups: data[param["Username"]]}))
    }
});

var dataResp, errResp;

const respondToAuthChallengeFn = jest.fn().mockImplementation((param, callback) => {
  if (_.isEqual(param, {
    ChallengeName: 'SOFTWARE_TOKEN_MFA', /* required */
    ClientId: "jestTEST1234", /* required */
    ChallengeResponses: {
        'USERNAME': "johnDoe",
        'SOFTWARE_TOKEN_MFA_CODE': "onetimepassword1234"
    },
    Session: "cognitosessionkey1234"
  })) {
      dataResp = {AuthenticationResult: {AccessToken: "accessToken"}}
    }
    else {
      errResp = {code: "FAILURE", message: "Invalid Input", stack: "Stack Trace Error"}
    }
    return callback(errResp,dataResp)
})

  const adminGetUserFn = jest.fn().mockImplementation((param, callback) => {
    let resp = {
            "johnDoe": {data: {UserStatus: "CONFIRMED", PreferredMfaSetting: "SOFTWARE_TOKEN_MFA"}, err: null},
            "no-mfa-username": {data: {UserStatus: "CONFIRMED"}, err:null},
            "invalid-username": {data: null, err: {message: "User does not exist."}},
            "not-in-pool-username": {data: null, err: {message: "Only radix 2, 4, 8, 16, 32 are supported"}},
          }
    if (resp[param.Username]!= undefined) {
      dataResp = resp[param.Username].data;
      errResp = resp[param.Username].err;
    }
    else {
      errResp = {message: "unkown error occurred"}
    }
    return callback(errResp, dataResp)
      });


class CognitoIdentityServiceProvider {
    adminListGroupsForUser = adminListGroupsForUserFn
    respondToAuthChallenge = respondToAuthChallengeFn
    adminGetUser = adminGetUserFn
    confirmForgotPassword = confirmForgotPasswordFn
    globalSignOut = globalSignOutFn
};

module.exports.CognitoIdentityServiceProvider = CognitoIdentityServiceProvider

const globalSignOutFn = jest.fn().mockImplementation((params, callback) => {
    let params2 = {"AccessToken":{"AccessToken":"123"}}
    if(JSON.stringify(params) === JSON.stringify(params2)){
        return callback(null, {"status": "SUCCESS", "statusCode": 200});
    } else {
        return callback({"status": "FAILURE"}, null);
    }
});

const confirmForgotPasswordFn = jest.fn().mockImplementation((params, callback) => {
    return callback(null, {"status": "SUCCESS", "statusCode": 200});
});
