/* s3 mock service
*
* @author mohamed.h.osman
*/
const zlib = require('zlib');

const getObjectFn = jest.fn().mockImplementation((query) => {
    let param1 = query
    let gzipBodyContent = zlib.gzipSync("this is the content of the file");
    if (param1.Bucket == "testBucket" && param1.Key == "testFile.test") {
    return {
        promise: jest.fn().mockReturnValue(Promise.resolve({
             AcceptRanges: "bytes",
             ContentLength: 3191,
             ContentType: "text/plain",
             ETag: "\"6805f2cfc46c0f04559748bb039d69ae\"",
             LastModified: "2021-03-10",
             Metadata: {
             },
             Body: gzipBodyContent ,
             TagCount: 2,
             VersionId: "null"
        }))//TODO add additional responses
    }}
    else {
      return {
          promise: jest.fn().mockReturnValue(Promise.reject("The specified bucket/key does not exist"))
    }}
});

const putObjectFn =   jest.fn().mockImplementation((query) => {
        let param2 = query
        return {
            promise: jest.fn().mockReturnValue(Promise.resolve({
               ETag: '"eTag123456789"',
               VersionId: "newVersionId1234"
         })  //TODO add additional responses
       )
     }
 });

 const listObjectsV2Fn =  jest.fn().mockImplementation((query) => {
    let param3 = query
    if (param3.Bucket == "testBucket" && param3.Prefix == "testDirectoryKey") {
         return {
             promise: jest.fn().mockReturnValue(Promise.resolve({
               Contents: [
                 {
                ETag: '"eTag123456789"',
                Key: "testFile.test",
                LastModified: "2021-03-10",
                Size: 11,
                StorageClass: "STANDARD"
          }],
              IsTruncated: true,
              KeyCount: 2,
              MaxKeys: 2,
              Name: "testBucket",
              NextContinuationToken: "1w41l63U0xa8q7smH50vCxyTQqdxo69O3EmK28Bi5PcROI4wI/EyIJg==",
              CommonPrefixes: [
                {
                Prefix: "testDirectoryKey/"
                }]
              }
        )  //TODO add additional responses
        )
      }}
    else {
      return {
          promise: jest.fn().mockReturnValue(Promise.reject("The specified directoy/bucket does not exist"))
    }
  }});

class S3 {
  getObject = getObjectFn;
  putObject = putObjectFn;
  listObjectsV2 = listObjectsV2Fn;
}//TODO add additional functions

module.exports.S3 = S3
