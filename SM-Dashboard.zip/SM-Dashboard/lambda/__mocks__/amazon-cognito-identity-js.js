const authenticationDetails = require('amazon-cognito-identity-js/AuthenticationDetails');
const cognitoUserPool = require('amazon-cognito-identity-js/CognitoUserPool')
const cognitoUser = require('amazon-cognito-identity-js/CognitoUser');

const AuthenticationDetails  = authenticationDetails.AuthenticationDetails
const CognitoUserPool = cognitoUserPool.CognitoUserPool
const CognitoUser = cognitoUser.CognitoUser


module.exports.AuthenticationDetails = AuthenticationDetails
module.exports.CognitoUserPool = CognitoUserPool
module.exports.CognitoUser = CognitoUser
