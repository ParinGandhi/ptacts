const ssmClient = require('aws-sdk/clients/ssm');
const dynamoClient = require('aws-sdk/clients/dynamodb')
const cognitoIdentityServiceProviderClient = require('aws-sdk/clients/cognitoidentityserviceprovider');
const s3Client = require('aws-sdk/clients/s3')

const SSM  = ssmClient.SSM
const DynamoDB = dynamoClient.DynamoDB
const CognitoIdentityServiceProvider = cognitoIdentityServiceProviderClient.CognitoIdentityServiceProvider
const S3 = s3Client.S3

module.exports.DynamoDB = DynamoDB
module.exports.SSM = SSM
module.exports.CognitoIdentityServiceProvider = CognitoIdentityServiceProvider
module.exports.S3 = S3
