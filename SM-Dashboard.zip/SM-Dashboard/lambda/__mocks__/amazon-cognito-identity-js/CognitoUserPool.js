class CognitoUserPool {

  constructor(data) {
    const {
      UserPoolId,
      ClientId,
    } = data || {};
    if (!UserPoolId || !ClientId) {
      throw new Error('Both UserPoolId and ClientId are required.');
    }
  //  if (!/^[\w-]+_.+$/.test(UserPoolId)) {
  //    throw new Error('Invalid UserPoolId format.');
  //  }
    const region = UserPoolId.split('_')[0];

    this.userPoolId = UserPoolId;
    this.clientId = ClientId;
    this.getCurrentUser = jest.fn().mockReturnValue('cognitouserpool');
  }
}

module.exports.CognitoUserPool = CognitoUserPool;
