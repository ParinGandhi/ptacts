/* AuthenticationDetails mock service
*
* @author mohamed.h.osman
*/

class AuthenticationDetails {

  constructor(data) {
    const {
			Username,
			Password
		} = data || {};
		this.username = Username;
		this.password = Password;
	}

  getClientMetadata = jest.fn().mockImplementation(() => {
    if (this.username != 'invalid-username' && this.password != 'invalid-password')
    {
      return true
  }
    else {
      return false
  }
    });
 };

module.exports.AuthenticationDetails = AuthenticationDetails;
