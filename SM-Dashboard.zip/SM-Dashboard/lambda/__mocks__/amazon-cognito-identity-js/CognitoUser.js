/* CognitoUser mock service
*
* @author mohamed.h.osman
*/
const authenticateUserFn = jest.fn().mockImplementation((param, callback) => {
  if (param.getClientMetadata())
  {
    return callback.onSuccess({accessToken: {jwtToken: "accessToken"}})
}
  else
  {
    return callback.onFailure()
}
  });

  const verifySoftwareTokenFn = jest.fn().mockImplementation((param1, param2, callback) => {
    if (param1 != 'invlaid-secretcode')
    {
      return callback.onSuccess()
    }
    else {
      return callback.onFailure({name: "UNVERIFIED", message: "Invalid secret code"})
    }
    });

    const setUserMfaPreferenceFn = jest.fn().mockImplementation((param1, param2, callback) => {
        return callback()
      });

    //  const associateSoftwareTokenFn = jest.fn().mockImplementation();
    const associateSoftwareTokenFn = jest.fn().mockImplementation((callback) => {
        //return callback.associateSecretCode({SecretCode: "string", Session: "string"})
      return callback.associateSecretCode("MFA is not enabled for the user pool")
      });

class CognitoUser {

  constructor(data) {
    if (data == null || data.Username == null || data.Pool == null) {
      throw new Error('Username and pool information are required.');
    }

    this.username = data.Username || '';
    this.pool = data.Pool;
    this.Session = null;
}

  authenticateUser = authenticateUserFn;
  verifySoftwareToken = verifySoftwareTokenFn;
  setUserMfaPreference = setUserMfaPreferenceFn;
  associateSoftwareToken = associateSoftwareTokenFn;

};



module.exports.CognitoUser = CognitoUser;
