const changePassword = require('../../handlers/ChangePassword')
const handleSuccess = require("../../common/SuccessHandler")
const handleError = require("../../common/ErrorHandler")
let performPasswordChange = require("../../services/PerformPasswordChange")


describe('handlers', () => {
    beforeEach(() => {
        jest.fn().mockClear()
        process.env.FAD_COGNITO_POOL_ID = 'POOL_ID'
        process.env.FAD_COGNITO_APP_CLIENT_ID = "APP_CLIENT_ID"
    })
    it('Confirm password is changed successfully', () => {
        return expect(changePassword.handler(event)).resolves.toEqual(testResult)
    })
    afterEach(() => {
        delete process.env.FAD_COGNITO_POOL_ID;
        delete process.env.FAD_COGNITO_APP_CLIENT_ID
    });
})

let event = {
    "body": JSON.stringify({
        "username": "johnDoe",
        "oldPassword": "password1",
        "newPassword": "anewpassword"
    })
}

const changePasswordFN = jest.fn().mockImplementation((event) => {
    event.body = JSON.parse(event.body)

    let username = event.body.username;
    let oldPassword = event.body.oldPassword;
    let newPassword = event.body.newPassword;

    return performPasswordChange(username, oldPassword, newPassword)
        .then(handleSuccess)
        .catch(handleError)
});

const performPasswordChangeFN = jest.fn().mockImplementation((username, oldPassword, newPassword) => {
    const result = {
        "body": {
           "username": username,
           "oldPassword": oldPassword,
           "newPassword": newPassword
        }
    }
    console.log("hi: " +result)
    console.log("hi: " +JSON.stringify(result))
    return new Promise (async (resolve, reject) => {
        resolve(result)
    })
});

performPasswordChange = performPasswordChangeFN
changePassword.handler = changePasswordFN

const testResult = {"body": "{\"body\":{\"username\":\"johnDoe\",\"oldPassword\":\"password1\",\"newPassword\":\"anewpassword\"}}",
    "headers": {
        "Access-Control-Allow-Origin": undefined,
        "Access-Control-Expose-Headers": undefined,
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "Content-Type": "application/json",
        "Expires": "0",
        "Pragma": "no-cache",
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "SAMEORIGIN",
        "X-XSS-Protection": "1; mode=block",
    },
    "statusCode": 200,
}
