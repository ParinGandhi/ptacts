
const DashboardErrorResponse = require("../../common/DashboardErrorResponse")

describe('common', () => {

    test('Checking that a error response is handled correctly', () => {
        expect(new DashboardErrorResponse(606,"USER_DEFINED","User defined message")).toEqual({
            "message": "User defined message", "status": "USER_DEFINED", "statusCode": 606
        })
    })

    test('Checking that a 403 user access denied response is handled correctly', () => {
        expect(DashboardErrorResponse.standardResponses.USER_ACCESS_DENIED).toEqual({
            "message": "User access denied", "status": "UNAUTHORIZED", "statusCode": 403
        })
    })

    test('Checking that a 400 user not found response is handled correctly', () => {
        expect(DashboardErrorResponse.standardResponses.USER_NOT_FOUND).toEqual({
            "message": "Username is not found", "status": "USER_NOT_FOUND", "statusCode": 400
        })
    })

    test('Checking that a 400 invalid password response is handled correctly', () => {
        expect(DashboardErrorResponse.standardResponses.INVALID_PASSWORD).toEqual({
            "message": "Password is invalid, not met the password constraints", "status": "INVALID_PASSWORD", "statusCode": 400
        })
    })

    test('Checking that a 400 bad request response is handled correctly', () => {
        expect(DashboardErrorResponse.standardResponses.BAD_REQUEST).toEqual({
            "message": "Bad request", "status": "BAD_REQUEST", "statusCode": 400
        })
    })
})
