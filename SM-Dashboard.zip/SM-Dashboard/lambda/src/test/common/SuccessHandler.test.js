/* Unit Test for SuccessHandler class
 * FFMARCH-2898
 * @author mohamed.h.osman
 */
const successHandler = require('../../common/SuccessHandler')

describe('Success Handler', () => {
    test('a response is formed with successful status and 200 status code', () => {
        expect(successHandler({status:"successful"})).toStrictEqual({headers: {
                                                                                "Content-Type": "application/json",
                                                                                "Access-Control-Allow-Origin": process.env.FAD_CORS_ALLOW_ORIGIN,
                                                                                "Access-Control-Expose-Headers": process.env.FAD_CORS_EXPOSE_HEADERS,
                                                                                "Cache-Control": "no-cache, no-store, must-revalidate",
                                                                                "Pragma": "no-cache",
                                                                                "Expires": "0",
                                                                                "X-XSS-Protection": "1; mode=block",
                                                                                "X-Content-Type-Options": "nosniff",
                                                                                "X-Frame-Options": "SAMEORIGIN"
                                                                            },
                                                                            statusCode: 200,
                                                                            body: JSON.stringify({status:"successful"})
                                                                        })
          })

     test('a response is not formed with failed status and 500 status code', () => {
                  expect(successHandler({status:"successful"})).not.toStrictEqual({headers: {
                                                                                          "Content-Type": "application/json",
                                                                                          "Access-Control-Allow-Origin": process.env.FAD_CORS_ALLOW_ORIGIN,
                                                                                          "Access-Control-Expose-Headers": process.env.FAD_CORS_EXPOSE_HEADERS,
                                                                                          "Cache-Control": "no-cache, no-store, must-revalidate",
                                                                                          "Pragma": "no-cache",
                                                                                          "Expires": "0",
                                                                                          "X-XSS-Protection": "1; mode=block",
                                                                                          "X-Content-Type-Options": "nosniff",
                                                                                          "X-Frame-Options": "SAMEORIGIN"
                                                                                      },
                                                                                      statusCode: 500,
                                                                                      body: JSON.stringify({status:"failed"})
                                                                                  })
                    })
     })
