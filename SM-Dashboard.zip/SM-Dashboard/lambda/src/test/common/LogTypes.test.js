 /* Unit test for logTypes class
  * FFMARCH-2895
  * @author mohamed.h.osman
  */
const logType = require('../../common/LogTypes')

describe('Log Types exist', () => {
    test('api_request log type exists', () => {
        expect(logType).toHaveProperty('api_request')
        })
    test('ref_data_request log type exists', () => {
        expect(logType).toHaveProperty('ref_data_request')
            })
    test('transaction_log_search log type exists', () => {
        expect(logType).toHaveProperty('transaction_log_search')
            })
    test('login log type exists', () => {
        expect(logType).toHaveProperty('login')
            })
    test('app_config_management_request log type exists', () => {
        expect(logType).toHaveProperty('app_config_management_request')
                 })
    test('app_config_list_s3_folder log type exists', () => {
        expect(logType).toHaveProperty('app_config_list_s3_folder')
                })
    test('app_config_get_s3_object log type exists', () => {
        expect(logType).toHaveProperty('app_config_get_s3_object')
                })
    test('app_config_update_s3_object log type exists', () => {
        expect(logType).toHaveProperty('app_config_update_s3_object')
                })
         })

