const errorHandler = require('../../common/ErrorHandler')
const DashboardErrorResponse = require('../../common/DashboardErrorResponse')
const correlationId = 1;

describe('common', () => {
    test('Check if  error  is handled and correct response is returned with 500 status code', async () => {
        const error = new DashboardErrorResponse(500, "INTERNAL_SERVER_ERROR", "An internal server error occurred.");
        const errorResponse = await errorHandler(error, correlationId);
        expect(errorResponse).toEqual({
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": process.env.FAD_CORS_ALLOW_ORIGIN,
                "Access-Control-Expose-Headers": process.env.FAD_CORS_EXPOSE_HEADERS,
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0",
                "X-XSS-Protection": "1; mode=block",
                "X-Content-Type-Options": "nosniff",
                "X-Frame-Options": "SAMEORIGIN"
            },
            statusCode: error.statusCode,
            body: JSON.stringify(error),
        })
    })

    test('Check if  error  is handled and correct response is returned with 401 status code', async () => {
        const error = new DashboardErrorResponse(401, "INTERNAL_SERVER_ERROR", "An internal server error occurred.");
        const errorResponse = await errorHandler(error, correlationId);
        expect(errorResponse).toEqual({
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": process.env.FAD_CORS_ALLOW_ORIGIN,
                "Access-Control-Expose-Headers": process.env.FAD_CORS_EXPOSE_HEADERS,
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0",
                "X-XSS-Protection": "1; mode=block",
                "X-Content-Type-Options": "nosniff",
                "X-Frame-Options": "SAMEORIGIN"
            },
            statusCode: error.statusCode,
            body: JSON.stringify(error),
        })
    })
})
