const injectCorrelationId = require('../../services/InjectCorrelationId')

describe('services', () => {
    it('Confirm Correlation ID is injected', () => {
        let newRequestResults = injectCorrelationId(newRequest);
        //Check if a correlation ID was added
        if (newRequestResults['headers']['x-correlation-id']) {
            newRequestResults['headers']['x-correlation-id'] = "a valid correlation id"
        }
        return expect(newRequestResults).toEqual(testResult);
    })
})

const newRequest = {
     "application": "DSRS",
     "service": "Get Document Metadata",
     "environment": {
       "env": "test3",
       "label": "Test 3"
     },
     "environments": [
       {
         "env": "test0",
         "label": "Test 0"
       },
       {
         "env": "test1",
         "label": "Test 1"
       },
       {
         "env": "test2",
         "label": "Test 2"
       },
       {
         "env": "test3",
         "label": "Test 3"
       },
       {
         "env": "test4",
         "label": "Test 4"
       },
       {
         "env": "test5",
         "label": "Test 5"
       }
     ],
     "downstreamUrlPath": "/v1/metadata/123123123",
     "url": "https://api.test3.dsrs-test.mp.cmscloud.local:8443/v1/metadata/123123123",
     "method": "GET",
     "_userPath": "/v1/metadata/123123123",
     "_apiKeyName": "FFM_SM",
     "_validPathRegex": "^/v1/metadata/[a-zA-Z0-9_-]+$",
     "headers": {
       "source-system-name": "FFM_EE",
       "role-id": "default",
       "partner-id": "123123123",
       "user-id": "123123123"
     },
     "body": "",
     "path": "/v1/metadata/123123123",
     "formmodel": {
       "roleId": "default",
       "sourceSystemName": "FFM_EE",
       "partnerId": "123123123",
       "userId": "123123123",
       "dsrsId": "123123123"
     },
     "username": "johnDoe",
     "logid": "4dbf8170-93b2-11eb-b858-595507bffc3a"
}

const testResult = {
    "_apiKeyName": "FFM_SM",
    "_userPath": "/v1/metadata/123123123",
    "_validPathRegex": "^/v1/metadata/[a-zA-Z0-9_-]+$",
    "application": "DSRS",
    "body": "",
    "downstreamUrlPath": "/v1/metadata/123123123",
    "environment": {
        "env": "test3",
        "label": "Test 3"
    },
    "environments": [
        {
            "env": "test0",
            "label": "Test 0"
        },
        {
            "env": "test1",
            "label": "Test 1"
        },
        {
            "env": "test2",
            "label": "Test 2"
        },
        {
            "env": "test3",
            "label": "Test 3"
        },
        {
            "env": "test4",
            "label": "Test 4"
        },
        {
            "env": "test5",
            "label": "Test 5"
        }
    ],
    "formmodel": {
        "dsrsId": "123123123",
        "partnerId": "123123123",
        "roleId": "default",
        "sourceSystemName": "FFM_EE",
        "userId": "123123123"
    },
    "headers": {
        "partner-id": "123123123",
        "role-id": "default",
        "source-system-name": "FFM_EE",
        "user-id": "123123123",
        "x-correlation-id": "a valid correlation id"
    },
    "logid": "4dbf8170-93b2-11eb-b858-595507bffc3a",
    "method": "GET",
    "path": "/v1/metadata/123123123",
    "service": "Get Document Metadata",
    "url": "https://api.test3.dsrs-test.mp.cmscloud.local:8443/v1/metadata/123123123",
    "username": "johnDoe"
}
