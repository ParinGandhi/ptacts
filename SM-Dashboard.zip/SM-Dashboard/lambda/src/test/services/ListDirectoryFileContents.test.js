/* Unit Test for ListDirectoryFileContents.js
 * FFMARCH-3042
 * @author mohamed.h.osman
 */

const listDirectoryFileContents = require("../../services/ListDirectoryFileContents");


describe('Retrieves the contents of all files in an s3 directory', () => {
    beforeEach(() =>{
        jest.fn().mockClear()
        process.env.FAD_ENV_TYPE = 'POC'
        })
    it('This is the correct content of the file', () => {
      return  expect(listDirectoryFileContents(bucketName, directoryKey)).resolves.toStrictEqual(correctContent)
    })
    it('This is not the correct content of the file', () => {
      return  expect(listDirectoryFileContents(bucketName, directoryKey)).resolves.not.toStrictEqual(incorrectContent)
    })
    it('This bucket name does not exist', () => {
      return  expect(listDirectoryFileContents("",directoryKey)).rejects.toStrictEqual(noSuchBucket)
    })
    it('This directory key does not exist', () => {
      return  expect(listDirectoryFileContents(bucketName,"")).rejects.toStrictEqual(noSuchBucket)
    })
    afterEach(() => {
        delete process.env.FAD_ENV_TYPE;
    });
 })


bucketName = "testBucket"
directoryKey = "testDirectoryKey"
noSuchBucket= "The specified directoy/bucket does not exist"
correctContent = ["this is the content of the file"]
incorrectContent = ["this is not the content of the file"]
