/* Unit Test for LogRequest.js
 * FFMARCH-3043
 * @author mohamed.h.osman
 */

const logRequest = require("../../services/LogRequest");



describe('Logs a request to the database to keep track of user activity', () => {
    beforeEach(() =>{
        jest.fn().mockClear()
        process.env.FAD_DYNAMODB_TABLE_LOGS = "sm_dashboard_poc_services"
        })
    it('user activity first request is logged correctly as sent', () => {
      return  expect(logRequest(request1)).resolves.toStrictEqual(request1)
    })
    it('user activity second log request is logged correctly as sent', () => {
      return  expect(logRequest(request2)).resolves.toStrictEqual(request2)
    })
    it('user activity request 1 is not logged incorrectly as request 2', () => {
      return  expect(logRequest(request1)).resolves.not.toStrictEqual(request2)
    })
    it('Empty request will throw a TypeError', () => {
      return  expect(() => {logRequest({})}).toThrow(TypeError)
    })
    afterEach(() => {
        delete process.env.FAD_DYNAMODB_TABLE_LOGS;
    });
 })

request1 = {
  username: "johnDoe",
  application: "SES",
  environment:{
    env: "test"
  },
  service: "AB Search Toggle",
  url: "https://test.healthcare.gov/base-rest/global/en_US/ReferenceCode",
  method: "GET",
  headers: "request_headers",
  body: "request.body",
  formmodel: "request.formmodel"
}
request2 = {environment: {env: "test"}}
