/* Unit Test for PreAutenticate class
 * FFMARCH-3076
 * @author mohamed.h.osman
 */

const preAutenticate = require("../../services/PreAuthenticate");
const DashboardErrorResponse = require('../../common/DashboardErrorResponse');

describe('Performing pre authentication of cognito user', () => {
    beforeEach(() =>{
      jest.fn().mockClear()
        process.env.FAD_COGNITO_POOL_ID = 'us-east-1_jestTest'
        process.env.FAD_COGNITO_APP_CLIENT_ID = 'jestTEST1234'
          })
    it('Valid username and password is resolved with a success response', () => {
      return  expect(preAutenticate(username, password)).resolves.toStrictEqual(successfulResponse)
    })
    it('Invalid username is rejected with UNAUTHORIZED error response', () => {
      return  expect(preAutenticate(invalidUsername, password)).rejects.toStrictEqual(unauthorizedResponse)
    })
    it('Username not in pool is rejected with UNAUTHORIZED error response', () => {
      return  expect(preAutenticate(notInPoolUsername, password)).rejects.toStrictEqual(unauthorizedResponse)
    })
    it('Username with no MFA is rejected with UNAUTHORIZED error response', () => {
      return  expect(preAutenticate(usernameNoMFA, password)).rejects.toStrictEqual(mfaNotFoundResponse)
    })
    it('Unexpected or missing input is rejected with UNKNOWN error response', () => {
      return  expect(preAutenticate()).rejects.toStrictEqual(unknownErrordResponse)
    })
    afterEach(() => {
        delete process.env.FAD_COGNITO_POOL_ID;
        delete process.env.FAD_COGNITO_APP_CLIENT_ID;
    });
 })
//Inputs
const username = 'johnDoe'
const password = 'password1234'
const usernameNoMFA = 'no-mfa-username'
const invalidUsername = 'invalid-username'
const notInPoolUsername = 'not-in-pool-username'
//Expected Responses
const successfulResponse = {UserStatus: "CONFIRMED", PreferredMfaSetting: "SOFTWARE_TOKEN_MFA"}
const unauthorizedResponse = new DashboardErrorResponse(403, "UNAUTHORIZED", "Invalid username or password")
const mfaNotFoundResponse = new DashboardErrorResponse(401, "TOTP_SETUP_REQUIRED", "MFA is not enabled for the user pool")
const unknownErrordResponse = new DashboardErrorResponse(500, "UNKNOWN", "An error occurred")
