/* Unit Test for ListDirectory.js
 * FFMARCH-3042
 * @author mohamed.h.osman
 */

const listDirectory = require("../../services/ListDirectory");
const DashboardErrorResponse = require("../../common/DashboardErrorResponse")

describe('Lists the names of files and folders of a S3 buckts', () => {
    beforeEach(() =>{
        jest.fn().mockClear()
        process.env.FAD_ENV_TYPE = 'POC'
        })
    it('Correct File and Folder name is listed', () => {
      return  expect(listDirectory(request1, userName, bucketName)).resolves.toStrictEqual(listOfFilesFolders)
    })
    it('Incorrect File and Folder name is listed', () => {
      return  expect(listDirectory(request1, userName, bucketName)).resolves.not.toStrictEqual(incorrectListOfFilesFolders)
    })
    it('Files and Folders list is not empty', () => {
      return  expect(listDirectory(request1, userName, bucketName)).resolves.not.toStrictEqual([])
    })
    it('Error is produced when bucket name does not exist', () => {
      return  expect(listDirectory(request2, userName, bucketName)).rejects.toStrictEqual(DashboardErrorResponse.standardResponses.UNKNOWN)
    })
    afterEach(() => {
        delete process.env.FAD_ENV_TYPE;
    });
 })

 request1 = {
   "bucketName": "testBucket",
   "prefix": "testDirectoryKey",
   "service": "testService",
 }
 request2 = {
   "bucketName": "wrongBucket",
   "prefix": "",
   "service": "testService",
 }
userName = "johnDoe"

bucketName = "testBucket"

listOfFilesFolders = [
	{
		"fileExtension": ".test",
		"fileType": "test",
		"id": "testBucket/testFile.test",
		"lastModified": "2021-03-10",
		"name": "testFile.test",
		"prefix": "",
		"s3Key": "testFile.test",
		"serviceName": "testService",
		"size": 11
	},
	{
		"id": "testBucket/testDirectoryKey/",
		"lastModified": null,
		"name": "testDirectoryKey/",
		"prefix": "testDirectoryKey/",
		"serviceName": "testService",
		"size": 0,
		"subFolders": []
	}
]

incorrectListOfFilesFolders = [
	{
		"fileExtension": ".txt",
		"fileType": "txt",
		"id": "testBucket/wrongTestFile.txt",
		"lastModified": "2021-03-1",
		"name": "wrongTestFile.test",
		"prefix": "",
		"s3Key": "wrongTestFile.test",
		"serviceName": "testService",
		"size": 11
	},
	{
		"id": "wrongtestBucket/testDirectoryKey/",
		"lastModified": null,
		"name": "testDirectoryKey/",
		"prefix": "testDirectoryKey/",
		"serviceName": "testService",
		"size": 0,
		"subFolders": []
	}
]
