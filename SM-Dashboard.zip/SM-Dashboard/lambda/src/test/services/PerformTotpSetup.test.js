/* Unit Test for PerformTotpSetup class
 * FFMARCH-3076
 * @author mohamed.h.osman
 */

const performTotpSetup = require("../../services/PerformTotpSetup");
const DashboardErrorResponse = require('../../common/DashboardErrorResponse');

describe('Performing complete otp setup', () => {
    beforeEach(() =>{
    //  jest.setTimeout(30000);
      //  jest.fn().mockClear()
        process.env.FAD_COGNITO_POOL_ID = 'us-east-1_jestTest'
        process.env.FAD_COGNITO_APP_CLIENT_ID = 'jestTEST1234'
          })
    it('Valid username and password and secretcode is resolved with a success response', () => {
      return  expect(performTotpSetup(secretcode, username, password)).resolves.toStrictEqual(successfulResponse)
    })
    it('Invalid username is rejected with UNAUTHORIZED error response', () => {
      return  expect(performTotpSetup(secretcode, invalidUsername, password)).rejects.toStrictEqual(unauthorizedResponse)
    })
    it('Invalid password is rejected with UNAUTHORIZED error response', () => {
      return  expect(performTotpSetup(secretcode, username, invalidPassword)).rejects.toStrictEqual(unauthorizedResponse)
    })
    it('Invalid password is rejected with UNVERIFIED error response', () => {
      return  expect(performTotpSetup(invalidSecretcode, username, password)).rejects.toStrictEqual(unverifiedResponse)
    })
    afterEach(() => {
        delete process.env.FAD_COGNITO_POOL_ID;
        delete process.env.FAD_COGNITO_APP_CLIENT_ID;
    });
 })

const secretcode = 'secretcode1234'
const username = 'johnDoe'
const password = 'password1234'

const invalidSecretcode = 'invlaid-secretcode'
const invalidUsername = 'invalid-username'
const invalidPassword = 'invalid-password'


const successfulResponse = {
    "status": "SUCCESS",
    "accessToken": "accessToken"
};

const unauthorizedResponse = new DashboardErrorResponse(403, "UNAUTHORIZED", "Invalid username or password")

const unverifiedResponse = new DashboardErrorResponse(403, "UNVERIFIED", "Invalid secret code")
