/* Unit Test for getService class
 * FFMARCH-2993
 * @author mohamed.h.osman
 */

const getService = require('../../services/GetService')


describe('Retrieve the configuration of a specific service ', () => {
    beforeEach(() => {
        jest.fn().mockClear()
        process.env.FAD_ENV_TYPE = 'POC'
        process.env.FAD_DYNAMODB_TABLE_SERVICES = "sm_dashboard_poc_services"
    })
    it('Confirm correctly formatted configuration of DSRS Get Document Metadata service is returned', () => {
        return expect(getService("DSRS","Get Document Metadata")).resolves.toEqual(configService);
    })
    it('Confirm request doesnt return empyt value of config service', () => {
        return expect(getService("DSRS","Get Document Metadata")).resolves.not.toEqual('');
    })
    afterEach(() => {
        delete process.env.FAD_ENV_TYPE;
        delete process.env.FAD_DYNAMODB_TABLE_SERVICES
    });
})


const configService =   {
		"api_key_name": "FFM_SM",
		"service": "Get Document Metadata",
		"template": {
			"headers": [
				"source-system-name: <%= sourceSystemName %>",
				"role-Id: <%= roleId %>",
				"<%= partnerId ? \"partner-id: \" + partnerId : \"\"%>",
				"user-Id: <%= userId %>",
				"Content-Type:application/json",
				"x-correlation-id: <%= correlationId %>"
			],
			"formSchema": [
				{
					"id": "sourceSystemName",
					"type": "select",
					"title": "Source System Name",
					"items": [
						"FFM_SM",
						"FFM_EE",
						"FFM_MCR",
						"FFM_DSRS",
						"FFM_IES",
						"FFM_SES",
						"FFM_PM",
						"FFM_CORRESPONDENCE",
						"NGD",
						"ESS",
						"DSH",
						"APP3.0",
						"CERRS",
						"ESDCU",
						"EACMS"
					],
					"required": true
				},
				{
					"default": "default",
					"id": "roleId",
					"type": "string",
					"title": "Role ID",
					"required": true
				},
				{
					"id": "partnerId",
					"type": "string",
					"title": "Partner ID",
					"required": true
				},
				{
					"id": "userId",
					"type": "string",
					"title": "User ID",
					"required": true
				},
				{
					"id": "dsrsId",
					"type": "string",
					"title": "DSRS ID",
					"required": true
				}
			]
		},
		"root_url": "https://api.poc.dsrs-test.mp.cmscloud.local:8443",
		"path": "/v1/metadata/<%=dsrsId%>",
		"path_regex": "^/v1/metadata/[a-zA-Z0-9_-]+$",
		"environments": [
			{
				"env": "test0",
				"label": "Test 0"
			},
			{
				"env": "test1",
				"label": "Test 1"
			},
			{
				"env": "test2",
				"label": "Test 2"
			},
			{
				"env": "test3",
				"label": "Test 3"
			},
			{
				"env": "test4",
				"label": "Test 4"
			},
			{
				"env": "test5",
				"label": "Test 5"
			}
		],
		"application": "DSRS",
		"service_type": "api_service",
		"method": "GET"
	}
