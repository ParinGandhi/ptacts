/* Unit Test for PerformValidateTotp class
 * FFMARCH-3076
 * @author mohamed.h.osman
 */

const performValidateTotp = require("../../services/PerformValidateTotp");
const DashboardErrorResponse = require('../../common/DashboardErrorResponse');

describe('Performing validate time-based one-time code', () => {
    beforeEach(() =>{
        jest.fn().mockClear()
        process.env.FAD_COGNITO_APP_CLIENT_ID = 'jestTEST1234'
          })
    it('Valid username, opt, cognitosessionkey is resolved with SUCESS status', () => {
      return  expect(performValidateTotp(userName, otp, cognitosessionkey)).resolves.toStrictEqual(successfulResponse)
    })
    it('Valid username, opt, cognitosessionkey is not resolved with FAILURE status', () => {
      return  expect(performValidateTotp(userName, otp, cognitosessionkey)).resolves.not.toStrictEqual(failedResponse)
    })
    it('Invalid userName value is rejected with an error', () => {
      return  expect(performValidateTotp(invalidUserName, otp, cognitosessionkey)).rejects.toStrictEqual(errorResponse)
    })
    it('Invalid otp value is rejected with an error', () => {
      return  expect(performValidateTotp(userName, invalidOTP, cognitosessionkey)).rejects.toStrictEqual(errorResponse)
    })
    it('Invalid cognitosessionkey value is rejected with an error', () => {
      return  expect(performValidateTotp(userName, otp, invalidCognitosessionkey)).rejects.toStrictEqual(errorResponse)
    })
    afterEach(() => {
        delete process.env.FAD_COGNITO_APP_CLIENT_ID;
    });
 })

const cognitosessionkey = 'cognitosessionkey1234'
const userName = 'johnDoe'
const otp = 'onetimepassword1234'

const invalidCognitosessionkey = 'invalid-cognitosessionkey'
const invalidUserName = 'invalid-username'
const invalidOTP = 'invalid-otp'

const successfulResponse = {
    "status": "SUCCESS",
    "accessToken": "accessToken"
};

const failedResponse = {
    "status": "FAILURE",
    "accessToken": "accessToken"
};


const errorResponse = new DashboardErrorResponse(401, "FAILURE", "Invalid Input")
