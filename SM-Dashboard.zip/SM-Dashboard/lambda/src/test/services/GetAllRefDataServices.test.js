const getAllRefDataServices = require('../../services/GetAllRefDataServices')

describe('services', () => {
    beforeEach(() => {
        jest.fn().mockClear()
        process.env.FAD_ENV_TYPE = 'POC'
        process.env.FAD_DYNAMODB_TABLE_SERVICES = "sm_dashboard_poc_services"
    })
    it('Confirm correctly formatted service configurations are returned', () => {
        return expect(getAllRefDataServices()).resolves.toEqual(testResult);
    })
    afterEach(() => {
        delete process.env.FAD_ENV_TYPE;
        delete process.env.FAD_DYNAMODB_TABLE_SERVICES
    });
})

const testResult = {"applications": [
    {
        "name": "EE",
        "services": [
        {
            "name": "AB Search Toggle",
            "label": "AB Search Toggle",
            "method": "GET",
            "path": "/FindPersonNgAccessEnablement",
            "root_url": "https://<%=env%>.healthcare.gov/base-rest/global/en_US/ReferenceCode",
            "headers": [],
            "formSchema": [],
            "environments": [
            {
                "env": "test",
                "env_cookies": "/smdashboard/poc0/cookies",
                "label": "Test 0"
            },
            {
                "env": "aws-test1",
                "env_cookies": "/smdashboard/poc1/cookies",
                "label": "Test 1"
            },
            {
                "env": "test2",
                "env_cookies": "/smdashboard/poc2/cookies",
                "label": "Test 2"
            },
            {
                "env": "test3",
                "env_cookies": "/smdashboard/poc3/cookies",
                "label": "Test 3"
            },
            {
                "env": "test5",
                "env_cookies": "/smdashboard/poc5/cookies",
                "label": "Test 5"
            }],
            "allowed_roles": ["REF_DATA_BROWSING_RO", "REF_DATA_BROWSING_WO"],
            "legend": ["false=OFF", "true=ON"],
            "notes": ["Currently set to false (OFF) in production.", "When OFF, the search is routed through Legacy Person Search, otherwise SES API."],
            "filtered_values": ["codeGroup.referenceTypeName", "value"]
        },
        {
            "name": "Custom Entry",
            "label": "Custom Entry",
            "method": "GET",
            "path": "/<%=customEntry%>",
            "root_url": "https://<%=env%>.healthcare.gov/base-rest/global/en_US/ReferenceCode",
            "headers": [],
            "formSchema": [
            {
                "id": "customEntry",
                "type": "string",
                "title": "Custom Params",
                "required": true
            }],
            "environments": [
            {
                "env": "test",
                "env_cookies": "/smdashboard/poc0/cookies",
                "label": "Test 0"
            },
            {
                "env": "aws-test1",
                "env_cookies": "/smdashboard/poc1/cookies",
                "label": "Test 1"
            },
            {
                "env": "test2",
                "env_cookies": "/smdashboard/poc2/cookies",
                "label": "Test 2"
            },
            {
                "env": "test3",
                "env_cookies": "/smdashboard/poc3/cookies",
                "label": "Test 3"
            },
            {
                "env": "test5",
                "env_cookies": "/smdashboard/poc5/cookies",
                "label": "Test 5"
            }],
            "filtered_values": ["codeGroup.referenceTypeName", "value"]
        },
        {
            "name": "Date Shift",
            "label": "Date Shift",
            "method": "GET",
            "path": "/AnnualOpenEnrollmentPeriodDates/<%=oePeriod%>",
            "root_url": "https://<%=env%>.healthcare.gov/base-rest/global/en_US/ReferenceCode",
            "headers": [],
            "formSchema": [
            {
                "id": "oePeriod",
                "type": "select",
                "title": "OE period",
                "items": ["2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021"],
                "required": true
            }],
            "environments": [
            {
                "env": "test",
                "env_cookies": "/smdashboard/poc0/cookies",
                "label": "Test 0"
            },
            {
                "env": "aws-test1",
                "env_cookies": "/smdashboard/poc1/cookies",
                "label": "Test 1"
            },
            {
                "env": "test2",
                "env_cookies": "/smdashboard/poc2/cookies",
                "label": "Test 2"
            },
            {
                "env": "test3",
                "env_cookies": "/smdashboard/poc3/cookies",
                "label": "Test 3"
            },
            {
                "env": "test5",
                "env_cookies": "/smdashboard/poc5/cookies",
                "label": "Test 5"
            }],
            "legend": ["Inside OE if today's date is between the start and end dates for this refdata."],
            "notes": ["E.g.\"01-NOV-2020:00:00:00|16-DEC-2020:02:59:59\"", "Specifies OE period for 2020"],
            "filtered_values": ["codeGroup.referenceTypeName", "value"]
        }]
    }]
   }
