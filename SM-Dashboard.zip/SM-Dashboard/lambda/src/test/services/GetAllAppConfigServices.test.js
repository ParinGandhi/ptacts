/* Unit Test for GetAllAppConfigServices class
 * FFMARCH-2989
 * @author mohamed.h.osman
 */

const getAllAppConfigServices = require('../../services/GetAllAppConfigServices')

describe('Retrieve all service configurations from DB', () => {
    beforeEach(() => {
        jest.fn().mockClear()
        process.env.FAD_ENV_TYPE = 'POC'
        process.env.FAD_DYNAMODB_TABLE_SERVICES = "sm_dashboard_poc_services"
    })
    it('Confirm correctly formatted configurations of all services are returned', () => {
        return expect(getAllAppConfigServices()).resolves.toEqual(expectedScanResults);
    })
    it('Confirm request doesnt return empty list of services configurations', () => {
        return expect(getAllAppConfigServices()).resolves.not.toEqual(emptyListConfigServices);
    })
    afterEach(() => {
        delete process.env.FAD_ENV_TYPE;
        delete process.env.FAD_DYNAMODB_TABLE_SERVICES
    });
})
let emptyListConfigServices =  {"applications": []}
let expectedScanResults = {
   "applications":  [
      {
       "name": "IES",
       "services":  [
          {
           "allowed_roles":  [
             "APP_CONFIG_MANAGEMENT_RO",
             "APP_CONFIG_MANAGEMENT_RW",
           ],
           "environments":  [
              {
               "env": "test0",
               "label": "Test 0",
             },
              {
               "env": "test1",
               "label": "Test 1",
             },
              {
               "env": "test2",
               "label": "Test 2",
             },
              {
               "env": "test3",
               "label": "Test 3",
             },
              {
               "env": "test4",
               "label": "Test 4",
             },
              {
               "env": "test5",
               "label": "Test 5",
             },
           ],
           "id": "hc-ies-poc-blue-config",
           "name": "Blue",
           "prefix": "",
           "s3BucketName": "hc-ies-poc-blue-config",
           "serviceName": "Blue",
           "subFolders":  [],
         },
          {
           "allowed_roles":  [
             "APP_CONFIG_MANAGEMENT_RO",
             "APP_CONFIG_MANAGEMENT_RW",
           ],
           "environments":  [
              {
               "env": "test0",
               "label": "Test 0",
             },
              {
               "env": "test1",
               "label": "Test 1",
             },
              {
               "env": "test2",
               "label": "Test 2",
             },
              {
               "env": "test3",
               "label": "Test 3",
             },
              {
               "env": "test4",
               "label": "Test 4",
             },
              {
               "env": "test5",
               "label": "Test 5",
             },
           ],
           "id": "hc-ies-poc-blue-config",
           "name": "Green",
           "prefix": "",
           "s3BucketName": "hc-ies-poc-blue-config",
           "serviceName": "Green",
           "subFolders":  [],
         },
       ],
     },
   ],
      }
