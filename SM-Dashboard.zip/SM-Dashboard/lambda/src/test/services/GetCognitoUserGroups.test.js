/*
 * Test Get cognito user groups
 *FFMARCH-2993
 * @author mohamed.h.osman
 */

const getCognitoUserGroups = require('../../services/GetCognitoUserGroups')
const expextedRoles = {"roles":["API_INVOKE_RO"]}
describe('Get Cognito User Groups roles list for current user', () => {
 beforeEach(() =>{
        jest.fn().mockClear()
        process.env.FAD_COGNITO_POOL_ID = '1234'
        })
    test('Confirm cognito user groups is returing roles list for current user', () => {
         return expect(getCognitoUserGroups('johnDoe')).resolves.toStrictEqual({"roles": ["API_INVOKE_RW", "APP_CONFIG_MANAGEMENT_WO", "APP_CONFIG_MANAGEMENT_RW" ]})
        })
    test('Confirm cognito user groups does not return empty roles list for current user', () => {
        return expect(getCognitoUserGroups('johnDoe')).resolves.not.toStrictEqual({"roles": [""]})
            })
        })
