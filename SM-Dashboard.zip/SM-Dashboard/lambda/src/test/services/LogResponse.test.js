/* Unit Test for LogRequest.js
 * FFMARCH-3043
 * @author mohamed.h.osman
 */

const logResponse = require("../../services/LogResponse");



describe('Logs a respone to the database to keep track of user activity', () => {
    beforeEach(() =>{
        jest.fn().mockClear()
        process.env.FAD_DYNAMODB_TABLE_LOGS = "sm_dashboard_poc_services"
        })
    it('user activity response is logged successfully', () => {
      return  expect(logResponse(wrappedRequestResponse1)).resolves.toBeTruthy()
    })
    it('user activity response with param key id missing is not logged', () => {
      return  expect(logResponse(wrappedRequestResponse2)).rejects.toBeFalsy()
    })
    it('Empty response will throw a TypeError', () => {
      return  expect(() => {logResponse({})}).toThrow(TypeError)
    })
    afterEach(() => {
        delete process.env.FAD_DYNAMODB_TABLE_LOGS;
    });
 })
wrappedRequestResponse1 = {
  originalRequest: {
    logid: 1234
  },
  responsePayload: {
    headers: "response_headers",
    status: "success",
    responseTime: 1234
  }
}

wrappedRequestResponse2 = {
  originalRequest: {
  },
  responsePayload: {
  }
}
