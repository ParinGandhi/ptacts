const getUserQueryHistory = require('../../services/GetUserQueryHistory')

describe('services', () => {
    beforeEach(() => {
        jest.fn().mockClear()
        process.env.FAD_ENV_TYPE = 'POC'
        process.env.FAD_DYNAMODB_TABLE_LOGS = "sm_dashboard_poc_services"
    })
    it('Confirm user query history is returned', () => {
        return expect(getUserQueryHistory("JohnDoe")).resolves.toEqual(testResult);
    })
    afterEach(() => {
        delete process.env.FAD_ENV_TYPE;
        delete process.env.FAD_DYNAMODB_TABLE_LOGS
    });
})

const testResult = [
    {
      "logType_creationDateTime": "api_request#2021-03-30T18:05:08.885Z",
      "response_time": 107.31748399999924,
      "request_formmodel": {
        "sourceSystemName": "FFM_SM",
        "partnerId": "1212",
        "userId": "121212",
        "dsrsId": "1212",
        "roleId": "default"
      },
      "user": "JohnDoe",
      "response_status": 403,
      "request_headers": {
        "partner-id": "1212",
        "role-id": "default",
        "source-system-name": "FFM_SM",
        "user-id": "121212"
      },
      "url": "https://api.test0.dsrs-test.mp.cmscloud.local:8443/v1/document/1212",
      "response_headers": {
        "date": "Tue, 30 Mar 2021 18:05:09 GMT",
        "content-length": "386",
        "server": "Layer7-API-Gateway",
        "content-type": "application/json;charset=UTF-8",
        "connection": "close"
      },
      "method": "GET",
      "service": "Get Document",
      "request_environment": "test0",
      "creationDateTime": "2021-03-30T18:05:08.885Z",
      "application": "DSRS",
      "request_body": null,
      "id": "76bdac50-9182-11eb-9615-21c10e909d19",
      "log_type": "api_request"
    },
    {
      "logType_creationDateTime": "api_request#2021-03-17T17:23:25.692Z",
      "request_formmodel": {
        "sourceSystemName": "FFM_EE",
        "correlationId": "dashboard-63e83e72-8745-11eb-88c8-65c49b297b39",
        "partnerId": "123123123",
        "userId": "123123123",
        "roleId": "default",
        "appId": "123123123123"
      },
      "user": "JohnDoe",
      "request_headers": {
        "partner-id": "123123123",
        "x-correlation-id": "dashboard-63e83e72-8745-11eb-88c8-65c49b297b39",
        "role-id": "default",
        "source-system-name": "FFM_EE",
        "user-id": "123123123"
      },
      "url": "http://api.test3.ee-test.mp.cmscloud.local:8080/ee-rest/v1/exemptions?insuranceApplicationId=123123123123",
      "method": "GET",
      "service": "Get Exemptions",
      "request_environment": "test3",
      "creationDateTime": "2021-03-17T17:23:25.692Z",
      "application": "EE",
      "request_body": null,
      "id": "7b59fbc0-8745-11eb-abe6-3bf106980ede",
      "log_type": "api_request"
    },
    {
      "logType_creationDateTime": "api_request#2021-02-23T22:20:45.284Z",
      "response_time": 35.87448499997845,
      "request_formmodel": {
        "coverageYear": null,
        "roleId": "default",
        "appId": "565656",
        "sourceSystemName": "FFM_MCR",
        "correlationId": "dashboard-30f45ac7-7625-11eb-a614-e715eb1cd419",
        "partnerId": "343434",
        "userId": "454545"
      },
      "user": "JohnDoe",
      "response_status": 400,
      "request_headers": {
        "partner-id": "343434",
        "x-correlation-id": "dashboard-30f45ac7-7625-11eb-a614-e715eb1cd419",
        "source-system-name": "FFM_MCR",
        "userid": "454545",
        "roleid": "default"
      },
      "url": "https://api.test3.ses-test.mp.cmscloud.local:8443/v1/applications?linkedToAppId=565656&startCoverageYear=",
      "response_headers": {
        "date": "Tue, 23 Feb 2021 22:20:45 GMT",
        "x-correlation-id": "dashboard-30f45ac7-7625-11eb-a614-e715eb1cd419",
        "content-length": "286",
        "server": "Layer7-API-Gateway",
        "content-type": "application/json",
        "connection": "close"
      },
      "method": "GET",
      "service": "Get App by Coverage Year",
      "request_environment": "test3",
      "creationDateTime": "2021-02-23T22:20:45.284Z",
      "application": "SES",
      "request_body": null,
      "id": "5f7d3240-7625-11eb-bbe8-597984e44542",
      "log_type": "api_request"
    }
]
