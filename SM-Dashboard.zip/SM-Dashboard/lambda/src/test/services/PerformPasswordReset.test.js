const performPasswordReset = require('../../services/PerformPasswordReset')

describe('services', () => {
    test('performing password reset', () => {
        return expect(performPasswordReset("johnDoe", "1234", "password1")).resolves.toEqual(expectedTestResults);
    })
})

let expectedTestResults = {
    "status": "SUCCESS",
    "statusCode": 200
}
