const performLogout = require('../../services/PerformLogout')

const accessToken = {
    "AccessToken": "123"
}

describe('services', () => {
    test('performing logout', () => {
        return expect(performLogout(accessToken)).resolves.toEqual(expectedTestResults);
    })
    //PerformLogout displays error message in the case of an error then returns the success response
    test('performing logout without access token', () => {
        return expect(performLogout(null)).resolves.toEqual(expectedTestResults);
    })
})

let expectedTestResults = {
    "status": "SUCCESS",
    "message": "Successfully logged out",
    "statusCode": 200
}
