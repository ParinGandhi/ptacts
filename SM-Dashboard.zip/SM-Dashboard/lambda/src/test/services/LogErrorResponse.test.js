/* Unit Test for LogErrorResponse.js
 * FFMARCH-3043
 * @author mohamed.h.osman
 */

const logErrorResponse = require("../../services/LogErrorResponse");



describe('Logs an error response to the database to keep track of user activity', () => {
    beforeEach(() =>{
        jest.fn().mockClear()
        process.env.FAD_DYNAMODB_TABLE_LOGS = "sm_dashboard_poc_services"
        })
    it('Error response is logged successfully', () => {
      return  expect(logErrorResponse(wrappedRequestResponse1)).resolves.toBeTruthy()
    })
    it('Error response with param key id missing is not logged', () => {
      return  expect(logErrorResponse(wrappedRequestResponse2)).rejects.toBeFalsy()
    })
    it('Empty response will throw a TypeError', () => {
      return  expect(() => {logErrorResponse({})}).toThrow(TypeError)
    })
    afterEach(() => {
        delete process.env.FAD_DYNAMODB_TABLE_LOGS;
    });
 })
wrappedRequestResponse1 = {
  originalRequest: {
    logid: 2341
  },
  responsePayload: {
    headers: "responseError_headers",
    status: "failed",
    responseTime: 1234
  }
}

wrappedRequestResponse2 = {
  originalRequest: {
  },
  responsePayload: {
  }
}
