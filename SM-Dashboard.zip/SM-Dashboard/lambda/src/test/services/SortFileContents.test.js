/* Unit Test for SortFileContents class
 * FFMARCH-3076
 * @author mohamed.h.osman
 */

const sortFileContents = require("../../services/SortFileContents");

describe('Sorts transaction log entries by timestamp', () => {

    it('In order transactions log entries are sorted by timestamp from old to new', () => {
      return  expect(sortFileContents(fileContentArrayInOrder)).resolves.toStrictEqual(sortedArray)
    })

    it('Out of order transactions log entries are sorted by timestamp from old to new', () => {
      return  expect(sortFileContents(fileContentArrayOutOfOrder)).resolves.toStrictEqual(sortedArray)
    })

    it('Out of order transactions log entries are not unsorted', () => {
      return  expect(sortFileContents(fileContentArrayOutOfOrder)).resolves.not.toStrictEqual(unSortedArray)
    })
    it('Sorting empty array produce empty array', () => {
      return  expect(sortFileContents([])).resolves.toStrictEqual([])
    })
 })


let fileContentArrayInOrder =  [
  "{\"timestamp\":1584384232961,\"name\":\"mcr\",\"request\":{\"method\":\"POST\",\"path\":\"/documents/information\",\"headers\":{\"role-id\":\"default\",\"user-id\":\"SM-MCR\",\"source-system-name\":\"FFM_MCR\",\"marketplace-api-key\":\"API-KEY\"},\"body\":\"{ \\\"personTrackingNumbers\\\":[\\\"1234868792351138843\\\"] }\"},\"tl_v\":1,\"tr\":0}\n{\"timestamp\":1584384232962,\"name\":\"mcr\",\"request\":{\"method\":\"POST\",\"path\":\"/documents/information\",\"headers\":{\"role-id\":\"default\",\"user-id\":\"SM-MCR\",\"source-system-name\":\"FFM_MCR\",\"marketplace-api-key\":\"API-KEY\"},\"body\":\"{ \\\"personTrackingNumbers\\\":[\\\"1994100221002130502\\\"] }\"},\"tl_v\":1,\"tr\":0}\n{\"timestamp\":1584384232964,\"name\":\"mcr\",\"request\":{\"method\":\"POST\",\"path\":\"/documents/information\",\"headers\":{\"role-id\":\"default\",\"user-id\":\"SM-MCR\",\"source-system-name\":\"FFM_MCR\",\"marketplace-api-key\":\"API-KEY\"},\"body\":\"{ \\\"personTrackingNumbers\\\":[\\\"1886868792351138842\\\"] }\"},\"tl_v\":1,\"tr\":0}\n{\"timestamp\":1584384232966,\"name\":\"mcr\",\"response\":{\"status_code\":200,\"headers\":{\"x-correlation-id\":\"000c04b0-8ac7-4311-a06e-1203eb671495\"},\"body\":\"{\\\"resultType\\\":\\\"error\\\",\\\"errorType\\\":\\\"validationError\\\",\\\"errorCode\\\":\\\"validation.error\\\",\\\"apiMessage\\\":\\\"Data Validation issue, please correct the data and try again\\\",\\\"validationErrors\\\":[{\\\"errorCode\\\":\\\"102212\\\",\\\"path\\\":\\\"personTrackingNumbers\\\",\\\"apiMessage\\\":\\\"Maximum field length has been reached\\\"}],\\\"requestId\\\":\\\"000c04b0-8ac7-4311-a06e-1203eb671495\\\"}\"},\"tl_v\":1,\"tr\":0}"
]

let fileContentArrayOutOfOrder =  [
  "{\"timestamp\":1584384232964,\"name\":\"mcr\",\"request\":{\"method\":\"POST\",\"path\":\"/documents/information\",\"headers\":{\"role-id\":\"default\",\"user-id\":\"SM-MCR\",\"source-system-name\":\"FFM_MCR\",\"marketplace-api-key\":\"API-KEY\"},\"body\":\"{ \\\"personTrackingNumbers\\\":[\\\"1886868792351138842\\\"] }\"},\"tl_v\":1,\"tr\":0}\n{\"timestamp\":1584384232961,\"name\":\"mcr\",\"request\":{\"method\":\"POST\",\"path\":\"/documents/information\",\"headers\":{\"role-id\":\"default\",\"user-id\":\"SM-MCR\",\"source-system-name\":\"FFM_MCR\",\"marketplace-api-key\":\"API-KEY\"},\"body\":\"{ \\\"personTrackingNumbers\\\":[\\\"1234868792351138843\\\"] }\"},\"tl_v\":1,\"tr\":0}\n{\"timestamp\":1584384232966,\"name\":\"mcr\",\"response\":{\"status_code\":200,\"headers\":{\"x-correlation-id\":\"000c04b0-8ac7-4311-a06e-1203eb671495\"},\"body\":\"{\\\"resultType\\\":\\\"error\\\",\\\"errorType\\\":\\\"validationError\\\",\\\"errorCode\\\":\\\"validation.error\\\",\\\"apiMessage\\\":\\\"Data Validation issue, please correct the data and try again\\\",\\\"validationErrors\\\":[{\\\"errorCode\\\":\\\"102212\\\",\\\"path\\\":\\\"personTrackingNumbers\\\",\\\"apiMessage\\\":\\\"Maximum field length has been reached\\\"}],\\\"requestId\\\":\\\"000c04b0-8ac7-4311-a06e-1203eb671495\\\"}\"},\"tl_v\":1,\"tr\":0}\n{\"timestamp\":1584384232962,\"name\":\"mcr\",\"request\":{\"method\":\"POST\",\"path\":\"/documents/information\",\"headers\":{\"role-id\":\"default\",\"user-id\":\"SM-MCR\",\"source-system-name\":\"FFM_MCR\",\"marketplace-api-key\":\"API-KEY\"},\"body\":\"{ \\\"personTrackingNumbers\\\":[\\\"1994100221002130502\\\"] }\"},\"tl_v\":1,\"tr\":0}"
]

let sortedArray =  [
          {
           "name": "mcr",
           "request":  {
             "body": "{ \"personTrackingNumbers\":[\"1234868792351138843\"] }",
             "headers":  {
               "marketplace-api-key": "API-KEY",
               "role-id": "default",
               "source-system-name": "FFM_MCR",
               "user-id": "SM-MCR",
             },
             "method": "POST",
             "path": "/documents/information",
           },
           "timestamp": 1584384232961,
           "tl_v": 1,
           "tr": 0,
         },
        {
         "name": "mcr",
         "request":  {
           "body": "{ \"personTrackingNumbers\":[\"1994100221002130502\"] }",
           "headers":  {
             "marketplace-api-key": "API-KEY",
             "role-id": "default",
             "source-system-name": "FFM_MCR",
             "user-id": "SM-MCR",
           },
           "method": "POST",
           "path": "/documents/information",
         },
         "timestamp": 1584384232962,
         "tl_v": 1,
         "tr": 0,
       },
       {
        "name": "mcr",
        "request":  {
          "body": "{ \"personTrackingNumbers\":[\"1886868792351138842\"] }",
          "headers":  {
            "marketplace-api-key": "API-KEY",
            "role-id": "default",
            "source-system-name": "FFM_MCR",
            "user-id": "SM-MCR",
          },
          "method": "POST",
          "path": "/documents/information",
        },
        "timestamp": 1584384232964,
        "tl_v": 1,
        "tr": 0,
      },
        {
         "name": "mcr",
         "response":  {
           "body": "{\"resultType\":\"error\",\"errorType\":\"validationError\",\"errorCode\":\"validation.error\",\"apiMessage\":\"Data Validation issue, please correct the data and try again\",\"validationErrors\":[{\"errorCode\":\"102212\",\"path\":\"personTrackingNumbers\",\"apiMessage\":\"Maximum field length has been reached\"}],\"requestId\":\"000c04b0-8ac7-4311-a06e-1203eb671495\"}",
           "headers":  {
             "x-correlation-id": "000c04b0-8ac7-4311-a06e-1203eb671495",
           },
           "status_code": 200,
         },
         "timestamp": 1584384232966,
         "tl_v": 1,
         "tr": 0,
       },
     ]

     let unSortedArray =  [
               {
                "name": "mcr",
                "request":  {
                  "body": "{ \"personTrackingNumbers\":[\"1886868792351138842\"] }",
                  "headers":  {
                    "marketplace-api-key": "API-KEY",
                    "role-id": "default",
                    "source-system-name": "FFM_MCR",
                    "user-id": "SM-MCR",
                  },
                  "method": "POST",
                  "path": "/documents/information",
                },
                "timestamp": 1584384232964,
                "tl_v": 1,
                "tr": 0,
              },
             {
              "name": "mcr",
              "request":  {
                "body": "{ \"personTrackingNumbers\":[\"1234868792351138843\"] }",
                "headers":  {
                  "marketplace-api-key": "API-KEY",
                  "role-id": "default",
                  "source-system-name": "FFM_MCR",
                  "user-id": "SM-MCR",
                },
                "method": "POST",
                "path": "/documents/information",
              },
              "timestamp": 1584384232961,
              "tl_v": 1,
              "tr": 0,
            },
             {
              "name": "mcr",
              "response":  {
                "body": "{\"resultType\":\"error\",\"errorType\":\"validationError\",\"errorCode\":\"validation.error\",\"apiMessage\":\"Data Validation issue, please correct the data and try again\",\"validationErrors\":[{\"errorCode\":\"102212\",\"path\":\"personTrackingNumbers\",\"apiMessage\":\"Maximum field length has been reached\"}],\"requestId\":\"000c04b0-8ac7-4311-a06e-1203eb671495\"}",
                "headers":  {
                  "x-correlation-id": "000c04b0-8ac7-4311-a06e-1203eb671495",
                },
                "status_code": 200,
              },
              "timestamp": 1584384232966,
              "tl_v": 1,
              "tr": 0,
            },
            {
             "name": "mcr",
             "request":  {
               "body": "{ \"personTrackingNumbers\":[\"1994100221002130502\"] }",
               "headers":  {
                 "marketplace-api-key": "API-KEY",
                 "role-id": "default",
                 "source-system-name": "FFM_MCR",
                 "user-id": "SM-MCR",
               },
               "method": "POST",
               "path": "/documents/information",
             },
             "timestamp": 1584384232962,
             "tl_v": 1,
             "tr": 0,
           }
          ]
