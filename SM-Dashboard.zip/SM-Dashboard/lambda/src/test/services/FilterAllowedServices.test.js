/* Unit Test for FilterAllowedServices class
 * FFMARCH-2937
 * @author mohamed.h.osman
 */

const filterAllowedServices = require("../../services/FilterAllowedServices");


describe('filter allowed services', () => {
    beforeEach(() =>{
        jest.fn().mockClear()
        process.env.FAD_ENV_TYPE = 'POC'
        })
    it('return filtered services for user with the allowed roles in allowed environments', () => {
      return  expect(filterAllowedServices(groupedAppServicesA, currentUser, capParamStoreKey)).resolves.toStrictEqual(filteredListServices)
    })
    it('return empty list of services for user without the allowed roles', () => {
      return  expect(filterAllowedServices(groupedAppServicesRolesNA, currentUser, capParamStoreKey)).resolves.toStrictEqual(emptyListServices)
     })
    it('return empty list of services not in the allowed environments', () => {
       return  expect(filterAllowedServices(groupedAppServicesEnvNA, currentUser, capParamStoreKey)).resolves.toStrictEqual(emptyListServices)
      })
    afterEach(() => {
        delete process.env.FAD_ENV_TYPE;
    });
 })

const groupedAppServicesA = {"applications": [ {"name": "EE", "services": [ {"name": "Get Benchmark Plans", "allowed_roles": [ "APP_CONFIG_MANAGEMENT_WO", "APP_CONFIG_MANAGEMENT_RW"], "environments": [ {"env": "test0", "label": "Test 0"}, {"env": "test1", "label": "Test 1"}] }]}]}
const groupedAppServicesRolesNA = {"applications": [ {"name": "EE", "services": [ {"name": "Get Benchmark Plans", "allowed_roles": [ "APP_CONFIG_MANAGEMENT", "API_INVOKE"], "environments": [ {"env": "test0", "label": "Test 0"}, {"env": "test1", "label": "Test 1"}] }]}]}
const groupedAppServicesEnvNA = {"applications": [ {"name": "EE", "services": [ {"name": "Get Benchmark Plans", "allowed_roles": [ "APP_CONFIG_MANAGEMENT_WO", "APP_CONFIG_MANAGEMENT_RW"], "environments": [ {"env": "impl0", "label": "Impl 0"}, {"env": "impl1", "label": "Impl 1"}] }]}]}

const filteredListServices = { 	"applications": [	{	"name": "EE",	"services": [	{	"environments": [	{	"env": "test0",	"label": "Test 0"	},	{	"env": "test1",	"label": "Test 1"	}	],	"name": "Get Benchmark Plans"	}	]	} 	] }
const emptyListServices =  {"applications": []}

const currentUser = "johnDoe"

const capParamStoreKey = "/smdashboard/POC/capabilities/api_request"
