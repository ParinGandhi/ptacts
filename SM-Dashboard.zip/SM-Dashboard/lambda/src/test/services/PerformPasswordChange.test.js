const performPasswordChange = require('../../services/PerformPasswordChange')

describe('services', () => {
    beforeEach(() => {
        jest.fn().mockClear()
        process.env.FAD_COGNITO_POOL_ID = 'POOL_ID'
        process.env.FAD_COGNITO_APP_CLIENT_ID = "APP_CLIENT_ID"
    })
    test('performing password change', () => {
        return expect(performPasswordChange("johnDoe", "password1", "password2")).rejects.toEqual(expectedTestResults);
    })
    afterEach(() => {
        delete process.env.FAD_COGNITO_POOL_ID;
        delete process.env.FAD_COGNITO_APP_CLIENT_ID
    });
})

let expectedTestResults =  {
    "message": "Submit a request to the system administrator to enable changing the password",
    "status": "PASSWORD_CHANGE_REQUEST_REQUIRED",
    "statusCode": 400
}
