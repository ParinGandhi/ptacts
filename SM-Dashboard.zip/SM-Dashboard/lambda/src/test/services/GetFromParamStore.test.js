/*
 * Test GetFromParamStore for a given key from AWS Secret Manager
 *FFMARCH-2993
 * @param key - key to obtain value for
 *
 * @author mohamed.h.osman
 */

const getFromParamStore = require('../../services/GetFromParamStore')
describe('Obtain value for a given key from AWS Secret Manager Store', () => {
    test('Confirm allowed/environments key returns allowed environments values', () => {
      return  expect(getFromParamStore('/smdashboard/POC/allowed/environments')).resolves.toStrictEqual('test,test0,test1,test2,test3,test4,test5')
        })
    test('Confirm allowed/environments key does not return empty values', () => {
      return  expect(getFromParamStore('/smdashboard/POC/allowed/environments')).resolves.not.toStrictEqual('')
        })
    test('Confirm capabilities/api_request key returns allowed roles values', () => {
      return  expect(getFromParamStore('/smdashboard/POC/capabilities/api_request')).resolves.toStrictEqual('{"allowedRoles":["APP_CONFIG_MANAGEMENT_RO","APP_CONFIG_MANAGEMENT_WO","API_INVOKE_RO"]}')
        })
    test('Confirm capabilities/api_request key does not return empty values', () => {
      return  expect(getFromParamStore('/smdashboard/POC/capabilities/api_request')).resolves.not.toStrictEqual('')
            })
            })
