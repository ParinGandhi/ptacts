const performLogin = require('../../services/PerformLogin')

describe('services', () => {
    beforeEach(() => {
        jest.fn().mockClear()
        process.env.FAD_COGNITO_POOL_ID = 'POOL_ID'
        process.env.FAD_COGNITO_APP_CLIENT_ID = "APP_CLIENT_ID"
    })
    test('performing login', () => {
        return expect(performLogin("johnDoe", "password1", 123)).resolves.toEqual(expectedTestResults);
    })
    afterEach(() => {
        delete process.env.FAD_COGNITO_POOL_ID;
        delete process.env.FAD_COGNITO_APP_CLIENT_ID
    });
})

let expectedTestResults = {
    "accessToken": "accessToken",
    "status": "SUCCESS",
}
