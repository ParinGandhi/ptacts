const getAllServices = require('../../services/GetAllServices')


describe('services', () => {
    beforeEach(() => {
        jest.fn().mockClear()
        process.env.FAD_ENV_TYPE = 'POC'
        process.env.FAD_DYNAMODB_TABLE_SERVICES = "sm_dashboard_poc_services"
    })
    it('Confirm correctly formatted services are returned', () => {
        return expect(getAllServices("jonhDoe")).resolves.toEqual(expectedScanResults);
    })
    afterEach(() => {
        delete process.env.FAD_ENV_TYPE;
        delete process.env.FAD_DYNAMODB_TABLE_SERVICES
    });
})

let expectedScanResults = {"applications":[
    {
        "name": "EE",
        "services": [
            {
                "name": "Get Benchmark Plans",
                "path": "/ee-rest/v1/plans/get-benchmark-plans",
                "body": "{ \"benchmarkCriteria\":[{ \"familyRelationships\": <%= JSON.stringify(familyRelationships) %>,\"legalRelationships\": <%= JSON.stringify(legalRelationships) %>,\"insuranceApplicationIdentifier\": <%= JSON.stringify(insuranceApplicationIdentifier) %>,\"members\": <%= JSON.stringify(members) %>,\"groupCoverageEffectiveStartDate\": <%= JSON.stringify(groupCoverageEffectiveStartDate) %>}]}",
                "headers": [
                    "source-system-name: <%= sourceSystemName %>",
                    "role-Id: <%= roleId %>",
                    "<%= partnerId ? \"partner-id: \" + partnerId : \"\"%>",
                    "user-Id: <%= userId %>",
                    "Content-Type:application/json",
                    "x-correlation-id: <%= correlationId %>"
                ],
                "formSchema": [
                    {
                        "default": "FFM_SES",
                        "id": "sourceSystemName",
                        "title": "Source System Name",
                        "type": "select",
                        "items": [
                            "FFM_SM",
                            "FFM_EE",
                            "FFM_MCR",
                            "FFM_DSRS",
                            "FFM_IES",
                            "FFM_SES",
                            "FFM_PM",
                            "FFM_CORRESPONDENCE",
                            "NGD",
                            "ESS",
                            "DSH",
                            "APP3.0",
                            "CERRS",
                            "ESDCU",
                            "EACMS"
                        ],
                        "required": true
                    },
                    {
                        "default": "SES",
                        "id": "roleId",
                        "type": "string",
                        "title": "Role ID",
                        "required": true
                    },
                    {
                        "id": "partnerId",
                        "type": "string",
                        "title": "Partner ID",
                        "required": false
                    },
                    {
                        "id": "userId",
                        "type": "string",
                        "title": "User ID",
                        "required": true
                    },
                    {
                        "id": "correlationId",
                        "type": "correlationId",
                        "title": "X-Correlation ID",
                        "required": true
                    },
                    {
                        "id": "insuranceApplicationIdentifier",
                        "type": "string",
                        "title": "Insurance Application Identifier",
                        "required": true
                    },
                    {
                        "id": "groupCoverageEffectiveStartDate",
                        "type": "string",
                        "title": "Group Coverage Effective Start Date",
                        "required": true
                    },
                    {
                        "item": {
                            "type": "object",
                            "title": "familyRelationships",
                            "items": [
                                {
                                    "type": "string",
                                    "title": "Subordinate Member",
                                    "id": "subordinateMember"
                                },
                                {
                                    "type": "string",
                                    "title": "Relationship Type",
                                    "id": "relationshipType"
                                },
                                {
                                    "type": "string",
                                    "title": "Superordinate Member",
                                    "id": "superordinateMember"
                                }
                            ],
                            "required": true
                        },
                        "id": "familyRelationships",
                        "type": "array",
                        "title": "familyRelationships",
                        "required": true
                    },
                    {
                        "item": {
                            "type": "object",
                            "title": "legalRelationships",
                            "items": [
                                {
                                    "type": "string",
                                    "title": "Subordinate Member",
                                    "id": "subordinateMember"
                                },
                                {
                                    "type": "string",
                                    "title": "Relationship Type",
                                    "id": "relationshipType"
                                },
                                {
                                    "type": "string",
                                    "title": "Superordinate Member",
                                    "id": "superordinateMember"
                                }
                            ],
                            "required": true
                        },
                        "id": "legalRelationships",
                        "type": "array",
                        "title": "legalRelationships",
                        "required": true
                    },
                    {
                        "item": {
                            "type": "object",
                            "title": "Members",
                            "items": [
                                {
                                    "type": "string",
                                    "title": "Application Member Identifier",
                                    "id": "applicationMemberIdentifier"
                                },
                                {
                                    "type": "boolean",
                                    "title": "Contact Requesting Coverage Indicator",
                                    "id": "contactRequestingCoverageIndicator"
                                },
                                {
                                    "type": "string",
                                    "title": "Sex",
                                    "id": "sex"
                                },
                                {
                                    "type": "string",
                                    "title": "Benchmark Type",
                                    "id": "benchmarkType"
                                },
                                {
                                    "id": "residencyAddress",
                                    "type": "object",
                                    "title": "Residency Address",
                                    "items": [
                                        {
                                            "type": "string",
                                            "title": "Residency Address Source Type",
                                            "id": "residencyAddressSourceType"
                                        },
                                        {
                                            "type": "string",
                                            "title": "Street Name 1",
                                            "id": "streetName1"
                                        },
                                        {
                                            "default": "null",
                                            "id": "streetName2",
                                            "type": "string",
                                            "title": "Street Name 2"
                                        },
                                        {
                                            "type": "string",
                                            "title": "State Code",
                                            "id": "stateCode"
                                        },
                                        {
                                            "type": "string",
                                            "title": "City Name",
                                            "id": "cityName"
                                        },
                                        {
                                            "type": "string",
                                            "title": "Zip Code",
                                            "id": "zipCode"
                                        },
                                        {
                                            "type": "string",
                                            "title": "County Name",
                                            "id": "countyName"
                                        },
                                        {
                                            "type": "string",
                                            "title": "County Fips Code",
                                            "id": "countyFipsCode"
                                        }
                                    ],
                                    "required": true
                                },
                                {
                                    "type": "string",
                                    "title": "Birth Date",
                                    "id": "birthDate"
                                },
                                {
                                    "type": "string",
                                    "title": "Coverage Effective Start Date",
                                    "id": "coverageEffectiveStartDate"
                                }
                            ],
                            "required": true
                        },
                        "id": "members",
                        "type": "array",
                        "title": "members",
                        "required": true
                    }
                ],
                "environments": [
                    {
                        "env": "test0",
                        "label": "Test 0"
                    },
                    {
                        "env": "test1",
                        "label": "Test 1"
                    },
                    {
                        "env": "test2",
                        "label": "Test 2"
                    },
                    {
                        "env": "test3",
                        "label": "Test 3"
                    },
                    {
                        "env": "test4",
                        "label": "Test 4"
                    },
                    {
                        "env": "test5",
                        "label": "Test 5"
                    }
                ]
            }
        ]
    },
    {
        "name": "IES",
        "services": [
            {
                "name": "Get Enrollments",
                "path": "/v1/enrollments?<%= field %>=<%= input %>",
                "headers": [
                    "source-system-name: <%= sourceSystemName %>",
                    "roleId: <%= roleId %>",
                    "<%= partnerId ? \"partner-id:\" + partnerId : \"\"%>",
                    "user-id: <%= userId %>"
                ],
                "formSchema": [
                    {
                        "id": "sourceSystemName",
                        "type": "select",
                        "title": "Source System Name",
                        "items": [
                            "FFM_SM",
                            "FFM_EE",
                            "FFM_MCR",
                            "FFM_DSRS",
                            "FFM_IES",
                            "FFM_SES",
                            "FFM_PM",
                            "FFM_CORRESPONDENCE",
                            "NGD",
                            "ESS",
                            "DSH",
                            "APP3.0",
                            "CERRS",
                            "ESDCU",
                            "EACMS"
                        ],
                        "required": true
                    },
                    {
                        "default": "default",
                        "id": "roleId",
                        "type": "string",
                        "title": "Role ID",
                        "required": true
                    },
                    {
                        "id": "partnerId",
                        "type": "string",
                        "title": "Partner ID",
                        "required": true
                    },
                    {
                        "id": "userId",
                        "type": "string",
                        "title": "User ID",
                        "required": true
                    },
                    {
                        "id": "field",
                        "type": "select",
                        "title": "Search By",
                        "items": [
                            "exchangeAssignedPolicyId",
                            "appId"
                        ],
                        "required": true
                    },
                    {
                        "id": "input",
                        "type": "string",
                        "title": "Input",
                        "required": true
                    }
                ],
                "environments": [
                    {
                        "env": "test0",
                        "label": "Test 0"
                    },
                    {
                        "env": "test1",
                        "label": "Test 1"
                    },
                    {
                        "env": "test2",
                        "label": "Test 2"
                    },
                    {
                        "env": "test3",
                        "label": "Test 3"
                    },
                    {
                        "env": "test4",
                        "label": "Test 4"
                    },
                    {
                        "env": "test5",
                        "label": "Test 5"
                    }
                ]
            }
        ]
    },
    {
        "name": "EE-PC2",
        "services": [
            {
                "name": "SVI Information",
                "path": "/ee-rest/api-auth/en_US/SepVerificationApi/v1/ffmRetrieveSVIInformation",
                "body": "{\"insuranceApplicationIdentifier\": <%= insuranceApplicationIdentifier %>}",
                "headers": [
                    "roleId: <%= roleId %>",
                    "source-system-name: <%= sourceSystemName %>",
                    "user-Id: <%= userId %>",
                    "Content-Type: application/json"
                ],
                "formSchema": [
                    {
                        "id": "sourceSystemName",
                        "type": "select",
                        "title": "Source System Name",
                        "items": [
                            "FFM_SM",
                            "FFM_EE",
                            "FFM_MCR",
                            "FFM_DSRS",
                            "FFM_IES",
                            "FFM_SES",
                            "FFM_PM",
                            "FFM_CORRESPONDENCE",
                            "NGD",
                            "ESS",
                            "DSH",
                            "APP3.0",
                            "CERRS",
                            "ESDCU",
                            "EACMS"
                        ],
                        "required": true
                    },
                    {
                        "id": "userId",
                        "type": "string",
                        "title": "User ID",
                        "required": true
                    },
                    {
                        "default": "SES",
                        "id": "roleId",
                        "type": "string",
                        "title": "Role ID",
                        "required": true
                    },
                    {
                        "id": "insuranceApplicationIdentifier",
                        "type": "string",
                        "title": "Insurance Application ID",
                        "required": true
                    }
                ],
                "environments": [
                    {
                        "env": "test0",
                        "label": "Test 0"
                    },
                    {
                        "env": "test1",
                        "label": "Test 1"
                    },
                    {
                        "env": "test2",
                        "label": "Test 2"
                    },
                    {
                        "env": "test3",
                        "label": "Test 3"
                    },
                    {
                        "env": "test4",
                        "label": "Test 4"
                    },
                    {
                        "env": "test5",
                        "label": "Test 5"
                    }
                ]
            }
        ]
    }
]}
