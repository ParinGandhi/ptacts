/* Unit Test for ValidateUserServiceAccess class
 * FFMARCH-2893
 * @author mohamed.h.osman
 */
const validateUserServiceAccess = require('../../utils/ValidateUserServiceAccess')

const serviceAllowedRoles = ["APP_CONFIG_MANAGEMENT_WO","APP_CONFIG_MANAGEMENT_RW"]

const envAllowedRoles_T =  ["APP_CONFIG_MANAGEMENT_RO","APP_CONFIG_MANAGEMENT_WO","API_INVOKE_RO"]
const envAllowedRoles_F =  ["APP_CONFIG_MANAGEMENT_RO","API_INVOKE_RO","REF_DATA_BROWSING_RO"]

const userRoles_T =  ["API_INVOKE_RW","APP_CONFIG_MANAGEMENT_WO","APP_CONFIG_MANAGEMENT_RW"]
const userRoles_F =  ["API_INVOKE_RO","APP_CONFIG_MANAGEMENT_RO","TL_SEARCH_RW"]


describe('utils', () => {
    test('user role is in the env allowed roles and service allowed roles', () => {
        expect(validateUserServiceAccess(serviceAllowedRoles, envAllowedRoles_T,
        userRoles_T)).toStrictEqual(true)
     })
     test('user role is in the env allowed roles but not in the service allowed roles', () => {
                     expect(validateUserServiceAccess(serviceAllowedRoles, envAllowedRoles_T,
                             userRoles_F)).toStrictEqual(false)
})
     test('user role is not in the env allowed roles nor in the service allowed roles', () => {
                     expect(validateUserServiceAccess(serviceAllowedRoles, envAllowedRoles_F,
                             userRoles_F)).toStrictEqual(false)
})
     test('user role is in the env allowed roles but not in the service allowed roles', () => {
                     expect(validateUserServiceAccess(serviceAllowedRoles, envAllowedRoles_F,
                             userRoles_T)).toStrictEqual(false)
})
})


