const validateServiceEnvList = require('../../utils/ValidateServiceEnvList')


describe('utils', () => {
    test('Do not confirm valid env for deployed environment', () => {
        expect(validateServiceEnvList([{
            "env": "test0",
            "label": "Test 0"
        }, {
            "env": "test1",
            "label": "Test 1"
        }], 'test5')).not.toStrictEqual([{
            "env": "test0",
            "label": "Test 0"
        }])
    })

    test('Confirm valid env for deployed environment', () => {
        expect(validateServiceEnvList([{
            "env": "test0",
            "label": "Test 0"
        }, {
            "env": "test1",
            "label": "Test 1"
        }], 'test0')).toStrictEqual([{
            "env": "test0",
            "label": "Test 0"
        }])
    })

    test('Do not confirm valid env for deployed environment when args are incorrect', () => {
        expect(validateServiceEnvList('test0')).toStrictEqual([])
    })

    test('Do not confirm valid env for deployed environment when args are missing', () => {
        expect(validateServiceEnvList()).toStrictEqual([])
    })
})
