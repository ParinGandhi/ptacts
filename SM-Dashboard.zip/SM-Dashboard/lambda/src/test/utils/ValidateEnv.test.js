const DashboardErrorResponse = require('../../common/DashboardErrorResponse');
const validateEnv = require('../../utils/ValidateEnv.js')

describe('utils', () => {
    beforeEach(() =>{
        jest.fn().mockClear()
        process.env.FAD_ENV_TYPE = 'POC'
    })
    it('Confirm user Env access',  () => {
        return expect(validateEnv(evn, serviceEnvs)).resolves.toStrictEqual(true);
    })
    it('Confirm user not allowed',  () => {
        return expect(validateEnv(evnNA, serviceEnvs)).rejects.toStrictEqual(DashboardErrorResponse.standardResponses.UNAUTHORIZED_ENVIRONMENT);
    })
    afterEach(() => {
        delete process.env.FAD_ENV_TYPE;
    });
})

const evnNA = 'impl1'
const evn = 'test4'
const serviceEnvs = [
    {
        "env": "test0",
        "label": "Test 0"
    },
    {
        "env": "test1",
        "label": "Test 1"
    },
    {
        "env": "test2",
        "label": "Test 2"
    },
    {
        "env": "test3",
        "label": "Test 3"
    },
    {
        "env": "test4",
        "label": "Test 4"
    },
    {
        "env": "test5",
        "label": "Test 5"
    }
]
