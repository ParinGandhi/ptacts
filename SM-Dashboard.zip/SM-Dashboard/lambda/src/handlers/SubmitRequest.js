/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * This handler performs the following tasks:
 *
 *  - Prepare the request to be sent to the external REST endpoint
 *  - Log a transaction record for future auditing purpose
 *  - Validate the request to ensure that its all good
 *  - Retrieve an API key from secret store and append it to the request header
 *  - Issue a call to the external REST service
 *  - Handle the REST call results
 *
 * @author theanh.ha
 */

let logRequest = require("../services/LogRequest");
let logResponse = require("../services/LogResponse");
let logErrorResponse = require("../services/LogErrorResponse");
let invokeRestAPI = require("../services/InvokeRestAPI");
let handleSuccess = require("../common/SuccessHandler");
let handleError = require("../common/ErrorHandler");
let getService = require("../services/GetService");
let getFromParamStore = require("../services/GetFromParamStore");
let getUserCognitoGroups = require("../services/GetCognitoUserGroups");
let verifyCapabilityEnabled = require("../services/VerifyCapabilityEnabled");
const validateUserServiceAccess = require("../utils/ValidateUserServiceAccess");
let verifyUserCapabilityAccess = require("../services/VerifyUserCapabilityAccess");
let verifyAccessToken = require("../services/VerifyAccessToken");
let injectCredentials = require("../services/InjectCredentials");
let injectCorrelationId = require("../services/InjectCorrelationId");
const DashboardErrorResponse = require('../common/DashboardErrorResponse');
const capabilityTypes = require('../common/CapabilityTypes');
let AWS = require("aws-sdk");
const _ = require('lodash');
const correlationIdHeaderKey = "x-correlation-id";
const correlationIdPrefix = "dashboard-";
let validateEnv = require("../utils/ValidateEnv")

exports.handler = async (event, context) => {
    let correlationId = null;
    let currentUser = null
    let cognitoUserId = null
    return verifyAccessToken(event.headers["access-token"])
        .then(([userName, cognitoId]) => {
            currentUser = userName;
            cognitoUserId = cognitoId
            return userName
        })
        .then( userName => verifyUserCapabilityAccess(userName, capabilityTypes.api_request_capability, cognitoUserId))
        .then(username => prepareRequest(username, event, cognitoUserId))
        .then(logRequest)
        .then(validateRequest)
        .then(injectCredentials)
        .then(injectCorrelationId)
        .then(request => {
            correlationId = _.get(request, ['headers', 'x-correlation-id']);
            return request;
        })
        .then(invokeRestAPI)
        .then(handleSuccess)
        .catch(error => handleError(error, correlationId))
};

function parseHeaders(headerArray) {
    const headers = {};
    if (!headerArray) {
        return headers;
    }
    for (const header of headerArray) {
        try {
            let [chaff, key, value] = header.trim().match(/^(.*?)\s*:\s*(.*)$/);
            headers[key.toLowerCase()] = value;
        } catch (e) {
            console.log('Unable to parse header', header, e);
        }
    }
    return headers;
}

async function prepareRequest(username, event, cognitoUserId) {
    event.body = JSON.parse(event.body);
    console.log("Preparing request for: " + JSON.stringify(_.pick(event.body, ['service', 'application', 'url', 'method', 'path'])));
    const service = await getService(event.body.application, event.body.service);
    await checkUserServiceAccess(cognitoUserId, service.allowed_roles)
    await validateEnv(event.body.serviceEnv['env'], service.environments)
    let path =  (_.template(service.root_url)(event.body.serviceEnv) + event.body.path);
    const request = {
        application: event.body.application,
        service: event.body.service,
        environment: event.body.serviceEnv,
        environments: service.environments,
        downstreamUrlPath: event.body.path,
        url: path,
        method: service.method,
        _userPath: event.body.path,
        _apiKeyName: service.api_key_name,
        _validPathRegex: service.path_regex,
        headers: parseHeaders(event.body.headers),
        body: event.body.body,
        path: event.body.path,
        formmodel:event.body.formmodel,
        username: username,
        _overriddenApiKeyHeaderName: service.overridden_api_key_header_name
    };

    if (!service.api_key_name) {
        request._oauth = service.oauth
    }

    return Promise.resolve(request)
}

async function checkUserServiceAccess(currentUser, serviceAllowedRoles) {
    return new Promise(async (resolve, reject) => {
        try {
            let allowed_roles_str = await getFromParamStore(capabilityTypes.api_request_capability.param_store_key)
            let allowed_roles = JSON.parse(allowed_roles_str)
            let userRoles = await getUserCognitoGroups(currentUser)
            if (!validateUserServiceAccess(serviceAllowedRoles, allowed_roles['allowedRoles'], userRoles['roles'])) {
                return reject(DashboardErrorResponse.standardResponses.USER_ACCESS_DENIED);
            }
        } catch (e) {
            console.warn(`Error verifying user access ${e}`)
            return reject(DashboardErrorResponse.standardResponses.USER_ACCESS_DENIED);
        }
        resolve(true)
    })
}

function validateRequest(request) {
    console.log('Validating request');
    if (!_.isString(request._userPath)) {
        return Promise.reject(getBadRequestError("Path must be a string"));
    }
    if (!new RegExp(request._validPathRegex).test(request._userPath)) {
        return Promise.reject(getBadRequestError("Invalid path"));
    }

    //Get the x-correlation-id from the header
    let correlationId = request.headers[correlationIdHeaderKey];

    //If the x-correlation-id is passed and does not start with dashboard-, reject the request
    if (correlationId && !correlationId.startsWith(correlationIdPrefix)) {
        let errorMessage = `x-correlation-id: ${correlationId} does not start with ${correlationIdPrefix}`;
        console.error(`Validating request: ${errorMessage}`);
        return Promise.reject(getBadRequestError(`Invalid x-correlation-id; ${errorMessage}`));
    }
    return Promise.resolve(request);
}

function getBadRequestError(msg) {
    let errMsg = DashboardErrorResponse.standardResponses.BAD_REQUEST;
    errMsg.message = msg;

    return errMsg;
}
