/**
 * ███████╗███╗   ███╗                                                      
 * ██╔════╝████╗ ████║                                                      
 * ███████╗██╔████╔██║                                                      
 * ╚════██║██║╚██╔╝██║                                                      
 * ███████║██║ ╚═╝ ██║                                                      
 * ╚══════╝╚═╝     ╚═╝                                                      
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗ 
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ 
 * 
 * This is a health check service
 * 
 * @author theanh.ha 
 */

exports.handler = async (event, context) => {
   let result = {}

   // Check the database
   await checkDynamoDB().then(dbResult => {
        result.dynamo = "OK"
   }).catch(error => {
       result.dynamo = error
   })

   // Check parameter store
   console.log("Check param store")
   await checkParameterStore().then(paramValue => {
       result.paramStore = paramValue
   }).catch(error => {
       result.paramStore = error
   })

   console.log("Done check")

   return {
       statusCode: 200,
       body: JSON.stringify(result)
   }

}

function checkDynamoDB() {
    let getAllServices = require("../services/GetAllServices")
    return getAllServices()
}

function checkParameterStore() {
    let getFromParamStore = require("../services/GetFromParamStore")
    return getFromParamStore("TEST_KEY")
}


