/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * This handler performs the following tasks:
 *
 *  - Prepare the request to be sent to the external REST endpoint
 *  - Log a transaction record for future auditing purpose
 *  - Issue a call to the ref data endpoint
 *  - Handle the REST call results
 *
 */

let invokeRefDataEndpoint = require("../services/InvokeRefDataEndpoint");
let handleSuccess = require("../common/SuccessHandler");
let handleError = require("../common/ErrorHandler");
let getService = require("../services/GetService");
let verifyAccessToken = require("../services/VerifyAccessToken");
let verifyUserCapabilityAccess = require("../services/VerifyUserCapabilityAccess");
const checkUserRefDataAccess = require("../utils/CheckUserRefDataAccess")
const getFromParamStore = require("../services/GetFromParamStore");
let uuidv1 = require('uuid/v1');
const logTypes = require('../common/LogTypes');
const capabilityTypes = require('../common/CapabilityTypes');
let AWS = require("aws-sdk");
const _ = require('lodash');
let validateEnv = require("../utils/ValidateEnv")

exports.handler = async (event, context) => {
    let correlationId = null;
    let cognitoUserId = null
    return verifyAccessToken(event.headers["access-token"])
        .then( ([userName, cognitoId]) => {
            cognitoUserId = cognitoId
            return userName
        })
        .then( userName => verifyUserCapabilityAccess(userName, capabilityTypes.ref_data_browsing_capability, cognitoUserId))
        .then(username => prepareRequest(username, event, cognitoUserId))
        .then(log)
        .then(request => injectCookie(request))
        .then(invokeRefDataEndpoint)
        .then(handleSuccess)
        .catch(error => handleError(error, correlationId))
};

function parseHeaders(headerArray, envCookies) {
    const headers = {};
    if (!headerArray) {
        return headers;
    }
    for (const header of headerArray) {
        try {
            let [chaff, key, value] = header.trim().match(/^(.*?)\s*:\s*(.*)$/);
            headers[key.toLowerCase()] = value;
        } catch (e) {
            console.log('Unable to parse header', header, e);
        }
    }
    return headers;
}

async function prepareRequest(username, event, cognitoUserId) {
    event.body = JSON.parse(event.body);
    console.log("Preparing request for: " + JSON.stringify(_.pick(event.body, ['service', 'application', 'url', 'method', 'path'])));
    const service = await getService(event.body.application, event.body.service);
    await checkUserRefDataAccess(cognitoUserId, service.allowed_roles)
    await validateEnv(event.body.serviceEnv['env'], service.environments)
    let path = (_.template(service.root_url)(event.body.serviceEnv) + event.body.path);
    const request = {
        application: event.body.application,
        service: event.body.service,
        environment: event.body.serviceEnv,
        environments: service.environments,
        downstreamUrlPath: event.body.path,
        url: path,
        method: event.body.method,
        headers: parseHeaders(event.body.headers),
        body: event.body.body,
        username: username
    };

    return Promise.resolve(request)
}

async function injectCookie(request) {
    let envCookie = "";
    try {
        let paramStoreKey = _.find(request.environments, (tenv => tenv.env === request.environment['env']))['env_cookies']
        envCookie = await getFromParamStore(paramStoreKey);
    } catch (e) {
        console.warn(`No param store cookie set for ${request.environment['env']} environment`)
    }
    request.headers.Cookie = envCookie;
    return request
}

async function log(request) {
    console.log('Writing refdata request audit log to DynamoDB');
    const client = new AWS.DynamoDB.DocumentClient({convertEmptyValues: true});
    request.logid = uuidv1();
    let timeStamp = new Date().toISOString();

    let params = {
        TableName: process.env.FAD_DYNAMODB_TABLE_LOGS,
        Item: {
            id: request.logid,
            log_type: logTypes.ref_data_request,
            user: request.username,
            application: request.application,
            service: request.service,
            request_environment: request.environment['env'],
            url: request.url,
            method: request.method,
            request_headers: request.headers,
            creationDateTime: timeStamp,
            logType_creationDateTime: logTypes.ref_data_request + "#" + timeStamp
        },
    };
    return client.put(params).promise().then(data => request);
}
