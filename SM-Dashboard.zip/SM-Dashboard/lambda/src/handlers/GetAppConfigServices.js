/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Retrieve all available `Application Config s3 buckets` this Service Management Dashboard
 * application supports. Please note that only Read-Only services are currently
 * supported.
 */

const capabilityTypes = require('../common/CapabilityTypes');
let getFromParamStore = require("../services/GetFromParamStore");
let getAllAppConfigServices = require("../services/GetAllAppConfigServices")
let filterAllowedServices = require("../services/FilterAllowedServices")
let verifyAccessToken = require("../services/VerifyAccessToken")
let handleSuccess = require("../common/SuccessHandler")
let handleError = require("../common/ErrorHandler")
let _ = require("lodash")

exports.handler = async (event, context) => {
    console.log('GetAppConfigServices called');
    let currentUser = null
    let cognitoUserId = null
    return verifyAccessToken(event.headers["access-token"])
        .then(([userName, cognitoId]) => {
            currentUser = userName;
            cognitoUserId = cognitoId
            return userName;
        })
        .then(getAllAppConfigServices)
        .then(groupedAppServices => filterAllowedServices(groupedAppServices, cognitoUserId, capabilityTypes.app_config_management_capability.param_store_key))
        .then(groupedAppServices => applyEnvActiveColor(groupedAppServices))
        .then(handleSuccess)
        .catch(handleError);
}


async function applyEnvActiveColor(groupedServices) {
    let inActiveColorMap = {}
    let active = {
        blue: 'green',
        green: 'blue'
    }
    for (let app of groupedServices['applications']) {
        for (let entry of app['services']) {
            for (let env of entry.environments) {
                try {
                    if (inActiveColorMap[`/${_.toLower(app['name'])}/${env['env']}/environment_color`]) {
                        let color = inActiveColorMap[`/${_.toLower(app['name'])}/${env['env']}/environment_color`]
                        env.active_bucket_color = active[color] != null ? active[color] : ""
                    } else {
                        let color = await getFromParamStore(`/${_.toLower(app['name'])}/${env['env']}/environment_color`);
                        inActiveColorMap[`/${_.toLower(app['name'])}/${env['env']}/environment_color`] = color
                        env.active_bucket_color = active[color] != null ? active[color] : ""
                    }
                } catch (e) {
                    console.warn(`No param store property set for ${_.toLower(app['name'])}/${env['env']} environment color`)
                }
            }
        }
    }
    return groupedServices
}
