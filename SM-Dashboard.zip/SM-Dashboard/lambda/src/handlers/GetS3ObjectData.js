/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Retrieve file data of an s3 object
 */

let uuidv1 = require('uuid/v1');
const logTypes = require('../common/LogTypes');
const capabilityTypes = require('../common/CapabilityTypes');
const DashboardErrorResponse = require('../common/DashboardErrorResponse');
const validateUserServiceAccess = require("../utils/ValidateUserServiceAccess");
const getFromParamStore = require("../services/GetFromParamStore");
const getUserCognitoGroups = require("../services/GetCognitoUserGroups");
let validateEnv = require("../utils/ValidateEnv")
let getService = require("../services/GetService");
let verifyUserCapabilityAccess = require("../services/VerifyUserCapabilityAccess");
let verifyAccessToken = require("../services/VerifyAccessToken")
let handleSuccess = require("../common/SuccessHandler")
let handleError = require("../common/ErrorHandler")
let _ = require("lodash")
let path = require('path')
const AWS = require('aws-sdk');
const s3 = new AWS.S3({apiVersion: '2006-03-01'});

exports.handler = async (event, context) => {
    console.log('GetS3ObjectData called');
    let currentUser = null
    let requestRef = null
    let cognitoUserId = null
    return verifyAccessToken(event.headers["access-token"])
        .then(([userName, cognitoId]) => {
            currentUser = userName;
            cognitoUserId = cognitoId
            return [userName, cognitoId];
        })
        .then( ([userName, cognitoId]) => verifyUserCapabilityAccess(userName, capabilityTypes.app_config_management_capability, cognitoId))
        .then(username => prepareRequest(username, event, cognitoUserId))
        .then(request => {
            requestRef = request
            return request;
        })
        .then(log)
        .then(async (request) => {
            const params = {
                Bucket: request.bucketName,
                Key: request.s3Key,
            };
            return s3.getObject(params).promise();
        })
        .then(promisedData => prepareResponse(promisedData, requestRef))
        .then(handleSuccess)
        .catch(handleError);
}


function prepareResponse(promisedData, request) {
    let dataText = promisedData.Body.toString('ascii')
    let fData = {
        data: dataText,
        lastModified:promisedData.LastModified,
        contentLength:promisedData.ContentLength,
        fileType:promisedData.ContentType,
        fileExtension:path.extname(request.s3Key),
        writeAccess:request.writeAccess
    }
    return {
        fileData: fData,
    };
}

async function prepareRequest(username, event, cognitoUserId) {
    event.body = JSON.parse(event.body);
    const service = await getService(event.body.application, event.body.service);
    await verifyExclusionListAccess(event.body.s3Key, service.s3_object_exclusion_list)
    await checkUserGetS3ObjectAccess(cognitoUserId, service.allowed_roles)
    await validateEnv(event.body.serviceEnv['env'], service.environments)
    let bucketName = _.template(service.s3_bucket_name)(event.body.serviceEnv);
    console.log("Preparing to get s3 object data: " + JSON.stringify(_.pick(event.body, ['bucketName', 'prefix'])));
    const request = {
        application: event.body.application,
        service: event.body.service,
        environment: event.body.serviceEnv,
        environments: service.environments,
        bucketName: bucketName,
        s3Key: event.body.s3Key,
        username: username,
        writeAccess: await checkUserGetS3ObjectWriteAccess(cognitoUserId, service.required_write_access_roles)
    };
    return Promise.resolve(request)
}

function checkUserGetS3ObjectAccess(currentUser, serviceAllowedRoles) {
    return new Promise(async (resolve, reject) => {
        try {
            let allowed_roles_str = await getFromParamStore(capabilityTypes.app_config_management_capability.param_store_key)
            let allowed_roles = JSON.parse(allowed_roles_str)
            let userRoles = await getUserCognitoGroups(currentUser)

            if (!validateUserServiceAccess(serviceAllowedRoles, allowed_roles['allowedRoles'], userRoles['roles'])) {
                return reject(DashboardErrorResponse.standardResponses.USER_ACCESS_DENIED);
            }
        } catch (e) {
            console.warn(`Error verifying user access ${e}`)
            return reject(DashboardErrorResponse.standardResponses.USER_ACCESS_DENIED);
        }
        resolve(true)
    })
}

function verifyExclusionListAccess(s3Key, exclusionList){
    _.forEach(exclusionList, fileName => {
        if(s3Key.endsWith(fileName)){
            throw DashboardErrorResponse.standardResponses.S3_OBJECT_ACCESS_RESTRICTED
        }
    })
}

function checkUserGetS3ObjectWriteAccess(currentUser, serviceAllowedRoles) {
    return new Promise(async (resolve, reject) => {
        try {
            let allowed_roles_str = await getFromParamStore(capabilityTypes.app_config_management_capability.param_store_key)
            let allowed_roles = JSON.parse(allowed_roles_str)
            let userRoles = await getUserCognitoGroups(currentUser)

            if (!validateUserServiceAccess(serviceAllowedRoles, allowed_roles['allowedRoles'], userRoles['roles'])) {
                return resolve(false);
            }
        } catch (e) {
            console.warn(`Error verifying user write access ${e}`)
            return resolve(false);
        }
        return resolve(true)
    })
}

function log(request) {
    console.log('Writing GetS3Data request to dynamoDB');
    const client = new AWS.DynamoDB.DocumentClient({convertEmptyValues: true});
    request.logid = uuidv1();
    let timeStamp = new Date().toISOString();

    let params = {
        TableName: process.env.FAD_DYNAMODB_TABLE_LOGS,
        Item: {
            id: request.logid,
            log_type: logTypes.app_config_get_s3_object,
            user: request.username,
            application: request.application,
            service: request.service,
            request_environment: request.environment['env'],
            s3Key: request.s3Key,
            bucket_name: request.bucketName,
            creationDateTime: timeStamp,
            logType_creationDateTime: logTypes.app_config_get_s3_object + "#" + timeStamp
        },
    };
    return client.put(params).promise().then(data => request);
}
