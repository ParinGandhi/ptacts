/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Retrieve all available `external ref data services` this Service Management Dashboard
 * application supports. Please note that only Read-Only services are currently
 * supported.
 */

const capabilityTypes = require('../common/CapabilityTypes');
let getAllRefDataServices = require("../services/GetAllRefDataServices")
let filterAllowedServices = require("../services/FilterAllowedServices")
let verifyAccessToken = require("../services/VerifyAccessToken")
let handleSuccess = require("../common/SuccessHandler")
let handleError = require("../common/ErrorHandler")

exports.handler = async (event, context) => {
    console.log('GetRefDataServices called');
    let currentUser = null
    let cognitoUserId = null
    return verifyAccessToken(event.headers["access-token"])
        .then(([userName, cognitoId]) => {
            currentUser = userName;
            cognitoUserId = cognitoId
            return userName;
        })
        .then(getAllRefDataServices)
        .then(groupedAppServices => filterAllowedServices(groupedAppServices, cognitoUserId, capabilityTypes.ref_data_browsing_capability.param_store_key))
        .then(handleSuccess)
        .catch(handleError);
}
