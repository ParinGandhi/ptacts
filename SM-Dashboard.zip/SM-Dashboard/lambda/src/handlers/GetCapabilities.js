/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Retrieve all available `external ref data services` this Service Management Dashboard
 * application supports. Please note that only Read-Only services are currently
 * supported.
 */

const capabilityTypes = require('../common/CapabilityTypes');
let verifyAccessToken = require("../services/VerifyAccessToken")
let handleSuccess = require("../common/SuccessHandler")
let handleError = require("../common/ErrorHandler")
const getFromParamStore = require("../services/GetFromParamStore");
const DashboardErrorResponse = require('../common/DashboardErrorResponse');
const _ = require('lodash');
const getUserCognitoGroups = require("../services/GetCognitoUserGroups");

exports.handler = async (event, context) => {
    console.log('GetCapabilities called');
    return verifyAccessToken(event.headers["access-token"])
        .then(compileCapabilities)
        .then(prepareResponse)
        .then(handleSuccess)
        .catch(handleError);
}

function prepareResponse(capabilityList) {
    return {
        capabilityList: capabilityList,
    };
}

function compileCapabilities([userName, cognitoId]) {
    let envCapabilities = []
    return new Promise(async (resolve, reject) => {
        let userCognitoRoles = await getUserCognitoGroups(cognitoId);
        for (let cap of capabilityTypes.capabilities) {
            try {
                let capStatus = await getFromParamStore(cap.param_store_key);
                let capStatusObj = JSON.parse(capStatus)
                if (capStatusObj.enabled) {
                    for (let capRole of capStatusObj.allowedRoles) {
                        if (_.includes(userCognitoRoles.roles, capRole)) {
                            let fItem = _.omit(cap, ['param_store_key']);
                            fItem['status'] = "ON"
                            envCapabilities.push(fItem);
                            break
                        }
                    }
                }
            } catch (e) {
                console.warn(`No param store property set for ${cap.param_store_key} capability`)
            }
        }
        resolve(envCapabilities)
    })
}
