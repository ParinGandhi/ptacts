/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Retrieve all available `external services` this Service Management Dashboard
 * application supports. Please note that only Read-Only services are currently
 * supported.
 *
 * @author theanh.ha
 */

const capabilityTypes = require('../common/CapabilityTypes');
let getAllServices = require("../services/GetAllServices")
let filterAllowedServices = require("../services/FilterAllowedServices")
let verifyAccessToken = require("../services/VerifyAccessToken")
let handleSuccess = require("../common/SuccessHandler")
let handleError = require("../common/ErrorHandler")

exports.handler = async (event, context) => {
    console.log('GetServices called');
    let currentUser = null
    let cognitoUserId = null
    return verifyAccessToken(event.headers["access-token"])
        .then(([userName, cognitoId]) => {
            currentUser = userName;
            cognitoUserId = cognitoId
            return userName;
        })
        .then(getAllServices)
        .then(groupedAppServices => filterAllowedServices(groupedAppServices, cognitoUserId, capabilityTypes.api_request_capability.param_store_key))
        .then(handleSuccess)
        .catch(handleError);
}
