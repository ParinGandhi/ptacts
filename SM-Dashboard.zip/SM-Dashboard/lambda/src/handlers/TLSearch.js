/**
 *
 * Search by correlation id handler
 *
 * @param request - the request object
 *
 */

let handlerError = require("../common/ErrorHandler")
let handleSuccess = require("../common/SuccessHandler")
let listDirContents = require("../services/ListDirectoryFileContents")
let sortFileContents = require("../services/SortFileContents")
let verifyUserCapabilityAccess = require("../services/VerifyUserCapabilityAccess");
let verifyAccessToken = require("../services/VerifyAccessToken")
const AWS = require("aws-sdk");
const uuidv1 = require('uuid/v1');
const logTypes = require('../common/LogTypes');
const capabilityTypes = require('../common/CapabilityTypes');
const bucket = process.env.FAD_TL_BUCKET_NAME
const directoryRoot = process.env.FAD_TL_DIRECTORY

exports.handler = (event) => {
    return verifyAccessToken(event.headers["access-token"])
        .then( ([userName, cognitoId]) => verifyUserCapabilityAccess(userName, capabilityTypes.transaction_log_search_capability, cognitoId))
        .then(async (username) => {
            try {
                event.body = JSON.parse(event.body)
            } catch (e) {
                await log({
                    username: username,
                    query: event.body,
                });
                throw e;
            }
            await log({
                username: username,
                query: event.body,
            });
            const correlationId = event.body.correlationId;
            const directoryFullPath = directoryRoot + '/' + correlationId + '/';
            console.log("Searching transaction logs for correlationId: " + correlationId);

            return listDirContents(bucket, directoryFullPath)
        })
        .then(sortFileContents)
        .then(prepareResponse)
        .then(handleSuccess)
        .catch(handlerError)
}

function prepareResponse(sortedArray) {
    return {
        logs: sortedArray,
    };
}

async function log(object) {
    console.log('Writing transaction log search audit log to DynamoDB');
    const client = new AWS.DynamoDB.DocumentClient({convertEmptyValues: true});
    let timeStamp = new Date().toISOString();

    let params = {
        TableName: process.env.FAD_DYNAMODB_TABLE_LOGS,
        Item: {
            id: uuidv1(),
            log_type: logTypes.transaction_log_search,
            user: object.username,
            query: object.query,
            creationDateTime: timeStamp,
            logType_creationDateTime: logTypes.transaction_log_search + "#" + timeStamp
        },
    };
    return client.put(params).promise();
}
