/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Reset password using temporary code
 *
 * @param request - the request object
 *
 * @author theanh.ha
 */

 let performPasswordReset = require("../services/PerformPasswordReset")
let handleError = require("../common/ErrorHandler")
let handleSuccess = require("../common/SuccessHandler")

exports.handler = (event) => {
    event.body = JSON.parse(event.body)

    return performPasswordReset(event.body.username, event.body.resetCode, event.body.newPassword)
        .then(handleSuccess)
        .catch(handleError)
}
