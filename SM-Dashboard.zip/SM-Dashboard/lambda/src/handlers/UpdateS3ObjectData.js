/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Updates file data of an s3 object
 */

let uuidv1 = require('uuid/v1');
const logTypes = require('../common/LogTypes');
const capabilityTypes = require('../common/CapabilityTypes');
const DashboardErrorResponse = require('../common/DashboardErrorResponse');
const validateUserServiceAccess = require("../utils/ValidateUserServiceAccess")
const getFromParamStore = require("../services/GetFromParamStore");
const getUserCognitoGroups = require("../services/GetCognitoUserGroups");
let validateEnv = require("../utils/ValidateEnv")
let getService = require("../services/GetService");
let verifyUserCapabilityAccess = require("../services/VerifyUserCapabilityAccess");
let verifyAccessToken = require("../services/VerifyAccessToken")
let handleSuccess = require("../common/SuccessHandler")
let handleError = require("../common/ErrorHandler")
let _ = require("lodash")
const AWS = require('aws-sdk');
const s3 = new AWS.S3({apiVersion: '2006-03-01'});

exports.handler = async (event, context) => {
    console.log('UpdateS3ObjectData called');
    let currentUser = null
    let cognitoUserId = null
    return verifyAccessToken(event.headers["access-token"])
        .then( ([userName, cognitoId]) => {
            currentUser = userName;
            cognitoUserId = cognitoId
            return userName;
        })
        .then(userName => verifyUserCapabilityAccess(userName, capabilityTypes.app_config_management_capability, cognitoUserId))
        .then(username => prepareRequest(username, event, cognitoUserId))
        .then(log)
        .then(async (request) => {
            const params = {
                Body: request.fileData,
                Bucket: request.bucketName,
                Key: request.s3Key,
            };
            return  s3.headObject({
                    Bucket: request.bucketName,
                    Key: request.s3Key,
                })
                .promise()
                .then(
                    (metadata) => {
                        return s3.putObject(params).promise();
                    },
                    (err) => {
                        if (err.code === 'NotFound') {
                            throw DashboardErrorResponse.standardResponses.S3_OBJECT_NOT_FOUND
                        }
                        throw err;
                    }
                );
        })
        .then(handleSuccess)
        .catch(handleError);
}

async function prepareRequest(username, event, cognitoUserId) {
    event.body = JSON.parse(event.body);
    const service = await getService(event.body.application, event.body.service);
    await checkUserUpdateS3ObjectAccess(cognitoUserId, service.required_write_access_roles)
    await validateEnv(event.body.serviceEnv['env'], service.environments)
    let bucketName = _.template(service.s3_bucket_name)(event.body.serviceEnv);
    console.log("Preparing to update s3 object data: " + JSON.stringify(_.pick(event.body, ['bucketName', 'prefix'])));
    const request = {
        application: event.body.application,
        service: event.body.service,
        environment: event.body.serviceEnv,
        environments: service.environments,
        bucketName: bucketName,
        s3Key: event.body.s3Key,
        fileData: event.body.fileData,
        username: username
    };
    return Promise.resolve(request)
}

function checkUserUpdateS3ObjectAccess(currentUser, serviceAllowedRoles) {
    return new Promise(async (resolve, reject) => {
        try {
            let allowed_roles_str = await getFromParamStore(capabilityTypes.app_config_management_capability.param_store_key)
            let allowed_roles = JSON.parse(allowed_roles_str)
            let userRoles = await getUserCognitoGroups(currentUser)

            if (!validateUserServiceAccess(serviceAllowedRoles, allowed_roles['allowedRoles'], userRoles['roles'])) {
                return reject(DashboardErrorResponse.standardResponses.USER_ACCESS_DENIED);
            }
        } catch (e) {
            console.warn(`Error verifying user access ${e}`)
            return reject(DashboardErrorResponse.standardResponses.USER_ACCESS_DENIED);
        }
        resolve(true)
    })
}

function log(request) {
    console.log('Writing UpdateS3Object request to dynamoDB');
    const client = new AWS.DynamoDB.DocumentClient({convertEmptyValues: true});
    request.logid = uuidv1();
    let timeStamp = new Date().toISOString();

    let params = {
        TableName: process.env.FAD_DYNAMODB_TABLE_LOGS,
        Item: {
            id: request.logid,
            log_type: logTypes.app_config_update_s3_object,
            user: request.username,
            application: request.application,
            service: request.service,
            request_environment: request.environment['env'],
            s3Key: request.s3Key,
            bucket_name: request.bucketName,
            creationDateTime: timeStamp,
            logType_creationDateTime: logTypes.app_config_update_s3_object + "#" + timeStamp
        },
    };
    return client.put(params).promise().then(data => request);
}
