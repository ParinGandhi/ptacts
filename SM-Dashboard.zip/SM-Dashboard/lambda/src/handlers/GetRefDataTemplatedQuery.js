/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Retrieve all available `external ref data services` this Service Management Dashboard
 * application supports. Please note that only Read-Only services are currently
 * supported.
 */

const capabilityTypes = require('../common/CapabilityTypes');
let getRefDataQueryTemplateServices = require("../services/GetRefDataQueryTemplateServices")
let verifyAccessToken = require("../services/VerifyAccessToken") 
let verifyUserCapabilityAccess = require("../services/VerifyUserCapabilityAccess");
let handleSuccess = require("../common/SuccessHandler")
let handleError = require("../common/ErrorHandler")
const _ = require('lodash');
let uuidv1 = require('uuid/v1');
const logTypes = require('../common/LogTypes');
let AWS = require("aws-sdk");

exports.handler = async (event, context) => {
    console.log('GetRefDataQueryTemplateServices called');
    let cognitoUserId = null
    return verifyAccessToken(event.headers["access-token"])
        .then( ([userName, cognitoId]) => {
            cognitoUserId = cognitoId
            return userName
        })
        .then( userName => verifyUserCapabilityAccess(userName, capabilityTypes.ref_data_browsing_capability, cognitoUserId))
        .then(username => prepareRequest(cognitoUserId, event))
        .then(log)
        .then(getRefDataQueryTemplateServices)
        .then(prepareResponse)
        .then(handleSuccess)
        .catch(handleError);
}

async function prepareRequest(username, event) {
    event.body = JSON.parse(event.body);
    console.log("Preparing request for: " + JSON.stringify(_.pick(event.body, ['application', 'queryFormModel'])));
    const request = {
        application: event.body.application,
        environment: event.body.serviceEnv,
        queryFormModel: event.body.queryFormModel,
        username: username
    };
    return Promise.resolve(request)
}

function prepareResponse(templatedQuery) {
    return {
        templatedQuery: templatedQuery,
    };
}

async function log(request) {
    console.log('Writing refdata template request audit log to DynamoDB');
    const client = new AWS.DynamoDB.DocumentClient({convertEmptyValues: true});
    request.logid = uuidv1();
    let timeStamp = new Date().toISOString();

    let params = {
        TableName: process.env.FAD_DYNAMODB_TABLE_LOGS,
        Item: {
            id: request.logid,
            log_type: logTypes.ref_data_templated_query_request,
            user: request.username,
            application: request.application,
            services: Object.keys(request.queryFormModel),
            request_environment: request.environment['env'],
            queryFormModel: request.queryFormModel,
            creationDateTime: timeStamp,
            logType_creationDateTime: logTypes.ref_data_templated_query_request + "#" + timeStamp
        },
    };
    return client.put(params).promise().then(data => request);
}
