/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Login handler
 *
 * @param request - the request object
 *
 * @author raja.sekhar.dasa
 */


let handleError = require("../common/ErrorHandler")
let handleSuccess = require("../common/SuccessHandler")
let performLogin = require("../services/PerformLogin")
let preAuthenticate = require("../services/PreAuthenticate")

const _ = require('lodash');
const AWS = require("aws-sdk");
const uuidv1 = require('uuid/v1');
const logTypes = require('../common/LogTypes');

exports.handler = (event) => {
    event.body = JSON.parse(event.body)

    return preAuthenticate(event.body.username, event.body.password)
        .then(result => performLogin(event.body.username, event.body.password, event.body.otp))
        .then(result => logSuccess(result, event.body.username))
        .catch(error => logError(error, _.get(event, 'body.username', '(no username)')))
        .then(handleSuccess)
        .catch(handleError)
}

async function logSuccess(result, username) {
    await log({
        result: 'success',
        username: username,
    });
    return result;
}

async function logError(error, username) {
    await log({
        result: 'rejected',
        username: username,
    })
    throw error;
}

async function log(object) {
    console.log('Writing login audit log to DynamoDB');
    const client = new AWS.DynamoDB.DocumentClient({convertEmptyValues: true});
    let timeStamp = new Date().toISOString();

    let params = {
        TableName: process.env.FAD_DYNAMODB_TABLE_LOGS,
        Item: {
            id: uuidv1(),
            log_type: logTypes.login,
            user: object.username,
            result: object.result,
            creationDateTime: timeStamp,
            logType_creationDateTime: logTypes.login + "#" + timeStamp
        },
    };
    return client.put(params).promise();
}
