/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 
 * Lambda handler to list the names of files and folders of a S3 buckts.
 *
 * @author pavan.gaddam
 * @param request - the request object
 *
 */

let handlerError = require("../common/ErrorHandler")
let handleSuccess = require("../common/SuccessHandler")
let listDirectory = require("../services/ListDirectory")
let verifyUserCapabilityAccess = require("../services/VerifyUserCapabilityAccess");
let verifyAccessToken = require("../services/VerifyAccessToken")
let getService = require("../services/GetService");
const logTypes = require('../common/LogTypes');
const capabilityTypes = require('../common/CapabilityTypes');
const DashboardErrorResponse = require('../common/DashboardErrorResponse');
const validateUserServiceAccess = require("../utils/ValidateUserServiceAccess");
const getFromParamStore = require("../services/GetFromParamStore");
const getUserCognitoGroups = require("../services/GetCognitoUserGroups");
let validateEnv = require("../utils/ValidateEnv")
let uuidv1 = require('uuid/v1');
const _ = require('lodash');
const AWS = require('aws-sdk');

exports.handler = (event) => {
    let currentUser = null
    let cognitoUserId = null
    return verifyAccessToken(event.headers["access-token"])
        .then(([userName, cognitoId]) => {
            currentUser = userName;
            cognitoUserId = cognitoId
            return userName
        })
        .then( userName => verifyUserCapabilityAccess(userName, capabilityTypes.app_config_management_capability, cognitoUserId))
        .then(username => prepareRequest(username, event, cognitoUserId))
        .then(log)
        .then(listDirectory)
        .then(prepareResponse)
        .then(handleSuccess)
        .catch(handlerError)
}

function prepareResponse(sortedArray) {
    return {
        folderItems: sortedArray,
    };
}

async function prepareRequest(username, event, cognitoUserId) {
    event.body = JSON.parse(event.body);
    const service = await getService(event.body.application, event.body.service);
    await checkUserListS3DirectoryAccess(cognitoUserId, service.allowed_roles)
    await validateEnv(event.body.serviceEnv['env'], service.environments)
    let bucketName = _.template(service.s3_bucket_name)(event.body.serviceEnv);
    console.log("Preparing to retrieve bucket items: " + JSON.stringify(_.pick(event.body, ['bucketName', 'prefix'])));
    const request = {
        application: event.body.application,
        service: event.body.service,
        environment: event.body.serviceEnv,
        environments: service.environments,
        bucketName: bucketName,
        prefix: event.body.prefix,
        username: username
    };
    return Promise.resolve(request)
}

function checkUserListS3DirectoryAccess(currentUser, serviceAllowedRoles) {
    return new Promise(async (resolve, reject) => {
        try {
            let allowed_roles_str = await getFromParamStore(capabilityTypes.app_config_management_capability.param_store_key)
            let allowed_roles = JSON.parse(allowed_roles_str)
            let userRoles = await getUserCognitoGroups(currentUser)

            if (!validateUserServiceAccess(serviceAllowedRoles, allowed_roles['allowedRoles'], userRoles['roles'])) {
                return reject(DashboardErrorResponse.standardResponses.USER_ACCESS_DENIED);
            }
        } catch (e) {
            console.warn(`Error verifying user access ${e}`)
            return reject(DashboardErrorResponse.standardResponses.USER_ACCESS_DENIED);
        }
        resolve(true)
    })
}

function log(request) {
    console.log('Writing app config list directory items audit log to DynamoDB');
    const client = new AWS.DynamoDB.DocumentClient({convertEmptyValues: true});
    request.logid = uuidv1();
    let timeStamp = new Date().toISOString();

    let params = {
        TableName: process.env.FAD_DYNAMODB_TABLE_LOGS,
        Item: {
            id: request.logid,
            log_type: logTypes.app_config_list_s3_folder,
            user: request.username,
            application: request.application,
            service: request.service,
            request_environment: request.environment['env'],
            prefix: request.prefix,
            bucket_name: request.bucketName,
            creationDateTime: timeStamp,
            logType_creationDateTime: logTypes.app_config_list_s3_folder + "#" + timeStamp
        },
    };
    return client.put(params).promise().then(data => request);
}
