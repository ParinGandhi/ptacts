/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Change password handler
 *
 * @param request - the request object
 *
 * @author theanh.ha
 */

let handleError = require("../common/ErrorHandler")
let handleSuccess = require("../common/SuccessHandler")
let performPasswordChange = require("../services/PerformPasswordChange")

exports.handler = (event) => {
    event.body = JSON.parse(event.body)

    let username = event.body.username;
    let oldPassword = event.body.oldPassword;
    let newPassword = event.body.newPassword;

    return performPasswordChange(username, oldPassword, newPassword)
        .then(handleSuccess)
        .catch(handleError)
}


