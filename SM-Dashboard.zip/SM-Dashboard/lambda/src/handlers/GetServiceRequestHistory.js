/**
 *
 * Retrieve a users request history
 *
 * @param access-token - current users access token
 *
 */

let verifyAccessToken = require("../services/VerifyAccessToken")
let getQueryHistory = require("../services/GetUserQueryHistory")
let handleSuccess = require("../common/SuccessHandler")
let handleError = require("../common/ErrorHandler")

exports.handler = async (event, context) => {

    return verifyAccessToken(event.headers["access-token"])
        .then(([userName, cognitoId]) => {
            console.log('Calling GetUserQueryHistory...');
            return getQueryHistory(userName);
        })
        .then(prepareResponse)
        .then(handleSuccess)
        .catch(handleError);
}

function prepareResponse(requestHistory) {
    return {
        userRequestHistory: requestHistory,
    };
}
