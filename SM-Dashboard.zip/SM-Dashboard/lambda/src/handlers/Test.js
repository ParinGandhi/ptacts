let env = {
    name: "POC",
    type: "nonprod"
}

console.log(env.type)
