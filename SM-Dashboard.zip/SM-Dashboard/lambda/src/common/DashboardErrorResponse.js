/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 */

/**
 * Create a handled, non-redacted error response
 * @param statusCode HTTP status code
 * @param status Enum-like searchable text
 * @param message Natural language message
 * @constructor
 */
function DashboardErrorResponse(statusCode, status, message) {
    if (arguments.length === 0) {
        this.statusCode = 500;
        this.status = "INTERNAL_SERVER_ERROR";
        this.message = "An internal server error occurred.";
    } else {
        this.statusCode = statusCode;
        this.status = status;
        this.message = message;
    }
}
const standardResponses = {
    INTERNAL_SERVER_ERROR: new DashboardErrorResponse(),
    NEW_PASSWORD_REQUIRED: new DashboardErrorResponse(401, "NEW_PASSWORD_REQUIRED", "New password is required."),
    UNKNOWN: new DashboardErrorResponse(500, "UNKNOWN", "An error occurred"),
    PASSWORD_RESET_REQUIRED: new DashboardErrorResponse(401, "PASSWORD_RESET_REQUIRED", "Password reset is required."),
    UNAUTHORIZED: new DashboardErrorResponse(403, "UNAUTHORIZED", "Invalid username or password"),
    UNAUTHORIZED_ENVIRONMENT: new DashboardErrorResponse(403, "UNAUTHORIZED", "Unauthorized Environment Sent"),
    PASSWORD_CHANGE_REQUIRED: new DashboardErrorResponse(400, "PASSWORD_CHANGE_REQUEST_REQUIRED", "Submit a request to the system administrator to enable changing the password"),
    SAME_PASSWORD: new DashboardErrorResponse(400, "NEW_PASSWORD_REQUIRED", "The new password must be different from the old password"),
    INVALID_PASSWORD: new DashboardErrorResponse(400, "INVALID_PASSWORD", "Password is invalid, not met the password constraints"),
    USER_NOT_FOUND: new DashboardErrorResponse(400, "USER_NOT_FOUND", "Username is not found"),
    INVALID_VERIFICATION_CODE: new DashboardErrorResponse(400, "INVALID_VERIFICATION_CODE", "Invalid Verification Code"),
    BAD_REQUEST : new DashboardErrorResponse(400, "BAD_REQUEST", "Bad request"),
    USER_ACCESS_DENIED : new DashboardErrorResponse(403,"UNAUTHORIZED","User access denied"),
    CAPABILITY_DISABLED : new DashboardErrorResponse(403,"UNAUTHORIZED","Capability Disabled"),
    PARAMETER_NOT_FOUND : new DashboardErrorResponse(400,"PARAMETER NOT FOUND","Parameter store item not found"),
    S3_OBJECT_NOT_FOUND : new DashboardErrorResponse(400,"S3 OBJECT NOT FOUND","s3 object with supplied key does not exist"),
    S3_OBJECT_ACCESS_RESTRICTED : new DashboardErrorResponse(403,"S3 OBJECT ACCESS RESTRICTED","Access to the requested s3 object is not allowed")
};

DashboardErrorResponse.standardResponses = standardResponses;

module.exports = DashboardErrorResponse;
