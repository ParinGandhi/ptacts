const API_REQUEST_CAPABILITY = {
    name: "api_request_capability",
    label: "FFE API Invocations",
    param_store_key: `/smdashboard/${process.env.FAD_ENV_TYPE}/capabilities/api_request`,
    description: "Call FFE APIs",
    path: "/dashboard.html",
    role: "dashboard"
}
const REF_DATA_BROWSING_CAPABILITY = {
    name: "ref_data_browsing_capability",
    label: "Reference Data Browsing",
    param_store_key: `/smdashboard/${process.env.FAD_ENV_TYPE}/capabilities/ref_data_request`,
    description: "Reference Data Endpoints",
    path: "/refdataviewer.html",
    role: "refdata",
}
const TRANSACTION_LOG_SEARCH_CAPABILITY = {
    name: "transaction_log_search_capability",
    label: "Transaction Logs Search",
    param_store_key: `/smdashboard/${process.env.FAD_ENV_TYPE}/capabilities/transaction_log_search`,
    description: "Inspect Logs by Correlation ID",
    path: "/logviewer.html",
    role: "logs",
}
const APP_CONFIG_MANAGEMENT_CAPABILITY = {
    name: "app_config_management_capability",
    label: "FFE Application Configuration Management",
    param_store_key: `/smdashboard/${process.env.FAD_ENV_TYPE}/capabilities/app_config_management`,
    description: "Manage Application Configuration Files",
    path: "/appconfig.html",
    role: "appconfig",
}

module.exports = {
    api_request_capability: API_REQUEST_CAPABILITY,
    ref_data_browsing_capability:REF_DATA_BROWSING_CAPABILITY,
    transaction_log_search_capability:TRANSACTION_LOG_SEARCH_CAPABILITY,
    app_config_management_capability: APP_CONFIG_MANAGEMENT_CAPABILITY,
    capabilities: [
        API_REQUEST_CAPABILITY,
        APP_CONFIG_MANAGEMENT_CAPABILITY,
        REF_DATA_BROWSING_CAPABILITY,
        TRANSACTION_LOG_SEARCH_CAPABILITY
    ]
}
