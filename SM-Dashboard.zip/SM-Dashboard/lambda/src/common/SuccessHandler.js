/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Upon successful processing of the request, a successful response will
 * be formed using the `result` passed into this function and returned
 * back to the UI with a HTTP status code 200.
 *
 * @author theanh.ha
 */

const util = require('util');
const _ = require('lodash');

module.exports = (result) => {
    console.log("External call complete: ", result.status);
    let response = {
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": process.env.FAD_CORS_ALLOW_ORIGIN,
            "Access-Control-Expose-Headers": process.env.FAD_CORS_EXPOSE_HEADERS,
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache",
            "Expires": "0",
            "X-XSS-Protection": "1; mode=block",
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "SAMEORIGIN"
        },
        statusCode: 200,
        body: JSON.stringify(result)
    }

    return response;
}
