/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Handle error if there happens to be any. An error response will
 * be formed and returned back to the UI with HTTP status code 500 or 401 for unauthorized.
 *
 * @author theanh.ha
 */

const DashboardErrorResponse = require('./DashboardErrorResponse')

module.exports = async (error, correlationId) => {
    console.log('Handling error response');
    if (!(error instanceof DashboardErrorResponse)) {
        console.log('Unknown internal server error -- ' + error);
        error = DashboardErrorResponse.standardResponses.INTERNAL_SERVER_ERROR;
    }
    if (correlationId) {
        error.requestCorrelationId = correlationId;
    }

    // error is now guaranteed to be a DashboardErrorResponse
    return {
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": process.env.FAD_CORS_ALLOW_ORIGIN,
            "Access-Control-Expose-Headers": process.env.FAD_CORS_EXPOSE_HEADERS,
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache",
            "Expires": "0",
            "X-XSS-Protection": "1; mode=block",
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "SAMEORIGIN"
        },
        statusCode: error.statusCode,
        body: JSON.stringify(error),
    };
}
