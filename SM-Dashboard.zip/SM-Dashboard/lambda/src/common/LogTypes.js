const logTypes = {
    api_request: 'api_request',
    ref_data_request: 'ref_data_request',
    ref_data_templated_query_request: 'ref_data_templated_query_request',
    transaction_log_search: 'transaction_log_search',
    login: 'login',
    app_config_management_request: 'app_config_management_request',
    app_config_list_s3_folder: 'app_config_list_s3_folder',
    app_config_get_s3_object: 'app_config_get_s3_object',
    app_config_update_s3_object: 'app_config_update_s3_object',
};

module.exports = logTypes;
