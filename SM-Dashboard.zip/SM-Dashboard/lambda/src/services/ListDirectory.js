/**
 * Retrieves the contents of all files in an s3 directory
 *
 * @param bucketName - the s3 bucket name
 * @param directoryKey - the key of the s3 directory
 */

/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Lists the names of files and folders of a S3 buckts.
 *
 * @author pavan.gaddam
 * @param userName The loggedin user name
 * @param bucketName - the s3 bucket name
 *
 */
const logTypes = require('../common/LogTypes');
const DashboardErrorResponse = require('../common/DashboardErrorResponse');
const AWS = require('aws-sdk');
const s3 = new AWS.S3({apiVersion: '2006-03-01'});
let uuidv1 = require('uuid/v1');
const matchFolderPattern = /^.*[\\\/]/g;
let path = require('path')

module.exports = async (request, userName, bucketName) => {
    return new Promise(async (resolve, reject) => {
        const params = {
            Bucket: request.bucketName,
            Delimiter: "/"
        };
        if (request.prefix && request.prefix.trim().length > 0) {
            params.Prefix = request.prefix
        }
        let s3Objects
        try {
            s3Objects = await s3.listObjectsV2(params).promise();
            let items = s3Objects.Contents
                .filter(item => item.Key != request.prefix)
                .map(item => {
                    return {
                        s3Key: item.Key,
                        id: request.bucketName+ "/" + item.Key,
                        name: item.Key.replace(matchFolderPattern, ''),
                        serviceName: request.service,
                        prefix: "",
                        fileType: getFileType(item.Key),
                        fileExtension:path.extname(item.Key),
                        lastModified: item.LastModified,
                        size: item.Size
                    }
                })
            s3Objects.CommonPrefixes.forEach(folderItem => {
                items.push({
                    prefix: folderItem.Prefix,
                    id: request.bucketName + "/" + folderItem.Prefix,
                    name: getFolderName(folderItem.Prefix),
                    serviceName: request.service,
                    lastModified: null,
                    size: 0,
                    subFolders: []
                })
            })
            resolve(items)
        } catch (e) {
            console.log('Error while listing S3 object:', e)
            reject(DashboardErrorResponse.standardResponses.UNKNOWN);
        }
    })
}

const getFileType = (filename) => {
    if (filename.endsWith("/")) {
        return "folder"
    }
    const splitArray = filename.split('.')
    return splitArray.length > 1 ? splitArray.pop() : ""
}

const getFolderName = (fullPrefix) => {
    let folderName = fullPrefix
    if (folderName.endsWith("/")) {
        folderName = folderName.slice(0, -1)
    }
    folderName = folderName.replace(matchFolderPattern, '')
    return folderName.length > 1 ? `${folderName}/` : fullPrefix
}
