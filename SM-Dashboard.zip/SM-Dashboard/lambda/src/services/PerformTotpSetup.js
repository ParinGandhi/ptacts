/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 */

let AmazonCognitoIdentity = require('amazon-cognito-identity-js');
const DashboardErrorResponse = require('../common/DashboardErrorResponse');

let AWS = require('aws-sdk');
const friendlyDevideName = 'user_totp_auth-app'

module.exports = (secretcode, username, password) => {
    console.log('Performing complete otp setup')
    global.fetch = require('node-fetch');
    return new Promise(async (resolve, reject) => {
        let authenticationData = {
            Username: username,
            Password: password,
        };
        let poolData = {
            UserPoolId: process.env.FAD_COGNITO_POOL_ID,
            ClientId: process.env.FAD_COGNITO_APP_CLIENT_ID
        };
        let authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails(authenticationData);
        let userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
        let userData = {
            Username: username,
            Pool: userPool
        };
        let cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
        cognitoUser.authenticateUser(authenticationDetails, {
            onSuccess: function (result) {
                let accessToken = result.accessToken.jwtToken;
                cognitoUser.verifySoftwareToken(secretcode, friendlyDevideName, {
                    onSuccess: session => {
                        console.log('Auth App Verified');
                        cognitoUser.setUserMfaPreference(null, {
                            Enabled: true,
                            PreferredMfa: true
                        }, function (err, result) {
                            if (err) {
                                console.log(err);
                                return reject(new DashboardErrorResponse(
                                    403,
                                    "FAILED_SETUP_MFA_PREFERENCE",
                                    err
                                ));
                            } else {
                                console.log('Cognito authentication succeeded');
                                const response = {
                                    "status": "SUCCESS",
                                    "accessToken": accessToken
                                };
                                return resolve(response);
                            }
                        })
                    },
                    onFailure: err => {
                        console.log(err);
                        return reject(new DashboardErrorResponse(
                            403,
                            err.name,
                            err.message
                        ));
                    }
                });
            },
            onFailure: function (err) {
                return reject(new DashboardErrorResponse(
                    403,
                    "UNAUTHORIZED",
                    "Invalid username or password"
                ));
            },
            newPasswordRequired: function (userAttributes, requiredAttributes) {
                //we should never hit this
            }
        });

    })
}
