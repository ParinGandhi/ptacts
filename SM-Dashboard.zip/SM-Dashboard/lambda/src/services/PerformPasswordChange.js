/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Perform password change
 *
 * @param username
 * @param oldPassword
 * @param newPassword
 *
 * @author theanh.ha
 */

let AWS = require('aws-sdk');
let performLogin = require("../services/PerformLogin")
const DashboardErrorResponse = require('../common/DashboardErrorResponse');

module.exports = (username, oldPassword, newPassword) => {
    global.fetch = require('node-fetch');

    return new Promise(async (resolve, reject) => {
        // Try logging in first with the old password.
        // Only move forward if the status is "NEW_PASSWORD_REQUIRED"
        // Otherwise, reject!!!!
        // Note that a failure is always expected in this case!!!!!!
        console.log("Attempting to login with old password")
        performLogin(username, oldPassword)
            .then(unexpectedSuccess => {
                return reject(DashboardErrorResponse.standardResponses.PASSWORD_CHANGE_REQUIRED);
            })
            .catch(expectedFailure => {
                if (oldPassword === newPassword) {
                    // TODO extract standard error responses instead of hardcoding the same response values
                    return reject(DashboardErrorResponse.standardResponses.SAME_PASSWORD);
                }
                if (expectedFailure.status !== "NEW_PASSWORD_REQUIRED") {
                    return reject(expectedFailure)
                }
                console.log("Successful login with old password and received status: NEW_PASSWORD_REQUIRED")

                let params = {
                    Password: newPassword,
                    Permanent: true,
                    Username: username,
                    UserPoolId: process.env.FAD_COGNITO_POOL_ID
                }

                let cognitoIdentityServiceProvider = new AWS.CognitoIdentityServiceProvider()

                console.log("Changing password to new one")
                cognitoIdentityServiceProvider.adminSetUserPassword(params, (err, data) => {
                    if (err) {
                        console.log(err)
                        if (['InvalidPasswordException', 'InvalidParameterException'].includes(err.code || err.name) && (
                            err.message.includes('Password does not conform to policy') || err.message.includes("'password' failed to satisfy constraint")
                        )) {
                            return reject(DashboardErrorResponse.standardResponses.INVALID_PASSWORD);
                        }
                        return reject(DashboardErrorResponse.standardResponses.UNKNOWN);
                    }
                    console.log(data)
                    return resolve(data)
                })
            })
    })
}
