/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Logs a request to the database to keep track of user activity.
 * This information will be later used for security audit purpose whenever required.
 *
 * @author theanh.ha
 */

let AWS = require("aws-sdk")
let uuidv1 = require('uuid/v1');
const logTypes = require('../common/LogTypes');

module.exports = (request) => {
    console.log('Writing request audit log to DynamoDB');
    const client = new AWS.DynamoDB.DocumentClient({convertEmptyValues: true});
    request.logid = uuidv1();
    let timeStamp = new Date().toISOString();
    let params = {
        TableName: process.env.FAD_DYNAMODB_TABLE_LOGS,
        Item: {
            id: request.logid ,
            log_type: logTypes.api_request,
            user: request.username,
            application: request.application,
            request_environment:request.environment['env'],
            service: request.service,
            url: request.url,
            method: request.method,
            request_headers: request.headers,
            request_body: request.body,
            request_formmodel: request.formmodel,
            creationDateTime: timeStamp,
            logType_creationDateTime: logTypes.api_request + "#" + timeStamp
        }
    };
    return client.put(params).promise().then(data => request);
}
