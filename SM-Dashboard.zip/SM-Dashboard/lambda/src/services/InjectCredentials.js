/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 */

module.exports = injectCredentials;

const _ = require('lodash');
const util = require('util');
const axios = require('axios')
const getFromParamStore = require("../services/GetFromParamStore");

const API_DASHBOARD_SOURCE_SYSTEM_NAME = 'FFM_SM';
const API_DASHBOARD_ROLE_ID = 'SM_READ';

async function injectCredentials(request) {
   // console.log('Injecting credentials');

    const requestedSourceSystemName = request.headers['source-system-name'];
    const requestedRoleId = request.headers['role-id'] || request.headers['roleid'];

    let apiKey;
    if (!_.isNil(request._apiKeyName)) {
        try {
            let sourceSystemNameKey = util.format(process.env.FAD_SSM_API_KEY_FORMAT, request._apiKeyName);
            apiKey = await getFromParamStore(sourceSystemNameKey);
        } catch (e) {
            console.log('error getting api key from parameter store', e);
        }
    }

    request.headers['source-system-name'] = API_DASHBOARD_SOURCE_SYSTEM_NAME;
    request.headers['role-id'] = API_DASHBOARD_ROLE_ID;
    request.headers['roleid'] = API_DASHBOARD_ROLE_ID;

    if (apiKey != null) {
        if (request._overriddenApiKeyHeaderName) {
            // remove the 'market-place-api-key' header
            _.remove(request.headers, function (header) {
                return header === 'marketplace-api-key'
            });

            // use the overridden header name for api key
            request.headers[request._overriddenApiKeyHeaderName] = apiKey;
        } else {
            request.headers['marketplace-api-key'] = apiKey;
        }
    } else if (!_.isNil(request._oauth)) {
        //console.log('Getting OKTA Access Token')
        const sourceSystemOauthKey = util.format(process.env.FAD_SSM_OAUTH_FORMAT, request._oauth);
        const oauthSsmValue = await getFromParamStore(sourceSystemOauthKey);
        const oauthParsedValues = JSON.parse(oauthSsmValue)
        const config = {
            CLIENT_ID: oauthParsedValues.CLIENT_ID,
            CLIENT_SECRET: oauthParsedValues.CLIENT_SECRET,
            ISSUER: oauthParsedValues.ISSUER
        }
        const token = await getAccessToken(config)
        request.headers['Authorization'] = `Bearer ${token}`;
    } else {
        console.error('Both API Key & OKTA Config values are missing')
        throw new Error('Both API Key & OKTA Config values are missing');
    }

    if (requestedSourceSystemName != null) {
        request.headers['impersonated-source-system-name'] = requestedSourceSystemName;
    } else {
        console.log('source-system-name not supplied in request; not injecting api key');
    }

    if (requestedRoleId != null) {
        request.headers['impersonated-roleid'] = requestedRoleId;
    } else {
        console.log('role-id not supplied in request; not injecting api key');
    }

    if (requestedSourceSystemName === API_DASHBOARD_SOURCE_SYSTEM_NAME &&
        requestedRoleId === API_DASHBOARD_ROLE_ID) {
        request.headers = _.omit(request.headers, [
            'impersonated-source-system-name',
            'impersonated-roleid']);
    }

    return request;
}


const getAccessToken = async (config) => {

    const client_secret_encoded = Buffer.from(`${config.CLIENT_ID}:${config.CLIENT_SECRET}`).toString('base64')

    try {

        const url = config.ISSUER
        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': 'application/json',
                'Authorization': `Basic ${client_secret_encoded}`
            },
            url,
        };

        const { access_token } = (await axios(options)).data

       // console.log("access_token", access_token)

        return access_token

    } catch (error) {
        console.log(`Error while fetching OKTA token: ${error.message}`)
    }
}

