/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Retrieve all service configurations from the database.
 * For security reason, only a subset of attributes will be returned
 * as a result of this call.
 *
 */

let _ = require("lodash")
let fs = require("fs")
const path = require('path');
const checkUserRefDataAccess = require("../utils/CheckUserRefDataAccess")
let getService = require("../services/GetService");
let validateEnv = require("../utils/ValidateEnv")

module.exports = async (request) => {
    console.log('GetRefDataQueryTemplateServices called');

    return Promise.all(_.map(request['queryFormModel'], async (serviceModel, serviceName, queryFormModel) => {
        try {
            //perform validation checks on each service and skip any that fail
            const service = await getService(request.application, serviceName);
            await checkUserRefDataAccess(request.username, service.allowed_roles)
            await validateEnv(request.environment['env'], service.environments)
            return await getTemplatedQuery(request.queryFormModel[serviceName], service);
        } catch (e) {
            console.log(e)
            return '\n'
        }
    })).then(templatedArray => {
        return templatedArray.join('\n')
    })
}

function readFileToStrSync(fileName) {
    return new Promise(function (resolve, reject) {
        let fullPath = path.join(__dirname, "../data/" + fileName);
        fs.readFile(fullPath, "utf8", function (err, data) {
            if (err) return reject(err);
            return resolve(data.toString());
        });
    });
}

async function getTemplatedQuery(queryModel, service) {
    return Promise.all(_.map(service.ref_data_template.refDataQueryFiles, async (fileName, key, collection) => {
        const fileData = await readFileToStrSync(fileName);
        return _.template(fileData)(queryModel)
    })).then(templatedArray => {
        return '(:***** ' + service.service + ' *****:)\n\n\n'.concat(templatedArray.join('\n\n--------------------------------------------------------------------------------\n\n'), '\n\n\n###############################################################################', '\n', '\n')
    })
}
