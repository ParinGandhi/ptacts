/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Verify if a user has capability access
 * 
 * @author pavan.gaddam
 *
 * @param username username
 * @param capability capability
 * @return username if enabled, otherwise error
 *
 */

const _ = require('lodash');
const DashboardErrorResponse = require('../common/DashboardErrorResponse');
const getFromParamStore = require("../services/GetFromParamStore");
const getUserCognitoGroups = require("../services/GetCognitoUserGroups");

module.exports = async (username, capability, cognitoId) => {
    return new Promise(async (resolve, reject) => {
        try {     
            let userCognitoRoles = await getUserCognitoGroups(cognitoId);
            let capStatus = await getFromParamStore(capability.param_store_key);
            let capStatusObj = JSON.parse(capStatus)
            if (capStatusObj.enabled) {
                for (let capRole of capStatusObj.allowedRoles) {
                    if (_.includes(userCognitoRoles.roles, capRole)) {
                        return resolve(username)
                    }
                }
                reject(DashboardErrorResponse.standardResponses.USER_ACCESS_DENIED);
            }
            else {
                reject(DashboardErrorResponse.standardResponses.CAPABILITY_DISABLED);
            }
        } catch (e) {
            reject(DashboardErrorResponse.standardResponses.PARAMETER_NOT_FOUND);
        }
    })
}
