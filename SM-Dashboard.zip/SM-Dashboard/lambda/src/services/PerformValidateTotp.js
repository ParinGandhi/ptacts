/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 */

let AmazonCognitoIdentity = require('amazon-cognito-identity-js');
const DashboardErrorResponse = require('../common/DashboardErrorResponse');

let AWS = require('aws-sdk');
const friendlyDevideName = 'userAuthApp'

module.exports = (userName, otp, cognitosessionkey) => {
    console.log('Performing validate totp code')
    global.fetch = require('node-fetch');
    return new Promise(async (resolve, reject) => {

        var params = {
            ChallengeName: 'SOFTWARE_TOKEN_MFA', /* required */
            ClientId: process.env.FAD_COGNITO_APP_CLIENT_ID, /* required */
            ChallengeResponses: {
                'USERNAME': userName,
                'SOFTWARE_TOKEN_MFA_CODE': otp
            },
            Session: cognitosessionkey
        };
        let cognitoIdentityServiceProvider = new AWS.CognitoIdentityServiceProvider();

        cognitoIdentityServiceProvider.respondToAuthChallenge(params, function (err, data) {
            if (err) {
                console.log(err, err.stack);
                return reject(new DashboardErrorResponse(
                    401,
                    err.code,
                    err.message
                ));
            } else {
                console.log('Cognito authentication succeeded');
                const response = {
                    "status": "SUCCESS",
                    "accessToken": data.AuthenticationResult.AccessToken
                };
                return resolve(response);
            }
        });
    })
}
