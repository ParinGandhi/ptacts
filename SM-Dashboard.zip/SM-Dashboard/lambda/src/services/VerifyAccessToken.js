/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Verify access token
 *
 * @param accessToken
 * @return username if validation is successful
 *
 * @author theanh.ha
 */

let AWS = require('aws-sdk');
const DashboardErrorResponse = require('../common/DashboardErrorResponse');
const jwt = require('jsonwebtoken');
const jwkToPem = require('jwk-to-pem');
const axios = require('axios');
let _ = require("lodash")

module.exports = async (accessToken) => {
    const cognitoJwkUrl = `https://cognito-idp.us-east-1.amazonaws.com/${process.env.FAD_COGNITO_POOL_ID}/.well-known/jwks.json`
    const kidToPem = (await axios.get(cognitoJwkUrl, {validateStatus: false})).data.keys
        .reduce((acc, item) => {
            acc[item.kid] = jwkToPem(item);
            return acc
        }, {})
    const decoded = jwt.decode(accessToken, {complete: true})
    const pem = kidToPem[decoded.header.kid]

    try {
        jwt.verify(accessToken, pem, {
            issuer: `https://cognito-idp.us-east-1.amazonaws.com/${process.env.FAD_COGNITO_POOL_ID}`,
            // audience: process.env.FAD_COGNITO_APP_CLIENT_ID, // AWS documentation says to make this check, but the payload does not have an aud claim
        })
    } catch (exc) {
        console.log('Received token from invalid issuer');
        throw DashboardErrorResponse.standardResponses.UNAUTHORIZED;
    }

    return new Promise((resolve, reject) => {
        let cognitoIdentityServiceProvider = new AWS.CognitoIdentityServiceProvider()
        cognitoIdentityServiceProvider.getUser({AccessToken: accessToken}, (err, data) => {
            if (err) {
                console.log(err)
                return reject(DashboardErrorResponse.standardResponses.UNAUTHORIZED)
            } else {
                let uid = _.find(data.UserAttributes, {Name: 'custom:uid'});
                if(uid) {
                    return resolve([uid.Value, data.Username]);
                } else {
                    console.log('Unexpected error: custom attribute uid not found')
                    return reject(DashboardErrorResponse.standardResponses.INTERNAL_SERVER_ERROR)
                }
            }
        })
    })
}
