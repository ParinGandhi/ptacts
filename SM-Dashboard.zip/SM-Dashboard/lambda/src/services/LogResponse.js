/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Logs a response to the database to keep track of user activity.
 * This information will be later used for security audit purpose whenever required.
 * @param wrappedRequestResponse - An object that contains the original request and response from the invoked API
 */

let AWS = require("aws-sdk")
let uuidv1 = require('uuid/v1');

module.exports = (wrappedRequestResponse) => {
    console.log('Writing response audit log to DynamoDB');
    const client = new AWS.DynamoDB.DocumentClient({convertEmptyValues: true});
    let successfulResult = wrappedRequestResponse.responsePayload;

    let params = {
        TableName: process.env.FAD_DYNAMODB_TABLE_LOGS,
        Key:{
            "id": wrappedRequestResponse.originalRequest.logid
        },
        UpdateExpression: "set response_headers = :rh, response_status = :rs, response_time = :rt",
        ExpressionAttributeValues:{
            ":rh":successfulResult.headers,
            ":rs":successfulResult.status,
            ":rt":successfulResult.responseTime
        },
        ReturnValues:"ALL_NEW"
    };
    return client.update(params).promise();
}
