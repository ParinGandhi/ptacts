/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Perform password reset
 *
 * @param username
 * @param resetCode
 * @param newPassword
 *
 * @author theanh.ha
 */

let AWS = require('aws-sdk');
const DashboardErrorResponse = require('../common/DashboardErrorResponse');

module.exports = (username, resetCode, newPassword) => {
    return new Promise(async (resolve, reject) => {
        console.log("Resetting password using reset code", resetCode)

        let params = {
            Username: username,
            ConfirmationCode: resetCode,
            Password: newPassword,
            ClientId: process.env.FAD_COGNITO_APP_CLIENT_ID
        }

        let cognitoIdentityServiceProvider = new AWS.CognitoIdentityServiceProvider()

        cognitoIdentityServiceProvider.confirmForgotPassword(params, (err, data) => {
            if (err) {
                console.log("Error: ", err)
                let response;

                if (err.code === "UserNotFoundException") {
                    response =  DashboardErrorResponse.standardResponses.USER_NOT_FOUND;
                } else if (err.code === "CodeMismatchException") {
                    response = DashboardErrorResponse.standardResponses.INVALID_VERIFICATION_CODE;
                } else if (err.code === "InvalidParameterException" && err.message.includes("'password' failed to satisfy constraint")) {
                    response = DashboardErrorResponse.standardResponses.INVALID_PASSWORD;
                } else {
                    response = DashboardErrorResponse.standardResponses.UNKNOWN;
                }
                return reject(response)
            } else {
                return resolve(data)
            }
        })
    })
}
