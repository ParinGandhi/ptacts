/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Perform global signout using access token
 *
 * @param accessToken
 *
 * @author theanh.ha
 */

let AWS = require('aws-sdk');

module.exports = (accessToken) => {
    // console.log("Performing logout on token: ", accessToken)
    console.log('Performing logout')
    return new Promise(async (resolve, reject) => {
        let cognitoIdentityServiceProvider = new AWS.CognitoIdentityServiceProvider()
        cognitoIdentityServiceProvider.globalSignOut({ AccessToken: accessToken }, (err, data) => {
            // In the case of success, we'll return success
            // In the case of error, we'll still return success due to the fact that
            // error could probably be related to token already being in "expired" state.
            const response = {
                "status": "SUCCESS",
                "message": "Successfully logged out",
                "statusCode": 200
            };

            if (err) {
                console.log('Error logging out'); // TODO why is this ending a successful response??
                resolve(response)
            } else {
                resolve(response)
            }
        })
    })
}
