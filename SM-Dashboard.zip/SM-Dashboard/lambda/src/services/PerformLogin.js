/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Perform login
 *
 * @param userName
 * @param password
 *
 * @author theanh.ha
 */

let AWS = require('aws-sdk');
let AmazonCognitoIdentity = require('amazon-cognito-identity-js');
const DashboardErrorResponse = require('../common/DashboardErrorResponse');

module.exports = async (userName, password, verificationCode) => {

    global.fetch = require('node-fetch');

    let authenticationData = {
        Username: userName,
        Password: password,
    };

    let authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails(authenticationData);

    let poolData = {
        UserPoolId: process.env.FAD_COGNITO_POOL_ID,
        ClientId: process.env.FAD_COGNITO_APP_CLIENT_ID
    };

    let userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
    let userData = {
        Username: userName,
        Pool: userPool
    };

    let cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);

    return new Promise((resolve, reject) => {
        cognitoUser.authenticateUser(authenticationDetails, {
            onSuccess: result => {
                // console.log("Cognito Response is: " + JSON.stringify(result))
                console.log('Cognito authentication succeeded');
                const response = {
                    "status": "SUCCESS",
                    "accessToken": result.accessToken.jwtToken
                };
                return resolve(response);
            },
            newPasswordRequired: (userAttributes, requiredAttributes) => {
                console.log('New password required');
                return reject(DashboardErrorResponse.standardResponses.NEW_PASSWORD_REQUIRED);
            },
            totpRequired: async (codeDeliveryDetails) => {
                return reject(new DashboardErrorResponse(
                    200,
                    "TOTP_REQUIRED",
                    cognitoUser.Session
                ));
            },
            onFailure: err => {
                console.log("Cognito response", err)
                if (!err) {
                    return reject(DashboardErrorResponse.standardResponses.UNKNOWN);
                }
                if (err.message === 'Only radix 2, 4, 8, 16, 32 are supported') {
                    // TODO upgrade AWS Cognito library, confirm the bug is fixed, and remove this workaround; username not in pool will return this error
                    //  https://github.com/aws-amplify/amplify-js/issues/4430
                    return reject(DashboardErrorResponse.standardResponses.UNAUTHORIZED);
                }
                let errString = JSON.stringify(err)
                let rawMessage = JSON.stringify(err.message)
                if (rawMessage.includes("newPasswordRequired") || errString.includes("newPasswordRequired")) {
                    // For newly established account by Admin
                    return reject(DashboardErrorResponse.standardResponses.NEW_PASSWORD_REQUIRED);
                }
                if (errString.includes("PasswordResetRequiredException")) {
                    // For account which new password is required after Admin reset
                    return reject(DashboardErrorResponse.standardResponses.PASSWORD_RESET_REQUIRED);
                }
                if (rawMessage.includes("User does not exist.") || errString.includes("NotAuthorizedException")) {
                    // For incorrect credentials
                    return reject(DashboardErrorResponse.standardResponses.UNAUTHORIZED);
                }
                // For everything else
                return reject(DashboardErrorResponse.standardResponses.UNKNOWN);
            }
        });
    });
}
