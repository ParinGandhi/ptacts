/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Sorts transaction log entries by timestamp
 *
 * @author kevin.truong
 */

const _ = require('lodash');

module.exports = (fileContentArray) => {
    return new Promise((resolve, reject) => {
        let jsonArray = [];
        _.forEach(fileContentArray, fileContents => {
            //convert the log file into an array by splitting the file at the end of each line
            let logArrayByLine = fileContents.toString("utf8").split(/(?:\r\n|\r|\n)/g);
            _.forEach(logArrayByLine, (value, key) => {
                try {// convert each line to a json object and add it to an array
                    let jsonStructuredLine = value.substring((value.indexOf("{")), value.length);
                    let jsonObj = JSON.parse(jsonStructuredLine);
                    jsonArray.push(jsonObj);
                } catch (e) {
                    console.log(e);
                }
            });
        });
        let sortedArray = _.orderBy(jsonArray, logObject => {
            return logObject.timestamp
        }, ['asc']);
        resolve(sortedArray)
    })
};
