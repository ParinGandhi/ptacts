/**
 * Retrieves the contents of all files in an s3 directory
 *
 * @param bucketName - the s3 bucket name
 * @param directoryKey - the key of the s3 directory
 */

const util = require('util');
const zlib = require('zlib');
const aws = require('aws-sdk');
const _ = require('lodash');
const s3 = new aws.S3({apiVersion: '2006-03-01'});

const maxKeys = 60;

module.exports = async (bucketName, directoryKey) => {

    const params = {
        Bucket: bucketName,
        MaxKeys: maxKeys,
        Prefix: directoryKey
    };

    const promisedDirFiles = await s3.listObjectsV2(params).promise()
    return Promise.all(_.map(promisedDirFiles.Contents, async s3ObjMetaData => {
        let promisedData = await s3.getObject({Bucket: bucketName, Key: s3ObjMetaData.Key}).promise();
        let deflatedBuffer = await deCompressData(Buffer.from(promisedData.Body, 'utf8'));
        return deflatedBuffer.toString("utf8");
    }));

}

function deCompressData(buffer) {
    return util.promisify(zlib.gunzip.bind(zlib))(buffer)
}
