let uuidv1 = require('uuid/v1');

const correlationIdHeaderKey = "x-correlation-id";
const correlationIdPrefix = "dashboard-";

module.exports = (request) => {
    let newRequest = JSON.parse(JSON.stringify(request))

    console.log('Injecting correlationId');
    //Create a new x-correlation-id if it was not passed

    if (!newRequest.headers[correlationIdHeaderKey]) {
        //The x-correlation-id should be prefixed with dashboard-
        //This will help identify requests coming from the Dashboard in the logs
        let generatedCorrelationId = correlationIdPrefix + uuidv1();
        //add the new generated correlationId to the headers
        newRequest.headers[correlationIdHeaderKey] = generatedCorrelationId;
        console.log("x-correlation-id:" + generatedCorrelationId + " was generated for this request")
    }
    return newRequest;
};
