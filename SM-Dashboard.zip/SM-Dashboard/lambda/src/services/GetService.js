/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Retrieve the configuration of a specific service from the database.
 *
 * @param application - the name of the application
 * @param service - the name of the service
 *
 * @author theanh.ha
 */

let AWS = require("aws-sdk")
//let dynamodb = new AWS.DynamoDB();

module.exports = (application, service) => {
    console.log("Getting service metadata from database for " + application + "/" + service)
    const client = new AWS.DynamoDB.DocumentClient();

    let params = {
        TableName: process.env.FAD_DYNAMODB_TABLE_SERVICES,
        Key: {
            "application": application,
            "service": service
        }
    };

    return client.get(params).promise()
        .then(data => data.Item);
}
