/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Retrieve all service configurations from the database.
 * For security reason, only a subset of attributes will be returned
 * as a result of this call.
 *
 */

let AWS = require("aws-sdk")
let _ = require("lodash")
const getFromParamStore = require("../services/GetFromParamStore")
let uuidv1 = require('uuid/v1');
let validateServiceEnvList = require("../utils/ValidateServiceEnvList")
const paramStoreKey = `/smdashboard/${process.env.FAD_ENV_TYPE}/allowed/environments`

module.exports = () => {
    console.log('GetAllAppConfigServices called');
    const client = new AWS.DynamoDB.DocumentClient();

    let params = {
        TableName: process.env.FAD_DYNAMODB_TABLE_SERVICES,
        ProjectionExpression: "application, service, s3_bucket_name, #st, environments, allowed_roles",
        FilterExpression: "#st = :a_s",
        ExpressionAttributeNames: {
            "#st": "service_type"
        },
        ExpressionAttributeValues: {
            ":a_s": "app_config_management_request"
        }
    };
    return client.scan(params).promise().then(async data => {
        // Aggregate the data before returning
        console.log('getAllAppConfigServices data', data);

        try {

            let dbResult = _.groupBy(data.Items, i => i.application)
            let result = _.keys(dbResult).map(application => {
                return {
                    "name": application,
                    "services": _.map(dbResult[application], entry => {
                        return {
                            name: entry.service,
                            id: entry.s3_bucket_name,
                            serviceName: entry.service,
                            s3BucketName: entry.s3_bucket_name,
                            environments :entry.environments,
                            allowed_roles: entry.allowed_roles,
                            prefix:"",
                            subFolders: []
                        }
                    })
                }
            });

            return {
                applications: result
            };

        } catch (e) {
            console.error('Error getting all services', e);
            throw e;
        }
    })
}
