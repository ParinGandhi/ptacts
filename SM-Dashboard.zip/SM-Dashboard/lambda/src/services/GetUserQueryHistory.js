/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Retrieve user query history
 *
 * @param userName - name of the user from the access token
 *
 * @author kevin.truong
 */

let AWS = require("aws-sdk");

module.exports = (userName) => {
    const client = new AWS.DynamoDB.DocumentClient();
    const queryLimit = 20;
    const logType = 'api_request';

    let params = {
        TableName: process.env.FAD_DYNAMODB_TABLE_LOGS,
        IndexName: "user-logType_creationDateTime-index",
        KeyConditionExpression: '#u = :user AND begins_with(logType_creationDateTime, :log_type)',
        ExpressionAttributeNames: {
            '#u': "user"
        },
        ExpressionAttributeValues: {
            ':user': userName,
            ':log_type': logType
        },
        Limit: queryLimit,
        ScanIndexForward: "false"
    };

    return client.query(params).promise().then(data => data.Items);
};
