let AWS = require("aws-sdk");
let AmazonCognitoIdentity = require('amazon-cognito-identity-js');
const DashboardErrorResponse = require('../common/DashboardErrorResponse');

module.exports = async (userName, password) => {
    console.log('PreAuthenticate called');
    global.fetch = require('node-fetch');

    let cognitoIdentityServiceProvider = new AWS.CognitoIdentityServiceProvider();
    let params = {
        UserPoolId: process.env.FAD_COGNITO_POOL_ID,
        Username: userName
    };
    let poolData = {
        UserPoolId: process.env.FAD_COGNITO_POOL_ID,
        ClientId: process.env.FAD_COGNITO_APP_CLIENT_ID
    };

    return new Promise((resolve, reject) => {
        cognitoIdentityServiceProvider.adminGetUser(params, async (err, data) => {
            if (err) {
                console.log("Error: ", err)
                if (err.message === 'Only radix 2, 4, 8, 16, 32 are supported') {
                    // TODO upgrade AWS Cognito library, confirm the bug is fixed, and remove this workaround; username not in pool will return this error
                    //  https://github.com/aws-amplify/amplify-js/issues/4430
                    console.log("User does not exist")
                    return reject(new DashboardErrorResponse(
                        403,
                        "UNAUTHORIZED",
                        "Invalid username or password"
                    ));
                }
                let rawMessage = JSON.stringify(err.message)
                if (rawMessage.includes("User does not exist.")) {
                    console.log("User does not exist")
                    return reject(new DashboardErrorResponse(
                        403,
                        "UNAUTHORIZED",
                        "Invalid username or password"
                    ));
                }
                return reject(new DashboardErrorResponse(
                    500,
                    "UNKNOWN",
                    "An error occurred"
                ))
            } else {
                let mfaAttribute = data.hasOwnProperty('PreferredMfaSetting');
                let userStatus = data.UserStatus;
                if (!mfaAttribute && userStatus === 'CONFIRMED') {
                    let authenticationData = {
                        Username: userName,
                        Password: password,
                    };
                    let authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails(authenticationData);
                    let userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
                    let userData = {
                        Username: userName,
                        Pool: userPool
                    };
                    let cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
                    cognitoUser.authenticateUser(authenticationDetails, {
                        onSuccess: function (result) {
                            cognitoUser.associateSoftwareToken(this);
                        },
                        mfaSetup: function(challengeName, challengeParameters) {
                            cognitoUser.associateSoftwareToken(this);
                        },
                        associateSecretCode: function(secretCode) {
                            return reject(new DashboardErrorResponse(
                                401,
                                "TOTP_SETUP_REQUIRED",
                                secretCode
                            ));
                        },
                        onFailure: function (err) {
                            return reject(new DashboardErrorResponse(
                                403,
                                "UNAUTHORIZED",
                                "Invalid username or password"
                            ));
                        }
                    });
                } else {
                    //User is confirmed and has setup totp, do noting
                    return resolve(data)
                }
            }
        });
    });

}
