/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Filters services based on the users access level
 *
 * @return The filtered services grouped by applications
 */

let AWS = require("aws-sdk")
let _ = require("lodash")
const getFromParamStore = require("../services/GetFromParamStore")
let uuidv1 = require('uuid/v1');
let validateServiceEnvList = require("../utils/ValidateServiceEnvList")
let validateUserServiceAccess = require("../utils/ValidateUserServiceAccess");
const getUserCognitoGroups = require("../services/GetCognitoUserGroups");

module.exports = (groupedAppServices, currentUser, capParamStoreKey) => {
    console.log('FilterAllowedServices called...');
    const allowedEnvsParamStoreKey = `/smdashboard/${process.env.FAD_ENV_TYPE}/allowed/environments`
    const client = new AWS.DynamoDB.DocumentClient({convertEmptyValues: true});
    return new Promise(async (resolve, reject) => {
        try {
            let result = []
            let allowedEnvs = await getFromParamStore(allowedEnvsParamStoreKey)
            let allowed_roles_str = await getFromParamStore(capParamStoreKey)
            let allowed_roles = JSON.parse(allowed_roles_str)
            let userRoles = await getUserCognitoGroups(currentUser)

            for (let app of groupedAppServices['applications']) {
                const appPackage = {
                    "name": app['name'],
                    "services": []
                }
                _.forEach(app['services'], (entry) => {
                    let filteredEnvList = validateServiceEnvList(entry.environments, allowedEnvs)
                    if (!_.isEmpty(filteredEnvList) && validateUserServiceAccess(entry.allowed_roles, allowed_roles['allowedRoles'], userRoles['roles'])) {
                        entry.environments = filteredEnvList
                        delete entry.allowed_roles
                        let svs = entry
                        appPackage.services.push(svs)
                    }
                })
                if (!_.isEmpty(appPackage.services)) {
                    result.push(appPackage)
                }
            }
            resolve({
                applications: result
            })
        } catch (e) {
            console.error("Error filtering services"+e)
            reject(e)
        }
    })
}
