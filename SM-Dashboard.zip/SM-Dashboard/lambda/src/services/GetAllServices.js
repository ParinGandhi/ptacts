/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Retrieve all service configurations from the database.
 * For security reason, only a subset of attributes will be returned
 * as a result of this call.
 *
 * @author theanh.ha
 */

let AWS = require("aws-sdk")
let _ = require("lodash")
const getFromParamStore = require("../services/GetFromParamStore")
let uuidv1 = require('uuid/v1');

module.exports = (userName) => {
    console.log('GetAllServices called');
    const client = new AWS.DynamoDB.DocumentClient();
    const user_name = userName;
    let params = {
        TableName: process.env.FAD_DYNAMODB_TABLE_SERVICES,
        ProjectionExpression: "application, service, #pt, template, environments, allowed_roles",
        FilterExpression: "#st = :a_s",
        ExpressionAttributeNames: {
            "#st": "service_type",
            "#pt": "path"
        },
        ExpressionAttributeValues: {
            ":a_s": "api_service"
        }
    };
    return client.scan(params).promise().then(async data => {
        // Aggregate the data before returning
        console.log('getAllServices data', data);

        try {
            const newDataItems = await Promise.all(data.Items.map(async item => {
                const schemaItems = await Promise.all(item.template.formSchema.map(schemaItem => {
                    if (!schemaItem.default || !schemaItem.default.startsWith('@')) {
                        return schemaItem;
                    }
                    // return schemaItem; // TODO REMOVE. For testing.

                    // if value is `@uuid` then generate uuid
                    if (schemaItem.default == "@uuid") {
                        schemaItem.default = uuidv1()
                        return schemaItem
                    }

                    return getFromParamStore(schemaItem.default.substring(1))
                        .then(value => {
                            schemaItem.default = value;
                            return schemaItem;
                        })
                        .catch(err => {
                            console.error('Schema item not found; unable to dereference for services', err);
                            return schemaItem;
                        })
                }))
                item.template.formSchema = schemaItems;
                return item;
            }));

            let dbResult = _.groupBy(newDataItems, i => i.application)

            let result = _.keys(dbResult).map(application => {
                return {
                    "name": application,
                    "services": _.map(dbResult[application], entry => {
                        return {
                            name: entry.service,
                            path: entry.path,
                            body: entry.template.body,
                            headers: entry.template.headers,
                            formSchema: entry.template.formSchema,
                            environments :entry.environments,
                            allowed_roles: entry.allowed_roles
                        }
                    })
                }
            });

            return {
                applications: result
            };

        } catch (e) {
            console.error('Error getting all services', e);
            throw e;
        }
    })
}
