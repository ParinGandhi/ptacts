/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Invoke RefData endpoint
 *
 * @param request - the request object
 */
const _ = require('lodash');
const axios = require('axios');
const logErrorResponse = require("../services/LogErrorResponse")
const logResponse = require("../services/LogResponse")
const {performance} = require('perf_hooks');
let AWS = require("aws-sdk");

module.exports = (request) => {
    console.log(`Invoking refdata endpoint: ${request.method} ${request.url}`);
    let start = performance.now();
    //This will ignore certificate validation
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    return axios({
        method: request.method,
        url: request.url,
        headers: request.headers,
        data: request.body,
        validateStatus: false,
        withCredentials: true
    }).then(result => {
        let stop = performance.now();
        let responseTime = stop - start;
        let successfulResult = {
            status: result.status,
            headers: result.headers,
            body: result.data,
            responseTime: responseTime,
            downstreamUrl: request.url
        };
        console.log("Received HTTP Status " + result.status + " in " + responseTime + "ms");

        return logResponse({
            responsePayload: successfulResult,
            originalRequest: request,
        }).then(updatedItem => {
            console.log('Updated log item is: ' + JSON.stringify(_.pick(updatedItem, ['Attributes.id', 'Attributes.response_status', 'Attributes.response_time'])));
            return successfulResult;
        });
    }).catch(err => {
        console.log("ERROR: ", err);
        let stop = performance.now();
        let responseTime = stop - start;
        let errorResult = {
            statusCode: 500,
            error: err,
            responseTime: responseTime,
        };

        return logErrorResponse({
            responsePayload: errorResult,
            originalRequest: request,
        }).then(updatedItem => {
            let dashBoardError = new DashboardErrorResponse();
            dashBoardError.requestHistoryItem = updatedItem.Attributes
            throw dashBoardError;
        });
    })
};
