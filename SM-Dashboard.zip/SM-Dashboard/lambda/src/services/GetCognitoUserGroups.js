/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Get cognito user groups
 *
 * @param accessToken
 * @return Congnito user groups
 *
 * @author pavan.gaddam
 */

let AWS = require('aws-sdk');

module.exports = async (userName) => {
    let params = {
        UserPoolId: process.env.FAD_COGNITO_POOL_ID, 
        Username: userName
    };

    let cognitoIdentityServiceProvider = new AWS.CognitoIdentityServiceProvider()
    return cognitoIdentityServiceProvider.adminListGroupsForUser (params).promise().then(data => {
        return { roles : data['Groups'].map(group => group['GroupName']) }
    })
}
