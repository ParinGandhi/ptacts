/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Retrieve all service configurations from the database.
 * For security reason, only a subset of attributes will be returned
 * as a result of this call.
 *
 */

let AWS = require("aws-sdk")
let _ = require("lodash")
const getFromParamStore = require("../services/GetFromParamStore")
let uuidv1 = require('uuid/v1');
let validateServiceEnvList = require("../utils/ValidateServiceEnvList")
const paramStoreKey = `/smdashboard/${process.env.FAD_ENV_TYPE}/allowed/environments`

module.exports = () => {
    console.log('GetAllRefDataServices called');
    const client = new AWS.DynamoDB.DocumentClient();
    let params = {
        TableName: process.env.FAD_DYNAMODB_TABLE_SERVICES,
        ProjectionExpression: "application, service, #md, #pt, root_url, template, ref_data_template, group_info, #st, environments, legend, notes, filtered_values, allowed_roles, label",
        FilterExpression: "#st = :a_s",
        ExpressionAttributeNames: {
            "#st": "service_type",
            "#pt": "path",
            "#md": "method"
        },
        ExpressionAttributeValues: {
            ":a_s": "ref_data_service"
        }
    };
    return client.scan(params).promise().then(async data => {
        // Aggregate the data before returning
        console.log('getAllRefDataServices data', data);

        try {
            const newDataItems = await Promise.all(data.Items.map(async item => {
                const schemaItems = await Promise.all(item.template.formSchema.map(schemaItem => {
                    if (!schemaItem.default || !schemaItem.default.startsWith('@')) {
                        return schemaItem;
                    }
                    // return schemaItem; // TODO REMOVE. For testing.

                    // if value is `@uuid` then generate uuid
                    if (schemaItem.default == "@uuid") {
                        schemaItem.default = uuidv1()
                        return schemaItem
                    }

                    return getFromParamStore(schemaItem.default.substring(1))
                        .then(value => {
                            schemaItem.default = value;
                            return schemaItem;
                        })
                        .catch(err => {
                            console.error('Schema item not found; unable to dereference for services', err);
                            return schemaItem;
                        })
                }))
                item.template.formSchema = schemaItems;
                return item;
            }));

            let dbResult = _.groupBy(newDataItems, i => i.application)
            let result = _.keys(dbResult).map(application => {
                return {
                    "name": application,
                    "services": _.map(dbResult[application], entry => {
                        if (!entry.label) {
                            entry.label = entry.service
                        }
                        return {
                            name: entry.service,
                            label: entry.label,
                            method: entry.method,
                            path: entry.path,
                            root_url: entry.root_url,
                            body: entry.template.body,
                            headers: entry.template.headers,
                            formSchema: entry.template.formSchema,
                            refDataValueTemplate: entry.ref_data_template.refDataValueTemplate,
                            refDataFormSchema: entry.ref_data_template.refDataFormSchema,
                            valueRegex: entry.ref_data_template.valueRegex,
                            groupInfo: entry.group_info,
                            environments: entry.environments,
                            allowed_roles: entry.allowed_roles,
                            legend: entry.legend,
                            notes: entry.notes,
                            filtered_values: entry.filtered_values
                        }
                    })
                }
            });

            return {
                applications: result
            };

        } catch (e) {
            console.error('Error getting all services', e);
            throw e;
        }
    }).catch(error => {
        console.error("Error getting service form dynamoDb", error)
        throw error;
    })
}
