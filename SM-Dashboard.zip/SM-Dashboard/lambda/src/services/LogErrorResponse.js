/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Logs an error response to the database to keep track of user activity.
 * This information will be later used for security audit purpose whenever required.
 * @param wrappedRequestResponse - An object that contains the original request and the error response from the invoked API
 */

let AWS = require("aws-sdk")
let uuidv1 = require('uuid/v1');

module.exports = (wrappedRequestResponse) => {
    console.log('Writing error response audit log to DynamoDB');
    const client = new AWS.DynamoDB.DocumentClient({convertEmptyValues: true});
    let errorResult = wrappedRequestResponse.responsePayload;

    let params = {
        TableName: process.env.FAD_DYNAMODB_TABLE_LOGS,
        Key:{
            "id": wrappedRequestResponse.originalRequest.logid
        },
        UpdateExpression: "set response_status = :rs, response_time = :rt",
        ExpressionAttributeValues:{
            ":rs":errorResult.statusCode,
            ":rt":errorResult.responseTime
        },
        ReturnValues:"ALL_NEW"
    };
    return client.update(params).promise();
}
