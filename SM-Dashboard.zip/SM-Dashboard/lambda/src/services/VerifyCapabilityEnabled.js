/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Verify if a dashboard capability is enabled
 *
 * @param capabilityName
 * @return true if enabled
 *
 */

let AWS = require('aws-sdk');
const _ = require('lodash');
const DashboardErrorResponse = require('../common/DashboardErrorResponse');
const getFromParamStore = require("../services/GetFromParamStore");

module.exports = async (capability) => {
    return new Promise(async (resolve, reject) => {
        try{
        let capabilityStatus = await getFromParamStore(capability.param_store_key)
        if(_.toLower(capabilityStatus) === 'on'){
            resolve(true)
        }else{
            reject(new DashboardErrorResponse(
                403,
                "UNAUTHORIZED",
                "Capability Disabled"
            ));
        }
        }catch (e) {
            reject(new DashboardErrorResponse(
                400,
                "PARAMETER NOT FOUND",
                "Parameter store item not found"
            ));
        }
    })
}
