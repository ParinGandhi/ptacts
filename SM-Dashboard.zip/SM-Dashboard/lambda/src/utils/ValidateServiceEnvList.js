/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Validates envs are allowed for deployed environment
 *
 */

const _ = require('lodash');
const getFromParamStore = require("../services/GetFromParamStore");
const paramStoreKey = `/smdashboard/${process.env.FAD_ENV_TYPE}/allowed/environments`

module.exports = (envArray, allowedEnvs) => {
    try {
        let validEnvList = []
        let allowedEnvList = allowedEnvs.split(',')
        _.map(envArray, env => {
            if (allowedEnvList.includes(env['env'])) {
                validEnvList.push(env)
            }
        })
        return validEnvList
    } catch (e) {
        console.warn(`Error validating environment list" ${JSON.stringify(envArray)}`)
        return []
    }
};
