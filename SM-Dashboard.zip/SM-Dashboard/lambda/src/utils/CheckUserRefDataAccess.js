/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Validates envs are allowed for deployed environment
 *
 */

const _ = require('lodash');
const capabilityTypes = require('../common/CapabilityTypes');
const getFromParamStore = require("../services/GetFromParamStore");
const getUserCognitoGroups = require("../services/GetCognitoUserGroups");
const validateUserServiceAccess = require("./ValidateUserServiceAccess");
const DashboardErrorResponse = require('../common/DashboardErrorResponse');

module.exports = async (currentUser, serviceAllowedRoles) =>  {

    return new Promise(async (resolve, reject) => {
        try {
            let allowed_roles_str = await getFromParamStore(capabilityTypes.ref_data_browsing_capability.param_store_key)
            let allowed_roles = JSON.parse(allowed_roles_str)
            let userRoles = await getUserCognitoGroups(currentUser)

            if (!validateUserServiceAccess(serviceAllowedRoles, allowed_roles['allowedRoles'], userRoles['roles'])) {
                return reject(DashboardErrorResponse.standardResponses.USER_ACCESS_DENIED);
            }
        } catch (e) {
            console.warn(`Error verifying user access ${e}`)
            return reject(DashboardErrorResponse.standardResponses.USER_ACCESS_DENIED);
        }
        resolve(true)
    })
};
