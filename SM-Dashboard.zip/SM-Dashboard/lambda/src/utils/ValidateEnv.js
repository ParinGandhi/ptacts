/**
 * ███████╗███╗   ███╗
 * ██╔════╝████╗ ████║
 * ███████╗██╔████╔██║
 * ╚════██║██║╚██╔╝██║
 * ███████║██║ ╚═╝ ██║
 * ╚══════╝╚═╝     ╚═╝
 * ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗
 * ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
 * ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║
 * ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
 * ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
 * ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝
 *
 * Validates envs are allowed for deployed environment
 *
 */

const _ = require('lodash');
const getFromParamStore = require("../services/GetFromParamStore");
const DashboardErrorResponse = require('../common/DashboardErrorResponse');

module.exports = (env, serviceEnvs) => {
    const paramStoreKey = `/smdashboard/${process.env.FAD_ENV_TYPE}/allowed/environments`
    return new Promise(async (resolve, reject) => {
        try {
            let allowedEnvs = await getFromParamStore(paramStoreKey)
            let allowedEnvList = allowedEnvs.split(',')
                if (!allowedEnvList.includes(env) || !_.find(serviceEnvs, ['env', env])) {
                    let errMsg = DashboardErrorResponse.standardResponses.UNAUTHORIZED_ENVIRONMENT;
                    reject(errMsg)
                }
        } catch (e) {
            console.warn(`No param store cookie set for ${env} environment`)
            let errMsg = DashboardErrorResponse.standardResponses.UNAUTHORIZED_ENVIRONMENT;
            reject(errMsg)
        }
        resolve(true)
    })
};
