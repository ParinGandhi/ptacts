ssh goq2@10.135.16.16 << EOF
rm -rf deploy/SM-Dashboard/web
exit
EOF
rm -rf /c/Users/pavan.k.gaddam/code/SM-Dashboard/web/node_modules
rm -rf /c/Users/pavan.k.gaddam/code/SM-Dashboard/web/dist
scp -rp /c/Users/pavan.k.gaddam/code/SM-Dashboard/web goq2@10.135.16.16:/home/goq2/deploy/SM-Dashboard
ssh goq2@10.135.16.16 << EOF
cd deploy/SM-Dashboard/web/
rm .npmrc
rm ffe-api-dashboard-lambda-1.5.1-SNAPSHOT.0.tgz
npm install
npm pack && ( . ../../dev.env ; ./deploy.sh ; )
exit
EOF

