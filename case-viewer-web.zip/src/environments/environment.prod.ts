import { PtabTrialConstants } from "src/app/constants/ptab-trials.constants";

export const environment = {
  production: true,
  showLogin: false,
  TRIALS_SERVICE_API: `${window.location.protocol}//${window.location.host}${PtabTrialConstants.TRIAL_SERVICES_URL}`,
  COMMON_SERVICE_API: `${window.location.protocol}//${window.location.host}${PtabTrialConstants.COMMON_SERVICES_URL}`,
  CASEVIEWER_SERVICE_API: `${window.location.protocol}//${window.location.host}${PtabTrialConstants.CASEVIEWER_BASE_URL}`
};
