import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Router } from "@angular/router";
import { Store } from '@ngrx/store';
import { ToastrService } from 'ngx-toastr';
import { CaseViewerService } from 'src/app/services/case-viewer.service';
import { JpViewService } from 'src/app/services/jpview.service';
import { getUserInfoAction } from 'src/app/store/case-viewer/case-viewer.actions';
import { PtabTrialConstants } from "../../constants/ptab-trials.constants";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.less']
})
export class LoginComponent implements OnInit {

  @Output() loginInfoEmitter: EventEmitter<any> = new EventEmitter();
  userName: string = null;
  showLoginDialog: boolean = true;

  constructor(
    private jpViewService: JpViewService,
    private caseViewerService: CaseViewerService,
    private router: Router,
    private store: Store,
    private toastr: ToastrService) { }

  ngOnInit(): void {

   }

  getUserInfo() {
    // let urlString = `${PtabTrialConstants.CASE_VIEWER_URL}${PtabTrialConstants.USER_INFO}${this.userName}`;
    // this.store.dispatch(getUserInfoAction({ url: urlString }));
    this.store.dispatch(getUserInfoAction({ url: this.userName }));
    // console.log(this.userInfo$)
    // this.jpViewService.getUserInfo(urlString).subscribe((userInfoResponse) => {
    this.caseViewerService.getUserInfo(this.userName).subscribe((userInfoResponse) => {
      this.loginInfoEmitter.emit(userInfoResponse.caseDetailsData[0]);
      window.sessionStorage.setItem('userInfo', JSON.stringify(userInfoResponse.caseDetailsData[0]));
      this.router.navigate(['/aiaTrialsWorkspace/aiaSearch']);
      this.toastr.success(`Successfully logged in as ${userInfoResponse.caseDetailsData[0].fullName}`, "Login", {
        closeButton: true
      } );
    })
  }

}
