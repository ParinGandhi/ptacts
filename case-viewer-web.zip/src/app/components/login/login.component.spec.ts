import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideMockStore, MockStore } from "@ngrx/store/testing";
import { LoginComponent } from './login.component';
import { PtabTrialConstants } from "src/app/constants/ptab-trials.constants";
import { JpViewService } from 'src/app/services/jpview.service';
import { of } from 'rxjs';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from "@angular/router/testing";
import { Router } from "@angular/router";

import {
  routes
} from "../../app-routing.module"

xdescribe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let store: MockStore;
  let jpViewService: JpViewService;
  let router: Router;
  const initialState = {}

  const loggedInUserInfo = {
    caseDetailsData:
      [{
        activeIn: "Active",
        apjSeniorityRank: 85,
        disiplanceCd: "Electrical",
        emailAddress: "Test_Jennifer.Bisk@USPTO.GOV",
        firstName: "Jennifer",
        fullName: "Bisk, Jennifer S.",
        jobClassificationCode: "APJ",
        lastName: "Bisk",
        leadApjIndicator: "APJ1",
        loginId: "jbisk",
        preferredFullName: "Bisk, Jennifer S.",
        privileges: null,
        roleDescription: "Judge",
        trialJudgeIndicator: "Judge",
        userIdentiifier: 5017,
        userWorkerNumber: "88548",
        isAdmin: false
        }
      ]
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes(routes), HttpClientTestingModule],
      declarations: [LoginComponent],
      providers: [provideMockStore({initialState}), JpViewService]
    })
    store = TestBed.inject(MockStore);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    jpViewService = TestBed.inject(JpViewService);
    component = fixture.componentInstance;
    router = TestBed.inject(Router);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('should be a valid username', () => {
  //   component.userName = "jbisk";
  //   let urlString = PtabTrialConstants.USER_INFO + component.userName;
  //   spyOn(jpViewService, 'getUserInfo').and.returnValue(of(loggedInUserInfo));
  //   component.getUserInfo();
  //   expect(urlString).toEqual(PtabTrialConstants.USER_INFO + "jbisk");
  // })
});
