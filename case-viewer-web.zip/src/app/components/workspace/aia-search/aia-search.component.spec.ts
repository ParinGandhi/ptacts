import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import { CommonUtilitiesService } from '../../../services/common-utilities.service';
import { CommonService } from '../../../services/common.service';
import { GridHelperService } from '../../../services/grid-helper.service';
import { TrialsService } from '../../../services/trials.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { FormsModule } from '@angular/forms';
import { AiaSearchComponent } from './aia-search.component';
import { of } from 'rxjs';

describe('AiaSearchComponent', () => {
  let component: AiaSearchComponent;
  let fixture: ComponentFixture<AiaSearchComponent>;

  beforeEach(() => {
    const changeDetectorRefStub = () => ({ detectChanges: () => ({}) });
    const commonUtilitiesServiceStub = () => ({
      setTypeaheadList: (listofJudges, string, string1) => ({}),
      parseKeyDates: (mileStoneDt, dESC) => ({}),
      parseAllPartiesInfo: allPartiesInfo => ({}),
      findDecisionOutcome: mileStoneDt => ({}),
      convertDatePickerToDisplayDate: fromDate => ({}),
      setToastr: (string, message) => ({}),
      openConfirmModal: modal => ({ onHide: { subscribe: f => f({}) } }),
      convertDatePickerToEpoch: fromDate => ({}),
      setDateOnDatePicker: fromDate => ({}),
      formatNumber: arg => ({})
    });
    const commonServiceStub = () => ({
      getDropDownList: fILING_PARTY => ({ subscribe: f => f({}) })
    });
    const gridHelperServiceStub = () => ({
      convertDateToString: arg => ({}),
      paginationGetTotalPages: arg => ({}),
      // paginationSetPageSize: arg => ({}),
      onFilterChanged: gridApi => ({ numberOfFilters: {} }),
      exportDataAsCsv: (gridApi, string) => ({})
    });
    const trialsServiceStub = () => ({
      getJudgeList: () => ({ subscribe: f => f({}) }),
      searchByCase: caseSearch => ({ subscribe: f => f({}) }),
      searchByDocument: documentSearch => ({ subscribe: f => f({}) })
    });
    const bsModalServiceStub = () => ({ hide: () => ({}) });
    TestBed.configureTestingModule({
      imports: [FormsModule],
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [AiaSearchComponent],
      providers: [
        { provide: ChangeDetectorRef, useFactory: changeDetectorRefStub },
        {
          provide: CommonUtilitiesService,
          useFactory: commonUtilitiesServiceStub
        },
        { provide: CommonService, useFactory: commonServiceStub },
        { provide: GridHelperService, useFactory: gridHelperServiceStub },
        { provide: TrialsService, useFactory: trialsServiceStub },
        { provide: BsModalService, useFactory: bsModalServiceStub }
      ]
    });
    fixture = TestBed.createComponent(AiaSearchComponent);
    component = fixture.componentInstance;
    const testlist = []
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`noRowsTemplate has default value`, () => {
    expect(component.noRowsTemplate).toEqual(`No cases found`);
  });

  it(`rowSelection has default value`, () => {
    expect(component.rowSelection).toEqual(`multiple`);
  });

  it(`selectedCaseTypes has default value`, () => {
    expect(component.selectedCaseTypes).toEqual([]);
  });

  it(`caseTypes has default value`, () => {
    expect(component.caseTypes).toBeDefined();
  });

  it(`searchBy has default value`, () => {
    expect(component.searchBy).toEqual(`case`);
  });

  it(`filingParties has default value`, () => {
    expect(component.filingParties).toEqual([]);
  });

  it(`availabilities has default value`, () => {
    expect(component.availabilities).toEqual([]);
  });

  it(`paperTypes has default value`, () => {
    expect(component.paperTypes).toEqual([]);
  });

  it(`searchResults has default value`, () => {
    expect(component.searchResults).toEqual([]);
  });

  it(`judgeList has default value`, () => {
    expect(component.judgeList).toEqual([]);
  });

  it(`numberOfFilters has default value`, () => {
    expect(component.numberOfFilters).toEqual(0);
  });

  it(`searching has default value`, () => {
    expect(component.searching).toEqual(false);
  });

  it(`message has default value`, () => {
    expect(component.message).toEqual(
      `Enter search criteria to display results`
    );
  });

  it(`resultsFound has default value`, () => {
    expect(component.resultsFound).toEqual(false);
  });

  it(`popoverContent has default value`, () => {
    expect(component.popoverContent).toEqual(
      `<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>`
    );
  });

  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      spyOn(component, 'getFilingParties').and.returnValue();
      spyOn(component, 'getAvailabilities').and.returnValue();
      spyOn(component, 'getJudgeList').and.returnValue();
      spyOn(component, 'popoverShow').and.returnValue();
      component.ngOnInit();
      expect(component.getFilingParties).toBeDefined();
      expect(component.getAvailabilities).toBeDefined();
      expect(component.getJudgeList).toBeDefined();
      expect(component.popoverShow).toBeDefined();
    });
  });

  // describe('ngAfterViewInit', () => {
  //   it('makes expected calls', () => {
  //     const changeDetectorRefStub: ChangeDetectorRef = fixture.debugElement.injector.get(
  //       ChangeDetectorRef
  //     );
  //     spyOn(changeDetectorRefStub, 'detectChanges').and.returnValue();
  //     component.ngAfterViewInit();
  //     expect(changeDetectorRefStub.detectChanges).toBeDefined();
  //   });
  // });

  describe('getFilingParties', () => {
    it('makes expected calls', () => {
      const commonServiceStub: CommonService = fixture.debugElement.injector.get(
        CommonService
      );
      let filingPartyResponse = [{'displayNameText':'','code':''},{'displayNameText':'','code':''}]
      spyOn(commonServiceStub, 'getDropDownList').and.returnValue(of(filingPartyResponse));
      component.getFilingParties();
      expect(commonServiceStub.getDropDownList).toBeDefined();
    });
  });

  describe('getAvailabilities', () => {
    it('makes expected calls', () => {
      const commonServiceStub: CommonService = fixture.debugElement.injector.get(
        CommonService
      );
      let aResponse = [{'displayNameText':'','code':''},{'displayNameText':'','code':''}]
      spyOn(commonServiceStub, 'getDropDownList').and.returnValue(of(aResponse));
      component.getAvailabilities();
      expect(commonServiceStub.getDropDownList).toBeDefined();
    });
  });

  describe('getJudgeList', () => {
    it('makes expected calls', () => {
      const commonUtilitiesServiceStub: CommonUtilitiesService = fixture.debugElement.injector.get(
        CommonUtilitiesService
      );
      const trialsServiceStub: TrialsService = fixture.debugElement.injector.get(
        TrialsService
      );
      let jResponse = [{'displayNameText':'','code':''},{'displayNameText':'','code':''}]

      spyOn(commonUtilitiesServiceStub, 'setTypeaheadList').and.returnValue(of({}));
      spyOn(trialsServiceStub, 'getJudgeList').and.returnValue(of());
      component.getJudgeList();
      expect(commonUtilitiesServiceStub.setTypeaheadList).toBeDefined();
      expect(trialsServiceStub.getJudgeList).toBeDefined();
    });
  });

  describe('getCaseSearchResults', () => {
    it('makes expected calls', () => {
      const commonUtilitiesServiceStub: CommonUtilitiesService = fixture.debugElement.injector.get(
        CommonUtilitiesService
      );
      const trialsServiceStub: TrialsService = fixture.debugElement.injector.get(
        TrialsService
      );
      spyOn(component, 'setPaginationDetails').and.callThrough();
      spyOn(commonUtilitiesServiceStub, 'parseKeyDates').and.returnValue(of());
      spyOn(
        commonUtilitiesServiceStub,
        'parseAllPartiesInfo'
      ).and.callThrough();
      spyOn(
        commonUtilitiesServiceStub,
        'findDecisionOutcome'
      ).and.callThrough();
      let cResponse = [{'displayNameText':'','code':''},{'displayNameText':'','code':''}]

      spyOn(trialsServiceStub, 'searchByCase').and.returnValue(of(cResponse));
      component.getCaseSearchResults();
      expect(component.setPaginationDetails).toBeDefined();
      expect(commonUtilitiesServiceStub.parseKeyDates).toBeDefined();
      expect(commonUtilitiesServiceStub.parseAllPartiesInfo).toBeDefined();
      expect(commonUtilitiesServiceStub.findDecisionOutcome).toBeDefined();
      expect(trialsServiceStub.searchByCase).toBeDefined();
    });
  });

  describe('getDocumentSearchResults', () => {
    it('makes expected calls', () => {
      const commonUtilitiesServiceStub: CommonUtilitiesService = fixture.debugElement.injector.get(
        CommonUtilitiesService
      );
      const gridHelperServiceStub: GridHelperService = fixture.debugElement.injector.get(
        GridHelperService
      );
      const trialsServiceStub: TrialsService = fixture.debugElement.injector.get(
        TrialsService
      );
      spyOn(component, 'validateDocumentDates').and.callThrough();
      spyOn(component, 'openWarningModal').and.callThrough();
      spyOn(component, 'setFilingPartyDescription').and.callThrough();
      spyOn(component, 'setAvailabilityDescription').and.callThrough();
      spyOn(component, 'setPaginationDetails').and.callThrough();
      spyOn(
        commonUtilitiesServiceStub,
        'convertDatePickerToDisplayDate'
      ).and.callThrough();
      spyOn(commonUtilitiesServiceStub, 'parseKeyDates').and.callThrough();
      spyOn(commonUtilitiesServiceStub, 'setToastr').and.callThrough();
      spyOn(gridHelperServiceStub, 'convertDateToString').and.callThrough();
      spyOn(trialsServiceStub, 'searchByDocument').and.callThrough();
      component.getDocumentSearchResults();
      expect(component.validateDocumentDates).toBeDefined();
      expect(component.openWarningModal).toBeDefined();
      expect(component.setFilingPartyDescription).toBeDefined();
      expect(component.setAvailabilityDescription).toBeDefined();
      expect(component.setPaginationDetails).toBeDefined();
      expect(
        commonUtilitiesServiceStub.convertDatePickerToDisplayDate
      ).toBeDefined();
      expect(commonUtilitiesServiceStub.parseKeyDates).toBeDefined();
      expect(commonUtilitiesServiceStub.setToastr).toBeDefined();
      expect(gridHelperServiceStub.convertDateToString).toBeDefined();
      expect(trialsServiceStub.searchByDocument).toBeDefined();
    });
  });

  // describe('openWarningModal', () => {
  //   it('makes expected calls', () => {
  //     const commonUtilitiesServiceStub: CommonUtilitiesService = fixture.debugElement.injector.get(
  //       CommonUtilitiesService
  //     );
  //     const bsModalServiceStub: BsModalService = fixture.debugElement.injector.get(
  //       BsModalService
  //     );
  //     spyOn(commonUtilitiesServiceStub, 'openConfirmModal').and.callThrough();
  //     spyOn(bsModalServiceStub, 'hide').and.returnValue();
  //     component.openWarningModal();
  //     expect(commonUtilitiesServiceStub.openConfirmModal).toBeDefined();
  //     expect(bsModalServiceStub.hide).toBeDefined();
  //   });
  // });

  describe('validateDocumentDates', () => {
    it('makes expected calls', () => {
      const commonUtilitiesServiceStub: CommonUtilitiesService = fixture.debugElement.injector.get(
        CommonUtilitiesService
      );
      spyOn(
        commonUtilitiesServiceStub,
        'convertDatePickerToEpoch'
      ).and.callThrough();
      component.validateDocumentDates();
      expect(
        commonUtilitiesServiceStub.convertDatePickerToEpoch
      ).toBeDefined();
    });
  });

  // describe('onFilterChanged', () => {
  //   it('makes expected calls', () => {
  //     const gridHelperServiceStub: GridHelperService = fixture.debugElement.injector.get(
  //       GridHelperService
  //     );
  //     spyOn(gridHelperServiceStub, 'onFilterChanged').and.callThrough();
  //     component.onFilterChanged();
  //     expect(gridHelperServiceStub.onFilterChanged).toBeDefined();
  //   });
  // });

  describe('getTotalCount', () => {
    it('makes expected calls', () => {
      const commonUtilitiesServiceStub: CommonUtilitiesService = fixture.debugElement.injector.get(
        CommonUtilitiesService
      );
      spyOn(commonUtilitiesServiceStub, 'formatNumber').and.callThrough();
      component.getTotalCount();
      expect(commonUtilitiesServiceStub.formatNumber).toBeDefined();
    });
  });

  // describe('goToPage', () => {
  //   it('makes expected calls', () => {
  //     spyOn(component, 'setPaginationDetails').and.callThrough();
  //     component.goToPage();
  //     expect(component.setPaginationDetails).toBeDefined();
  //   });
  // });

  // describe('setPageSize', () => {
  //   it('makes expected calls', () => {
  //     spyOn(component, 'setPaginationDetails').and.callThrough();
  //     component.setPageSize();
  //     expect(component.setPaginationDetails).toBeDefined();
  //   });
  // });

  describe('exportDataAsCsv', () => {
    it('makes expected calls', () => {
      const commonUtilitiesServiceStub: CommonUtilitiesService = fixture.debugElement.injector.get(
        CommonUtilitiesService
      );
      const gridHelperServiceStub: GridHelperService = fixture.debugElement.injector.get(
        GridHelperService
      );
      spyOn(commonUtilitiesServiceStub, 'setToastr').and.callThrough();
      spyOn(gridHelperServiceStub, 'exportDataAsCsv').and.callThrough();
      component.exportDataAsCsv();
      expect(commonUtilitiesServiceStub.setToastr).toBeDefined();
      expect(gridHelperServiceStub.exportDataAsCsv).toBeDefined();
    });
  });

   afterAll(() => {
    TestBed.resetTestingModule();
   });

});

