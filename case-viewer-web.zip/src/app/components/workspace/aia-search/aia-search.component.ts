import { AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { ICellRendererParams } from 'ag-grid-community';
import { PtabTrialConstants } from '../../../constants/ptab-trials.constants';
import GridRefreshModel from '../../../models/common/GridRefresh.model';
import { CommonUtilitiesService } from '../../../services/common-utilities.service';
import { CommonService } from '../../../services/common.service';
import { GridHelperService } from '../../../services/grid-helper.service';
import { TrialsService } from '../../../services/trials.service';
import { JudgePanelRendererComponent } from '../../common/judge-panel-renderer/judge-panel-renderer.component';
import { OpenCaseviewerComponent } from '../../common/open-caseviewer/open-caseviewer.component';
import { CaseSearch } from '../../../models/search/CaseSearch';
import { GridPagination } from '../../../models/grid/GridPagination';
import { CheckboxDropdownComponent } from '../../common/checkbox-dropdown/checkbox-dropdown.component';
import { ToolTipComponent } from '../tool-tip/tool-tip.component';
import { AdditionalFiltersComponent } from './additional-filters/additional-filters.component';
import { DocumentSearch } from 'src/app/models/search/DocumentSearch';
import InfoModalModel from 'src/app/models/common/InfoModal.model';
import { BsModalService } from 'ngx-bootstrap/modal';
import { FilterValidations } from 'src/app/models/search/FilterValidations';
import { OpenDocumentComponent } from '../../common/open-document/open-document.component';
declare let $:any;

@Component({
  selector: 'app-aia-search',
  templateUrl: './aia-search.component.html',
  styleUrls: ['./aia-search.component.less']
})
export class AiaSearchComponent implements OnInit, AfterViewInit {

  // @ViewChild(CheckboxDropdownComponent)
  // private readonly checkboxDropdownComponent: CheckboxDropdownComponent;

  @ViewChild('searchCaseTypes') caseTypesDropdownComponent: CheckboxDropdownComponent;

  // @ViewChild('documentPaperType') paperTypesDropdownComponent: CheckboxDropdownComponent;

  @ViewChild('documentCaseTypes') documentCaseTypesDropdownComponent: CheckboxDropdownComponent;

  @ViewChild('documentFilingParty') filingPartiesDropdownComponent: CheckboxDropdownComponent;

  @ViewChild('documentAvailabilities') availabilitiesDropdownComponent: CheckboxDropdownComponent;

  @ViewChild(AdditionalFiltersComponent)
  private readonly additionalFiltersComponent: AdditionalFiltersComponent;


  /**
   *  Grid
   */
   gridApi;
   gridColumnApi;
   noRowsTemplate = "No cases found";
   frameworkComponents;
  rowSelection = "multiple";

   defaultCaseColDef = {
     filter: true,
     sortable: true,
     floatingFilter: true,
     suppressMenu: true,
     tooltipComponent: 'customTooltip',
     filterParams: {
       newRowsAction: 'keep'
     },
     headerCheckboxSelection: false,
     checkboxSelection: false,
   };

   defaultDocumentColDef = {
    filter: true,
    sortable: true,
    floatingFilter: true,
    suppressMenu: true,
    tooltipComponent: 'customTooltip',
    filterParams: {
      newRowsAction: 'keep'
     },
    //? Enable when download is implemented
    // headerCheckboxSelection: this.isFirstColumn,
    // checkboxSelection: this.isFirstColumn,
    headerCheckboxSelection: false,
    checkboxSelection: false,
  };

   gridRefreshValues: GridRefreshModel = {
    refreshFailed: false,
    showLoading: false,
    lastRefresh: null
   }


  columnDefs = {
    caseCols: [
      // {
      //   "headerName": "",
      //   "field": "",
      //   "width": 25,
      //   "minWidth": 25,
      //   "maxWidth": 25,
      //   "resizable": false,
      //   "floatingFilter": false,
      //   "headerCheckboxSelection": false,
      //   "cellStyle": {
      //     "background-color": "#F0F0EE"
      //   }
      // },
      {
        "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.AIA_REVIEW,
        "field": "proceedingNumber",
        "width": 130,
        "minWidth": 130,
        "resizable": true,
        "cellRendererFramework": OpenCaseviewerComponent
      },
      {
        "headerName": PtabTrialConstants.KEY_DATES.FILING_DATE.DESC,
        "field": PtabTrialConstants.KEY_DATES.FILING_DATE.KEY,
        "width": 150,
        "minWidth": 150,
        "resizable": true,
        "comparator": this.gridHelper.dateComparator,
        "headerCheckboxSelection": false,
        "sort": "asc",
        "type": "date"
      },
      {
        "headerName": "Institution decision date",
        "field": PtabTrialConstants.KEY_DATES.DECISION_TO_INSTITUE.KEY,
        "width": 150,
        "minWidth": 150,
        "comparator": this.gridHelper.dateComparator,
        "resizable": true,
        "wrapText": false,
        "autoHeight": false,
        "type": "date"
      },
      {
        "headerName": "Termination date",
        "field": PtabTrialConstants.KEY_DATES.TERMINATION_DECISION.KEY,
        "width": 150,
        "minWidth": 150,
        "comparator": this.gridHelper.dateComparator,
        "resizable": true,
        "wrapText": false,
        "autoHeight": false,
        "type": "date"
      },
      {
        "headerName": "Petitioner application #",
        "field": "petiApplicationId",
        "width": 125,
        "minWidth": 125,
        "resizable": true,
        "wrapText": false,
        "autoHeight": false,
      },
      {
        "headerName": "Petitioner patent #",
        "field": "petiPatentNumber",
        "width": 115,
        "minWidth": 115,
        "resizable": true,
        "wrapText": false,
        "autoHeight": false,
      },
      {
        "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITIONER_TECH_CENTER,
        "field": "petiTechCenterId",
        "width": 115,
        "minWidth": 115,
        "resizable": true
      },
      {
        "headerName": "Petitioner",
        "field": "petiRealParty",
        "width": 200,
        "minWidth": 200,
        "resizable": true,
        "tooltipField": 'petitonerRealParty',
        "tooltipComponentParams": { data: 'petitonerRealParty' }
      },
      {
        "headerName": "PO / Respondent application #",
        "field": "poApplicationId",
        "width": 150,
        "minWidth": 150,
        "resizable": true
      },
      {
        "headerName": "PO / Respondent patent #",
        "field": "poPatentNumber",
        "width": 150,
        "minWidth": 150,
        "resizable": true
      },
      {
        "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT_TECH_CENTER,
        "field": "poTechCenterId",
        "width": 150,
        "minWidth": 150,
        "resizable": true
      },
      {
        "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT,
        "field": "poRealParty",
        "width": 175,
        "minWidth": 175,
        "resizable": true,
        "tooltipField": 'poRealParty',
      "tooltipComponentParams": { data: 'poRealParty' }
      },

      {
        "headerName": "APJ1/APJ2+",
        "field": "judges",
        "width": 175,
        "minWidth": 175,
        "resizable": true,
        "tooltipField": 'judges',
        "tooltipComponentParams": { data: 'judges' },
        "cellRendererFramework": JudgePanelRendererComponent,
        "cellRendererParams": (params: ICellRendererParams) => this.gridHelper.formatSearchJudgeTooltip(params)
      },
      {
        "headerName": "Status",
        "field": "statusDisplay",
        "width": 150,
        "minWidth": 150,
        "resizable": true
      },
      {
        "headerName": "Case confidentiality",
        "field": "caseConfidentiality",
        "width": 150,
        "minWidth": 150,
        "resizable": true
      },
      {
        "headerName": "Decision outcome",
        "field": "decisionOutcome",
        "width": 150,
        "minWidth": 150,
        "resizable": true
      }
    ],
    documentCols: [
      // {
      //   "headerName": "",
      //   "field": "",
      //   "width": 25,
      //   "minWidth": 25,
      //   "maxWidth": 25,
      //   "resizable": false,
      //   "floatingFilter": false,
      //   "headerCheckboxSelection": false,
      //   "cellStyle": {
      //     "background-color": "#F0F0EE"
      //   }
      // },
      {
        "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.AIA_REVIEW,
        "field": "proceedingMetadata.proceedingNumber",
        "width": 130,
        "minWidth": 130,
        "resizable": true,
        "cellRendererFramework": OpenCaseviewerComponent
      },
      {
        "headerName": "Filing date",
        // "field": "proceedingMetadata.filingDate",
        "field": "docFilingDateStr",
        "width": 120,
        "minWidth": 120,
        "resizable": true,
        "comparator": this.gridHelper.dateComparator,
        "headerCheckboxSelection": false,
        "sort": "asc",
        "type": "date"
      },
      {
        "headerName": "Document title",
        "field": "documentInfo",
        "width": 250,
        "minWidth": 250,
        "resizable": true,
        "wrapText": false,
        "autoHeight": false,
        "cellRendererFramework": OpenDocumentComponent
      },
      {
        "headerName": "Doc type",
        "field": "documentInfo.docType",
        "width": 100,
        "minWidth": 100,
        "resizable": true,
        "wrapText": false,
        "autoHeight": false
      },
      {
        "headerName": "Exhibit/Paper #",
        "field": "documentInfo.docNumber",
        "width": 100,
        "minWidth": 100,
        "comparator": this.gridHelper.dateComparator,
        "resizable": true,
        "wrapText": false,
        "autoHeight": false,
        "type": "date"
      },
      // {
      //   "headerName": "Page count",
      //   "field": "documentInfo.pageCount",
      //   "width": 75,
      //   "minWidth": 75,
      //   "resizable": true,
      //   "wrapText": false,
      //   "autoHeight": false,
      //   "tooltipField": 'documentInfo.pageCount',
      //   "tooltipComponentParams": { data: 'documentInfo.pageCount' }
      // },
      {
        "headerName": "Institution decision date",
        "field": "proceedingMetadata.decisionToInstituteDate",
        "width": 150,
        "minWidth": 150,
        "comparator": this.gridHelper.dateComparator,
        "resizable": true,
        "wrapText": false,
        "autoHeight": false,
        "type": "date"
      },
      {
        "headerName": "Petitioner application #",
        "field": "proceedingMetadata.petiApplicationId",
        "width": 145,
        "minWidth": 145,
        "resizable": true
      },
      {
        "headerName": "Petitioner patent #",
        "field": "proceedingMetadata.petiPatentNumber",
        "width": 145,
        "minWidth": 145,
        "resizable": true
      },
      {
        "headerName": "Petitioner",
        "field": "proceedingMetadata.petiRealParty",
        "width": 200,
        "minWidth": 200,
        "resizable": true,
        "tooltipField": 'proceedingMetadata.petiRealParty',
        "tooltipComponentParams": { data: 'proceedingMetadata.petiRealParty' }
      },
      {
        "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITIONER_TECH_CENTER,
        "field": "proceedingMetadata.petiTechCenterId",
        "width": 135,
        "minWidth": 135,
        "resizable": true
      },
      {
        "headerName": "PO/Respondent application #",
        "field": "proceedingMetadata.poApplicationId",
        "width": 150,
        "minWidth": 150,
        "resizable": true
      },
      {
        "headerName": "PO/Respondent patent #",
        "field": "proceedingMetadata.poPatentNumber",
        "width": 150,
        "minWidth": 150,
        "resizable": true
      },
      {
        "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT_TECH_CENTER,
        "field": "proceedingMetadata.poTechCenterId",
        "width": 150,
        "minWidth": 150,
        "resizable": true
      },
      {
        "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT,
        "field": "proceedingMetadata.poRealParty",
        "width": 175,
        "minWidth": 175,
        "resizable": true,
        "tooltipField": 'proceedingMetadata.poRealParty',
        "tooltipComponentParams": { data: 'proceedingMetadata.poRealParty' }
      },
      {
        "headerName": "APJ1/APJ2+",
        "field": "proceedingMetadata.judges",
        "width": 175,
        "minWidth": 175,
        "resizable": true,
        "tooltipField": 'proceedingMetadata.judges',
        "tooltipComponentParams": { data: 'proceedingMetadata.judges' },
        "cellRendererFramework": JudgePanelRendererComponent,
        "cellRendererParams": (params: ICellRendererParams) => this.gridHelper.formatJudgePanelTooltip(params)
      },
      {
        "headerName": "Status",
        "field": "proceedingMetadata.statusDisplay",
        "width": 200,
        "minWidth": 200,
        "resizable": true
      },
      {
        "headerName": "Filing party",
        "field": "documentInfo.docFilingParty",
        "width": 125,
        "minWidth": 125,
        "resizable": true
      },
      {
        "headerName": "Availability",
        "field": "documentInfo.availability",
        "width": 125,
        "minWidth": 125,
        "resizable": true
      },
      {
        "headerName": "Case confidentiality",
        "field": "proceedingMetadata.caseConfidentiality",
        "width": 125,
        "minWidth": 125,
        "resizable": true
      },
    ]
  }


  selectedCaseTypes: Array<string> = [];
  caseTypes: Array<any> = [
    {
      val: false,
      description: 'IPR',
      code: 'IPR'
    },
    {
      val: false,
      description: 'PGR',
      code: 'PGR'
    },
    {
      val: false,
      description: 'CBM',
      code: 'CBM'
    },
    {
      val: false,
      description: 'DER',
      code: 'DER'
    }
  ];
  searchBy = 'case';

  filingParties: Array<any> = [];
  availabilities: Array<any> = [];
  paperTypes: Array<any> = [];

  rowData = {
    caseData: [],
    documentData: []
  }

  searchResults: Array<any> = [];

  gridPagination: GridPagination = new GridPagination();


  searchCriteria = {
    fromDate: null,
    fromMax: null,
    toDate: null,
    toMin: null
  };

  judgeList: Array<any> = [];

  caseSearch: CaseSearch = new CaseSearch();
  documentSearch: DocumentSearch = new DocumentSearch();

  options = {
    multiple: false,
    closeOnSelect: true,
    width: '100%',
    allowClear: true,
    theme: 'bootstrap',
    openOnEnter: true,
    // minimumResultsForSearch: Infinity - use to hide search box
  }

  numberOfFilters = 0;
  searching = false;
  message = 'Enter search criteria to display results';
  resultsFound = false;
  validations = {
    fromDateError: false,
    toDateError: false,
    dateErrorMessage: null
  };
  filterType: string = null;
  popoverContent: string = `<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>`;

  constructor(
    private readonly commonService: CommonService,
    private readonly commonUtils: CommonUtilitiesService,
    private readonly gridHelper: GridHelperService,
    private readonly trialsService: TrialsService,
    public changeDetector: ChangeDetectorRef,
    private modalService: BsModalService
  ) { }

  ngOnInit(): void {
    this.frameworkComponents = { customTooltip: ToolTipComponent };
    this.gridPagination.pageSize = 25;
    this.getFilingParties();
    this.getAvailabilities();
    // this.getPaperTypes();
    this.getJudgeList();
    this.popoverShow();
  }
/*istanbul ignore next*/
  popoverShow() {
    $(function () {
      $('.fa-info-circle').hover(function(){
        $('[data-toggle="popover"]').popover({placement: 'top'}).popover()
      })
    })
  }
/*istanbul ignore next*/
  ngAfterViewInit(): void  {
    // this.checkboxDropdownComponent.toggleAll('all');
    this.caseTypesDropdownComponent?this.caseTypesDropdownComponent.toggleAll('all'): "";
    // this.paperTypesDropdownComponent.toggleAll('all');
    this.documentCaseTypesDropdownComponent?this.documentCaseTypesDropdownComponent.toggleAll('all'):"";
    this.filingPartiesDropdownComponent?this.filingPartiesDropdownComponent.toggleAll('all'):"";
    this.availabilitiesDropdownComponent?this.availabilitiesDropdownComponent.toggleAll('all'):"";
    this.changeDetector.detectChanges();
  }

  getFilingParties() {
    this.commonService.getDropDownList(PtabTrialConstants.REFERENCE_TYPES.FILING_PARTY).subscribe((filingPartyResponse) => {
      console.log('filingPartyResponse: ', filingPartyResponse);
      filingPartyResponse.forEach((filingParty) => {
        this.filingParties.push({
          val: false,
          description: filingParty.displayNameText,
          code: filingParty.code
        });
      });
    });
  };


  getAvailabilities() {
    this.commonService.getDropDownList(PtabTrialConstants.REFERENCE_TYPES.AVAILABILITY).subscribe((availabilitiesResponse) => {
      console.log('availabilitiesResponse: ', availabilitiesResponse);
      availabilitiesResponse.forEach((availability) => {
        this.availabilities.push({
          val: false,
          description: availability.displayNameText,
          code: availability.code
        });
      });
    });
  };


  // getPaperTypes() {
  //   this.commonService.getDropDownList(PtabTrialConstants.REFERENCE_TYPES.PAPER_TYPE).subscribe((paperTypesResponse) => {
  //     console.log('paperTypesResponse: ', paperTypesResponse);
  //     paperTypesResponse.forEach((paperType) => {
  //       this.paperTypes.push({
  //         val: false,
  //         description: paperType.displayNameText
  //       });
  //     });
  //   });
  // };

/*istanbul ignore next*/
  getJudgeList() {
    this.trialsService.getJudgeList().subscribe((judgeListResponse) => {
      judgeListResponse.listofJudges.sort((a, b) => {
        var nameA = a.prefferedName.toUpperCase(); // ignore upper and lowercase
        var nameB = b.prefferedName.toUpperCase(); // ignore upper and lowercase
        if (nameA < nameB) {
          return -1;
        }
        if (nameA > nameB) {
          return 1;
        }

        // names must be equal
        return 0;
      });
      this.judgeList = this.commonUtils.setTypeaheadList(judgeListResponse.listofJudges, "prefferedName", "prefferedName");
    });
  }




  getCaseSearchResults() {
    this.searching = true;
    this.resultsFound = false;
    this.trialsService.searchByCase(this.caseSearch).subscribe((caseSearchResp => {
      caseSearchResp.forEach((element) => {
        element[PtabTrialConstants.KEY_DATES.FILING_DATE.KEY] = this.commonUtils.parseKeyDates(element.mileStoneDt, PtabTrialConstants.KEY_DATES.FILING_DATE.DESC);
        element[PtabTrialConstants.KEY_DATES.DECISION_TO_INSTITUE.KEY] = this.commonUtils.parseKeyDates(element.mileStoneDt, PtabTrialConstants.KEY_DATES.DECISION_TO_INSTITUE.DESC);
        element[PtabTrialConstants.KEY_DATES.TERMINATION_DECISION.KEY] = this.commonUtils.parseKeyDates(element.mileStoneDt, PtabTrialConstants.KEY_DATES.TERMINATION_DECISION.DESC);
        element.allPartiesInfoParsed = this.commonUtils.parseAllPartiesInfo(element.allPartiesInfo);
        element.decisionOutcome = this.commonUtils.findDecisionOutcome(element.mileStoneDt);
      });
      this.rowData.caseData = caseSearchResp;
      this.searchResults = [...caseSearchResp];
      this.filterType = "case";
      this.resultsFound = true;
      this.gridPagination.totalItems = this.rowData.caseData.length;
      this.numberOfFilters = 0;
      setTimeout(() => {
      this.gridPagination.totalPages = this.gridApi.paginationGetTotalPages();
      this.gridPagination.currentPage = 1;
      this.setPaginationDetails();
      }, 200);
      this.searching = false;
      this.message = "No records found"
    }), (caseSearchFailure) => {
      console.log("caseSearchFailure: ", caseSearchFailure);
      this.searching = false;
    });
  };


/*istanbul ignore next*/
  getDocumentSearchResults() {
    if (!this.validateDocumentDates()) {
      return;
    } else if ((this.searchCriteria.fromDate || this.searchCriteria.toDate) && (!this.documentSearch.proceedingNumber && !this.documentSearch.documentText)) {
      this.openWarningModal();
    } else {
      this.searching = true;
    this.resultsFound = false;
    if (this.searchCriteria.fromDate || this.searchCriteria.toDate) {
      this.documentSearch.uploadedStartDate = this.commonUtils.convertDatePickerToDisplayDate(this.searchCriteria.fromDate);
      this.documentSearch.uploadedEndDate = this.commonUtils.convertDatePickerToDisplayDate(this.searchCriteria.toDate);
      // this.documentSearch.uploadedStartDate = this.searchCriteria.fromDate;
      // this.documentSearch.uploadedEndDate = this.searchCriteria.toDate;
    }
    if (this.documentSearch.filingParties.length > 0) {
      let tempFilingParty = [];
      this.documentSearch.filingParties.forEach((filingParty) => {
        tempFilingParty.push(filingParty.toUpperCase());
      })
      this.documentSearch.filingParties = [];
      this.documentSearch.filingParties = [...tempFilingParty];
    }
      this.trialsService.searchByDocument(this.documentSearch).subscribe((docSearchResponse) => {
        this.rowData.documentData = [];
        this.message = "Searching...";
      if (docSearchResponse && docSearchResponse.documentSearchResults) {
        docSearchResponse.documentSearchResults.forEach((element) => {
          element.docFilingDateStr = this.gridHelper.convertDateToString(new Date(element.documentInfo.filingDate).getTime());
          //   element.institutionDecisionDateStr =this.gridHelper.convertDateToString(new Date(element.proceedingMetadata.instDecisionDate).getTime());
          // element.proceedingMetadata[PtabTrialConstants.KEY_DATES.FILING_DATE.KEY] = this.commonUtils.parseKeyDates(element.proceedingMetadata.mileStoneDt, PtabTrialConstants.KEY_DATES.FILING_DATE.DESC);
          element.proceedingMetadata[PtabTrialConstants.KEY_DATES.DECISION_TO_INSTITUE.KEY] = this.commonUtils.parseKeyDates(element.proceedingMetadata.mileStoneDt, PtabTrialConstants.KEY_DATES.DECISION_TO_INSTITUE.DESC);
          element.documentInfo.docFilingParty = this.setFilingPartyDescription(element.documentInfo.docFilingParty);
          element.documentInfo.availability = this.setAvailabilityDescription(element.documentInfo.availability);
        });
        this.rowData.documentData = [...docSearchResponse.documentSearchResults];
        this.searchResults = [...docSearchResponse.documentSearchResults];
        this.filterType = "document";
        this.resultsFound = true;
        this.gridPagination.totalItems = this.rowData.documentData.length;
        this.numberOfFilters = 0;
        setTimeout(() => {
        this.gridPagination.totalPages = this.gridApi.paginationGetTotalPages();
        this.gridPagination.currentPage = 1;
        this.setPaginationDetails();
        }, 200);
      }
      this.searching = false;
      this.message = "No records found"
    }, (docSearchFailure) => {
      this.commonUtils.setToastr('error', docSearchFailure.error.message);
      this.searching = false;
    });
    }

  };

/*istanbul ignore next*/
  setFilingPartyDescription(docFilingParty) {
    let foundItem = this.filingParties.find((filingParty) => {
      return filingParty.code.toLowerCase() === docFilingParty.toLowerCase();
    });
    return foundItem ? foundItem.description : docFilingParty;
  }

/*istanbul ignore next*/
  setAvailabilityDescription(docAvailability) {
    let foundItem = this.availabilities.find((availability) => {
      return availability.code.toLowerCase() === docAvailability.toLowerCase();
    });
    return foundItem ? foundItem.description : docAvailability;
  }

/* istanbul ignore next*/
  openWarningModal() {
    let modal: InfoModalModel = {
      infoText: ["Please enter search criteria for AIA review # and/or Document text"],
      title: "Additional search criteria required",
      showLeftBtn: false,
      leftBtnClass: 'btn-default',
      leftBtnLabel: 'Back',
      showRightBtn: true,
      rightBtnClass: 'btn-primary',
      rightBtnLabel: 'OK',
      isConfirm: false,
      modalHeight: 100
    }
    let response = this.commonUtils.openConfirmModal(modal);
    response.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        this.modalService.hide();
      }
    })
  }

/*istanbul ignore next*/
  validateDocumentDates() {
    let datesAreValid = true;
    this.validations.toDateError = false;
    this.validations.fromDateError = false;
    if (this.searchCriteria.fromDate && !this.searchCriteria.toDate) {
      this.validations.toDateError = true;
      this.validations.dateErrorMessage = "Please enter 'to' date";
      datesAreValid = false;
    } else if (!this.searchCriteria.fromDate && this.searchCriteria.toDate) {
      this.validations.fromDateError = true;
      this.validations.dateErrorMessage = "Please enter 'from' date";
      datesAreValid = false;
    }
    if (this.searchCriteria.fromDate && this.searchCriteria.toDate) {
      const fromDateEpoch = this.commonUtils.convertDatePickerToEpoch(this.searchCriteria.fromDate);
      const toDateEpooch = this.commonUtils.convertDatePickerToEpoch(this.searchCriteria.toDate);
      if (fromDateEpoch > toDateEpooch) {
        this.validations.toDateError = true;
        this.validations.fromDateError = true;
        this.validations.dateErrorMessage = `'To' date must be greater than 'from' date`;
        datesAreValid = false;
      }
    }
    return datesAreValid;
  }

/*istanbul ignore next*/
  dateChange(range) {
    if (range === 'from') {
      this.searchCriteria.toMin = this.commonUtils.setDateOnDatePicker(this.searchCriteria.fromDate);
    } else if (range === 'to') {
      this.searchCriteria.fromMax = this.commonUtils.setDateOnDatePicker(this.searchCriteria.toDate);
    }
  }

/*istanbul ignore next*/
  clearCaseSearchResults() {
    this.caseSearch = new CaseSearch();
    // this.checkboxDropdownComponent.toggleAll('all');
    this.caseTypesDropdownComponent.toggleAll('all');
    this.rowData.caseData = [];
    this.resultsFound = false;
  }

/*istanbul ignore next*/
  clearDocumentSearchResults() {
    this.documentSearch = new DocumentSearch();
    // this.checkboxDropdownComponent.toggleAll('all');
    // this.paperTypesDropdownComponent.toggleAll('all');
    this.documentCaseTypesDropdownComponent?this.documentCaseTypesDropdownComponent.toggleAll('all'): "";
    this.availabilitiesDropdownComponent?this.availabilitiesDropdownComponent.toggleAll('all'): "";
    this.availabilitiesDropdownComponent?this.filingPartiesDropdownComponent.toggleAll('all'): "";
    // this.filingPartiesDropdownComponent.toggleAll('all');
    // this.availabilitiesDropdownComponent.toggleAll('all');
    this.rowData.documentData = [];
    this.searchCriteria = {
      fromDate: null,
      fromMax: null,
      toDate: null,
      toMin: null
    };
    this.validations = {
      fromDateError: false,
      toDateError: false,
      dateErrorMessage: null
    };
    this.resultsFound = false;
  }

/*istanbul ignore next*/
  setSelectedCaseTypes(e) {
    this.caseSearch.trailTypes = e;
    this.documentSearch.trailTypes = e;
  }
/*istanbul ignore next*/
  setSelectedFilingParty(e) {
    this.documentSearch.filingParties = e;
  }
/*istanbul ignore next*/
  setSelectedAvailability(e) {
    this.documentSearch.visibilityOptions = e;
  }

/*istanbul ignore next*/
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.gridPagination.totalPages = this.gridApi.paginationGetTotalPages();
    this.gridPagination.currentPage = 1;
    this.setPaginationDetails();
  }

/*istanbul ignore next*/
  onFilterChanged() {
    const resp = this.gridHelper.onFilterChanged(this.gridApi);
    this.numberOfFilters = resp.numberOfFilters + this.additionalFiltersComponent.tags.length;
    this.gridPagination.totalItems = this.gridApi.getDisplayedRowCount();
  }

/*istanbul ignore next*/
  getTotalCount() {
    if (this.gridApi) {
      const totalCount = this.commonUtils.formatNumber(this.gridApi.getDisplayedRowCount());
      return totalCount ? totalCount : 0
    } else {
      return 0
    }
  }

/*istanbul ignore next*/
  paginationControls(step) {
    switch (step) {
      case 'first':
        this.gridApi.paginationGoToFirstPage();
        break;
        case 'previous':
          this.gridApi.paginationGoToPreviousPage();
        break;
        case 'next':
          this.gridApi.paginationGoToNextPage();
        break;
        case 'last':
          this.gridApi.paginationGoToLastPage();
        break;
      default:
        break;
    }
    this.gridPagination.currentPage = this.gridApi.paginationGetCurrentPage() + 1;
    this.setPaginationDetails();
  };

/*istanbul  ignore next*/
  goToPage() {
    this.gridApi.paginationGoToPage(parseInt(this.gridPagination.currentPage) - 1);
    this.setPaginationDetails();
  }

/*istanbul  ignore next*/
  setPageSize() {
    this.gridApi.paginationSetPageSize(parseInt(this.gridPagination.pageSize));
    this.gridPagination.totalPages = this.gridApi.paginationGetTotalPages();
    this.setPaginationDetails();
  }

/*istanbul ignore next*/
  setPaginationDetails() {
    const tempTo = this.gridPagination.pageSize * this.gridPagination.currentPage;
    this.gridPagination.to = this.gridPagination.totalItems > tempTo ? this.gridPagination.pageSize * this.gridPagination.currentPage : this.gridPagination.totalItems;
    this.gridPagination.from = (tempTo - this.gridPagination.pageSize) + 1
  }


/*istanbul ignore next*/
  clearGridFilters() {
    this.gridApi.setFilterModel(null);
    this.additionalFiltersComponent.clearFilters();
  }


  exportDataAsCsv() {
    this.commonUtils.setToastr('success', 'Processing export...');
    this.gridHelper.exportDataAsCsv(this.gridApi, 'Searched result');
  }

/*istanbul ignore next*/
  setFilteredResults(filteredResults) {
    if (this.filterType === "case") {
      this.rowData.caseData = filteredResults;
    } else if (this.filterType === "document") {
      this.rowData.documentData = filteredResults;
    }
    this.gridPagination.totalItems = filteredResults.length;

    setTimeout(() => {
      this.gridPagination.totalPages = this.gridApi.paginationGetTotalPages();
      this.gridPagination.currentPage = 1;
      this.setPaginationDetails();
      }, 200);
  }

/*istanbul ignore next*/
  isFirstColumn(params) {
    const displayedColumns = params.columnApi.getAllDisplayedColumns();
    const thisIsFirstColumn = displayedColumns[0] === params.column;
    return thisIsFirstColumn;
  }

/*istanbul ignore next*/
  setFilterCount(filterCount) {
    const filterModel = this.gridApi.getFilterModel();
    const resp = this.gridHelper.onFilterChanged(this.gridApi);
    this.numberOfFilters = resp.numberOfFilters + filterCount;
    this.gridApi.setFilterModel(filterModel);
  }


  // downloadZip() {
  //   let selectedRows = this.gridApi.getSelectedRows();
  //   console.log('selectedRows: ', selectedRows);
  // }


}
