import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonUtilitiesService } from '../../../../services/common-utilities.service';
import { CommonService } from '../../../../services/common.service';
import { FormsModule } from '@angular/forms';
import { AdditionalFiltersComponent } from './additional-filters.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { of } from 'rxjs';

describe('AdditionalFiltersComponent', () => {
  let component: AdditionalFiltersComponent;
  let fixture: ComponentFixture<AdditionalFiltersComponent>;

  beforeEach(() => {
    const commonUtilitiesServiceStub = () => ({
      setTypeaheadOptions: () => ({}),
      setTypeaheadList: (decisionOutComeTypes, string, string1) => ({}),
      parseKeyDates: (mileStoneDt, dESC) => ({}),
      convertDatePickerToEpoch: fromDate => ({}),
      convertDatePickerToDisplayDate: institutionDateFrom => ({}),
      setDateOnDatePicker: dateVal => ({})
    });
    const commonServiceStub = () => ({
      getDecisionOutcomeTypes: arg => ({ subscribe: f => f({}) })
    });
    TestBed.configureTestingModule({
      imports: [FormsModule, NgbModule],
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [AdditionalFiltersComponent],
      providers: [
        {
          provide: CommonUtilitiesService,
          useFactory: commonUtilitiesServiceStub
        },
        { provide: CommonService, useFactory: commonServiceStub }
      ]
    });
    fixture = TestBed.createComponent(AdditionalFiltersComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`tags has default value`, () => {
    expect(component.tags).toEqual([]);
  });

  it(`enableSearch has default value`, () => {
    expect(component.enableSearch).toEqual(true);
  });

  it(`showError has default value`, () => {
    expect(component.showError).toEqual(true);
  });

  it(`decisionOutcomeList has default value`, () => {
    expect(component.decisionOutcomeList).toEqual([]);
  });

  it(`popoverContent has default value`, () => {
    expect(component.popoverContent).toEqual(
      `<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>`
    );
  });

  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      const commonUtilitiesServiceStub: CommonUtilitiesService = fixture.debugElement.injector.get(
        CommonUtilitiesService
      );
      spyOn(component, 'getDecisionOutcomeTypes').and.returnValue();
      spyOn(component, 'popoverInitiate').and.callThrough();
      spyOn(
        commonUtilitiesServiceStub,
        'setTypeaheadOptions'
      ).and.callThrough();
      component.ngOnInit();
      expect(component.getDecisionOutcomeTypes).toBeDefined();
      expect(component.popoverInitiate).toBeDefined();
      expect(commonUtilitiesServiceStub.setTypeaheadOptions).toBeDefined();
    });
  });

  describe('getDecisionOutcomeTypes', () => {
    it('makes expected calls', () => {
      const commonUtilitiesServiceStub: CommonUtilitiesService = fixture.debugElement.injector.get(
        CommonUtilitiesService
      );
      const commonServiceStub: CommonService = fixture.debugElement.injector.get(
        CommonService
      );
      let filingPartyResponse = [{'displayNameText':'','code':'','decisionOutcomeResponse':[{'decisionOutcomeGroupTypes':[]}]},{'displayNameText':'','code':'','decisionOutcomeResponse':[{'decisionOutcomeGroupTypes':[]}]}]
      spyOn(commonUtilitiesServiceStub, 'setTypeaheadList').and.callThrough();
      spyOn(commonServiceStub, 'getDecisionOutcomeTypes').and.returnValue(of(filingPartyResponse));
      component.getDecisionOutcomeTypes();
      expect(commonUtilitiesServiceStub.setTypeaheadList).toBeDefined();
      expect(commonServiceStub.getDecisionOutcomeTypes).toBeDefined();
    });
  });

  describe('validateFilters', () => {
    it('makes expected calls', () => {
      spyOn(component, 'validateDateRanges').and.callThrough();
      component.validateFilters();
      expect(component.validateDateRanges).toBeDefined();
    });
  });

  describe('addTags', () => {
    it('makes expected calls', () => {
      const commonUtilitiesServiceStub: CommonUtilitiesService = fixture.debugElement.injector.get(
        CommonUtilitiesService
      );
      spyOn(
        commonUtilitiesServiceStub,
        'convertDatePickerToDisplayDate'
      ).and.callThrough();
      component.addTags();
      expect(
        commonUtilitiesServiceStub.convertDatePickerToDisplayDate
      ).toBeDefined();
    });
  });

  describe('clearFilters', () => {
    it('makes expected calls', () => {
      spyOn(component, 'applyFilters').and.callThrough();
      component.clearFilters();
      expect(component.applyFilters).toBeDefined();
    });
  });
});
