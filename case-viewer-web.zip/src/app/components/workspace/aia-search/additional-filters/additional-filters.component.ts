import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { PtabTrialConstants } from '../../../../constants/ptab-trials.constants';
import { FilterParams } from '../../../../models/search/FilterParams';
import { FilterValidations } from '../../../../models/search/FilterValidations';
import { CommonUtilitiesService } from '../../../../services/common-utilities.service';
import { CommonService } from '../../../../services/common.service';
declare let $:any;
@Component({
  selector: 'app-additional-filters',
  templateUrl: './additional-filters.component.html',
  styleUrls: ['./additional-filters.component.less']
})
export class AdditionalFiltersComponent implements OnInit {

  @Input() searchResults: any;
  @Input() filterType: string;

  @Output() filteredResultsEmitter: EventEmitter<Array<any>> = new EventEmitter<any>();
  @Output() filterCountEmitter: EventEmitter<Number> = new EventEmitter<Number>();

  filterParams: FilterParams = new FilterParams();
  tags: Array<any> = [];
  enableSearch = true;
  dateRange = {
    institution: {
      min: null,
      max: null
    },
    filing: {
      min: null,
      max: null
    },
    termination: {
      min: null,
      max: null
    }
  }

  validations: FilterValidations;
  showError = true;
  decisionOutcomeList: Array<any> = [];
  dropdownOptions: any;
  selectedDecisionOutcome: any;
  popoverContent: string = `<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>`;

  constructor(
    private readonly commonUtils: CommonUtilitiesService,
    private readonly commonService: CommonService
  ) { }
/*istanbul ignore next*/
  ngOnInit(): void {
    this.dropdownOptions = this.commonUtils.setTypeaheadOptions();
    this.getDecisionOutcomeTypes();
    /*istanbul ignore next*/
   this.popoverInitiate();
  }

/*istanbul ignore next*/
popoverInitiate() {
  $(function () {
    $('.fa-info-circle').hover(function(){
      $('[data-toggle="popover"]').popover({placement: 'top'}).popover()
    })
    // $('[data-toggle="popover"]').popover()
  })
}
/*istanbul ignore next*/
  getDecisionOutcomeTypes() {
    this.commonService.getDecisionOutcomeTypes(`${PtabTrialConstants.REFERENCE_TYPES.TYPE_CODE}${PtabTrialConstants.REFERENCE_TYPES.DECISION_OUTCOME}`).subscribe((decisionOutcomeResponse) => {
      this.decisionOutcomeList = this.commonUtils.setTypeaheadList(decisionOutcomeResponse[0].decisionOutcomeGroupTypes[0].decisionOutComeTypes, 'identifier', 'descriptionText');
    });
  }

/*istanbul ignore next*/
  setDecisionOutcome(e) {
    console.log('e: ', e);
    const foundDecisionOutcome = this.decisionOutcomeList.find((decision) => {
      /** using == instead of === because decision could be number or string */
      return decision.identifier == e;
    });
    console.log("Found decision outcome: ", foundDecisionOutcome);

    this.filterParams.decisionOutcome = foundDecisionOutcome ? foundDecisionOutcome.descriptionText: null;
  }

/*istanbul ignore next*/
  applyFilters(filtersDropdown) {
    console.log('filtersDropdown: ', filtersDropdown);

    if (this.validateFilters()) {
      if (filtersDropdown) {
        filtersDropdown.close();
      }
      let filteredResults = [];
      if (this.filterType === "case") {
        this.searchResults.forEach((item) => {
          let checkNextCondition = true;
          let keyDateEpoch = null;

          // Party name
          if (checkNextCondition && this.filterParams.partyName) {
            let foundParty = false;
            if (checkNextCondition && this.filterParams.additionalRealParty) {
              foundParty = this.findParty(item, 'additionalPartyList', this.filterParams.partyName);
            }
            if (!foundParty && this.filterParams.counsel) {
              foundParty = this.findParty(item, 'couselList', this.filterParams.partyName);
            }
            checkNextCondition = foundParty;
          }

          // Institution date range
          if (checkNextCondition && (this.filterParams.institutionDateFrom || this.filterParams.institutionDateTo)) {
            keyDateEpoch = new Date(this.commonUtils.parseKeyDates(item.mileStoneDt, PtabTrialConstants.KEY_DATES.DECISION_TO_INSTITUE.DESC)).getTime();
            checkNextCondition = this.checkDateRange(this.filterParams.institutionDateFrom, this.filterParams.institutionDateTo, keyDateEpoch);

          }

          // Filing date range
          if (checkNextCondition && (this.filterParams.filingDateFrom || this.filterParams.filingDateTo)) {
            keyDateEpoch = new Date(this.commonUtils.parseKeyDates(item.mileStoneDt, PtabTrialConstants.KEY_DATES.FILING_DATE.DESC)).getTime();
            checkNextCondition = this.checkDateRange(this.filterParams.filingDateFrom, this.filterParams.filingDateTo, keyDateEpoch);
          }

          // Termination date range
          if (checkNextCondition && (this.filterParams.terminationDateFrom || this.filterParams.terminationDateTo)) {
            keyDateEpoch = new Date(this.commonUtils.parseKeyDates(item.mileStoneDt, PtabTrialConstants.KEY_DATES.TERMINATION_DECISION.DESC)).getTime();
            checkNextCondition = this.checkDateRange(this.filterParams.terminationDateFrom, this.filterParams.terminationDateTo, keyDateEpoch);
          }

          // Decision outcome
          if (checkNextCondition && this.filterParams.decisionOutcome) {
            if (item.decisionOutcome && item.decisionOutcome.toLowerCase() === this.filterParams.decisionOutcome.toLowerCase()) {
              checkNextCondition = true;
            } else {
              checkNextCondition = false;
            }
          }


          if (checkNextCondition) {
            filteredResults.push(item);
          }
        });
      } else if (this.filterType === "document") {
        this.searchResults.forEach((item) => {
          let checkNextCondition = true;
          let keyDateEpoch = null;

          // Party name
          if (checkNextCondition && this.filterParams.partyName) {
            let foundParty = false;
            if (checkNextCondition && this.filterParams.additionalRealParty) {
              foundParty = this.findParty(item.proceedingMetadata, 'additionalPartyList', this.filterParams.partyName);
            }
            if (!foundParty && this.filterParams.counsel) {
              foundParty = this.findParty(item.proceedingMetadata, 'couselList', this.filterParams.partyName);
            }
            checkNextCondition = foundParty;
          }

          // Institution date range
          if (checkNextCondition && (this.filterParams.institutionDateFrom || this.filterParams.institutionDateTo)) {
            keyDateEpoch = new Date(this.commonUtils.parseKeyDates(item.proceedingMetadata.mileStoneDt, PtabTrialConstants.KEY_DATES.DECISION_TO_INSTITUE.DESC)).getTime();
            checkNextCondition = this.checkDateRange(this.filterParams.institutionDateFrom, this.filterParams.institutionDateTo, keyDateEpoch);

          }

          // Filing date range
          if (checkNextCondition && (this.filterParams.filingDateFrom || this.filterParams.filingDateTo)) {
            keyDateEpoch = new Date(this.commonUtils.parseKeyDates(item.proceedingMetadata.mileStoneDt, PtabTrialConstants.KEY_DATES.FILING_DATE.DESC)).getTime();
            checkNextCondition = this.checkDateRange(this.filterParams.filingDateFrom, this.filterParams.filingDateTo, keyDateEpoch);
          }

          // Termination date range
          if (checkNextCondition && (this.filterParams.terminationDateFrom || this.filterParams.terminationDateTo)) {
            keyDateEpoch = new Date(this.commonUtils.parseKeyDates(item.proceedingMetadata.mileStoneDt, PtabTrialConstants.KEY_DATES.TERMINATION_DECISION.DESC)).getTime();
            checkNextCondition = this.checkDateRange(this.filterParams.terminationDateFrom, this.filterParams.terminationDateTo, keyDateEpoch);
          }

          // Decision outcome
          if (checkNextCondition && this.filterParams.decisionOutcome) {
            if (item.proceedingMetadata.decisionOutcome && item.proceedingMetadata.decisionOutcome.toLowerCase() === this.filterParams.decisionOutcome.toLowerCase()) {
              checkNextCondition = true;
            } else {
              checkNextCondition = false;
            }
          }


          if (checkNextCondition) {
            filteredResults.push(item);
          }
        });
   }
    console.log("Filtered results: ", filteredResults);
    this.addTags();
    this.filteredResultsEmitter.emit(filteredResults);
   }
  }
/*istanbul ignore next*/
  findParty(item, partyToFind, searchCriteria) {
    let foundParty = false;
    if (item.allPartiesInfoParsed && item.allPartiesInfoParsed.petitioner && item.allPartiesInfoParsed.petitioner[partyToFind] && item.allPartiesInfoParsed.petitioner[partyToFind].length > 0) {
      const petitionerPartyFound = item.allPartiesInfoParsed.petitioner[partyToFind].find((info) => {
        return info.toLowerCase().includes(searchCriteria.toLowerCase());
      })
      if (petitionerPartyFound) {
        foundParty = true
      }
    }
    if (!foundParty && item.allPartiesInfoParsed && item.allPartiesInfoParsed.patentOwner && item.allPartiesInfoParsed.patentOwner[partyToFind] && item.allPartiesInfoParsed.patentOwner[partyToFind].length > 0) {
      const poPartyFound = item.allPartiesInfoParsed.patentOwner[partyToFind].find((info) => {
        return info.toLowerCase().includes(searchCriteria.toLowerCase());
      })
      if (poPartyFound) {
        foundParty = true;
      }
    }
    return foundParty;
  }

/*istanbul ignore next*/
  validateFilters() {
    this.validations = new FilterValidations();
    let formIsValid = true;

    if (this.filterParams.partyName) {
      if (!this.filterParams.additionalRealParty && !this.filterParams.counsel) {
        this.validations.partyNameHasError = true;
        this.validations.partyNameMessage = "Please select at least 1 party type";
        formIsValid = false;
      }
    }

    formIsValid = this.validateDateRanges(this.filterParams.institutionDateFrom, this.filterParams.institutionDateTo, "institution", formIsValid);
    formIsValid = this.validateDateRanges(this.filterParams.filingDateFrom, this.filterParams.filingDateTo, "filing", formIsValid);
    formIsValid = this.validateDateRanges(this.filterParams.terminationDateFrom, this.filterParams.terminationDateTo, "termination", formIsValid);
    return formIsValid;
  }

/*istanbul ignore next*/
  validateDateRanges(fromDate, toDate, dateType, formIsValid) {
    if (fromDate && !toDate) {
      this.validations[`${dateType}ToHasError`] = true;
      this.validations[`${dateType}Message`] = "Please enter 'to' date";
      formIsValid = false;
    } else if (!fromDate && toDate) {
      this.validations[`${dateType}FromHasError`] = true;
      this.validations[`${dateType}Message`] = "Please enter 'from' date";
      formIsValid = false;
    }
    if (fromDate && toDate) {
      const fromDateEpoch = this.commonUtils.convertDatePickerToEpoch(fromDate);
      const toDateEpooch = this.commonUtils.convertDatePickerToEpoch(toDate);
      if (fromDateEpoch > toDateEpooch) {
        this.validations[`${dateType}ToHasError`] = true;
        this.validations[`${dateType}FromHasError`] = true;
        this.validations[`${dateType}Message`] = `'To' ${dateType} date must be greater than 'from' ${dateType} date`;
        formIsValid = false;
      }
    }
    return formIsValid;
  }

/*istanbul ignore next*/
  checkDateRange(dateFrom, dateTo, keyDateEpoch) {
    const fromDateInEpoch = this.commonUtils.convertDatePickerToEpoch(dateFrom);
    const toDateInEpoch = this.commonUtils.convertDatePickerToEpoch(dateTo);

    if (dateFrom && dateTo) {
      return (keyDateEpoch >= fromDateInEpoch && keyDateEpoch <= toDateInEpoch);
    } else if (dateFrom && !dateTo) {
      return keyDateEpoch >= fromDateInEpoch;
    } else if (dateTo && !dateFrom) {
      return keyDateEpoch <= toDateInEpoch;
    } else {
      return false;
    }
  }

/*istanbul ignore next*/
  addTags() {
    this.tags = [];
    if (this.filterParams.partyName && (this.filterParams.additionalRealParty || this.filterParams.counsel)) {
      const parties = [];
      if (this.filterParams.additionalRealParty) {
        parties.push("Additional real party");
      }
      if (this.filterParams.counsel) {
        parties.push("Counsel");
      }
      this.tags.push({
        "description": `${this.filterParams.partyName}`,
        "tooltip": `${parties.join(" and ")}`,
        "tagType": "party"
      });
    }

    if (this.filterParams.institutionDateFrom && this.filterParams.institutionDateTo) {
      const fromDate = this.commonUtils.convertDatePickerToDisplayDate(this.filterParams.institutionDateFrom);
      const toDate = this.commonUtils.convertDatePickerToDisplayDate(this.filterParams.institutionDateTo);
      this.tags.push({
        "description": `Institution date range: ${fromDate} to ${toDate}`,
        "tooltip": `Institution date range: ${fromDate} to ${toDate}`,
        "tagType": "institutionDate"
      });
    }

    if (this.filterParams.filingDateFrom && this.filterParams.filingDateTo) {
      const fromDate = this.commonUtils.convertDatePickerToDisplayDate(this.filterParams.filingDateFrom);
      const toDate = this.commonUtils.convertDatePickerToDisplayDate(this.filterParams.filingDateTo);
      this.tags.push({
        "description": `Filing date range: ${fromDate} to ${toDate}`,
        "tooltip": `Filing date range: ${fromDate} to ${toDate}`,
        "tagType": "filingDate"
      });
    }


    if (this.filterParams.terminationDateFrom && this.filterParams.terminationDateTo) {
      const fromDate = this.commonUtils.convertDatePickerToDisplayDate(this.filterParams.terminationDateFrom);
      const toDate = this.commonUtils.convertDatePickerToDisplayDate(this.filterParams.terminationDateTo);
      this.tags.push({
        "description": `Termination date range: ${fromDate} to ${toDate}`,
        "tooltip": `Termination date range: ${fromDate} to ${toDate}`,
        "tagType": "terminationDate"
      });
    }

    if (this.filterParams.decisionOutcome) {
      this.tags.push({
        "description": this.filterParams.decisionOutcome,
        "tooltip": this.filterParams.decisionOutcome,
        "tagType": "decision"
      });
    }

      this.filterCountEmitter.emit(this.tags.length)
  }

/*istanbul ignore next*/
  removeTag(tag) {
    this.tags.splice(this.tags.indexOf(tag), 1);
    switch (tag.tagType) {
      case 'party':
        this.filterParams.partyName = null;
        break;
      case "institutionDate":
        this.filterParams.institutionDateFrom = null;
        this.filterParams.institutionDateTo = null;
        break;
      case "filingDate":
        this.filterParams.filingDateFrom = null;
        this.filterParams.filingDateTo = null;
        break;
      case "terminationDate":
        this.filterParams.terminationDateFrom = null;
        this.filterParams.terminationDateTo = null;
        break;
      case 'decision':
        this.filterParams.decisionOutcome = null;
        break;
      default:
        break;
    }
    this.applyFilters(null);
  }

/*istanbul ignore next*/
  clearFilters() {
    this.validations = new FilterValidations();
    this.dateRange = {
      institution: {
        min: null,
        max: null
      },
      filing: {
        min: null,
        max: null
      },
      termination: {
        min: null,
        max: null
      }
    }
    this.filterParams = new FilterParams();
    this.tags = [];
    this.applyFilters(null);
  }

/*istanbul ignore next*/
  setMinMaxDate(range, dateType, dateVal) {
    if (range === 'from') {
      this.dateRange[dateType].min = this.commonUtils.setDateOnDatePicker(dateVal);
    } else if (range === 'to') {
      this.dateRange[dateType].max = this.commonUtils.setDateOnDatePicker(dateVal);
    }
  }

}
