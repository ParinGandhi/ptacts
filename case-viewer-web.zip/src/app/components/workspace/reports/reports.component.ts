import { Component, OnInit } from '@angular/core';

import { ICellRendererParams } from 'ag-grid-community';

import { ActivatedRoute } from '@angular/router';
import { JpViewService } from 'src/app/services/jpview.service';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import GridRefreshModel from 'src/app/models/common/GridRefresh.model';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { JudgePanelRendererComponent } from '../../common/judge-panel-renderer/judge-panel-renderer.component';
import { OpenCaseviewerComponent } from '../../common/open-caseviewer/open-caseviewer.component';
import { ToolTipComponent } from '../tool-tip/tool-tip.component';
import { TrialsService } from 'src/app/services/trials.service';
import { select, Store } from '@ngrx/store';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';


@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.less']
})
export class ReportsComponent implements OnInit {

  selectedType = 'submittedCasesWithMilestoneDt';

  /**
   *  Grid
   */
  gridApi;
  gridColumnApi;
  noRowsTemplate = "No cases found";
  frameworkComponents;
  userPermissions$ = this.store.pipe(select(CaseViewerSelectors.userInfoData));
  defaultColDef = {
    filter: true,
    sortable: true,
    floatingFilter: true,
    suppressMenu: true,
    tooltipComponent: 'customTooltip',
    headerCheckboxSelection: this.isFirstColumn,
      checkboxSelection: this.isFirstColumn,
  };

  reviewTypes = {
    submittedCasesWithMilestoneDt: {
      loadingMessage: "Loading all Submitted cases with milestone dates...",
      noRowsTemplate: "No cases found.",
      fileName: "SubmittedCasesWithMilestoneDt",
      total:null
      // url: `${PtabTrialConstants.AIA_REVIEWS.BASE}${PtabTrialConstants.AIA_REVIEWS.ALL}`
    },
    pendingWithl3judges: {
      loadingMessage: "Loading all pending cases without less than 3 judges",
      noRowsTemplate: "No cases found.",
      fileName: "PendingCasesWithLessthan3judges",
      total:null
      // url: `${PtabTrialConstants.AIA_REVIEWS.BASE}${PtabTrialConstants.AIA_REVIEWS.WITHOUT_MN}`
    },
    defective: {
      loadingMessage: "Loading all defective cases...",
      noRowsTemplate: "No defective cases found.",
      fileName: "Defective",
      total:null
      // url: `${PtabTrialConstants.AIA_REVIEWS.BASE}${PtabTrialConstants.AIA_REVIEWS.DEFECTIVE}`
    },
    readyForTrial: {
      loadingMessage: "Loading all ready for trials certificate cases...",
      noRowsTemplate: "No ready for trials cases found.",
      fileName: "Ready for Trials",
      total:null
      // url: `${PtabTrialConstants.AIA_REVIEWS.BASE}${PtabTrialConstants.AIA_REVIEWS.TRIALS_CERTIFICATE}`
    },
    requiringClosure: {
      loadingMessage: "Loading all cases requiring closure...",
      noRowsTemplate: "No cases requiring closure found.",
      fileName: "Requiring closure",
      total:null
      // url: `${PtabTrialConstants.AIA_REVIEWS.BASE}${PtabTrialConstants.AIA_REVIEWS.REQUIRE_CLOSURE}`
    }
  };


  rowSelection = 'single';
  showLoading = false;
  loadingMessage: string = null;

  gridRefreshValues: GridRefreshModel = {
    refreshFailed: false,
    showLoading: false,
    lastRefresh: null
  }

  columnDefs = {
    aiaReviews: [{
      "headerName": "",
      "field": "",
      "width": 25,
      "minWidth": 25,
      "maxWidth": 25,
      "resizable": false,
      "floatingFilter": false,
      "headerCheckboxSelection": false,
      "cellStyle": {
        "background-color": "#F0F0EE"
      }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.AIA_REVIEW,
      "field": "proceedingNumber",
      "width": 130,
      "minWidth": 130,
      "resizable": true,
      "cellRendererFramework": OpenCaseviewerComponent
    },
    {
      "headerName": "Status",
      "field": "statusDisplay",
      "width": 200,
      "minWidth": 200,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITION_SUBMISSION_DT,
      "field": "submittedDateStr",
      "width": 130,
      "minWidth": 130,
      "resizable": true,
      "comparator": this.gridHelper.dateComparator,
      "headerCheckboxSelection": false,
      "sort": "asc",
      "type": "date"
    },
    {
      "headerName": "NOFDA date",
      "field": "nofdaStr",
      "width": 80,
      "minWidth": 80,
      "comparator": this.gridHelper.dateComparator,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "type": "date"
    },
    {
      "headerName": "Institution decision date",
      "field": "institutionDecisionDateStr",
      "width": 100,
      "minWidth": 100,
      "comparator": this.gridHelper.dateComparator,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "type": "date"
    },
    {
      "headerName": "Termination date",
      "field": "terminationDateStr",
      "width": 100,
      "minWidth": 100,
      "comparator": this.gridHelper.dateComparator,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "type": "date"
    },
    {
      "headerName": "Decision outcome",
      "field": "terminationType",
      "width": 300,
      "minWidth": 200,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "tooltipField": 'terminationType',
      "tooltipComponentParams": { data: 'terminationType' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITIONER_PATENT_NO,
      // "valueGetter": function (params) {
      //   if (!params.data.petitionerPatentNumber || params.data.petitionerPatentNumber === "") {
      //     return params.data.petitionerapplicationId;
      //   } else {
      //     return params.data.petitionerPatentNumber
      //   }
      // },
      "valueGetter": this.gridHelper.valueGetterForPetitionerPatentNoAia,
      "width": 145,
      "minWidth": 145,
      "resizable": true
    },
    {
      "headerName": "Petitioner",
      "field": "petiRealParty",
      "width": 200,
      "minWidth": 200,
      "resizable": true,
      "tooltipField": 'petiRealParty',
      "tooltipComponentParams": { data: 'petiRealParty' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITIONER_TECH_CENTER,
      "field": "petiTechCenterId",
      "width": 100,
      "minWidth": 100,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_PATENT_NO,
      // "valueGetter": function (params) {
      //   if (!params.data.patentNumber || params.data.patentNumber === "") {
      //     return params.data.applicationId;
      //   } else {
      //     return params.data.patentNumber
      //   }
      // },
      "valueGetter": this.gridHelper.valueGetterForPOPatentNoAia,
      "width": 150,
      "minWidth": 150,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT,
      "field": "patentOwnerName",
      "width": 175,
      "minWidth": 175,
      "resizable": true,
      "tooltipField": 'patentOwnerName',
      "tooltipComponentParams": { data: 'patentOwnerName' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT_TECH_CENTER,
      "field": "poTechCenterId",
      "width": 120,
      "minWidth": 120,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.JUDGE_PANEL,
      "field": "judges",
      "width": 175,
      "minWidth": 175,
      "resizable": true,
      "tooltipField": 'judges',
      "tooltipComponentParams": { data: 'judges' },
      "cellRendererFramework": JudgePanelRendererComponent,
      "cellRendererParams": (params: ICellRendererParams) => this.gridHelper.formatJudgePanelTooltip(params)
    }
  ],
    withoutMandatoryNotices: [{
      "headerName": "",
      "field": "",
      "width": 25,
      "minWidth": 25,
      "maxWidth": 25,
      "resizable": false,
      "floatingFilter": false,
      "headerCheckboxSelection": false,
      "cellStyle": {
        "background-color": "#F0F0EE"
      }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.AIA_REVIEW,
      "field": "proceedingNumber",
      "width": 130,
      "minWidth": 130,
      "maxWidth": 130,
      "resizable": true,
      "cellRendererFramework": OpenCaseviewerComponent
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITION_SUBMISSION_DT,
      "field": "submittedDateStr",
      "width": 130,
      "minWidth": 130,
      "maxWidth": 130,
      "resizable": true,
      "comparator": this.gridHelper.dateComparator,
      "headerCheckboxSelection": false,
      "sort": "asc",
      "type": "timestamp"
    },
    {
      "headerName": "NOFDA date",
      "field": "nofdaStr",
      "width": 80,
      "minWidth": 80,
      "maxWidth": 80,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "type": "date"
    },
    {
      "headerName": "Days since the petition was filed",
      "field": "daysSinceSubmissionDate",
      "width": 150,
      "minWidth": 150,
      "maxWidth": 150,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false
    },
    {
      "headerName": "Days since the petition was accorded",
      "field": "daysSinceAccorded",
      "width": 185,
      "minWidth": 185,
      "maxWidth": 185,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITIONER_PATENT_NO,
      // "valueGetter": function (params) {
      //   if (!params.data.petitionerPatentNumber || params.data.petitionerPatentNumber === "") {
      //     return params.data.petitionerapplicationId;
      //   } else {
      //     return params.data.petitionerPatentNumber
      //   }
      // },
      "valueGetter": this.gridHelper.valueGetterForPetitionerPatentNoAia,
      "width": 145,
      "minWidth": 145,
      "maxWidth": 145,
      "resizable": true
    },
    {
      "headerName": "Petitioner",
      "field": "petiRealParty",
      "width": 300,
      "minWidth": 300,
      "maxWidth": 300,
      "resizable": true,
      "tooltipField": 'petiRealParty',
      "tooltipComponentParams": { data: 'petiRealParty' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITIONER_TECH_CENTER,
      "field": "petiTechCenterId",
      "width": 100,
      "minWidth": 100,
      "maxWidth": 100,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_PATENT_NO,
      // "valueGetter": function (params) {
      //   if (!params.data.patentNumber || params.data.patentNumber === "") {
      //     return params.data.applicationId;
      //   } else {
      //     return params.data.patentNumber
      //   }
      // },
      "valueGetter": this.gridHelper.valueGetterForPOPatentNoAia,
      "width": 150,
      "minWidth": 150,
      "maxWidth": 150,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT,
      "field": "patentOwnerName",
      "width": 175,
      "minWidth": 175,
      "maxWidth": 175,
      "resizable": true,
      "tooltipField": 'patentOwnerName',
      "tooltipComponentParams": { data: 'patentOwnerName' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT_TECH_CENTER,
      "field": "poTechCenterId",
      "width": 120,
      "minWidth": 120,
      "maxWidth": 120,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.JUDGE_PANEL,
      "field": "judges",
      "width": 175,
      "minWidth": 175,
      "resizable": true,
      "tooltipField": 'judges',
      "tooltipComponentParams": { data: 'judges' },
      "cellRendererFramework": JudgePanelRendererComponent,
      "cellRendererParams": (params: ICellRendererParams) => this.gridHelper.formatJudgePanelTooltip(params)
    }
  ],
    defective: [{
      "headerName": "",
      "field": "",
      "width": 25,
      "minWidth": 25,
      "maxWidth": 25,
      "resizable": false,
      "floatingFilter": false,
      "headerCheckboxSelection": false,
      "cellStyle": {
        "background-color": "#F0F0EE"
      }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.AIA_REVIEW,
      "field": "proceedingNumber",
      "width": 130,
      "minWidth": 130,
      "maxWidth": 130,
      "resizable": true,
      "cellRendererFramework": OpenCaseviewerComponent
    },
    {
      "headerName": "Status",
      "field": "statusDisplay",
      "width": 200,
      "minWidth": 200,
      "maxWidth": 200,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITION_SUBMISSION_DT,
      "field": "submittedDateStr",
      "width": 130,
      "minWidth": 130,
      "maxWidth": 130,
      "resizable": true,
      "comparator": this.gridHelper.dateComparator,
      "headerCheckboxSelection": false,
      "sort": "asc",
      "type": "date"
    },
    {
      "headerName": "Petitioner",
      "field": "petiRealParty",
      "width": 200,
      "minWidth": 200,
      "resizable": true,
      "tooltipField": 'petiRealParty',
      "tooltipComponentParams": { data: 'petiRealParty' }
    },
    {
      "headerName": "Application #",
      "field": "poApplicationId",
      "width": 175,
      "minWidth": 175,
      "maxWidth": 175,
      "resizable": true
    },
    {
      "headerName": "Patent #",
      "field": "poPatentNumber",
      "width": 175,
      "minWidth": 175,
      "maxWidth": 175,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT,
      "field": "",
      "minWidth": 175,
      "resizable": true,
      "tooltipField": 'patentOwnerName',
      "tooltipComponentParams": { data: 'patentOwnerName' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT_TECH_CENTER,
      "field": "poTechCenterId",
      "width": 120,
      "minWidth": 120,
      "maxWidth": 120,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.JUDGE_PANEL,
      "field": "judges",
      "width": 175,
      "minWidth": 175,
      "maxWidth": 175,
      "resizable": true,
      "tooltipField": 'judges',
      "tooltipComponentParams": { data: 'judges' },
      "cellRendererFramework": JudgePanelRendererComponent,
      "cellRendererParams": (params: ICellRendererParams) => this.gridHelper.formatJudgePanelTooltip(params)
    }
  ],
    readyForTrial: [{
      "headerName": "",
      "field": "",
      "width": 25,
      "minWidth": 25,
      "maxWidth": 25,
      "resizable": false,
      "floatingFilter": false,
      "headerCheckboxSelection": false,
      "cellStyle": {
        "background-color": "#F0F0EE"
      }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.AIA_REVIEW,
      "field": "proceedingNumber",
      "width": 130,
      "minWidth": 130,
      "resizable": true,
      "cellRendererFramework": OpenCaseviewerComponent
    },
    {
      "headerName": "Filing date",
      "field": "submittedDateStr",
      "width": 130,
      "minWidth": 130,
      "maxWidth": 130,
      "resizable": true,
      "type": "date"
    },
    {
      "headerName": "Petitioner",
      "field": "petiRealParty",
      "width": 250,
      "minWidth": 250,
      "resizable": true,
      "tooltipField": 'petiRealParty',
      "tooltipComponentParams": { data: 'petiRealParty' }
    },
    {
      "headerName": "Application #",
      "field": "poApplicationId",
      "width": 150,
      "minWidth": 150,
      "maxWidth": 150,
      "resizable": true
    },
    {
      "headerName": "Patent #",
      "field": "poPatentNumber",
      "width": 150,
      "minWidth": 150,
      "maxWidth": 150,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT,
      "field": "patentOwnerName",
      "width": 250,
      "minWidth": 250,
      "resizable": true,
      "tooltipField": 'patentOwnerName',
      "tooltipComponentParams": { data: 'patentOwnerName' }
    },
    {
      "headerName": "Invention title",
      "field": "poInventionTitleTx",
      "width": 300,
      "minWidth": 300,
      "resizable": true,
      "tooltipField": 'poInventionTitleTx',
      "tooltipComponentParams": { data: 'poInventionTitleTx' }
    },
    {
      "headerName": "Inventor",
      "field": "poInventorFullName",
      "width": 175,
      "minWidth": 175,
      "maxWidth": 175,
      "resizable": true
    }
  ],
    requiringClosure: [{
      "headerName": "",
      "field": "",
      "width": 25,
      "minWidth": 25,
      "maxWidth": 25,
      "resizable": false,
      "floatingFilter": false,
      "headerCheckboxSelection": false,
      "cellStyle": {
        "background-color": "#F0F0EE"
      }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.AIA_REVIEW,
      "field": "proceedingNumber",
      "width": 130,
      "minWidth": 130,
      "resizable": true,
      "cellRendererFramework": OpenCaseviewerComponent
    },
    {
      "headerName": "Status",
      "field": "statusDisplay",
      "width": 200,
      "minWidth": 200,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITION_SUBMISSION_DT,
      "field": "submittedDateStr",
      "width": 130,
      "minWidth": 130,
      "resizable": true,
      "comparator": this.gridHelper.dateComparator,
      "headerCheckboxSelection": false,
      "sort": "asc",
      "type": "date"
    },
    {
      "headerName": "NOFDA date",
      "field": "nofdaStr",
      "width": 80,
      "minWidth": 80,
      "comparator": this.gridHelper.dateComparator,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "type": "date"
    },
    {
      "headerName": "Institution decision date",
      "field": "institutionDecisionDateStr",
      "width": 100,
      "minWidth": 100,
      "comparator": this.gridHelper.dateComparator,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "type": "date"
    },
    {
      "headerName": "Termination date",
      "field": "terminationDateStr",
      "width": 100,
      "minWidth": 100,
      "comparator": this.gridHelper.dateComparator,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "type": "date"
    },
    {
      "headerName": "Decision outcome",
      "field": "terminationType",
      "width": 200,
      "minWidth": 200,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "tooltipField": 'terminationType',
      "tooltipComponentParams": { data: 'terminationType' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITIONER_PATENT_NO,
      // "valueGetter": function (params) {
      //   if (!params.data.petitionerPatentNumber || params.data.petitionerPatentNumber === "") {
      //     return params.data.petitionerapplicationId;
      //   } else {
      //     return params.data.petitionerPatentNumber
      //   }
      // },
      "valueGetter": this.gridHelper.valueGetterForPetitionerPatentNoAia,
      "width": 145,
      "minWidth": 145,
      "resizable": true
    },
    {
      "headerName": "Petitioner",
      "field": "petiRealParty",
      "width": 200,
      "minWidth": 200,
      "resizable": true,
      "tooltipField": 'petiRealParty',
      "tooltipComponentParams": { data: 'petiRealParty' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITIONER_TECH_CENTER,
      "field": "petiTechCenterId",
      "width": 100,
      "minWidth": 100,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_PATENT_NO,
      // "valueGetter": function (params) {
      //   if (!params.data.patentNumber || params.data.patentNumber === "") {
      //     return params.data.applicationId;
      //   } else {
      //     return params.data.patentNumber
      //   }
      // },
      "valueGetter": this.gridHelper.valueGetterForPOPatentNoAia,
      "width": 150,
      "minWidth": 150,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT,
      "field": "patentOwnerName",
      "width": 175,
      "minWidth": 175,
      "resizable": true,
      "tooltipField": 'patentOwnerName',
      "tooltipComponentParams": { data: 'patentOwnerName' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT_TECH_CENTER,
      "field": "poTechCenterId",
      "width": 120,
      "minWidth": 120,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.JUDGE_PANEL,
      "field": "judges",
      "width": 175,
      "minWidth": 175,
      "resizable": true,
      "tooltipField": 'judges',
      "tooltipComponentParams": { data: 'judges' },
      "cellRendererFramework": JudgePanelRendererComponent,
      "cellRendererParams": (params: ICellRendererParams) => this.gridHelper.formatJudgePanelTooltip(params)
    }
  ]
  };

  rowData = {
    submittedCasesWithMilestoneDt:[],
    pendingWithl3judges:[],
    aiaReviews: [],
    withoutMandatoryNotices: [],
    defective: [],
    readyForTrial: [],
    requiringClosure: []
  }

  allAIAColumnDefs: Array<any> = [];
  allAIARowData: Array<any> = [];
  withoutMandatoryNoticeColumnDefs: Array<any> = [];
  withoutMandatoryNoticeRowData: Array<any> = [];

  numberOfFilters = 0;

  total = {
    submittedCasesWithMilestoneDt:null,
    pendingWithl3judges:null,
    aiaReviews: null,
    withoutMandatoryNotices: null,
    defective: null,
    readyForTrial: null,
    requiringClosure: null
  }

  fileName: string = null;
  aiaResponse: any;
  colState: any;
  quickLinks: any;

  constructor(
    private gridHelper: GridHelperService,
    private trialsService: TrialsService,
    private commonUtils: CommonUtilitiesService,
    private activatedRoute: ActivatedRoute,
  private store: Store<CaseViewerState>,

  ) { }

  ngOnInit(): void {
    this.trialsService.codeReference("QUICK_LINKS").subscribe((response) => {
      if(response){
        response.forEach(element => {
          if(element.valueText =="TRIALS"){
           this.quickLinks=JSON.parse(element.descriptionText);
          }
        });
      }
    })
    this.frameworkComponents = { customTooltip: ToolTipComponent };
    this.gridRefreshValues.showLoading = true;
   // this.getAllAIAReviews(this.selectedType, true);
    // setInterval(()=>{
    //   this.colState = this.gridApi.getFilterModel();
    //   this.gridRefreshValues.showLoading = false;
    //   this.getAllAIAReviews(this.selectedType, true);
    // },300000)
  }
  ngAfterViewInit(){
//     this.activatedRoute.queryParams.subscribe(params => {
       
//       let type = document.getElementById(params['report-type']);
// if(type){
//   type.click()
// }
       // Print the parameter to the console. 
  //});
  }
  

  refresh(reviewType, forceRefresh){
    this.colState = this.gridApi.getFilterModel();
    this.gridRefreshValues.showLoading = true;
    this.getAllAIAReviews(this.selectedType, forceRefresh)
  }

  getAllAIAReviews(reviewType, forceRefresh) {
    
    console.log("Getting");
    this.loadingMessage = "Loading ...";
    this.noRowsTemplate = this.reviewTypes[reviewType].noRowsTemplate;
    this.fileName = this.reviewTypes[reviewType].fileName;
    if (this.rowData[reviewType].length <= 0 || forceRefresh) {
      let count =0;
     
      
      let obj ={
        "proceedingState":reviewType,
        "trailTypes": [
            "IPR",
            "PGR",
            "CBM",
            "DER"
        ]

    }
      this.trialsService.getInitiatedCasesNew(obj).subscribe((aiaReviewsResponse) => {
        this.numberOfFilters = 0;
        console.log(aiaReviewsResponse);
        count =count+1;
        let readyForTrial=[];
        this.aiaResponse = aiaReviewsResponse;
        aiaReviewsResponse.forEach(aiaresp => {
          // aiaresp.mileStoneDt? aiaresp.terminationType=this.commonUtils.findDecisionOutcome(aiaresp.mileStoneDt):''
          // aiaresp.nofda = this.commonUtils.parseKeyDates(aiaresp.mileStoneDt,"Notice of Accorded Filing Date");
          // aiaresp.accordedDate = this.commonUtils.parseKeyDates(aiaresp.mileStoneDt,"Accorded Filing Date");
          // aiaresp.terminationDate = this.commonUtils.parseKeyDates(aiaresp.mileStoneDt,"Termination Decision");
          // aiaresp.institutionDecisionDate = this.commonUtils.parseKeyDates(aiaresp.mileStoneDt,"Decision to Institute");
          // aiaresp.submittedDate = this.commonUtils.parseKeyDates(aiaresp.mileStoneDt,"Filing Date");
         
          if(aiaresp.submittedDate){ 
          aiaresp.daysSinceSubmissionDate=((new Date().getTime()-aiaresp.submittedDate)/(24*60*60*1000));
          aiaresp.daysSinceSubmissionDate=parseInt(aiaresp.daysSinceSubmissionDate);
           }
           if(aiaresp.accordedDate){
            aiaresp.daysSinceAccorded=(new Date().getTime()-aiaresp.accordedDate)/(24*60*60*1000);
            aiaresp.daysSinceAccorded=parseInt(aiaresp.daysSinceAccorded);
             }  
             if(reviewType=="pendingWithl3judges" && aiaresp.judges && aiaresp.judges.length<3  ){
              
         
            readyForTrial.push(aiaresp);
          
         }
        });
        this.rowData[reviewType] = reviewType=="pendingWithl3judges"?readyForTrial:aiaReviewsResponse;
        this.total[reviewType] = reviewType=="pendingWithl3judges"?this.commonUtils.formatNumber(readyForTrial.length):this.commonUtils.formatNumber(aiaReviewsResponse.length);
        if(this.colState){
        setTimeout(() => {
          this.gridApi.setFilterModel(this.colState);
        }, 100);
      }
          this.reviewTypes[reviewType].total=this.commonUtils.formatNumber(aiaReviewsResponse.length);
       console.log(Object.keys(this.reviewTypes).length-1,count,"test")
      
        console.log(this.rowData);
        for (const [key] of Object.entries(this.rowData)) {
          this.convertDatesToString(this.rowData[key]);
        }
        this.gridRefreshValues.showLoading = false;
        this.gridRefreshValues.lastRefresh = Date.now();
      
          
      }, (allAIAFailure) => {
        count =count+1;
          console.log(allAIAFailure);
          this.gridRefreshValues.showLoading =  false ;
        this.gridRefreshValues.lastRefresh = Date.now();
      }
      );
    }
  }
     
    
  
  


  convertDatesToString(el) {
    el.forEach(element => {
      element.submittedDateStr = element.submittedDate ? this.gridHelper.convertDateToString(element.submittedDate) : null;
      element.nofdaStr = element.nofda ? this.gridHelper.convertDateToString(element.nofda) : null;
      element.institutionDecisionDateStr = element.institutionDecisionDate ? this.gridHelper.convertDateToString(element.institutionDecisionDate) : null;
      element.terminationDateStr = element.terminationDate ? this.gridHelper.convertDateToString(element.terminationDate) : null;
    });
  }

  changeType(reviewType) {
    this.selectedType = reviewType;
    this.numberOfFilters = 0;
    this.noRowsTemplate = this.reviewTypes[reviewType].noRowsTemplate;
    this.total[reviewType]=this.reviewTypes[reviewType].total;
    
      this.clearGridFilters();
 
    
    this.getAllAIAReviews(reviewType, true)
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }


  onFilterChanged() {
    // console.log("On filter changed: ", this.gridApi.getDisplayedRowCount());
    // const filterModel = this.gridApi.getFilterModel();
    // this.numberOfFilters = Object.keys(filterModel).length;
    // this.total[this.selectedType] = this.commonUtils.formatNumber(this.gridApi.getDisplayedRowCount());
    const resp = this.gridHelper.onFilterChanged(this.gridApi);
    this.numberOfFilters = resp.numberOfFilters;
    this.total[this.selectedType] = resp.totalCount;
  }


  getTotalCount() {
    if (this.gridApi) {
      const totalCount = this.commonUtils.formatNumber(this.gridApi.getDisplayedRowCount());
      return totalCount ? totalCount : 0
    } else {
      return 0
    }
  }



  isFirstColumn(params) {
    const displayedColumns = params.columnApi.getAllDisplayedColumns();
    const thisIsFirstColumn = displayedColumns[0] === params.column;
    return thisIsFirstColumn;
  }



  clearGridFilters() {

    try {
      this.gridApi.setFilterModel(null);
  } catch (e) {
     console.log(e);
  }
    
  }


  exportDataAsCsv() {
    this.commonUtils.setToastr('success', 'Processing export...');
    this.gridHelper.exportDataAsCsv(this.gridApi, this.reviewTypes[this.selectedType].fileName);
  }

  openReport(type){
    let currentUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
    let up = window.sessionStorage.getItem("up");

    let prefix = "fromJudgePortal"
      window.open(this.quickLinks[type], prefix + JSON.stringify({
              "currentUser": currentUser,
              "up": up
      }));

  }

}

