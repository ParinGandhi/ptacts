import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { TrialsService } from 'src/app/services/trials.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AgGridModule } from 'ag-grid-angular';
import { DatePipe } from '@angular/common';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { ToastrService } from 'ngx-toastr';
import { of, throwError } from 'rxjs';
import { GridOptions } from "ag-grid-community";

import { AiaReviewsComponent } from './aia-reviews.component';


/**
 * 56.84%
 */
//! Need updated response
// FIXME - need updated response
describe('AiaReviewsComponent', () => {
  let component: AiaReviewsComponent;
  let gridHelper: GridHelperService;
  let trialsService: TrialsService;
  let commonUtils: CommonUtilitiesService;
  let gridOptions: GridOptions = <GridOptions>{};
  let fixture: ComponentFixture<AiaReviewsComponent>;


  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => {},
    error: (
      message?: string,
      title?: string
    ) => {},
  };

  const allAIAResponseMock = {
    "aiaProceedings": [
      {
        "proceedingsAIA": [
          {
            "patentOwner": "Varia Holdings LLC",
            "petitionerPatentNumber": null,
            "nofda": 1363702380000,
            "petitionerRealParty": null,
            "patentNumber": "7167731",
            "poRealParty": null,
            "submittedDate": 1363320000000,
            "petitionerTechCenterId": null,
            "inventionTitle": "EMOTICON INPUT METHOD AND APPARATUS",
            "petitioner": "Samsung Electronics Co., Ltd.",
            "accordedDate": 1363320000000,
            "terminationDate": 1371044700000,
            "petitionerapplicationId": null,
            "daysSinceSubmissionDate": 2922,
            "proceedingNumber": "IPR2013-00190",
            "daysSinceAccorded": 2922,
            "institutionDecisionDate": 1371044700000,
            "terminationType": "SETTLED BEFORE INSTITUTION",
            "poTechCenterId": "2600",
            "inventor": "Jonathan Nelson",
            "applicationId": "11224679",
            "judges": [
              "Tierney, Michael",
              "Bisk, Jennifer",
              "Ward, Trenton",
              null,
              null,
              null,
              null
            ],
            "status": "Terminated-Denied"
          },
          {
            "patentOwner": "Volcano Corporation",
            "petitionerPatentNumber": null,
            "nofda": 1367612820000,
            "petitionerRealParty": null,
            "patentNumber": "7134994",
            "poRealParty": null,
            "submittedDate": 1367294400000,
            "petitionerTechCenterId": null,
            "inventionTitle": "MULTIPURPOSE HOST SYSTEM FOR INVASIVE CARDIOVASCULAR DIAGNOSTIC MEASUREMENT ACQUISITION AND DISPLAY",
            "petitioner": "St. Jude Medical, Cardiology Division, Inc.",
            "accordedDate": 1367294400000,
            "terminationDate": 1381951740000,
            "petitionerapplicationId": null,
            "daysSinceSubmissionDate": 2876,
            "proceedingNumber": "IPR2013-00258",
            "daysSinceAccorded": 2876,
            "institutionDecisionDate": 1381951740000,
            "terminationType": "DENIED",
            "poTechCenterId": "3700",
            "inventor": "Howard Alpert",
            "applicationId": "10151423",
            "judges": [
              "Lee, Jameson",
              "Kamholz, Scott",
              "Cocks, Josiah",
              null,
              null,
              null,
              null
            ],
            "status": "Terminated-Denied"
          }
        ],
        "total": 2,
        "reviewType": "aiaReviews",
        "proceedings": null
      },
      {
        "proceedingsAIA": [
          {
            "patentOwner": null,
            "petitionerPatentNumber": null,
            "nofda": null,
            "petitionerRealParty": null,
            "patentNumber": "7631191",
            "poRealParty": null,
            "submittedDate": null,
            "petitionerTechCenterId": null,
            "inventionTitle": "SYSTEM AND METHOD FOR AUTHENTICATING A WEB PAGE",
            "petitioner": "Bank of the West",
            "accordedDate": null,
            "terminationDate": null,
            "petitionerapplicationId": null,
            "daysSinceSubmissionDate": 0,
            "proceedingNumber": "CBM2015-00007",
            "daysSinceAccorded": 0,
            "institutionDecisionDate": null,
            "terminationType": "",
            "poTechCenterId": "2400",
            "inventor": "Elliott Glazer",
            "applicationId": "11423340",
            "judges": [
              null,
              null,
              null,
              null,
              null,
              null,
              null
            ],
            "status": "Withdrawn"
          },
          {
            "patentOwner": null,
            "petitionerPatentNumber": null,
            "nofda": null,
            "petitionerRealParty": null,
            "patentNumber": "6081792",
            "poRealParty": null,
            "submittedDate": null,
            "petitionerTechCenterId": null,
            "inventionTitle": "ATM AND POS TERMINAL AND METHOD OF USE THEREOF",
            "petitioner": "NRT TECHNOLOGY CORP.",
            "accordedDate": null,
            "terminationDate": null,
            "petitionerapplicationId": null,
            "daysSinceSubmissionDate": 0,
            "proceedingNumber": "CBM2015-00163",
            "daysSinceAccorded": 0,
            "institutionDecisionDate": null,
            "terminationType": "",
            "poTechCenterId": "2700",
            "inventor": "ROBERT CUCINOTTA",
            "applicationId": "09007740",
            "judges": [
              null,
              null,
              null,
              null,
              null,
              null,
              null
            ],
            "status": "Withdrawn"
          }
        ],
        "total": 2,
        "reviewType": "withoutMandatoryNotices",
        "proceedings": null
      },
      {
        "proceedingsAIA": [
          {
            "patentOwner": "Arunachalam, Lakshmi",
            "petitionerPatentNumber": null,
            "nofda": 1396623525000,
            "petitionerRealParty": null,
            "patentNumber": "8346894",
            "poRealParty": null,
            "submittedDate": 1395806400000,
            "petitionerTechCenterId": null,
            "inventionTitle": "REAL-TIME WEB TRANSACTIONS FROM WEB APPLICATIONS",
            "petitioner": "Home Depot U.S.A., Inc.",
            "accordedDate": 1395806400000,
            "terminationDate": 1410450720000,
            "petitionerapplicationId": null,
            "daysSinceSubmissionDate": 2546,
            "proceedingNumber": "CBM2014-00097",
            "daysSinceAccorded": 2546,
            "institutionDecisionDate": 1410450720000,
            "terminationType": "SETTLED BEFORE INSTITUTION",
            "poTechCenterId": "2400",
            "inventor": "Lakshmi Arunachalam",
            "applicationId": "12628066",
            "judges": [
              "McNamara, Brian",
              "Saindon, William",
              "Easthom, Karl",
              null,
              null,
              null,
              null
            ],
            "status": "Terminated-Denied"
          },
          {
            "patentOwner": "S.J. Bashen Corporation",
            "petitionerPatentNumber": null,
            "nofda": 1415638269000,
            "petitionerRealParty": null,
            "patentNumber": "6985922",
            "poRealParty": null,
            "submittedDate": 1413432000000,
            "petitionerTechCenterId": null,
            "inventionTitle": "METHOD, APPARATUS AND SYSTEM FOR PROCESSING COMPLIANCE ACTIONS OVER A WIDE AREA NETWORK",
            "petitioner": "Littler Mendelson, P.C.",
            "accordedDate": 1413432000000,
            "terminationDate": 1418747460000,
            "petitionerapplicationId": null,
            "daysSinceSubmissionDate": 2342,
            "proceedingNumber": "CBM2015-00011",
            "daysSinceAccorded": 2342,
            "institutionDecisionDate": 1418747460000,
            "terminationType": "SETTLED BEFORE INSTITUTION",
            "poTechCenterId": "2100",
            "inventor": "Janet Bashen",
            "applicationId": "10028235",
            "judges": [
              "Wood, Benjamin",
              "Powell, Neil",
              "Saindon, William",
              null,
              null,
              null,
              null
            ],
            "status": "Terminated-Denied"
          }
        ],
        "total": 7492,
        "reviewType": "requiringClosure",
        "proceedings": null
      },
      {
        "proceedingsAIA": [
          {
            "patentOwner": null,
            "petitionerPatentNumber": null,
            "nofda": 1615266000000,
            "petitionerRealParty": null,
            "patentNumber": "9884423",
            "poRealParty": null,
            "submittedDate": 1614203932000,
            "petitionerTechCenterId": null,
            "inventionTitle": "AUTONOMOUS ROBOT AUTO-DOCKING AND ENERGY MANAGEMENT SYSTEMS AND METHODS",
            "petitioner": "SharkNinja Operating LLC",
            "accordedDate": 1615266000000,
            "terminationDate": null,
            "petitionerapplicationId": null,
            "daysSinceSubmissionDate": 18,
            "proceedingNumber": "IPR2021-00544",
            "daysSinceAccorded": 6,
            "institutionDecisionDate": null,
            "terminationType": "",
            "poTechCenterId": "2800",
            "inventor": null,
            "applicationId": "15491599",
            "judges": [
              null,
              null,
              null,
              null,
              null,
              null,
              null
            ],
            "status": "Submitted"
          }
        ],
        "total": 1,
        "reviewType": "defective",
        "proceedings": null
      },
      {
        "proceedingsAIA": [
          {
            "patentOwner": "Blue Calypso, LLC.",
            "petitionerPatentNumber": null,
            "nofda": 1377522240000,
            "petitionerRealParty": null,
            "patentNumber": "8452646",
            "poRealParty": null,
            "submittedDate": 1376625600000,
            "petitionerTechCenterId": null,
            "inventionTitle": "SYSTEM AND METHOD FOR PROVIDING ENDORSED ELECTRONIC OFFERS BETWEEN COMMUNICATION DEVICES",
            "petitioner": "Groupon, Inc.",
            "accordedDate": 1376625600000,
            "terminationDate": 1418846400000,
            "petitionerapplicationId": null,
            "daysSinceSubmissionDate": 2768,
            "proceedingNumber": "CBM2013-00044",
            "daysSinceAccorded": 2768,
            "institutionDecisionDate": 1389968400000,
            "terminationType": "FINAL WRITTEN DECISION",
            "poTechCenterId": "3600",
            "inventor": "Andrew Levi",
            "applicationId": "12925218",
            "judges": [
              "Chang, Joni",
              "Kim, Michael",
              "Benoit, Barbara",
              null,
              null,
              null,
              null
            ],
            "status": "FWD Entered"
          },
          {
            "patentOwner": "Progressive Casualty Insurance Company",
            "petitionerPatentNumber": null,
            "nofda": 1348260060000,
            "petitionerRealParty": null,
            "patentNumber": "8140358",
            "poRealParty": null,
            "submittedDate": 1347768000000,
            "petitionerTechCenterId": null,
            "inventionTitle": "VEHICLE MONITORING SYSTEM",
            "petitioner": "Liberty Mutual Insurance Company",
            "accordedDate": 1347768000000,
            "terminationDate": 1392133500000,
            "petitionerapplicationId": null,
            "daysSinceSubmissionDate": 3102,
            "proceedingNumber": "CBM2012-00003",
            "daysSinceAccorded": 3102,
            "institutionDecisionDate": 1360674600000,
            "terminationType": "FINAL WRITTEN DECISION",
            "poTechCenterId": "3600",
            "inventor": "William Everett",
            "applicationId": "12132487",
            "judges": [
              "Lee, Jameson",
              "Zecher, Michael",
              "Chang, Joni",
              null,
              null,
              null,
              null
            ],
            "status": "FWD Entered"
          }
        ],
        "total": 4100,
        "reviewType": "readyForTrial",
        "proceedings": null
      }
    ],
    "ptabReadOnlyUser": true
  };


  const allAiaFailureMock = {
    error: {
      message: "Error"
    }
  }


  const gridApiMock = {
    setFilterModel: () => { },
    getDisplayedRowCount: () => {
      return 5;
    },
    getFilterModel: () => {
      const filterModelMock = {
        status: {
          filter: "n",
          filterType: "text",
          type: "contains"
        }
      }
      return filterModelMock;
    },
    exportDataAsCsv: () => {}
  }



  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, AgGridModule.withComponents([])],
      declarations: [AiaReviewsComponent],
      providers: [GridHelperService, TrialsService, DatePipe,
        BsModalService,
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useValue: {}
        },
        {
          provide: ToastrService,
          useValue: toastrService
        }]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AiaReviewsComponent);
    gridHelper = TestBed.inject(GridHelperService);
    trialsService = TestBed.inject(TrialsService);
    commonUtils = TestBed.inject(CommonUtilitiesService);
    component = fixture.componentInstance;
    let store = {};
  const mockSessionStorage = {
    getItem: (key: string): string => {
      return key in store ? store[key] : null;
    },
    setItem: (key: string, value: string) => {
      store[key] = `${value}`;
    },
    removeItem: (key: string) => {
      delete store[key];
    },
    clear: () => {
      store = {};
    }
  };
  spyOn(sessionStorage, 'getItem')
    .and.callFake(mockSessionStorage.getItem);
  spyOn(sessionStorage, 'setItem')
    .and.callFake(mockSessionStorage.setItem);
  spyOn(sessionStorage, 'removeItem')
    .and.callFake(mockSessionStorage.removeItem);
  spyOn(sessionStorage, 'clear')
      .and.callFake(mockSessionStorage.clear);

    let userName = {
      loginId: "sbartlett"
    };
    mockSessionStorage.setItem('userInfo', JSON.stringify(userName));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  //!Need updated payload
  xit('should get all aia reviews cases', () => {
    spyOn(trialsService, 'getInitiatedCasesNew').and.returnValue(of(allAIAResponseMock));
    component.getAllAIAReviews('aiaReviews', false);
    expect(component.gridRefreshValues.showLoading).toBeFalse;
    // expect(component.gridRefreshValues.lastRefresh).toBeTruthy();
  });


  it('should call getAllAIAReviews and throw error', () => {
    spyOn(trialsService, 'getInitiatedCasesNew').and.returnValue(throwError(allAiaFailureMock));
    component.getAllAIAReviews('aiaReviews', false);
    expect(component.gridRefreshValues.showLoading).toBeFalse;
    // expect(component.gridRefreshValues.lastRefresh).toBeTruthy();
  })


  it('should change type to aiaReviews', () => {
    const data = {
      api: component.gridApi,
      columnApi: component.gridColumnApi
    }
    let reviewType = 'aiaReviews';
    component.gridApi = gridApiMock;
    component.changeType(reviewType);
    fixture.detectChanges();
    expect(component.selectedType).toBe(reviewType);
    expect(component.numberOfFilters).toBe(0);
    expect(component.noRowsTemplate).toBe("No AIA reviews cases found.");
  });


  it('should invoke onFilterChanged', () => {
    const data = {
      api: component.gridApi,
      columnApi: component.gridColumnApi
    }
    component.gridApi = gridApiMock;
    component.onFilterChanged();
    fixture.detectChanges();
  });


  it('should export data as csv', () => {
    const data = {
      api: component.gridApi,
      columnApi: component.gridColumnApi
    }
    component.gridApi = gridApiMock;
    component.exportDataAsCsv();
    fixture.detectChanges();
  });


});
