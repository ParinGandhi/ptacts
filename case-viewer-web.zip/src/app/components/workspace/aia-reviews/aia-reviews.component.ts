import { Component, OnInit } from '@angular/core';
import { GridHelperService } from '../../../services/grid-helper.service';
import GridRefreshModel from '../../../models/common/GridRefresh.model';
import { OpenCaseviewerComponent } from '../../common/open-caseviewer/open-caseviewer.component';
import { TrialsService } from '../../../services/trials.service';
import { ToolTipComponent } from '../tool-tip/tool-tip.component';
import { ICellRendererParams } from 'ag-grid-community';
import { PtabTrialConstants } from '../../../constants/ptab-trials.constants';
import { CommonUtilitiesService } from '../../../services/common-utilities.service';
import { JudgePanelRendererComponent } from '../../common/judge-panel-renderer/judge-panel-renderer.component';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-aia-reviews',
  templateUrl: './aia-reviews.component.html',
  styleUrls: ['./aia-reviews.component.less']
})
export class AiaReviewsComponent implements OnInit {

  selectedType = 'aiaReviews';

  /**
   *  Grid
   */
  gridApi;
  gridColumnApi;
  noRowsTemplate = "No cases found";
  frameworkComponents;


  defaultColDef = {
    filter: true,
    sortable: true,
    floatingFilter: true,
    suppressMenu: true,
    tooltipComponent: 'customTooltip',
    headerCheckboxSelection: this.isFirstColumn,
      checkboxSelection: this.isFirstColumn,
  };

  reviewTypes = {
    aiaReviews: {
      loadingMessage: "Loading all AIA reviews cases...",
      noRowsTemplate: "No AIA reviews cases found.",
      fileName: "All AIA Reviews",
      total:null
      // url: `${PtabTrialConstants.AIA_REVIEWS.BASE}${PtabTrialConstants.AIA_REVIEWS.ALL}`
    },
    withoutMandatoryNotices: {
      loadingMessage: "Loading all cases without mandatory notices...",
      noRowsTemplate: "No cases without mandatory notices found.",
      fileName: "Without mandatory notice",
      total:null
      // url: `${PtabTrialConstants.AIA_REVIEWS.BASE}${PtabTrialConstants.AIA_REVIEWS.WITHOUT_MN}`
    },
    defective: {
      loadingMessage: "Loading all defective cases...",
      noRowsTemplate: "No defective cases found.",
      fileName: "Defective",
      total:null
      // url: `${PtabTrialConstants.AIA_REVIEWS.BASE}${PtabTrialConstants.AIA_REVIEWS.DEFECTIVE}`
    },
    readyForTrial: {
      loadingMessage: "Loading all ready for trials certificate cases...",
      noRowsTemplate: "No ready for trials cases found.",
      fileName: "Ready for Trials",
      total:null
      // url: `${PtabTrialConstants.AIA_REVIEWS.BASE}${PtabTrialConstants.AIA_REVIEWS.TRIALS_CERTIFICATE}`
    },
    requiringClosure: {
      loadingMessage: "Loading all cases requiring closure...",
      noRowsTemplate: "No cases requiring closure found.",
      fileName: "Requiring closure",
      total:null
      // url: `${PtabTrialConstants.AIA_REVIEWS.BASE}${PtabTrialConstants.AIA_REVIEWS.REQUIRE_CLOSURE}`
    }
  };


  rowSelection = 'single';
  showLoading = false;
  loadingMessage: string = null;

  gridRefreshValues: GridRefreshModel = {
    refreshFailed: false,
    showLoading: false,
    lastRefresh: null
  }

  columnDefs = {
    aiaReviews: [{
      "headerName": "",
      "field": "",
      "width": 25,
      "minWidth": 25,
      "maxWidth": 25,
      "resizable": false,
      "floatingFilter": false,
      "headerCheckboxSelection": false,
      "cellStyle": {
        "background-color": "#F0F0EE"
      }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.AIA_REVIEW,
      "field": "proceedingNumber",
      "width": 130,
      "minWidth": 130,
      "resizable": true,
      "cellRendererFramework": OpenCaseviewerComponent
    },
    {
      "headerName": "Status",
      "field": "statusDisplay",
      "width": 200,
      "minWidth": 200,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITION_SUBMISSION_DT,
      "field": "submittedDateStr",
      "width": 130,
      "minWidth": 130,
      "resizable": true,
      "comparator": this.gridHelper.dateComparator,
      "headerCheckboxSelection": false,
      "sort": "asc",
      "type": "date"
    },
    {
      "headerName": "NOFDA date",
      "field": "nofdaStr",
      "width": 80,
      "minWidth": 80,
      "comparator": this.gridHelper.dateComparator,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "type": "date"
    },
    {
      "headerName": "Institution decision date",
      "field": "institutionDecisionDateStr",
      "width": 100,
      "minWidth": 100,
      "comparator": this.gridHelper.dateComparator,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "type": "date"
    },
    {
      "headerName": "Termination date",
      "field": "terminationDateStr",
      "width": 100,
      "minWidth": 100,
      "comparator": this.gridHelper.dateComparator,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "type": "date"
    },
    {
      "headerName": "Decision outcome",
      "field": "terminationType",
      "width": 300,
      "minWidth": 200,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "tooltipField": 'terminationType',
      "tooltipComponentParams": { data: 'terminationType' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITIONER_PATENT_NO,
      // "valueGetter": function (params) {
      //   if (!params.data.petitionerPatentNumber || params.data.petitionerPatentNumber === "") {
      //     return params.data.petitionerapplicationId;
      //   } else {
      //     return params.data.petitionerPatentNumber
      //   }
      // },
      "valueGetter": this.gridHelper.valueGetterForPetitionerPatentNoAia,
      "width": 145,
      "minWidth": 145,
      "resizable": true
    },
    {
      "headerName": "Petitioner",
      "field": "petiRealParty",
      "width": 200,
      "minWidth": 200,
      "resizable": true,
      "tooltipField": 'petiRealParty',
      "tooltipComponentParams": { data: 'petiRealParty' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITIONER_TECH_CENTER,
      "field": "petiTechCenterId",
      "width": 100,
      "minWidth": 100,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_PATENT_NO,
      // "valueGetter": function (params) {
      //   if (!params.data.patentNumber || params.data.patentNumber === "") {
      //     return params.data.applicationId;
      //   } else {
      //     return params.data.patentNumber
      //   }
      // },
      "valueGetter": this.gridHelper.valueGetterForPOPatentNoAia,
      "width": 150,
      "minWidth": 150,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT,
      "field": "poRealParty",
      "width": 175,
      "minWidth": 175,
      "resizable": true,
      "tooltipField": 'poRealParty',
      "tooltipComponentParams": { data: 'poRealParty' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT_TECH_CENTER,
      "field": "poTechCenterId",
      "width": 120,
      "minWidth": 120,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.JUDGE_PANEL,
      "field": "judges",
      "width": 175,
      "minWidth": 175,
      "resizable": true,
      "tooltipField": 'judges',
      "tooltipComponentParams": { data: 'judges' },
      "cellRendererFramework": JudgePanelRendererComponent,
      "cellRendererParams": (params: ICellRendererParams) => this.gridHelper.formatJudgePanelTooltip(params)
    }
  ],
    withoutMandatoryNotices: [{
      "headerName": "",
      "field": "",
      "width": 25,
      "minWidth": 25,
      "maxWidth": 25,
      "resizable": false,
      "floatingFilter": false,
      "headerCheckboxSelection": false,
      "cellStyle": {
        "background-color": "#F0F0EE"
      }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.AIA_REVIEW,
      "field": "proceedingNumber",
      "width": 130,
      "minWidth": 130,
      "maxWidth": 130,
      "resizable": true,
      "cellRendererFramework": OpenCaseviewerComponent
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITION_SUBMISSION_DT,
      "field": "submittedDateStr",
      "width": 130,
      "minWidth": 130,
      "maxWidth": 130,
      "resizable": true,
      "comparator": this.gridHelper.dateComparator,
      "headerCheckboxSelection": false,
      "sort": "asc",
      "type": "timestamp"
    },
    {
      "headerName": "NOFDA date",
      "field": "nofdaStr",
      "width": 80,
      "minWidth": 80,
      "maxWidth": 80,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "type": "date"
    },
    {
      "headerName": "Days since the petition was filed",
      "field": "daysSinceSubmissionDate",
      "width": 150,
      "minWidth": 150,
      "maxWidth": 150,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false
    },
    {
      "headerName": "Days since the petition was accorded",
      "field": "daysSinceAccorded",
      "width": 185,
      "minWidth": 185,
      "maxWidth": 185,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITIONER_PATENT_NO,
      // "valueGetter": function (params) {
      //   if (!params.data.petitionerPatentNumber || params.data.petitionerPatentNumber === "") {
      //     return params.data.petitionerapplicationId;
      //   } else {
      //     return params.data.petitionerPatentNumber
      //   }
      // },
      "valueGetter": this.gridHelper.valueGetterForPetitionerPatentNoAia,
      "width": 145,
      "minWidth": 145,
      "maxWidth": 145,
      "resizable": true
    },
    {
      "headerName": "Petitioner",
      "field": "petiRealParty",
      "width": 300,
      "minWidth": 300,
      "maxWidth": 300,
      "resizable": true,
      "tooltipField": 'petiRealParty',
      "tooltipComponentParams": { data: 'petiRealParty' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITIONER_TECH_CENTER,
      "field": "petiTechCenterId",
      "width": 100,
      "minWidth": 100,
      "maxWidth": 100,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_PATENT_NO,
      // "valueGetter": function (params) {
      //   if (!params.data.patentNumber || params.data.patentNumber === "") {
      //     return params.data.applicationId;
      //   } else {
      //     return params.data.patentNumber
      //   }
      // },
      "valueGetter": this.gridHelper.valueGetterForPOPatentNoAia,
      "width": 150,
      "minWidth": 150,
      "maxWidth": 150,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT,
      "field": "poRealParty",
      "width": 175,
      "minWidth": 175,
      "maxWidth": 175,
      "resizable": true,
      "tooltipField": 'poRealParty',
      "tooltipComponentParams": { data: 'poRealParty' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT_TECH_CENTER,
      "field": "poTechCenterId",
      "width": 120,
      "minWidth": 120,
      "maxWidth": 120,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.JUDGE_PANEL,
      "field": "judges",
      "width": 175,
      "minWidth": 175,
      "resizable": true,
      "tooltipField": 'judges',
      "tooltipComponentParams": { data: 'judges' },
      "cellRendererFramework": JudgePanelRendererComponent,
      "cellRendererParams": (params: ICellRendererParams) => this.gridHelper.formatJudgePanelTooltip(params)
    }
  ],
    defective: [{
      "headerName": "",
      "field": "",
      "width": 25,
      "minWidth": 25,
      "maxWidth": 25,
      "resizable": false,
      "floatingFilter": false,
      "headerCheckboxSelection": false,
      "cellStyle": {
        "background-color": "#F0F0EE"
      }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.AIA_REVIEW,
      "field": "proceedingNumber",
      "width": 130,
      "minWidth": 130,
      "maxWidth": 130,
      "resizable": true,
      "cellRendererFramework": OpenCaseviewerComponent
    },
    {
      "headerName": "Status",
      "field": "statusDisplay",
      "width": 200,
      "minWidth": 200,
      "maxWidth": 200,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITION_SUBMISSION_DT,
      "field": "submittedDateStr",
      "width": 130,
      "minWidth": 130,
      "maxWidth": 130,
      "resizable": true,
      "comparator": this.gridHelper.dateComparator,
      "headerCheckboxSelection": false,
      "sort": "asc",
      "type": "date"
    },
    {
      "headerName": "Petitioner",
      "field": "petiRealParty",
      "width": 200,
      "minWidth": 200,
      "resizable": true,
      "tooltipField": 'petiRealParty',
      "tooltipComponentParams": { data: 'petiRealParty' }
    },
    {
      "headerName": "Application #",
      "field": "poApplicationId",
      "width": 175,
      "minWidth": 175,
      "maxWidth": 175,
      "resizable": true
    },
    {
      "headerName": "Patent #",
      "field": "poPatentNumber",
      "width": 175,
      "minWidth": 175,
      "maxWidth": 175,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT,
      "field": "",
      "minWidth": 175,
      "resizable": true,
      "tooltipField": 'poRealParty',
      "tooltipComponentParams": { data: 'poRealParty' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT_TECH_CENTER,
      "field": "poTechCenterId",
      "width": 120,
      "minWidth": 120,
      "maxWidth": 120,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.JUDGE_PANEL,
      "field": "judges",
      "width": 175,
      "minWidth": 175,
      "maxWidth": 175,
      "resizable": true,
      "tooltipField": 'judges',
      "tooltipComponentParams": { data: 'judges' },
      "cellRendererFramework": JudgePanelRendererComponent,
      "cellRendererParams": (params: ICellRendererParams) => this.gridHelper.formatJudgePanelTooltip(params)
    }
  ],
    readyForTrial: [{
      "headerName": "",
      "field": "",
      "width": 25,
      "minWidth": 25,
      "maxWidth": 25,
      "resizable": false,
      "floatingFilter": false,
      "headerCheckboxSelection": false,
      "cellStyle": {
        "background-color": "#F0F0EE"
      }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.AIA_REVIEW,
      "field": "proceedingNumber",
      "width": 130,
      "minWidth": 130,
      "resizable": true,
      "cellRendererFramework": OpenCaseviewerComponent
      },
    {
      "headerName": "Filing date",
      "field": "submittedDateStr",
      "width": 100,
      "minWidth": 100,
      "maxWidth": 100,
      "comparator": this.gridHelper.dateComparator,
      "resizable": true,
      "type": "date"
      },
      {
        "headerName": "Status",
        "field": "statusDisplay",
        "width": 130,
        "minWidth": 130,
        "resizable": true
        // "cellRendererFramework": OpenCaseviewerComponent
      },
     {
      "headerName": "Termination date",
      "field": "terminationDateStr",
      "width": 100,
      "minWidth": 100,
      "comparator": this.gridHelper.dateComparator,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "type": "date"
    },
    {
      "headerName": "Decision outcome",
      "field": "terminationType",
      "width": 200,
      "minWidth": 200,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "tooltipField": 'terminationType',
      "tooltipComponentParams": { data: 'terminationType' }
    },
  //   {
  //     "headerName": "Status",
  //     "field": "statusDisplay",
  //     "width": 130,
  //     "minWidth": 130,
  //     "resizable": true
  //     // "cellRendererFramework": OpenCaseviewerComponent
  //   },
  //  {
  //   "headerName": "Termination date",
  //   "field": "terminationDateStr",
  //   "width": 100,
  //   "minWidth": 100,
  //   "comparator": this.gridHelper.dateComparator,
  //   "resizable": true,
  //   "wrapText": false,
  //   "autoHeight": false,
  //   "type": "date"
  // },
  // {
  //   "headerName": "Decision outcome",
  //   "field": "terminationType",
  //   "width": 200,
  //   "minWidth": 200,
  //   "resizable": true,
  //   "wrapText": false,
  //   "autoHeight": false,
  //   "tooltipField": 'terminationType',
  //   "tooltipComponentParams": { data: 'terminationType' }
  // },
    {
      "headerName": "Petitioner",
      "field": "petiRealParty",
      "width": 250,
      "minWidth": 250,
      "resizable": true,
      "tooltipField": 'petiRealParty',
      "tooltipComponentParams": { data: 'petiRealParty' }
    },
    {
      "headerName": "Application #",
      "field": "poApplicationId",
      "width": 150,
      "minWidth": 150,
      "maxWidth": 150,
      "resizable": true
    },
    {
      "headerName": "Patent #",
      "field": "poPatentNumber",
      "width": 150,
      "minWidth": 150,
      "maxWidth": 150,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT,
      "field": "poRealParty",
      "width": 250,
      "minWidth": 250,
      "resizable": true,
      "tooltipField": 'poRealParty',
      "tooltipComponentParams": { data: 'poRealParty' }
    },
    {
      "headerName": "Invention title",
      "field": "poInventionTitleTx",
      "width": 300,
      "minWidth": 300,
      "resizable": true,
      "tooltipField": 'poInventionTitleTx',
      "tooltipComponentParams": { data: 'poInventionTitleTx' }
    },
    {
      "headerName": "Inventor",
      "field": "poInventorFullName",
      "width": 175,
      "minWidth": 175,
      "maxWidth": 175,
      "resizable": true
    }
  ],
    requiringClosure: [{
      "headerName": "",
      "field": "",
      "width": 25,
      "minWidth": 25,
      "maxWidth": 25,
      "resizable": false,
      "floatingFilter": false,
      "headerCheckboxSelection": false,
      "cellStyle": {
        "background-color": "#F0F0EE"
      }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.AIA_REVIEW,
      "field": "proceedingNumber",
      "width": 130,
      "minWidth": 130,
      "resizable": true,
      "cellRendererFramework": OpenCaseviewerComponent
    },
    {
      "headerName": "Status",
      "field": "statusDisplay",
      "width": 200,
      "minWidth": 200,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITION_SUBMISSION_DT,
      "field": "submittedDateStr",
      "width": 130,
      "minWidth": 130,
      "resizable": true,
      "comparator": this.gridHelper.dateComparator,
      "headerCheckboxSelection": false,
      "sort": "asc",
      "type": "date"
    },
    {
      "headerName": "NOFDA date",
      "field": "nofdaStr",
      "width": 80,
      "minWidth": 80,
      "comparator": this.gridHelper.dateComparator,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "type": "date"
    },
    {
      "headerName": "Institution decision date",
      "field": "institutionDecisionDateStr",
      "width": 100,
      "minWidth": 100,
      "comparator": this.gridHelper.dateComparator,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "type": "date"
    },
    {
      "headerName": "Termination date",
      "field": "terminationDateStr",
      "width": 100,
      "minWidth": 100,
      "comparator": this.gridHelper.dateComparator,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "type": "date"
    },
    {
      "headerName": "Decision outcome",
      "field": "terminationType",
      "width": 200,
      "minWidth": 200,
      "resizable": true,
      "wrapText": false,
      "autoHeight": false,
      "tooltipField": 'terminationType',
      "tooltipComponentParams": { data: 'terminationType' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITIONER_PATENT_NO,
      // "valueGetter": function (params) {
      //   if (!params.data.petitionerPatentNumber || params.data.petitionerPatentNumber === "") {
      //     return params.data.petitionerapplicationId;
      //   } else {
      //     return params.data.petitionerPatentNumber
      //   }
      // },
      "valueGetter": this.gridHelper.valueGetterForPetitionerPatentNoAia,
      "width": 145,
      "minWidth": 145,
      "resizable": true
    },
    {
      "headerName": "Petitioner",
      "field": "petiRealParty",
      "width": 200,
      "minWidth": 200,
      "resizable": true,
      "tooltipField": 'petiRealParty',
      "tooltipComponentParams": { data: 'petiRealParty' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITIONER_TECH_CENTER,
      "field": "petiTechCenterId",
      "width": 100,
      "minWidth": 100,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_PATENT_NO,
      // "valueGetter": function (params) {
      //   if (!params.data.patentNumber || params.data.patentNumber === "") {
      //     return params.data.applicationId;
      //   } else {
      //     return params.data.patentNumber
      //   }
      // },
      "valueGetter": this.gridHelper.valueGetterForPOPatentNoAia,
      "width": 150,
      "minWidth": 150,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT,
      "field": "poRealParty",
      "width": 175,
      "minWidth": 175,
      "resizable": true,
      "tooltipField": 'poRealParty',
      "tooltipComponentParams": { data: 'poRealParty' }
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_RESPONDENT_TECH_CENTER,
      "field": "poTechCenterId",
      "width": 120,
      "minWidth": 120,
      "resizable": true
    },
    {
      "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.JUDGE_PANEL,
      "field": "judges",
      "width": 175,
      "minWidth": 175,
      "resizable": true,
      "tooltipField": 'judges',
      "tooltipComponentParams": { data: 'judges' },
      "cellRendererFramework": JudgePanelRendererComponent,
      "cellRendererParams": (params: ICellRendererParams) => this.gridHelper.formatJudgePanelTooltip(params)
    }
  ]
  };

  rowData = {
    aiaReviews: [],
    withoutMandatoryNotices: [],
    defective: [],
    readyForTrial: [],
    requiringClosure: []
  }

  allAIAColumnDefs: Array<any> = [];
  allAIARowData: Array<any> = [];
  withoutMandatoryNoticeColumnDefs: Array<any> = [];
  withoutMandatoryNoticeRowData: Array<any> = [];

  numberOfFilters = 0;

  total = {
    aiaReviews: null,
    withoutMandatoryNotices: null,
    defective: null,
    readyForTrial: null,
    requiringClosure: null
  }

  fileName: string = null;
  aiaResponse: any;
  colState: any;

  constructor(
    private gridHelper: GridHelperService,
    private trialsService: TrialsService,
    private commonUtils: CommonUtilitiesService
  ) { }

  ngOnInit(): void {
    this.frameworkComponents = { customTooltip: ToolTipComponent };
    this.gridRefreshValues.showLoading = true;
    this.getAllAIAReviews(this.selectedType, true);
    setInterval(()=>{
     let ele =document.getElementById('autorefresh');
   if(ele){ele.click();}
    },300000)
  }

   autoRefresh() {
    this.colState = this.gridApi.getFilterModel();
    this.gridRefreshValues.showLoading = false;
    this.getAllAIAReviews(this.selectedType, true);
  }

  refresh(reviewType, forceRefresh){
    this.colState = this.gridApi.getFilterModel();
    this.gridRefreshValues.showLoading = true;
    this.getAllAIAReviews(reviewType, forceRefresh)
  }

  getAllAIAReviews(reviewType, forceRefresh) {


    this.loadingMessage = "Loading all AIA reviews...";
    this.noRowsTemplate = this.reviewTypes[reviewType].noRowsTemplate;
    this.fileName = this.reviewTypes[reviewType].fileName;
    if (this.rowData[reviewType].length <= 0 || forceRefresh) {
      let count =0;
     Object.keys(this.reviewTypes).forEach((element) => {

      let obj ={
        "proceedingState":element,
        "trailTypes": [
            "IPR",
            "PGR",
            "CBM",
            "DER"
        ]

    }
      this.trialsService.getInitiatedCasesNew(obj).pipe(take(1)).subscribe((aiaReviewsResponse) => {
        this.numberOfFilters = 0;

        count =count+1;
        let readyForTrial=[];

        aiaReviewsResponse.forEach(aiaresp => {
          // aiaresp.mileStoneDt? aiaresp.terminationType=this.commonUtils.findDecisionOutcome(aiaresp.mileStoneDt):''
          // aiaresp.nofda = this.commonUtils.parseKeyDates(aiaresp.mileStoneDt,"Notice of Accorded Filing Date");
          // aiaresp.accordedDate = this.commonUtils.parseKeyDates(aiaresp.mileStoneDt,"Accorded Filing Date");
          // aiaresp.terminationDate = this.commonUtils.parseKeyDates(aiaresp.mileStoneDt,"Termination Decision");
          // aiaresp.institutionDecisionDate = this.commonUtils.parseKeyDates(aiaresp.mileStoneDt,"Decision to Institute");
          // aiaresp.submittedDate = this.commonUtils.parseKeyDates(aiaresp.mileStoneDt,"Filing Date");
          if (aiaresp.submittedDate) {
            // aiaresp.submittedDateStr = this.gridHelper.convertDateToString(aiaresp.submittedDate);
          aiaresp.daysSinceSubmissionDate=((new Date().getTime()-aiaresp.submittedDate)/(24*60*60*1000));
          aiaresp.daysSinceSubmissionDate=parseInt(aiaresp.daysSinceSubmissionDate);
           }
           if(aiaresp.accordedDate){
            aiaresp.daysSinceAccorded=(new Date().getTime()-aiaresp.accordedDate)/(24*60*60*1000);
            aiaresp.daysSinceAccorded=parseInt(aiaresp.daysSinceAccorded);
             }
          if (element == "readyForTrial" && aiaresp.terminationDate) {
            aiaresp.submittedDateStr = aiaresp.submittedDate ? this.gridHelper.convertDateToString(aiaresp.submittedDate) : null;
            aiaresp.terminationDateStr = aiaresp.terminationDate ? this.gridHelper.convertDateToString(aiaresp.terminationDate) : null;

          if(((new Date().getTime()-aiaresp.terminationDate)/(24*60*60*1000)) > 63){
            // console.log("dtae",new Date(aiaresp.terminationDate).getTime())
            readyForTrial.push(aiaresp);
          }
         }
        });
        if(element=="readyForTrial"){
          this.rowData[element]=readyForTrial;
          readyForTrial=[];
        }else{

        }  this.rowData[element]=aiaReviewsResponse;

        this.total[element] = this.commonUtils.formatNumber(aiaReviewsResponse.length);
        if(this.colState){
        setTimeout(() => {
          this.gridApi.setFilterModel(this.colState);
        }, 100);
      }
          this.reviewTypes[element].total=this.commonUtils.formatNumber(aiaReviewsResponse.length);

      if( element=='aiaReviews' ){

        for (const [key] of Object.entries(this.rowData)) {
          this.convertDatesToString(this.rowData[key]);
        }
        this.gridRefreshValues.showLoading = false;
        this.gridRefreshValues.lastRefresh = Date.now();
      }

      }, (allAIAFailure) => {
        count =count+1;

          this.gridRefreshValues.showLoading = reviewType === 'aiaReviews' ? false : true;
        this.gridRefreshValues.lastRefresh = Date.now();
      }
      );
      });


    } else {
      this.gridRefreshValues.showLoading = false;
    }
  }


  convertDatesToString(el) {
    el.forEach(element => {
      element.submittedDateStr = element.submittedDate ? this.gridHelper.convertDateToString(element.submittedDate) : null;
      element.nofdaStr = element.nofda ? this.gridHelper.convertDateToString(element.nofda) : null;
      element.institutionDecisionDateStr = element.institutionDecisionDate ? this.gridHelper.convertDateToString(element.institutionDecisionDate) : null;
      element.terminationDateStr = element.terminationDate ? this.gridHelper.convertDateToString(element.terminationDate) : null;
    });
  }

  changeType(reviewType) {
    this.selectedType = reviewType;
    this.numberOfFilters = 0;
    this.noRowsTemplate = this.reviewTypes[reviewType].noRowsTemplate;
    this.total[reviewType]=this.reviewTypes[reviewType].total;
    this.clearGridFilters();
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }


  onFilterChanged() {
    // console.log("On filter changed: ", this.gridApi.getDisplayedRowCount());
    // const filterModel = this.gridApi.getFilterModel();
    // this.numberOfFilters = Object.keys(filterModel).length;
    // this.total[this.selectedType] = this.commonUtils.formatNumber(this.gridApi.getDisplayedRowCount());
    const resp = this.gridHelper.onFilterChanged(this.gridApi);
    this.numberOfFilters = resp.numberOfFilters;
    this.total[this.selectedType] = resp.totalCount;
  }


  getTotalCount() {
    if (this.gridApi) {
      const totalCount = this.commonUtils.formatNumber(this.gridApi.getDisplayedRowCount());
      return totalCount ? totalCount : 0
    } else {
      return 0
    }
  }



  isFirstColumn(params) {
    const displayedColumns = params.columnApi.getAllDisplayedColumns();
    const thisIsFirstColumn = displayedColumns[0] === params.column;
    return thisIsFirstColumn;
  }



  clearGridFilters() {
    this.gridApi.setFilterModel(null);
  }


  exportDataAsCsv() {
    this.commonUtils.setToastr('success', 'Processing export...');
    this.gridHelper.exportDataAsCsv(this.gridApi, this.reviewTypes[this.selectedType].fileName);
  }

}
