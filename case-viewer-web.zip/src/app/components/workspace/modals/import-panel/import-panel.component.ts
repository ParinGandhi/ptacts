import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { TrialsService } from 'src/app/services/trials.service';
import { Store, select } from '@ngrx/store';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';

@Component({
  selector: 'app-import-panel',
  templateUrl: './import-panel.component.html',
  styleUrls: ['./import-panel.component.less']
})
export class ImportPanelComponent implements OnInit {

  constructor(
    public bsModalRef: BsModalRef,
    private trialsService: TrialsService,
    private commonUtils: CommonUtilitiesService,
    private store: Store<CaseViewerState>
  ) { }

  importPanel: any;
  fileName: any;
  fileToImport: any;
  sheetNames: Array<string> = [];
  selectedSheet: string = null;
  importing: boolean = false;
  loggedInUser = null;

  ngOnInit(): void {
    this.store.pipe(select(CaseViewerSelectors.userInfoData)).subscribe(data => {
      this.loggedInUser = data.caseDetailsData[0];
      if (!this.loggedInUser) {
        this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
      }
    });
  }

/*istanbul ignore next*/
  fileChangeEvent(e) {
    this.fileToImport = e.target.files[0];
    let fd = new FormData();
    fd.append('file', this.fileToImport);
    this.fileName = this.fileToImport.name;
    this.trialsService.getSheetNames(fd).subscribe((sheetNamesResponse) => {
      console.log('sheetNamesResponse: ', sheetNamesResponse);
      this.sheetNames = sheetNamesResponse.sheetNames;
      this.sheetNames.sort();
      this.selectedSheet = this.sheetNames[0];
    }, (sheetNamesFailure) => {
      console.log('sheetNamesFailure: ', sheetNamesFailure);
      this.clearFile();
      this.commonUtils.setToastr('error', sheetNamesFailure.error.message);
    });
  }

/*istanbul ignore next*/
  bulkImport() {
    this.importing = true;
    // let loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
    let formData: FormData = new FormData();
    formData.append('file', this.fileToImport);
    formData.append('sheetName', this.selectedSheet);
    formData.append('userIdentifier', this.loggedInUser.loginId);
    this.trialsService.importPanel(formData).subscribe((bulkImportSuccess) => {
      console.log('bulkImportSuccess: ', bulkImportSuccess);
      let toastrType = bulkImportSuccess.message.toLowerCase().includes('none') ? 'error' : 'success';
      this.commonUtils.setToastr(toastrType, bulkImportSuccess.message);
      this.importing = false;
      if (toastrType === 'success') {
        this.close(true);
      }
    }, (bulkImportFailure) => {
      console.log('bulkImportFailure: ', bulkImportFailure);
      this.commonUtils.setToastr('error', bulkImportFailure.error.message);
      this.importing = false;
    });
  }


  clearFile() {
    (<HTMLInputElement>document.getElementById("importPanelFile")).value = "";
    this.sheetNames = [];
    this.fileName = null;
  }


  close(val) {
    this.importPanel.isConfirm = val;
    this.bsModalRef.hide();
  }

}
