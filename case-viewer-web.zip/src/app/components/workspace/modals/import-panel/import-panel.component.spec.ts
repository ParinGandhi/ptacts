import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ImportPanelComponent } from './import-panel.component';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { TrialsService } from 'src/app/services/trials.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DatePipe } from '@angular/common';
import { provideMockStore } from '@ngrx/store/testing';
import * as CaseViewerSelectors  from 'src/app/store/case-viewer/case-viewer.selectors';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { ToastrService } from 'ngx-toastr';
import { of, throwError } from 'rxjs';


/**
 * 78.26%
 */
describe('ImportPanelComponent', () => {
    let component: ImportPanelComponent;
    let trialsService: TrialsService;
    let importPanelModelRef: BsModalRef;
    let modalService: BsModalService;
    let commonUtils: CommonUtilitiesService;
    let fixture: ComponentFixture<ImportPanelComponent>;

    const toastrService = {
        success: (
          message?: string,
          title?: string
        ) => {},
        error: (
          message?: string,
          title?: string
        ) => {},
    };

    const importPanelMock = {
        title: 'AIA Trial panel bulk import',
        isConfirm: false,
        height: 190
    }

    const sheetNamesResponseMock = {
        sheetNames: [
            "Sheet1", "Sheet2", "Sheet3"
        ]
    }

    const bulkImportSuccessMock = {
        message: "None of the cases were paneled."
    }

    const loggedInUserInfo = {
        caseDetailsData:
          [{
            activeIn: "Active",
            apjSeniorityRank: 85,
            disiplanceCd: "Electrical",
            emailAddress: "Test_Jennifer.Bisk@USPTO.GOV",
            firstName: "Jennifer",
            fullName: "Bisk, Jennifer S.",
            jobClassificationCode: "APJ",
            lastName: "Bisk",
            leadApjIndicator: "APJ1",
            loginId: "jbisk",
            preferredFullName: "Bisk, Jennifer S.",
            privileges: null,
            roleDescription: "Judge",
            trialJudgeIndicator: "Judge",
            userIdentiifier: 5017,
            userWorkerNumber: "88548",
            isAdmin: false
            }
          ]
      };


    const failureMock = {
        error: {
            message: "Error"
        }
    };

  beforeEach(async () => {
      await TestBed.configureTestingModule({
        imports: [HttpClientTestingModule],
        declarations: [ImportPanelComponent],
        providers: [TrialsService, CommonUtilitiesService, DatePipe,
            {
                provide: BsModalRef,
                useValue: {}
            },
            {
                provide: BsModalService,
                useValue: {}
            },
            {
                provide: ToastrService,
                useValue: toastrService
            },
            provideMockStore({
                selectors: [{ selector: CaseViewerSelectors.userInfoData, value: { caseDetailsData: [] } },
                {selector: CaseViewerSelectors.userInfoData,value:{caseDetailsData: [{
                  activeIn: "Active",
                  apjSeniorityRank: 85,
                  disiplanceCd: "Electrical",
                  emailAddress: "Test_Jennifer.Bisk@USPTO.GOV",
                  firstName: "Jennifer",
                  fullName: "Bisk, Jennifer S.",
                  jobClassificationCode: "APJ",
                  lastName: "Bisk",
                  leadApjIndicator: "APJ1",
                  loginId: "jbisk",
                  preferredFullName: "Bisk, Jennifer S.",
                  privileges: null,
                  roleDescription: "Judge",
                  trialJudgeIndicator: "Judge",
                  userIdentiifier: 5017,
                  userWorkerNumber: "88548",
                  isAdmin: false
                  }]}}]
              })
        ]
    })
    .compileComponents();
  });

  beforeEach(() => {
      fixture = TestBed.createComponent(ImportPanelComponent);
      commonUtils = TestBed.inject(CommonUtilitiesService);
      trialsService = TestBed.inject(TrialsService);
      modalService = TestBed.inject(BsModalService);
      component = fixture.componentInstance;
      component.importPanel = importPanelMock;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


    it('should call file change event', () => {
        let userName ={}
        spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
            return userName[key];
        });
        spyOn(trialsService, 'getSheetNames').and.returnValue(of(sheetNamesResponseMock))
        let dummyFile = new File([""], "fileName.xls");
        let file = {
            target: {
                files: []
            }
        };
        file.target.files.push(dummyFile);
        component.fileChangeEvent(file);
        expect(component.sheetNames).toEqual(sheetNamesResponseMock.sheetNames);
        expect(component.selectedSheet).toEqual(component.sheetNames[0]);
    });


    // it('should call bulk import', () => {

    //     let userName = {};
    //     spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
    //         return userName[key];
    //     });
    //     spyOn(trialsService, 'importPanel').and.returnValue(of(bulkImportSuccessMock));
    //     let dummyFile = new File([""], "fileName.xls");
    //     let file = {
    //         target: {
    //             files: []
    //         }
    //     };
    //     file.target.files.push(dummyFile);
    //     component.fileToImport = file;
    //     component.bulkImport();
    // });


    it('should call clear file', () => {
        component.clearFile();
        expect(component.sheetNames.length).toBe(0);
        expect(component.fileName).toBeNull();
    });


    it('should fail trying to read sheets', () => {
        let userName ={}
        spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
            return userName[key];
        });
        spyOn(trialsService, 'getSheetNames').and.returnValue(throwError(failureMock));
        let dummyFile = new File([""], "fileName.xls");
        let file = {
            target: {
                files: []
            }
        };
        file.target.files.push(dummyFile);
        component.fileChangeEvent(file);
    });


    // it('should fail trying to do bulk import', () => {
    //     let userName = {};
    //     spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
    //         return userName[key];
    //     });
    //     spyOn(trialsService, 'importPanel').and.returnValue(throwError(failureMock));
    //     let dummyFile = new File([""], "fileName.xls");
    //     let file = {
    //         target: {
    //             files: []
    //         }
    //     };
    //     file.target.files.push(dummyFile);
    //     component.fileToImport = file;
    //     component.bulkImport();
    // });
});
