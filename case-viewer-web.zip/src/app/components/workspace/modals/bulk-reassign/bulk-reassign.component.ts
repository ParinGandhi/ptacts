import { Component, OnInit } from '@angular/core';
import { Select2OptionData } from 'ng-select2';
import { Options } from 'select2';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import { JpViewService } from 'src/app/services/jpview.service';
import { TrialsService } from 'src/app/services/trials.service';
declare let $: any;

@Component({
  selector: 'app-bulk-reassign',
  templateUrl: './bulk-reassign.component.html',
  styleUrls: ['./bulk-reassign.component.less']
})
export class BulkReassignComponent implements OnInit {

  modal: any;
  reassignToList: Array<any> = [];
  selectedReassignTo: any = null;
  selectedDueDateOption: string = null;
  selectedNewDate: any = null;
  canReassign: boolean = false;
/* istanbul ignore next */
   templateResult = (state: any): string => {
    if (!state.id) {
      return state.text;
    }
    let badgeText = '<span class="badge"></span>';
    if (state.activeTask >0) {
      badgeText = '<span class="badge">' + state.activeTask + '</span>';
    } else {
      badgeText = '<span class="badge">' + 0 + '</span>';
    }
    return $('<span>' + state.text + ' '+badgeText + '</span>');
  }

  options = {
    multiple: false,
    closeOnSelect: true,
    width: '100%',
    allowClear: true,
    theme: 'bootstrap',
    openOnEnter: true,
    templateResult: this.templateResult,
    templateSelection: this.templateResult,
    // minimumResultsForSearch: Infinity - use to hide search box
  }

  constructor(private modalService: BsModalService, private jpViewService: JpViewService, private trialsService: TrialsService, private toastr: ToastrService) { }

  ngOnInit(): void {

    this.modal.workQueueInfo.forEach(element => {
      if (element.comments && element.comments.length > 0) {
        element.notesText = element.comments[0];
      } else {
        element.notesText = null;
      }
    });
    this.getAssignToList();
    this.selectedDueDateOption = 'existingDate';
  }

  close(refreshValue) {
      this.modal.isConfirm = refreshValue;
      this.modalService.hide();
  }

  getAssignToList() {
    // this.jpViewService.getAssignToList(`/standard-hierarchy-group/my-team/${this.modal.loggedInUser.loginId}?activeOnly=true`).subscribe((assignToListSuccess)=>{
    this.trialsService.getAssignToList(`${PtabTrialConstants.HIERARCHY.MY_GROUP}${this.modal.loggedInUser.loginId}?activeOnly=true`).subscribe((assignToListSuccess)=>{
    // this.jpViewService.getAssignToList(`https://ptabe2eint-fqt.etc.uspto.gov/PTABAppealsServices/user-management/assignees/${this.modal.loggedInUser.loginId}`).subscribe((assignToListSuccess) => {
      this.reassignToList = [];
      if (assignToListSuccess && assignToListSuccess.assigneeData) {
        assignToListSuccess.assigneeData.forEach(element => {
        // assignToListSuccess.teamData.forEach(element => {
          element.id = element.assigneeNumberText;
          element.text = element.assigneeFullNameText;
          element.activeTask = element.activeCaseCount;
          this.reassignToList.push(element);
        });
      }

    });
  }


  validateFields() {
    // this.canReassign = false;
     if (this.selectedDueDateOption === 'changeDate' && this.selectedNewDate && this.selectedReassignTo) {
      this.canReassign = true;
    } else if(this.selectedReassignTo && this.selectedReassignTo != null){
      this.canReassign = true;
    } else {
      this.canReassign = false;
    }
  }

/* istanbul ignore next */
  reassignTasks() {

    let assigneeName: string = null;
    let assigneeIdentifier: string = null;

    this.reassignToList.forEach((element) => {

      if (element.id == this.selectedReassignTo) {
        assigneeName = element.text;
        assigneeIdentifier = element.userIdentifier;
      }
    });
    let currentTimeStamp = new Date().getTime();
    let newDate = null;
    if (this.selectedDueDateOption === 'changeDate') {
      newDate = Date.parse(`${this.selectedNewDate}T00:00`);
    }
    this.modal.workQueueInfo.forEach((task) => {

      // task.assigneeUserIdentifier = this.selectedReassignTo;
      // task.assigneeUserIdentifier = assigneeName;
      // task.assigneeUserIdentifier = 'sbartlett';
      task.assignerUserIdentifier = this.modal.loggedInUser.loginId;
      task.assigneeUserIdentifier = assigneeIdentifier;
      task.deadLineDate = newDate ? newDate : task.deadLineDate;
      task.goalDate = this.modal.workQueueInfo[0].statutoryDate;
      task.petitionerNameVsrespondentName = null;
      task.judgePanel = null;
      task.panelCount = null;
      task.judgeNamesList = [];
      task.requesterUserIdentifier = task.requesterUserIdentifier? task.requesterUserIdentifier: this.modal.loggedInUser.loginId;
      // task.notesText = task.comments;
      task.audit = {
        createUserIdentifier: this.modal.loggedInUser.loginId,
          "lastModifiedUserIdentifier": this.modal.loggedInUser.loginId,
          "lastModifiedTimestamp": currentTimeStamp,
          "createTimestamp": currentTimeStamp
      }
    })
    let tasksToReassign = {
      tasksList: this.modal.workQueueInfo
    };
    this.trialsService.reassignTasks(`/worker-task/bulk`, tasksToReassign).subscribe((reassignSuccess) => {
      console.log('reassignSuccess: ', reassignSuccess);
      this.toastr.success("Successfully reassigned tasks", "", {
        closeButton: true
      });
      this.close(true);

    }, (reassignFailure) => {
        console.log('reassignFailure: ', reassignFailure);
        this.toastr.error(reassignFailure.error.message, "", {
          closeButton: true
        });
    });

  }

}
