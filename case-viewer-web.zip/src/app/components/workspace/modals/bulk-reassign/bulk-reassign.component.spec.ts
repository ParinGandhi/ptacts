import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import * as CaseViewerSelectors  from 'src/app/store/case-viewer/case-viewer.selectors';
import { ActivatedRoute } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { BulkReassignComponent } from './bulk-reassign.component';
import { ToastrService } from 'ngx-toastr';
import { JpViewService } from 'src/app/services/jpview.service';
import { of } from 'rxjs/internal/observable/of';
import { TrialsService } from 'src/app/services/trials.service';
import { throwError } from 'rxjs';


/**
 * 81.43%
 */
describe('BulkReassignComponent', () => {
  let component: BulkReassignComponent;
  let fixture: ComponentFixture<BulkReassignComponent>;
  let modalService: BsModalService;
  let jpViewService: JpViewService;
  let trialsService: TrialsService;
  const bsMock ={
    hide: () => {}
  }
  const activatedRouteMock = {
    snapshot: {
      params: {
        serialNo: "123456789",
        proceedingNo: "DER2020-123456"
      },
      url:[
        {
          path: "case-viewer"
        }
      ]
    }
  }

  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => {},
    error: (
      message?: string,
      title?: string
    ) => {},
  };

  const assignToListMock ={
    assigneeData : [
      {
        "assigneeNumberText" : "numberText",
        "assigneeFullNameText" : "fullname",
        "activeCaseCount":"3"
      }
    ]
  }

  // const modal = {
  //   title: 'Update',
  //   closeBtnName: 'Done',
  //   isConfirm: 'false',
  //   workQueueInfo: [{
  //     comments:'firstComment',
  //     assigneeUserIdentifier : 'assigneeIdentifier',
  //     deadLineDate : new Date().getTime(),
  //     petitionerNameVsrespondentName : null,
  //     judgePanel : null,
  //     panelCount : null,
  //     judgeNamesList : []
  //   },{
  //     comments:'',
  //     assigneeUserIdentifier : 'assigneeIdentifier',
  //     deadLineDate : new Date().getTime(),
  //     petitionerNameVsrespondentName : null,
  //     judgePanel : null,
  //     panelCount : null,
  //     judgeNamesList : []
  //   }],
  //   caseInfo: [{
  //     serialNo: '14178064',
  //     proceedingNo: 'DER2018-00328'
  //     }],
  //   loggedInUser: [{
  //       loginId: "akellogg",
  //       privileges: "PanelMember"
  //     }],
  //   modalType: 'updateTask'
  // };

  const reAssignMock = {
    success : "success"
  }

  const modalRef = { hide: null, setClass: null };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [ BulkReassignComponent ],
      providers: [
        provideMockStore({
          selectors: [
            { selector: CaseViewerSelectors.caseInfoData, value: { proceedingNo: '37553565' } },
            { selector: CaseViewerSelectors.userInfoData,value:{caseDetailsData: [{loginId: "akellogg"}]}}
          ]
        }),
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        },
        {
          provide: BsModalRef,
          useValue: bsMock
        },
        {
          provide: BsModalService,
          useValue: bsMock
        },
        { provide: ToastrService,
          useValue: toastrService
        }
       ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BulkReassignComponent);
    // modalService = TestBed.inject(BsModalService);
    trialsService = TestBed.inject(TrialsService);
    jpViewService = TestBed.inject(JpViewService);
    component = fixture.componentInstance;
    let userName ={}
    spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
        return userName[key];
    });
    // spyOn(jpViewService, 'getAssignToList').and.returnValue(of({assignToListMock}));
    spyOn(trialsService, 'getAssignToList').and.returnValue(of({assignToListMock}));
    component.reassignToList = [{
      text : "text",
      userIdentifier : "userIdentifier"
    }];
    component.modal = {
      title: 'Update',
      closeBtnName: 'Done',
      isConfirm: 'false',
      workQueueInfo: [{
        comments:'firstComment',
        assigneeUserIdentifier : 'assigneeIdentifier',
        deadLineDate : new Date().getTime(),
        petitionerNameVsrespondentName : null,
        judgePanel : null,
        panelCount : null,
        judgeNamesList : []
      },{
        comments:'',
        assigneeUserIdentifier : 'assigneeIdentifier',
        deadLineDate : new Date().getTime(),
        petitionerNameVsrespondentName : null,
        judgePanel : null,
        panelCount : null,
        judgeNamesList : []
      }],
      caseInfo: [{
        serialNo: '14178064',
        proceedingNo: 'DER2018-00328'
        }],
      loggedInUser: [{
          loginId: "akellogg",
          privileges: "PanelMember"
        }],
      modalType: 'updateTask'
    };
    // component.modal = modal;
    fixture.detectChanges();
  });

  it('should create', () => {
    // component.modal = modal;
    expect(component).toBeTruthy();
  });

  it('should call getAssignToList and get successResponse', () => {
    // component.modal = modal;
  //  spyOn(jpViewService, 'getAssignToList').and.returnValue(of({assignToListMock}));
  //  component.getAssignToList();
   // expect(component.reassignToList).not.toEqual([]);
  });

  it('should validateFields', () => {
    component.validateFields();
    expect(component.canReassign).toEqual(false);
  });

  it('should call validateFields with existingDate', () => {
    component.selectedDueDateOption = 'existingDate';
    component.selectedReassignTo = true;
    component.validateFields();
    expect(component.canReassign).toEqual(true);
  });

  it('should validateFields with changeDate', () => {
    component.selectedDueDateOption = 'changeDate';
    component.selectedNewDate = new Date().getTime();
    component.selectedReassignTo = true;
    component.validateFields();
    expect(component.canReassign).toEqual(true);
  });

  xit('should call reassignTasks', () => {
    // component.reassignToList = [{
    //   text : "text",
    //   userIdentifier : "userIdentifier"
    // }];
    // component.modal=modal;
    spyOn(trialsService, 'reassignTasks').and.returnValue(of(reAssignMock));
    modalService.hide = (): BsModalRef => {
      return ({ id: null, hide: null, setClass: null, onHide: null, onHidden: null});
    };
    spyOn(modalService, 'hide').and.returnValue();
    component.reassignTasks();
    expect(component.selectedDueDateOption).toEqual(null);
  });

  xit('should call reassignTasks  and throw error', () => {
    component.selectedDueDateOption ="changeDate";
    // component.reassignToList = [{
    //   text : "text",
    //   userIdentifier : "userIdentifier"
    // }];
    // component.modal=modal;
    const ResponseMock = {
      error: {
        message:""
      }

  }
    spyOn(trialsService, 'reassignTasks').and.returnValue(throwError(ResponseMock));
    modalService.hide = (): BsModalRef => {
      return ({ id: null, hide: null, setClass: null, onHide: null, onHidden: null});
    };
    spyOn(modalService, 'hide').and.returnValue();
    component.reassignTasks();
    expect(component.selectedDueDateOption).not.toEqual(null);
  });

  it('should call close', () =>{
    component.close(true);
  })

});
