import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { JpViewService } from 'src/app/services/jpview.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { provideMockStore } from '@ngrx/store/testing';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { OrderModule } from 'ngx-order-pipe';
import { PanelingComponent } from './paneling.component';
import { TrialsService } from 'src/app/services/trials.service';
import { of } from 'rxjs';
import { throwError } from 'rxjs';
import { EventEmitter } from '@angular/core';


/**
 * 69.92%
 */
describe('PanelingComponent', () => {
  let component: PanelingComponent;
  let trialsService: TrialsService;
  let jpViewService: JpViewService;
  let modalService: BsModalService;
  let modalRef: BsModalRef;
  let fixture: ComponentFixture<PanelingComponent>;

  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => {},
    error: (
      message?: string,
      title?: string
    ) => {},
  };
  const assignPanelSuccessMock = {
    success: {
      message: "Success"
    }
  };
  let caseInfoMock = {
    serialNo: "12345678",
    proceedingNo: "12345678"
  }

  const headerInfoResponseMock = {
    artUnit: "2826",
    attorneys: null,
    casePhase: null,
    derproceedingTypeDetails: null,
    inventionTitle: "AN INTERPOSING STRUCTURE",
    keyDates: null,
    mileStoneDates: null,
    parties: null,
    patentNumberText: "7566960",
    proceedingNumber: "IPR2012-00008",
    ptabReadOnlyUser: true,
    techCenterNum: "2800"
  }

  const panelingMock = {
    caseToPanel: {
      applicationId: "10698704",
      nofda: null,
      nofdaStr: null,
      patentNumber: "7566960",
      patentOwner: null,
      petitioner: null,
      petitionerRealParty: "Intellectual Ventures Management, LLC",
      poRealParty: null,
      proceedingNumber: "IPR2012-00008",
      submittedDate: 1347836540664,
      submittedDateStr: "09/16/2012 07:02:20 PM",
      techCenterId: "2800"
    },
    isConfirm: false,
    showClearPanelBtn: false,
    title: "Assign",
  }


  const disciplineListMock = [{ "caseDisciplineCode": "B", "caseDisciplineDescription": "Biotech" }, { "caseDisciplineCode": "BM", "caseDisciplineDescription": "Business Methods" }, { "caseDisciplineCode": "C", "caseDisciplineDescription": "Chemical" }, { "caseDisciplineCode": "CE", "caseDisciplineDescription": "Communication/Electrical" }, { "caseDisciplineCode": "CM", "caseDisciplineDescription": "Computer" }, { "caseDisciplineCode": "E", "caseDisciplineDescription": "Electrical" }, { "caseDisciplineCode": "I", "caseDisciplineDescription": "Design" }, { "caseDisciplineCode": "M", "caseDisciplineDescription": "Mechanical" }, { "caseDisciplineCode": "MX", "caseDisciplineDescription": "Mixed" }, { "caseDisciplineCode": "P", "caseDisciplineDescription": "Plant" }, { "caseDisciplineCode": "R", "caseDisciplineDescription": "Reexam" }, { "caseDisciplineCode": "SC", "caseDisciplineDescription": "Semiconductor" }, { "caseDisciplineCode": "TM", "caseDisciplineDescription": "Contested Case" }, { "caseDisciplineCode": "TP", "caseDisciplineDescription": "Interference" }, { "caseDisciplineCode": "U", "caseDisciplineDescription": "Unknown" }, { "caseDisciplineCode": "Z", "caseDisciplineDescription": "Other" }];

  const sectionListMock = [{ "sectionName": "Section 01", "teamIdentifier": 22 }, { "sectionName": "Section 02", "teamIdentifier": 23 }, { "sectionName": "Section 03", "teamIdentifier": 24 }, { "sectionName": "Section 04", "teamIdentifier": 25 }, { "sectionName": "Section 05", "teamIdentifier": 26 }, { "sectionName": "Section 06", "teamIdentifier": 27 }, { "sectionName": "Section 07", "teamIdentifier": 28 }, { "sectionName": "Section 08", "teamIdentifier": 29 }, { "sectionName": "Section 09", "teamIdentifier": 30 }, { "sectionName": "Section 10", "teamIdentifier": 31 }, { "sectionName": "Section 11", "teamIdentifier": 32 }, { "sectionName": "Section 12", "teamIdentifier": 33 }, { "sectionName": "Section 13", "teamIdentifier": 34 }, { "sectionName": "Section 14", "teamIdentifier": 35 }, { "sectionName": "Section 15", "teamIdentifier": 36 }, { "sectionName": "Section 16", "teamIdentifier": 37 }, { "sectionName": "Section 17", "teamIdentifier": 38 }, { "sectionName": "Section 18", "teamIdentifier": 39 }, { "sectionName": "Section 19", "teamIdentifier": 40 }, { "sectionName": "Section 20", "teamIdentifier": 41 }, { "sectionName": "Section 21", "teamIdentifier": 42 }, { "sectionName": "Section 22", "teamIdentifier": 43 }, { "sectionName": "Section A", "teamIdentifier": 44 }, { "sectionName": "Section B", "teamIdentifier": 45 }, { "sectionName": "Section C", "teamIdentifier": 46 }, { "sectionName": "Section F", "teamIdentifier": 47 }, { "sectionName": "Section G", "teamIdentifier": 48 }, { "sectionName": "Section 23", "teamIdentifier": 49 }, { "sectionName": "Section 24", "teamIdentifier": 50 }, { "sectionName": "Section I", "teamIdentifier": 51 }];


  const judgeListMock = { "supplementaryIdType": null, "listofJudges": [{ "identifier": "739", "firstName": "Arul", "lastName": "Savariraj", "electronicAddress": [{ "email": "Arul.Savariraj@USPTO.GOV" }], "prefferedName": "Savariraj, Arul" }, { "identifier": "5011", "firstName": "Lora", "lastName": "Green", "electronicAddress": [{ "email": "TEST_Lora.Green@USPTO.GOV" }], "prefferedName": "Green, Lora" }, { "identifier": "10836", "firstName": "Cameron", "lastName": "Weiffenbach", "electronicAddress": [{}], "prefferedName": "Weiffenbach, Cameron" }, { "identifier": "10838", "firstName": "Sherman", "lastName": "Winters", "electronicAddress": [{}], "prefferedName": "Winters, Sherman" }, { "identifier": "10805", "firstName": "Lee", "lastName": "Barrett", "electronicAddress": [{ "email": "TEST_lee.barrett@uspto.gov" }], "prefferedName": "Barrett, Lee" }, { "identifier": "10806", "firstName": "Ian", "lastName": "Calvert", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_Ian.Calvert@USPTO.GOV" }], "prefferedName": "Calvert, Ian A." }, { "identifier": "10807", "firstName": "Michael", "lastName": "Fleming", "middleInitial": "R.", "electronicAddress": [{ "email": "TEST_michael.fleming@uspto.gov" }], "prefferedName": "Fleming, Michael R." }, { "identifier": "10808", "firstName": "Gary", "lastName": "Harkcom", "electronicAddress": [{ "email": "TEST_gary.harkcom@uspto.gov" }], "prefferedName": "Harkcom, Gary" }, { "identifier": "10809", "firstName": "Edward", "lastName": "Kimlin", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_edward.kimlin@uspto.gov" }], "prefferedName": "Kimlin, Edward C." }, { "identifier": "10810", "firstName": "Errol", "lastName": "Krass", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_errol.krass@uspto.gov" }], "prefferedName": "Krass, Errol A." }, { "identifier": "10811", "firstName": "Jeffrey", "lastName": "Nase", "electronicAddress": [{ "email": "TEST_jeffrey.nase@uspto.gov" }], "prefferedName": "Nase, Jeffrey" }, { "identifier": "10813", "firstName": "William", "lastName": "Smith", "middleInitial": "F.", "electronicAddress": [{ "email": "TEST_william.smith@uspto.gov" }], "prefferedName": "Smith, William F." }, { "identifier": "10814", "firstName": "Bruce", "lastName": "Stoner, Jr.", "middleInitial": "H.", "electronicAddress": [{}], "prefferedName": "Stoner, Jr., Bruce H." }, { "identifier": "10815", "firstName": "James", "lastName": "Thomas", "middleInitial": "D.", "electronicAddress": [{ "email": "TEST_james.thomas@uspto.gov" }], "prefferedName": "Thomas, James D." }, { "identifier": "10816", "firstName": "Charles", "lastName": "Warren", "electronicAddress": [{ "email": "TEST_charles.warren@uspto.gov" }], "prefferedName": "Warren, Charles" }, { "identifier": "10817", "firstName": "Richard", "lastName": "Torczon", "electronicAddress": [{ "email": "TEST_richard.torczon@uspto.gov" }], "prefferedName": "Torczon, Richard" }, { "identifier": "10818", "firstName": "Chung", "lastName": "Pak", "electronicAddress": [{ "email": "TEST_chung.pak@uspto.gov" }], "prefferedName": "Pak, Chung" }, { "identifier": "10819", "firstName": "Lance", "lastName": "Barry", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_lance.barry@uspto.gov" }], "prefferedName": "Barry, Lance L." }, { "identifier": "10820", "electronicAddress": [{}], "prefferedName": "null, null" }, { "identifier": "10821", "firstName": "Unknown1", "lastName": "Unknown1", "electronicAddress": [{}], "prefferedName": "Unknown1, Unknown1" }, { "identifier": "10822", "firstName": "Joan", "lastName": "Ellis", "electronicAddress": [{}], "prefferedName": "Ellis, Joan" }, { "identifier": "4623", "firstName": "Trenton", "lastName": "Ward", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_Trenton.Ward@USPTO.GOV" }], "prefferedName": "Ward, Trenton A." }, { "identifier": "5012", "firstName": "Scott", "lastName": "Boalick", "middleInitial": "R.", "electronicAddress": [{ "email": "TEST_Scott.Boalick@USPTO.GOV" }], "prefferedName": "Boalick, Scott R." }, { "identifier": "5016", "firstName": "Jacqueline", "lastName": "Bonilla", "middleInitial": "Wright", "electronicAddress": [{ "email": "TEST_Jacqueline.Bonilla@USPTO.GOV" }], "prefferedName": "Bonilla, Jacqueline Wright" }, { "identifier": "98129", "firstName": "Janet", "lastName": "Gongola", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_ janet.gongola@uspto.gov" }], "prefferedName": "Gongola, Janet A." }, { "identifier": "5130", "firstName": "Michael", "lastName": "Tierney", "middleInitial": "P.", "electronicAddress": [{ "email": "TEST_Michael.Tierney@USPTO.GOV" }], "prefferedName": "Tierney, Michael P." }, { "identifier": "56345", "firstName": "Scott", "lastName": "Weidenfeller", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_scott.weidenfeller@uspto.gov" }], "prefferedName": "Weidenfeller, Scott C." }, { "identifier": "1089", "firstName": "William", "lastName": "Fink", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_William.Fink@USPTO.GOV" }], "prefferedName": "Fink, William M." }, { "identifier": "4720", "firstName": "Michael", "lastName": "Kim", "middleInitial": "W.", "electronicAddress": [{ "email": "TEST_Michael.Kim@USPTO.GOV" }], "prefferedName": "Kim, Michael W." }, { "identifier": "5025", "firstName": "Jameson", "lastName": "Lee", "electronicAddress": [{ "email": "TEST_Jameson.Lee@USPTO.GOV" }], "prefferedName": "Lee, Jameson" }, { "identifier": "20729", "firstName": "Adriene", "lastName": "Hanlon", "middleInitial": "Lepiane", "electronicAddress": [{ "email": "TEST_adriene.hanlon@uspto.gov" }], "prefferedName": "Hanlon, Adriene Lepiane" }, { "identifier": "20733", "firstName": "Terry", "lastName": "Owens", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_Terry.Owens@USPTO.GOV" }], "prefferedName": "Owens, Terry J." }, { "identifier": "5015", "firstName": "Murriel", "lastName": "Crawford", "middleInitial": "E.", "electronicAddress": [{ "email": "TEST_Murriel.Crawford@USPTO.GOV" }], "prefferedName": "Crawford, Murriel E." }, { "identifier": "5131", "firstName": "Hubert", "lastName": "Lorin", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_Hubert.Lorin@USPTO.GOV" }], "prefferedName": "Lorin, Hubert C." }, { "identifier": "20727", "firstName": "Joseph", "lastName": "Dixon", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_joe.dixon@uspto.gov" }], "prefferedName": "Dixon, Joseph L." }, { "identifier": "9951", "firstName": "Jennifer", "lastName": "Bahr", "middleInitial": "D.", "electronicAddress": [{ "email": "TEST_jennifer.bahr@uspto.gov" }], "prefferedName": "Bahr, Jennifer D." }, { "identifier": "20734", "firstName": "Catherine", "lastName": "Timm", "middleInitial": "Q.", "electronicAddress": [{ "email": "TEST_Catherine.Timm@USPTO.GOV" }], "prefferedName": "Timm, Catherine Q." }, { "identifier": "10782", "firstName": "Donald", "lastName": "Adams", "middleInitial": "E.", "electronicAddress": [{ "email": "TEST_donald.adams@uspto.gov" }], "prefferedName": "Adams, Donald E." }, { "identifier": "10826", "firstName": "Jeffrey", "lastName": "Smith", "middleInitial": "T.", "electronicAddress": [{ "email": "TEST_jeffreyt.smith@uspto.gov" }], "prefferedName": "Smith, Jeffrey T." }, { "identifier": "5023", "firstName": "Sally", "lastName": "Lane", "middleInitial": "Gardner", "electronicAddress": [{ "email": "TEST_Sally.Lane@USPTO.GOV" }], "prefferedName": "Lane, Sally Gardner" }, { "identifier": "5029", "firstName": "Sally", "lastName": "Medley", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_Sally.Medley@USPTO.GOV" }], "prefferedName": "Medley, Sally C." }, { "identifier": "118640", "firstName": "Eric", "lastName": "Grimes", "middleInitial": "B.", "electronicAddress": [{ "email": "TEST_eric.grimes@uspto.gov" }], "prefferedName": "Grimes, Eric B." }, { "identifier": "10742", "firstName": "Beverly", "lastName": "Franklin", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_beverly.pawlikowski@uspto.gov" }], "prefferedName": "Franklin, Beverly A." }, { "identifier": "5129", "firstName": "James", "lastName": "Moore", "middleInitial": "T.", "electronicAddress": [{ "email": "TEST_JamesT.Moore@USPTO.GOV" }], "prefferedName": "Moore, James T." }, { "identifier": "3289", "firstName": "Linda", "lastName": "Gaudette", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_Linda.Gaudette@USPTO.GOV" }], "prefferedName": "Gaudette, Linda M." }, { "identifier": "4072", "firstName": "Mahshid", "lastName": "Saadat", "middleInitial": "D.", "electronicAddress": [{ "email": "TEST_Mahshid.Saadat@USPTO.GOV" }], "prefferedName": "Saadat, Mahshid D." }, { "identifier": "5013", "firstName": "Allen", "lastName": "MacDonald", "middleInitial": "R.", "electronicAddress": [{ "email": "TEST_Allen.MacDonald@USPTO.GOV" }], "prefferedName": "MacDonald, Allen R." }, { "identifier": "1804", "firstName": "Robert", "lastName": "Nappi", "middleInitial": "E.", "electronicAddress": [{ "email": "TEST_Robert.Nappi@USPTO.GOV" }], "prefferedName": "Nappi, Robert E." }, { "identifier": "3883", "firstName": "Linda", "lastName": "Horner", "middleInitial": "E.", "electronicAddress": [{ "email": "TEST_Linda.Horner@USPTO.GOV" }], "prefferedName": "Horner, Linda E." }, { "identifier": "5024", "firstName": "Richard", "lastName": "Lebovitz", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_Richard.Lebovitz@USPTO.GOV" }], "prefferedName": "Lebovitz, Richard M." }, { "identifier": "4612", "firstName": "Anton", "lastName": "Fetting", "middleInitial": "W.", "electronicAddress": [{ "email": "TEST_Anton.Fetting@USPTO.GOV" }], "prefferedName": "Fetting, Anton W." }, { "identifier": "9073", "firstName": "Jean", "lastName": "Homere", "middleInitial": "R.", "electronicAddress": [{ "email": "TEST_Jean.Homere@USPTO.GOV" }], "prefferedName": "Homere, Jean R." }, { "identifier": "20737", "firstName": "John", "lastName": "Jeffery", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_john.jeffery@uspto.gov" }], "prefferedName": "Jeffery, John A." }, { "identifier": "10755", "firstName": "St. John", "lastName": "Courtenay III", "electronicAddress": [{ "email": "TEST_st.john.courtenay@uspto.gov" }], "prefferedName": "Courtenay III, St. John" }, { "identifier": "20728", "firstName": "Marc", "lastName": "Hoff", "middleInitial": "S.", "electronicAddress": [{ "email": "TEST_marc.hoff@uspto.gov" }], "prefferedName": "Hoff, Marc S." }, { "identifier": "80434", "firstName": "Joseph", "lastName": "Fischetti", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_joseph.fischetti@uspto.gov" }], "prefferedName": "Fischetti, Joseph A." }, { "identifier": "20726", "firstName": "Karen", "lastName": "Hastings", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_karen.hastings@uspto.gov" }], "prefferedName": "Hastings, Karen M." }, { "identifier": "9070", "firstName": "John", "lastName": "Kerins", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_John.Kerins@USPTO.GOV" }], "prefferedName": "Kerins, John C." }, { "identifier": "3902", "firstName": "Francisco", "lastName": "Prats", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_Frank.Prats@USPTO.GOV" }], "prefferedName": "Prats, Francisco C." }, { "identifier": "9075", "firstName": "Thu", "lastName": "Dang", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_Thu.Dang@USPTO.GOV" }], "prefferedName": "Dang, Thu A." }, { "identifier": "4203", "firstName": "Bibhu", "lastName": "Mohanty", "middleInitial": "R.", "electronicAddress": [{ "email": "TEST_Bibhu.Mohanty@USPTO.GOV" }], "prefferedName": "Mohanty, Bibhu R." }, { "identifier": "5020", "firstName": "Karl", "lastName": "Easthom", "middleInitial": "D.", "electronicAddress": [{ "email": "TEST_Karl.Easthom@USPTO.GOV" }], "prefferedName": "Easthom, Karl D." }, { "identifier": "10719", "firstName": "Michael", "lastName": "Colaianni", "middleInitial": "P.", "electronicAddress": [{ "email": "TEST_michael.colaianni@uspto.gov" }], "prefferedName": "Colaianni, Michael P." }, { "identifier": "5074", "firstName": "Kevin", "lastName": "Turner", "middleInitial": "F.", "electronicAddress": [{ "email": "TEST_Kevin.Turner@USPTO.GOV" }], "prefferedName": "Turner, Kevin F." }, { "identifier": "10832", "firstName": "Carolyn", "lastName": "Thomas", "middleInitial": "D.", "electronicAddress": [{ "email": "TEST_carolynd.thomas@uspto.gov" }], "prefferedName": "Thomas, Carolyn D." }, { "identifier": "69010", "firstName": "Jeffrey", "lastName": "Fredman", "middleInitial": "N.", "electronicAddress": [{ "email": "TEST_jeffery.fredman@uspto.gov" }], "prefferedName": "Fredman, Jeffrey N." }, { "identifier": "5031", "firstName": "Jeffrey", "lastName": "Robertson", "middleInitial": "B.", "electronicAddress": [{ "email": "TEST_Jeffrey.Robertson@USPTO.GOV" }], "prefferedName": "Robertson, Jeffrey B." }, { "identifier": "5033", "firstName": "Daniel", "lastName": "Song", "middleInitial": "S.", "electronicAddress": [{ "email": "TEST_Daniel.Song@USPTO.GOV" }], "prefferedName": "Song, Daniel S." }, { "identifier": "9069", "firstName": "Eleni", "lastName": "Mantis Mercader", "electronicAddress": [{ "email": "TEST_Eleni.Mantis-Mercader@USPTO.GOV" }], "prefferedName": "Mantis Mercader, Eleni" }, { "identifier": "10750", "firstName": "Stefan", "lastName": "Staicovici", "electronicAddress": [{ "email": "TEST_stefan.staicovici@uspto.gov" }], "prefferedName": "Staicovici, Stefan" }, { "identifier": "5014", "firstName": "Ken", "lastName": "Barrett", "middleInitial": "B.", "electronicAddress": [{ "email": "TEST_Ken.Barrett@USPTO.GOV" }], "prefferedName": "Barrett, Ken B." }, { "identifier": "3339", "firstName": "Debra", "lastName": "Stephens", "middleInitial": "K.", "electronicAddress": [{ "email": "TEST_Debra.Stephens@USPTO.GOV" }], "prefferedName": "Stephens, Debra K." }, { "identifier": "20735", "firstName": "Carl W.,", "lastName": "Whitehead", "middleInitial": "Jr.", "electronicAddress": [{ "email": "TEST_carl.whitehead@uspto.gov" }], "prefferedName": "Whitehead, Carl W., Jr." }, { "identifier": "34763", "firstName": "William", "lastName": "Baumeister", "electronicAddress": [{ "email": "TEST_BWilliam.Baumeister@USPTO.GOV" }], "prefferedName": "Baumeister, William" }, { "identifier": "10834", "firstName": "James", "lastName": "Hughes", "middleInitial": "R.", "electronicAddress": [{ "email": "TEST_james.hughes2@uspto.gov" }], "prefferedName": "Hughes, James R." }, { "identifier": "20738", "firstName": "Eric", "lastName": "Frahm", "middleInitial": "S.", "electronicAddress": [{ "email": "TEST_eric.frahm@uspto.gov" }], "prefferedName": "Frahm, Eric S." }, { "identifier": "5133", "firstName": "Joni", "lastName": "Chang", "middleInitial": "Y.", "electronicAddress": [{ "email": "TEST_Joni.Chang@USPTO.GOV" }], "prefferedName": "Chang, Joni Y." }, { "identifier": "4070", "firstName": "Kristen", "lastName": "Droesch", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_Kristen.Droesch@USPTO.GOV" }], "prefferedName": "Droesch, Kristen L." }, { "identifier": "4068", "firstName": "Denise", "lastName": "Pothier", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_Denise.Pothier@USPTO.GOV" }], "prefferedName": "Pothier, Denise M." }, { "identifier": "5022", "firstName": "Rae Lynn", "lastName": "Guest", "middleInitial": "P.", "electronicAddress": [{ "email": "TEST_Rae.Guest@USPTO.GOV" }], "prefferedName": "Guest, Rae Lynn P." }, { "identifier": "5019", "firstName": "Josiah", "lastName": "Cocks", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_Josiah.Cocks@USPTO.GOV" }], "prefferedName": "Cocks, Josiah C." }, { "identifier": "3343", "firstName": "Phillip", "lastName": "Kauffman", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_Phillip.Kauffman@USPTO.GOV" }], "prefferedName": "Kauffman, Phillip J." }, { "identifier": "3347", "firstName": "Meredith", "lastName": "Petravick", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_Meredith.Petravick@USPTO.GOV" }], "prefferedName": "Petravick, Meredith C." }, { "identifier": "10663", "firstName": "Edward", "lastName": "Brown", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_edward.brown@uspto.gov" }], "prefferedName": "Brown, Edward A." }, { "identifier": "8729", "firstName": "Jeffrey", "lastName": "Smith", "middleInitial": "S.", "electronicAddress": [{ "email": "TEST_Jeffrey.Smith@USPTO.GOV" }], "prefferedName": "Smith, Jeffrey S." }, { "identifier": "10654", "firstName": "Charles", "lastName": "Greenhut", "middleInitial": "N.", "electronicAddress": [{ "email": "TEST_charles.greenhut@uspto.gov" }], "prefferedName": "Greenhut, Charles N." }, { "identifier": "3752", "firstName": "Kalyan", "lastName": "Deshpande", "middleInitial": "K.", "electronicAddress": [{ "email": "TEST_Kalyan.Deshpande@USPTO.GOV" }], "prefferedName": "Deshpande, Kalyan K." }, { "identifier": "93588", "firstName": "David", "lastName": "Kohut", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_david.kohut@uspto.gov" }], "prefferedName": "Kohut, David M." }, { "identifier": "10831", "firstName": "Jason", "lastName": "Morgan", "middleInitial": "V.", "electronicAddress": [{ "email": "TEST_jason.morgan@uspto.gov" }], "prefferedName": "Morgan, Jason V." }, { "identifier": "10760", "firstName": "Eric", "lastName": "Chen", "middleInitial": "B.", "electronicAddress": [{ "email": "TEST_eric.chen@uspto.gov" }], "prefferedName": "Chen, Eric B." }, { "identifier": "3750", "firstName": "William", "lastName": "Saindon", "middleInitial": "V.", "electronicAddress": [{ "email": "TEST_William.Saindon@USPTO.GOV" }], "prefferedName": "Saindon, William V." }, { "identifier": "5035", "firstName": "Michael", "lastName": "Zecher", "middleInitial": "R.", "electronicAddress": [{ "email": "TEST_Michael.Zecher@USPTO.GOV" }], "prefferedName": "Zecher, Michael R." }, { "identifier": "10660", "firstName": "Michael", "lastName": "Astorino", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_michael.astorino@uspto.gov" }], "prefferedName": "Astorino, Michael C." }, { "identifier": "10753", "firstName": "Michael", "lastName": "Hoelter", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_michael.hoelter@uspto.gov" }], "prefferedName": "Hoelter, Michael L." }, { "identifier": "3294", "firstName": "James", "lastName": "Calve", "middleInitial": "P.", "electronicAddress": [{ "email": "TEST_James.Calve@uspto.gov" }], "prefferedName": "Calve, James P." }, { "identifier": "3293", "firstName": "Erica", "lastName": "Franklin", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_erica.franklin@USPTO.GOV" }], "prefferedName": "Franklin, Erica A." }, { "identifier": "4789", "firstName": "Deborah", "lastName": "Katz", "electronicAddress": [{ "email": "TEST_Deborah.Katz@USPTO.GOV" }], "prefferedName": "Katz, Deborah" }, { "identifier": "20724", "firstName": "James", "lastName": "Housel", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_james.housel@uspto.gov" }], "prefferedName": "Housel, James C." }, { "identifier": "80427", "firstName": "George", "lastName": "Best", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_George.Best@USPTO.GOV" }], "prefferedName": "Best, George C." }, { "identifier": "5132", "firstName": "Justin", "lastName": "Arbes", "middleInitial": "T.", "electronicAddress": [{ "email": "TEST_Justin.Arbes@USPTO.GOV" }], "prefferedName": "Arbes, Justin T." }, { "identifier": "4027", "firstName": "Grace", "lastName": "Obermann", "middleInitial": "K.", "electronicAddress": [{ "email": "TEST_grace.obermann@uspto.gov" }], "prefferedName": "Obermann, Grace K." }, { "identifier": "5021", "firstName": "Thomas", "lastName": "Giannetti", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_Thomas.Giannetti@USPTO.GOV" }], "prefferedName": "Giannetti, Thomas L." }, { "identifier": "10835", "firstName": "Johnny", "lastName": "Kumar", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_johnny.kumar@uspto.gov" }], "prefferedName": "Kumar, Johnny A." }, { "identifier": "4719", "firstName": "Bryan", "lastName": "Moore", "middleInitial": "F.", "electronicAddress": [{ "email": "TEST_Bryan.Moore@USPTO.GOV" }], "prefferedName": "Moore, Bryan F." }, { "identifier": "5017", "firstName": "Jennifer", "lastName": "Bisk", "middleInitial": "S.", "electronicAddress": [{ "email": "TEST_Jennifer.Bisk@USPTO.GOV" }], "prefferedName": "Bisk, Jennifer S." }, { "identifier": "3286", "firstName": "Donna", "lastName": "Praiss", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_Donna.Praiss@USPTO.GOV" }], "prefferedName": "Praiss, Donna M." }, { "identifier": "3895", "firstName": "Benjamin", "lastName": "Wood", "middleInitial": "D.M.", "electronicAddress": [{ "email": "TEST_Benjamin.Wood@USPTO.GOV" }], "prefferedName": "Wood, Benjamin D.M." }, { "identifier": "3751", "firstName": "Trevor", "lastName": "Jefferson", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_Trevor.Jefferson@USPTO.GOV" }], "prefferedName": "Jefferson, Trevor M." }, { "identifier": "10772", "firstName": "Michael", "lastName": "Strauss", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_michael.strauss@uspto.gov" }], "prefferedName": "Strauss, Michael J." }, { "identifier": "43284", "firstName": "John", "lastName": "Evans", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_john.evans@uspto.gov" }], "prefferedName": "Evans, John A." }, { "identifier": "5028", "firstName": "Brian", "lastName": "McNamara", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_Brian.McNamara@USPTO.GOV" }], "prefferedName": "McNamara, Brian J." }, { "identifier": "10780", "firstName": "Larry", "lastName": "Hume", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_larry.hume@uspto.gov" }], "prefferedName": "Hume, Larry J." }, { "identifier": "10732", "firstName": "Brett", "lastName": "Martin", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_brett.martin@uspto.gov" }], "prefferedName": "Martin, Brett C." }, { "identifier": "20736", "firstName": "Lynne", "lastName": "Browne", "middleInitial": "H.", "electronicAddress": [{ "email": "TEST_lynne.browne@uspto.gov" }], "prefferedName": "Browne, Lynne H." }, { "identifier": "3279", "firstName": "Patrick", "lastName": "Scanlon", "middleInitial": "R.", "electronicAddress": [{ "email": "TEST_Patrick.Scanlon@USPTO.GOV" }], "prefferedName": "Scanlon, Patrick R." }, { "identifier": "80431", "firstName": "Jeremy", "lastName": "Curcuri", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_jeremy.curcuri@uspto.gov" }], "prefferedName": "Curcuri, Jeremy J." }, { "identifier": "5036", "firstName": "Michael", "lastName": "Fitzpatrick", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_Michael.Fitzpatrick@USPTO.GOV" }], "prefferedName": "Fitzpatrick, Michael J." }, { "identifier": "3349", "firstName": "Michelle", "lastName": "Osinski", "middleInitial": "R.", "electronicAddress": [{ "email": "TEST_Michelle.Osinski@USPTO.GOV" }], "prefferedName": "Osinski, Michelle R." }, { "identifier": "9072", "firstName": "Ulrike", "lastName": "Jenks", "middleInitial": "W.", "electronicAddress": [{ "email": "TEST_Ulrike.Jenks@USPTO.GOV" }], "prefferedName": "Jenks, Ulrike W." }, { "identifier": "2105", "firstName": "John", "lastName": "New", "middleInitial": "G.", "electronicAddress": [{ "email": "TEST_John.New@USPTO.GOV" }], "prefferedName": "New, John G." }, { "identifier": "3275", "firstName": "Justin", "lastName": "Busch", "electronicAddress": [{ "email": "TEST_Justin.Busch@USPTO.GOV" }], "prefferedName": "Busch, Justin" }, { "identifier": "80438", "firstName": "Annette", "lastName": "Reimers", "middleInitial": "R.", "electronicAddress": [{ "email": "TEST_annette.reimers@uspto.gov" }], "prefferedName": "Reimers, Annette R." }, { "identifier": "4718", "firstName": "Rama", "lastName": "Elluru", "middleInitial": "G.", "electronicAddress": [{ "email": "TEST_Rama.Elluru@USPTO.GOV" }], "prefferedName": "Elluru, Rama G." }, { "identifier": "3348", "firstName": "Hyun", "lastName": "Jung", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_Hyun.Jung@USPTO.GOV" }], "prefferedName": "Jung, Hyun J." }, { "identifier": "10770", "firstName": "Nina", "lastName": "Medlock", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_nina.medlock@uspto.gov" }], "prefferedName": "Medlock, Nina L." }, { "identifier": "3283", "firstName": "William", "lastName": "Capp", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_William.Capp@USPTO.GOV" }], "prefferedName": "Capp, William A." }, { "identifier": "4039", "firstName": "Barbara", "lastName": "Benoit", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_Barbara.Benoit@USPTO.GOV" }], "prefferedName": "Benoit, Barbara A." }, { "identifier": "3901", "firstName": "Sheridan", "lastName": "Snedden", "middleInitial": "K.", "electronicAddress": [{ "email": "TEST_Sheridan.Snedden@USPTO.GOV" }], "prefferedName": "Snedden, Sheridan K." }, { "identifier": "10825", "firstName": "Jennifer", "lastName": "McKeown", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_jennifer.mckeown@uspto.gov" }], "prefferedName": "McKeown, Jennifer L." }, { "identifier": "4542", "firstName": "James", "lastName": "Arpin", "middleInitial": "B.", "electronicAddress": [{ "email": "TEST_James.Arpin@USPTO.GOV" }], "prefferedName": "Arpin, James B." }, { "identifier": "3344", "firstName": "Scott", "lastName": "Daniels", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_Scott.Daniels@USPTO.GOV" }], "prefferedName": "Daniels, Scott A." }, { "identifier": "3280", "firstName": "Neil", "lastName": "Powell", "middleInitial": "T.", "electronicAddress": [{ "email": "TEST_Neil.Powell@USPTO.GOV" }], "prefferedName": "Powell, Neil T." }, { "identifier": "3898", "firstName": "Barry", "lastName": "Grossman", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_Barry.Grossman@USPTO.GOV" }], "prefferedName": "Grossman, Barry L." }, { "identifier": "66964", "firstName": "Jill", "lastName": "Hill", "middleInitial": "D.", "electronicAddress": [{ "email": "TEST_jill.hill@uspto.gov" }], "prefferedName": "Hill, Jill D." }, { "identifier": "4038", "firstName": "Lynne", "lastName": "Pettigrew", "middleInitial": "E.", "electronicAddress": [{ "email": "TEST_Lynne.Pettigrew@USPTO.GOV" }], "prefferedName": "Pettigrew, Lynne E." }, { "identifier": "3282", "firstName": "Bart", "lastName": "Gerstenblith", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_Bart.Gerstenblith@USPTO.GOV" }], "prefferedName": "Gerstenblith, Bart A." }, { "identifier": "3896", "firstName": "Mitchell", "lastName": "Weatherly", "middleInitial": "G.", "electronicAddress": [{ "email": "TEST_Mitchell.Weatherly@USPTO.GOV" }], "prefferedName": "Weatherly, Mitchell G." }, { "identifier": "3747", "firstName": "David", "lastName": "McKone", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_David.McKone@USPTO.GOV" }], "prefferedName": "McKone, David C." }, { "identifier": "3342", "firstName": "Jeremy", "lastName": "Plenzler", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_Jeremy.Plenzler@USPTO.GOV" }], "prefferedName": "Plenzler, Jeremy M." }, { "identifier": "4499", "firstName": "Christopher", "lastName": "Crumbley", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_Christopher.Crumbley@USPTO.GOV" }], "prefferedName": "Crumbley, Christopher L." }, { "identifier": "3749", "firstName": "James", "lastName": "Tartal", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_James.Tartal@USPTO.GOV" }], "prefferedName": "Tartal, James A." }, { "identifier": "3345", "firstName": "Phillip", "lastName": "Hoffmann", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_Philip.Hoffmann@USPTO.GOV" }], "prefferedName": "Hoffmann, Phillip J." }, { "identifier": "4541", "firstName": "Georgianna", "lastName": "Braden", "middleInitial": "W.", "electronicAddress": [{ "email": "TEST_Georgianna.Braden@USPTO.GOV" }], "prefferedName": "Braden, Georgianna W." }, { "identifier": "4415", "firstName": "Miriam", "lastName": "Quinn", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_Miriam.Quinn@USPTO.GOV" }], "prefferedName": "Quinn, Miriam L." }, { "identifier": "3937", "firstName": "Barbara", "lastName": "Parvis", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_Barbara.Parvis@USPTO.GOV" }], "prefferedName": "Parvis, Barbara A." }, { "identifier": "3900", "firstName": "Carl", "lastName": "Defranco", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_Carl.Defranco@USPTO.GOV" }], "prefferedName": "Defranco, Carl M." }, { "identifier": "3753", "firstName": "Gregg", "lastName": "Anderson", "middleInitial": "I.", "electronicAddress": [{ "email": "TEST_Gregg.Anderson@USPTO.GOV" }], "prefferedName": "Anderson, Gregg I." }, { "identifier": "80428", "firstName": "Gene", "lastName": "Branch", "middleInitial": "E.", "electronicAddress": [{ "email": "TEST_Gene.Branch@USPTO.GOV" }], "prefferedName": "Branch, Gene E." }, { "identifier": "3936", "firstName": "Patrick", "lastName": "Boucher", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_Patrick.Boucher@USPTO.GOV" }], "prefferedName": "Boucher, Patrick M." }, { "identifier": "3748", "firstName": "Stacey", "lastName": "White", "middleInitial": "G.", "electronicAddress": [{ "email": "TEST_Stacey.White@USPTO.GOV" }], "prefferedName": "White, Stacey G." }, { "identifier": "4069", "firstName": "Catherine", "lastName": "Shiang", "electronicAddress": [{ "email": "TEST_Catherine.Shiang@USPTO.GOV" }], "prefferedName": "Shiang, Catherine" }, { "identifier": "3292", "firstName": "Susan", "lastName": "Mitchell", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_Susan.Mitchell@USPTO.GOV" }], "prefferedName": "Mitchell, Susan L." }, { "identifier": "3350", "firstName": "George", "lastName": "Hoskins", "middleInitial": "R.", "electronicAddress": [{ "email": "TEST_George.Hoskins@USPTO.GOV" }], "prefferedName": "Hoskins, George R." }, { "identifier": "3287", "firstName": "Jo-Anne", "lastName": "Kokoski", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_Jo-Anne.Kokoski@USPTO.GOV" }], "prefferedName": "Kokoski, Jo-Anne M." }, { "identifier": "3288", "firstName": "Kristina", "lastName": "Kalan", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_Kristina.Kalan@USPTO.GOV" }], "prefferedName": "Kalan, Kristina M." }, { "identifier": "10739", "firstName": "N.", "lastName": "Wilson", "middleInitial": "Whitney", "electronicAddress": [{ "email": "TEST_whitney.wilson@uspto.gov" }], "prefferedName": "Wilson, N. Whitney" }, { "identifier": "3341", "firstName": "Zhenyu", "lastName": "Yang", "electronicAddress": [{ "email": "TEST_Zhenyu.Yang@USPTO.GOV" }], "prefferedName": "Yang, Zhenyu" }, { "identifier": "3351", "firstName": "Jon", "lastName": "Tornquist", "middleInitial": "B.", "electronicAddress": [{ "email": "TEST_Jon.Tornquist@USPTO.GOV" }], "prefferedName": "Tornquist, Jon B." }, { "identifier": "3336", "firstName": "Jennifer", "lastName": "Chagnon", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_Jennifer.Chagnon@USPTO.GOV" }], "prefferedName": "Chagnon, Jennifer M." }, { "identifier": "3281", "firstName": "Frances", "lastName": "Ippolito", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_Frances.Ippolito@USPTO.GOV" }], "prefferedName": "Ippolito, Frances L." }, { "identifier": "3337", "firstName": "Kerry", "lastName": "Begley", "electronicAddress": [{ "email": "TEST_Kerry.Begley@USPTO.GOV" }], "prefferedName": "Begley, Kerry" }, { "identifier": "3290", "firstName": "Tina", "lastName": "Hulse", "middleInitial": "E.", "electronicAddress": [{ "email": "TEST_Tina.Hulse@USPTO.GOV" }], "prefferedName": "Hulse, Tina E." }, { "identifier": "10703", "firstName": "Brandon", "lastName": "Warner", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_Brandon.Warner@USPTO.GOV" }], "prefferedName": "Warner, Brandon J." }, { "identifier": "1805", "firstName": "Linzy", "lastName": "McCartney", "middleInitial": "T.", "electronicAddress": [{ "email": "TEST_Linzy.McCartney@USPTO.GOV" }], "prefferedName": "McCartney, Linzy T." }, { "identifier": "2409", "firstName": "Christopher", "lastName": "Kaiser", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_Christopher.Kaiser@USPTO.GOV" }], "prefferedName": "Kaiser, Christopher M." }, { "identifier": "2410", "firstName": "Kevin", "lastName": "Cherry", "middleInitial": "W.", "electronicAddress": [{ "email": "TEST_Kevin.Cherry@USPTO.GOV" }], "prefferedName": "Cherry, Kevin W." }, { "identifier": "2408", "firstName": "Robert", "lastName": "Weinschenk", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_Robert.Weinschenk@USPTO.GOV" }], "prefferedName": "Weinschenk, Robert J." }, { "identifier": "2411", "firstName": "Jungkeun", "lastName": "Lee", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_Jungkeun.Lee@USPTO.GOV" }], "prefferedName": "Lee, Jungkeun J." }, { "identifier": "10752", "firstName": "Lisa", "lastName": "Guijt", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_lisa.guijt@uspto.gov" }], "prefferedName": "Guijt, Lisa M." }, { "identifier": "1750", "firstName": "Christopher", "lastName": "Paulraj", "middleInitial": "G.", "electronicAddress": [{ "email": "TEST_Christopher.Paulraj@USPTO.GOV" }], "prefferedName": "Paulraj, Christopher G." }, { "identifier": "1807", "firstName": "Minn", "lastName": "Chung", "electronicAddress": [{ "email": "TEST_Minn.Chung@USPTO.GOV" }], "prefferedName": "Chung, Minn" }, { "identifier": "9068", "firstName": "John", "lastName": "Pinkerton", "middleInitial": "P.", "electronicAddress": [{ "email": "TEST_John.Pinkerton@USPTO.GOV" }], "prefferedName": "Pinkerton, John P." }, { "identifier": "1809", "firstName": "Charles", "lastName": "Boudreau", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_Charles.Boudreau@USPTO.GOV" }], "prefferedName": "Boudreau, Charles J." }, { "identifier": "80433", "firstName": "Wesley", "lastName": "Derrick", "middleInitial": "B.", "electronicAddress": [{ "email": "TEST_wesley.derrick@uspto.gov" }], "prefferedName": "Derrick, Wesley B." }, { "identifier": "1752", "firstName": "Jeffrey", "lastName": "Abraham", "middleInitial": "W.", "electronicAddress": [{ "email": "TEST_Jeffrey.Abraham@USPTO.GOV" }], "prefferedName": "Abraham, Jeffrey W." }, { "identifier": "1808", "firstName": "Jason", "lastName": "Chung", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_Jason.Chung@USPTO.GOV" }], "prefferedName": "Chung, Jason J." }, { "identifier": "1803", "firstName": "Beth", "lastName": "Shaw", "middleInitial": "Z.", "electronicAddress": [{ "email": "TEST_Beth.Shaw@USPTO.GOV" }], "prefferedName": "Shaw, Beth Z." }, { "identifier": "1751", "firstName": "Timothy", "lastName": "Goodson", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_Timothy.Goodson@USPTO.GOV" }], "prefferedName": "Goodson, Timothy J." }, { "identifier": "1801", "firstName": "Michelle", "lastName": "Wormmeester", "middleInitial": "N.", "electronicAddress": [{ "email": "TEST_Michelle.Wormmeester@USPTO.GOV" }], "prefferedName": "Wormmeester, Michelle N." }, { "identifier": "1748", "firstName": "James", "lastName": "Worth", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_James.Worth@USPTO.GOV" }], "prefferedName": "Worth, James A." }, { "identifier": "8707", "firstName": "Terrence", "lastName": "McMillin", "middleInitial": "W.", "electronicAddress": [{ "email": "TEST_Terrence.McMillin@USPTO.GOV" }], "prefferedName": "McMillin, Terrence W." }, { "identifier": "9071", "firstName": "Jon", "lastName": "Jurgovan", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_Jon.Jurgovan@USPTO.GOV" }], "prefferedName": "Jurgovan, Jon M." }, { "identifier": "1749", "firstName": "Robert", "lastName": "Pollock", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_Robert.Pollock@USPTO.GOV" }], "prefferedName": "Pollock, Robert A." }, { "identifier": "529", "firstName": "John", "lastName": "Horvath", "middleInitial": "F.", "electronicAddress": [{ "email": "TEST_John.Horvath@USPTO.GOV" }], "prefferedName": "Horvath, John F." }, { "identifier": "530", "firstName": "Michael", "lastName": "Woods", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_Michael.Woods@USPTO.GOV" }], "prefferedName": "Woods, Michael L." }, { "identifier": "1999", "firstName": "Kimberly", "lastName": "McGraw", "electronicAddress": [{ "email": "TEST_Kimberly.McGraw@USPTO.GOV" }], "prefferedName": "McGraw, Kimberly" }, { "identifier": "534", "firstName": "Robert", "lastName": "Kinder", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_Robert.Kinder@USPTO.GOV" }], "prefferedName": "Kinder, Robert L." }, { "identifier": "531", "firstName": "James", "lastName": "Mayberry", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_James.Mayberry@USPTO.GOV" }], "prefferedName": "Mayberry, James J." }, { "identifier": "69011", "firstName": "Nathan", "lastName": "Engels", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_nathan.engels@uspto.gov" }], "prefferedName": "Engels, Nathan A." }, { "identifier": "1088", "firstName": "Daniel", "lastName": "Galligan", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_Daniel.Galligan@USPTO.GOV" }], "prefferedName": "Galligan, Daniel J." }, { "identifier": "9067", "firstName": "Carl", "lastName": "Silverman", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_Carl.Silverman@USPTO.GOV" }], "prefferedName": "Silverman, Carl L." }, { "identifier": "10659", "firstName": "Cynthia", "lastName": "Murphy", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_cynthia.murphy@uspto.gov" }], "prefferedName": "Murphy, Cynthia L." }, { "identifier": "10666", "firstName": "Bruce", "lastName": "Wieder", "middleInitial": "T.", "electronicAddress": [{ "email": "TEST_bruce.wieder@uspto.gov" }], "prefferedName": "Wieder, Bruce T." }, { "identifier": "1085", "firstName": "Elizabeth", "lastName": "Roesel", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_Elizabeth.Roesel@USPTO.GOV" }], "prefferedName": "Roesel, Elizabeth M." }, { "identifier": "1087", "firstName": "Scott", "lastName": "Moore", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_Scott.Moore@USPTO.GOV" }], "prefferedName": "Moore, Scott C." }, { "identifier": "118710", "firstName": "Kenneth", "lastName": "Schopfer", "middleInitial": "G.", "electronicAddress": [{ "email": "TEST_kenneth.schopfer@uspto.gov" }], "prefferedName": "Schopfer, Kenneth G." }, { "identifier": "10662", "firstName": "Bradley", "lastName": "Bayat", "middleInitial": "B.", "electronicAddress": [{ "email": "swetha.rama@uspto.gov" }], "prefferedName": "Bayat, Bradley B." }, { "identifier": "533", "firstName": "Christa", "lastName": "Zado", "middleInitial": "P.", "electronicAddress": [{ "email": "TEST_Christa.Zado@USPTO.GOV" }], "prefferedName": "Zado, Christa P." }, { "identifier": "526", "firstName": "Elizabeth", "lastName": "LaVier", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_Elizabeth.LaVier@USPTO.GOV" }], "prefferedName": "LaVier, Elizabeth A." }, { "identifier": "69005", "firstName": "Norman", "lastName": "Beamer", "middleInitial": "H.", "electronicAddress": [{ "email": "TEST_norman.beamer@uspto.gov" }], "prefferedName": "Beamer, Norman H." }, { "identifier": "9077", "firstName": "Kevin", "lastName": "Trock", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_Kevin.Trock@USPTO.GOV" }], "prefferedName": "Trock, Kevin C." }, { "identifier": "10730", "firstName": "Lee", "lastName": "Stepina", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_lee.stepina@uspto.gov" }], "prefferedName": "Stepina, Lee L." }, { "identifier": "614", "firstName": "Michelle", "lastName": "Ankenbrand", "middleInitial": "N.", "electronicAddress": [{ "email": "TEST_Michelle.Ankenbrand@USPTO.GOV" }], "prefferedName": "Ankenbrand, Michelle N." }, { "identifier": "10736", "firstName": "Tara", "lastName": "Hutchings", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_tara.hutchings@uspto.gov" }], "prefferedName": "Hutchings, Tara L." }, { "identifier": "536", "firstName": "John", "lastName": "Hudalla", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_John.Hudalla@USPTO.GOV" }], "prefferedName": "Hudalla, John A." }, { "identifier": "10781", "firstName": "Adam", "lastName": "Pyonin", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_adam.pyonin@uspto.gov" }], "prefferedName": "Pyonin, Adam J." }, { "identifier": "64305", "firstName": "Eric", "lastName": "Jeschke", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_eric.jeschke@uspto.gov" }], "prefferedName": "Jeschke, Eric C." }, { "identifier": "528", "firstName": "Amanda", "lastName": "Wieker", "middleInitial": "F.", "electronicAddress": [{ "email": "TEST_Amanda.Wieker@USPTO.GOV" }], "prefferedName": "Wieker, Amanda F." }, { "identifier": "535", "firstName": "Sheila", "lastName": "McShane", "middleInitial": "F.", "electronicAddress": [{ "email": "TEST_Sheila.McShane@USPTO.GOV" }], "prefferedName": "McShane, Sheila F." }, { "identifier": "9076", "firstName": "Melissa", "lastName": "Haapala", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_Melissa.Haapala@USPTO.GOV" }], "prefferedName": "Haapala, Melissa A." }, { "identifier": "10827", "firstName": "James", "lastName": "Dejmek", "middleInitial": "W.", "electronicAddress": [{ "email": "TEST_james.dejmek@uspto.gov" }], "prefferedName": "Dejmek, James W." }, { "identifier": "7887", "firstName": "Jessica", "lastName": "Kaiser", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_Jessica.Kaiser@USPTO.GOV" }], "prefferedName": "Kaiser, Jessica C." }, { "identifier": "6314", "firstName": "Garth", "lastName": "Baer", "middleInitial": "D.", "electronicAddress": [{ "email": "TEST_Garth.Baer@USPTO.GOV" }], "prefferedName": "Baer, Garth D." }, { "identifier": "9307", "firstName": "Nabeel", "lastName": "Khan", "middleInitial": "U.", "electronicAddress": [{ "email": "TEST_Nabeel.Khan@USPTO.GOV" }], "prefferedName": "Khan, Nabeel U." }, { "identifier": "6483", "firstName": "Richard", "lastName": "Marschall", "middleInitial": "H.", "electronicAddress": [{ "email": "TEST_Richard.Marschall@USPTO.GOV" }], "prefferedName": "Marschall, Richard H." }, { "identifier": "8346", "firstName": "Monica", "lastName": "Ullagaddi", "middleInitial": "S.", "electronicAddress": [{ "email": "TEST_Monica.Ullagaddi@USPTO.GOV" }], "prefferedName": "Ullagaddi, Monica S." }, { "identifier": "9074", "firstName": "Amber", "lastName": "Hagy", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_Amber.Hagy@USPTO.GOV" }], "prefferedName": "Hagy, Amber L." }, { "identifier": "10727", "firstName": "Amee", "lastName": "Shah", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_amee.shah@uspto.gov" }], "prefferedName": "Shah, Amee A." }, { "identifier": "104170", "firstName": "Kara", "lastName": "Szpondowski", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_kara.szpondowski@uspto.gov" }], "prefferedName": "Szpondowski, Kara L." }, { "identifier": "69006", "firstName": "Christopher", "lastName": "Ogden", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_christopher.ogden@uspto.gov" }], "prefferedName": "Ogden, Christopher L." }, { "identifier": "69007", "firstName": "Sharon", "lastName": "Fenick", "electronicAddress": [{ "email": "TEST_sharon.fenick@uspto.gov" }], "prefferedName": "Fenick, Sharon" }, { "identifier": "80440", "firstName": "Christopher", "lastName": "Kennedy", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_christopher.kennedy@uspto.gov" }], "prefferedName": "Kennedy, Christopher C." }, { "identifier": "69004", "firstName": "Richard", "lastName": "Smith", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_richard.smith1@uspto.gov" }], "prefferedName": "Smith, Richard J." }, { "identifier": "69804", "firstName": "Julia", "lastName": "Heaney", "electronicAddress": [{ "email": "TEST_julia.heaney@uspto.gov" }], "prefferedName": "Heaney, Julia" }, { "identifier": "41449", "firstName": "Scott", "lastName": "Howard", "middleInitial": "B.", "electronicAddress": [{ "email": "TEST_scott.howard@uspto.gov" }], "prefferedName": "Howard, Scott B." }, { "identifier": "69008", "firstName": "John", "lastName": "Hamann", "middleInitial": "D.", "electronicAddress": [{ "email": "TEST_john.hamann@uspto.gov" }], "prefferedName": "Hamann, John D." }, { "identifier": "10745", "firstName": "Tawen", "lastName": "Chang", "electronicAddress": [{ "email": "TEST_tawen.chang@uspto.gov" }], "prefferedName": "Chang, Tawen" }, { "identifier": "17670", "firstName": "Jason", "lastName": "Melvin", "middleInitial": "W.", "electronicAddress": [{ "email": "TEST_Jason.Melvin@USPTO.GOV" }], "prefferedName": "Melvin, Jason W." }, { "identifier": "69009", "firstName": "Frederick", "lastName": "Laney", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_frederick.laney@uspto.gov" }], "prefferedName": "Laney, Frederick C." }, { "identifier": "5034", "firstName": "Matthew", "lastName": "Meyers", "middleInitial": "S.", "electronicAddress": [{ "email": "TEST_Matthew.Meyers@USPTO.GOV" }], "prefferedName": "Meyers, Matthew S." }, { "identifier": "64544", "firstName": "John", "lastName": "Kenny", "middleInitial": "R.", "electronicAddress": [{ "email": "TEST_john.kenny@uspto.gov" }], "prefferedName": "Kenny, John R." }, { "identifier": "10734", "firstName": "Joyce", "lastName": "Craig", "electronicAddress": [{ "email": "TEST_joyce.craig@uspto.gov" }], "prefferedName": "Craig, Joyce" }, { "identifier": "80439", "firstName": "Monte", "lastName": "Squire", "middleInitial": "T.", "electronicAddress": [{ "email": "TEST_monte.squire@uspto.gov" }], "prefferedName": "Squire, Monte T." }, { "identifier": "67926", "firstName": "Matthew", "lastName": "McNeill", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_matthew.mcneill@uspto.gov" }], "prefferedName": "McNeill, Matthew J." }, { "identifier": "7686", "firstName": "Stacy", "lastName": "Margolies", "middleInitial": "B.", "electronicAddress": [{ "email": "TEST_stacy.margolies@uspto.gov" }], "prefferedName": "Margolies, Stacy B." }, { "identifier": "21446", "firstName": "Avelyn", "lastName": "Ross", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_avelyn.ross@uspto.gov" }], "prefferedName": "Ross, Avelyn M." }, { "identifier": "21447", "firstName": "Aaron", "lastName": "Moore", "middleInitial": "W.", "electronicAddress": [{ "email": "TEST_aaron.moore@uspto.gov" }], "prefferedName": "Moore, Aaron W." }, { "identifier": "10738", "firstName": "Jeffrey", "lastName": "Snay", "middleInitial": "R.", "electronicAddress": [{ "email": "TEST_jeffrey.snay@uspto.gov" }], "prefferedName": "Snay, Jeffrey R." }, { "identifier": "21450", "firstName": "Paul", "lastName": "Korniczky", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_paul.korniczky@uspto.gov" }], "prefferedName": "Korniczky, Paul J." }, { "identifier": "21451", "firstName": "Arthur", "lastName": "Peslak", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_arthur.peslak@uspto.gov" }], "prefferedName": "Peslak, Arthur M." }, { "identifier": "21453", "firstName": "Robert", "lastName": "Silverman", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_robert.silverman@uspto.gov" }], "prefferedName": "Silverman, Robert J." }, { "identifier": "80426", "firstName": "Scott", "lastName": "Bain", "middleInitial": "E.", "electronicAddress": [{ "email": "TEST_scott.bain@uspto.gov" }], "prefferedName": "Bain, Scott E." }, { "identifier": "21452", "firstName": "Brian", "lastName": "Range", "middleInitial": "D.", "electronicAddress": [{ "email": "TEST_brian.range@uspto.gov" }], "prefferedName": "Range, Brian D." }, { "identifier": "21448", "firstName": "Jennifer", "lastName": "Gupta", "electronicAddress": [{ "email": "TEST_jennifer.gupta@uspto.gov" }], "prefferedName": "Gupta, Jennifer" }, { "identifier": "21458", "firstName": "John", "lastName": "Schneider", "middleInitial": "E.", "electronicAddress": [{ "email": "TEST_john.schneider@uspto.gov" }], "prefferedName": "Schneider, John E." }, { "identifier": "21456", "firstName": "Debra", "lastName": "Dennett", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_debra.dennett@uspto.gov" }], "prefferedName": "Dennett, Debra L." }, { "identifier": "21455", "firstName": "Ryan", "lastName": "Flax", "middleInitial": "H.", "electronicAddress": [{ "email": "TEST_ryan.flax@uspto.gov" }], "prefferedName": "Flax, Ryan H." }, { "identifier": "21457", "firstName": "Lilan", "lastName": "Ren", "electronicAddress": [{ "email": "TEST_lilan.ren@uspto.gov" }], "prefferedName": "Ren, Lilan" }, { "identifier": "21454", "firstName": "Timothy", "lastName": "Majors", "middleInitial": "G.", "electronicAddress": [{ "email": "TEST_timothy.majors@uspto.gov" }], "prefferedName": "Majors, Timothy G." }, { "identifier": "80437", "firstName": "Sean", "lastName": "O'Hanlon", "middleInitial": "P.", "electronicAddress": [{ "email": "TEST_sean.ohanlon@uspto.gov" }], "prefferedName": "O'Hanlon, Sean P." }, { "identifier": "21460", "firstName": "David", "lastName": "Cutitta II", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_David.Cutitta@USPTO.GOV" }], "prefferedName": "Cutitta II, David J." }, { "identifier": "21459", "firstName": "Michael", "lastName": "Engle", "middleInitial": "J.", "electronicAddress": [{ "email": "TEST_michael.engle@uspto.gov" }], "prefferedName": "Engle, Michael J." }, { "identifier": "20723", "firstName": "Kristi", "lastName": "Sawert", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_kristi.sawert@uspto.gov" }], "prefferedName": "Sawert, Kristi L." }, { "identifier": "80441", "firstName": "Rachel", "lastName": "Townsend", "middleInitial": "H.", "electronicAddress": [{ "email": "TEST_rachel.townsend@uspto.gov" }], "prefferedName": "Townsend, Rachel H." }, { "identifier": "80435", "firstName": "Michael", "lastName": "McManus", "middleInitial": "G.", "electronicAddress": [{ "email": "TEST_michael.mcmanus@uspto.gov" }], "prefferedName": "McManus, Michael G." }, { "identifier": "80436", "firstName": "Devon", "lastName": "Newman", "electronicAddress": [{ "email": "TEST_devon.zastrownewman@uspto.gov" }], "prefferedName": "Newman, Devon" }, { "identifier": "80442", "firstName": "Brent", "lastName": "Dougal", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_brent.dougal@uspto.gov" }], "prefferedName": "Dougal, Brent M." }, { "identifier": "104169", "firstName": "Steven", "lastName": "Amundson", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_steven.amundson@uspto.gov" }], "prefferedName": "Amundson, Steven M." }, { "identifier": "80429", "firstName": "David", "lastName": "Cotta", "middleInitial": "D.", "electronicAddress": [{ "email": "TEST_david.cotta@uspto.gov" }], "prefferedName": "Cotta, David D." }, { "identifier": "10763", "firstName": "Phillip", "lastName": "Bennett", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_phillip.bennett@uspto.gov" }], "prefferedName": "Bennett, Phillip A." }, { "identifier": "10741", "firstName": "Merrell", "lastName": "Cashion Jr.", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_merrell.cashion@uspto.gov" }], "prefferedName": "Cashion Jr., Merrell C." }, { "identifier": "65564", "firstName": "Jason", "lastName": "Repko", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_jason.repko@uspto.gov" }], "prefferedName": "Repko, Jason M." }, { "identifier": "738", "firstName": "Alyssa", "lastName": "Finamore", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_Alyssa.Finamore@USPTO.GOV" }], "prefferedName": "Finamore, Alyssa A." }, { "identifier": "10656", "firstName": "Jane", "lastName": "Inglese", "middleInitial": "E.", "electronicAddress": [{ "email": "TEST_jane.inglese@uspto.gov" }], "prefferedName": "Inglese, Jane E." }, { "identifier": "120571", "firstName": "Michael", "lastName": "Cygan", "middleInitial": "T.", "electronicAddress": [{ "email": "TEST_Michael.Cygan@uspto.gov" }], "prefferedName": "Cygan, Michael T." }, { "identifier": "120570", "firstName": "Stephen", "lastName": "Belisle", "middleInitial": "E.", "electronicAddress": [{ "email": "TEST_Stephen.Belisle@uspto.gov" }], "prefferedName": "Belisle, Stephen E." }, { "identifier": "120533", "firstName": "Juliet Mitchell", "lastName": "Dirba", "electronicAddress": [{ "email": "TEST_Juliet.Dirba@USPTO.GOV" }], "prefferedName": "Dirba, Juliet Mitchell" }, { "identifier": "120572", "firstName": "Scott", "lastName": "Raevsky", "electronicAddress": [{ "email": "TEST_Scott.Raevsky@USPTO.GOV" }], "prefferedName": "Raevsky, Scott" }, { "identifier": "120575", "firstName": "Russell", "lastName": "Cass", "middleInitial": "E.", "electronicAddress": [{ "email": "TEST_Russell.Cass@USPTO.GOV" }], "prefferedName": "Cass, Russell E." }, { "identifier": "120574", "firstName": "Cynthia", "lastName": "Hardman", "middleInitial": "M.", "electronicAddress": [{ "email": "TEST_Cynthia.Hardman@USPTO.GOV" }], "prefferedName": "Hardman, Cynthia M." }, { "identifier": "120576", "firstName": "Michael", "lastName": "Valek", "middleInitial": "A.", "electronicAddress": [{ "email": "TEST_Michael.Valek@USPTO.GOV" }], "prefferedName": "Valek, Michael A." }, { "identifier": "120573", "firstName": "Jamie", "lastName": "Wisz", "middleInitial": "T.", "electronicAddress": [{ "email": "TEST_Jamie.Wisz@USPTO.GOV" }], "prefferedName": "Wisz, Jamie T." }, { "identifier": "121654", "firstName": "Iftikhar", "lastName": "Ahmed", "electronicAddress": [{ "email": "TEST_iftikhar.ahmed@uspto.gov" }], "prefferedName": "Ahmed, Iftikhar" }, { "identifier": "78106", "firstName": "Mindy", "lastName": "Brown", "middleInitial": "G", "electronicAddress": [{ "email": "TEST_mindy.brown@uspto.gov" }], "prefferedName": "Brown, Mindy G" }, { "identifier": "141150", "firstName": "Danielle", "lastName": "Zapata", "electronicAddress": [{ "email": "TEST_danielle.zapata@uspto.gov" }], "prefferedName": "Zapata, Danielle" }, { "identifier": "149038", "firstName": "Derek", "lastName": "Taylor", "electronicAddress": [{ "email": "Derek.Taylor@USPTO.GOV" }], "prefferedName": "Taylor, Derek" }, { "identifier": "149039", "firstName": "Joy", "lastName": "Weber", "electronicAddress": [{ "email": "Joy.Weber@USPTO.GOV" }], "prefferedName": "Weber, Joy" }, { "identifier": "149040", "firstName": "MD", "lastName": "Parvesh", "electronicAddress": [{ "email": "MD.Parvesh@uspto.gov" }], "prefferedName": "Parvesh, MD" }, { "identifier": "10699", "firstName": "Rachel", "lastName": "Chu", "middleInitial": "H", "electronicAddress": [{ "email": "TEST_Rachel.Chu@USPTO.GOV" }], "prefferedName": "Chu, Rachel H" }, { "identifier": "10682", "firstName": "Archana", "lastName": "Sankineni", "electronicAddress": [{ "email": "Arul.Savariraj@USPTO.GOV" }], "prefferedName": "Sankineni, Archana" }, { "identifier": "10797", "firstName": "Brodie", "lastName": "Follman", "electronicAddress": [{ "email": "TEST_michael.fuelling@uspto.gov" }], "prefferedName": "Follman, Brodie" }, { "identifier": "5768", "firstName": "Parin", "lastName": "Gandhi", "electronicAddress": [{ "email": "Arul.Savariraj@USPTO.GOV" }], "prefferedName": "Gandhi, Parin" }, { "identifier": "8083", "firstName": "Judge1", "lastName": "Ptab", "electronicAddress": [{ "email": "evlptabjudge1@gmail.com" }], "prefferedName": "Ptab, Judge1" }, { "identifier": "85", "firstName": "Judge2", "lastName": "Ptab", "electronicAddress": [{ "email": "evlptabjudge2@gmail.com" }], "prefferedName": "Ptab, Judge2" }, { "identifier": "10768", "firstName": "Parin", "lastName": "Gandhiji", "middleInitial": "G", "electronicAddress": [{ "email": "Arul.Savariraj@USPTO.GOV" }], "prefferedName": "Gandhiji, Parin G" }, { "identifier": "10718", "firstName": "Sharla", "lastName": "Ramnarine", "electronicAddress": [{ "email": "Arul.Savariraj@USPTO.GOV" }], "prefferedName": "Ramnarine, Sharla" }, { "identifier": "10717", "firstName": "Rey", "lastName": "De Jesus", "electronicAddress": [{ "email": "Arul.Savariraj@USPTO.GOV" }], "prefferedName": "De Jesus, Rey" }, { "identifier": "10715", "firstName": "Krishna", "lastName": "Murali", "electronicAddress": [{ "email": "Arul.Savariraj@USPTO.GOV" }], "prefferedName": "Murali, Krishna" }, { "identifier": "10714", "firstName": "Jainti", "lastName": "Pramanik", "electronicAddress": [{ "email": "Arul.Savariraj@USPTO.GOV" }], "prefferedName": "Pramanik, Jainti" }, { "identifier": "149041", "firstName": "Sreeni", "lastName": "Ekambarapu", "electronicAddress": [{ "email": "Sreeni.Ekambarapu@USPTO.GOV" }], "prefferedName": "Ekambarapu, Sreeni" }, { "identifier": "88888", "firstName": "Chiranjeevi", "lastName": "Danda", "middleInitial": "A", "electronicAddress": [{ "email": "TEST_chiranjeevi.danda@uspto.gov" }], "prefferedName": "Danda, Chiranjeevi A" }, { "identifier": "10653", "firstName": "Sasidhar", "lastName": "Koduru", "electronicAddress": [{ "email": "Arul.Savariraj@USPTO.GOV" }], "prefferedName": "Koduru, Sasidhar" }], "ptabReadOnlyUser": true, "proceedingSupplementaryIdList": null, "caseNo": null, "caseType": null };


  const paneledJudgesResponseMock = { "supplementaryIdType": "PATENT", "listofJudges": [{ "activeIndicator": "Y", "identifier": "5017", "firstName": "Jennifer", "lastName": "Bisk", "activeJudgeIndicator": "N", "middleInitial": "S.", "electronicAddress": [{ "email": "TEST_Jennifer.Bisk@USPTO.GOV" }], "prefferedName": "Bisk, Jennifer S.", "audit": { "createUserIdentifier": "sbartlett", "lastModifiedUserIdentifier": "sbartlett", "lastModifiedTimestamp": 1615407337000, "createTimestamp": 1615407337000 }, "rank": "1", "lifeCycle": { "beginEffectiveDate": 1615352400000 } }, { "activeIndicator": "Y", "identifier": "4718", "firstName": "Rama", "lastName": "Elluru", "activeJudgeIndicator": "Y", "middleInitial": "G.", "electronicAddress": [{ "email": "TEST_Rama.Elluru@USPTO.GOV" }], "prefferedName": "Elluru, Rama G.", "audit": { "createUserIdentifier": "sbartlett", "lastModifiedUserIdentifier": "sbartlett", "lastModifiedTimestamp": 1615407337000, "createTimestamp": 1615407337000 }, "rank": "2", "lifeCycle": { "beginEffectiveDate": 1615352400000 } }, { "activeIndicator": "Y", "identifier": "529", "firstName": "John", "lastName": "Horvath", "activeJudgeIndicator": "Y", "middleInitial": "F.", "electronicAddress": [{ "email": "TEST_John.Horvath@USPTO.GOV" }], "prefferedName": "Horvath, John F.", "audit": { "createUserIdentifier": "sbartlett", "lastModifiedUserIdentifier": "sbartlett", "lastModifiedTimestamp": 1615407337000, "createTimestamp": 1615407337000 }, "rank": "3", "lifeCycle": { "beginEffectiveDate": 1615352400000 } }], "ptabReadOnlyUser": true, "proceedingSupplementaryIdList": ["9521269"], "caseNo": "IPR2021-00421", "caseType": "TRIALS" };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, OrderModule],
      declarations: [PanelingComponent],
      providers: [
        DatePipe,
        provideMockStore({
          selectors: [
            { selector: CaseViewerSelectors.caseInfoData, value: { proceedingNo: '37553565' } },
            {selector: CaseViewerSelectors.userInfoData,value:{caseDetailsData: []}}
          ]
        }),
      {
        provide: BsModalRef,
        useValue: {}
      },
      {
        provide: BsModalService,
        useValue: {}
        },
        {
          provide: ToastrService,
          useValue: toastrService
        }]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PanelingComponent);
    jpViewService = TestBed.inject(JpViewService);
    trialsService = TestBed.inject(TrialsService);
    modalService = TestBed.inject(BsModalService);
    modalRef = TestBed.inject(BsModalRef);
    component = fixture.componentInstance;
    modalService.hide = (): BsModalRef => {
      return ({ id: null, hide: null, setClass: null, onHide: null, onHidden: null});
    };
    spyOn(trialsService, "assignPanelToCase").and.returnValue(of(assignPanelSuccessMock));
    spyOn(modalService, 'hide').and.returnValue();
    component.paneling = panelingMock;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should get case info', () => {
    let caseInfoResponseMock = {
      serialNumber: ["12345678"],
      appealNumber: ["12345678"]
    };

    spyOn(jpViewService, 'getDocuments').and.returnValue(of(caseInfoResponseMock));
    spyOn(component, 'getCaseHeaderInfo');
    component.getCaseInfo();
    expect(component.caseInfo.serialNo).toEqual(caseInfoResponseMock.serialNumber[0]);
    expect(component.caseInfo.proceedingNo).toEqual(caseInfoResponseMock.appealNumber[0]);
    expect(component.getCaseHeaderInfo).toHaveBeenCalled();
  });


  it('should get case header info', () => {
    spyOn(trialsService, 'getHeaderInfo').and.returnValue(of(headerInfoResponseMock));
    component.getCaseHeaderInfo(caseInfoMock);
    expect(component.headerInfo).toEqual(headerInfoResponseMock);
  });


  it('should get judge list', () => {
    spyOn(trialsService, 'getJudgeList').and.returnValue(of(judgeListMock));
    spyOn(component, 'removePaneledJudgesFromList');
    component.getJudgeList();
    expect(component.judgeList).not.toBeNull();
    expect(component.removePaneledJudgesFromList).toHaveBeenCalled();
    expect(component.fullJudgeList).toEqual(component.judgeList);

  });


  it('should get discipline list', () => {
    spyOn(trialsService, 'getDisciplineList').and.returnValue(of(disciplineListMock));
    component.getDisciplineList();
    expect(component.disciplineList[0].id).toBe('all');
    expect(component.disciplineList[0].text).toBe('Choose a discipline...');
    expect(component.selectedDiscipline).toBe('all');
  });


  it('should get section list', () => {
    spyOn(trialsService, 'getSectionList').and.returnValue(of(sectionListMock));
    component.getSectionList();
    expect(component.sectionList[0].id).toBe('all');
    expect(component.sectionList[0].text).toBe('Choose a section...');
    expect(component.selectedSection).toBe('all');
  });


  it('should get paneled judges', () => {
    spyOn(trialsService, 'getPaneledJudges').and.returnValue(of(paneledJudgesResponseMock));
    component.headerInfo = {
      attorneys: []
    };
    // modalService.hide = (): BsModalRef => {
    //   return ({ id: null, hide: null, setClass: null, onHide: null, onHidden: null});
    // };
    // spyOn(modalService, 'hide').and.returnValue();
    component.judgeList = judgeListMock.listofJudges;
    component.getPaneledJudges();
  });


  it('should filter by discipline and no section', () => {
    component.selectedDiscipline = "Biotech";
    component.selectedSection = "all";
    let filteredListResponseMock = { "supplementaryIdType": null, "listofJudges": [{ "identifier": "10745", "firstName": "Tawen", "lastName": "Chang", "electronicAddress": [{ "email": "TEST_tawen.chang@uspto.gov" }], "prefferedName": "Chang, Tawen" }, { "identifier": "10782", "firstName": "Donald", "lastName": "Adams", "middleInitial": "E.", "electronicAddress": [{ "email": "TEST_donald.adams@uspto.gov" }], "prefferedName": "Adams, Donald E." }, { "identifier": "20723", "firstName": "Kristi", "lastName": "Sawert", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_kristi.sawert@uspto.gov" }], "prefferedName": "Sawert, Kristi L." }], "ptabReadOnlyUser": true, "proceedingSupplementaryIdList": null, "caseNo": null, "caseType": null };

    spyOn(trialsService, 'getFilteredList').and.returnValue(of(filteredListResponseMock));
    component.filterBySectionDiscipline();
    expect(component.judgeList).toEqual(filteredListResponseMock.listofJudges);
  });


  it('should filter by section and no discipline', () => {
    component.selectedDiscipline = "all";
    component.selectedSection = "Section 05";
    let filteredListResponseMock = { "supplementaryIdType": null, "listofJudges": [{ "identifier": "10745", "firstName": "Tawen", "lastName": "Chang", "electronicAddress": [{ "email": "TEST_tawen.chang@uspto.gov" }], "prefferedName": "Chang, Tawen" }, { "identifier": "10782", "firstName": "Donald", "lastName": "Adams", "middleInitial": "E.", "electronicAddress": [{ "email": "TEST_donald.adams@uspto.gov" }], "prefferedName": "Adams, Donald E." }, { "identifier": "20723", "firstName": "Kristi", "lastName": "Sawert", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_kristi.sawert@uspto.gov" }], "prefferedName": "Sawert, Kristi L." }], "ptabReadOnlyUser": true, "proceedingSupplementaryIdList": null, "caseNo": null, "caseType": null };

    spyOn(trialsService, 'getFilteredList').and.returnValue(of(filteredListResponseMock));
    component.filterBySectionDiscipline();
    expect(component.judgeList).toEqual(filteredListResponseMock.listofJudges);
  });


  it('should filter by section and discipline', () => {
    component.selectedDiscipline = "Biotech";
    component.selectedSection = "Section 05";
    let filteredListResponseMock = { "supplementaryIdType": null, "listofJudges": [{ "identifier": "10745", "firstName": "Tawen", "lastName": "Chang", "electronicAddress": [{ "email": "TEST_tawen.chang@uspto.gov" }], "prefferedName": "Chang, Tawen" }, { "identifier": "10782", "firstName": "Donald", "lastName": "Adams", "middleInitial": "E.", "electronicAddress": [{ "email": "TEST_donald.adams@uspto.gov" }], "prefferedName": "Adams, Donald E." }, { "identifier": "20723", "firstName": "Kristi", "lastName": "Sawert", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_kristi.sawert@uspto.gov" }], "prefferedName": "Sawert, Kristi L." }], "ptabReadOnlyUser": true, "proceedingSupplementaryIdList": null, "caseNo": null, "caseType": null };

    spyOn(trialsService, 'getFilteredList').and.returnValue(of(filteredListResponseMock));
    component.filterBySectionDiscipline();
    expect(component.judgeList).toEqual(filteredListResponseMock.listofJudges);
  });


  it('should filter by no section and no discipline', () => {
    component.selectedDiscipline = "all";
    component.selectedSection = "all";
    component.fullJudgeList = judgeListMock.listofJudges;
    component.filterBySectionDiscipline();
    expect(component.judgeList).toEqual(component.fullJudgeList);
  });


  it('should fail while filtering by section or discipline', () => {
    component.selectedDiscipline = "all";
    component.selectedSection = "Section 05";
    let filteredListResponseMock = { "supplementaryIdType": null, "listofJudges": [{ "identifier": "10745", "firstName": "Tawen", "lastName": "Chang", "electronicAddress": [{ "email": "TEST_tawen.chang@uspto.gov" }], "prefferedName": "Chang, Tawen" }, { "identifier": "10782", "firstName": "Donald", "lastName": "Adams", "middleInitial": "E.", "electronicAddress": [{ "email": "TEST_donald.adams@uspto.gov" }], "prefferedName": "Adams, Donald E." }, { "identifier": "20723", "firstName": "Kristi", "lastName": "Sawert", "middleInitial": "L.", "electronicAddress": [{ "email": "TEST_kristi.sawert@uspto.gov" }], "prefferedName": "Sawert, Kristi L." }], "ptabReadOnlyUser": true, "proceedingSupplementaryIdList": null, "caseNo": null, "caseType": null };

    spyOn(trialsService, 'getFilteredList').and.returnValue(throwError(""));
    component.filterBySectionDiscipline();
    expect(component.judgeList.length).toEqual(0);
  });


  it('should removed paneled judges from the list', () => {
    component.judgesOnTheCase = paneledJudgesResponseMock.listofJudges;
    component.judgeList = judgeListMock.listofJudges;
    component.removePaneledJudgesFromList();
  });


  it('should call close with no judges and in assign mode', () => {
    component.paneling.title = 'Assign';
    component.judgesOnTheCase = [];
    // modalService.hide = (): BsModalRef => {
    //   return ({ id: null, hide: null, setClass: null, onHide: null, onHidden: null});
    // };
    // spyOn(modalService, 'hide').and.returnValue();
    component.close(false);
    expect(component.paneling.isConfirm).toBe(false);
  });

  it('should call close with no judges and in update mode', () => {
    component.paneling.title = 'update';
    component.judgesOnTheCase = [];
    // modalService.hide = (): BsModalRef => {
    //   return ({ id: null, hide: null, setClass: null, onHide: null, onHidden: null});
    // };
    // spyOn(modalService, 'hide').and.returnValue();
    component.close(false);
    expect(component.paneling.isConfirm).toBe(false);
  });

  it('should check if judges are equal', () => {
    component.originalJudgesOnTheCase = paneledJudgesResponseMock.listofJudges;
    component.judgesOnTheCase = paneledJudgesResponseMock.listofJudges;
    let result = component.checkIfJudgesAreEqual(component.originalJudgesOnTheCase, component.judgesOnTheCase);
    expect(result).toBeTrue();
  });


  it('should add judge to the panel', () => {
    component.selectedJudges = [{ "identifier": "10660", "firstName": "Michael", "lastName": "Astorino", "middleInitial": "C.", "electronicAddress": [{ "email": "TEST_michael.astorino@uspto.gov" }], "prefferedName": "Astorino, Michael C." }];
    component.judgeList = judgeListMock.listofJudges;
    component.judgesOnTheCase = [];
    component.addJudgesToPanel();
    expect(component.judgesOnTheCase.length).toBe(1);
    expect(component.selectedJudges.length).toBe(0);
  });


  it('should remove a single judge from the panel', () => {
    let judgeToRemove = paneledJudgesResponseMock.listofJudges[0];
    component.judgesOnTheCase = paneledJudgesResponseMock.listofJudges;
    component.removeJudgeFromPanel(judgeToRemove);
    expect(component.judgesOnTheCase.length).toBe(2);
  });


  it('should remove all judges from the panel', () => {
    let judgesToRemove = paneledJudgesResponseMock.listofJudges;
    component.judgeList = judgeListMock.listofJudges;
    component.removeJudgeFromPanel(judgesToRemove);
    expect(component.judgesOnTheCase.length).toBe(0);
  });


  it('should move the judge up', () => {
    component.judgesOnTheCase = JSON.parse(JSON.stringify(paneledJudgesResponseMock.listofJudges));
    component.moveJudge(1, 'up');
    expect(component.judgesOnTheCase[0]).toEqual(paneledJudgesResponseMock.listofJudges[1]);
  });


  it('should move the judge down', () => {
    component.judgesOnTheCase = JSON.parse(JSON.stringify(paneledJudgesResponseMock.listofJudges));
    component.moveJudge(1, 'down');
    expect(component.judgesOnTheCase[2]).toEqual(paneledJudgesResponseMock.listofJudges[1]);
  });


  it('should search for judge', () => {
    component.searchCriteria = 'bisk';
    component.judgeList = judgeListMock.listofJudges;
    component.fullJudgeList = judgeListMock.listofJudges;
    component.judgesOnTheCase = paneledJudgesResponseMock.listofJudges;
    component.searchForJudge();
  });


  it('should search for judge and not find a match', () => {
    component.searchCriteria = 'bisk';
    component.judgeList = [{ "activeIndicator": "Y", "identifier": "5017", "firstName": "Jennifer", "lastName": "Bisk", "activeJudgeIndicator": "N", "middleInitial": "S.", "electronicAddress": [{ "email": "TEST_Jennifer.Bisk@USPTO.GOV" }], "prefferedName": null, "audit": { "createUserIdentifier": "sbartlett", "lastModifiedUserIdentifier": "sbartlett", "lastModifiedTimestamp": 1615407337000, "createTimestamp": 1615407337000 }, "rank": "1", "lifeCycle": { "beginEffectiveDate": 1615352400000 } }, { "activeIndicator": "Y", "identifier": "4718", "firstName": "Rama", "lastName": "Elluru", "activeJudgeIndicator": "Y", "middleInitial": "G.", "electronicAddress": [{ "email": "TEST_Rama.Elluru@USPTO.GOV" }], "prefferedName": "Elluru, Rama G.", "audit": { "createUserIdentifier": "sbartlett", "lastModifiedUserIdentifier": "sbartlett", "lastModifiedTimestamp": 1615407337000, "createTimestamp": 1615407337000 }, "rank": "2", "lifeCycle": { "beginEffectiveDate": 1615352400000 } }, { "activeIndicator": "Y", "identifier": "529", "firstName": "John", "lastName": "Horvath", "activeJudgeIndicator": "Y", "middleInitial": "F.", "electronicAddress": [{ "email": "TEST_John.Horvath@USPTO.GOV" }], "prefferedName": "Horvath, John F.", "audit": { "createUserIdentifier": "sbartlett", "lastModifiedUserIdentifier": "sbartlett", "lastModifiedTimestamp": 1615407337000, "createTimestamp": 1615407337000 }, "rank": "3", "lifeCycle": { "beginEffectiveDate": 1615352400000 } }];
    component.fullJudgeList = [{ "activeIndicator": "Y", "identifier": "5017", "firstName": "Jennifer", "lastName": "Bisk", "activeJudgeIndicator": "N", "middleInitial": "S.", "electronicAddress": [{ "email": "TEST_Jennifer.Bisk@USPTO.GOV" }], "prefferedName": null, "audit": { "createUserIdentifier": "sbartlett", "lastModifiedUserIdentifier": "sbartlett", "lastModifiedTimestamp": 1615407337000, "createTimestamp": 1615407337000 }, "rank": "1", "lifeCycle": { "beginEffectiveDate": 1615352400000 } }, { "activeIndicator": "Y", "identifier": "4718", "firstName": "Rama", "lastName": "Elluru", "activeJudgeIndicator": "Y", "middleInitial": "G.", "electronicAddress": [{ "email": "TEST_Rama.Elluru@USPTO.GOV" }], "prefferedName": "Elluru, Rama G.", "audit": { "createUserIdentifier": "sbartlett", "lastModifiedUserIdentifier": "sbartlett", "lastModifiedTimestamp": 1615407337000, "createTimestamp": 1615407337000 }, "rank": "2", "lifeCycle": { "beginEffectiveDate": 1615352400000 } }, { "activeIndicator": "Y", "identifier": "529", "firstName": "John", "lastName": "Horvath", "activeJudgeIndicator": "Y", "middleInitial": "F.", "electronicAddress": [{ "email": "TEST_John.Horvath@USPTO.GOV" }], "prefferedName": "Horvath, John F.", "audit": { "createUserIdentifier": "sbartlett", "lastModifiedUserIdentifier": "sbartlett", "lastModifiedTimestamp": 1615407337000, "createTimestamp": 1615407337000 }, "rank": "3", "lifeCycle": { "beginEffectiveDate": 1615352400000 } }];
    component.judgesOnTheCase = paneledJudgesResponseMock.listofJudges;
    component.searchForJudge();
  })


  it('should search for judge with no search criteria', () => {
    component.searchCriteria = '';
    component.judgeList = judgeListMock.listofJudges;
    component.fullJudgeList = judgeListMock.listofJudges;
    component.judgesOnTheCase = paneledJudgesResponseMock.listofJudges;
    component.searchForJudge();
    expect(component.judgeList.length).toBe(component.fullJudgeList.length);
  });


  it('should call verifySubmitOrUpdate as update', () => {
    component.paneling.title = "Update";
    component.originalJudgesOnTheCase = paneledJudgesResponseMock.listofJudges;
    component.loggedInUser = {
      loginId: "sbartlett"
    }
    let userName = {};
    spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
        return userName[key];
    });
    component.panelingDate = new Date();

    const trialsServiceStub: TrialsService = fixture.debugElement.injector.get(
      TrialsService
    );
    const assignPanelSuccessMock = {
      success: {
        message: "Success"
      }
    };
    // spyOn(trialsService, 'assignPanelToCase').and.returnValue(of({test:''}));
    spyOn(trialsService, "clearPanel").and.returnValue(of(assignPanelSuccessMock));
   // spyOn(trialsServiceStub, 'assignPanelToCase').and.callThrough();

    component.verifySubmitOrUpdate();
  });

  it('should call verifySubmitOrUpdate as empty', () => {
    component.paneling.title = "";
    component.loggedInUser = {
      loginId: "sbartlett"
    }
    let userName = {};
    spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
        return userName[key];
    });
    // spyOn(trialsService, 'assignPanelToCase').and.returnValue(of({test:''}));
    component.verifySubmitOrUpdate();
  });

  it('should call checkForRemovedJudges', () => {
    component.paneling.title = "";
    component.loggedInUser = {
      loginId: "sbartlett"
    }
    let userName = {};
    spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
        return userName[key];
    });
    // spyOn(trialsService, 'assignPanelToCase').and.returnValue(of({test:''}));
    component.originalJudgesOnTheCase = [];
    component.checkForRemovedJudges();
  });


  it('should submit panel', () => {
    component.judgesOnTheCase = paneledJudgesResponseMock.listofJudges;
    component.panelingDate = new Date();
    component.loggedInUser = {
      loginId: "sbartlett"
    }
    const assignPanelSuccessMock = {
      success: {
        message: "Success"
      }
    };
    let userName = {};
    spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
        return userName[key];
    });
    // spyOn(trialsService, "assignPanelToCase").and.returnValue(of(assignPanelSuccessMock));
    // modalService.hide = (): BsModalRef => {
    //   return ({ id: null, hide: null, setClass: null, onHide: null, onHidden: null});
    // };
    // spyOn(modalService, 'hide').and.returnValue();
    component.submitPanel();
    expect(component.paneling.isConfirm).toBe(true);

  });


  it('should submit panel and fail', () => {
    component.judgesOnTheCase = paneledJudgesResponseMock.listofJudges;
    component.panelingDate = new Date();
    component.loggedInUser = {
      loginId: "sbartlett"
    }
    let userName = {};
    spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
        return userName[key];
    });
    const assignPanelFailureMock = {
      error: {
        message: "Error"
      }
    };
    // spyOn(trialsService, "assignPanelToCase").and.returnValue(throwError(assignPanelFailureMock));
    component.submitPanel();
  });


  // it('should clear panel', () => {
  //   component.judgesToRemove = paneledJudgesResponseMock.listofJudges;
  //   component.panelingDate = new Date();
  //   component.loggedInUser = {
  //     loginId: "sbartlett"
  //   };
  //   const assignPanelFailureMock = {
  //     error: {
  //       message: "Error"
  //     }
  //   };
  //   spyOn(trialsService, "clearPanel").and.returnValue(throwError(assignPanelFailureMock));
  //   component.clearPanel(false);
  // });

  // it('should clear panel', () => {
  //   component.loggedInUser = {
  //     loginId: "sbartlett"
  //   };
  //   const assignPanelSuccessMock = {
  //     success: {
  //       message: "Success"
  //     }
  //   };
  //   spyOn(trialsService, "clearPanel").and.returnValue(of(assignPanelSuccessMock));
  //   modalService.hide = (): BsModalRef => {
  //     return ({ id: null, hide: null, setClass: null, onHide: null, onHidden: null});
  //   };
  //   spyOn(modalService, 'hide').and.returnValue();
  //   component.clearPanel(false);
  //   expect(component.paneling.isConfirm).toBe(true);
  // });

  it('should clear panel with proceedToAdd as true', () => {
    component.loggedInUser = {
      loginId: "sbartlett"
    };
    const assignPanelSuccessMock = {
      success: {
        message: "Success"
      }
    };
    spyOn(trialsService, "clearPanel").and.returnValue(of(assignPanelSuccessMock));
    // modalService.hide = (): BsModalRef => {
    //   return ({ id: null, hide: null, setClass: null, onHide: null, onHidden: null});
    // };
    // spyOn(modalService, 'hide').and.returnValue();
    component.clearPanel(true);
    // expect(component.paneling.isConfirm).toBe(false);
  });

  it('should call openHistoryModal' , () =>{

    const initialState = {
      panelHistory: {
        isConfirm: false,
        proceedingNo: component.paneling.caseToPanel.proceedingNo
      }
    };
    const reason = {
      initialState:{
        isConfirm: true,
        proceedingNo: component.paneling.caseToPanel.proceedingNo
      }
    }
    const emitter = new EventEmitter();
    emitter.emit(reason);

    modalService.show = (): BsModalRef => {
      return ({ id: null, hide: null, setClass: null, onHide: emitter, onHidden: null});
    };


    spyOn(component, "openHistoryModal").and.callThrough();
    component.openHistoryModal();
    expect(component.openHistoryModal).toHaveBeenCalled();

   });


  // afterAll(() => {
  //   TestBed.resetTestingModule();
  // });

});
