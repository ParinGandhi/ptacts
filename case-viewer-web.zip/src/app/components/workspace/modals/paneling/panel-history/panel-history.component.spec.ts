import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { DatePipe } from '@angular/common';
import { TrialsService } from 'src/app/services/trials.service';
import { ToastrService } from 'ngx-toastr';
import { of } from 'rxjs';
import { AgGridModule } from 'ag-grid-angular';

import { PanelHistoryComponent } from './panel-history.component';


/**
 * 65.71%
 */
describe('PanelHistoryComponent', () => {
  let component: PanelHistoryComponent;
  let trialsService: TrialsService;
  let modalRef: BsModalRef;
  let modalService: BsModalService;
  let fixture: ComponentFixture<PanelHistoryComponent>;

  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => {},
    error: (
      message?: string,
      title?: string
    ) => {},
};

  const panelHistoryMock = {
    proceedingNo: "1234567",
    isConfirm: false
  }

  const panelHistoryResponseMock = {
    "supplementaryIdType": "PATENT",
    "listofJudges": [
      {
        "activeIndicator": "N",
        "identifier": "9951",
        "firstName": "Jennifer",
        "lastName": "Bahr",
        "activeJudgeIndicator": "Y",
        "middleInitial": "D.",
        "electronicAddress": [
          {
            "email": "TEST_jennifer.bahr@uspto.gov"
          }
        ],
        "prefferedName": "Bahr, Jennifer D.",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615779223000,
          "createTimestamp": 1615778678000
        },
        "rank": "1",
        "lifeCycle": {
          "endEffectiveDate": 1615779223000,
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "Y",
        "identifier": "5032",
        "firstName": "Stephen",
        "lastName": "Siu",
        "activeJudgeIndicator": "N",
        "electronicAddress": [
          {
            "email": "TEST_stephen.siu@USPTO.GOV"
          }
        ],
        "prefferedName": "Siu, Stephen",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615779223000,
          "createTimestamp": 1615779223000
        },
        "rank": "1",
        "lifeCycle": {
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "N",
        "identifier": "1806",
        "firstName": "Daniel",
        "lastName": "Fishman",
        "activeJudgeIndicator": "N",
        "middleInitial": "N.",
        "electronicAddress": [
          {
            "email": "TEST_Daniel.Fishman@USPTO.GOV"
          }
        ],
        "prefferedName": "Fishman, Daniel N.",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615578171000,
          "createTimestamp": 1615578050000
        },
        "rank": "1",
        "lifeCycle": {
          "endEffectiveDate": 1615578171000,
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "N",
        "identifier": "1806",
        "firstName": "Daniel",
        "lastName": "Fishman",
        "activeJudgeIndicator": "N",
        "middleInitial": "N.",
        "electronicAddress": [
          {
            "email": "TEST_Daniel.Fishman@USPTO.GOV"
          }
        ],
        "prefferedName": "Fishman, Daniel N.",
        "audit": {
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Torres, Shanna ",
          "lastModifiedTimestamp": 1615578050000,
          "createTimestamp": 1516817760709
        },
        "rank": "1",
        "lifeCycle": {
          "endEffectiveDate": 1615578050000,
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "N",
        "identifier": "1806",
        "firstName": "Daniel",
        "lastName": "Fishman",
        "activeJudgeIndicator": "N",
        "middleInitial": "N.",
        "electronicAddress": [
          {
            "email": "TEST_Daniel.Fishman@USPTO.GOV"
          }
        ],
        "prefferedName": "Fishman, Daniel N.",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615778677000,
          "createTimestamp": 1615578171000
        },
        "rank": "1",
        "lifeCycle": {
          "endEffectiveDate": 1615778677000,
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "N",
        "identifier": "1809",
        "firstName": "Charles",
        "lastName": "Boudreau",
        "activeJudgeIndicator": "Y",
        "middleInitial": "J.",
        "electronicAddress": [
          {
            "email": "TEST_Charles.Boudreau@USPTO.GOV"
          }
        ],
        "prefferedName": "Boudreau, Charles J.",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615778677000,
          "createTimestamp": 1615578171000
        },
        "rank": "2",
        "lifeCycle": {
          "endEffectiveDate": 1615778677000,
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "N",
        "identifier": "5014",
        "firstName": "Ken",
        "lastName": "Barrett",
        "activeJudgeIndicator": "Y",
        "middleInitial": "B.",
        "electronicAddress": [
          {
            "email": "TEST_Ken.Barrett@USPTO.GOV"
          }
        ],
        "prefferedName": "Barrett, Ken B.",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615779223000,
          "createTimestamp": 1615778678000
        },
        "rank": "2",
        "lifeCycle": {
          "endEffectiveDate": 1615779223000,
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "N",
        "identifier": "1809",
        "firstName": "Charles",
        "lastName": "Boudreau",
        "activeJudgeIndicator": "Y",
        "middleInitial": "J.",
        "electronicAddress": [
          {
            "email": "TEST_Charles.Boudreau@USPTO.GOV"
          }
        ],
        "prefferedName": "Boudreau, Charles J.",
        "audit": {
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Torres, Shanna ",
          "lastModifiedTimestamp": 1615578050000,
          "createTimestamp": 1516817760710
        },
        "rank": "2",
        "lifeCycle": {
          "endEffectiveDate": 1615578050000,
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "N",
        "identifier": "1809",
        "firstName": "Charles",
        "lastName": "Boudreau",
        "activeJudgeIndicator": "Y",
        "middleInitial": "J.",
        "electronicAddress": [
          {
            "email": "TEST_Charles.Boudreau@USPTO.GOV"
          }
        ],
        "prefferedName": "Boudreau, Charles J.",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615578171000,
          "createTimestamp": 1615578050000
        },
        "rank": "2",
        "lifeCycle": {
          "endEffectiveDate": 1615578171000,
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "Y",
        "identifier": "9951",
        "firstName": "Jennifer",
        "lastName": "Bahr",
        "activeJudgeIndicator": "Y",
        "middleInitial": "D.",
        "electronicAddress": [
          {
            "email": "TEST_jennifer.bahr@uspto.gov"
          }
        ],
        "prefferedName": "Bahr, Jennifer D.",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615779223000,
          "createTimestamp": 1615779223000
        },
        "rank": "2",
        "lifeCycle": {
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "N",
        "identifier": "1809",
        "firstName": "Charles",
        "lastName": "Boudreau",
        "activeJudgeIndicator": "Y",
        "middleInitial": "J.",
        "electronicAddress": [
          {
            "email": "TEST_Charles.Boudreau@USPTO.GOV"
          }
        ],
        "prefferedName": "Boudreau, Charles J.",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615779223000,
          "createTimestamp": 1615778678000
        },
        "rank": "3",
        "lifeCycle": {
          "endEffectiveDate": 1615779223000,
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "Y",
        "identifier": "5014",
        "firstName": "Ken",
        "lastName": "Barrett",
        "activeJudgeIndicator": "Y",
        "middleInitial": "B.",
        "electronicAddress": [
          {
            "email": "TEST_Ken.Barrett@USPTO.GOV"
          }
        ],
        "prefferedName": "Barrett, Ken B.",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615779223000,
          "createTimestamp": 1615779223000
        },
        "rank": "3",
        "lifeCycle": {
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "N",
        "identifier": "5032",
        "firstName": "Stephen",
        "lastName": "Siu",
        "activeJudgeIndicator": "N",
        "electronicAddress": [
          {
            "email": "TEST_stephen.siu@USPTO.GOV"
          }
        ],
        "prefferedName": "Siu, Stephen",
        "audit": {
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Torres, Shanna ",
          "lastModifiedTimestamp": 1615578050000,
          "createTimestamp": 1516817760709
        },
        "rank": "3",
        "lifeCycle": {
          "endEffectiveDate": 1615578050000,
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "N",
        "identifier": "5032",
        "firstName": "Stephen",
        "lastName": "Siu",
        "activeJudgeIndicator": "N",
        "electronicAddress": [
          {
            "email": "TEST_stephen.siu@USPTO.GOV"
          }
        ],
        "prefferedName": "Siu, Stephen",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615578171000,
          "createTimestamp": 1615578050000
        },
        "rank": "3",
        "lifeCycle": {
          "endEffectiveDate": 1615578171000,
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "N",
        "identifier": "5032",
        "firstName": "Stephen",
        "lastName": "Siu",
        "activeJudgeIndicator": "N",
        "electronicAddress": [
          {
            "email": "TEST_stephen.siu@USPTO.GOV"
          }
        ],
        "prefferedName": "Siu, Stephen",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615778677000,
          "createTimestamp": 1615578171000
        },
        "rank": "3",
        "lifeCycle": {
          "endEffectiveDate": 1615778677000,
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "N",
        "identifier": "5014",
        "firstName": "Ken",
        "lastName": "Barrett",
        "activeJudgeIndicator": "Y",
        "middleInitial": "B.",
        "electronicAddress": [
          {
            "email": "TEST_Ken.Barrett@USPTO.GOV"
          }
        ],
        "prefferedName": "Barrett, Ken B.",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615578171000,
          "createTimestamp": 1615578050000
        },
        "rank": "4",
        "lifeCycle": {
          "endEffectiveDate": 1615578171000,
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "N",
        "identifier": "5014",
        "firstName": "Ken",
        "lastName": "Barrett",
        "activeJudgeIndicator": "Y",
        "middleInitial": "B.",
        "electronicAddress": [
          {
            "email": "TEST_Ken.Barrett@USPTO.GOV"
          }
        ],
        "prefferedName": "Barrett, Ken B.",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615778678000,
          "createTimestamp": 1615578171000
        },
        "rank": "4",
        "lifeCycle": {
          "endEffectiveDate": 1615778678000,
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "Y",
        "identifier": "1809",
        "firstName": "Charles",
        "lastName": "Boudreau",
        "activeJudgeIndicator": "Y",
        "middleInitial": "J.",
        "electronicAddress": [
          {
            "email": "TEST_Charles.Boudreau@USPTO.GOV"
          }
        ],
        "prefferedName": "Boudreau, Charles J.",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615779223000,
          "createTimestamp": 1615779223000
        },
        "rank": "4",
        "lifeCycle": {
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "N",
        "identifier": "1806",
        "firstName": "Daniel",
        "lastName": "Fishman",
        "activeJudgeIndicator": "N",
        "middleInitial": "N.",
        "electronicAddress": [
          {
            "email": "TEST_Daniel.Fishman@USPTO.GOV"
          }
        ],
        "prefferedName": "Fishman, Daniel N.",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615779223000,
          "createTimestamp": 1615778678000
        },
        "rank": "4",
        "lifeCycle": {
          "endEffectiveDate": 1615779223000,
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "N",
        "identifier": "10745",
        "firstName": "Tawen",
        "lastName": "Chang",
        "activeJudgeIndicator": "Y",
        "electronicAddress": [
          {
            "email": "TEST_tawen.chang@uspto.gov"
          }
        ],
        "prefferedName": "Chang, Tawen",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615578171000,
          "createTimestamp": 1615578050000
        },
        "rank": "5",
        "lifeCycle": {
          "endEffectiveDate": 1615578171000,
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "Y",
        "identifier": "1806",
        "firstName": "Daniel",
        "lastName": "Fishman",
        "activeJudgeIndicator": "N",
        "middleInitial": "N.",
        "electronicAddress": [
          {
            "email": "TEST_Daniel.Fishman@USPTO.GOV"
          }
        ],
        "prefferedName": "Fishman, Daniel N.",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615779223000,
          "createTimestamp": 1615779223000
        },
        "rank": "5",
        "lifeCycle": {
          "beginEffectiveDate": 1516770000000
        }
      },
      {
        "activeIndicator": "N",
        "identifier": "5032",
        "firstName": "Stephen",
        "lastName": "Siu",
        "activeJudgeIndicator": "N",
        "electronicAddress": [
          {
            "email": "TEST_stephen.siu@USPTO.GOV"
          }
        ],
        "prefferedName": "Siu, Stephen",
        "audit": {
          "createUserIdentifier": "sbartlett",
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedPrefferedName": "Bartlett, Steven ",
          "createdPrefferedName": "Bartlett, Steven ",
          "lastModifiedTimestamp": 1615779223000,
          "createTimestamp": 1615778678000
        },
        "rank": "5",
        "lifeCycle": {
          "endEffectiveDate": 1615779223000,
          "beginEffectiveDate": 1516770000000
        }
      }
    ],
    "ptabReadOnlyUser": true,
    "proceedingSupplementaryIdList": [
      "7337241"
    ],
    "caseNo": "IPR2018-00328",
    "caseType": "TRIALS"
  };


  const gridApiMock = {
    setFilterModel: () => { },
    getDisplayedRowCount: () => {
      return 5;
    },
    getFilterModel: () => {
      const filterModelMock = {
        status: {
          filter: "n",
          filterType: "text",
          type: "contains"
        }
      }
      return filterModelMock;
    },
    exportDataAsCsv: () => { },
    getSelectedRows: () => { }
  };



  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, AgGridModule.withComponents([])],
      declarations: [PanelHistoryComponent],
      providers: [TrialsService, DatePipe, {
        provide: BsModalRef,
        useValue: {}
    },
    {
        provide: BsModalService,
        useValue: {}
    },{
      provide: ToastrService,
      useValue: toastrService
  }]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PanelHistoryComponent);
    trialsService = TestBed.inject(TrialsService);
    modalService = TestBed.inject(BsModalService);
    component = fixture.componentInstance;
    component.panelHistory = panelHistoryMock;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should get panel history', () => {
    spyOn(trialsService, 'getPaneledJudges').and.returnValue(of(panelHistoryResponseMock));
    component.getPanelHistory();
    expect(component.allJudges).toEqual(panelHistoryResponseMock.listofJudges);
  });



  it('should toggle filter with only paneled', () => {
    // component.allJudges = panelHistoryResponseMock.listofJudges;
    let onlyPaneled = [];
    panelHistoryResponseMock.listofJudges.forEach((judge) => {
      if (judge.activeIndicator && judge.activeIndicator.toLowerCase() === 'y') {
        onlyPaneled.push(judge);
      }
    });
    component.onlyPaneled = onlyPaneled;
    component.showPaneledOnly = true;
    component.toggleFilter();
    expect(component.rowData).toEqual(onlyPaneled);
  })


  it('should toggle filter with all', () => {
    component.allJudges = panelHistoryResponseMock.listofJudges;
    // let onlyPaneled = [];
    // panelHistoryResponseMock.listofJudges.forEach((judge) => {
    //   if (judge.activeIndicator && judge.activeIndicator.toLowerCase() === 'y') {
    //     onlyPaneled.push(judge);
    //   }
    // });
    // component.onlyPaneled = onlyPaneled;
    component.showPaneledOnly = false;
    component.toggleFilter();
    expect(component.rowData).toEqual(panelHistoryResponseMock.listofJudges);
  })


  it('should invoke onFilterChanged', () => {
    const data = {
      api: component.gridApi,
      columnApi: component.gridColumnApi
    }
    component.gridApi = gridApiMock;
    component.onFilterChanged();
    fixture.detectChanges();
  });


  it('should export data as csv', () => {
    const data = {
      api: component.gridApi,
      columnApi: component.gridColumnApi
    }
    component.gridApi = gridApiMock;
    component.exportDataAsCsv();
    fixture.detectChanges();
  });


  // it('should call onRowSelected', () => {
  //   component.gridApi = gridApiMock;
  //   component.onRowSelected();
  //   fixture.detectChanges();
  // });


  it('should clear filters', () => {
    component.gridApi = gridApiMock;
    component.clearGridFilters();
    fixture.detectChanges();
  });

  afterAll(() => {
    TestBed.resetTestingModule();
  });

});
