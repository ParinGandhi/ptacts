import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { TrialsService } from 'src/app/services/trials.service';

@Component({
  selector: 'app-panel-history',
  templateUrl: './panel-history.component.html',
  styleUrls: ['./panel-history.component.less']
})
export class PanelHistoryComponent implements OnInit {

  panelHistory: any;
  panelHistoryModalRef: BsModalRef;

  gridApi;
  gridColumnApi;
  noRowsTemplate: string = "No inactive ............";

  defaultColDef = {
    filter: true,
    sortable: true,
    floatingFilter: true,
    suppressMenu: true,
    suppressHorizontalScroll: true,
  };

  rowSelection = 'single';


  columnDefs = [
    // {
    //   headerName: 'Decision',
    //   field: 'decision',
    //   width: 190,
    //   minWidth: 190,
    //   maxWidth: 190,
    //   resizable: true,
    //   headerCheckboxSelection: false
    // },
    {
      headerName: 'Panel role',
      // field: 'panelRole',
      "valueGetter": function (params) {
        return `APJ${params.data.rank}`;
      },
      width: 110,
      minWidth: 110,
      maxWidth: 110,
      resizable: true
    },
    {
      headerName: 'Name',
      field: 'prefferedName',
      resizable: true
    },
    {
      headerName: 'Status',
      // field: 'status',
      "valueGetter": function (params) {
        return params.data.activeIndicator.toLowerCase() === 'n' ? 'Unpaneled' : 'Paneled';
      },
      width: 110,
      minWidth: 110,
      maxWidth: 110,
      resizable: true
    },
    {
      headerName: 'Paneled date',
      field: 'beginEffectiveDateStr',
      resizable: true,
      width: 125,
      minWidth: 125,
      maxWidth: 125,
      comparator: this.gridHelper.dateComparator,
      type: 'date'
    },
    {
      headerName: 'Updated by',
      field: 'audit.lastModifiedPrefferedName',
      resizable: true,
      wrapText: false,
      autoHeight: false
    },
    {
      headerName: 'Timestamp',
      field: 'lastModifiedTimestampStr',
      width: 175,
      minWidth: 175,
      maxWidth: 175,
      resizable: true,
      comparator: this.gridHelper.dateComparator,
      type: 'timestamp'
    }
  ];

  rowData: Array<any> = [];
  allJudges: Array<any> = [];
  onlyPaneled: Array<any> = [];

  showPaneledOnly: boolean = false;

  constructor
    (
      private panelHistoryModalService: BsModalService,
    private gridHelper: GridHelperService,
      private trialsService: TrialsService
  ) { }

  ngOnInit(): void {
    this.getPanelHistory();
  }

  getPanelHistory() {
    this.trialsService.getPaneledJudges(this.panelHistory.proceedingNo, true).subscribe((panelHistoryResponse) => {
      panelHistoryResponse.listofJudges.forEach(element => {
        element.beginEffectiveDateStr = element.lifeCycle.beginEffectiveDate ? this.gridHelper.convertDateToString(element.lifeCycle.beginEffectiveDate) : null;
        element.lastModifiedTimestampStr = element.audit.lastModifiedTimestamp ? this.gridHelper.convertDateToTimeStamp(element.audit.lastModifiedTimestamp) : null;
        if (element.activeIndicator && element.activeIndicator.toLowerCase() === 'y') {
          this.onlyPaneled.push(element);
        }
      });
      this.allJudges = JSON.parse(JSON.stringify(panelHistoryResponse.listofJudges));
      this.rowData = panelHistoryResponse.listofJudges;
    });
  }

  close(value) {
    console.log(value);
    this.panelHistoryModalService.hide(1);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }



  onFilterChanged() {
    console.log("On filter changed: ", this.gridApi.getDisplayedRowCount());
    const filterModel = this.gridApi.getFilterModel();
    // this.numberOfFilters = Object.keys(filterModel).length;
  }



  // isFirstColumn(params) {
  //   let displayedColumns = params.columnApi.getAllDisplayedColumns();
  //   let thisIsFirstColumn = displayedColumns[0] === params.column;
  //   return thisIsFirstColumn;
  // }



  clearGridFilters() {
    this.gridApi.setFilterModel(null);
  }


  exportDataAsCsv() {
    let fileName: string = `AIA Trials panel history_${this.panelHistory.proceedingNo}_`;
    this.gridHelper.exportDataAsCsv(this.gridApi, fileName);
  }

  toggleFilter() {
    this.rowData = this.showPaneledOnly ? this.onlyPaneled : this.allJudges;
  }

}
