import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import InfoModalModel from 'src/app/models/common/InfoModal.model';
import PanelJudgeModel from 'src/app/models/common/PanelJudge.model';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { TrialsService } from 'src/app/services/trials.service';
import { Store, select } from '@ngrx/store';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import * as CaseViewerActions from 'src/app/store/case-viewer/case-viewer.actions';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import { JpViewService } from 'src/app/services/jpview.service';
import { PanelHistoryComponent } from './panel-history/panel-history.component';
import { CaseViewerService } from 'src/app/services/case-viewer.service';

@Component({
  selector: 'app-paneling',
  templateUrl: './paneling.component.html',
  styleUrls: ['./paneling.component.less']
})
export class PanelingComponent implements OnInit {

  paneling: any;

  options: any = {};
  //   multiple: false,
  //   closeOnSelect: true,
  //   width: '100%',
  //   allowClear: true,
  //   theme: 'bootstrap',
  //   openOnEnter: true,
  //   // minimumResultsForSearch: Infinity - use to hide search box
  // }
  modalRef: BsModalRef;

  disciplineList: Array<any> = [];

  sectionList: Array<any> = [];

  getCasePhase$ = this.store.pipe(select(CaseViewerSelectors.casePhaseData));
  judgeList: Array<any> = [];
  inactiveJudgesList: Array<any> = [];
  fullJudgeList: Array<any> = [];
  judgesOnTheCase: Array<PanelJudgeModel> = [];
  originalJudgesOnTheCase: Array<PanelJudgeModel> = [];
  selectedJudges: Array<any> = [];
  judgesToRemove: Array<any> = [];
  searchCriteria: string = null;
  panelingDate = null;
  originalPanelingDate = null;
  minimumNumberOfJudges: number = 3;
  caseInfo: CaseInfoModel;
  headerInfo: any = null;
  loggedInUser: any;
  selectedDiscipline: any;
  selectedSection: any;
  showLessThanThreeJudgeMessage: boolean = false;
  activeJudgeCount: number = 0;
  inactiveJudgeOnPanel: boolean = false;


  constructor(
    private modalService: BsModalService,
    private trialsService: TrialsService,
    private jpViewService: JpViewService,
    private caseViewerService: CaseViewerService,
    private commonUtils: CommonUtilitiesService,
    private store: Store<CaseViewerState>,
  ) { }

  ngOnInit(): void {

    // this.store.pipe(select(CaseViewerSelectors.caseHeaderData)).subscribe(headerState => {
    //   this.headerInfo = headerState;
    //   console.log('this.headerInfo: ', this.headerInfo);
    // })

    this.panelingDate = this.commonUtils.setDateOnDatePicker(Date.now());
    this.originalPanelingDate = this.commonUtils.setDateOnDatePicker(Date.now());

    this.loggedInUser = JSON.parse(window.sessionStorage.getItem("userInfo"));

   this.options = this.commonUtils.setTypeaheadOptions();
    this.getJudgeList();
    this.getDisciplineList();
    this.getSectionList();
    if (this.paneling.title.toLowerCase() === 'update') {
      this.getPaneledJudges();
    }
    // this.getCaseHeaderInfo(this.paneling.caseInfo);
    this.getCaseInfo();
  }


  getCaseInfo() {
    let proceedingNo = this.paneling.caseToPanel.proceedingNumber ? this.paneling.caseToPanel.proceedingNumber : this.paneling.caseToPanel.proceedingNo;
    // let url = this.paneling.caseToPanel.proceedingNumber ? `${PtabTrialConstants.CASE_VIEWER_URL}/case-viewer/caseNumber-search?caseNumber=${this.paneling.caseToPanel.proceedingNumber}` : `${PtabTrialConstants.CASE_VIEWER_URL}/case-viewer/caseNumber-search?caseNumber=${this.paneling.caseToPanel.proceedingNo}`
    // this.jpViewService.getDocuments(url).subscribe((caseInfoResonse) => {
    this.caseViewerService.caseSearch(proceedingNo).subscribe((caseInfoResonse) => {
      this.caseInfo = {
        "serialNo": caseInfoResonse.serialNumber[0].trim(),
        "proceedingNo": caseInfoResonse.appealNumber[0]
      };
      this.getCaseHeaderInfo(this.caseInfo);
    })
  }


  getCaseHeaderInfo(caseInfo) {
    // let urlString = PtabTrialConstants.CASE_HEADER + `${caseInfo.serialNo}&proceedingSupplementaryId=${caseInfo.proceedingNo}`;
    // this.trialsService.getHeaderInfo(urlString).subscribe((headerInfoResponse) => {
    this.trialsService.getHeaderInfo(caseInfo.proceedingNo).subscribe((headerInfoResponse) => {
      this.headerInfo = headerInfoResponse[0];
      if (this.headerInfo) {
        this.headerInfo.attorneys = [];
        this.headerInfo.attorneys = [...this.originalJudgesOnTheCase];
        // this.headerInfo.attorneys[1].activeJudgeIndicator === 'N';
      }
      console.log('this.headerInfo: ', this.headerInfo);
    })
  };



  getJudgeList() {
    this.trialsService.getJudgeList().subscribe((judgeListResponse) => {
      this.judgeList = judgeListResponse.listofJudges.filter((judge) => {
        return !judge.prefferedName.includes("null");
      });
      this.removePaneledJudgesFromList();
      this.fullJudgeList = [...this.judgeList];
    });
  }


  getDisciplineList() {
    this.trialsService.getDisciplineList().subscribe((disciplineListResponse) => {
      this.disciplineList = this.commonUtils.setTypeaheadList(disciplineListResponse, 'caseDisciplineDescription', 'caseDisciplineDescription');
      const defaultDiscipline = {
        id: 'all',
        text: 'Choose a discipline...'
      };
      this.disciplineList.unshift(defaultDiscipline);
      this.selectedDiscipline = 'all';
      // disciplineListResponse.responseData.forEach((discipline) => {
      //   discipline.id = discipline.caseDisciplineCode;
      //   discipline.text = discipline.caseDisciplineDescription;
      // });
      // this.disciplineList = disciplineListResponse.responseData;
    });
  }


  getSectionList() {
    this.trialsService.getSectionList().subscribe((sectionListResponse) => {
      this.sectionList = this.commonUtils.setTypeaheadList(sectionListResponse, 'sectionName', 'sectionName');
      this.sectionList.forEach((section) => {
        section.text = section.text.slice(section.text.indexOf("-") + 1);
        section.id = section.id.slice(section.id.indexOf("-") + 1);
      })
      const defaultSection = {
        id: 'all',
        text: 'Choose a section...'
      };
      this.sectionList.unshift(defaultSection);
      this.selectedSection = 'all';
      // sectionListResponse.responseData.forEach((section) => {
      //   section.id = section.teamIdentifier;
      //   section.text = section.sectionName;
      // });
      // this.sectionList = sectionListResponse.responseData;
    });
  }


  getPaneledJudges() {
    this.trialsService.getPaneledJudges(this.paneling.caseToPanel.proceedingNo, false).subscribe((paneledJudgesResponse) => {
      this.judgesOnTheCase = [];
      paneledJudgesResponse.listofJudges.forEach(judge => {
        this.judgesOnTheCase[parseInt(judge.rank) - 1] = judge;
      });

      // Remove the paneled judges from the main judge list
      for (let i = 0; i < this.judgeList.length; i++) {
        this.judgesOnTheCase.forEach((judge) => {
          if (judge.identifier === this.judgeList[i].identifier) {
            this.judgeList.splice(i, 1);
          }
        })
      };
      this.originalJudgesOnTheCase = [...this.judgesOnTheCase];
      this.fullJudgeList = [...this.judgeList];
      if (this.headerInfo && this.headerInfo.attorneys && this.headerInfo.attorneys.length <= 0) {
        this.headerInfo.attorneys = [];
        this.headerInfo.attorneys = [...this.judgesOnTheCase];
      }

      // Remove inactive judges
      // this.judgesOnTheCase[1].activeJudgeIndicator = "N";
      this.showLessThanThreeJudgeMessage = false;
      this.inactiveJudgesList = [];
      this.activeJudgeCount = this.judgesOnTheCase.length
      for (let i = 0; i < this.judgesOnTheCase.length; i++) {
        if (this.judgesOnTheCase[i] && this.judgesOnTheCase[i].activeJudgeIndicator && this.judgesOnTheCase[i].activeJudgeIndicator.toLowerCase() === 'n') {
          this.inactiveJudgesList.push(this.judgesOnTheCase[i]);
          this.inactiveJudgeOnPanel = true;
          this.activeJudgeCount--;
          // this.judgesOnTheCase.splice(i, 1);
        }
      }
      this.showLessThanThreeJudgeMessage = this.activeJudgeCount < 3;

      if (this.judgesOnTheCase[0]) {
        this.panelingDate = this.commonUtils.setDateOnDatePicker(this.judgesOnTheCase[0].lifeCycle.beginEffectiveDate);
        this.originalPanelingDate = this.commonUtils.setDateOnDatePicker(this.judgesOnTheCase[0].lifeCycle.beginEffectiveDate);
      }
    });
  }


  filterBySectionDiscipline() {
    console.log("Selected discipline: ", this.selectedDiscipline);
    console.log("Selected section: ", this.selectedSection);
    this.searchCriteria = null;
    let url = null;
    // If only discipline is selected
    if ((this.selectedDiscipline && this.selectedDiscipline !== 'all') && (!this.selectedSection || this.selectedSection === 'all')) {
      url = `?${PtabTrialConstants.PANEL.DISCIPLINE}${this.selectedDiscipline}`;
    }

    // If only section is selected
    if ((this.selectedSection && this.selectedSection !== 'all') && (!this.selectedDiscipline || this.selectedDiscipline === 'all')) {
      url = `?${PtabTrialConstants.PANEL.SECTION}${this.selectedSection}`;
    }

    // If both are selected
    if (this.selectedSection && this.selectedSection !== 'all' && this.selectedDiscipline && this.selectedDiscipline !== 'all') {
      url = `?${PtabTrialConstants.PANEL.SECTION}${this.selectedSection}&${PtabTrialConstants.PANEL.DISCIPLINE}${this.selectedDiscipline}`;
    }

    // If none are selected
    if ((!this.selectedSection || this.selectedSection === 'all') && (!this.selectedDiscipline || this.selectedDiscipline === 'all')) {
      this.judgeList = [...this.fullJudgeList];
      this.getJudgeList();
    } else {
      this.trialsService.getFilteredList(url).subscribe((filteredListResponse) => {
        this.judgeList = filteredListResponse.listofJudges;
        this.removePaneledJudgesFromList();
        this.fullJudgeList = [...this.judgeList];
      }, (filteredListFailure) => {
          this.judgeList = [];
          this.fullJudgeList = [...this.judgeList];
      })
    }
  }


  removePaneledJudgesFromList() {
    for (let i = 0; i < this.judgeList.length; i++) {
      this.judgesOnTheCase.forEach((judge) => {
        if (judge.identifier === this.judgeList[i].identifier) {
          this.judgeList.splice(i, 1);
        }
      })
    };
  }


  close(refreshValue) {
    if (this.paneling.title.toLowerCase() === 'assign') {
      if (this.judgesOnTheCase.length > 0) {
        this.openAbandonChangesModal();
      }  else {
        this.paneling.isConfirm = refreshValue;
        this.modalService.hide();
      }
    } else if (this.paneling.title.toLowerCase() === 'update') {
      console.log(this.panelingDate);
      if (!this.checkIfJudgesAreEqual(this.originalJudgesOnTheCase, this.judgesOnTheCase) || (this.panelingDate !== this.originalPanelingDate)) {
        this.openAbandonChangesModal();
      } else {
        this.paneling.isConfirm = refreshValue;
        this.modalService.hide();
      }
    }
  }


  checkIfJudgesAreEqual(a, b) {
     return Array.isArray(a) &&
    Array.isArray(b) &&
    a.length === b.length &&
    a.every((val, index) => val === b[index]);
  }


  addJudgesToPanel() {
    this.judgeList = this.judgeList.filter((judge) => {
      return !this.selectedJudges.includes(judge);
    });
    this.judgesOnTheCase = this.judgesOnTheCase.concat(this.selectedJudges);
    this.activeJudgeCount = this.activeJudgeCount + this.selectedJudges.length;
    // this.activeJudgeCount++;
    this.selectedJudges = [];
    this.showLessThanThreeJudgeMessage = this.activeJudgeCount < 3;
  }


  removeJudgeFromPanel(judgesToRemove) {
    if (judgesToRemove) {
      if (Array.isArray(judgesToRemove) && judgesToRemove.length > 0) {
        this.judgesToRemove = [...this.judgesOnTheCase];
        this.judgeList = this.judgeList.concat(judgesToRemove);
        this.judgesOnTheCase = [];
        this.activeJudgeCount = 0;
        this.showLessThanThreeJudgeMessage = this.activeJudgeCount < 3;
      } else {
        // this.judgeList.push(judgesToRemove);
        // this.fullJudgeList.push(judgesToRemove);
        this.judgesOnTheCase.splice(this.judgesOnTheCase.indexOf(judgesToRemove), 1);
        if (judgesToRemove && !judgesToRemove.activeJudgeIndicator || judgesToRemove.activeJudgeIndicator.toLowerCase() === 'y') {
          this.activeJudgeCount--;
        }
        if (judgesToRemove && judgesToRemove.activeJudgeIndicator && judgesToRemove.activeJudgeIndicator.toLowerCase() === 'n') {
          this.inactiveJudgesList.splice(this.inactiveJudgesList.indexOf(judgesToRemove));
          this.inactiveJudgeOnPanel = this.inactiveJudgesList.length === 0;

        }
        this.showLessThanThreeJudgeMessage = this.activeJudgeCount < 3;
        this.filterBySectionDiscipline();
      }
      // this.searchForJudge();
    }
  }

  moveJudge(judgeIndex, direction) {
    const destination = direction.toLowerCase() === 'up' ? judgeIndex - 1 : judgeIndex + 1;
      let temp = this.judgesOnTheCase[destination];
      this.judgesOnTheCase[destination] = this.judgesOnTheCase[judgeIndex];
      this.judgesOnTheCase[judgeIndex] = temp;
      // return itemsList;
  }


  searchForJudge() {
    if (this.searchCriteria && this.searchCriteria.trim() !== "") {
      this.judgeList = this.fullJudgeList.filter((judge) => {
        if (judge && judge.prefferedName) {
          return judge.prefferedName.toLowerCase().includes(this.searchCriteria.toLowerCase());
        } else {
          return false;
        }
      });
      this.judgeList = this.judgeList.filter((judge) => {
        return !this.judgesOnTheCase.includes(judge);
      });
    } else {
      this.judgeList = this.fullJudgeList.filter((judge) => {
        return !this.judgesOnTheCase.includes(judge);
      });
    }
  }

  // verifySubmitPanel() {
  //   if (this.judgesOnTheCase.length < 3) {
  //     let modal = {
  //       infoText: ['You are submitting this panel with less than three (3) judges.', 'Do you want to continue?'],
  //       title: "Minimum judge panel",
  //       showLeftBtn: true,
  //       leftBtnClass: 'btn-default',
  //       leftBtnLabel: 'Back',
  //       showRightBtn: true,
  //       rightBtnClass: 'btn-primary',
  //       rightBtnLabel: 'Yes, proceed',
  //       isConfirm: false,
  //       modalHeight: 120
  //     }
  //     this.openConfirmModal(modal, 'submit');
  //  }
  // }

  verifyClearPanel() {
    let modal: InfoModalModel = {
      infoText: ["Clearing panel will remove the case from the currently assigned judges' dockets. The case will return to the pending paneling widget.", 'Do you want to continue?'],
      title: "Clear panel?",
      showLeftBtn: true,
      leftBtnClass: 'btn-default',
      leftBtnLabel: 'Back',
      showRightBtn: true,
      rightBtnClass: 'btn-primary',
      rightBtnLabel: 'Yes, clear panel',
      isConfirm: false,
      modalHeight: 120
    }
    this.openConfirmModal(modal, 'clear');
  }


  openConfirmModal(modal, action) {
    let response = this.commonUtils.openConfirmModal(modal);
    response.onHide.subscribe((reason: string | any) => {
      console.log('reason: ', reason);
      if (reason.initialState.modal.isConfirm) {
        if (action.toLowerCase() === 'clear') {
          this.judgesToRemove = [...this.originalJudgesOnTheCase];
          this.clearPanel(false);
        }
      }
    })
  };

  openAbandonChangesModal() {
    let response = this.commonUtils.openAbandonChangesModal('You have made changes to the panel that have not been saved or submitted.');
     response.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        this.modalService.hide();
      }
    })
  }


  verifySubmitOrUpdate() {
    if (this.paneling.title.toLowerCase() === 'update') {
      this.checkForRemovedJudges();
    } else {
      this.submitPanel();
    }
  }


  checkForRemovedJudges() {
    let originalJudgeList = [...this.originalJudgesOnTheCase];
    // this.judgesOnTheCase.forEach((judge) => {
    //   for (let i = 0; i < originalJudgeList.length; i++) {
    //     if (judge.identifier === originalJudgeList[i].identifier) {
    //       originalJudgeList.splice(i, 1);
    //     }
    //   }
    // });
    if (originalJudgeList.length > 0) {
      this.judgesToRemove = originalJudgeList;
      let proceedToAdd = this.paneling.title.toLowerCase() === 'update';
      this.clearPanel(proceedToAdd);
    } else {
      this.submitPanel();
    }
  }

  submitPanel() {

    const caseToPanel = this.setPanelPayload(this.judgesOnTheCase);
//     console.log("Submitting panel: ", this.judgesOnTheCase);
//     console.log("Paneling date: ", this.panelingDate);
//     const panelDate = this.commonUtils.convertDatePickerToEpoch(this.panelingDate);
//     let listofJudges = [];
//     let currentTime = Date.now();
//     let audit = {
//       "lastModifiedTimestamp": currentTime,
//       "lastModifiedUserIdentifier": this.loggedInUser.loginId,
//       "createUserIdentifier": this.loggedInUser.loginId,
//       "createTimestamp": currentTime
//     };
//     let lifeCycle = {
//       "beginEffectiveDate": panelDate
//     };
//     for (let i = 0; i < this.judgesOnTheCase.length; i++) {
//       let tempJudge = {
//         "identifier": this.judgesOnTheCase[i].identifier,
//         "rank": i + 1,
//         "role": "APJ",
//         "lifeCycle": lifeCycle,
//          "audit": audit
//       }
//       listofJudges.push(tempJudge);
//     }
//     let caseToPanel = {
//       "caseNo": this.paneling.caseToPanel.proceedingNumber,
//       "caseType": "TRIALS",
//       "listofJudges": listofJudges
//     }
//     console.log("CaseToPanel: ", caseToPanel);

    this.trialsService.assignPanelToCase(caseToPanel).subscribe((assignPanelSuccess) => {
      console.log('assignPanelSuccess: ', assignPanelSuccess);
      this.commonUtils.setToastr('success', 'Panel info saved');
      this.paneling.isConfirm = true;
      this.modalService.hide();
    }, (assignPanelFailure) => {
        console.log('assignPanelFailure: ', assignPanelFailure);
        this.commonUtils.setToastr('error', assignPanelFailure.error.message);
    });
  }


  clearPanel(proceedToAdd) {
    //judgesToRemove
    const caseToPanel = this.setPanelPayload(this.judgesToRemove);

    this.trialsService.clearPanel(caseToPanel).subscribe((assignPanelSuccess) => {
      console.log('assignPanelSuccess: ', assignPanelSuccess);
      if (!proceedToAdd) {
        this.commonUtils.setToastr("success", "Panel successfully cleared.");
        this.paneling.isConfirm = true;
        this.modalService.hide();
      } else {
        this.submitPanel();
      }
    }, (assignPanelFailure) => {
        console.log('assignPanelFailure: ', assignPanelFailure);
        this.commonUtils.setToastr("error", assignPanelFailure.error.message);
    });
  }


  deleteInactiveJudge(inactiveJudge) {
      let modal: InfoModalModel = {
        infoText: ["You are about to remove the inactive judge from the panel.", 'Do you want to continue?'],
        title: "Remove inactive judge?",
        showLeftBtn: true,
        leftBtnClass: 'btn-default',
        leftBtnLabel: 'Back',
        showRightBtn: true,
        rightBtnClass: 'btn-primary',
        rightBtnLabel: 'Yes, remove judge',
        isConfirm: false,
        modalHeight: 120
      }

      let response = this.commonUtils.openConfirmModal(modal);
      response.onHide.subscribe((reason: string | any) => {
        console.log('reason: ', reason);
        if (reason.initialState.modal.isConfirm) {
          let judgeToRemove = [];
          judgeToRemove.push(inactiveJudge);
          const caseToPanel = this.setPanelPayload(judgeToRemove);
          console.log('caseToPanel: ', caseToPanel);
          this.trialsService.clearPanel(caseToPanel).subscribe((assignPanelSuccess) => {
            console.log('assignPanelSuccess: ', assignPanelSuccess);
              this.commonUtils.setToastr("success", "Successfully removed inactive judge.");
            this.paneling.isConfirm = true;
            this.getPaneledJudges();
            this.getCaseInfo();
          }, (assignPanelFailure) => {
              console.log('assignPanelFailure: ', assignPanelFailure);
              this.commonUtils.setToastr("error", assignPanelFailure.error.message);
          });
        }
      })




  }


  setPanelPayload(panelList) {
    const panelDate = this.commonUtils.convertDatePickerToEpoch(this.panelingDate);
    let listofJudges = [];
    let currentTime = Date.now();
    let audit = {
      "lastModifiedTimestamp": currentTime,
      "lastModifiedUserIdentifier": this.loggedInUser.loginId,
      "createUserIdentifier": this.loggedInUser.loginId,
      "createTimestamp": currentTime
    };
    let lifeCycle = {
      "beginEffectiveDate": panelDate
    };
    for (let i = 0; i < panelList.length; i++) {
      let tempJudge = {
        "identifier": panelList[i].identifier,
        "rank": i + 1,
        "role": "APJ",
        "lifeCycle": lifeCycle,
         "audit": audit
      }
      listofJudges.push(tempJudge);
    }
    let caseToPanel = {
      "caseNo": this.paneling.caseToPanel.proceedingNumber ? this.paneling.caseToPanel.proceedingNumber : this.paneling.caseToPanel.proceedingNo,
      "caseType": "TRIALS",
      "listofJudges": listofJudges
    }
    return caseToPanel;
  }



  openHistoryModal() {
    const initialState = {
      panelHistory: {
        isConfirm: false,
        proceedingNo: this.paneling.caseToPanel.proceedingNo
      }
    };
    this.modalRef = this.modalService.show(PanelHistoryComponent, {
      animated: true,
      backdrop: true,
      ignoreBackdropClick: true,
      id: 1,
      class: 'panel-history-modal-content second-modal',
      initialState
    });
    this.commonUtils.setSecondModalBackgroundColor();
    this.modalRef.onHide.subscribe((reason: string | any) => {
      console.log('reason: ', reason);
      if (reason.initialState.panelHistory.isConfirm) {
        this.modalService.hide();
      }
    })

  }



}
