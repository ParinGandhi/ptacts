import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { provideMockStore } from '@ngrx/store/testing';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';

import { WorkspacesComponent } from './workspaces.component';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

/**
 * 81.82%
 */
describe('WorkspacesComponent', () => {
  let component: WorkspacesComponent;
  let modalService: BsModalService;
  let fixture: ComponentFixture<WorkspacesComponent>;

  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "08423235",
        caseNumber: "2020005372"
      }
    }
  }

  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => {},
    error: (
      message?: string,
      title?: string
    ) => {},
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [WorkspacesComponent],
      providers: [
        DatePipe,
        CommonUtilitiesService,
        provideMockStore({
          selectors: [
            { selector: CaseViewerSelectors.caseInfoData, value: { proceedingNo: '37553565' } },
            {selector: CaseViewerSelectors.userInfoData,value:{caseDetailsData: []}}
          ]
        }),
        {
        provide: ActivatedRoute,
        useValue: activatedRouteMock
        },
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useValue: {}
        },
        {
          provide: ToastrService,
          useValue: toastrService
        }]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkspacesComponent);
    modalService = TestBed.inject(BsModalService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
