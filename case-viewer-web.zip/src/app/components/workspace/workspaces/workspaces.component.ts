import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import * as CaseViewerActions from 'src/app/store/case-viewer/case-viewer.actions';
import { Store, select } from '@ngrx/store';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';

@Component({
  selector: 'app-workspaces',
  templateUrl: './workspaces.component.html',
  styleUrls: ['./workspaces.component.less']
})

export class WorkspacesComponent implements OnInit {

  caseInfo: CaseInfoModel = {
    serialNo: null,
    proceedingNo: null
  };
  loggedInUser: any;
  loggedInUser$ = this.store.pipe(select(CaseViewerSelectors.userInfoData));

  isPanelMember: boolean = false;
  isSplAdmin: boolean = false;
  isJudge: boolean = false;
  isPl: boolean = false;

  constructor(
    public router: Router,
    private activatedRoute: ActivatedRoute,
    private store: Store<CaseViewerState>,
    private commonUtils: CommonUtilitiesService
  ) { }

  ngOnInit(): void {
    this.store.select(CaseViewerSelectors.userInfoData).subscribe(data => {
      this.isSplAdmin = data.isSplAdmin;
      this.isJudge = data.isJudge;
      this.isPl = data.isPl;
      this.loggedInUser = data.caseDetailsData[0];
      if (!this.loggedInUser) {
        this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
      }
      this.isPanelMember = this.commonUtils.checkIfPanelingMember(this.loggedInUser);
    });

    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber'],
      scrollToId: this.activatedRoute.snapshot.params['scrollToId']
    };
    this.store.dispatch(CaseViewerActions.setCaseInfoAction({payload:this.caseInfo}));
  }


  /*istanbul ignore next*/
  ngAfterViewInit(): void {
    setTimeout(() => {
    let arrays =  document.getElementsByClassName('workspaceTabs') as HTMLCollectionOf<HTMLLinkElement>;
    for (const tag of Array.from(arrays)) {
      tag.classList.remove('active')
    }
    let worktabPan = document.getElementsByClassName('workspaceTabCon') as HTMLCollectionOf<HTMLLinkElement>;
    for (const workP of Array.from(worktabPan)) {
      workP.classList.remove('active')
    }
    if(this.caseInfo.scrollToId == 'aiaSearch') {
      document.getElementById('aiaSearchTab')?.classList.add('active');

    }else if (this.activatedRoute.snapshot.params['scrollToId'] == 'aiaTrialsWorkspaces') {
      document.getElementById('workspaceTab')?.classList.add('active');
    }else if (this.activatedRoute.snapshot.params['scrollToId'] == 'aiaAllReviews') {
      document.getElementById('allReviewsTab')?.classList.add('active');
    }
    else if (this.activatedRoute.snapshot.params['scrollToId'] == 'allInitiatedPetitions') {
      document.getElementById('initiatedTab')?.classList.add('active');
    }
    else if (this.activatedRoute.snapshot.params['scrollToId'] == 'reports') {
      document.getElementById('reports')?.classList.add('active');
    }
    
    document.getElementById(`${this.activatedRoute.snapshot.params['scrollToId']}`)?.classList.add('active')
  }, 300);
  }

/*istanbul ignore next*/
  setActiveTab(tabId) {
    let allTabs = document.querySelectorAll('.workspaceTabs');

    for (let i = 0; i < allTabs.length; i++) {
      console.log('allTabs: ', allTabs[i]);
    }
  }

  redirect(scrollToId) {
    
    let caseInfo = JSON.parse(JSON.stringify(this.caseInfo));
    caseInfo.scrollToId = scrollToId;
 
    // window.sessionStorage.setItem('caseInfo', JSON.stringify(this.caseInfo));
    let path = [`/aiaTrialsWorkspace/${caseInfo.scrollToId}`];
    this.router.navigate(path);

  }


}
