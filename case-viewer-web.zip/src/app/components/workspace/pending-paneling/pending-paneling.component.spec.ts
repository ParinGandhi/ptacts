import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { TrialsService } from 'src/app/services/trials.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DatePipe } from '@angular/common';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { OpenCaseviewerComponent } from '../../common/open-caseviewer/open-caseviewer.component';
import { PanelingComponent } from '../modals/paneling/paneling.component';
import { ImportPanelComponent } from '../modals/import-panel/import-panel.component';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { ToastrService } from 'ngx-toastr';

import { PendingPanelingComponent } from './pending-paneling.component';
import { of } from 'rxjs/internal/observable/of';
import { AgGridModule } from 'ag-grid-angular';
import { ColumnApi, GridApi, GridOptions } from 'ag-grid-community';
import { throwError } from 'rxjs';

/**
 * 61.82%
 */
describe('PendingPanelingComponent', () => {
  let component: PendingPanelingComponent;
  let fixture: ComponentFixture<PendingPanelingComponent>;
  let trialsService: TrialsService;
  let gridHelper: GridHelperService;
  let modalService: BsModalService;
  let commonUtils: CommonUtilitiesService;
  let toastr: ToastrService;
  let gridOptions: GridOptions = <GridOptions>{};

  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => {},
    error: (
      message?: string,
      title?: string
    ) => {},
  };

  const pendingPanelingMock = {
    "ptabReadOnlyUser": true,
    "proceedings": [{
      "patentOwner": "Esquivia-Lee et al",
      "nofda": "2017-10-14 00:00:00.0",
      "petitionerRealParty": null,
      "proceedingNumber": "DER2018-00002",
      "patentNumber": "5454545",
      "poRealParty": null,
      "submittedDate": null,
      "petitioner": null
    },
    {
      "patentOwner": null,
      "nofda": "2020-10-09 00:00:00.0",
      "petitionerRealParty": null,
      "proceedingNumber": "IPR2020-01458",
      "patentNumber": "9859464",
      "poRealParty": null,
      "submittedDate": null,
      "petitioner": null
    },
    {
      "patentOwner": null,
      "nofda": "2020-09-11 00:00:00.0",
      "petitionerRealParty": null,
      "proceedingNumber": "IPR2020-01617",
      "patentNumber": "10340637",
      "poRealParty": null,
      "submittedDate": null,
      "petitioner": null
    },
    {
      "patentOwner": null,
      "nofda": "2020-09-23 00:00:00.0",
      "petitionerRealParty": null,
      "proceedingNumber": "IPR2020-01660",
      "patentNumber": "9982179",
      "poRealParty": null,
      "submittedDate": null,
      "petitioner": null
    },
    {
      "patentOwner": null,
      "nofda": "2020-08-27 00:00:00.0",
      "petitionerRealParty": null,
      "proceedingNumber": "IPR2020-01527",
      "patentNumber": "10200648",
      "poRealParty": null,
      "submittedDate": null,
      "petitioner": null
    }]
  };



  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "08423235",
        caseNumber: "2020005372"
      }
    }
  };


  const gridApiMock = {
    setFilterModel: () => { },
    getDisplayedRowCount: () => {
      return 5;
    },
    getFilterModel: () => {
      const filterModelMock = {
        status: {
          filter: "n",
          filterType: "text",
          type: "contains"
        }
      }
      return filterModelMock;
    },
    exportDataAsCsv: () => { },
    getSelectedRows: () => { }
  };


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, AgGridModule.withComponents([])],
      declarations: [PendingPanelingComponent, OpenCaseviewerComponent, PanelingComponent, ImportPanelComponent],
      providers: [
        DatePipe,
        TrialsService,
        BsModalService,
        GridHelperService,
        {
          provide: CommonUtilitiesService,
          useValue: commonUtils
        },
        {
          provide: ToastrService,
          useValue: toastrService
        },
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        },
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useValue: {}
        }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PendingPanelingComponent);
    trialsService = TestBed.inject(TrialsService);
    gridHelper = TestBed.inject(GridHelperService)
    modalService = TestBed.inject(BsModalService);
    commonUtils = TestBed.inject(CommonUtilitiesService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should call getPendingPaneling and return successResponse', () => {
    spyOn(trialsService, 'getPendingPanelingCases').and.returnValue(of(pendingPanelingMock));
    expect(component.gridRefreshValues.showLoading).toBeTrue();
    component.getPendingPanelingCases();
    expect(component.rowData).toEqual(pendingPanelingMock.proceedings);
    expect(component.gridRefreshValues.showLoading).toBeFalse();
    expect(component.gridRefreshValues.lastRefresh).toBeTruthy();
  });


  it('should call getPendingPaneling and return failure', () => {
    spyOn(trialsService, 'getPendingPanelingCases').and.returnValue(throwError(""));
    component.getPendingPanelingCases();
    expect(component.gridRefreshValues.refreshFailed ).toBeTrue();
    expect(component.gridRefreshValues.showLoading).toBeFalse();
    expect(component.gridRefreshValues.lastRefresh).toBeTruthy();
  });


  it('should invoke onFilterChanged', () => {
    const data = {
      api: component.gridApi,
      columnApi: component.gridColumnApi
    }
    component.gridApi = gridApiMock;
    component.onFilterChanged();
    fixture.detectChanges();
  });


  it('should export data as csv', () => {
    const data = {
      api: component.gridApi,
      columnApi: component.gridColumnApi
    }
    component.gridApi = gridApiMock;
    component.exportDataAsCsv();
    fixture.detectChanges();
  });


  it('should call onRowSelected', () => {
    component.gridApi = gridApiMock;
    component.onRowSelected();
    fixture.detectChanges();
  });


  it('should clear filters', () => {
    component.gridApi = gridApiMock;
    component.clearGridFilters();
    fixture.detectChanges();
  });


  // it('should call openAssignPanelModal', () => {
  //   const initialState: any = {
  //     paneling: {
  //       title: 'Assign',
  //       showClearPanelBtn: false,
  //       isConfirm: false,
  //       caseToPanel: pendingPanelingMock
  //     }
  //   };
  //   let modalServiceMock = modalService.show(PanelingComponent, {
  //     animated: true,
  //     backdrop: true,
  //     ignoreBackdropClick: true,
  //     class: 'md-lg',
  //     initialState
  //   })
  //   // modalService.show = (): BsModalRef => {
  //   //   return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
  //   //     animated: true,
  //   //     backdrop: 'static',
  //   //     class: 'modal-audit-size',
  //   //     initialState
  //   //   }}
  //   // }
  //   spyOn(commonUtils, 'openModal').and.returnValue(of(modalServiceMock);
  //   component.openAssignPanelingModal();
  // });


  // it('should call onRowSelected', () => {
  //   component.selectedCaseToPanel = ["Testing"];
  //   const gridParamsMock = {
  //     api: new GridApi(),
  //     columnApi: new ColumnApi()
  //   }
  //   component.gridApi = new GridApi();
  //   console.log("*****TEST GRIDAPI *****", component.gridApi);
  //   // component.gridApi.getSelectedRows = function () {
  //   //   return [];
  //   // }
  //   component.onRowSelected(gridParamsMock);

  //   expect(component.selectedCaseToPanel.length).toBe(0);
  //   // expect(component.gridColumnApi).not.toBeNull();
  //   // expect(component.gridApi.).toEqual(gridParamsMock.api);
  // })


  // it('should call exportDataAsCsv', () => {
  //   component.exportDataAsCsv();
  //   expect(gridHelper.exportDataAsCsv).toHaveBeenCalled();
  // })

});
