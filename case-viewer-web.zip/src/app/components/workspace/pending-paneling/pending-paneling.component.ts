import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { OpenCaseviewerComponent } from '../../common/open-caseviewer/open-caseviewer.component';
import { PanelingComponent } from '../modals/paneling/paneling.component';
import { ImportPanelComponent } from '../modals/import-panel/import-panel.component';

import { GridHelperService } from '../../../services/grid-helper.service';
import { TrialsService } from '../../../services/trials.service';
import { CommonUtilitiesService } from '../../../services/common-utilities.service';

import GridRefreshModel from '../../../models/common/GridRefresh.model';
import CaseInfoModel from '../../../models/CaseInfo.model';
import { Store, select } from '@ngrx/store';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';

@Component({
  selector: 'app-pending-paneling',
  templateUrl: './pending-paneling.component.html',
  styleUrls: ['./pending-paneling.component.less']
})
export class PendingPanelingComponent implements OnInit {

  /**
   *  Grid
   */
  gridApi;
  gridColumnApi;
  noRowsTemplate = "No cases have been promoted for paneling";

  defaultColDef = {
    filter: true,
    sortable: true,
    floatingFilter: true,
    suppressMenu: true,
    headerCheckboxSelection: this.isFirstColumn,
      checkboxSelection: this.isFirstColumn,
  };

  rowSelection = 'single';
  showLoading = false;

  gridRefreshValues: GridRefreshModel = {
    refreshFailed: false,
    showLoading: false,
    lastRefresh: null
  }

  columnDefs = [
    {
      headerName: '',
      field: '',
      width: 25,
      minWidth: 25,
      maxWidth: 25,
      resizable: false,
      floatingFilter: false,
      headerCheckboxSelection: false,
      cellStyle: {'background-color': '#F0F0EE'}
    },
    {
      headerName: 'Date submitted',
      field: 'submittedDateStr',
      width: 190,
      minWidth: 190,
      maxWidth: 190,
      resizable: true,
      comparator: this.gridHelper.dateComparator,
      headerCheckboxSelection: false,
      tooltipField: 'Date submitted',
      sort: 'asc',
      type: 'timestamp'
    },
    {
      headerName: 'AIA Review #',
      field: 'proceedingNumber',
      width: 130,
      minWidth: 130,
      maxWidth: 130,
      resizable: true,
      cellRendererFramework: OpenCaseviewerComponent,
      tooltipField: 'AIA Review #'
    },
    {
      headerName: 'PO patent # / Application #',
      valueGetter: this.gridHelper.valueGetterForPendingPanelingPatentNo,
      // field: 'patentNumber',
      width: 150,
      minWidth: 150,
      maxWidth: 150,
      resizable: true
    },
    {
      headerName: 'Petitioner patent # / Application #',
      valueGetter: this.gridHelper.valueGetterPendingPanelingPetitionerNo,
      // field: 'petitionerPatentNo',
      width: 175,
      minWidth: 175,
      maxWidth: 175,
      resizable: true
    },
    // {
    //   headerName: 'Petitioner',
    //   field: 'petitioner',
    //   resizable: true,
    //   wrapText: false,
    //   autoHeight: false
    // },
    // {
    //   headerName: 'Patent owner',
    //   field: 'patentOwner',
    //   resizable: true,
    //   wrapText: false,
    //   autoHeight: false
    // },
    {
      headerName: 'Petitioner real party',
      field: 'petitionerRealParty',
      resizable: true,
      wrapText: false,
      minWidth: 170,
      width: 380,
      autoHeight: false
    },
    {
      headerName: 'Patent owner real party',
      field: 'poRealParty',
      resizable: true,
      minWidth: 170,
      width: 380,
      wrapText: false,
      autoHeight: false
    },
    {
      headerName: 'NOFDA',
      field: 'nofdaStr',
      width: 146,
      minWidth: 146,
      maxWidth: 146,
      resizable: true,
      wrapText: false,
      autoHeight: false,
      type: 'date'
    }
  ];

  rowData: Array<any> = [];


  isLoading = false;
  refreshFailed = false;
  lastRefresh: any = null;
  selectedCaseToPanel: Array<any> = [];
  numberOfFilters = 0;
  caseInfo: CaseInfoModel;

  loggedInUser$ = this.store.pipe(select(CaseViewerSelectors.userInfoData));
  autoRefresh: boolean = false;
  colState: any;


  constructor(
    private activatedRoute: ActivatedRoute,
    private trialsService: TrialsService,
    private gridHelper: GridHelperService,
    private commonUtils: CommonUtilitiesService,
    private store: Store
  ) { }


  ngOnInit(): void {
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };
    this.getPendingPanelingCases();
    // setInterval(()=>{
    //   this.colState = this.gridApi.getFilterModel();
    //   this.gridRefreshValues.showLoading = false;
    //   this.autoRefresh = true;
    //   this.getPendingPanelingCases();
    // },300000)
  }


  getPendingPanelingCases() {
    if(this.autoRefresh){
      this.gridRefreshValues.showLoading = false;
      }else{
        this.gridRefreshValues.showLoading = true;
      }
    this.trialsService.getPendingPanelingCases().subscribe((pendingPanelingCases) => {
      pendingPanelingCases.proceedings.forEach(element => {
        // element.submittedDateStr = element.submittedDate ? this.gridHelper.convertDateToTimeStamp(element.submittedDate) : null;
        // element.nofdaStr = element.nofda ? this.gridHelper.convertDateToString(element.nofda) : null;
        element.submittedDateStr = this.commonUtils.parseKeyDates(element.mileStoneDataJson, "Filing Date");
        element.nofdaStr = this.commonUtils.parseKeyDates(element.mileStoneDataJson, "Notice of Accorded Filing Date");
      });
      this.rowData = pendingPanelingCases.proceedings;
      this.gridRefreshValues.showLoading = false;
      this.gridRefreshValues.lastRefresh = Date.now()
      if(this.colState){
        setTimeout(() => {
          this.gridApi.setFilterModel(this.colState);
        }, 100);
      }
      this.autoRefresh = false;
      this.lastRefresh = new Date();
    }, () => {
        this.gridRefreshValues.refreshFailed = true;
        this.gridRefreshValues.showLoading = false;
        this.gridRefreshValues.lastRefresh = Date.now();
    })
  }

/* istanbul ignore next */
  openAssignPanelingModal() {
    const initialState = {
      paneling: {
        title: 'Assign',
        showClearPanelBtn: false,
        isConfirm: false,
        caseToPanel: this.selectedCaseToPanel[0]
      }
    };
    const response = this.commonUtils.openModal(PanelingComponent, initialState, 'add-update-parties-modal-content')
    response.onHide.subscribe((reason: string | any) => {
      console.log('reason: ', reason);
      if (reason.initialState.paneling.isConfirm) {
        this.getPendingPanelingCases();
      }
    })
  }

/* istanbul ignore next */
  openImportPanelModal() {
    const initialState = {
      importPanel: {
        title: 'AIA Trial panel bulk import',
        isConfirm: false,
        height: 190
      }
    };
    const response = this.commonUtils.openModal(ImportPanelComponent, initialState, 'modal-md');
    response.onHide.subscribe((reason: string | any) => {
      console.log('reason: ', reason);
      if (reason.initialState.importPanel.isConfirm) {
        this.getPendingPanelingCases();
      }
    })
  }


  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }


  onRowSelected() {
    this.selectedCaseToPanel = this.gridApi.getSelectedRows();

  }

  onFilterChanged() {
    console.log("On filter changed: ", this.gridApi.getDisplayedRowCount());
    const filterModel = this.gridApi.getFilterModel();
    this.numberOfFilters = Object.keys(filterModel).length;
  }



  isFirstColumn(params) {
    const displayedColumns = params.columnApi.getAllDisplayedColumns();
    const thisIsFirstColumn = displayedColumns[0] === params.column;
    return thisIsFirstColumn;
  }



  clearGridFilters() {
    this.gridApi.setFilterModel(null);
  }


  exportDataAsCsv() {
    const fileName = `AIA Trials Pending Paneling`;
    this.gridHelper.exportDataAsCsv(this.gridApi, fileName);
  }

}
