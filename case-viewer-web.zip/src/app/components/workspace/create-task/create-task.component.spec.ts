import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Store } from '@ngrx/store';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { BsModalService } from 'ngx-bootstrap/modal';
import { provideMockStore } from '@ngrx/store/testing';
import { ToastrService } from 'ngx-toastr';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { JpViewService } from 'src/app/services/jpview.service';
import { TrialsService } from 'src/app/services/trials.service';
import * as CaseViewerSelectors  from 'src/app/store/case-viewer/case-viewer.selectors';
import { ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CreateTaskComponent } from './create-task.component';
import { of } from 'rxjs';

fdescribe('CreateTaskComponent', () => {
  let component: CreateTaskComponent;
  let fixture: ComponentFixture<CreateTaskComponent>;
  let assignToListSuccess;
  let toastr:ToastrService;
  let reason;
  const responseList = {"assigneeData":[{}]};
  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => {},
    error: (
      message?: string,
      title?: string
    ) => {},
  };
  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "08423235",
        caseNumber: "IPR2014-00355"
      }
    }
	};
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [CreateTaskComponent],
      providers: [
        provideMockStore({
          selectors: [{ selector: CaseViewerSelectors.userInfoData, value: { caseDetailsData: [] } },
          {selector: CaseViewerSelectors.userInfoData,value:{caseDetailsData: [{
            activeIn: "Active",
            apjSeniorityRank: 85,
            disiplanceCd: "Electrical",
            emailAddress: "Test_Jennifer.Bisk@USPTO.GOV",
            firstName: "Jennifer",
            fullName: "Bisk, Jennifer S.",
            jobClassificationCode: "APJ",
            lastName: "Bisk",
            leadApjIndicator: "APJ1",
            loginId: "jbisk",
            preferredFullName: "Bisk, Jennifer S.",
            privileges: null,
            roleDescription: "Judge",
            trialJudgeIndicator: "Judge",
            userIdentiifier: 5017,
            userWorkerNumber: "88548",
            isAdmin: false
            }]}}]
        }),
        TrialsService,        {
          provide: ToastrService,
          useValue: toastrService
        },

        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        }
      ]
    })
    .compileComponents();
  });

  beforeEach( () => {
    const storeStub = () => ({});
    const bsModalRefStub = () => ({});
    const bsModalServiceStub = () => ({ hide: () => ({}) });
    const toastrServiceStub = () => ({
      success: (string, string1, object) => ({}),
      error: (message, string, object) => ({})
    });
    const commonUtilitiesServiceStub = () => ({
      setDateOnDatePicker: assignmentDate => ({}),
      openAbandonChangesModal: string => ({
        onHide: { pipe: () => ({ subscribe: f => f({}) }) }
      }),
      convertDatePickerToEpoch: taskRequestedDate => ({})
    });
    const jpViewServiceStub = () => ({
      getAssignToList: arg => ({ subscribe: f => f({}) })
    });
    const trialsServiceStub = () => ({
      getHeaderInfo: urlString => ({ subscribe: f => f({}) }),
      createTask: createObj => ({ subscribe: f => f({}) }),
      updateTask: updateObj => ({ subscribe: f => f({}) }),
      getAssignToList: arg => ({ subscribe: f => f({}) })
    });
     TestBed.configureTestingModule({
      imports: [FormsModule],
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [CreateTaskComponent],
      providers: [
        { provide: Store, useFactory: storeStub },
        { provide: BsModalRef, useFactory: bsModalRefStub },
        { provide: BsModalService, useFactory: bsModalServiceStub },
        { provide: ToastrService, useFactory: toastrServiceStub },
        {
          provide: CommonUtilitiesService,
          useFactory: commonUtilitiesServiceStub
        },
        { provide: JpViewService, useFactory: jpViewServiceStub },
        { provide: TrialsService, useFactory: trialsServiceStub }
      ]
    });
    fixture = TestBed.createComponent(CreateTaskComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });




  it(`assignToList has default value`, () => {
    expect(component.assignToList).toEqual([]);
  });

  it(`originalJudgesOnTheCase has default value`, () => {
    expect(component.originalJudgesOnTheCase).toEqual([]);
  });

  // it(`taskType has default value`, () => {
  //   expect(component.taskType).toEqual([, , ,]);
  // });

  it(`unsavedChanges has default value`, () => {
    expect(component.unsavedChanges).toEqual(false);
  });

  it(`saved has default value`, () => {
    expect(component.saved).toEqual(false);
  });

  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      component.assignToList = [];
      let obj =
        {
          id: 123,
          text: "test",
          activeTask: 4,
          userIdentifier: 345,
          selected: false
        };
        component.modal ={
          "loggedInUser":{
            "loginId":"akellogg"
          },
          "title":'Update',
          "workQueueInfo":{
          "poApplicationIdentifier":12345,
          "proceedingNumber":"IPR2020-00011",
          "assignmentDate":null,
          "taskRequested":null
        }}
      const commonUtilitiesServiceStub: CommonUtilitiesService = fixture.debugElement.injector.get(
        CommonUtilitiesService
      );
      assignToListSuccess = {"assigneeData": []}
       spyOn(component, 'getAssignToList').and.returnValue()
      spyOn(component, 'getCaseHeaderInfo').and.callThrough();
      spyOn(
        commonUtilitiesServiceStub,
        'setDateOnDatePicker'
      ).and.callThrough();

     // spyOn(component, 'getAssignToList').and.callThrough();
      component.ngOnInit();
      component.getAssignToList();
      component.getCaseHeaderInfo({ serialNo: component.modal.workQueueInfo.poApplicationIdentifier, proceedingNo: component.modal.workQueueInfo.proceedingNumber });
      expect(component.getAssignToList).toBeDefined();
      expect(component.getCaseHeaderInfo).toBeDefined();
      expect(commonUtilitiesServiceStub.setDateOnDatePicker).toBeDefined();
    });
  });

  describe('openAbandonChangesModal', () => {
    it('makes expected calls', () => {
      reason={"initialState":{
        modal:{
          "isConfirm":true
        }
      }
    }
      const bsModalServiceStub: BsModalService = fixture.debugElement.injector.get(
        BsModalService
      );
      const commonUtilitiesServiceStub: CommonUtilitiesService = fixture.debugElement.injector.get(
        CommonUtilitiesService
      );


      spyOn(bsModalServiceStub, 'hide').and.callThrough();
      spyOn(
        commonUtilitiesServiceStub,
        'openAbandonChangesModal'
      ).and.callThrough();

      reason={"initialState":{
        modal:{
          "isConfirm":true
        }
      }};

      component.openAbandonChangesModal();
      expect(bsModalServiceStub.hide).toBeDefined();
      expect(
        commonUtilitiesServiceStub.openAbandonChangesModal
      ).toBeDefined();
    });
  });

  describe('getAssignToList', () => {
    it('makes expected calls', () => {

      component.modal= {
        "loggedInUser":{
          "loginId":"akellogg"
        },
        "workQueueInfo":{
          "taskIdentifier":123,
          "proceedingNumber":"IPR2020-00017",
          "taskTypeName":null,
          "customTaskText":null,
          "deadLineDate":null,
          "poApplicationIdentifier":3454335,
          "assigneeName":"test"
        }
      }
      let obj =
        {
          id: 123,
          text: "test",
          activeTask: 4,
          userIdentifier: 345,
          selected: false
        };
        component.assignToList = [obj];
      // const jpViewServiceStub: JpViewService = fixture.debugElement.injector.get(
        // JpViewService
      // );
      const trialsServiceStub: TrialsService = fixture.debugElement.injector.get(
        TrialsService
      );
      // spyOn(jpViewServiceStub, 'getAssignToList').and.returnValue(of(responseList));
      spyOn(trialsServiceStub, 'getAssignToList').and.returnValue(of(responseList));
      component.getAssignToList();
      // expect(jpViewServiceStub.getAssignToList).toBeDefined();
    });
  });


  describe('getCaseHeaderInfo', () => {
    it('makes expected calls', () => {
      component.taskType=[];
      component.modal= {
        "loggedInUser":{
          "loginId":"akellogg"
        },
        "workQueueInfo":{
          "taskIdentifier":123,
          "proceedingNumber":"IPR2020-00017",
          "taskTypeName":null,
          "customTaskText":null,
          "deadLineDate":null,
          "poApplicationIdentifier":3454335
        }
      }

      component.taskType = [
        {"code":"RP","description":"Reconcile petition"},
        {"code":"RMN","description":"Reconcile PO mandatory notices"},
        {"code":"RCP","description":"Review corrected petition"},
        {"code":"RRR","description":"Review refund request"},
       ]
      component.aiaReviewNumber = "123";
      component.selectedTaskType = "RRR";
      component.selectedAssign = "akellogg";
      const trialsServiceStub: TrialsService = fixture.debugElement.injector.get(
        TrialsService
      );
      spyOn(component, 'checkChange').and.callThrough();
      spyOn(trialsServiceStub, 'getHeaderInfo').and.callThrough();
      const caseInfo={
        serialNo:"FFDDS",
        proceedingNumber:"23455"
      };
      component.getCaseHeaderInfo(caseInfo);

    });
  });



  describe('changeTaskType', () => {
    it('makes expected calls', () => {
      component.taskType=[];
      component.modal= {
        "loggedInUser":{
          "loginId":"akellogg"
        },
        "workQueueInfo":{
          "taskIdentifier":123,
          "proceedingNumber":"IPR2020-00017",
          "taskTypeName":null,
          "customTaskText":null,
          "deadLineDate":null,
          "poApplicationIdentifier":3454335
        }
      }

      component.taskType = [
        {"code":"RP","description":"Reconcile petition"},
        {"code":"RMN","description":"Reconcile PO mandatory notices"},
        {"code":"RCP","description":"Review corrected petition"},
        {"code":"RRR","description":"Review refund request"},
       ]
      component.aiaReviewNumber = "123";
      component.selectedTaskType = "RRR";
      component.selectedAssign = "akellogg";
      spyOn(component, 'checkChange').and.callThrough();
      component.changeTaskType("RRR");

    });
  });


  describe('close', () => {
    it('makes expected calls', () => {
      component.taskType=[];
      component.modal= {
        "loggedInUser":{
          "loginId":"akellogg"
        },
        "workQueueInfo":{
          "taskIdentifier":123,
          "proceedingNumber":"IPR2020-00017",
          "taskTypeName":null,
          "customTaskText":null,
          "deadLineDate":null,
          "poApplicationIdentifier":3454335
        }
      }
      component.saved=false;
      component.close(false);

    });
  });




  describe('validateForm', () => {
    it('makes expected calls', () => {
      component.modal= {
        "loggedInUser":{
          "loginId":"akellogg"
        },
        "workQueueInfo":{
          "taskIdentifier":123,
          "proceedingNumber":"IPR2020-00017",
          "taskTypeName":null,
          "customTaskText":null,
          "deadLineDate":null,
          "poApplicationIdentifier":3454335
        }
      }
      component.aiaReviewNumber = "123";
      component.selectedTaskType = "RRR";
      component.selectedAssign = "akellogg";
      spyOn(component, 'checkFormModel').and.callThrough();
      component.validateForm();
      expect(component.checkFormModel).toBeDefined;
    });
  });

  describe('createTask', () => {
    it('makes expected calls', () => {
      component.modal= {
        "loggedInUser":{
          "loginId":"akellogg"
        },
        "workQueueInfo":{
          "taskIdentifier":123,
          "proceedingNumber":"IPR2020-00017",
          "taskTypeName":null,
          "customTaskText":null,
          "deadLineDate":null
        }
      };
      component.assignToList = component.assignToList = [{
          id: 123,
          text: "test",
          activeTask: 4,
          userIdentifier: 345,
          selected: false
        }];
      const toastrServiceStub: ToastrService = fixture.debugElement.injector.get(
        ToastrService
      );
      const commonUtilitiesServiceStub: CommonUtilitiesService = fixture.debugElement.injector.get(
        CommonUtilitiesService
      );
      const trialsServiceStub: TrialsService = fixture.debugElement.injector.get(
        TrialsService
      );
      spyOn(component, 'validateForm').and.callThrough();
      spyOn(component, 'close').and.callThrough();
      spyOn(toastrServiceStub, 'success').and.callThrough();
      spyOn(toastrServiceStub, 'error').and.callThrough();
      spyOn(
        commonUtilitiesServiceStub,
        'convertDatePickerToEpoch'
      ).and.callThrough();
      spyOn(trialsServiceStub, 'createTask').and.callThrough();
      component.createTask();
      expect(component.validateForm).toBeDefined();
      expect(component.close).toBeDefined();
      expect(toastrServiceStub.success).toBeDefined();
      expect(toastrServiceStub.error).toBeDefined();
      expect(
        commonUtilitiesServiceStub.convertDatePickerToEpoch
      ).toBeDefined();
      expect(trialsServiceStub.createTask).toBeDefined();
    });
  });

  describe('updateTask', () => {
    it('makes expected calls', () => {
      component.modal= {
        "loggedInUser":{
          "loginId":"akellogg"
        },
        "workQueueInfo":{
          "taskIdentifier":123,
          "proceedingNumber":"IPR2020-00017",
          "taskTypeName":null,
          "customTaskText":null,
          "deadLineDate":null
        }
      }
      const toastrServiceStub: ToastrService = fixture.debugElement.injector.get(
        ToastrService
      );
      const commonUtilitiesServiceStub: CommonUtilitiesService = fixture.debugElement.injector.get(
        CommonUtilitiesService
      );
      const trialsServiceStub: TrialsService = fixture.debugElement.injector.get(
        TrialsService
      );
      spyOn(component, 'close').and.callThrough();
      spyOn(toastrServiceStub, 'success').and.callThrough();
      spyOn(toastrServiceStub, 'error').and.callThrough();
      spyOn(
        commonUtilitiesServiceStub,
        'convertDatePickerToEpoch'
      ).and.callThrough();
      spyOn(trialsServiceStub, 'updateTask').and.callThrough();
      component.updateTask();
      expect(component.close).toBeDefined();
      expect(toastrServiceStub.success).toBeDefined();
      expect(toastrServiceStub.error).toBeDefined();
      expect(
        commonUtilitiesServiceStub.convertDatePickerToEpoch
      ).toBeDefined();
      expect(trialsServiceStub.updateTask).toBeDefined();
    });
  });

  it('should call checkChange',()=>{
    component.checkChange('eventval');
  });

  it('should call checkChange with null',()=>{
    component.checkChange(null);
  });

  it('should call changeTaskType',() =>{
    component.modal={
      "workQueueInfo":{
        "customTaskText":null
      }
    }
    component.taskType =[{"code":"RRR","description":"Review refund request"}]
    component.changeTaskType('RRR');
  });


});
function key(): () => void {
  throw new Error('Function not implemented.');
}

