import { Component, OnInit, ViewChild } from '@angular/core';
import { Store } from '@ngrx/store';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { element } from 'protractor';
import { take } from 'rxjs/operators';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import PanelJudgeModel from 'src/app/models/common/PanelJudge.model';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { JpViewService } from 'src/app/services/jpview.service';
import { TrialsService } from 'src/app/services/trials.service';
import { caseInfoData } from 'src/app/store/case-viewer/case-viewer.selectors';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import { DatePipe } from '@angular/common';
declare let $: any;


@Component({
  selector: 'app-create-task',
  templateUrl: './create-task.component.html',
  styleUrls: ['./create-task.component.less']
})
export class CreateTaskComponent implements OnInit {
  modal: any;
  paneling: any;
  assignToList: Array<any> = [];
  currentTimeStamp = new Date().getTime();
  selectedAssign: any;
  taskRequestedDate = this.commonUtils.setDateOnDatePicker(Date.now());
  selectedTaskType: any;
  taskDescription: any;
  originalJudgesOnTheCase: Array<PanelJudgeModel> = [];
  notesText: any;
  validationObject = {
    title: false,
    aiaReview: false,
    taskType: false,
    assignedTo: false
  }
  noAssigne = {
    id: null,
    text: null,
    activeTask: null,
    selected: false
  }
  taskType = [
    { "code": "RP", "description": "Reconcile petition" },
    { "code": "RMN", "description": "Reconcile PO mandatory notices" },
    { "code": "RCP", "description": "Review corrected petition" },
    { "code": "RRR", "description": "Review refund request" },
  ]
  deadLineDate: string;
  headerInfo: any;
  caseInfo: { serialNo: any; proceedingNo: any; };
  unsavedChanges: boolean = false;
  saved: boolean = false;

  checkFormModel(formModel) {
    if (!formModel) {
      return true;
    }
    return false;
  }
  /* istanbul ignore next */
  templateResult = (state: any): string => {
    if (!state.id) {
      return state.text;
    }
    let badgeText = '<span class="badge"></span>';
    if (state.activeTask > 0) {
      badgeText = '<span class="badge">' + state.activeTask + '</span>';
    } else {
      badgeText = '<span class="badge">' + 0 + '</span>';
    }
    return $('<span id=' + state.id + '>' + state.text + ' ' + badgeText + '</span>');
  }
  options = {
    multiple: false,
    closeOnSelect: true,
    width: '100%',
    allowClear: true,
    theme: 'bootstrap',
    openOnEnter: true,
    templateResult: this.templateResult,
    templateSelection: this.templateResult
  }

  option = {
    multiple: false,
    closeOnSelect: true,
    width: '100%',
    allowClear: true,
    theme: 'bootstrap',
    openOnEnter: true,
  }
  aiaReviewNumber: any;
  constructor(public bsModalRef: BsModalRef, private modalService: BsModalService, private commonUtils: CommonUtilitiesService, private jpViewService: JpViewService, private trialsService: TrialsService, private store: Store<CaseViewerState>, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getAssignToList();
    this.getPanelInfo({ serialNo: this.modal.workQueueInfo.poApplicationIdentifier, proceedingNo: this.modal.workQueueInfo.proceedingNumber });
    this.getCaseHeaderInfo({ serialNo: this.modal.workQueueInfo.poApplicationIdentifier, proceedingNo: this.modal.workQueueInfo.proceedingNumber });
    
    let today = new Date().toISOString().split('T')[0];
    document.getElementsByName("taskRequestedDate")[0].setAttribute('min', today);

    if (this.modal.title == 'Update') {
      this.taskRequestedDate = this.commonUtils.setDateOnDatePicker(this.modal.workQueueInfo.assignmentDate);
      this.selectedTaskType = this.modal.workQueueInfo.taskRequested;
    }
  }
  /* istanbul ignore next */
  ngAfterViewInit() {
    if (this.modal.title == 'Create') {
      let today = new Date().toISOString().split("T")[0];
      document.getElementById("taskDueDate").setAttribute('min', today);
    }
  }

  checkChange(event) {
    if (event) {
      this.unsavedChanges = true;
    } else {
      this.unsavedChanges = false;
    }
  }

  close(refreshValue) {
    if (!this.saved) {
      if (this.unsavedChanges || ((this.selectedAssign && this.selectedAssign.id) != document.getElementsByClassName('select2-selection__rendered')[0]?.querySelectorAll('span')[0]?.getAttributeNode('id')?.value)) {
        this.openAbandonChangesModal();
      } else {
        this.modalService.hide();
        this.modal.workQueueInfo.customTaskText = null;
        this.modal.workQueueInfo.customDescriptionText = null;
      }
    } else {
      this.modal.isConfirm = refreshValue;
      this.modal.workQueueInfo.customTaskText = null;
      this.modal.workQueueInfo.deadLineDate = null;
      this.modal.workQueueInfo.customDescriptionText = null;
      this.modalService.hide();
    }

  };

  changeTaskType(task) {
    this.checkChange(task);
    this.selectedTaskType = task;
    this.taskType.forEach(el => {
      if (el.code == this.selectedTaskType) {
        this.modal.workQueueInfo.customTaskText = el.description;
      }
    })
  };

  openAbandonChangesModal() {
    let response = this.commonUtils.openAbandonChangesModal('You have task information that has not been saved to the widget.');
    response.onHide.pipe(take(1)).subscribe((reason: string | any) => {
      try {
        if (reason.initialState.modal.isConfirm) {
          this.modalService.hide();
          this.modal.workQueueInfo.customTaskText = null;
          this.modal.workQueueInfo.deadLineDate = null;
          this.modal.workQueueInfo.customDescriptionText = null;
        }
      } catch (error) {
        // Left intentionally blank
      }
    })
  }

  getAssignToList() {
    // this.jpViewService.getAssignToList(`/standard-hierarchy-group/my-group/${this.modal?.loggedInUser.loginId}`).subscribe((assignToListSuccess) => {
    console.log(`${PtabTrialConstants.HIERARCHY.MY_GROUP}${this.modal?.loggedInUser.loginId}?activeOnly=true`);
    this.trialsService.getAssignToList(`${PtabTrialConstants.HIERARCHY.MY_GROUP}${this.modal?.loggedInUser.loginId}?activeOnly=true`).subscribe((assignToListSuccess) => {
      this.assignToList = [];
      assignToListSuccess.assigneeData.forEach(element => {
          let obj =
          {
            id: element.assigneeNumberText,
            text: element.assigneeFullNameText,
            activeTask: element.activeCaseCount,
            userIdentifier: element.userIdentifier,
            selected: false
          }
          this.assignToList.push(obj);
      });
      this.assignToList.forEach(el => {
        if (el.text && el.text.indexOf(this.modal.workQueueInfo.assigneeName) > -1) {
          el.selected = true;
          this.selectedAssign = el;
        }

      })
    });
  };

  getPanelInfo(caseInfo) {
    this.trialsService.getPaneledJudges(caseInfo.proceedingNo, false).subscribe((paneledJudgesResponse) => {
      this.originalJudgesOnTheCase = paneledJudgesResponse.listofJudges;
    }, (paneledJudgesFailure) => {
      this.originalJudgesOnTheCase = [];
    });
  }

  getCaseHeaderInfo(caseInfo) {
    let urlString = PtabTrialConstants.CASE_HEADER + `?proceedingSupplementaryId=${caseInfo.proceedingNo}`;
    this.trialsService.getHeaderInfo(caseInfo.proceedingNo).subscribe((headerInfoResponse) => {
      this.headerInfo = headerInfoResponse[0];
      if (this.headerInfo) {
        this.headerInfo.attorneys = [];
        this.headerInfo.attorneys = [...this.originalJudgesOnTheCase];

      }
    })
  };

  validateForm() {
    this.validationObject.title = this.checkFormModel(this.modal.workQueueInfo.customTaskText);
    this.validationObject.aiaReview = this.checkFormModel(this.aiaReviewNumber);
    this.validationObject.taskType = this.checkFormModel(this.selectedTaskType);
    this.validationObject.assignedTo = this.checkFormModel(this.selectedAssign);
    return this.validationObject.title || this.validationObject.aiaReview || this.validationObject.taskType || this.validationObject.assignedTo;
  };
  /* istanbul ignore next */
  createTask() {
    if (!this.validateForm()) {
      let assigneeName: string = null;
      let assigneeIdentifier: string = null;
      this.assignToList.forEach((element) => {
        if (element.id == this.selectedAssign) {
          assigneeName = element.text;
          assigneeIdentifier = element.userIdentifier;
        }
      });

      let createObj =
      {
        "assignerUserIdentifier": this.modal.loggedInUser.loginId,
        "requesterUserIdentifier": this.modal.loggedInUser.loginId,
        "assigneeUserIdentifier": assigneeIdentifier,
        "proceedingNumber": this.aiaReviewNumber.toUpperCase(),
        "taskTypeName": this.selectedTaskType,
        "customDescriptionText": this.modal.workQueueInfo.customDescriptionText,
        "customTaskText": this.modal.workQueueInfo.customTaskText,
        "completionDate": null,
        "assignmentDate": this.commonUtils.convertDatePickerToEpoch(this.taskRequestedDate),
        "deadLineDate": this.commonUtils.convertDatePickerToEpoch(this.modal.workQueueInfo.deadLineDate),
        "goalDate": null,
        "taskStatusDate": null,
        "completionCode": null,
        "notesText": this.notesText,
        "taskStatusCode": "AS",
        "taskPriorityCode": "U",
        "audit": {
          "lastModifiedTimestamp": this.currentTimeStamp,
          "lastModifiedUserIdentifier": this.modal.loggedInUser.loginId,
          "createUserIdentifier": this.modal.loggedInUser.loginId,
          "createTimestamp": this.currentTimeStamp
        }
      };

      this.trialsService.createTask(createObj).subscribe((reassignSuccess) => {
        this.unsavedChanges = false;
        this.saved = true;
        this.modal.workQueueInfo.customDescriptionText = null;
        this.toastr.success("Successfully created task", "", {
          closeButton: true
        });
        this.close(true);


      }, (reassignFailure) => {
        this.toastr.error(reassignFailure.error.message, "", {
          closeButton: true
        });
      });
    }
  }
  /* istanbul ignore next */
  updateTask() {
    
    let assigneeName: string = null;
    let assigneeIdentifier: string = null;
    this.assignToList.forEach((element) => {
      if (element.id == document.getElementsByClassName('select2-selection__rendered')[1].querySelectorAll('span')[0].getAttributeNode('id').value) {
        assigneeName = element.text;
        assigneeIdentifier = element.userIdentifier;
      }
    });

    let createObj =
    {
      "taskIdentifier": this.modal.workQueueInfo.taskIdentifier,
      "assignerUserIdentifier": this.modal.loggedInUser.loginId,
      "requesterUserIdentifier": this.modal.loggedInUser.loginId,
      "assigneeUserIdentifier": assigneeIdentifier,
      "proceedingNumber": this.modal.workQueueInfo.proceedingNumber,
      "taskTypeName": this.modal.workQueueInfo.taskTypeName,
      "customDescriptionText": this.modal.workQueueInfo.customDescriptionText,
      "customTaskText": this.modal.workQueueInfo.customTaskText,
      "completionDate": null,
      "assignmentDate": this.commonUtils.convertDatePickerToEpoch(this.taskRequestedDate),
      "deadLineDate": this.modal.workQueueInfo.deadLineDate,
      "goalDate": null,
      "taskStatusDate": null,
      "completionCode": null,
      "notesText": this.notesText,
      "taskStatusCode": "AS",
      "taskPriorityCode": "U",
      "audit": {
        "lastModifiedTimestamp": this.currentTimeStamp,
        "lastModifiedUserIdentifier": this.modal.loggedInUser.loginId,
        "createUserIdentifier": this.modal.loggedInUser.loginId,
        "createTimestamp": this.currentTimeStamp
      }
    };
    
    let updateObj = { "tasksList": [createObj] }

    this.trialsService.updateTask(updateObj).subscribe((reassignSuccess) => {
      this.unsavedChanges = false;
      this.saved = true;
      console.log('reassignSuccess: ', reassignSuccess);
      this.toastr.success("Successfully updated task", "", {
        closeButton: true
      });
      this.close(true);
    }, (reassignFailure) => {
      console.log('reassignFailure: ', reassignFailure);
      this.toastr.error(reassignFailure.error.message, "", {
        closeButton: true
      });
    });
  }
}

