import { Component, OnInit } from '@angular/core';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import GridRefreshModel from 'src/app/models/common/GridRefresh.model';
import { TrialsService } from 'src/app/services/trials.service';
import { ToolTipComponent } from '../tool-tip/tool-tip.component';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import { OpenCaseviewerComponent } from '../../common/open-caseviewer/open-caseviewer.component';
import { DatePipe } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-initiated-petitions',
  templateUrl: './initiated-petitions.component.html',
  styleUrls: ['./initiated-petitions.component.less']
})
export class InitiatedPetitionsComponent implements OnInit {

  selectedType: string = 'aiaReviews';

  /**
   *  Grid
   */
  gridApi;
  gridColumnApi;
  noRowsTemplate: string = "No cases found";
  frameworkComponents;


  defaultColDef = {
    filter: true,
    sortable: true,
    floatingFilter: true,
    suppressMenu: true,
    tooltipComponent: 'customTooltip',
    headerCheckboxSelection: this.isFirstColumn,
    checkboxSelection: this.isFirstColumn,
  };


  rowSelection = 'single';
  showLoading: boolean = false;
  loadingMessage: string = null;
  autoRefresh: boolean = false;

  gridRefreshValues: GridRefreshModel = {
    refreshFailed: false,
    showLoading: false,
    lastRefresh: null
  }

  columnDefs = [{
    "headerName": "",
    "field": "",
    "width": 25,
    "minWidth": 25,
    "maxWidth": 25,
    "resizable": false,
    "floatingFilter": false,
    "headerCheckboxSelection": false,
    "cellStyle": {
      "background-color": "#F0F0EE"
    }
  },
  {
    "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.AIA_REVIEW,
    "field": "proceedingNumber",
    "width": 130,
    "minWidth": 130,
    //"maxWidth": 130,
    "resizable": true,
    "cellRendererFramework": OpenCaseviewerComponent
  },
  {
    "headerName": "Date initiated",
    "field": "initiatedDateStr",
    "width": 150,
    "minWidth": 150,
    //"maxWidth": 150,
    "resizable": true,
    "comparator": this.gridHelper.dateComparator,
    "sort": "asc",
    "type": "date"
  },
  {
    "headerName": "Days Inactive",
    "field": "inActiveDays",
    "width": 150,
    "minWidth": 150,
    //"maxWidth": 150,
    "resizable": true,
    // "comparator": this.gridHelper.dateComparator,
    // "sort": "asc",
    // "type": "date"
  },
  {
    "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PETITIONER_PATENT_NO,
    valueGetter: this.gridHelper.valueGetterForPetitionerInitiatedCase,
    // "field": "petitionerApplNumber",
    "width": 145,
    "minWidth": 145,
    //"maxWidth": 145,
    "resizable": true
  },
  {
    "headerName": "Petitioner",
    //"field": "petitionerName",
    //"field":"petiInventorFullName",
    "field":"petiRealParty",
    "minWidth": 400,
    "resizable": true,
    "tooltipField": 'petitioner',
    "tooltipComponentParams": { data: 'petitioner' }
  },
  {
    "headerName": "Petitioner tech center",
    //"field": "techCenter",
    "field": "petiTechCenterId",
    "width": 135,
    "minWidth": 135,
    //"maxWidth": 135,
    "resizable": true
  },
  {
    "headerName": PtabTrialConstants.GRID_COLUMN_NAMES.PO_PATENT_NO,
    valueGetter: this.gridHelper.valueGetterPOPatentNumber,
    // "field": "poRespondentApplNumber",
    //"field": "poApplicationId",
    "width": 150,
    "minWidth": 150,
    //"maxWidth": 150,
    "resizable": true
  },
  {
    "headerName": "PO / Respondent",
    //"field": "patentOwnerName",
    //"field": "poInventorFullName",
    "field": "poRealParty",
    "minWidth": 400,
    "resizable": true,
    "tooltipField": 'poRealParty',
    "tooltipComponentParams": { data: 'poRealParty' }
  },
  {
    "headerName": "PO / Respondent tech center",
    //"field": "patentOwnerTechCenter",
    "field": "poTechCenterId",
    "width": 150,
    "minWidth": 150,
    //"maxWidth": 150,
    "resizable": true
  },
  {
    "headerName": "Initiated user ID",
    //"field": "initiatedUserId",
    "field": "initiatedUser",
    "width": 250,
    "minWidth": 250,
    "resizable": true
  }
  ];


  rowData: Array<any> = [];
  colState:any;

  numberOfFilters: number = 0;
  caseInfo: CaseInfoModel;

  constructor(
    private readonly activatedRoute: ActivatedRoute,
    private datePipe: DatePipe,
    private gridHelper: GridHelperService,
    private trialsService: TrialsService
  ) { }

  ngOnInit(): void {
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };
    this.frameworkComponents = { customTooltip: ToolTipComponent };
    //this.getInitiatedCases();
    this.getInitiatedCasesNew();
    setInterval(()=>{
      let ele =document.getElementById('autorefreshInitiatedPet');
      if(ele){ele.click();}
    },300000)
  }



  autoRefreshIni() {
    this.colState = this.gridApi.getFilterModel();
    this.autoRefresh = true;
    this.gridRefreshValues.showLoading = false;
    this.getInitiatedCasesNew();
  }

  // getInitiatedCases() {
  //   this.gridRefreshValues.showLoading = true;
  //   this.trialsService.getInitiatedCases().subscribe((initiatedResponse) => {
  //     initiatedResponse.forEach(element => {
  //       element.initiatedDateStr = element.initiatedDate ? this.gridHelper.convertDateToString(element.initiatedDate) : null;
  //       let currentDate = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
  //       const diffDays = (date, otherDate) => Math.ceil(Math.abs(date - otherDate) / (1000 * 60 * 60 * 24));
  //       element.inActiveDays = diffDays(new Date(currentDate), new Date(element.initiatedDateStr));
  //     });
  //     this.rowData = initiatedResponse;
  //     this.gridRefreshValues.showLoading = false;
  //     this.gridRefreshValues.lastRefresh = Date.now();
  //   }, (allAIAFailure) => {
  //     this.gridRefreshValues.showLoading = false;
  //     this.gridRefreshValues.lastRefresh = Date.now();
  //   });
  // }

  getInitiatedCasesNew(){
    let obj ={
      "proceedingNumber": null,
      "patentNumber": null,
      "applicationNumber": null,
      "partyName": null,
      "apj1Judge": null,
      "apjXJudge": null,
      "techCenterNum": null,
      "proceedingState":"initiated",
      "trailTypes": [
          "IPR",
          "PGR",
          "CBM",
          "DER"
      ],
      "inventionTitle": null,
      "casePhase": null,
      "artUnit": null
  }
  if(this.autoRefresh){
    this.gridRefreshValues.showLoading = false;
    }else{
      this.gridRefreshValues.showLoading = true;
    }
  this.trialsService.getInitiatedCasesNew(obj).pipe(take(1)).subscribe((initiatedCaseResponse) => {
    initiatedCaseResponse.forEach(element => {
      element.initiatedDateStr = element.prcdCreatedTs ? this.gridHelper.convertDateToString(new Date(element.prcdCreatedTs).getTime()) : null;
      let lastModifiedDate = null;
      if (element.audit && element.audit.lastModifiedTimestamp) {
        lastModifiedDate = this.gridHelper.convertDateToString(element.audit.lastModifiedTimestamp);
      }
      let currentDate = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
      const diffDays = (date, otherDate) => Math.ceil(Math.abs(date - otherDate) / (1000 * 60 * 60 * 24));
      element.inActiveDays = diffDays(new Date(currentDate), new Date(lastModifiedDate));
    });
    this.rowData = initiatedCaseResponse;
    this.gridRefreshValues.showLoading = false;
    this.gridRefreshValues.lastRefresh = Date.now();
    this.autoRefresh = false;
    if(this.colState){
      setTimeout(() => {
        this.gridApi.setFilterModel(this.colState);
      }, 100);
    }
  },  (allAIAFailure) => {
    this.gridRefreshValues.showLoading = false;
    this.gridRefreshValues.lastRefresh = Date.now();
  });

  }




  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }

  onFilterChanged() {
    console.log("On filter changed: ", this.gridApi.getDisplayedRowCount());
    const filterModel = this.gridApi.getFilterModel();
    this.numberOfFilters = Object.keys(filterModel).length;
  }


  getTotalCount() {
    if (this.gridApi) {
      let totalCount = this.gridApi.getDisplayedRowCount();
      return totalCount ? totalCount : 0
    } else {
      return 0
    }
  }


  isFirstColumn(params) {
    let displayedColumns = params.columnApi.getAllDisplayedColumns();
    let thisIsFirstColumn = displayedColumns[0] === params.column;
    return thisIsFirstColumn;
  }


  clearGridFilters() {
    this.gridApi.setFilterModel(null);
  }


  exportDataAsCsv() {
    let fileName: string = 'All initiated petitions';
    this.gridHelper.exportDataAsCsv(this.gridApi, fileName);
  }

}
