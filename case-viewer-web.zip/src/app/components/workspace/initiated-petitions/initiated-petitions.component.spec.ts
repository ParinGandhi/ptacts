import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { TrialsService } from 'src/app/services/trials.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AgGridModule } from 'ag-grid-angular';
import { DatePipe } from '@angular/common';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { of, throwError } from 'rxjs';
import { ActivatedRoute } from '@angular/router';

import { InitiatedPetitionsComponent } from './initiated-petitions.component';
import { ToastrMock } from 'src/app/models/Testing/ToastrMock.model';
import { GridApiMock } from 'src/app/models/Testing/GridApiMock.model';
import { GridRefreshComponent } from '../../common/grid-refresh/grid-refresh.component';


/**
 * !100.00%
 */
describe('InitiatedPetitionsComponent', () => {
  let component: InitiatedPetitionsComponent;
  let gridHelper: GridHelperService;
  let trialsService: TrialsService;
  let fixture: ComponentFixture<InitiatedPetitionsComponent>;

  const toastrService: ToastrMock = new ToastrMock();

  const initiatedResponseMock = [{
    "proceedingId": 1462523,
    "proceedingNumber": "IPR2016-01184",
    "petiArtUnitcd": null,
    "poArtUnitcd": null,
    "petiPatentNumber": null,
    "poPatentNumber": "6881745",
    "petiApplicationId": null,
    "poApplicationId": "10461503",
    "petiInventionTitleTx": null,
    "poInventionTitleTx": "PHARMACEUTICAL COMPOSITIONS FOR POORLY SOLUBLE DRUGS",
    "terminationTypeId": null,
    "currentPrcdStateId": "1",
    "petiInventorFullName": null,
    "poInventorFullName": "David Hayes",
    "patentOwnerName": "",
    "terminationTypeName": null,
    "statusDisplay": "Initiated",
    "poRealParty": null,
    "petiRealParty": null,
    "judges": [],
    "prcdCreatedTs": "2016-06-10 00:00:00.0",
    "petiTechCenterId": null,
    "poTechCenterId": "1600",
    "mileStoneDt": null,
    "allPartiesInfo": null,
    "initiatedUser": "test1_jlove@gibsondunn.com",
    "audit": {
      "lastModifiedTimestamp": 1618980053000
    }
  }, {
    "proceedingId": 1462987,
    "proceedingNumber": "IPR2016-01339",
    "petiArtUnitcd": null,
    "poArtUnitcd": null,
    "petiPatentNumber": null,
    "poPatentNumber": "RE41980",
    "petiApplicationId": null,
    "poApplicationId": "11984551",
    "petiInventionTitleTx": null,
    "poInventionTitleTx": "SEMICONDUCTOR INTERCONNECT FORMED OVER AN INSULATION AND HAVING MOISTURE RESISTANT MATERIAL",
    "terminationTypeId": null,
    "currentPrcdStateId": "1",
    "petiInventorFullName": null,
    "poInventorFullName": "Toshiki Yabu",
    "patentOwnerName": null,
    "terminationTypeName": null,
    "statusDisplay": "Initiated",
    "poRealParty": null,
    "petiRealParty": null,
    "judges": [],
    "prcdCreatedTs": "2016-06-30 00:00:00.0",
    "petiTechCenterId": null,
    "poTechCenterId": "2800",
    "mileStoneDt": null,
    "allPartiesInfo": null,
    "initiatedUser": "test1_bob.yoches@finnegan.com",
    "audit": {
      "lastModifiedTimestamp": 1618981474000
    }
  }, {
    "proceedingId": 1505437,
    "proceedingNumber": "IPR2018-00483",
    "petiArtUnitcd": null,
    "poArtUnitcd": "3744",
    "petiPatentNumber": null,
    "poPatentNumber": "6199388",
    "petiApplicationId": null,
    "poApplicationId": "09271046",
    "petiInventionTitleTx": null,
    "poInventionTitleTx": "SYSTEM AND METHOD FOR CONTROLLING TEMPERATURE AND HUMIDITY",
    "terminationTypeId": null,
    "currentPrcdStateId": "1",
    "petiInventorFullName": null,
    "poInventorFullName": null,
    "patentOwnerName": null,
    "terminationTypeName": null,
    "statusDisplay": "Initiated",
    "poRealParty": null,
    "petiRealParty": "Trane U.S. Inc.",
    "judges": [],
    "prcdCreatedTs": "2018-01-12 00:00:00.0",
    "petiTechCenterId": null,
    "poTechCenterId": "3700",
    "mileStoneDt": null,
    "allPartiesInfo": null,
    "initiatedUser": "test1_cmorton@robinskaplan.com",
    "audit": {
      "lastModifiedTimestamp": 1618991867000
    }
  }, {
    "proceedingId": 1464205,
    "proceedingNumber": "IPR2016-01308",
    "petiArtUnitcd": null,
    "poArtUnitcd": null,
    "petiPatentNumber": null,
    "poPatentNumber": "8863752",
    "petiApplicationId": null,
    "poApplicationId": "13915427",
    "petiInventionTitleTx": null,
    "poInventionTitleTx": "ELECTRONIC CIGARETTE",
    "terminationTypeId": null,
    "currentPrcdStateId": "1",
    "petiInventorFullName": null,
    "poInventorFullName": "Lik Hon",
    "patentOwnerName": "",
    "terminationTypeName": null,
    "statusDisplay": "Initiated",
    "poRealParty": null,
    "petiRealParty": null,
    "judges": [],
    "prcdCreatedTs": "2016-06-28 00:00:00.0",
    "petiTechCenterId": null,
    "poTechCenterId": "1700",
    "mileStoneDt": null,
    "allPartiesInfo": null,
    "initiatedUser": "test1_elizabeth.weiswasser@weil.com",
    "audit": {
      "lastModifiedTimestamp": 1618985305000
    }
  }, {
    "proceedingId": 1464213,
    "proceedingNumber": "IPR2016-01346",
    "petiArtUnitcd": null,
    "poArtUnitcd": null,
    "petiPatentNumber": null,
    "poPatentNumber": "8218481",
    "petiApplicationId": null,
    "poApplicationId": "12303947",
    "petiInventionTitleTx": null,
    "poInventionTitleTx": "METHOD OF TRANSMITTING DATA IN A MOBILE COMMUNICATION SYSTEM",
    "terminationTypeId": null,
    "currentPrcdStateId": "1",
    "petiInventorFullName": null,
    "poInventorFullName": "Yeong Hyeon Kwon",
    "patentOwnerName": null,
    "terminationTypeName": null,
    "statusDisplay": "Initiated",
    "poRealParty": null,
    "petiRealParty": null,
    "judges": [],
    "prcdCreatedTs": "2016-07-01 00:00:00.0",
    "petiTechCenterId": null,
    "poTechCenterId": "2400",
    "mileStoneDt": null,
    "allPartiesInfo": null,
    "initiatedUser": "test1_jimglass@quinnemanuel.com",
    "audit": {
      "lastModifiedTimestamp": 1618981785000
    }
  }, {
    "proceedingId": 1464278,
    "proceedingNumber": "IPR2016-01267",
    "petiArtUnitcd": null,
    "poArtUnitcd": null,
    "petiPatentNumber": null,
    "poPatentNumber": "8365742",
    "petiApplicationId": null,
    "poApplicationId": "13079937",
    "petiInventionTitleTx": null,
    "poInventionTitleTx": "AEROSOL ELECTRONIC CIGARETTE",
    "terminationTypeId": null,
    "currentPrcdStateId": "1",
    "petiInventorFullName": null,
    "poInventorFullName": "Lik HON",
    "patentOwnerName": null,
    "terminationTypeName": null,
    "statusDisplay": "Initiated",
    "poRealParty": null,
    "petiRealParty": null,
    "judges": [],
    "prcdCreatedTs": "2016-06-27 00:00:00.0",
    "petiTechCenterId": null,
    "poTechCenterId": "1700",
    "mileStoneDt": null,
    "allPartiesInfo": null,
    "initiatedUser": "test1_rgabric@brinksgilson.com",
    "audit": {
      "lastModifiedTimestamp": 1618991674000
    }
  }, {
    "proceedingId": 1464302,
    "proceedingNumber": "IPR2016-01269",
    "petiArtUnitcd": null,
    "poArtUnitcd": null,
    "petiPatentNumber": null,
    "poPatentNumber": "8490628",
    "petiApplicationId": null,
    "poApplicationId": "13560789",
    "petiInventionTitleTx": null,
    "poInventionTitleTx": "ELECTRONIC ATOMIZATION CIGARETTE",
    "terminationTypeId": null,
    "currentPrcdStateId": "1",
    "petiInventorFullName": null,
    "poInventorFullName": "Lik Hon",
    "patentOwnerName": "",
    "terminationTypeName": null,
    "statusDisplay": "Initiated",
    "poRealParty": null,
    "petiRealParty": null,
    "judges": [],
    "prcdCreatedTs": "2016-06-27 00:00:00.0",
    "petiTechCenterId": null,
    "poTechCenterId": "1700",
    "mileStoneDt": null,
    "allPartiesInfo": null,
    "initiatedUser": "test1_rgabric@brinksgilson.com",
    "audit": {
      "lastModifiedTimestamp": 1618984224000
    }
  }, {
    "proceedingId": 1463368,
    "proceedingNumber": "IPR2016-01330",
    "petiArtUnitcd": null,
    "poArtUnitcd": null,
    "petiPatentNumber": null,
    "poPatentNumber": "RE41980",
    "petiApplicationId": null,
    "poApplicationId": "11984551",
    "petiInventionTitleTx": null,
    "poInventionTitleTx": "SEMICONDUCTOR INTERCONNECT FORMED OVER AN INSULATION AND HAVING MOISTURE RESISTANT MATERIAL",
    "terminationTypeId": null,
    "currentPrcdStateId": "1",
    "petiInventorFullName": null,
    "poInventorFullName": "Toshiki Yabu",
    "patentOwnerName": null,
    "terminationTypeName": null,
    "statusDisplay": "Initiated",
    "poRealParty": null,
    "petiRealParty": null,
    "judges": [],
    "prcdCreatedTs": "2016-06-30 00:00:00.0",
    "petiTechCenterId": null,
    "poTechCenterId": "2800",
    "mileStoneDt": null,
    "allPartiesInfo": null,
    "initiatedUser": "test1_bob.yoches@finnegan.com",
    "audit": {
      "lastModifiedTimestamp": 1618981475000
    }
  }, {
    "proceedingId": 1463555,
    "proceedingNumber": "IPR2016-01306",
    "petiArtUnitcd": null,
    "poArtUnitcd": null,
    "petiPatentNumber": null,
    "poPatentNumber": "8863752",
    "petiApplicationId": null,
    "poApplicationId": "13915427",
    "petiInventionTitleTx": null,
    "poInventionTitleTx": "ELECTRONIC CIGARETTE",
    "terminationTypeId": null,
    "currentPrcdStateId": "1",
    "petiInventorFullName": null,
    "poInventorFullName": "Lik Hon",
    "patentOwnerName": "",
    "terminationTypeName": null,
    "statusDisplay": "Initiated",
    "poRealParty": null,
    "petiRealParty": null,
    "judges": [],
    "prcdCreatedTs": "2016-06-28 00:00:00.0",
    "petiTechCenterId": null,
    "poTechCenterId": "1700",
    "mileStoneDt": null,
    "allPartiesInfo": null,
    "initiatedUser": "test1_elizabeth.weiswasser@weil.com",
    "audit": {
      "lastModifiedTimestamp": 1618985305000
    }
  }];

  const gridApiMock: GridApiMock = new GridApiMock();

  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "08423235",
        caseNumber: "2020005372"
      }
    }
  };


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, AgGridModule.withComponents([])],
      declarations: [InitiatedPetitionsComponent, GridRefreshComponent],
      providers: [GridHelperService, TrialsService, DatePipe,  {
        provide: BsModalRef,
        useValue: {}
      },
      {
        provide: BsModalService,
        useValue: {}
      },
      {
        provide: ToastrService,
        useValue: toastrService
        },
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        }]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InitiatedPetitionsComponent);
    gridHelper = TestBed.inject(GridHelperService);
    trialsService = TestBed.inject(TrialsService);
    component = fixture.componentInstance;
    let store = {};
  const mockSessionStorage = {
    getItem: (key: string): string => {
      return key in store ? store[key] : null;
    },
    setItem: (key: string, value: string) => {
      store[key] = `${value}`;
    },
    removeItem: (key: string) => {
      delete store[key];
    },
    clear: () => {
      store = {};
    }
  };
  spyOn(sessionStorage, 'getItem')
    .and.callFake(mockSessionStorage.getItem);
  spyOn(sessionStorage, 'setItem')
    .and.callFake(mockSessionStorage.setItem);
  spyOn(sessionStorage, 'removeItem')
    .and.callFake(mockSessionStorage.removeItem);
  spyOn(sessionStorage, 'clear')
      .and.callFake(mockSessionStorage.clear);

    let userName = {
      loginId: "sbartlett"
    };
    mockSessionStorage.setItem('userInfo', JSON.stringify(userName));
    fixture.detectChanges();
  });



  it('should create', () => {
    // let userName ={}
    // spyOn(window.sessionStorage, 'getItem').and.callFake((key)=>{
    //   return userName[key];
    // })

    expect(component).toBeTruthy();
  });


  it('getAllInitiatedCases', () => {
    // let userName ={}
    // spyOn(window.sessionStorage, 'getItem').and.callFake((key)=>{
    //   return userName[key];
    // })
    spyOn(trialsService, 'getInitiatedCasesNew').and.returnValue(of(initiatedResponseMock));
    component.getInitiatedCasesNew();
    expect(component.rowData.length).toBe(initiatedResponseMock.length);
  });


  it('getAllInitiatedCases and fail', () => {
    // let userName ={}
    // spyOn(window.sessionStorage, 'getItem').and.callFake((key)=>{
    //   return userName[key];
    // })
    spyOn(trialsService, 'getInitiatedCasesNew').and.returnValue(throwError(""));
    component.getInitiatedCasesNew();
    // expect(component.rowData).toEqual(initiatedResponseMock);
  });


  it('should invoke onFilterChanged', () => {
    const data = {
      api: component.gridApi,
      columnApi: component.gridColumnApi
    }
    component.gridApi = gridApiMock;
    component.onFilterChanged();
    fixture.detectChanges();
  });


  it('should export data as csv', () => {
    const data = {
      api: component.gridApi,
      columnApi: component.gridColumnApi
    }
    component.gridApi = gridApiMock;
    component.exportDataAsCsv();
    fixture.detectChanges();
  });


  // it('should call onRowSelected', () => {
  //   component.gridApi = gridApiMock;
  //   component.onRowSelected();
  //   fixture.detectChanges();
  // });


  it('should clear filters', () => {
    component.gridApi = gridApiMock;
    component.clearGridFilters();
    fixture.detectChanges();
  });


});
