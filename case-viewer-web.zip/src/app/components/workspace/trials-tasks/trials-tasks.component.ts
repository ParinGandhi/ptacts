import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import { ToastrService } from 'ngx-toastr';
import { Store, select } from '@ngrx/store';
import { JpViewService } from 'src/app/services/jpview.service';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import { BulkReassignComponent } from '../modals/bulk-reassign/bulk-reassign.component';
import { OpenCaseviewerComponent } from '../../common/open-caseviewer/open-caseviewer.component';
import { DatePipe } from '@angular/common';
import { ICellRendererParams } from 'ag-grid-community';
import { ToolTipComponent } from '../tool-tip/tool-tip.component';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { CreateTaskComponent } from '../create-task/create-task.component';
import { CommonService } from 'src/app/services/common.service';
import { TrialsService } from 'src/app/services/trials.service';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-trials-tasks',
  templateUrl: './trials-tasks.component.html',
  styleUrls: ['./trials-tasks.component.less']
})
export class TrialsTasksComponent implements OnInit {

  selectedTask: string = 'openTask';
  recordsForAction: Array<any> = [];
  completedtaskList: Array<any>= [];
  taskData: any;
  disableAction: boolean = true;
  disableUpdate: boolean = false;
  taskTemp: any[] = [];
  caseNumberSearch: any;
  totalRecords: any;
  loggedInUser: any;
  loggedInUser$ = this.store.pipe(select(CaseViewerSelectors.userInfoData));
  caseInfo: CaseInfoModel;
  disableUpdateCal: boolean;
  dateNotSelected: boolean;
  showError: boolean;
  dateFutrueErrowMessage: boolean;
  dateErrowMessage: boolean;
  startDateFm: any = new Date(new Date().setHours(0,0,0,0));
  endDateFm = new Date().setHours(0,0,0,0);
  updateTaskModelRef: BsModalRef;
  date = new Date;
  totalCompletedRecords: any;
  refreshFailed: boolean = false;
  lastRefresh = new Date();
  showLoading: boolean = false;
  numberOfFilters: number = 0;
  autoRefresh: boolean = false;
  colState: any;

  options = {
    multiple: false,
    closeOnSelect: true,
    width: '100%',
    allowClear: true,
    theme: 'bootstrap',
    openOnEnter: true,
    minimumResultsForSearch: -1
  }

  gridApi;
  gridColumnApi;
  frameworkComponents;

  defaultColDef = {
    filter: true,
    sortable: true,
    floatingFilter: true,
    suppressMenu: true,
    tooltipComponent: 'customTooltip',
    headerCheckboxSelection: this.isFirstColumn,
      checkboxSelection: this.isFirstColumn,
  };


  rowSelection = 'multiple';

  columnDefs = [
    {
      headerName: '',
      field: '',
      width: 25,
      minWidth: 25,
      maxWidth: 25,
      resizable: false,
      floatingFilter: false,
      headerCheckboxSelection: true,
      cellStyle: {
        'background-color': '#F0F0EE'
      }
    }, {
      headerName: 'AIA Review #',
      field: 'proceedingNumber',
      width: 130,
      minWidth: 130,
      resizable: true,
      cellRendererFramework: OpenCaseviewerComponent,
      tooltipField: 'AIA Review #'
    }, {
      headerName: 'Requested date',
      field: 'taskRequestedDateStr',
      width: 100,
      minWidth: 100,
      resizable: true,
      sort: 'desc',
      comparator: this.gridHelper.dateComparator,
      type: 'date'
    }, {
      headerName: 'Task title',
      field: 'taskRequested',
      width: 200,
      minWidth: 200,
      resizable: true,
      wrapText: true,
      autoHeight: true
    }, {
      headerName: 'Assigned by',
      field: 'assignerName',
      width: 175,
      minWidth: 175,
      resizable: true
    }, {
      headerName: 'Assigned to',
      field: 'assigneeName',
      width: 175,
      minWidth: 175,
      resizable: true
    }, {
      headerName: 'Statutory deadline',
      field: 'statutoryDateStr',
      width: 80,
      minWidth: 80,
      resizable: true,
      comparator: this.gridHelper.dateComparator,
      type: 'date'
    }, {
      headerName: 'AIA Review status',
      field: 'aiaReviewStatus',
      width: 200,
      minWidth: 200,
      resizable: true,
      wrapText: false,
      autoHeight: false
    }, {
      headerName: 'Petitioner vs. PO/Respondent',
      field: 'petitionerNameVsrespondentName',
      // cellRendererFramework: ToolTipComponent,
      // cellRendererParams: (params: ICellRendererParams) => this.gridHelper.formatPetVsPOTooltip(params),
      tooltipField: 'petitionerNameVsrespondentName',
      tooltipComponentParams: { data: 'petitionerNameVsrespondentName' },
      width: 225,
      minWidth: 225,
      resizable: true,
      wrapText: false,
      autoHeight: false
    }, {
      headerName: 'Petitioner patent/appln #',
      valueGetter: this.gridHelper.valueGetterPetitionerPatentNo,
      width: 110,
      minWidth: 110,
      resizable: true
    }, {
      headerName: 'PO/Respondent patent/appln #',
      valueGetter: this.gridHelper.valueGetterPOPatentNo,
      width: 110,
      minWidth: 110,
      resizable: true
    },
    // { headerName: 'Judge panel', field: 'judgeNamesList', width: 150, minWidth: 150,
    // resizable: true,cellRendererFramework: ToolTipComponent, cellRendererParams: (params: ICellRendererParams) => this.gridHelper.formatJudgePanelTooltip(params)},
    {
      headerName: 'Task due date',
      field: 'deadLineDateStr',
      width: 125,
      minWidth: 125,
      resizable: true,
      comparator: this.gridHelper.dateComparator,
      type: 'date'
    },
    // { headerName: 'Comments', field: 'comments', width: 150, minWidth: 150, cellRendererFramework: ToolTipComponent, cellRendererParams: (params: ICellRendererParams) => this.gridHelper.formatCommentsTooltip(params) },
    {
      headerName: 'Completed timestamp',
      field: 'completionDateStr',
      width: 200,
      minWidth: 200,
      resizable: true,
      comparator: this.gridHelper.sortedDates,
      type: 'timestamp'
    }, {
      headerName: 'Last modified timestamp',
      field: 'lastModifiedTimestampStr',
      width: 200,
      minWidth: 200,
      resizable: true,
      comparator: this.gridHelper.sortedDates,
      type: 'timestamp'
    }, {
      headerName: 'Last modified user',
      field: 'lastModifiedUserName',
      width: 175,
      minWidth: 175,
      resizable: true
    },
    {
      headerName: 'Trial type ',
      field: 'trialType',
      width: 110,
      minWidth: 110,
      resizable: true
    }
  ];

  rowData: Array<any> = [];
  fetchTeam: boolean;
  fetchGroup: any;
  totalGroupTasks: any;
  totalTeamsTasks: any;
  completedTaskType: string = 'teamsClosedTask';
  showCompletedOptions: boolean;
  totalSystemTasks: any;
  selectedStartDate: any;
  selectedEndDate: any;
  tempSelectedStartDate: any;
  tempSelectedEndDate: any;
  taskTypeSelected: any;
  sysGen: boolean = false;
  onlySysGen: boolean;
  systemGeneratedTasks: any;
  finalCount: any;
  filterOn: boolean = false;
  KEY_LEFT = 37;
  KEY_UP = 38;
  KEY_RIGHT = 39;
  KEY_DOWN = 40;
  constructor(
    private activatedRoute: ActivatedRoute,
    private jpViewService: JpViewService,
    private trialsService: TrialsService,
    private store: Store<CaseViewerState>,
    private modalService: BsModalService,
    private toastr: ToastrService,
    private gridHelper: GridHelperService
  ) { }


  ngOnInit(): void {

    this.frameworkComponents = { customTooltip: ToolTipComponent };

    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };
    this.store.pipe(select(CaseViewerSelectors.userInfoData)).subscribe(data => {
      this.loggedInUser = data.caseDetailsData[0];
      if (!this.loggedInUser) {
        this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
      }
    });
    this.startDateFm = this.startDateFm.setDate(this.startDateFm.getDate()-7);
    this.tempSelectedEndDate = this.selectedEndDate? this.selectedEndDate : this.endDateFm;
    this.tempSelectedStartDate = this.selectedStartDate? this.selectedStartDate : this.startDateFm
    this.changeTasks('openTask', false, true);
    setInterval(()=>{
      let ele =document.getElementById('autoRefreshTask');
      if(ele){ele.click();}
    },300000)
  }

   autoRefreshTask() {
    this.colState = this.gridApi.getFilterModel();
    this.autoRefresh = true;
    this.showLoading = false;
    this.changeTasks('openTask', false, true);
  }

  changeButtonClicked() {
   this.showError = false;
   this.dateNotSelected = false;
   this.disableUpdateCal = false;
    this.dateFutrueErrowMessage = false;
    this.dateErrowMessage = false;
    const datepipe: DatePipe = new DatePipe('en-US');
    this.selectedStartDate = this.selectedStartDate ? datepipe.transform(this.selectedStartDate, 'yyyy-MM-dd'):datepipe.transform(this.startDateFm, 'yyyy-MM-dd')
    this.selectedEndDate = this.selectedEndDate ?  datepipe.transform(this.selectedEndDate, 'yyyy-MM-dd'): datepipe.transform(this.endDateFm, 'yyyy-MM-dd')
  };


  completeObj = {​​​​​​​​
    "tasksList":[]
  }​​​​​​​​


  getTasks(taskType, date) {
    this.recordsForAction = [];
    this.filterOn = false;
    this.taskTypeSelected = taskType;
    const datepipe: DatePipe = new DatePipe('en-US');
    let sDate = datepipe.transform(this.selectedStartDate, 'MM-dd-yyyy')
    let eDate = datepipe.transform(this.selectedEndDate, 'MM-dd-yyyy')
    const event1 = new Date();
    const event2 = new Date(eDate);
    let now = new Date();
    now.setHours(0,0,0,0);
    event2.setTime(event1.getTime());
    this.tempSelectedStartDate = this.selectedStartDate? new Date(sDate).getTime(): null;
    this.tempSelectedEndDate = this.selectedEndDate? ( (this.selectedEndDate < datepipe.transform(now, 'yyyy-MM-dd'))? new Date(eDate).setHours(23,59,59,999): new Date(eDate).setTime(event1.getTime())): null;

    if(this.autoRefresh){
      this.showLoading = false;
      }else{
        this.showLoading = true;
      }
    if (taskType == '') {
      this.fetchTeam = true;
      this.showLoading  = false;
      this.taskData = {
        tableId: "taskTable",
        tableHeaderClass: "taskTableHeader",
        tableBodyClass: "taskTableBody",
        checkboxClass: "taskCheckbox",
        columnDefs: []
      };
      this.rowData = [];
    } else {
      let activeOnlyValue = (taskType == 'openTask'|| taskType =='teamsOpenTask' || taskType == 'groupOpenTask' || taskType == 'systemGenTask' ) ? true : false;
      this.fetchTeam = (taskType =='teamsOpenTask' || taskType == 'teamsClosedTask' || taskType =='completedTask')? true: false;
      this.fetchGroup = (taskType == 'groupOpenTask' || taskType == 'groupClosedTask')? true: false;
      this.onlySysGen = (taskType == 'systemGenTask')? true: false;
      this.sysGen = (taskType != 'systemGenTask' )? true: false;
    if (activeOnlyValue == false){
      this.showCompletedOptions = true;
    } else {
      this.showCompletedOptions = false;
    }
    if(taskType == 'completedTask'){
      this.completedTaskType = 'teamsClosedTask'
    }

       let dataToFilter= {
        "activeOnly": activeOnlyValue,
        "fetchTeam":this.fetchTeam,
        "fetchGroup":this.fetchGroup,
        "taskBelongsTo": this.loggedInUser.loginId,
        "startDate":  date ? (this.selectedStartDate ? this.tempSelectedStartDate: this.startDateFm)  : null,
        "endDate": date ?(this.selectedEndDate?  this.tempSelectedEndDate: this.endDateFm): null,
        "includeSystemGenerated": true,
        "systemGeneratedOnly": this.onlySysGen
      }
        // this.jpViewService.getWorkQueue(`/worker-task/details`,dataToFilter).subscribe((response) => {
        this.trialsService.getWorkQueue(dataToFilter).pipe(take(1)).subscribe((response) => {
          this.showLoading = false;
          this.refreshFailed = false;
          if (response && response.workerTasksList.length >= 0) {


            if(taskType == 'teamsCompletedTask' || (taskType != 'groupClosedTask' && taskType != 'myclosedTasks')){
              this.totalCompletedRecords = response.teamCompletedTasksCount;
            }else if(taskType == 'groupClosedTask'){
              this.totalCompletedRecords = response.groupCompletedTasksCount;
            }else if(taskType == 'myclosedTasks') {
              this.totalCompletedRecords = response.completedTasksCount;
            }
              this.totalTeamsTasks = response.teamActiveTasksCount;
              this.totalGroupTasks = response.groupActiveTasksCount;
              this.totalRecords = response.activeTasksCount;
              this.systemGeneratedTasks = response.systemGeneratedTasksCount;
              // this.finalCount = this.gridApi.getDisplayedRowCount();
            for(let i=0; i < response.workerTasksList.length; i++){
              response.workerTasksList[i].judgeNamesList = [];
              response.workerTasksList[i].petitionerNameVsrespondentName = response.workerTasksList[i].petitionerName ? response.workerTasksList[i].petitionerName : '';
          if (response.workerTasksList[i].respondentName) {
            response.workerTasksList[i].petitionerNameVsrespondentName += ` vs ${response.workerTasksList[i].respondentName}`;
          }
              // response.workerTasksList[i].petitionerNameVsrespondentName = response.workerTasksList[i].petitionerName? response.workerTasksList[i].petitionerName : ''  +( response.workerTasksList[i].respondentName? " vs ": '') +( response.workerTasksList[i].respondentName? response.workerTasksList[i].respondentName: '');
              response.workerTasksList[i].judgePanel = response.workerTasksList[i].judgePanelList? (response.workerTasksList[i].judgePanelList[0].lastName? response.workerTasksList[i].judgePanelList[0].lastName: "") + " "+ (response.workerTasksList[i].judgePanelList[0].firstName? response.workerTasksList[i].judgePanelList[0].firstName: "") +" "+ (response.workerTasksList[i].judgePanelList[0].middleInitial? response.workerTasksList[i].judgePanelList[0].middleInitial: null):'';
              response.workerTasksList[i].panelCount = response.workerTasksList[i].judgePanelList ? response.workerTasksList[i].judgePanelList.length : null;
              response.workerTasksList[i].taskRequestedDateStr = this.gridHelper.convertDateToString(response.workerTasksList[i].assignmentDate);
              response.workerTasksList[i].statutoryDateStr = this.gridHelper.convertDateToString(response.workerTasksList[i].statutoryDate);
              response.workerTasksList[i].deadLineDateStr = this.gridHelper.convertDateToString(response.workerTasksList[i].deadLineDate);
              response.workerTasksList[i].completionDateStr = this.gridHelper.convertDateToTimeStamp(response.workerTasksList[i].completionDate);
              response.workerTasksList[i].lastModifiedTimestampStr = this.gridHelper.convertDateToTimeStamp(response.workerTasksList[i].lastModifiedTimestamp);
             if(response.workerTasksList[i].judgePanelList && response.workerTasksList[i].judgePanelList.length > 0){
              response.workerTasksList[i].judgePanelList.forEach(element => {
                response.workerTasksList[i].judgeNamesList.push((element.lastName?element.lastName: "") + " "+ (element.firstName?element.firstName: "") + " "+ (element.middleInitial?element.middleInitial:""))
              });
            }
            }
          }
          this.rowData = response.workerTasksList;
          if(this.colState){
            setTimeout(() => {
              this.gridApi.setFilterModel(this.colState);
            }, 100);
          }
          this.autoRefresh = false;
          this.lastRefresh = new Date();
        },(failure) => {
          this.showLoading = false;
          this.rowData = [];
          this.totalCompletedRecords = 0;
          this.totalRecords = 0;
          this.refreshFailed = true;
          this.toastr.error(`${failure.error.message}`, "", {
            closeButton: true
          });
      });
      }
    };


  changeTasks(task, date, refresh) {
    this.showCompletedOptions = false;
    this.numberOfFilters = 0;
    this.selectedTask = task;
    this.getTasks(task,date);
    if(refresh){
      const datepipe: DatePipe = new DatePipe('en-US');
      this.selectedStartDate = datepipe.transform(this.startDateFm, 'yyyy-MM-dd')
      this.selectedEndDate = datepipe.transform(this.endDateFm, 'yyyy-MM-dd')
    }
  }



  markComplete() {
    if(this.recordsForAction.length > 0){

      this.recordsForAction.forEach((task) => {

        task.petitionerNameVsrespondentName = null;
        task.judgePanel = null;
        task.panelCount = null;
        task.completionDate =  new Date(this.lastRefresh).getTime(),
        task.audit = {
           "createUserIdentifier": this.loggedInUser.loginId,
            "lastModifiedUserIdentifier": this.loggedInUser.loginId,
            "lastModifiedTimestamp": new Date(this.lastRefresh).getTime(),
            "createTimestamp": new Date(this.lastRefresh).getTime()
        }
        task.requesterUserIdentifier = task.requesterUserIdentifier? task.requesterUserIdentifier : this.loggedInUser.loginId
      })

      this.completeObj = {
        tasksList: this.recordsForAction
      };

      // this.jpViewService.markCompleteWorkQueue("/worker-task/bulk", this.completeObj).subscribe((response) => {
      this.trialsService.markCompleteWorkQueue(this.completeObj).subscribe((response) => {
          this.completeObj.tasksList = [];
          this.toastr.success(`Task(s) successfully marked complete`, "", {
            closeButton: true
          });
          this.selectedTask = this.taskTypeSelected;
          this.getTasks(this.taskTypeSelected,false);
        },(failure) => {
          this.completeObj.tasksList = [];
          this.toastr.error(`${failure.error.message}`, "", {
            closeButton: true
          });
      });
      }
      };


  openBulkReassignModal() {
    const initialState = {
      modal: {
        title: `Update`,
        closeBtnName: "Done",
        isConfirm: false,
        workQueueInfo: this.recordsForAction,
        caseInfo: this.caseInfo,
        loggedInUser: this.loggedInUser,
        modalType: 'updateTask'
      }
    };
    this.updateTaskModelRef = this.modalService.show(BulkReassignComponent, {
      animated: true,
      backdrop: true,
      ignoreBackdropClick: true,
      class: 'add-update-parties-modal-content',
      initialState
    });
    this.updateTaskModelRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        this.recordsForAction = [];
        this.changeTasks('openTask', false,true);
      }
    })
  }


  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }


  onRowSelected() {
    this.recordsForAction = this.gridApi.getSelectedRows();

  }

  onFilterChanged() {
    this.filterOn = true;
    this.finalCount = this.gridApi.getDisplayedRowCount();
    const filterModel = this.gridApi.getFilterModel();
    this.numberOfFilters = Object.keys(filterModel).length;
  }



  isFirstColumn(params) {
    let displayedColumns = params.columnApi.getAllDisplayedColumns();
    let thisIsFirstColumn = displayedColumns[0] === params.column;
    return thisIsFirstColumn;
  }



  clearGridFilters() {
    this.gridApi.setFilterModel(null);
  }


  exportDataAsCsv() {
    let fileName: string = `AIA Trials Tasks`;
    this.gridHelper.exportDataAsCsv(this.gridApi, fileName);
  }


  openCreateModal() {
    const initialState = {
      modal: {
        title: `Create`,
        closeBtnName: "Done",
        isConfirm: false,
        workQueueInfo: this.recordsForAction,
        caseInfo: this.caseInfo,
        loggedInUser: this.loggedInUser,
        modalType: 'createTask'
      }
    };
    this.updateTaskModelRef = this.modalService.show(CreateTaskComponent, {
      animated: true,
      backdrop: true,
      ignoreBackdropClick: true,
      class: 'add-update-parties-modal-content',
      initialState
    });
    this.updateTaskModelRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        this.getTasks(this.selectedTask,null);
        // this.recordsForAction = [];
        // this.changeTasks('openTask', false,true);
      }
    })
  }


  openUpdateModal() {
    const initialState = {
      modal: {
        title: `Update`,
        closeBtnName: "Done",
        isConfirm: false,
        workQueueInfo: this.recordsForAction[0],
        caseInfo: this.caseInfo,
        loggedInUser: this.loggedInUser,
        modalType: 'updateTask'
      }
    };
    this.updateTaskModelRef = this.modalService.show(CreateTaskComponent, {
      animated: true,
      backdrop: true,
      ignoreBackdropClick: true,
      class: 'add-update-parties-modal-content',
      initialState
    });
    this.updateTaskModelRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        this.getTasks(this.selectedTask,null);
        // this.recordsForAction = [];
        // this.changeTasks('openTask', false,true);
      }
    })
  }


}
