import { ComponentFixture, TestBed, fakeAsync } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { TrialsService } from 'src/app/services/trials.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DatePipe } from '@angular/common';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { AgGridModule } from 'ag-grid-angular';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { GridOptions } from 'ag-grid-community';
import { TrialsTasksComponent } from './trials-tasks.component';
import { OpenCaseviewerComponent } from '../../common/open-caseviewer/open-caseviewer.component';
import { ImportPanelComponent } from '../modals/import-panel/import-panel.component';
import { provideMockStore } from '@ngrx/store/testing';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { componentFactoryName } from '@angular/compiler';
import { JpViewService } from 'src/app/services/jpview.service';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { of } from 'rxjs';
import { Injectable, EventEmitter } from '@angular/core';
import { InfoModalComponent } from '../../common/info-modal/info-modal.component';
import { BulkReassignComponent } from '../modals/bulk-reassign/bulk-reassign.component';


const workQueueMock = {
  groupCompletedTasksCount: null,
  teamCompletedTasksCount: null,
  allowedResourceObjectList: [
    "panel_Update"
  ],
  ptabDefaultRefreshTime: 300000,
  activeTasksCount: null,
  groupActiveTasksCount: null,
  ptabReadOnlyUser: false,
  teamActiveTasksCount: null,
  completedTasksCount: null,
  workerTasksList: [
    {
      judgePanelList: null,
      customDescriptionText: "System Task(s) Description",
      taskRequested: "Review Appeal",
      taskTypeName: "RA",
      assigneeUserIdentifier: null,
      statutoryDate: null,
      proceedingNumber: "IPR2014-00504",
      assigneeName: null,
      customTaskText: "System Task(s)",
      deadLineDate: 1600660800000,
      poApplicationIdentifier: "10386691",
      aiaReviewStatus: "Final Written Decision",
      assignerUserIdentifier: "system",
      taskPriorityCode: "U",
      assignerName: "System, System",
      comments: null,
      petitionerName: "Motorola Mobility LLC",
      trialType: "IPR",
      requesterUserIdentifier: "sbartlett",
      poPatentNumber: "7382771",
      lastModifiedUserName: "Bartlett, Steven",
      priority: "Urgent",
      taskIdentifier: 1442864,
      lastModifiedTimestamp: 1615227627057,
      statusDescription: "ACTIVE",
      petitionerApplicationIdentifier: null,
      respondentName: "Intellectual Ventures I LLC",
      completionDate: null,
      assignmentDate: 1600401600000,
      taskStatusDate: null,
      taskStatusCode: "AC",
      taskRequestedDate: 1395174292000
    }
  ]
};


fdescribe('TrialsTasksComponent', () => {
  let component: TrialsTasksComponent;
  let trialsService: TrialsService;
  let gridHelper: GridHelperService;
  let modalService: BsModalService;
  let commonUtils: CommonUtilitiesService;
  let gridApi: GridOptions = <GridOptions>{};
  let fixture: ComponentFixture<TrialsTasksComponent>;
  let gridOptions: GridOptions = <GridOptions>{};

  const jpServiceMock = {
    getWorkQueue: () => of({ workerTasksList: [{ petitionerName: '03/04/1991', judgePanelList: [{ lastName: 'test' }] }] }),
    markCompleteWorkQueue: () => of({ recordsForAction: 'Test' })

  };

  @Injectable()
  class StubbedModalService {
    public show(): void { }
  }
  //show: () => { return { onHide: new EventEmitter() } }
  //};

  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => { },
    error: (
      message?: string,
      title?: string
    ) => { },
  };

  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "08423235",
        caseNumber: "2020005372"
      }
    }
  };

  let reason = {
    initialState: {
      modal: {
        isConfirm: true
      }
    }
  }
  class modalServiceMock {
    // hide: () => {},
    // show:() => {return {onHide:() => {return of(reason)}}}
    show = (infoModalComponent: BulkReassignComponent) => { return { onHide: () => { return of(reason) } } }
    hide = () => { return {} }
  };

  const loggedInUserInfo = {
    activeIn: "Active",
    apjSeniorityRank: 85,
    disiplanceCd: "Electrical",
    emailAddress: "Test_Jennifer.Bisk@USPTO.GOV",
    firstName: "Jennifer",
    fullName: "Bisk, Jennifer S.",
    jobClassificationCode: "APJ",
    lastName: "Bisk",
    leadApjIndicator: "APJ1",
    loginId: "jbisk",
    preferredFullName: "Bisk, Jennifer S.",
    privileges: null,
    roleDescription: "Judge",
    trialJudgeIndicator: "Judge",
    userIdentiifier: 5017,
    userWorkerNumber: "88548",
    isAdmin: false
  };

  const failure = {
    error: {
      message: "Error"
    }
  };


  const gridApiMock = {
    setFilterModel: () => { },
    getDisplayedRowCount: () => {
      return 5;
    },
    getFilterModel: () => {
      const filterModelMock = {
        status: {
          filter: "n",
          filterType: "text",
          type: "contains"
        }
      }
      return filterModelMock;
    },
    exportDataAsCsv: () => { },
    getSelectedRows: () => { }
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, AgGridModule.withComponents([])],
      declarations: [TrialsTasksComponent, OpenCaseviewerComponent, ImportPanelComponent],
      providers: [
        provideMockStore({
          selectors: [
            { selector: CaseViewerSelectors.caseInfoData, value: { proceedingNo: '37553565' } },
            {
              selector: CaseViewerSelectors.userInfoData, value: {
                caseDetailsData: [{
                  activeIn: "Active",
                  apjSeniorityRank: 85,
                  disiplanceCd: "Electrical",
                  emailAddress: "Test_Jennifer.Bisk@USPTO.GOV",
                  firstName: "Jennifer",
                  fullName: "Bisk, Jennifer S.",
                  jobClassificationCode: "APJ",
                  lastName: "Bisk",
                  leadApjIndicator: "APJ1",
                  loginId: "jbisk",
                  preferredFullName: "Bisk, Jennifer S.",
                  privileges: null,
                  roleDescription: "Judge",
                  trialJudgeIndicator: "Judge",
                  userIdentiifier: 5017,
                  userWorkerNumber: "88548",
                  isAdmin: false
                }]
              }
            }
          ]
        }),
        DatePipe,
        TrialsService,
        BsModalService,
        GridHelperService,
        {
          provide: CommonUtilitiesService,
          useValue: commonUtils
        },
        {
          provide: JpViewService,
          useValue: jpServiceMock
        },
        {
          provide: ToastrService,
          useValue: toastrService
        },
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        },
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useClass: modalServiceMock
        }
      ]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TrialsTasksComponent);
    trialsService = TestBed.inject(TrialsService);
    gridHelper = TestBed.inject(GridHelperService)
    modalService = TestBed.inject(BsModalService);
    commonUtils = TestBed.inject(CommonUtilitiesService);
    component = fixture.componentInstance;
    // jpServiceMock = TestBed.get(JpViewService);

    //const  = spyOn(userStore, 'pipe').and.returnValue(of(user));
    //component.loggedInUser = loggedInUserInfo;
    fixture.detectChanges();
    // stubbedModalService = fixture.debugElement.injector.get(BsModalService);
    // showSpy = spyOn(stubbedModalService, 'show').and.returnValue(undefined);
  });

  it('should create', () => {
    let userInfo = JSON.stringify(loggedInUserInfo);

    window.sessionStorage.setItem('userInfo', userInfo);
    expect(component).toBeTruthy();
  });

  it('should create changeButtonClicked ', () => {
    component.showError = true;
    //  spyOn(jpServiceMock.getWorkQueue(`/worker-task/details`, dataFilter), 'subscribe');
    component.changeButtonClicked();
    expect(component.showError).toBeFalsy();

  });


  it('should create getTasks with task', fakeAsync(() => {

    // spyOn(jpServiceMock, 'getWorkQueue').and.returnValue(of(mockWorkQueueList));
    component.getTasks('openTask', new Date());

    //expect(component.rowData.length).toBeGreaterThan(0);
    expect(component.rowData.length).toEqual(0);

  }));


  it('should create getTasks with task', fakeAsync(() => {
    component.getTasks('', new Date());
    expect(component.fetchTeam).toBeTrue();
    expect(component.showLoading).toBeFalse();
    expect(component.rowData.length).toBe(0);
  }));

  it('should create getTasks with task failure', () => {
    // const jpViewService = TestBed.inject(JpViewService);
    const trialsService = TestBed.inject(TrialsService);
    // spyOn(jpViewService, 'getWorkQueue').and.returnValue(throwError(failure));
    spyOn(trialsService, 'getWorkQueue').and.returnValue(throwError(failure));
    component.getTasks('openTask', new Date());

    expect(component.rowData.length).toBe(0);

  });


  it('should create markComplete ', fakeAsync(() => {
    component.recordsForAction = [{ petitionerNameVsrespondentName: 'shsh' }]
    component.markComplete();
    expect(component.completeObj.tasksList.length).toBeGreaterThan(0);
  }));


  it('should create markComplete failure', () => {
    const jpViewService = TestBed.inject(JpViewService);
    // spyOn(jpViewService, 'markCompleteWorkQueue').and.returnValue(throwError(failure));
    spyOn(trialsService, 'markCompleteWorkQueue').and.returnValue(throwError(failure));
    component.recordsForAction = [{ petitionerNameVsrespondentName: 'shsh' }]
    component.markComplete();
    expect(component.completeObj.tasksList.length).toBe(0);
  });

  // it('should create openBulkReassignModal ', fakeAsync(() => {
  //   const bsModalService = fixture.debugElement.injector.get(BsModalService);
  //   //const dilougeRefspy = spyOn(bsModalService, 'show')
  //   //    const test = { onHide: () => of('hshs') }
  //   spyOn(bsModalService, 'show').and.returnValue(undefined);
  //   component.openBulkReassignModal();
  //   //expect(component.completeObj.tasksList.length).toBe(0);
  // }));

  // it('should create onRowSelected ', fakeAsync(() => {
  //   component.gridApi = {};
  //   //component.gridApi.selectedRows = 25;
  //   component.onRowSelected('bsbsh');
  //   //expect(component.completeObj.tasksList.length).toBe(0);
  // }));

  it('should call openBulkReassignModal', () => {
    const emitter = new EventEmitter();
    emitter.emit(true);

    modalService.show = (): BsModalRef => {
      return ({ id: null, hide: null, setClass: null, onHide: emitter, onHidden: null });
    };

    spyOn(component, "openBulkReassignModal").and.callThrough();
    component.openBulkReassignModal();
    expect(component.openBulkReassignModal).toHaveBeenCalled();

  });

  it('should call openCreateModal', () => {
    const emitter = new EventEmitter();
    emitter.emit(true);

    modalService.show = (): BsModalRef => {
      return ({ id: null, hide: null, setClass: null, onHide: emitter, onHidden: null });
    };

    spyOn(component, "openCreateModal").and.callThrough();
    component.openCreateModal();
    expect(component.openCreateModal).toHaveBeenCalled();

  });

  it('should call openUpdateModal', () => {
    const emitter = new EventEmitter();
    emitter.emit(true);

    modalService.show = (): BsModalRef => {
      return ({ id: null, hide: null, setClass: null, onHide: emitter, onHidden: null });
    };

    spyOn(component, "openUpdateModal").and.callThrough();
    component.openUpdateModal();
    expect(component.openUpdateModal).toHaveBeenCalled();

  });

  // it('onRowSelected called', () => {
  //   // const data = {
  //   //   api: component.gridApi.api,
  //   //   columnApi: component.gridApi.columnApi
  //   // }
  //   // let userInfo = JSON.stringify(loggedInUserInfo);

  //   // window.sessionStorage.setItem('userInfo', userInfo);
  //   component.startDateFm = new Date(new Date().setHours(0, 0, 0, 0));
  //   component.endDateFm = new Date().setHours(0, 0, 0, 0);
  //   component.ngOnInit();
  //   //component.gridApi.getSelectedRows = 20;
  //   component.onRowSelected('sns');
  //   // expect(component.gridApi).not.toBeNull();
  //   // expect(component.gridColumnApi).not.toBeNull();
  // });


  it('should invoke onFilterChanged', () => {
    const data = {
      api: component.gridApi,
      columnApi: component.gridColumnApi
    }
    component.gridApi = gridApiMock;
    component.onFilterChanged();
    fixture.detectChanges();
  });


  it('should export data as csv', () => {
    const data = {
      api: component.gridApi,
      columnApi: component.gridColumnApi
    }
    component.gridApi = gridApiMock;
    component.exportDataAsCsv();
    fixture.detectChanges();
  });


  it('should call onRowSelected', () => {
    component.gridApi = gridApiMock;
    component.onRowSelected();
    fixture.detectChanges();
  });


  it('should clear filters', () => {
    component.gridApi = gridApiMock;
    component.clearGridFilters();
    fixture.detectChanges();
  });


  afterAll(() => {
    TestBed.resetTestingModule();
  });


});
