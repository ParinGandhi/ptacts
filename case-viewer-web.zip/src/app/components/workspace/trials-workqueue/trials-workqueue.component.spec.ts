
import { ComponentFixture, TestBed, fakeAsync, flush } from '@angular/core/testing';
import { TrialsWorkqueueComponent } from './trials-workqueue.component';
import { ActivatedRoute } from '@angular/router';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { TrialsService } from 'src/app/services/trials.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DatePipe } from '@angular/common';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { AgGridModule } from 'ag-grid-angular';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { GridOptions } from 'ag-grid-community';
import { OpenCaseviewerComponent } from '../../common/open-caseviewer/open-caseviewer.component';
import { ImportPanelComponent } from '../modals/import-panel/import-panel.component';
import { provideMockStore } from '@ngrx/store/testing';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { componentFactoryName } from '@angular/compiler';
import { JpViewService } from 'src/app/services/jpview.service';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { of } from 'rxjs';
import { Injectable, EventEmitter } from '@angular/core';
import { InfoModalComponent } from '../../common/info-modal/info-modal.component';
import { CreateTaskComponent } from '../create-task/create-task.component';

const workQueueMock = {
  groupCompletedTasksCount: null,
  teamCompletedTasksCount: null,
  allowedResourceObjectList: [
    "panel_Update"
  ],
  ptabDefaultRefreshTime: 300000,
  activeTasksCount: null,
  groupActiveTasksCount: null,
  ptabReadOnlyUser: false,
  teamActiveTasksCount: null,
  completedTasksCount: null,
  workerTasksList: [
    {
      judgePanelList: null,
      customDescriptionText: "System Task(s) Description",
      taskRequested: "Review Appeal",
      taskTypeName: "RA",
      assigneeUserIdentifier: null,
      statutoryDate: null,
      proceedingNumber: "IPR2014-00504",
      assigneeName: null,
      customTaskText: "System Task(s)",
      deadLineDate: 1600660800000,
      poApplicationIdentifier: "10386691",
      aiaReviewStatus: "Final Written Decision",
      assignerUserIdentifier: "system",
      taskPriorityCode: "U",
      assignerName: "System, System",
      comments: null,
      petitionerName: "Motorola Mobility LLC",
      trialType: "IPR",
      requesterUserIdentifier: "sbartlett",
      poPatentNumber: "7382771",
      lastModifiedUserName: "Bartlett, Steven",
      priority: "Urgent",
      taskIdentifier: 1442864,
      lastModifiedTimestamp: 1615227627057,
      statusDescription: "ACTIVE",
      petitionerApplicationIdentifier: null,
      respondentName: "Intellectual Ventures I LLC",
      completionDate: null,
      assignmentDate: 1600401600000,
      taskStatusDate: null,
      taskStatusCode: "AC",
      taskRequestedDate: 1395174292000
    }
  ]
};

describe('TrialsWorkqueueComponent', () => {
  let component: TrialsWorkqueueComponent;
  let trialsService: TrialsService;
  let gridHelper: GridHelperService;
  let modalService: BsModalService
  let commonUtils: CommonUtilitiesService;
  let gridOptions: GridOptions = <GridOptions>{};
  let fixture: ComponentFixture<TrialsWorkqueueComponent>;

  const jpServiceMock = {
    getWorkQueue: () => of({ workerTasksList: [{ petitionerName: '03/04/1991', judgePanelList: [{ lastName: 'test' }] }] }),
    markCompleteWorkQueue: () => of({ recordsForAction: 'Test' })

  };

  @Injectable()
  class StubbedModalService {
    public show(): void { }
  }

  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => { },
    error: (
      message?: string,
      title?: string
    ) => { },
  };

  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "08423235",
        caseNumber: "2020005372"
      }
    }
  };
  let reason = {
    initialState: {
      modal: {
        isConfirm: true
      }
    }
  }
  class modalServiceMock {
    // hide: () => {},
    // show:() => {return {onHide:() => {return of(reason)}}}
    show = (infoModalComponent: CreateTaskComponent) => { return { onHide: () => { return of(reason) } } }
    hide = () => { return {} }
  };

  const loggedInUserInfo = {
    activeIn: "Active",
    apjSeniorityRank: 85,
    disiplanceCd: "Electrical",
    emailAddress: "Test_Jennifer.Bisk@USPTO.GOV",
    firstName: "Jennifer",
    fullName: "Bisk, Jennifer S.",
    jobClassificationCode: "APJ",
    lastName: "Bisk",
    leadApjIndicator: "APJ1",
    loginId: "jbisk",
    preferredFullName: "Bisk, Jennifer S.",
    privileges: null,
    roleDescription: "Judge",
    trialJudgeIndicator: "Judge",
    userIdentiifier: 5017,
    userWorkerNumber: "88548",
    isAdmin: false
  };

  const failure = {
    error: {
      message: "Error"
    }
  };


  const gridApiMock = {
    setFilterModel: () => { },
    getDisplayedRowCount: () => {
      return 5;
    },
    getFilterModel: () => {
      const filterModelMock = {
        status: {
          filter: "n",
          filterType: "text",
          type: "contains"
        }
      }
      return filterModelMock;
    },
    exportDataAsCsv: () => { },
    getSelectedRows: () => { }
  }

  beforeEach(async () => {
    const commonUtilitiesServiceStub = () => ({
      setTypeaheadOptions: () => ({}),
      setTypeaheadList: (decisionOutComeTypes, string, string1) => ({}),
      parseKeyDates: (mileStoneDt, dESC) => ({}),
      convertDatePickerToEpoch: fromDate => ({}),
      convertDatePickerToDisplayDate: institutionDateFrom => ({}),
      setDateOnDatePicker: dateVal => ({})
    });
    const gridHelperServiceStub = () => ({
      convertDateToString: arg => ({}),
      convertDateToTimeStamp: arg => ({}),
      // paginationSetPageSize: arg => ({}),
      onFilterChanged: gridApi => ({ numberOfFilters: {} }),
      exportDataAsCsv: (gridApi, string) => ({})
    });
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, AgGridModule.withComponents([])],
      declarations: [TrialsWorkqueueComponent, OpenCaseviewerComponent, ImportPanelComponent],
      providers: [
        provideMockStore({
          selectors: [
            { selector: CaseViewerSelectors.caseInfoData, value: { proceedingNo: '37553565' } },
            {
              selector: CaseViewerSelectors.userInfoData, value: {
                caseDetailsData: [{
                  activeIn: "Active",
                  apjSeniorityRank: 85,
                  disiplanceCd: "Electrical",
                  emailAddress: "Test_Jennifer.Bisk@USPTO.GOV",
                  firstName: "Jennifer",
                  fullName: "Bisk, Jennifer S.",
                  jobClassificationCode: "APJ",
                  lastName: "Bisk",
                  leadApjIndicator: "APJ1",
                  loginId: "jbisk",
                  preferredFullName: "Bisk, Jennifer S.",
                  privileges: null,
                  roleDescription: "Judge",
                  trialJudgeIndicator: "Judge",
                  userIdentiifier: 5017,
                  userWorkerNumber: "88548",
                  isAdmin: false
                }]
              }
            }
          ]
        }),
        DatePipe,
        TrialsService,
        BsModalService,
        GridHelperService,
        {
          provide: CommonUtilitiesService,
          useFactory: commonUtilitiesServiceStub
        },
        {
          provide: JpViewService,
          useValue: jpServiceMock
        },
        { provide: GridHelperService,
          useFactory: gridHelperServiceStub
        },
        {
          provide: ToastrService,
          useValue: toastrService
        },
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        },
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useClass: modalServiceMock
        }
      ]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TrialsWorkqueueComponent);
    trialsService = TestBed.inject(TrialsService);
    gridHelper = TestBed.inject(GridHelperService)
    modalService = TestBed.inject(BsModalService);
    commonUtils = TestBed.inject(CommonUtilitiesService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    let userInfo = JSON.stringify(loggedInUserInfo);
    window.sessionStorage.setItem('userInfo', userInfo);
    expect(component).toBeTruthy();
  });

  it('should create getWorkQueue with task', fakeAsync(() => {

    // spyOn(jpServiceMock, 'getWorkQueue').and.returnValue(of(mockWorkQueueList));
    component.getWorkQueue();
    expect(component.rowData.length).toBeDefined();

  }));

  it('should create getWorkQueue with task failure', () => {
    // const toastrServiceStub: ToastrService = fixture.debugElement.injector.get(
    //   ToastrService
    // );
    // const jpViewService = TestBed.inject(JpViewService);
    const trialsService = TestBed.inject(TrialsService);

    spyOn(trialsService, 'getWorkQueue').and.returnValue(throwError(failure));
    //spyOn(toastrServiceStub, 'error').and.callThrough();
    component.getWorkQueue();
    expect(component.showLoading).toBeFalsy();
    //expect(toastrServiceStub.error).toBeDefined();
  });


  it('should create markComplete ', fakeAsync(() => {
    component.recordsForAction = [{ petitionerNameVsrespondentName: 'shsh' }]
    component.markComplete();
    expect(component.completeObj.tasksList.length).toBe(0);
    flush();
  }));


  it('should create markComplete failure', () => {
    // const jpViewService = TestBed.inject(JpViewService);
    const trialsService = TestBed.inject(TrialsService);
    // spyOn(jpViewService, 'markCompleteWorkQueue').and.returnValue(throwError(failure));
    spyOn(trialsService, 'markCompleteWorkQueue').and.returnValue(throwError(failure));
    component.recordsForAction = [{ petitionerNameVsrespondentName: 'shsh' }]
    component.markComplete();
    expect(component.completeObj.tasksList.length).toBe(0);
  });

  it('should call openUPdateMOdal', () => {
    const emitter = new EventEmitter();
    emitter.emit(true);

    modalService.show = (): BsModalRef => {
      return ({ id: null, hide: null, setClass: null, onHide: emitter, onHidden: null });
    };

    spyOn(component, "openUPdateMOdal").and.callThrough();
    component.openUPdateMOdal();
    expect(component.openUPdateMOdal).toHaveBeenCalled();

  });

  it('should call openBulkReassignModal', () => {
    const emitter = new EventEmitter();
    emitter.emit(true);

    modalService.show = (): BsModalRef => {
      return ({ id: null, hide: null, setClass: null, onHide: emitter, onHidden: null });
    };

    spyOn(component, "openBulkReassignModal").and.callThrough();
    component.openBulkReassignModal();
    expect(component.openBulkReassignModal).toHaveBeenCalled();

  });


  it('should invoke onFilterChanged', () => {
    const data = {
      api: component.gridApi,
      columnApi: component.gridColumnApi
    }
    component.gridApi = gridApiMock;
    component.onFilterChanged();
    fixture.detectChanges();
  });


  it('should export data as csv', () => {
    const data = {
      api: component.gridApi,
      columnApi: component.gridColumnApi
    }
    component.gridApi = gridApiMock;
    component.exportDataAsCsv();
    fixture.detectChanges();
  });


  it('should call onRowSelected', () => {
    component.gridApi = gridApiMock;
    component.onRowSelected();
    fixture.detectChanges();
  });


  it('should clear filters', () => {
    component.gridApi = gridApiMock;
    component.clearGridFilters();
    fixture.detectChanges();
  });


  afterAll(() => {
    TestBed.resetTestingModule();
  });

});