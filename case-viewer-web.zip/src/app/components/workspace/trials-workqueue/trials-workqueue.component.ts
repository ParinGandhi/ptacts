import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import { JpViewService } from 'src/app/services/jpview.service';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import { ToastrService } from 'ngx-toastr';
import { Store, select } from '@ngrx/store';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import DataTableModel from 'src/app/models/common/dataTable.model';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import * as CaseViewerActions from 'src/app/store/case-viewer/case-viewer.actions';
import { BulkReassignComponent } from '../modals/bulk-reassign/bulk-reassign.component';
import { OpenCaseviewerComponent } from '../../common/open-caseviewer/open-caseviewer.component';
import { DatePipe } from '@angular/common';
import { ICellRendererParams } from 'ag-grid-community';
import { ToolTipComponent } from '../tool-tip/tool-tip.component';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { CreateTaskComponent } from '../create-task/create-task.component';
import { CommonUtilitiesService } from '../../../services/common-utilities.service';
import { TrialsService } from 'src/app/services/trials.service';
import { take } from 'rxjs/operators';


@Component({
  selector: 'app-trials-workqueue',
  templateUrl: './trials-workqueue.component.html',
  styleUrls: ['./trials-workqueue.component.less']
})
export class TrialsWorkqueueComponent implements OnInit {
  caseInfo: CaseInfoModel;
  workQueueData: DataTableModel;
  enableCheckbox: boolean = true
  loggedInUser: any;
  loggedInUser$ = this.store.pipe(select(CaseViewerSelectors.userInfoData));
  isSplAdmin: boolean = false;
  recordsForAction: any[] = [];
  disableAction: boolean = true;
  updateTaskModelRef: BsModalRef;
  disableUpdate: boolean = false;
  caseNumberSearch: any;
  orderByField: any[] = [];
  workQueueTemp: any[] = [];
  totalRecords: any;
  date = new Date();
  refreshFailed: boolean = false;
  lastRefresh = new Date();
  showLoading: boolean = false;
  numberOfFilters: number = 0;
  autoRefresh: boolean = false;
  colState: any;

  gridApi;
  gridColumnApi;
  frameworkComponents;

  defaultColDef = {
    filter: true,
    sortable: true,
    floatingFilter: true,
    suppressMenu: true,
    tooltipComponent: 'customTooltip',
    headerCheckboxSelection: this.isFirstColumn,
    checkboxSelection: this.isFirstColumn,
  };
  rowSelection = 'multiple';

  columnDefs = [
    {
      headerName: '',
      field: '',
      width: 25,
      minWidth: 25,
      maxWidth: 25,
      resizable: false,
      floatingFilter: false,
      headerCheckboxSelection: true,
      cellStyle: { 'background-color': '#F0F0EE' }
    },
    {
      headerName: 'AIA Review #',
      field: 'proceedingNumber',
      width: 130,
      minWidth: 130,
      resizable: true,
      cellRendererFramework: OpenCaseviewerComponent,
      tooltipField: 'AIA Review #'
    },
    {
      headerName: 'Requested date',
      field: 'taskRequestedDateStr',
      width: 100,
      minWidth: 100,
      resizable: true,
      sort: 'desc',
      comparator: this.gridHelper.dateComparator,
      type: 'date'
    },
    {
      headerName: 'Task title',
      field: 'taskRequested',
      width: 200,
      minWidth: 200,
      resizable: true,
      wrapText: true,
      autoHeight: true
    },
    {
      headerName: 'Assigned by',
      field: 'assignerName',
      width: 175,
      minWidth: 175,
      resizable: true
    },
    {
      headerName: 'Assigned to',
      field: 'assigneeName',
      width: 175,
      minWidth: 175,
      resizable: true
    },
    {
      headerName: 'Statutory deadline',
      field: 'statutoryDateStr',
      width: 80,
      minWidth: 80,
      resizable: true,
      comparator: this.gridHelper.dateComparator,
      type: 'date'
    },
    {
      headerName: 'AIA Review status',
      field: 'aiaReviewStatus',
      width: 200,
       minWidth: 200,
      resizable: true,
      wrapText: false,
      autoHeight: false
    },
    {
      headerName: 'Petitioner vs. PO/Respondent',
      field: 'petitionerNameVsrespondentName',
      // cellRendererFramework: ToolTipComponent,
      // cellRendererParams: (params: ICellRendererParams) => this.gridHelper.formatPetVsPOTooltip(params),
      tooltipField: 'petitionerNameVsrespondentName',
      tooltipComponentParams: { data: 'petitionerNameVsrespondentName' },
      width: 225,
      minWidth: 225,
      resizable: true,
      wrapText: false,
      autoHeight: false
    },
    {
      headerName: 'Petitioner patent/appln #',
      valueGetter: this.gridHelper.valueGetterPetitionerPatentNo,
      width: 125,
      minWidth: 125,
      resizable: true
    },
    {
      headerName: 'PO/Respondent patent/appln #',
      valueGetter: this.gridHelper.valueGetterPOPatentNo,
      width: 125,
      minWidth: 125,
      resizable: true
    },
    // { headerName: 'Judge panel', field: 'judgeNamesList', width: 150, minWidth: 150, resizable: true, cellRendererFramework: ToolTipComponent, cellRendererParams: (params: ICellRendererParams) => this.gridHelper.formatJudgePanelTooltip(params) },
    {
      headerName: 'Task due date',
      field: 'deadLineDateStr',
      width: 125,
      minWidth: 125,
      resizable: true,
      comparator: this.gridHelper.dateComparator,
      type: 'date'
    },
    // { headerName: 'Comments', field: 'comments', minWidth: 150, cellRendererFramework: ToolTipComponent, cellRendererParams: (params: ICellRendererParams) => this.gridHelper.formatCommentsTooltip(params) },
    {
      headerName: 'Last modified timestamp',
      field: 'lastModifiedTimestampStr',
      width: 200,
      minWidth: 200,
      resizable: true,
      comparator: this.gridHelper.sortedDates,
      type: 'timestamp'
    },
    {
      headerName: 'Last modified user',
      field: 'lastModifiedUserName',
      width: 175,
      minWidth: 175,
      resizable: true
    },
    {
      headerName: 'Trial type ',
      field: 'trialType',
      width: 110,
      minWidth: 110,
      resizable: true
    }
  ];

  rowClassRules = {
    'alternate-row': function (params) {
      return params.node.rowIndex % 2 === 1;
    }
  }

  rowData: Array<any> = [];
  workQueue: any;
  filterOn: boolean = false;
  finalCount: any;

  constructor(
    private activatedRoute: ActivatedRoute,
    private jpViewService: JpViewService,
    private trialsService: TrialsService,
    private store: Store<CaseViewerState>,
    private modalService: BsModalService,
    private toastr: ToastrService,
    private datePipe: DatePipe,
    private gridHelper: GridHelperService,
    private commonUtils: CommonUtilitiesService
  ) { }


  ngOnInit(): void {
    this.frameworkComponents = { customTooltip: ToolTipComponent };

    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };
    this.store.pipe(select(CaseViewerSelectors.userInfoData)).subscribe(data => {
      this.loggedInUser = data.caseDetailsData[0];
      if (!this.loggedInUser) {
        this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
      }
    })
    this.getWorkQueue();
    setInterval(()=>{
      let ele =document.getElementById('autorefreshWorkQ');
      if(ele){ele.click();}
    },300000)
  }


  completeObj = {
    "tasksList": []
  }

   autoRefreshWorkQ() {
    this.colState = this.gridApi.getFilterModel();
    this.autoRefresh = true;
    this.showLoading = false;
    this.getWorkQueue();
  }

/*istanbul ignore next*/
  getWorkQueue() {
    this.recordsForAction = [];
    this.numberOfFilters = 0;
    this.filterOn = false;
    if(this.autoRefresh){
    this.showLoading = false;
    }else{
      this.showLoading = true;
    }
    let dataToFilter = {
      "unassigneeFlag": true,
      "activeOnly": true,
      "taskBelongsTo": null,
      "startDate": null,
      "endDate": null,
      "includeSystemGenerated": true

    }
    // this.jpViewService.getWorkQueue(`/worker-task/details`, dataToFilter).subscribe((response) => {
    this.trialsService.getWorkQueue(dataToFilter).pipe(take(1)).subscribe((response) => {
      this.showLoading = false;
      this.refreshFailed = false;
      if (response && response.workerTasksList.length > 0) {
        this.totalRecords = response.workerTasksList.length;
        this.workQueue = response.workerTasksList;

        for (let i = 0; i < this.workQueue.length; i++) {
          response.workerTasksList[i].judgeNamesList = [];
          this.workQueue[i].petitionerNameVsrespondentName = this.workQueue[i].petitionerName ? this.workQueue[i].petitionerName : '';
          if (this.workQueue[i].respondentName) {
            this.workQueue[i].petitionerNameVsrespondentName += ` vs ${this.workQueue[i].respondentName}`;
          }
          // this.workQueue[i].petitionerNameVsrespondentName = this.workQueue[i].petitionerName? this.workQueue[i].petitionerName : '' + (this.workQueue[i].respondentName ? " vs " : '') + (this.workQueue[i].respondentName ? this.workQueue[i].respondentName : '');
          this.workQueue[i].judgePanel = this.workQueue[i].judgePanelList ? (this.workQueue[i].judgePanelList[0].lastName ? this.workQueue[i].judgePanelList[0].lastName : "") + " " + (this.workQueue[i].judgePanelList[0].firstName ? this.workQueue[i].judgePanelList[0].firstName : "") + " " + (this.workQueue[i].judgePanelList[0].middleInitial ? this.workQueue[i].judgePanelList[0].middleInitial : null) : '';
          this.workQueue[i].panelCount = this.workQueue[i].judgePanelList ? this.workQueue[i].judgePanelList.length : null;

          // this.workQueue[i].taskRequestedDate = this.commonUtils.parseKeyDates(this.workQueue[i].milestoneDates,"Notice of Accorded Filing Date");
          response.workerTasksList[i].taskRequestedDateStr = this.gridHelper.convertDateToString(response.workerTasksList[i].accordedFilingDate);
              response.workerTasksList[i].statutoryDateStr = this.gridHelper.convertDateToString(response.workerTasksList[i].statutoryDate);
              response.workerTasksList[i].deadLineDateStr = this.gridHelper.convertDateToString(response.workerTasksList[i].deadLineDate);
              response.workerTasksList[i].lastModifiedTimestampStr = this.gridHelper.convertDateToTimeStamp(response.workerTasksList[i].lastModifiedTimestamp);
              if(response.workerTasksList[i].judgePanelList && response.workerTasksList[i].judgePanelList.length > 0){
                response.workerTasksList[i].judgePanelList.forEach(element => {
                  response.workerTasksList[i].judgeNamesList.push((element.lastName?element.lastName: "") + " "+ (element.firstName?element.firstName: "") + " "+ (element.middleInitial?element.middleInitial:""))
                });
              }
        }
      }
      this.rowData = this.workQueue ? this.workQueue : [];
      if(this.colState){
        setTimeout(() => {
          this.gridApi.setFilterModel(this.colState);
        }, 100);
      }
      this.autoRefresh = false;
      this.lastRefresh = new Date();
    }, (failure) => {
      this.showLoading = false;
      this.refreshFailed = true;
      this.toastr.error(`${failure.error.message}`, "", {
        closeButton: true
      });
    });
  };



  markComplete() {
    if (this.recordsForAction.length > 0) {

      this.recordsForAction.forEach((task) => {
        task.petitionerNameVsrespondentName = null;
        task.judgePanel = null;
        task.panelCount = null;
        task.assigneeUserIdentifier = this.loggedInUser.loginId;
        task.assignerUserIdentifier = this.loggedInUser.loginId;
        task.assignmentDate = new Date(task.taskRequestedDate).getTime();
        task.requesterUserIdentifier = task.requesterUserIdentifier ? task.requesterUserIdentifier : this.loggedInUser.loginId;
        task.completionDate = new Date(this.lastRefresh).getTime(),
          task.audit = {
            "createUserIdentifier": this.loggedInUser.loginId,
            "lastModifiedUserIdentifier": this.loggedInUser.loginId,
            "lastModifiedTimestamp": new Date(this.lastRefresh).getTime(),
            "createTimestamp": new Date(this.lastRefresh).getTime()
          }
      })
      this.completeObj = {
        tasksList: this.recordsForAction
      };

      // this.jpViewService.markCompleteWorkQueue("/worker-task/bulk", this.completeObj).subscribe((response) => {
      this.trialsService.markCompleteTaskWorkQueue(this.completeObj).subscribe((response) => {
        this.completeObj.tasksList = [];
        this.toastr.success(`Task(s) successfully marked complete`, "", {
          closeButton: true
        });
        this.getWorkQueue();
      }, (failure) => {
        this.completeObj.tasksList = [];
        this.toastr.error(`${failure.error.message}`, "", {
          closeButton: true
        });
      });
    }
  };



  openUPdateMOdal() {
    const initialState = {
      modal: {
        title: `Update`,
        closeBtnName: "Done",
        isConfirm: false,
        workQueueInfo: this.recordsForAction[0],
        caseInfo: this.caseInfo,
        loggedInUser: this.loggedInUser,
        modalType: 'updateWorkqueue'
      }
    };
    this.updateTaskModelRef = this.modalService.show(CreateTaskComponent, {
      animated: true,
      backdrop: true,
      ignoreBackdropClick: true,
      class: 'add-update-parties-modal-content',
      initialState
    });
    this.updateTaskModelRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        this.getWorkQueue();
      }
    })
  }




  openBulkReassignModal() {
    const initialState = {
      modal: {
        title: `Update`,
        closeBtnName: "Done",
        isConfirm: false,
        workQueueInfo: this.recordsForAction,
        caseInfo: this.caseInfo,
        loggedInUser: this.loggedInUser,
        modalType: 'updateTask'
      }
    };
    this.updateTaskModelRef = this.modalService.show(BulkReassignComponent, {
      animated: true,
      backdrop: true,
      ignoreBackdropClick: true,
      class: 'add-update-parties-modal-content',
      initialState
    });
    this.updateTaskModelRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        this.recordsForAction = [];
        // this.numberOfFilters = 0;
        this.getWorkQueue();
       if(document.getElementById('taskRefresh')) {
         document.getElementById('taskRefresh').click();
        }
      }
    })
  }



  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }

  onRowSelected() {
    this.recordsForAction = this.gridApi.getSelectedRows();

  }

  onFilterChanged() {
    this.filterOn = true;
    this.finalCount = this.gridApi.getDisplayedRowCount();
    const filterModel = this.gridApi.getFilterModel();
    this.numberOfFilters = Object.keys(filterModel).length;
  }


  isFirstColumn(params) {
    let displayedColumns = params.columnApi.getAllDisplayedColumns();
    let thisIsFirstColumn = displayedColumns[0] === params.column;
    return thisIsFirstColumn;
  }


  clearGridFilters() {
    this.gridApi.setFilterModel(null);
  }


  exportDataAsCsv() {
    let fileName: string = `AIA Trials Workqueue`;
    this.gridHelper.exportDataAsCsv(this.gridApi, fileName);
  }


}
