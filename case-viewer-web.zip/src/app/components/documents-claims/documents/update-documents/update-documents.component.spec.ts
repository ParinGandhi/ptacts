import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { JpViewService } from 'src/app/services/jpview.service';
import { TrialsService } from 'src/app/services/trials.service';
import { Store, select } from '@ngrx/store';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { ToastrService } from 'ngx-toastr';
import { InfoModalComponent } from 'src/app/components/common/info-modal/info-modal.component';
import { CommonService } from 'src/app/services/common.service';
import { DatePipe } from '@angular/common';
import { Observable, of } from 'rxjs';
import { provideMockStore } from '@ngrx/store/testing';
import { UpdateDocumentsComponent } from './update-documents.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { FilterPipe } from 'src/app/utilities/table-filter-pipe';

describe('UpdateDocumentsComponent', () => {
  let component: UpdateDocumentsComponent;
  let trialsService: TrialsService;
  let jpViewService: JpViewService;
  let commonUtils: CommonUtilitiesService;
  let modalService: BsModalService;
  let toastr: ToastrService
  let commonService: CommonService;
  let fixture: ComponentFixture<UpdateDocumentsComponent>;

  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => {},
    error: (
      message?: string,
      title?: string
    ) => {},
  };


  const modalMock = {
    caseInfo: {
      proceedingNo: "1234567",
      isConfirm: false
    }
  }


  const loggedInUserInfo = {
    caseDetailsData:
      [{
        activeIn: "Active",
        apjSeniorityRank: 85,
        disiplanceCd: "Electrical",
        emailAddress: "Test_Jennifer.Bisk@USPTO.GOV",
        firstName: "Jennifer",
        fullName: "Bisk, Jennifer S.",
        jobClassificationCode: "APJ",
        lastName: "Bisk",
        leadApjIndicator: "APJ1",
        loginId: "jbisk",
        preferredFullName: "Bisk, Jennifer S.",
        privileges: null,
        roleDescription: "Judge",
        trialJudgeIndicator: "Judge",
        userIdentiifier: 5017,
        userWorkerNumber: "88548",
        isAdmin: false
        }
      ]
  };

  const theTableOptions = {
    tableId: "updateDocumentsTable",
    tableHeaderClass: "updateDocumentsTableHeader",
    tableBodyClass: "updateDocumentsTableBody",
    columnDefs: [
      {
        name: "",
        displayName: "",
        field: "",
        width: "25px",
        type: "radio",
        searchText: null
      },
      {
        name: "Doc #",
        displayName: "Doc #",
        field: "docNo",
        width: "80px",
        type: "string",
        searchText: null
      },
      {
        name: "Filing date",
        displayName: "Filing date",
        field: "filingDate",
        width: "155px",
        type: "date",
        searchText: null
      },
      {
        name: "Doc type",
        displayName: "Doc type",
        field: "category",
        width: "110px",
        type: "string",
        searchText: null
      },
      {
        name: "Paper type",
        displayName: "Paper type",
        // field: "name",
        field: "documentTypeDescription",
        width: "200px",
        type: "string",
        searchText: null
      },
      {
        name: "Document name",
        displayName: "Document name",
        // field: "fileName",
        field: "name",
        width: "",
        type: "string",
        searchText: null
      },
      {
        name: "Pages",
        displayName: "Pages",
        field: "pageCount",
        width: "60px",
        type: "string",
        searchText: ""
      },
      {
        name: "Filing party",
        displayName: "Filing party",
        field: "filingParty",
        width: '150px',
        type: "string",
        searchText: ""
      },
      {
        name: "Availability",
        displayName: "Availability",
        field: "availability",
        width: "225px",
        type: "string",
        searchText: ""
      },
      {
        name: "Action(s)",
        displayName: "Action(s)",
        field: "availability",
        width: "95px",
        type: "action",
        searchText: ""
      }
    ]
  };
  const availabilityListMockResponse = [{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},{"code":"PRIVATE","descriptionText":"Available to parties and board.","displayNameText":"Parties and Board"},{"code":"CONFIDENTIAL","descriptionText":"Available to filing party and board.","displayNameText":"Filing party and Board"},{"code":"BOARD","descriptionText":"Available only to board.","displayNameText":"Board "}];


  const filingPartyListMockResponse = [{"code":"BOARD","descriptionText":"Board","displayNameText":"Board"},{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"}];

  const paperTypeListMockResponse =[{"identifier":241,"code":"ADVR:POSTINST","descriptionText":"Adverse judgement:  post-institution","displayNameText":"Adverse judgement:  post-institution","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616365655","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":240,"code":"ADVR:PREINST","descriptionText":"Adverse judgment:  pre-institution","displayNameText":"Adverse judgment:  pre-institution","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616365655","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":212,"code":"FINAL:FW","descriptionText":"Final Written Decision:  original","displayNameText":"Final Written Decision:  original","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616365655","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":213,"code":"FINAL:RH","descriptionText":"Final Written Decision:  rehearing","displayNameText":"Final Written Decision:  rehearing","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616365655","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":214,"code":"FINAL:RMD","descriptionText":"Final written decision:  On remand","displayNameText":"Final written decision:  On remand"},{"identifier":209,"code":"ID:DENY","descriptionText":"Institution Decision:  Deny","displayNameText":"Institution Decision:  Deny","documentTypeCustomAttributes":{"motionTypeIds":[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23],"rehearingIds":[1,2,3],"attributes":[{"id":5,"label":"Decision to Institute","dataType":"date","uielementId":"ID_DEC_INST","value":"1616365655","mandatory":false,"rolesForEdit":["XXX"]},{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERMDT","value":"1616365655","mandatory":false,"rolesForEdit":["XXX"]}]}},{"identifier":208,"code":"ID:GRANT","descriptionText":"Institution Decision:  Grant","displayNameText":"Institution Decision:  Grant ","documentTypeCustomAttributes":{"motionTypeIds":[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23],"rehearingIds":[1,2,3],"attributes":[{"id":5,"label":"Decision to Institute","dataType":"date","uielementId":"ID_DEC_INST","value":"1616365655","mandatory":false,"rolesForEdit":["XXX"]},{"id":11,"label":"Hearing date","dataType":"date","uielementId":"ID_HRGDT","value":"1616365655","mandatory":false,"rolesForEdit":["Paralegal/LIE","Supervisor","Patent Attorney","Business Administrator","Judge"]}]}},{"identifier":211,"code":"ID:RHDENY","descriptionText":"Institution Decision:  denying institution on request for rehearing","displayNameText":"Institution Decision:  denying institution on request for rehearing"},{"identifier":210,"code":"ID:RHGRNT","descriptionText":"Institution Decision:  granting institution on request for rehearing","displayNameText":"Institution Decision:  granting institution on request for rehearing"},{"identifier":215,"code":"MOT:PHV","descriptionText":"Motion: PHV","displayNameText":"Motion PHV"},{"identifier":221,"code":"MOT:JNDR","descriptionText":"Motion:  Joinder","displayNameText":"Motion:  Joinder"},{"identifier":219,"code":"MOT:ADVRS","descriptionText":"Motion:  Motion for Adverse Judgment","displayNameText":"Motion:  Motion for Adverse Judgment"},{"identifier":216,"code":"MOT:AMD","descriptionText":"Motion:  Motion to Amend","displayNameText":"Motion:  Motion to Amend"},{"identifier":217,"code":"MOT:DIS","descriptionText":"Motion:  Motion to dismiss due to settlement (pre-DI)","displayNameText":"Motion:  Motion to dismiss due to settlement (pre-DI)"},{"identifier":218,"code":"MOT:TERM","descriptionText":"Motion:  Motion to terminate due to settlement (post DI)","displayNameText":"Motion:  Motion to terminate due to settlement (post DI)"},{"identifier":220,"code":"MOT:ORLHRREQ","descriptionText":"Motion:  Oral Hearing Request","displayNameText":"Motion:  Oral Hearing Request"},{"identifier":222,"code":"MOT:OTH","descriptionText":"Motion:  Other","displayNameText":"Motion:  Other"},{"identifier":243,"code":"NOT:MN","descriptionText":"Notice:  Mandatory Notice","displayNameText":"Notice:  Mandatory Notice"},{"identifier":244,"code":"NOT:NOFDA","descriptionText":"Notice:  Notice filing date accorded","displayNameText":"Notice:  Notice filing date accorded","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":2,"label":"Accorded filing date","dataType":"date","uielementId":"ID_NOFD","value":"1616365655","mandatory":true},{"id":3,"label":"Notice mailed date","dataType":"date","uielementId":"ID_MNOFD","value":"1616365655","mandatory":true}]}},{"identifier":257,"code":"NOTOTH","descriptionText":"Notice:  Other","displayNameText":"Notice:  Other"},{"identifier":242,"code":"NOT:POA","descriptionText":"Notice:  Power of Attorney","displayNameText":"Notice:  Power of Attorney"},{"identifier":247,"code":"NOT:ACPTCPET","descriptionText":"Notice:  acceptance corrected petition","displayNameText":"Notice:  acceptance corrected petition"},{"identifier":246,"code":"NOT:DEFCTPET","descriptionText":"Notice:  defective petition","displayNameText":"Notice:  defective petition","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":2,"label":"Accorded filing date","dataType":"date","uielementId":"ID_NOFD","value":"1616365655","mandatory":true},{"id":3,"label":"Notice mailed date","dataType":"date","uielementId":"ID_MNOFD","value":"1616365655","mandatory":true}]}},{"identifier":251,"code":"NOT:DEMNS","descriptionText":"Notice:  demonstratives","displayNameText":"Notice:  demonstratives"},{"identifier":250,"code":"NOT:EXBH","descriptionText":"Notice:  exhibit list","displayNameText":"Notice:  exhibit list"},{"identifier":245,"code":"NOT:INCMPLTPET","descriptionText":"Notice:  incomplete petition","displayNameText":"Notice:  incomplete petition"},{"identifier":248,"code":"NOT:MNUPD","descriptionText":"Notice:  mandatory notice update","displayNameText":"Notice:  mandatory notice update"},{"identifier":252,"code":"NOT:NOA","descriptionText":"Notice:  notice of appeal","displayNameText":"Notice:  notice of appeal"},{"identifier":249,"code":"NOT:DEPS","descriptionText":"Notice:  notice of deposition","displayNameText":"Notice:  notice of deposition"},{"identifier":256,"code":"NOT:RCPTPOPR","descriptionText":"Notice:  notice of receipt of POP request","displayNameText":"Notice:  notice of receipt of POP request"},{"identifier":255,"code":"NOT:PRATRFAPR","descriptionText":"Notice:  partial refund approved","displayNameText":"Notice:  partial refund approved"},{"identifier":253,"code":"NOT:RFNDAprv","descriptionText":"Notice:  refund approved","displayNameText":"Notice:  refund approved"},{"identifier":254,"code":"NOT:RFNDDNY","descriptionText":"Notice:  refund denied","displayNameText":"Notice:  refund denied"},{"identifier":227,"code":"OPP","descriptionText":"Opposition","displayNameText":"Opposition"},{"identifier":229,"code":"ORD:AddBRF","descriptionText":"Order:  Additional Briefing","displayNameText":"Order:  Additional Briefing"},{"identifier":234,"code":"ORD:OTH","descriptionText":"Order:  Other","displayNameText":"Order:  Other"},{"identifier":232,"code":"ORD:TERM","descriptionText":"Order:  Termination as to one party","displayNameText":"Order:  Termination as to one party"},{"identifier":233,"code":"ORD:GRANT","descriptionText":"Order:  granting POP Request ","displayNameText":"Order:  granting POP Request "},{"identifier":230,"code":"ORD:MOT","descriptionText":"Order:  on Motion","displayNameText":"Order:  on Motion"},{"identifier":231,"code":"ORD:REQHR","descriptionText":"Order:  on requet for rehearing","displayNameText":"Order:  on requet for rehearing"},{"identifier":259,"code":"OTH:HRTRANS","descriptionText":"Other:  Hearing transcript","displayNameText":"Other:  Hearing transcript"},{"identifier":260,"code":"OTH:AMBRF","descriptionText":"Other:  amicus brief","displayNameText":"Other:  amicus brief"},{"identifier":262,"code":"OTH:FEDCRTD","descriptionText":"Other:  fed circuit mandate","displayNameText":"Other:  fed circuit mandate"},{"identifier":264,"code":"OTH:OTH","descriptionText":"Other:  other","displayNameText":"Other:  other"},{"identifier":263,"code":"OTH:CRTD","descriptionText":"Other:  other court decision","displayNameText":"Other:  other court decision"},{"identifier":261,"code":"OTH:REFRQST","descriptionText":"Other:  refund request","displayNameText":"Other:  refund request"},{"identifier":205,"code":"RESP:PO","descriptionText":"PO Response to Pet","displayNameText":"PO Response to Pet"},{"identifier":207,"code":"REPLY:PETSUR","descriptionText":"PO Sur-Reply to Pet Reply ","displayNameText":"PO Sur-Reply to Pet Reply "},{"identifier":203,"code":"POPR:FILED","descriptionText":"POPR: filed","displayNameText":"POPR: filed"},{"identifier":204,"code":"POPR:WAV","descriptionText":"POPR: waiver","displayNameText":"POPR: waiver"},{"identifier":206,"code":"REPLY:PET","descriptionText":"Pet Reply to PO Resp","displayNameText":"Pet Reply to PO Resp"},{"identifier":201,"code":"PET:ASFILED","descriptionText":"Petition: as filed","displayNameText":"Petition: as filed"},{"identifier":202,"code":"PET:CORREC","descriptionText":"Petititon: corrected","displayNameText":"Petititon: corrected"},{"identifier":225,"code":"RH:FWD","descriptionText":"Rehearing request:  FWD","displayNameText":"Rehearing request:  FWD"},{"identifier":226,"code":"RH:OTH","descriptionText":"Rehearing request:  Other ","displayNameText":"Rehearing request:  Other "},{"identifier":224,"code":"RH:INST","descriptionText":"Rehearing request: Institution","displayNameText":"Rehearing request: Institution"},{"identifier":228,"code":"REPLY:OPP","descriptionText":"Reply to Opposition","displayNameText":"Reply to Opposition"},{"identifier":223,"code":"MOT:SUPP","descriptionText":"Supplemental Brief","displayNameText":"Supplemental Brief"},{"identifier":236,"code":"TERM:POSTSETL","descriptionText":"Termination Decision:  Post-DI Settlement","displayNameText":"Termination Decision:  Post-DI Settlement","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616365655","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":237,"code":"TERM:PREDIS","descriptionText":"Termination Decision:  Pre-DI dismissal","displayNameText":"Termination Decision:  Pre-DI dismissal","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616365655","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":235,"code":"TERM:PRESETL","descriptionText":"Termination Decision:  Pre-DI settlement","displayNameText":"Termination Decision:  Pre-DI settlement","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616365655","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":239,"code":"TERM:VACT","descriptionText":"Termination Decision:  Vacate","displayNameText":"Termination Decision:  Vacate","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616365655","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":238,"code":"TERM:POSTSDIS","descriptionText":"Termination Decision: Post-DI dismissal","displayNameText":"Termination Decision: Post-DI dismissal","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616365655","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":258,"code":"TCERT:CERT","descriptionText":"Trial Certificate Checklist","displayNameText":"Trial Certificate Checklist"}];

  const uploadDocumentMockResponse = [{"documentNumber":4,"name":"Notice of Accord Filing Date","category":"PAPER","fileName":"DER2020-00001 DER Notice of Filing Date Accorded Petition (DER ONLY).pdf","filingParty":"BOARD","availability":"Public","documentTypeIdentifier":7,"documentTypeCode":"NOFDA","documentTypeDescription":"Notice of Filing Date Accorded to Petition","pageCount":3,"contentManagementId":"workspace://SpacesStore/4620050e-9244-4fb4-aea0-57fec5a2eb6a;1.0","artifactIdentifer":169911378,"artifactSubmissionIdentifier":85261516,"filingDate":1581001754,"filingDateString":"02/06/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"BOARD","descriptionText":"Board","displayNameText":"Board"},"artifactSummary":{"code":"PAPER","descriptionText":"Paper"}}]
  let reason ={
    initialState: {
      modal:{
        isConfirm: true
      }
    }
  }
  class modalServiceMock  {
    // hide: () => {},
    // show:() => {return {onHide:() => {return of(reason)}}}
    show = (infoModalComponent:InfoModalComponent)=>{return {onHide:() => {return of(reason)}}}
    hide = () =>{return {}}
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [UpdateDocumentsComponent, FilterPipe],
      providers: [TrialsService, CommonUtilitiesService, DatePipe, JpViewService, CommonService,
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useClass: modalServiceMock

        },
        {
            provide: ToastrService,
            useValue: toastrService
        },
        provideMockStore({
            selectors: [{ selector: CaseViewerSelectors.userInfoData, value: { caseDetailsData: [] } },
            {selector: CaseViewerSelectors.userInfoData,value:{caseDetailsData: [{
              activeIn: "Active",
              apjSeniorityRank: 85,
              disiplanceCd: "Electrical",
              emailAddress: "Test_Jennifer.Bisk@USPTO.GOV",
              firstName: "Jennifer",
              fullName: "Bisk, Jennifer S.",
              jobClassificationCode: "APJ",
              lastName: "Bisk",
              leadApjIndicator: "APJ1",
              loginId: "jbisk",
              preferredFullName: "Bisk, Jennifer S.",
              privileges: null,
              roleDescription: "Judge",
              trialJudgeIndicator: "Judge",
              userIdentiifier: 5017,
              userWorkerNumber: "88548",
              isAdmin: false
              }]}}]
          })
    ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateDocumentsComponent);
    jpViewService = TestBed.inject(JpViewService);
    trialsService = TestBed.inject(TrialsService);
    commonService = TestBed.inject(CommonService);
    modalService = TestBed.inject(BsModalService);
    toastr = TestBed.inject(ToastrService);
    component = fixture.componentInstance;
    component.modal = modalMock;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

   it('It should getNumberOfFilters', () => {

    component.tableOptions = theTableOptions;
    component.getNumberOfFilters();
  });

  it('It should call sortList', () => {
    const a={
      filingDate:1000
    }

    const b = {
      filingDate:2000
    }

    let ret = component.sortList(a, b);

    let ret2 = component.sortList(b,a);
  });

  it('It should call compareValues', () => {


   component.compareValues("filingDate", "asc",null);

  });

  it ("it should call sortColumn", () => {
    component.tableOptions = theTableOptions;
    component.tableOptions.data=[];
    let anObject = {
      name:"hello"
    };
    component.tableOptions.data= JSON.parse(JSON.stringify(uploadDocumentMockResponse));
    component.loggedInUser ={ loginId: "sbartlett"}

    component.sortColumn('-filingDate', 'p');
  });




  it('should call getNextExhibitNumber with success response', () => {
    const mockMotionsGetResponse = {"Patentowner":"2001","Board":"3001","ptabReadOnlyUser":true,"Petitioner":"1023"};
    // spyOn(jpViewService, 'getTrialsInfo').and.returnValue(of(mockMotionsGetResponse));
    spyOn(trialsService, 'getTrialsInfo').and.returnValue(of(mockMotionsGetResponse));
    component.getNextExhibitNumber();
    component.getNumberOfFilters();
  });

  it('should call getDocumentsForUpdate with success response', () => {
    spyOn(trialsService, 'getDocumentsForUpdate').and.returnValue(of(uploadDocumentMockResponse));
    component.getDocumentsForUpdate();
  });


   it('should call getPaperTypeList and return failed response', () => {
    component.loggedInUser ={ loginId: "sbartlett"}
    spyOn(commonService, 'getReferenceData').and.returnValue(of(paperTypeListMockResponse));
    component.getPaperTypeList();
   // expect(component.paperTypeListResponse).toEqual(paperTypeListMockResponse);
   // expect(component.paperTypeList).toEqual(paperTypeListMockResponse);
  });

  it('should call getFilingPartyTypeList and return success response', () => {
    component.loggedInUser ={ loginId: "sbartlett"}
    spyOn(commonService, 'getReferenceData').and.returnValue(of(filingPartyListMockResponse));
    component.getFilingPartyTypeList();
    //expect(component.filingPartyList).toEqual(filingPartyListMockResponse);
  })

  it('should call getAvailabilityList and return success response', () => {
    spyOn(commonService, 'getReferenceData').and.returnValue(of(availabilityListMockResponse));
    component.getAvailabilityList();
    expect(component.availabilityList).toEqual(availabilityListMockResponse);
  });

  it('should call editEdit', () => {
    component.filingPartyList = filingPartyListMockResponse;
  component.availabilityList = availabilityListMockResponse;
  component.paperTypeList = paperTypeListMockResponse;
    let row={
      category:"paper",
      filingParty:"Board",
      availability:"PUBLIC",
      documentTypeCode:"NDF"
    };
    component.enableEdit(row, true, 1);
  });

  it('should validate setDropDownValue for more paper type', () => {
    component.tableOptions = theTableOptions;
    component.tableOptions.data=[];
    let anObject = {
      name:"hello"
    };
    component.tableOptions.data= JSON.parse(JSON.stringify(uploadDocumentMockResponse));
    component.loggedInUser ={ loginId: "sbartlett"}
    spyOn(commonService, 'getReferenceData').and.returnValue(of(paperTypeListMockResponse));
    component.getPaperTypeList();
    component.filingPartyList=filingPartyListMockResponse;
    component.availabilityList=availabilityListMockResponse;
    component.paperTypeList = paperTypeListMockResponse;

    let row={
      category:"Paper",
      filingParty:"Board",
      availability:"PUBLIC",
      documentTypeCode:"NDF"
    };

    let row2={
      category:"exhibits",
      filingParty:"BOARD",
      availability:"PUBLIC",
      documentTypeCode:"NDF"
    };

    let row3={
      category:"exhibits",
      filingParty:"Patent owner",
      availability:"PUBLIC",
      documentTypeCode:"NDF"
    };

    let row4={
      category:"exhibits",
      filingParty:"Petitioner",
      availability:"PUBLIC",
      documentTypeCode:"NDF"
    };
//     component.setEditDropDownValue("BOARD", 0, "filingParty", row2);

    component.setEditDropDownValue("TCERT:CERT", 0, "paperType", row);

    component.setEditDropDownValue("PUBLIC", 0, "availability", row);
//    component.setEditDropDownValue("Patent owner", 0, "filingParty", row3);
//    component.setEditDropDownValue("BOARD", 0, "filingParty", row4);

   component.setEditDropDownValue("BOARD", 0, "filingParty", row4);
component.setEditDropDownValue("PETITIONER", 0, "filingParty", row4);
    component.setEditDropDownValue("PATENT OWNER", 0, "filingParty", row4);

  });

  it('should call saveInoformation', () => {
    spyOn(trialsService, 'updateDocumentInfo').and.returnValue(of(paperTypeListMockResponse));
    let row={
      category:"Paper",
      exhibitNumber:"3001",
      filingParty:"Board",
      availability:"PUBLIC",
      documentTypeCode:"NDF",
      name:"A.PDF"
    };
    component.loggedInUser ={ loginId: "sbartlett"}
    component.selectedFilingDate = "2021-02-04";
    component.saveInformation(row);
  });


  it('should call expungeDOc', () => {
    spyOn(trialsService, 'expungeDocument').and.returnValue(of(paperTypeListMockResponse));
    let row={
      artifactIdentifer: 170084504,
      artifactSubmissionIdentifier: 85426972,
      artifactSummary: {code: "PAPER", descriptionText: "Paper"},
      availability: "Public",
      availablitySummary: {code: "PUBLIC", descriptionText: "Available for everyone.", displayNameText: "Public"},
      category: "PAPER",
      contentManagementId: "workspace://SpacesStore/cdc6e478-413e-416b-98d2-714ac0184e17;1.0",
      directionCode: "INCOMING",
      docNo: 38,
      documentNumber: 38,
      documentStatus: "PENDING",
      documentTypeCode: "TERM:VACT",
      documentTypeDescription: "Termination Decision:  Vacate",
      documentTypeIdentifier: 239,
      fileName: "Test42PVT.pdf",
      fileSize: 0,
      filingDate: 1616374938000,
      filingDateString: "03/21/2021",
      filingParty: "BOARD",
      name: "Termination Decision:  Vacate",
      pageCount: 1
    };
    component.docToExpunge=row;
    component.loggedInUser ={ loginId: "sbartlett"}

    component.expungeDocument();
  });

  it('should call openPDF', () => {
    spyOn(commonService, 'openPdf').and.returnValue();
    let data={};
    component.openPdfFile(data);
  });

  it('should call cancelEdit', () => {
    let row={
      category:"Paper",
      exhibitNumber:"3001",
      filingParty:"Board",
      availability:"PUBLIC",
      documentTypeCode:"NDF",
      name:"A.PDF"
    };

    component.originalRow=row;
    component.editIndex=0;
    component.tableOptions=theTableOptions;
    component.tableOptions.data=[];
    let anObject = {
      name:"hello"
    };
    component.tableOptions.data.push(anObject);
    component.cancelEdit(row, 0);
  });


  it('should call clear all', () => {
    component.tableOptions=theTableOptions;
    component.clearAll();
  });

  it('should call close', () => {
    const initialState = {
      modal: {
        title: "Make document public ?",
        subText: "Document can be viewed by the public unless a different option is chosen",
        closeBtnName: "No, change availability",
        yesBtnName: "Yes, make it public",
        yesBtnClass: "btn-primary",
        isConfirm: false
      }
    };
      modalService.show = (): BsModalRef => {
      return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
        animated: true,
        backdrop: 'static',
        class: 'modal-audit-size',
        initialState
      }}
    }

    modalService.hide = (): BsModalRef => {
      return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
        animated: true,
        backdrop: 'static',
        class: 'modal-audit-size',
        initialState
      }}
    }


    component.editMode=false;
    component.close();

  });


  it('should call close with unsaved changes', () => {
    spyOn(component, 'openAbandonChangesModal');
   component.editMode=true;
    component.close();
  //  expect(component.openAbandonChangesModal).toHaveBeenCalled();
  });


  it('should call close validationPassed', () => {
    let row={
      category:"Paper",
      exhibitNumber:"3001",
      filingParty:"Board",
      availability:"PUBLIC",
      documentTypeCode:"NDF",
      name:""
    };
    component.selectedFilingDate="";
    component.validationPassed(row);
  });

  it('should call close validationPassed', () => {
    let row={
      category:"Paper",
      exhibitNumber:"3001",
      filingParty:"Board",
      availability:"PUBLIC",
      documentTypeCode:"NDF",
      name:""
    };
    component.selectedFilingDate="";
    component.setExpungeLabel("EXE");
  });

  it('should call close validateExhibitNumberRange', () => {
    let row={
      category:"Paper",
      exhibitNumber:3,
      filingParty:"Board",
      availability:"PUBLIC",
      documentTypeCode:"NDF",
      name:""
    };

    component.validateExhibitNumberRange(row);

    let row2={
      category:"Paper",
      exhibitNumber:1,
      filingParty:"Patent owner",
      availability:"PUBLIC",
      documentTypeCode:"NDF",
      name:""
    };
    component.validateExhibitNumberRange(row2);

    let row3={
      category:"Paper",
      exhibitNumber:93001,
      filingParty:"Patent owner",
      availability:"PUBLIC",
      documentTypeCode:"NDF",
      name:""
    };
    component.validateExhibitNumberRange(row3);

    let row4={
      category:"Paper",
      exhibitNumber:93001,
      filingParty:"petitioner",
      availability:"PUBLIC",
      documentTypeCode:"NDF",
      name:""
    };
    component.validateExhibitNumberRange(row4);
  });



});
