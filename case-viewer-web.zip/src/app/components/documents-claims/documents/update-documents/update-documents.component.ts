import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { JpViewService } from 'src/app/services/jpview.service';
import { TrialsService } from 'src/app/services/trials.service';
import { Store, select } from '@ngrx/store';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import { ToastrService } from 'ngx-toastr';
import { InfoModalComponent } from 'src/app/components/common/info-modal/info-modal.component';
import { CommonService } from 'src/app/services/common.service';
import { DatePipe } from '@angular/common';
// import { ConfirmDialogComponent } from 'src/app/shared/confirm-dialog/confirm-dialog.component';
import AlertModel from 'src/app/models/common/Alert.model';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';

@Component({
  selector: 'app-update-documents',
  templateUrl: './update-documents.component.html',
  styleUrls: ['./update-documents.component.less']
})
export class UpdateDocumentsComponent implements OnInit {

  bsModalRef: BsModalRef;
  modal: any;
  loggedInUser = null;
  adminLoggedIn: boolean = false;
  editMode: boolean = false;
  docToExpunge: any = null;
  editIndex: number = null;
  showLoading: boolean = false;
  expungeLabel: string = 'Expunge';
  originalRow: any = null;

  paperTypeListResponse: any;
  paperTypeList: Array < any > ;
  filingPartyList: Array < any > ;
  availabilityList: Array<any>;
  selectedFilingParty: string;
  selectedAvailability: string;
  selectedFilingDate: string;
  selectedPaper: any;
  testDate = new Date();
  documentData: Array<any> = [];
  tableOptions: any;
  orderByField: Array<any> = [];
  oldPaperType: string = null;

  alertOptions: AlertModel;
  selectedDocTypeCode: any = null;

  global = {
    rangeForBoard: {
      min: PtabTrialConstants.EXHIBIT_RANGE.MIN.BOARD,
      max: PtabTrialConstants.EXHIBIT_RANGE.MAX.BOARD
    },
    rangeForPO: {
      min: PtabTrialConstants.EXHIBIT_RANGE.MIN.PO,
      max: PtabTrialConstants.EXHIBIT_RANGE.MAX.PO
    },
    rangeForPetitioner: {
      min: PtabTrialConstants.EXHIBIT_RANGE.MIN.PETITIONER,
      max: PtabTrialConstants.EXHIBIT_RANGE.MAX.PETITIONER
    },
    edit: {
      enableEdit: false,
      editIndex: null,
      originalRow: {},
      rowToEdit: null
    },
    exhibitNumberSequence: {
      board: null,
      po: null,
      petitioner: null
    }
  };

  options = {
    multiple: false,
    closeOnSelect: true,
    width: '100%',
    allowClear: true,
    theme: 'bootstrap',
    openOnEnter: true,
    // minimumResultsForSearch: Infinity - use to hide search box
  }

  validationObj = {
    exhibitNo: false,
    filingDate: false,
    docName: false
  }

  constructor(
    private modalService: BsModalService,
    private jpviewService: JpViewService,
    private trialsService: TrialsService,
    private commonService: CommonService,
    private store: Store<CaseViewerState>,
    private toastr: ToastrService,
    private datePipe: DatePipe,
    private commonUtils: CommonUtilitiesService
  ) { }

  ngOnInit(): void {
    console.log('modal: ', this.modal)
    this.store.pipe(select(CaseViewerSelectors.userInfoData)).subscribe(data => {
      this.loggedInUser = data.caseDetailsData[0];
      // const tempPermissions = this.commonUtils.setUserPermissions()
      this.adminLoggedIn = data.permissions['DOCUMENTS_SUBTAB'].canEdit;
      if (!this.loggedInUser) {
        this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
      }
    });

    // this.store.pipe(select(CaseViewerSelectors.userInfoData)).subscribe();

    // this.adminLoggedIn = this.loggedInUser.roleDescription === PtabTrialConstants.ROLES.ADMIN || this.loggedInUser.roleDescription === PtabTrialConstants.ROLES.SPL;
    // this.adminLoggedIn = false;
    this.getDocumentsForUpdate();
    this.getPaperTypeList();
    this.getFilingPartyTypeList();
    this.getAvailabilityList();
    this.getNextExhibitNumber();
  }

  getNextExhibitNumber() {
    // this.jpviewService.getTrialsInfo(`${PtabTrialConstants.TRIAL_SERVICES_URL}/proceeding-party-details/exhibit-sequences?proceedingNumber=${this.modal.caseInfo.proceedingNo}`).subscribe((exhibitSequenceResponse) => {
    this.trialsService.getTrialsInfo(`/proceeding-party-details/exhibit-sequences?proceedingNumber=${this.modal.caseInfo.proceedingNo}`).subscribe((exhibitSequenceResponse) => {
      this.global.exhibitNumberSequence.board = this.validateMaxRange(exhibitSequenceResponse.Board, this.global.rangeForBoard.max);
      this.global.exhibitNumberSequence.po = this.validateMaxRange(exhibitSequenceResponse.Patentowner, this.global.rangeForPO.max);
      this.global.exhibitNumberSequence.petitioner = this.validateMaxRange(exhibitSequenceResponse.Petitioner, this.global.rangeForPetitioner.max);
    });
  }


  validateMaxRange(currentValue, maxValue) {
    return currentValue && maxValue ? currentValue > maxValue ? maxValue : currentValue : 0;
  }


  getDocumentsForUpdate() {
    this.showLoading = true;
    this.trialsService.getDocumentsForUpdate(`${PtabTrialConstants.TRIALS_URLS.GET_DOCUMENTS}${this.modal.caseInfo.proceedingNo}`).subscribe((documentSuccess) => {
    // this.jpviewService.getDocumentsForUpdate(`${PtabTrialConstants.TRIAL_SERVICES_URL}/proceeding-artifacts?proceedingNumber=${this.modal.caseInfo.proceedingNo}`).subscribe((documentSuccess) => {
      console.log('documentSuccess: ', documentSuccess);
      documentSuccess.sort(this.sortList);
      documentSuccess.forEach(element => {
        if (element.documentNumber) {
          element.docNo = element.documentNumber;
        }
        if (element.exhibitNumber) {
          element.docNo = element.exhibitNumber;
        }
        if (element.filingDate.toString().length <= 10) {
          element.filingDate = parseInt(element.filingDate.toString() + "000");
        }
      });
      this.tableOptions = {
        tableId: "updateDocumentsTable",
        tableHeaderClass: "updateDocumentsTableHeader",
        tableBodyClass: "updateDocumentsTableBody",
        columnDefs: [
          {
            name: "",
            displayName: "",
            field: "",
            width: "25px",
            type: "radio",
            searchText: null
          },
          {
            name: "Doc #",
            displayName: "Doc #",
            field: "docNo",
            width: "80px",
            type: "string",
            searchText: null
          },
          {
            name: "Filing date",
            displayName: "Filing date",
            field: "filingDateString",
            width: "155px",
            type: "date",
            searchText: null
          },
          {
            name: "Doc type",
            displayName: "Doc type",
            field: "category",
            width: "110px",
            type: "string",
            searchText: null
          },
          {
            name: "Paper type",
            displayName: "Paper type",
            // field: "name",
            field: "documentTypeDescription",
            width: "200px",
            type: "string",
            searchText: null
          },
          {
            name: "Document name",
            displayName: "Document name",
            // field: "fileName",
            field: "name",
            width: "",
            type: "string",
            searchText: null
          },
          {
            name: "Pages",
            displayName: "Pages",
            field: "pageCount",
            width: "60px",
            type: "string",
            searchText: ""
          },
          {
            name: "Filing party",
            displayName: "Filing party",
            field: "filingParty",
            width: '150px',
            type: "string",
            searchText: ""
          },
          {
            name: "Availability",
            displayName: "Availability",
            field: "availability",
            width: "225px",
            type: "string",
            searchText: ""
          },
          {
            name: "Action(s)",
            displayName: "Action(s)",
            field: "availability",
            width: "95px",
            type: "action",
            searchText: ""
          }
        ],
        data: JSON.parse(JSON.stringify(documentSuccess))
      };
      // this.sortColumn('-filingDate', 'p');
      this.sortColumn('-filingDateString', 'p');
      this.showLoading = false;
      // this.documentData = documentSuccess;
    }, (documentFailure) => {
      this.toastr.error(`${documentFailure.error.message}`, "", {
        closeButton: true
      });
          this.showLoading = false;
    });
  }


  getNumberOfFilters() {
    let count = 0;
    if (this.tableOptions && this.tableOptions.columnDefs && this.tableOptions.columnDefs.length > 0) {
      this.tableOptions.columnDefs.forEach(column => {
        if (column.searchText && column.searchText !== "" && column.searchText !== null) {
          count++;
        }
      });
    }
    return count;
  }

  clearAll() {
    this.tableOptions.columnDefs.forEach(column => {
      column.searchText = null;
    });
  }

  // sortColumn(columnToSort) {
  //   this.sortColumnEmitter.emit(columnToSort);
  // }


  sortList(a, b) {
    const bandA = a.filingDate;
    const bandB = b.filingDate;
    let comparison = 0;
    if (bandA < bandB) {
      comparison = 1;
    } else if (bandA > bandB) {
      comparison = -1;
    }
    return comparison;
  }


  getPaperTypeList() {
    this.commonService.getReferenceData(`${PtabTrialConstants.COMMON_URLS.REFERENCE_BASE}${PtabTrialConstants.REFERENCE_TYPES.PAPER_TYPE}`).subscribe((paperTypeListResp) => {
      if (paperTypeListResp && paperTypeListResp.length > 0) {
        this.paperTypeListResponse = paperTypeListResp;
        this.paperTypeList = paperTypeListResp;
        this.paperTypeList.forEach(paperType => {
          paperType.id = paperType.code;
          paperType.text = paperType.displayNameText;
        });
        this.paperTypeList.sort((a, b) => {
          return a.displayNameText > b.displayNameText ? 1 : -1;
        })
      }
    }, () => {
      this.toastr.error(`Unable to retrieve Paper type list.`, "", {
        closeButton: true
      });
    });
  }


  getFilingPartyTypeList() {
    this.commonService.getReferenceData(`${PtabTrialConstants.COMMON_URLS.REFERENCE_BASE}${PtabTrialConstants.REFERENCE_TYPES.FILING_PARTY}`).subscribe((filingPartyTypeListResp) => {
      if (filingPartyTypeListResp && filingPartyTypeListResp.length > 0) {
        this.filingPartyList = filingPartyTypeListResp;
        let foundBoard = this.filingPartyList.find((element) => element.code === "BOARD");
        this.selectedFilingParty = foundBoard ? foundBoard.code : null;
        // this.documentUploadObj.filingParty = foundBoard ? foundBoard.displayNameText : null;
      }
    }, () => {
      this.toastr.error(`Unable to retrieve Filing party list.`, "", {
        closeButton: true
      });
    });
  }


  getAvailabilityList() {
    this.commonService.getReferenceData(`${PtabTrialConstants.COMMON_URLS.REFERENCE_BASE}${PtabTrialConstants.REFERENCE_TYPES.AVAILABILITY}`).subscribe((availabilityListResp) => {
      if (availabilityListResp && availabilityListResp.length > 0) {
        this.availabilityList = availabilityListResp;
        let foundPublic = this.availabilityList.find((element) => element.code === "PUBLIC");
        this.selectedAvailability = foundPublic ? foundPublic.code : null;
        // this.documentUploadObj.availability = foundPublic ? foundPublic.displayNameText : null;
      }
    }, () => {
      this.toastr.error(`Unable to retrieve Availability list.`, "", {
        closeButton: true
      });
    });
  }


  enableEdit(row, val, index) {
    this.oldPaperType = row.documentTypeDescription;
    this.editMode = val;
    this.editIndex = index;
    this.originalRow = JSON.parse(JSON.stringify(row));
    this.selectedFilingDate = this.datePipe.transform(row.filingDate, 'yyyy-MM-dd');
    let foundFilingParty = this.filingPartyList.find((element) => {
      return element.displayNameText.toLowerCase() === row.filingParty.toLowerCase()
    });
    this.selectedFilingParty = foundFilingParty ? foundFilingParty.code : null;
    let foundAvailability = this.availabilityList.find((element) => {
      return element.displayNameText.toLowerCase() === row.availability.toLowerCase()
    });
    this.selectedAvailability = foundAvailability ? foundAvailability.code : null;
    if (row.category.toLowerCase() === "paper") {
      let foundPaperType = this.paperTypeList.find((element) => {
        return element.code === row.documentTypeCode
        // return element.displayNameText === row.documentTypeCode
      });
      row.documentTypeCode = foundPaperType ? foundPaperType.code : null;
      // row.name = foundPaperType ? foundPaperType.code : null;
      row.documentTypeDescription = foundPaperType ? foundPaperType.code : null;
      this.oldPaperType = foundPaperType ? null : this.oldPaperType;
    }
  }


  setEditDropDownValue(value, index, type, row) {
    switch (type) {
      case "paperType":
        this.selectedDocTypeCode = null;
        this.paperTypeList.forEach((item) => {
          if (item.id === value) {
            row.documentTypeCode = item.code;
            this.selectedDocTypeCode = item.identifier;
            // row.documentTypeCode = item.displayNameText;
            this.tableOptions.data[index].name = item.descriptionText;
          }
        });
        if (row.category == 'Paper') {
          let tempDocName = this.paperTypeList.find(element => element.code === value);
          // row.name = tempDocName ? tempDocName.descriptionText : null;
          row.name = tempDocName ? tempDocName.displayNameText : null;
        }
        break;
      case "filingParty":
        this.filingPartyList.forEach((item) => {
          if (item.code === value) {
            // row.filingParty = item.code;
            row.filingParty = item.displayNameText;
            if (value.toLowerCase() === "board") {
              let foundPublic = this.availabilityList.find((element) => element.code === "PUBLIC");
              this.selectedAvailability = foundPublic ? foundPublic.code : null;
              this.setEditDropDownValue("PUBLIC", index, "availability", row);
            }
            if (row.category && row.category.toLowerCase() === 'exhibits') {
              this.setExhibitNumber(row, index);
            }
          }
        });
        break;
      case "availability":
        this.availabilityList.forEach((item) => {
          if (item.code === value) {
            // row.availability = item.code;
            row.availability = item.displayNameText;
          }
        });
        break;
    }
  }

  setExhibitNumber(row, index) {
    switch (row.filingParty) {
      case 'Patent owner':
        this.tableOptions.data[index].exhibitNumber = this.global.exhibitNumberSequence.po;
        break;
      case 'Board':
        this.tableOptions.data[index].exhibitNumber = this.global.exhibitNumberSequence.board;
        break;
      case 'Petitioner':
        this.tableOptions.data[index].exhibitNumber = this.global.exhibitNumberSequence.petitioner;
        break;
      default:
        break;
    }
  }


  saveInformation(row) {

    if (this.validationPassed(row)) {
      console.log(this.selectedFilingParty);
    console.log("FilingDate: ", this.selectedFilingDate);
    console.log("FilingEpoch: ", new Date(this.selectedFilingDate).getTime());
    row.filingParty = this.selectedFilingParty;
    row.availability = this.selectedAvailability;
      let filingDate = new Date(this.selectedFilingDate);
      filingDate.setHours(filingDate.getHours() + 5);
    console.log("Row: ", row);

    // this.cancelEdit(null, null);
    let docToSave = {
          "name": row.name,
          "category": row.category,
          "filingParty": this.selectedFilingParty,
          "availability": this.selectedAvailability,
          "documentTypeIdentifier": this.selectedDocTypeCode ? this.selectedDocTypeCode : row.documentTypeIdentifier,
          "artifactIdentifer": row.artifactIdentifer,
          "filingDate":filingDate.getTime() / 1000,
          "exhibitNumber": row.exhibitNumber ? row.exhibitNumber : null,
          "audit": {
              "lastModifiedUserIdentifier": this.loggedInUser.loginId,
              "createUserIdentifier": this.loggedInUser.loginId
          },
           "proceedingNumberText": this.modal.caseInfo.proceedingNo
      }

      // if (!docToSave.documentTypeIdentifier && this.oldPaperType) {
      //   docToSave.documentTypeIdentifier = this.oldPaperType
      // }

    console.log("docToSave: ", docToSave);

      this.trialsService.updateDocumentInfo(`/proceeding-artifacts/${row.artifactIdentifer}`, docToSave).subscribe((updateDocSuccess) => {
        this.toastr.success(`Successfully updated document metadata`, "", {
          closeButton: true
        });
      console.log('updateDocSuccess: ', updateDocSuccess);
      this.cancelEdit(null, null);
      this.orderByField = [];
      this.getDocumentsForUpdate();
    }, (updateDocFailure) => {
      this.toastr.error(`${updateDocFailure.error.message}`, "", {
        closeButton: true
      });

    });
    }
  }


  validationPassed(row) {
    let msg = '';
    let numbersValiidated = this.validateExhibitNumberRange(row);
    if (numbersValiidated) {
      if (!this.selectedFilingDate || this.selectedFilingDate == '') {
        msg += `Filing date is required. `;
      }
      if (!row.name || row.name.trim() === '') {
        msg += `Document name is required. `;
      }
      // if (!row.documentTypeCode || !row.documentTypeDescription) {
      //   msg += `Paper type is required. `;
      // }
    }
    if (msg.trim() !== '') {
      this.setAlert(true, 'danger', msg);
    }
    // if (msg.trim() === '' && numbersValiidated) {

    // }
    return msg.trim() === '' && numbersValiidated;
  }


  openPdfFile(data) {
    this.commonService.openPdf(`/petitions/${this.modal.petitionerIdentifier}/download-documents?contentManagementId=${data.contentManagementId}`);

    // // let protocol: string = window.location.protocol;
    // // let hostname: string =  window.location.host;
    // // let devUrl = `${protocol}//${hostname}${PtabTrialConstants.COMMON_SERVICES_URL}/petitions/${this.modal.petitionerIdentifier}/download-documents?contentManagementId=${data.contentManagementId}`;

    // let devUrl = "https://ptab-q121-trial-services-wildfly-0.dev.uspto.gov:8443/PTABE2ECommonServices/petitions/" + this.modal.petitionerIdentifier + "/download-documents?contentManagementId=" + data.contentManagementId
    // // let url = "https://ptab-q121-trial-intservices-wildfly-green-0.pvt.uspto.gov:8443/PTABE2ECommonServices/petitions/"+ this.petitionerIdentifier+"/download-documents?contentManagementId="+data.contentManagementId
    // window.open(devUrl);
  }


  expungeDocument() {
    console.log(this.docToExpunge);
    let documentAction = this.docToExpunge.documentStatus.toLowerCase() === 'expunged' ? 'UNEXPUNGE' : 'EXPUNGE';
    let docToExpungeTemp = {
          "proceedingNumberText": this.modal.caseInfo.proceedingNo,
          "audit": {
              "lastModifiedUserIdentifier": this.loggedInUser.loginId,
              "createUserIdentifier": this.loggedInUser.loginId,
          },
          "artifactSubmissionIdentifier" : this.docToExpunge.artifactSubmissionIdentifier,
          "contentManagementId" : this.docToExpunge.contentManagementId,
          "documentAction" : documentAction
    }

    this.trialsService.expungeDocument(`${PtabTrialConstants.TRIALS_URLS.EXPUNGE_UNEXPUNGE}`, docToExpungeTemp).subscribe((expungeSuccess) => {
      console.log('expungeSuccess: ', expungeSuccess);
      let action = documentAction === 'EXPUNGE' ? 'expunged' : 'unexpunged';
      this.toastr.success(`Successfully ${action} document`, "", {
        closeButton: true
      });
      this.clearSelection();
      this.orderByField = [];
      this.getDocumentsForUpdate();
    }, (expungeFailure) => {

        this.toastr.error(`${expungeFailure.error.message}`, "", {
          closeButton: true
        });
    });
  }

  cancelEdit(row, index) {
    if (row) {
      this.tableOptions.data[index] = JSON.parse(JSON.stringify(this.originalRow));
    }
    this.editMode = false;
    this.editIndex = null;
    this.selectedDocTypeCode = null;
    this.resetAlert();
  }

  clearSelection() {
    this.docToExpunge = null;
    this.expungeLabel = 'Expunge';
  }

  close() {
    if (this.editMode) {
      this.openAbandonChangesModal();
    } else {
      this.modalService.hide();
    }
  }

  sortColumn(field, sortType) {
      !this.orderByField.includes(field) ? this.correctOrder(field, sortType) : this.correctOrder('-' + field, sortType);
      this.orderByField = !this.orderByField.includes(field) ? [field] : ['-' + field];
  }

  correctOrder(field, sortType) {
    let tempData;
      tempData = [...this.tableOptions.data];
      this.tableOptions.data = [];
      let order = field.charAt(0) === '-' ? "desc" : "asc"
      tempData.sort(this.compareValues(field, order, sortType));
      this.tableOptions.data = [...tempData];
  }

  compareValues(key, order = 'asc', sortType) {
    if (key.charAt(0) === '-') {
      key = key.substring(1);
    }

    return function innerSort(a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        // property doesn't exist on either object
        return 0;
      }

      const varA = (typeof a[key] === 'string')
        ? a[key].toUpperCase() : a[key];
      const varB = (typeof b[key] === 'string')
        ? b[key].toUpperCase() : b[key];


        // let comparison = 0;
        // if (varA > varB) {
        //   comparison = 1;
        // } else if (varA < varB) {
        //   comparison = -1;
        // }
        // return (
        //   (order === 'desc') ? (comparison * -1) : comparison
        // );

        let comparison = 0;
        if (varA > varB) {
          comparison = 1;
        } else if (varA < varB) {
          comparison = -1;
        } else {
        //   let numberA = sortType === 'p' ? a.paperNumber : a.exhibitNumber;
        // let numberB = sortType === 'p' ? b.paperNumber : b.exhibitNumber;
          let numberA = sortType === 'p' ? a.docNo : a.docNo;
        let numberB = sortType === 'p' ? b.docNo : b.docNo;

        if (numberA > numberB) {
          comparison = 1;
        } else if (numberA < numberB) {
          comparison = -1;
        } else {
          return 0;
        }
        }
        return (
          (order === 'desc') ? (comparison * -1) : comparison
        );


    };
  }


  showExpungedModal(docName) {
    const initialState: any = {
      title: "Document expunged",
      infoText: `'${docName}' has been expunged`,
      showLeftBtn: false,
      leftBtnClass: null,
      leftBtnLabel: null,
      showRightBtn: true,
      rightBtnClass: 'btn-default',
      rightBtnLabel: 'Close',
      isConfirm: false,
      modalHeight: 200
    };
    this.bsModalRef = this.modalService.show(InfoModalComponent, {
      animated: true,
      backdrop: 'static',
      class: 'modal-md',
      initialState
    });
  }


  setExpungeLabel(docStatus) {
    this.expungeLabel = docStatus.toLowerCase() === 'expunged' ? 'Unexpunge' : 'Expunge';
  }


  openAbandonChangesModal() {
    let response = this.commonUtils.openAbandonChangesModal('You have document information that has not been saved to the docket.');
    // const initialState = {
    //   modal: {
    //     title: "Abandon unsaved information?",
    //     subText: "You have document information that has not been saved to the docket. Your changes will be lost.",
    //     closeBtnName: "No, return to page",
    //     yesBtnName: "Yes, abandon changes",
    //     yesBtnClass: "btn-danger",
    //     isConfirm: false
    //   },
    //   animated: true,
    //   backdrop: 'static',
    //   class: 'modal-xlg'
    // };
    // this.bsModalRef = this.modalService.show(ConfirmDialogComponent, {
    //   initialState
    // });
    response.onHide.subscribe((reason: string | any) => {

      if (reason.initialState.modal.isConfirm) {
        this.modalService.hide();
      }
    })
  }


  validateExhibitNumberRange(rowToEdit) {
    if (rowToEdit.filingParty.toLowerCase() === 'board' && (rowToEdit.exhibitNumber < this.global.rangeForBoard.min || rowToEdit.exhibitNumber > this.global.rangeForBoard.max)) {
      this.setAlert(true, 'danger', `Exhibit number must be between ${this.global.rangeForBoard.min} and ${this.global.rangeForBoard.max}`);
      return false;
    } else if (rowToEdit.filingParty.toLowerCase() === 'patent owner' && (rowToEdit.exhibitNumber < this.global.rangeForPO.min || rowToEdit.exhibitNumber > this.global.rangeForPO.max)) {
      this.setAlert(true, 'danger', `Exhibit number must be between ${this.global.rangeForPO.min} and ${this.global.rangeForPO.max}`);
      return false;
    } else if (rowToEdit.filingParty.toLowerCase() === 'petitioner' && (rowToEdit.exhibitNumber < this.global.rangeForPetitioner.min || rowToEdit.exhibitNumber > this.global.rangeForPetitioner.max)) {
      this.setAlert(true, 'danger', `Exhibit number must be between ${this.global.rangeForPetitioner.min} and ${this.global.rangeForPetitioner.max}`);
      return false;
    } else {
      return true;
    }
  }


  setAlert(show, alertType, message) {
    this.alertOptions = {
      showAlert: show,
      alertType: alertType,
      message: message
    };
  }

  resetAlert() {
    this.alertOptions = {
      showAlert: false,
      alertType: null,
      message: null
    };
  }

}
