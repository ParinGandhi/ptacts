import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { JpViewService } from 'src/app/services/jpview.service';
import { ConfirmDialogComponent } from 'src/app/shared/confirm-dialog/confirm-dialog.component';
import { MultipleEmailModalComponent } from '../../case-viewer/counsel/multiple-email-modal/multiple-email-modal.component';
import { InfoModalComponent } from '../info-modal/info-modal.component';
import NewInterestedPartyModel from 'src/app/models/common/Party/NewInterestedParty.modal';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { Store, select } from '@ngrx/store';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import { ToastrService } from 'ngx-toastr';
import { TrialsService } from 'src/app/services/trials.service';
import InfoModalModel from 'src/app/models/common/InfoModal.model';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';

@Component({
  selector: 'app-update-parties-modal',
  templateUrl: './update-parties-modal.component.html',
  styleUrls: ['./update-parties-modal.component.less']
})
export class UpdatePartiesModalComponent implements OnInit {

  modal: any;
  unsavedChanges: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  counselToEdit: any = null;
  disableDoneBtn: boolean = false;
  actionToPerform: string = null;
  showLoading: boolean = false;
  disableBackup: boolean = false;
  proSeExists: boolean = false;
  firstBackupExists: boolean = false;
  modalTitle: string = null;


  validationObject = {
    firstNameEmpty: false,
    lastNameEmpty: false,
    counselType: false,
    proSe: false,
    showError: false,
    email: false,
    errorCount: 0,
    errorMessages: []
  }


  validationRealParty = {
    firstNameEmpty: false,
    lastNameEmpty: false,
    organization: false,
    email: false,
    city: false,
    phone: false,
    country: false,
    state: false,
    showError: false,
    errorCount: 0,
    errorMessages: []
  }

  countryList: Array<any>;
  stateList: Array<any>;

  proSe: string = null;
  searchCriteria: string = null;
  showNotRegisteredMsg: boolean = false;
  enableAdd: boolean = false;
  multipleEmaillModelRef: BsModalRef;
  counselWarningModelRef: BsModalRef;
  deleteModelRef: BsModalRef;
  zipCodeLabel: string = 'us';
  counselFound: boolean = false;

  addUpdateForm: NewInterestedPartyModel;
  tempPersonRealParty: NewInterestedPartyModel;
  tempOrgRealParty: NewInterestedPartyModel;

  partyType: string = null;
  loggedInUser: any;

  counselForm: any;
  showSwitch: boolean;
  openWarning: boolean = false;
  showErrorWarning: boolean = false;
  allCounselParties: Array<any> = [];
  index: any;
  partyTypeIn: any;
  partyTypeSelected: string;
  stateToEdit: string = null;

  constructor(
    public bsModalRef: BsModalRef,
    private modalService: BsModalService,
    private jpViewService: JpViewService,
    private trialsService: TrialsService,
    private store: Store<CaseViewerState>,
    private toastr: ToastrService,
    private commonUtils: CommonUtilitiesService
  ) { }

  ngOnInit(): void {
    this.modalTitle = `${this.modal.title} ${this.modal.partyType} ${this.modal.interestedParty}`;
    this.initiatePartiesModal();
    this.checkIfProSeExists();
    this.getCountryList();
    console.log('CaseInfo: ', JSON.stringify(this.modal));
    this.store.pipe(select(CaseViewerSelectors.userInfoData)).subscribe(data => {
      this.loggedInUser = data.caseDetailsData[0];
      if (!this.loggedInUser) {
        this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
      }
    })
    if(this.modal.completeCounsel && this.modal.completeCounsel.petitionCounsel){
      // this.allCounselParties= [...this.modal.completeCounsel.petitionCounsel.parties, ...this.modal.completeCounsel.poCounsel.parties];
      this.allCounselParties = this.allCounselParties.concat(this.modal.completeCounsel.petitionCounsel.parties);
    }
    if (this.modal.completeCounsel && this.modal.completeCounsel.poCounsel) {
      this.allCounselParties = this.allCounselParties.concat(this.modal.completeCounsel.poCounsel.parties);
    }
  };


  initiatePartiesModal() {
    this.partyType = null;
    this.addUpdateForm = {
      "caseNo": null,
      "proceedingSupplementaryIdList": [],
      "supplementaryIdType": null,
      "caseType": null,
      "identifier": null,
      "parties": [{
        "identifier": null,
        "rankNo": null,
        "partyType": null,
        "partySubType": null,
        "partySubTypeDescription": null,
        "registrationNo": null,
        "submitterType": null,
        "personType": [{
          "identifier": null,
          "firstName": null,
          "lastName": null,
          "middleInitial": null,
          "prefferedName": null,
          "mailingAddress": [{
            "identifier": null,
            "streetLineOneText": null,
            "streetLineTwoText": null,
            "city": null,
            "state": null,
            "zipCode": null,
            "country": null,
            "addressType": null,
          }],
          "electronicAddress": [{
            "identifier": null,
            "teleCommAddresType": null,
            "telephoneNumber": null,
            "email": null,
            "emailType": null,
            "extension": null,
          }]
        }],
        "orgType": [{
          "identifier": null,
          "legalname": null,
          "orgAddress": [{
            "identifier": null,
            "streetLineOneText": null,
            "streetLineTwoText": null,
            "city": null,
            "state": null,
            "zipCode": null,
            "country": null,
            "addressType": null,
          }],
          "electronicAddress": [{
            "identifier": null,
            "teleCommAddresType": null,
            "telephoneNumber": null,
            "email": null,
            "emailType": null,
            "extension": null,
          }]
        }]
      }],
      "audit":{
        "lastModifiedUserIdentifier": "",
        "createUserIdentifier":""
      }
    };
    this.tempOrgRealParty = JSON.parse(JSON.stringify(this.addUpdateForm));
    this.tempPersonRealParty = JSON.parse(JSON.stringify(this.addUpdateForm));
  }


  getCountryList() {
    // this.jpViewService.getCountries(`/geo-region/get-countriesinfo/TRAILS`).subscribe((countriesResponse) => {
    this.trialsService.getCountries().subscribe((countriesResponse) => {
      this.countryList = [];
      if (countriesResponse.responseData[0]) {
        countriesResponse.responseData[0].sort(this.sortList);
      this.countryList = countriesResponse.responseData[0];
      }


    });
  }


  getStateList(countryCode) {
    // this.jpViewService.getStates(`/geo-region/get-statesinfo/TRAILS/${countryCode}`).subscribe((statesResponse) => {
    this.trialsService.getStates(countryCode).subscribe((statesResponse) => {
      // console.trace();
      this.stateList = [];
      if (statesResponse.responseData[0]) {
        statesResponse.responseData[0].sort(this.sortList);
      this.stateList = statesResponse.responseData[0];
      }
    });
  }


  sortList(a, b) {
    const bandA = a.description.toUpperCase();
    const bandB = b.description.toUpperCase();
    let comparison = 0;
    if (bandA > bandB) {
      comparison = 1;
    } else if (bandA < bandB) {
      comparison = -1;
    }
    return comparison;
  }


  checkIfProSeExists() {
    this.proSeExists = false;
    this.firstBackupExists = false
    if (this.modal.counselInfo && this.modal.counselInfo.parties.length > 0) {
      this.modal.counselInfo.parties.forEach(element => {
        if (element.partySubType && element.partySubType.toLowerCase() === 'prose') {
          this.proSeExists = true;
        } else if (element.partySubType && element.partySubType.toLowerCase() === 'firstbkup') {
          this.firstBackupExists = true;
        }
      });
    }
  }

  selectedCountry(countryCode) {
    this.zipCodeLabel = countryCode.toLowerCase();
    this.getStateList(countryCode);
  }

  verifyWarning(regOrEmail) {
    if((this.modal.completeCounsel && this.modal.completeCounsel?.petitionCounsel?.parties) ||(this.modal.completeCounsel && this.modal.completeCounsel?.poCounsel?.parties)) {
      // this.allCounselParties = [...this.modal.completeCounsel.petitionCounsel.parties, ...this.modal.completeCounsel.poCounsel.parties];
      this.allCounselParties.forEach(element => {

        if((element.personType[0].electronicAddress[element.personType[0].electronicAddress.length - 1] && Number.isNaN(parseInt(regOrEmail)) && regOrEmail.toLowerCase() == element.personType[0].electronicAddress[element.personType[0].electronicAddress.length - 1].email)
         || (element.registrationNo && (regOrEmail.trim().replace(/,/g, '') == element.registrationNo.replace(/,/g, '')))) {
          this.partyTypeSelected =  element.submitterType.toLowerCase() == 'patentowner'? 'patent owner/respondent' : 'petitioner';
          if(
            // this.modal.partyType == element.submitterType.toLowerCase() ||
          this.modal.partyType == this.partyTypeSelected) {
            this.partyTypeIn = element.submitterType.toLowerCase()
            this.showErrorWarning = true;
          }else {
            this.openWarning = true;
            this.partyTypeIn = this.modal.partyType == 'petitioner'? 'patent owner/respondent' : 'petitioner';
          }

          // console.log("same email id number****");

        // }else if(regOrEmail.trim() == element.registrationNo){
        //   if(this.modal.partyType == element.submitterType.toLowerCase()) {
        //     this.showErrorWarning = true;
        //   }else {
        //     this.openWarning = true;
        //   }
        //   console.log("same reg number****");
         }
      });
    }else {
      this.openWarning = false;
    }



    // this.openWarning = false;
    // if ((this.modal.completeCounsel && this.modal.completeCounsel?.petitionCounsel?.parties) ||(this.modal.completeCounsel && this.modal.completeCounsel?.poCounsel?.parties)) {
    //   // this.allCounselParties = [...this.modal.completeCounsel.petitionCounsel.parties, ...this.modal.completeCounsel.poCounsel.parties];

    //   this.allCounselParties.forEach(element => {
    //     if (element.submitterType) {
    //       this.partyTypeSelected =  element.submitterType.toLowerCase() == 'patentowner'? 'patent owner/respondent' : 'petitioner';
    //     }
    //     // Email
    //     if (Number.isNaN(parseInt(regOrEmail))) {
    //       if (element.personType[0].electronicAddress[element.personType[0].electronicAddress.length - 1] && regOrEmail.toLowerCase() == element.personType[0].electronicAddress[element.personType[0].electronicAddress.length - 1].email.toLowerCase()) {
    //         if (this.modal.partyType == this.partyTypeSelected) {
    //           this.partyTypeIn = element.submitterType.toLowerCase()
    //           this.showErrorWarning = true;
    //         } else {
    //           this.openWarning = true;
    //           this.partyTypeIn = this.modal.partyType == 'petitioner'? 'patent owner/respondent' : 'petitioner';
    //         }
    //       }
    //     } else {
    //       if (element.registrationNo && (regOrEmail.trim().replace(/,/g, '') == element.registrationNo.replace(/,/g, ''))) {
    //         if (this.modal.partyType == this.partyTypeSelected) {
    //           this.partyTypeIn = element.submitterType.toLowerCase()
    //           this.showErrorWarning = true;
    //         } else {
    //           this.openWarning = true;
    //           this.partyTypeIn = this.modal.partyType == 'petitioner'? 'patent owner/respondent' : 'petitioner';
    //         }
    //       }
    //     }
    //   });
    // }
  }

  findCouncelGetCall(regOrEmail) {
    // let url = Number.isNaN(parseInt(regOrEmail)) ? `email=${regOrEmail.toLowerCase()}` : `registrationNumber=${regOrEmail}`;
    // this.jpViewService.findCounsel(`/proceeding-party-details/counsels/TRAILS?${url}`).subscribe(
    // this.initiatePartiesModal();
    // this.addMode = false;
    // this.editMode = false;
    // this.enableAdd = false;
    // this.counselFound = false;
    // this.disableDoneBtn = false;
    // this.disableBackup = false;
    // this.actionToPerform = null;
    // this.clearValidation();
      let searchCriteria = Number.isNaN(parseInt(regOrEmail)) ? `email=${regOrEmail.toLowerCase()}` : `registrationNumber=${regOrEmail}`;
    this.trialsService.findCounsel(`${searchCriteria}`).subscribe((findCounselResponse) => {
      this.openWarning = false;
      // this.showErrorWarning = false;
      console.log('findCounselResponse: ', findCounselResponse);
      if (findCounselResponse.length === 0 || findCounselResponse[0].parties.length === 0) {
        this.showNotRegisteredMsg = true;
      } else if (findCounselResponse[0].parties.length > 1) {
        this.openSelectEmailModal(findCounselResponse[0].parties, regOrEmail);
      } else {
        this.enableAdd = true;
        this.disableDoneBtn = true;
        this.createElectronicAddres();
        // this.addUpdateForm.parties[0].personType[0].electronicAddress = findCounselResponse[0].parties[0].personType[0].electronicAddress;
        this.addUpdateForm.parties[0].personType[0].firstName = findCounselResponse[0].parties[0].personType[0].firstName;
        this.addUpdateForm.parties[0].personType[0].lastName = findCounselResponse[0].parties[0].personType[0].lastName;
        this.addUpdateForm.parties[0].registrationNo = findCounselResponse[0].parties[0].registrationNo;
        if (findCounselResponse[0].parties[0].personType[0].electronicAddress[0].telephoneNumber) {
          this.addUpdateForm.parties[0].personType[0].electronicAddress.forEach((teleNum) => {
            if (teleNum.teleCommAddresType === 'W') {
              teleNum.telephoneNumber = findCounselResponse[0].parties[0].personType[0].electronicAddress[0].telephoneNumber;
            }
            // if (teleNum.emailType === 'WE') {
            //   teleNum.email = findCounselResponse[0].parties[0].personType[0].electronicAddress[0].email;
            // }
          });
        }
        if (findCounselResponse[0].parties[0].personType[0].electronicAddress[0].email) {
          this.addUpdateForm.parties[0].personType[0].electronicAddress.forEach((teleNum) => {
            // if (teleNum.teleCommAddresType === 'W') {
            //   teleNum.telephoneNumber = findCounselResponse[0].parties[0].personType[0].electronicAddress[0].telephoneNumber;
            // }
            if (teleNum.emailType === 'WE') {
              teleNum.email = findCounselResponse[0].parties[0].personType[0].electronicAddress[0].email;
            }
          });
        }
        console.log('this.addUpdateForm: ', this.addUpdateForm);
        this.checkForUnsavedChanges(true);
        this.counselFound = true;
      }
    })
  }
  findCounsel(regOrEmail) {
    this.clearValidation();
    this.verifyWarning(regOrEmail);
    if(!this.openWarning){
     this.findCouncelGetCall(regOrEmail);
  }else {
    this.openWarningModal(this.modal.partyType,regOrEmail,this.partyTypeIn);
  }
  }


  clearSearch() {
    this.searchCriteria = null;
  }


  cancelAddCounsel() {
    this.checkForUnsavedChanges(false);
    this.proSe = null;
    this.addMode = false;
    this.editMode = false;
    this.initiatePartiesModal();
    this.enableAdd = false;
    this.counselFound = false;
    this.disableDoneBtn = false;
    this.disableBackup = false;
    this.actionToPerform = null;
    this.clearValidation();
    this.clearSearch();
    this.openWarning = false;
    this.showErrorWarning = false;
  }


  clearValidation() {
    this.validationObject = {
      firstNameEmpty: false,
      lastNameEmpty: false,
      counselType: false,
      proSe: false,
      showError: false,
      email: false,
      errorCount: 0,
      errorMessages: []
    };
    this.showNotRegisteredMsg = false;
  }

  addCounsel() {
    if (!this.validateRequired()) {
      console.log('Valid!');
      console.log("Adding Counsel: ", JSON.stringify(this.addUpdateForm.parties));
      let counselToAdd = {
        caseNo: this.modal.caseInfo.proceedingNo,
        audit: {
          lastModifiedUserIdentifier: this.loggedInUser.loginId,
          createUserIdentifier: this.loggedInUser.loginId
        },
        parties: this.addUpdateForm.parties
      };
      if (this.proSe === 'yes') {
        counselToAdd.parties[0].partySubType = 'PROSE';
      }

      counselToAdd.parties[0].submitterType = this.modal.partyType === 'petitioner' ? 'PETITIONER' : 'PATENTOWNER';
      counselToAdd.parties[0].partyType = 'COUNSEL';
      counselToAdd.parties[0].personType[0].mailingAddress[0].addressType = "BUS";
      counselToAdd.parties[0].personType[0].electronicAddress[0].emailType = "WE";
      delete counselToAdd.parties[0].orgType;
      console.log('counselToAdd: ', JSON.stringify(counselToAdd));

      let proSeVal = this.proSe === 'yes' ? 'Y' : 'N';
      // this.jpViewService.addCounsel(`/proceeding-party-details?partyRepresentIndicator=${proSeVal}`, counselToAdd).subscribe((addCounselSuccess) => {
      this.trialsService.addCounsel(proSeVal, counselToAdd).subscribe((addCounselSuccess) => {
        console.log(addCounselSuccess);
        this.allCounselParties.push(addCounselSuccess.parties[0]);
        this.partyTypeIn = addCounselSuccess.parties[0].submitterType.toLowerCase()
        this.cancelAddCounsel();
        this.toastr.success(`Successfully added counsel`, "", {
          closeButton: true
        });
        this.getCounselInfo();
      }, (addCounselFailure) => {
          console.log(addCounselFailure);
          this.toastr.error(`${addCounselFailure.error.message}`, "", {
            closeButton: true
          });
      })
    }
  }

  getRealPartyInfo() {
    // this.jpViewService.getCounselInfo(`/proceeding-party-details?proceedingNumber=${this.modal.caseInfo.proceedingNo}`).subscribe((partyInfoResponse) => {
    this.trialsService.getCounselInfo(`${this.modal.caseInfo.proceedingNo}`).subscribe((partyInfoResponse) => {
      if (this.modal.partyType === 'Petitioner') {
        partyInfoResponse.petitionRealParty.parties.sort(this.sortCounselType);
        this.modal.counselInfo = partyInfoResponse.petitionRealParty;
      }else {
        partyInfoResponse.poRealParty.parties.sort(this.sortCounselType);
        this.modal.counselInfo = partyInfoResponse.poRealParty;
      }

    });
  }

  getCounselInfo() {
    // this.jpViewService.getCounselInfo(`/proceeding-party-details?proceedingNumber=${this.modal.caseInfo.proceedingNo}`).subscribe((counselInfoResponse) => {
    this.trialsService.getCounselInfo(`${this.modal.caseInfo.proceedingNo}`).subscribe((counselInfoResponse) => {
      if (this.modal.partyType === 'petitioner') {
        if (counselInfoResponse.petitionCounsel) {
          counselInfoResponse.petitionCounsel.parties.sort(this.sortCounselType);
        }
        this.modal.counselInfo = counselInfoResponse.petitionCounsel;
      }
      if (this.modal.partyType !== 'petitioner') {
        if (counselInfoResponse.poCounsel) {
          counselInfoResponse.poCounsel.parties.sort(this.sortCounselType);
        }
        this.modal.counselInfo = counselInfoResponse.poCounsel;
      }
      this.checkIfProSeExists();
    });
  }

  sortCounselType(a, b) {
    const rankA = a.rankNo;
    const rankB = b.rankNo;

    let comparison = 0;
    if (rankA > rankB) {
      comparison = 1;
    } else if (rankA < rankB) {
      comparison = -1;
    }
    return comparison;
  }



  validateRequired() {
    this.validationObject.errorMessages = [];
    this.validationObject.errorCount = 0;
    this.validationObject.firstNameEmpty = this.validateNull(this.addUpdateForm.parties[0].personType[0].firstName);
    if (this.validationObject.firstNameEmpty) {
      this.validationObject.errorMessages.push('First name is required.');
    }
    this.validationObject.lastNameEmpty = this.validateNull(this.addUpdateForm.parties[0].personType[0].lastName);
    if (this.validationObject.lastNameEmpty) {
      this.validationObject.errorMessages.push('Last name is required.');
    }
    if (!this.editMode) {
      this.validationObject.proSe = this.validateNull(this.proSe);
      if (!this.addUpdateForm.parties[0].partySubType && this.proSe === 'no') {
          this.validationObject.counselType = this.validateNull(this.addUpdateForm.parties[0].partySubType);
        if ( this.validationObject.counselType) {
          this.validationObject.errorMessages.push('Counsel type is required.');
         }
        } else {
          this.validationObject.counselType = false;
        }
    }
    if (this.addUpdateForm.parties[0].partySubType) {
      if (this.addUpdateForm.parties[0].registrationNo === '' || !this.addUpdateForm.parties[0].registrationNo) {
        if (this.addUpdateForm.parties[0].partySubType.toLowerCase() === 'lead' || this.proSe === 'yes' ) {
          let counselType = this.proSe.toLowerCase() === 'no' ? 'Lead counsel' : "Pro se";
          this.validationObject.errorMessages.push(`${counselType} cannot be a PHV.`);
        }
      }
    }



    // this.validationObject.showError = this.validationObject.errorCount > 0;
    return this.validationObject.errorMessages.length > 0;
  }


  validateNull(val) {
    if (val && val.trim() !== "" && val !== undefined && val !== null) {
      return false
    } else {
      this.modal.modalType === 'counsel' ? this.validationObject.errorCount++ : this.validationRealParty.errorCount++;
      return true;
    }
  }

  validateEmail(email) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    let resp = re.test(email.toLowerCase());
    return resp;
  }


  openSelectEmailModal(allCounselInfo, regNo) {
      const initialState = {
        modal: {
          title: `Multiple email addresses for registration number`,
          isConfirm: false,
          regNo: regNo,
          allCounselInfo: allCounselInfo
        }
      };
      this.multipleEmaillModelRef = this.modalService.show(MultipleEmailModalComponent, {
        animated: true,
        backdrop: true,
        ignoreBackdropClick: true,
        initialState
      });
      this.multipleEmaillModelRef.onHide.subscribe((reason: string | any) => {
        console.log('reason: ', reason);
        if (reason.initialState.modal.isConfirm) {
          let tempPartySubType = this.addUpdateForm.parties[0].partySubType;
          this.initiatePartiesModal();
          this.addUpdateForm.parties[0].partySubType = tempPartySubType;
          console.log(reason);
          // this.addUpdateForm.parties[0].personType[0].electronicAddress = reason.initialState.modal.allCounselInfo[reason.initialState.modal.selectedCounselInfo].personType[0].electronicAddress;
          // this.addUpdateForm.parties[0].personType[0].firstName = reason.initialState.modal.allCounselInfo[reason.initialState.modal.selectedCounselInfo].personType[0].firstName;
          // this.addUpdateForm.parties[0].personType[0].lastName = reason.initialState.modal.allCounselInfo[reason.initialState.modal.selectedCounselInfo].personType[0].lastName;
          // this.addUpdateForm.parties[0].registrationNo = reason.initialState.modal.allCounselInfo[reason.initialState.modal.selectedCounselInfo].registrationNo;
          // this.createElectronicAddres();
          // this.addUpdateForm.parties[0].personType[0].electronicAddress = reason.initialState.modal.allCounselInfo[reason.initialState.modal.selectedCounselInfo].personType[0].electronicAddress;
          this.addUpdateForm.parties[0].personType[0].firstName = reason.initialState.modal.allCounselInfo[reason.initialState.modal.selectedCounselInfo].personType[0].firstName;
          this.addUpdateForm.parties[0].personType[0].lastName = reason.initialState.modal.allCounselInfo[reason.initialState.modal.selectedCounselInfo].personType[0].lastName;
          this.addUpdateForm.parties[0].registrationNo = reason.initialState.modal.allCounselInfo[reason.initialState.modal.selectedCounselInfo].registrationNo;
          this.createElectronicAddres();
          if (reason.initialState.modal.allCounselInfo[reason.initialState.modal.selectedCounselInfo].personType[0].electronicAddress[0].telephoneNumber) {
            this.addUpdateForm.parties[0].personType[0].electronicAddress.forEach((teleNum) => {
              if (teleNum.teleCommAddresType === 'W') {
                teleNum.telephoneNumber = reason.initialState.modal.allCounselInfo[reason.initialState.modal.selectedCounselInfo].personType[0].electronicAddress[0].telephoneNumber;
              }
              // if (teleNum.emailType === 'WE') {
              //   teleNum.email = reason.initialState.modal.allCounselInfo[reason.initialState.modal.selectedCounselInfo].personType[0].electronicAddress[0].email;
              // }
            });
          }
          if (reason.initialState.modal.allCounselInfo[reason.initialState.modal.selectedCounselInfo].personType[0].electronicAddress[0].email) {
            this.addUpdateForm.parties[0].personType[0].electronicAddress.forEach((teleNum) => {
              // if (teleNum.teleCommAddresType === 'W') {
              //   teleNum.telephoneNumber = reason.initialState.modal.allCounselInfo[reason.initialState.modal.selectedCounselInfo].personType[0].electronicAddress[0].telephoneNumber;
              // }
              if (teleNum.emailType === 'WE') {
                teleNum.email = reason.initialState.modal.allCounselInfo[reason.initialState.modal.selectedCounselInfo].personType[0].electronicAddress[0].email;
              }
            });
          }
          console.log('this.addUpdateForm: ', this.addUpdateForm);
          this.enableAdd = true;
          this.counselFound = true;
          this.disableDoneBtn = true;
          this.checkForUnsavedChanges(true);
        }
      })
  }

  openWarningModal(partyType,regNo, existsFor) {
    let modal: InfoModalModel = {
      infoText: ["You are adding a "+ partyType +" counsel with someone who already exists for the "+existsFor, "Do you want to continue?"],
      title: "Counsel exists",
      showLeftBtn: true,
      leftBtnClass: 'btn-default',
      leftBtnLabel: 'Back',
      showRightBtn: true,
      rightBtnClass: 'btn-primary',
      rightBtnLabel: 'Yes, proceed',
      isConfirm: false,
      modalHeight: 100
    }
    let response = this.commonUtils.openConfirmModal(modal);
    // const initialState = {
    //   modal: {
    //     title: `Counsel exists`,
    //     isConfirm: false,
    //     regNo: regNo,
    //     partyType: partyType,
    //     exists: existsFor
    //   }
    // };
    // this.counselWarningModelRef = this.modalService.show(CounselWarningComponent, {
    //   animated: true,
    //   backdrop: true,
    //   ignoreBackdropClick: true,
    //   initialState
    // });
    response.onHide.subscribe((reason: string | any) => {

      if (reason.initialState.modal.isConfirm) {
        console.log(reason);
        this.findCouncelGetCall(regNo);
      } else {
        this.openWarning = false;
      }
    })
}

  checkForUnsavedChanges(val) {
    this.unsavedChanges = val;
  }

  setAddMode(val) {
    this.addMode = val;
  }

  close(value) {
    if (this.unsavedChanges) {
      this.openAbandonChangesModal();
    } else {
      this.modal.isConfirm = value;
      this.modalService.hide();
    }
  }


  openAbandonChangesModal() {
    const initialState = {
      modal: {
        title: "Abandon unsaved information?",
        subText: "You have document information that has not been saved to the docket. Your changes will be lost.",
        closeBtnName: "No, return to page",
        yesBtnName: "Yes, abandon changes",
        yesBtnClass: "btn-danger",
        isConfirm: false
      },
      animated: true,
      backdrop: 'static',
      class: 'modal-xlg'
    };
    this.bsModalRef = this.modalService.show(ConfirmDialogComponent, {
      initialState
    });
    this.bsModalRef.onHide.subscribe((reason: string | any) => {
      console.log('reason: ', reason);
      if (reason.initialState.modal.isConfirm) {
        this.modalService.hide();
      }
    })
  }


  switchRealParty(val, realPartyToSwitch) {
    console.log('counselToSwitch: ', realPartyToSwitch);
    let orgToSwitch = realPartyToSwitch.orgType[0]? realPartyToSwitch.orgType[0].legalname: null;
    let personToSwitch = orgToSwitch ? `${realPartyToSwitch.orgType[0].legalname}`:`${realPartyToSwitch.personType[0].firstName} ${realPartyToSwitch.personType[0].lastName}`;
    let switchTo = val ? 'real party' : 'additional real party';
    let partyList: Array<any> = [];
    partyList[0] = realPartyToSwitch;
    let realPartyToEdit = {
      caseNo: this.modal.caseInfo.proceedingNo,
      audit: {
        lastModifiedUserIdentifier: this.loggedInUser.loginId,
        createUserIdentifier: this.loggedInUser.loginId
      },
      parties: partyList
    };

    // this.jpViewService.switchCounsel(val, realPartyToEdit).subscribe((switchCounselSuccess) => {
    this.trialsService.switchCounsel(`${PtabTrialConstants.REAL_PARTY.SWITCH}${val}`, realPartyToEdit).subscribe((switchCounselSuccess) => {

           this.toastr.success(`Successfully switched ${personToSwitch} to ${switchTo}`, "", {
          closeButton: true
        });
      this.cancelAddRealParty();
      this.getRealPartyInfo();
    }, (failure) => {
      this.toastr.error(`${failure.message}`, "", {
        closeButton: true
         });

    });

  }

  switchCounsel(val, counselToSwitch) {
    console.log('counselToSwitch: ', counselToSwitch);
    let personToSwitch = `${counselToSwitch.personType[0].firstName} ${counselToSwitch.personType[0].lastName}`;
    let switchTo;
    if(counselToSwitch.partySubType == "FIRSTBKUP"){
      switchTo = 'first backup counsel';
    }else {
      switchTo = val ? 'lead counsel' : 'backup counsel';
    }
    let counselList: Array<any> = [];
    counselList[0] = counselToSwitch;
    let counselToEdit = {
      caseNo: this.modal.caseInfo.proceedingNo,
      audit: {
        lastModifiedUserIdentifier: this.loggedInUser.loginId,
        createUserIdentifier: this.loggedInUser.loginId
      },
      parties: counselList
    };
    // this.jpViewService.switchCounsel(`/proceeding-party-details/switch-counsels?isLeadCounsel=${val}`, counselToEdit).subscribe((switchCounselSuccess) => {
    this.trialsService.switchCounsel(`${PtabTrialConstants.COUNSEL.SWITCH}${val}`, counselToEdit).subscribe((switchCounselSuccess) => {
      console.log('switchCounselSuccess: ', switchCounselSuccess);
           this.toastr.success(`Successfully switched ${personToSwitch} to ${switchTo}`, "", {
          closeButton: true
           });
           this.cancelAddCounsel();
      this.getCounselInfo();
    }, (switchCounselFailure) => {
      this.toastr.error(`${switchCounselFailure.error.message}`, "", {
        closeButton: true
         });
      console.log('switchCounselFailure: ', switchCounselFailure);

    });

  }



  editRealParty(partyToEdit,action) {
    if (partyToEdit.personType[0] && partyToEdit.personType[0].mailingAddress[0] && partyToEdit.personType[0].mailingAddress[0].country) {
      this.getStateList(partyToEdit.personType[0].mailingAddress[0].country);
    } else if(partyToEdit.orgType[0] && partyToEdit.orgType[0].orgAddress[0] && partyToEdit.orgType[0].orgAddress[0].country) {
      this.getStateList(partyToEdit.orgType[0].orgAddress[0].country);
    }
    console.log('action: ', JSON.stringify(action));
    console.log('partyToEdit: ', JSON.stringify(partyToEdit));
    this.actionToPerform = action;
    this.checkForUnsavedChanges(true);
    console.log('partyToEdit: ', partyToEdit);
    this.editMode = true;
    this.disableDoneBtn = true;
    if(partyToEdit.orgType[0] && partyToEdit.orgType[0].legalname){
          this.partyType = 'organization';
        } else {
          this.partyType = 'individual';
        }

    // this.addUpdateForm.parties[0].rankNo = "1";
    this.addUpdateForm.parties[0].submitterType = this.modal.partyType === 'Petitioner'? "PETITIONER": "PATENTOWNER";
    this.addUpdateForm.parties[0].partyType = "REAL PARTY";
    this.addUpdateForm.caseNo = this.modal.caseInfo.proceedingNo;
    this.addUpdateForm.audit.createUserIdentifier = this.loggedInUser.loginId;
    this.addUpdateForm.audit.lastModifiedUserIdentifier = this.loggedInUser.loginId;
   setTimeout(() => {
    this.addUpdateForm.parties[0] = JSON.parse(JSON.stringify(partyToEdit));
    if(this.addUpdateForm.parties[0].personType[0] && this.addUpdateForm.parties[0].personType[0].firstName){
      this.addUpdateForm.parties[0].orgType = [];
      this.createElectronicAddres();
    }else {
      this.addUpdateForm.parties[0].personType = [];
      this.createOrgElectronicAddress();
    }
    // if (this.addUpdateForm.parties[0].personType[0] && this.addUpdateForm.parties[0].personType[0].mailingAddress[0] && this.addUpdateForm.parties[0].personType[0].mailingAddress[0].country) {
    //   this.getStateList(this.addUpdateForm.parties[0].personType[0].mailingAddress[0].country);
    // } else if(this.addUpdateForm.parties[0].orgType[0] && this.addUpdateForm.parties[0].orgType[0].orgAddress[0] && this.addUpdateForm.parties[0].orgType[0].orgAddress[0].country) {
    //   this.getStateList(this.addUpdateForm.parties[0].orgType[0].orgAddress[0].country);
    // } else
    if (!this.addUpdateForm.parties[0].orgType[0].orgAddress[0]) {
      this.createOrgAddress();
      this.getCountryList();
    }else if(!this.addUpdateForm.parties[0].personType[0].mailingAddress[0]){
      this.createPersonAddress();
      this.getCountryList();
    }
   }, 200);
  }

  editCounsel(counselToEdit, action) {
    let allowUpdate = true;
    if (this.modal.counselInfo.parties.length === 2) {
      this.modal.counselInfo.parties.forEach(party => {
        if (!party.registrationNo || party.registrationNo === "") {
          if ((counselToEdit.partySubType.toLowerCase() === 'lead' || counselToEdit.partySubType.toLowerCase() === 'prose') && (action.toLowerCase() === 'firstbkup' || action.toLowerCase() === 'backup')) {
            allowUpdate = false;
            this.toastr.error(`Cannot switch lead counsel`, "", {
              closeButton: true
            });
          }
        }
      });
    }
    if (allowUpdate) {
      console.log('action: ', JSON.stringify(action));
    console.log('counselToEdit: ', JSON.stringify(counselToEdit));
    if (action !== 'edit') {
      counselToEdit.partySubType = action.toUpperCase();
    }
    this.actionToPerform = action;
    this.checkForUnsavedChanges(true);
    console.log('counselToEdit: ', counselToEdit);
    this.editMode = true;
    this.disableDoneBtn = true;
      if (counselToEdit.personType[0].mailingAddress[0].country) {
        // this.stateToEdit = counselToEdit.personType[0].mailingAddress[0].state;
        this.getStateList(counselToEdit.personType[0].mailingAddress[0].country);
    }
    setTimeout(() => {
      this.addUpdateForm.parties[0] = JSON.parse(JSON.stringify(counselToEdit));
      this.createElectronicAddres();
    }, 200);

    this.counselFound = true;
    console.log(this.addUpdateForm);
    }
  }

  createPersonAddress() {
    this.addUpdateForm.parties[0].personType[0].mailingAddress.push(
      {
            "identifier": null,
            "streetLineOneText": null,
            "streetLineTwoText": null,
            "city": null,
            "state": null,
            "zipCode": null,
            "country": null,
            "addressType": null,
      }
    )
  }
  createOrgAddress() {
    this.addUpdateForm.parties[0].orgType[0].orgAddress.push(
      {
            "identifier": null,
            "streetLineOneText": null,
            "streetLineTwoText": null,
            "city": null,
            "state": null,
            "zipCode": null,
            "country": null,
            "addressType": null,
      }
    )
  }
  createOrgElectronicAddress() {
    let orgemailFound = false;
    let orgfaxFound = false;
    let orgphoneFound = false;
    for (let i = 0; i < this.addUpdateForm.parties[0].orgType[0].electronicAddress.length; i++){
      if (this.addUpdateForm.parties[0].orgType[0].electronicAddress[i].email) {
        orgemailFound = true;
      } else if (this.addUpdateForm.parties[0].orgType[0].electronicAddress[i].teleCommAddresType === 'F') {
        orgfaxFound = true;
      } else if (this.addUpdateForm.parties[0].orgType[0].electronicAddress[i].teleCommAddresType === 'W') {
        orgphoneFound = true;
      }
    }
    if (!orgemailFound) {
      this.addUpdateForm.parties[0].orgType[0].electronicAddress.push({
        "email": null,
        "emailType": 'WE',
        "identifier": null,
        "extension": null
      })
      }

      if (!orgfaxFound) {
        this.addUpdateForm.parties[0].orgType[0].electronicAddress.push({
          "teleCommAddresType": 'F',
          "telephoneNumber": null,
          "identifier": null,
          "extension": null
        })
        }

        if (!orgphoneFound) {
          this.addUpdateForm.parties[0].orgType[0].electronicAddress.push({
            "teleCommAddresType": 'W',
            "telephoneNumber": null,
            "identifier": null,
            "extension": null
          })
          }
  }
  createElectronicAddres() {
    let emailFound = false;
    let faxFound = false;
    let phoneFound = false;
    for (let i = 0; i < this.addUpdateForm.parties[0].personType[0].electronicAddress.length; i++) {
      console.log(this.addUpdateForm.parties[0].personType[0].electronicAddress[i]);
      // if (this.addUpdateForm.parties[0].personType[0].electronicAddress[i].email) {
      if (this.addUpdateForm.parties[0].personType[0].electronicAddress[i].emailType === 'WE') {
        emailFound = true;
      } else if (this.addUpdateForm.parties[0].personType[0].electronicAddress[i].teleCommAddresType === 'F') {
        faxFound = true;
      } else if (this.addUpdateForm.parties[0].personType[0].electronicAddress[i].teleCommAddresType === 'W') {
        phoneFound = true;
      }
}

    if (!emailFound) {
      this.addUpdateForm.parties[0].personType[0].electronicAddress.push({
        "email": null,
        "emailType": 'WE',
        "identifier": null,
        "extension": null
      })
      }

      if (!faxFound) {
        this.addUpdateForm.parties[0].personType[0].electronicAddress.push({
          "teleCommAddresType": 'F',
          "telephoneNumber": null,
          "identifier": null,
          "extension": null
        })
        }

        if (!phoneFound) {
          this.addUpdateForm.parties[0].personType[0].electronicAddress.push({
            "teleCommAddresType": 'W',
            "telephoneNumber": null,
            "identifier": null,
            "extension": null
          })
          }
  }


  updateCounsel() {
    console.log("Updating counsel");

    if (!this.validateRequired()) {
      let counselToEdit = {
        caseNo: this.modal.caseInfo.proceedingNo,
        audit: {
          lastModifiedUserIdentifier: this.loggedInUser.loginId,
          createUserIdentifier: this.loggedInUser.loginId
        },
        parties: this.addUpdateForm.parties
      };
      counselToEdit.parties[0].submitterType = this.modal.partyType === 'petitioner' ? 'PETITIONER' : 'PATENTOWNER';
      counselToEdit.parties[0].registrationNo = this.searchCriteria ? this.searchCriteria : counselToEdit.parties[0].registrationNo;
      counselToEdit.parties[0].personType[0].mailingAddress[0].addressType = "BUS";
      counselToEdit.parties[0].personType[0].electronicAddress[0].emailType = "WE";
      if (this.actionToPerform === "edit") {
        // this.jpViewService.updateCounsel(`/proceeding-party-details`, counselToEdit).subscribe((counselEditSuccess) => {
        this.trialsService.updateCounsel(counselToEdit).subscribe((counselEditSuccess) => {
        // this.jpViewService.updateCounsel(`/proceeding-party-details`, counselToEdit).subscribe((counselEditSuccess) => {
          console.log(counselEditSuccess);
          this.toastr.success(`Successfully updated counsel information`, "", {
            closeButton: true
          });
          this.cancelAddCounsel();
          this.getCounselInfo();
        }, (counselEditFailure) => {
          console.log(counselEditFailure);
          this.toastr.error(`${counselEditFailure.error.message}`, "", {
            closeButton: true
          });
        });
      // } else if (this.actionToPerform === 'lead' || this.actionToPerform === 'backup') {
      } else if (this.actionToPerform !== 'edit') {
        let val = this.actionToPerform === 'lead' ? true : false;
        this.switchCounsel(val, counselToEdit.parties[0]);
      }
    }
  }


  deleteCounsel(counselToDelete) {
    console.log('counselToDelete: ', counselToDelete);
    console.log("This modal: ", this.modal);
    let allowDelete = true;
    if (this.modal.counselInfo.parties.length === 2) {
      this.modal.counselInfo.parties.forEach(party => {
        if (!party.registrationNo || party.registrationNo === "") {
          if (party.identifier !== counselToDelete.identifier) {
            allowDelete = false;
            this.toastr.error(`Cannot delete Lead counsel`, "", {
              closeButton: true
            });
          }
        }
      });
      if (allowDelete) {
        this.openConfirmDeleteModal(counselToDelete);
      }
    } else {
      this.openConfirmDeleteModal(counselToDelete);
    }
    // if (counselToDelete) {
    //   this.openConfirmDeleteModal(counselToDelete);
    // }
  }


  openConfirmDeleteModal(counselToDelete) {
    let modal: InfoModalModel = {
      infoText: ["This information will be removed from the system."],
      title: "Delete this record?",
      showLeftBtn: true,
      leftBtnClass: 'btn-default',
      leftBtnLabel: 'No, return to page',
      showRightBtn: true,
      rightBtnClass: 'btn-danger',
      rightBtnLabel: 'Yes, delete this record',
      isConfirm: false,
      modalHeight: 100
    }
    let response = this.commonUtils.openConfirmModal(modal);
    response.onHide.subscribe((reason: string | any) => {
      console.log('reason: ', reason);
      if (reason.initialState.modal.isConfirm) {

        console.log("counselToDelete: ", counselToDelete);
        // this.jpViewService.deleteCounsel(`/proceeding-party-details?proceedingNumber=${this.modal.caseInfo.proceedingNo}&proceedingPartyIdentifier=${counselToDelete.identifier}`).subscribe((counselDeleteSuccess) => {
        this.trialsService.deleteCounsel(this.modal.caseInfo.proceedingNo, counselToDelete.identifier).subscribe((counselDeleteSuccess) => {
          this.index = this.allCounselParties.findIndex(ele => ele.registrationNo == counselToDelete.registrationNo);
          // this.partyTypeIn = this.allCounselParties[this.index].

          this.allCounselParties.splice(this.index,1);

          if(counselToDelete.partyType == 'REAL PARTY'){
            this.toastr.success(`real party successfully removed`, "", {
              closeButton: true
            });
            this.getRealPartyInfo();
          }else {
            console.log('counselDeleteSuccess: ', counselDeleteSuccess);
            this.toastr.success(`Successfully deleted counsel`, "", {
              closeButton: true
            });
            this.getCounselInfo();
          }
        }, (counselDeleteFailure) => {
            console.log('counselDeleteFailure: ', counselDeleteFailure);
            this.toastr.error(`${counselDeleteFailure.error.message}`, "", {
              closeButton: true
            });
        });
      }
    })
  }



  /**
   * Real Party
   */


  setRealPartyStatus(partyType) {
    this.unsavedChanges = true;
    this.addMode = true;
    let tempModel = JSON.parse(JSON.stringify(this.addUpdateForm));
    if (partyType === 'ind') {
      this.tempOrgRealParty = JSON.parse(JSON.stringify(this.addUpdateForm));
      this.addUpdateForm = JSON.parse(JSON.stringify(this.tempPersonRealParty));
    } else if (partyType === 'org') {
      this.tempPersonRealParty = JSON.parse(JSON.stringify(this.addUpdateForm));
      this.addUpdateForm = JSON.parse(JSON.stringify(this.tempOrgRealParty));
    }

  }

  addRealParty() {
    if (this.validateRequiredRealParty()) {
      console.log('Valid!');


      // this.addUpdateForm.parties[0].rankNo = "1";
      this.addUpdateForm.parties[0].submitterType = this.modal.partyType === 'Petitioner'? "PETITIONER": "PATENTOWNER";
      this.addUpdateForm.parties[0].partyType = "REAL PARTY";
      this.addUpdateForm.caseNo = this.modal.caseInfo.proceedingNo;
      this.addUpdateForm.audit.createUserIdentifier = this.loggedInUser.loginId;
      this.addUpdateForm.audit.lastModifiedUserIdentifier = this.loggedInUser.loginId;
      if(this.addUpdateForm.parties[0].personType[0] && this.addUpdateForm.parties[0].personType[0].firstName){
        this.addUpdateForm.parties[0].orgType = [];
        this.addUpdateForm.parties[0].personType[0].mailingAddress[0].addressType = 'RES';
        this.addUpdateForm.parties[0].personType[0].electronicAddress[0].emailType = 'PE';
      }else {
        this.addUpdateForm.parties[0].personType = [];
        this.addUpdateForm.parties[0].orgType[0].orgAddress[0].addressType = 'RES';
        this.addUpdateForm.parties[0].orgType[0].electronicAddress[0].emailType = 'WE';
      }
      let partUrl = `${PtabTrialConstants.TRIAL_SERVICES_URL}/proceeding-party-details`
      // this.jpViewService.uploadRealParty(partUrl,this.addUpdateForm).subscribe((partyResponse)=>{
      this.trialsService.uploadRealParty(this.addUpdateForm).subscribe((partyResponse)=>{
        this.cancelAddCounsel();
        this.unsavedChanges = false;
        this.getRealPartyInfo();
        this.toastr.success(this.modal.partyType +` real party successfully saved`, "", {
          closeButton: true
        });
      },(failure) => {
        console.log('addRealPartyFailure: ', failure);
        this.toastr.error(`${failure.error.message}`, "", {
          closeButton: true
        });
    });
    }
  }


  updateRealParty() {
    if (this.validateRequiredRealParty()) {
      console.log('Valid!');
      let partUrl = `${PtabTrialConstants.TRIAL_SERVICES_URL}/proceeding-party-details`;
      if (this.actionToPerform === "edit") {
      // this.jpViewService.updatePartyInfo(partUrl,this.addUpdateForm).subscribe((partyResponse)=>{
      this.trialsService.updateRealParty(partUrl,this.addUpdateForm).subscribe((partyResponse)=>{
        this.unsavedChanges = false;
        this.cancelAddRealParty();
        this.getRealPartyInfo();
        this.toastr.success(this.modal.partyType +` real party successfully saved`, "", {
          closeButton: true
        });
      }, (failure) => {
        console.log('updateRealPartyFailure: ', failure);
        this.toastr.error(`${failure.message}`, "", {
          closeButton: true
        });
    });
  }else if (this.actionToPerform === 'real' || this.actionToPerform === 'additional') {
    let val = this.actionToPerform === 'real' ? true : false;
    this.switchRealParty(val, this.addUpdateForm.parties[0]);
  }
    }

  }


  cancelAddRealParty() {
    console.log("cancelling add real party");
    this.partyType = null;
    this.unsavedChanges = false;
    this.addMode = false;
    this.editMode = false;
    this.initiatePartiesModal();
    this.disableDoneBtn = false;
    this.actionToPerform = null;
    this.enableAdd = false;
    this.clearRealPartyValidation();
  }


  clearRealPartyValidation() {
    this.validationRealParty = {
      firstNameEmpty: false,
      lastNameEmpty: false,
      organization: false,
      email: false,
      city: false,
      phone: false,
      country: false,
      state: false,
      showError: false,
      errorCount: 0,
      errorMessages: []
    };
  }


  validateRequiredRealParty() {
    this.validationRealParty.errorMessages = [];
    this.validationRealParty.errorCount = 0;
    if (this.partyType === 'individual') {
      this.validationRealParty.firstNameEmpty = this.validateNull(this.addUpdateForm.parties[0].personType[0].firstName);
      if (this.validationRealParty.firstNameEmpty) {
        this.validationRealParty.errorMessages.push('First name is required.')
      }
      this.validationRealParty.lastNameEmpty = this.validateNull(this.addUpdateForm.parties[0].personType[0].lastName);
      if (this.validationRealParty.lastNameEmpty) {
        this.validationRealParty.errorMessages.push('Last name is required.')
      }
      if (this.addUpdateForm.parties[0].personType[0].electronicAddress[0].email) {
        this.validationRealParty.email = !this.validateEmail(this.addUpdateForm.parties[0].personType[0].electronicAddress[0].email)
        if (this.validationRealParty.email) {
          this.validationRealParty.errorMessages.push('Email format is invalid.');
        }
      } else {
        this.validationRealParty.email = false;
      }
    }
    if (this.partyType === 'organization') {
      this.validationRealParty.organization = this.validateNull(this.addUpdateForm.parties[0].orgType[0].legalname);
      if (this.validationRealParty.organization) {
        this.validationRealParty.errorMessages.push('Organization is required.')
      }
      if (this.addUpdateForm.parties[0].orgType[0].electronicAddress[0].email) {
        this.validationRealParty.email = !this.validateEmail(this.addUpdateForm.parties[0].orgType[0].electronicAddress[0].email)
        if (this.validationRealParty.email) {
          this.validationRealParty.errorMessages.push('Email format is invalid.');
        }
      } else {
        this.validationRealParty.email = false;
      }
    }

    this.validationRealParty.showError = this.validationRealParty.errorCount > 0;

    if (this.partyType === 'individual') {
      return (!this.validationRealParty.firstNameEmpty || !this.validationRealParty.lastNameEmpty) && !this.validationRealParty.email;
    } else if (this.partyType === 'organization') {
      return !this.validationRealParty.organization && !this.validationRealParty.email;
    }
  }


  seeVals() {
    if (!this.modal.counselInfo) {
      this.disableBackup = true;
    }
  }

}
