import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { JpViewService } from '../../../services/jpview.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { take } from 'rxjs/operators';
import { of } from 'rxjs';
import { UpdatePartiesModalComponent } from './update-parties-modal.component';
import { provideMockStore } from '@ngrx/store/testing';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { ToastrService } from 'ngx-toastr';
import { PhonePipe } from 'src/app/utilities/phone-number-pipe';
import { TrialsService } from 'src/app/services/trials.service';



xdescribe('UpdatePartiesModalComponent', () => {
  let component: UpdatePartiesModalComponent;
  let modalService: BsModalService;
  let jpViewService: JpViewService;
  let trialsServices: TrialsService;
  let fixture: ComponentFixture<UpdatePartiesModalComponent>;
  let toastr: ToastrService

  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => {},
    error: (
      message?: string,
      title?: string
    ) => {},
  };


  const loggedInUserMock = {
    loginId: 'sbartlett'
  }


  const addUpdateFormMock = {
    "caseNo": null,
    "proceedingSupplementaryIdList": [],
    "supplementaryIdType": null,
    "caseType": null,
    "identifier": null,
    "parties": [{
      "identifier": null,
      "rankNo": null,
      "partyType": null,
      "partySubType": null,
      "partySubTypeDescription": null,
      // "partyReference": null,
      "registrationNo": null,
      "submitterType": null,
      "personType": [{
        "identifier": null,
        "firstName": null,
        "lastName": null,
        "middleInitial": null,
        "prefferedName": null,
        "mailingAddress": [{
          "identifier": null,
          "streetLineOneText": null,
          "streetLineTwoText": null,
          "city": null,
          "state": null,
          "zipCode": null,
          "country": null,
          "addressType": null,
        }],
        "electronicAddress": [{
          "identifier": null,
          "teleCommAddresType": null,
          "telephoneNumber": null,
          "email": null,
          "emailType": null,
          "extension": null,
        }]
      }],
      "orgType": [{
        "identifier": null,
        "legalname": null,
        "orgAddress": [{
          "identifier": null,
          "streetLineOneText": null,
          "streetLineTwoText": null,
          "city": null,
          "state": null,
          "zipCode": null,
          "country": null,
          "addressType": null,
        }],
        "electronicAddress": [{
          "identifier": null,
          "teleCommAddresType": null,
          "telephoneNumber": null,
          "email": null,
          "emailType": null,
          "extension": null,
        }]
      }]
    }],
    "audit":{
      "lastModifiedUserIdentifier": "",
      "createUserIdentifier":""
    }
  }

  let modal = {
    title: "Update",
    partyType: "Petitioner",
    interestedParty: "Counsel",
    caseInfo: {
      serialNo: "123456",
      proceedingNo: "CBM2020-00010"
    }
  }

  const modalMock = { "title": "Update", "interestedParty": "counsel", "partyType": "petitioner", "closeBtnName": "Done", "isConfirm": false, "counselInfo": { "parties": [{ "identifier": "15855895", "submitterType": "PETITIONER", "orgType": [], "partySubTypeDescription": "Lead Counsel", "registrationNo": "65,506", "partySubType": "LEAD", "partyType": "COUNSEL", "personType": [{ "identifier": "15858049", "firstName": "Kevin", "lastName": "Rodkey", "electronicAddress": [], "mailingAddress": [{ "identifier": "12151982", "zipCode": "30363-6209", "country": "US", "streetLineTwoText": "271 17th Street, NW, Suite 1400", "streetLineOneText": "Finnegan, Henderson, Farabow, Garrett & Dunner, LLP", "city": "Atlanta", "addressType": "BUS", "state": "GA" }] }], "rankNo": 1 }, { "identifier": "15855918", "submitterType": "PETITIONER", "orgType": [], "partySubTypeDescription": "Back Up Counsel", "registrationNo": "76,224", "partySubType": "BACKUP", "partyType": "COUNSEL", "personType": [{ "identifier": "15858072", "firstName": "Jency", "lastName": "Mathew", "electronicAddress": [], "mailingAddress": [{ "identifier": "12151949", "zipCode": "20190-5675", "country": "US", "streetLineTwoText": "11955 Freedom Drive", "streetLineOneText": "Finnegan, Henderson, Farabow, Garrett & Dunner, LLP", "city": "Reston", "addressType": "BUS", "state": "VA" }] }], "rankNo": 2 }, { "identifier": "15855894", "submitterType": "PETITIONER", "orgType": [], "partySubTypeDescription": "Back Up Counsel", "registrationNo": "57540", "partySubType": "BACKUP", "partyType": "COUNSEL", "personType": [{ "identifier": "15858048", "firstName": "Erika", "lastName": "Arner", "electronicAddress": [], "mailingAddress": [{ "identifier": "12151981", "zipCode": "20190-5675", "country": "US", "streetLineTwoText": "11955 Freedom Drive", "streetLineOneText": "Finnegan, Henderson, Farabow, Garrett & Dunner, LLP", "city": "Reston", "addressType": "BUS", "state": "VA" }] }], "rankNo": 3 }], "caseNo": "CBM2020-00010" }, "caseInfo": { "serialNo": "13088068", "proceedingNo": "CBM2020-00010" }, "modalType": "counsel" };


  const foundSingleCounsel = [{ "parties": [{ "registrationNo": "57540", "personType": [{ "firstName": "Erika", "lastName": "Arner", "electronicAddress": [{ "email": "test1_erika.arner@finnegan.com" }] }], "orgType": [] }] }];


  const getCounselInfoMock = { "poCounsel": { "parties": [{ "identifier": "15858717", "submitterType": "PATENTOWNER", "orgType": [], "partySubTypeDescription": "Lead Counsel", "registrationNo": "61554", "partySubType": "PROSE", "partyType": "COUNSEL", "personType": [{ "identifier": "15860931", "firstName": "Timothy", "lastName": "Wang", "electronicAddress": [{ "identifier": "12915212", "telephoneNumber": "9723314600", "teleCommAddresType": "W" }, { "identifier": "12915213", "telephoneNumber": "9723140900", "teleCommAddresType": "F" }, { "identifier": "10338419", "emailType": "WE", "email": "test4_twang@nilawfirm.com" }], "mailingAddress": [{ "identifier": "12154002", "zipCode": "75231", "country": "US", "streetLineTwoText": "Suite 500", "streetLineOneText": "8140 Walnut Hill Lane", "city": "Dallas", "addressType": "BUS", "state": "TX" }] }], "rankNo": 1 }], "caseNo": "CBM2020-00010" }, "ptabReadOnlyUser": true, "poRealParty": { "parties": [{ "identifier": "15858715", "submitterType": "PATENTOWNER", "orgType": [{ "identifier": "15860929", "electronicAddress": [], "legalname": "Lighthouse Consulting Group LLC", "orgAddress": [] }], "partyType": "REAL PARTY", "personType": [], "rankNo": 1 }, { "identifier": "15884163", "submitterType": "PATENTOWNER", "orgType": [{ "identifier": "15886230", "electronicAddress": [{ "identifier": "12933874", "telephoneNumber": "4562345672", "teleCommAddresType": "W" }, { "identifier": "10351533", "emailType": "WE", "email": "email" }], "legalname": "org test ", "orgAddress": [{ "identifier": "12169457", "country": "US", "streetLineTwoText": "22", "streetLineOneText": "address1", "city": "city", "addressType": "RES", "state": "VA" }] }], "partyType": "REAL PARTY", "personType": [], "rankNo": 1 }, { "identifier": "15884166", "submitterType": "PATENTOWNER", "orgType": [{ "identifier": "15886233", "electronicAddress": [{ "identifier": "12933878", "telephoneNumber": "4562345672", "teleCommAddresType": "W" }, { "identifier": "10351536", "emailType": "WE", "email": "email" }], "legalname": "org test ", "orgAddress": [{ "identifier": "12169460", "country": "US", "streetLineTwoText": "22", "streetLineOneText": "address1", "city": "city", "addressType": "RES", "state": "VA" }] }], "partyType": "REAL PARTY", "personType": [], "rankNo": 1 }, { "identifier": "15884165", "submitterType": "PATENTOWNER", "orgType": [{ "identifier": "15886232", "electronicAddress": [{ "identifier": "12933877", "telephoneNumber": "4562345672", "teleCommAddresType": "W" }, { "identifier": "10351535", "emailType": "WE", "email": "email" }], "legalname": "org test ", "orgAddress": [{ "identifier": "12169459", "country": "US", "streetLineTwoText": "22", "streetLineOneText": "address1", "city": "city", "addressType": "RES", "state": "VA" }] }], "partyType": "REAL PARTY", "personType": [], "rankNo": 1 }], "caseNo": "CBM2020-00010" }, "petitionRealParty": { "parties": [{ "identifier": "15855917", "submitterType": "PETITIONER", "orgType": [{ "identifier": "15858071", "electronicAddress": [], "legalname": "Fidelity Information Services, LLC", "orgAddress": [] }], "partyType": "REAL PARTY", "personType": [], "rankNo": 1 }, { "identifier": "15855893", "submitterType": "PETITIONER", "orgType": [{ "identifier": "15858047", "electronicAddress": [], "legalname": "Fidelity National Information Services, Inc.", "orgAddress": [] }], "partyType": "REAL PARTY", "personType": [], "rankNo": 2 }, { "identifier": "15884157", "submitterType": "PETITIONER", "orgType": [], "partyType": "REAL PARTY", "personType": [{ "identifier": "15886224", "firstName": "first", "lastName": "last", "electronicAddress": [{ "identifier": "12933864", "telephoneNumber": "34525325728", "teleCommAddresType": "W" }, { "identifier": "12933865", "telephoneNumber": "2389478948438", "teleCommAddresType": "F" }, { "identifier": "10351528", "emailType": "PE", "email": "email" }], "mailingAddress": [{ "identifier": "12169451", "country": "US", "streetLineTwoText": "add2", "streetLineOneText": "add1", "city": "city", "addressType": "RES", "state": "VA" }] }], "rankNo": 3 }, { "identifier": "15884158", "submitterType": "PETITIONER", "orgType": [{ "identifier": "15886225", "electronicAddress": [{ "identifier": "12933866", "telephoneNumber": "5765757567567", "teleCommAddresType": "W" }, { "identifier": "12933867", "telephoneNumber": "5675764323", "teleCommAddresType": "F" }, { "identifier": "10351529", "emailType": "WE", "email": "email" }], "legalname": "org test", "orgAddress": [{ "identifier": "12169452", "country": "US", "streetLineTwoText": "address22", "streetLineOneText": "address2", "city": "city", "addressType": "BUS", "state": "VT" }] }], "partyType": "REAL PARTY", "personType": [], "rankNo": 4 }, { "identifier": "15884159", "submitterType": "PETITIONER", "orgType": [{ "identifier": "15886226", "electronicAddress": [{ "identifier": "12933868", "telephoneNumber": "657657656754564", "teleCommAddresType": "W" }, { "identifier": "12933869", "telephoneNumber": "757657656575", "teleCommAddresType": "F" }, { "identifier": "10351530", "emailType": "WE", "email": "email" }], "legalname": "org test", "orgAddress": [{ "identifier": "12169453", "country": "US", "streetLineTwoText": "add2", "streetLineOneText": "add1", "city": "city", "addressType": "BUS", "state": "VI" }] }], "partyType": "REAL PARTY", "personType": [], "rankNo": 1 }, { "identifier": "15884162", "submitterType": "PETITIONER", "orgType": [{ "identifier": "15886229", "electronicAddress": [{ "identifier": "12933872", "telephoneNumber": "564565644", "teleCommAddresType": "W" }, { "identifier": "12933873", "telephoneNumber": "3456752346", "teleCommAddresType": "F" }, { "identifier": "10351532", "emailType": "WE", "email": "email" }], "legalname": "org test", "orgAddress": [{ "identifier": "12169456", "country": "US", "streetLineTwoText": "add2", "streetLineOneText": "add1", "city": "city", "addressType": "RES", "state": "VT" }] }], "partyType": "REAL PARTY", "personType": [], "rankNo": 1 }], "caseNo": "CBM2020-00010" }, "petitionCounsel": { "parties": [{ "identifier": "15855918", "submitterType": "PETITIONER", "orgType": [], "partySubTypeDescription": "Back Up Counsel", "registrationNo": "76,224", "partySubType": "BACKUP", "partyType": "COUNSEL", "personType": [{ "identifier": "15858072", "firstName": "Jency", "lastName": "Mathew", "electronicAddress": [], "mailingAddress": [{ "identifier": "12151949", "zipCode": "20190-5675", "country": "US", "streetLineTwoText": "11955 Freedom Drive", "streetLineOneText": "Finnegan, Henderson, Farabow, Garrett & Dunner, LLP", "city": "Reston", "addressType": "BUS", "state": "VA" }] }], "rankNo": 3 }, { "identifier": "15855895", "submitterType": "PETITIONER", "orgType": [], "partySubTypeDescription": "Back Up Counsel", "registrationNo": "65,506", "partySubType": "BACKUP", "partyType": "COUNSEL", "personType": [{ "identifier": "15858049", "firstName": "Kevin", "lastName": "Rodkey", "electronicAddress": [], "mailingAddress": [{ "identifier": "12151982", "zipCode": "30363-6209", "country": "US", "streetLineTwoText": "271 17th Street, NW, Suite 1400", "streetLineOneText": "Finnegan, Henderson, Farabow, Garrett & Dunner, LLP", "city": "Atlanta", "addressType": "BUS", "state": "GA" }] }], "rankNo": 3 }, { "identifier": "15855894", "submitterType": "PETITIONER", "orgType": [], "partySubTypeDescription": "Back Up Counsel", "registrationNo": "57540", "partySubType": "BACKUP", "partyType": "COUNSEL", "personType": [{ "identifier": "15858048", "firstName": "Erika", "lastName": "Arner", "electronicAddress": [], "mailingAddress": [{ "identifier": "12151981", "zipCode": "20190-5675", "country": "US", "streetLineTwoText": "11955 Freedom Drive", "streetLineOneText": "Finnegan, Henderson, Farabow, Garrett & Dunner, LLP", "city": "Reston", "addressType": "BUS", "state": "VA" }] }], "rankNo": 2 }, { "identifier": "15884357", "submitterType": "PETITIONER", "orgType": [], "partySubTypeDescription": "Pro se", "registrationNo": "00000", "partySubType": "PROSE", "partyType": "COUNSEL", "personType": [{ "identifier": "15886434", "firstName": "Patrick", "lastName": "Michael", "electronicAddress": [{ "identifier": "10351693", "emailType": "WE", "email": "test1_pmichael@jonesday.com" }], "mailingAddress": [{ "identifier": "12169651", "streetLineOneText": "    ", "city": "    ", "addressType": "BUS" }] }], "rankNo": 1 }], "caseNo": "CBM2020-00010" } };


  const countriesMock = {
    "ptabReadOnlyUser": true,
    "success": true,
    "responseData": [{
      "longDescription": "UNITED STATES OF AMERICA",
      "validDate": "12/15/1974",
      "description": "UNITED STATES",
      "id": "100753",
      "value": "US",
      "inValidDate": "01/01/0001",
      "propsList": []
    },
    {
      "longDescription": "CANADA",
      "validDate": "12/15/1974",
      "description": "CANADA",
      "id": "100563",
      "value": "CA",
      "inValidDate": "01/01/0001",
      "propsList": []
      }]
  };

  const statesMock = {
    "ptabReadOnlyUser": true,
    "success": true,
    "responseData": [{
      "longDescription": "ILLINOIS",
      "validDate": "12/15/1974",
      "description": "ILLINOIS",
      "id": "100810",
      "value": "IL",
      "inValidDate": "01/01/0001",
      "propsList": []
      },
      {
        "longDescription": "VIRGINIA",
        "validDate": "12/15/1974",
        "description": "VIRGINIA",
        "id": "100855",
        "value": "VA",
        "inValidDate": "01/01/0001",
        "propsList": []
        }]
  }



  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UpdatePartiesModalComponent, PhonePipe],
      imports: [HttpClientTestingModule],
      providers: [JpViewService, TrialsService, provideMockStore({
        selectors: [
          { selector: CaseViewerSelectors.caseInfoData, value: { proceedingNo: '37553565' } },
          {selector: CaseViewerSelectors.userInfoData,value:{caseDetailsData: []}}
        ]
      }),
      {
        provide: ToastrService,
        useValue: toastrService
      },
        {
        provide: BsModalRef,
        useValue: {}
      },
      {
        provide: BsModalService,
        useValue: {}
      }]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatePartiesModalComponent);
    modalService = TestBed.inject(BsModalService);
    jpViewService = TestBed.inject(JpViewService);
    trialsServices = TestBed.inject(TrialsService);
    component = fixture.componentInstance;
    component.modal = modalMock;
    component.loggedInUser = loggedInUserMock;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });



  it('should call get countryList and return response', () => {
    // spyOn(jpViewService, 'getCountries').and.returnValue(of(countriesMock));
    spyOn(trialsServices, 'getCountries').and.returnValue(of(countriesMock));
    component.getCountryList();
    expect(component.countryList).toEqual(countriesMock.responseData);
  });


  it('should call get stateList and return response', () => {
    // spyOn(jpViewService, 'getStates').and.returnValue(of(statesMock));
    spyOn(trialsServices, 'getStates').and.returnValue(of(statesMock));
    component.getStateList('US');
    expect(component.stateList).toEqual(statesMock.responseData);
  });


  it('should call selectedCountry and return success', () => {
    const countryCode = 'US';
    spyOn(component, 'getStateList');
    component.selectedCountry(countryCode);
    expect(component.zipCodeLabel).toEqual(countryCode.toLowerCase());
    expect(component.getStateList).toHaveBeenCalled();
  });


  it('should call clearSearch', () => {
    component.clearSearch();
    expect(component.searchCriteria).toBeNull();
  });


  it('should call cancelAddCounsel', () => {
    component.cancelAddCounsel();
    spyOn(component, 'initiatePartiesModal');
    spyOn(component, 'clearValidation');
    spyOn(component, 'clearSearch');
    expect(component.proSe).toBeNull();
    expect(component.addMode ).toBeFalse();
    expect(component.editMode).toBeFalse();
    expect(component.enableAdd ).toBeFalse();
    expect(component.counselFound ).toBeFalse();
    expect(component.disableDoneBtn).toBeFalse();
    expect(component.disableBackup).toBeFalse();
    expect(component.actionToPerform).toBeNull();
    // expect(component.initiatePartiesModal).toHaveBeenCalled();
    // expect(component.clearValidation).toHaveBeenCalled();
    // expect(component.clearSearch).toHaveBeenCalled();
  });


  it('should call validateRequired with no firstName', () => {
    component.addUpdateForm = addUpdateFormMock;
    component.addUpdateForm.parties[0].personType[0].firstName = null;
    component.addUpdateForm.parties[0].personType[0].lastName = "Doe";
    component.editMode = false;
    let results = component.validateRequired();
    expect(results).toBeTrue();
  });


  it('should call validateRequired with no lastName', () => {
    component.addUpdateForm = addUpdateFormMock;
    component.addUpdateForm.parties[0].personType[0].firstName = "John";
    component.addUpdateForm.parties[0].personType[0].lastName = null;
    component.editMode = false;
    let results = component.validateRequired();
    expect(results).toBeTrue();
  });


  it('should call validateRequired with in editMode with proSe as no', () => {
    component.addUpdateForm = addUpdateFormMock;
    component.addUpdateForm.parties[0].personType[0].firstName = "John";
    component.addUpdateForm.parties[0].personType[0].lastName = "Doe";
    component.addUpdateForm.parties[0].partySubType = null;
    component.editMode = true;
    component.proSe = 'no';
    let results = component.validateRequired();
    expect(results).toBeFalse();
  });


  it('should call findCounsel with email address and find one record', () => {
    // spyOn(jpViewService, 'findCounsel').and.returnValue(of(foundSingleCounsel));
    spyOn(trialsServices, 'findCounsel').and.returnValue(of(foundSingleCounsel));
    component.findCounsel('test1_erika.arner@finnegan.com');
    expect(component.enableAdd).toBeTrue();
  });



  // fit('should call findCounsel with email address and find multiple records', () => {
  //   let counselFound = [];
  //   counselFound.push({"parties":[{"registrationNo":"57540","personType":[{"firstName":"Erika","lastName":"Arner","electronicAddress":[{"email":"test1_erika.arner@finnegan.com"}]}],"orgType":[]}]});
  //   counselFound.push({"parties":[{"registrationNo":"57540","personType":[{"firstName":"Erika","lastName":"Arner","electronicAddress":[{"email":"test1_erika.arner@finnegan.com"}]}],"orgType":[]}]});
  //   spyOn(jpViewService, 'findCounsel').and.returnValue(of(counselFound));
  //   spyOn(component, 'openSelectEmailModal');
  //   component.findCounsel('test1_erika.arner@finnegan.com');
  //   expect(component.openSelectEmailModal).toHaveBeenCalled();
  // });


  it('should call findCounsel with no records', () => {
    let noCounselFound = [];
    // spyOn(jpViewService, 'findCounsel').and.returnValue(of(noCounselFound));
    spyOn(trialsServices, 'findCounsel').and.returnValue(of(noCounselFound));
    component.findCounsel('test1_erika.arner@finnegan.com');
    expect(component.showNotRegisteredMsg).toBeTrue();
  });


  it('should call getCounselInfo and return a success response for petitioner', () => {
    spyOn(trialsServices, 'getCounselInfo').and.returnValue(of(getCounselInfoMock));
    component.modal.partyType = 'petitioner';
    component.getCounselInfo();
    expect(component.modal.counselInfo).toEqual(getCounselInfoMock.petitionCounsel);
  });


  it('should call getCounselInfo and return a success response for patent owner', () => {
    spyOn(trialsServices, 'getCounselInfo').and.returnValue(of(getCounselInfoMock));
    component.modal.partyType = 'patent owner';
    component.getCounselInfo();
    expect(component.modal.counselInfo).toEqual(getCounselInfoMock.poCounsel);
  });

  it('should setAddMode as true', () => {
    component.setAddMode(true);
    expect(component.addMode).toBeTrue();
  })


  it('should setAddMode as false', () => {
    component.setAddMode(false);
    expect(component.addMode).toBeFalse();
  })


  it('should call close with unsaved changes', () => {
    spyOn(component, 'openAbandonChangesModal');
    component.unsavedChanges = true;
    component.close(true);
    expect(component.openAbandonChangesModal).toHaveBeenCalled();
  });


  // it('should call getRealPartyInfo and return a success response for petitioner', () => {
  //   spyOn(jpViewService, 'getCounselInfo').and.returnValue(of(getCounselInfoMock));
  //   component.modal.partyType = 'Petitioner';
  //   component.getRealPartyInfo();
  //   expect(component.modal.counselInfo).toEqual(getCounselInfoMock.petitionRealParty);
  // });


  // it('should call getRealPartyInfo and return a success response for patent owner', () => {
  //   spyOn(jpViewService, 'getCounselInfo').and.returnValue(of(getCounselInfoMock));
  //   component.modal.partyType = 'Patent owner';
  //   component.getRealPartyInfo();
  //   expect(component.modal.counselInfo).toEqual(getCounselInfoMock.poRealParty);
  // });


  // fit('should call addCounsel', () => {
  //   component.proSe = 'yes';
  //   component.loggedInUser = {
  //     loginId: 'sbartlett'
  //   };
  //   component.addUpdateForm.parties = [{ "identifier": null, "rankNo": null, "partyType": null, "partySubType": "BACKUP", "partySubTypeDescription": null, "registrationNo": "00000", "submitterType": null, "personType": [{ "identifier": null, "firstName": "Britton", "lastName": "Davis", "middleInitial": null, "prefferedName": null, "mailingAddress": [{ "identifier": null, "streetLineOneText": null, "streetLineTwoText": null, "city": null, "state": null, "zipCode": null, "country": null, "addressType": null }], "electronicAddress": [{ "email": "test1_bdavis@cooley.com", "identifier": null, "extension": null }, { "teleCommAddresType": "F", "telephoneNumber": null, "identifier": null, "extension": null }, { "teleCommAddresType": "W", "telephoneNumber": null, "identifier": null, "extension": null }] }], "orgType": [{ "identifier": null, "legalname": null, "orgAddress": [{ "identifier": null, "streetLineOneText": null, "streetLineTwoText": null, "city": null, "state": null, "zipCode": null, "country": null, "addressType": null }], "electronicAddress": [{ "identifier": null, "teleCommAddresType": null, "telephoneNumber": null, "email": null, "emailType": null, "extension": null }] }] }];
  //   // spyOn(jpViewService, 'addCounsel');
  //   const userName = {
  //     loginId: 'sbartlett'
  //   }
  //   window.sessionStorage.setItem('userName', JSON.stringify(userName));
  //   component.addCounsel();
  //   // expect(jpViewService.addCounsel).toHaveBeenCalled();
  // });


  it('should call editRealParty', () => {
    component.loggedInUser = {
      "loginId": "sbartlett"
    };
    const action = 'edit';
    const partyToEdit = { "identifier": "15855917", "submitterType": "PETITIONER", "orgType": [{ "identifier": "15858071", "electronicAddress": [], "legalname": "Fidelity Information Services, LLC", "orgAddress": [] }], "partyType": "REAL PARTY", "personType": [], "rankNo": 1 };
    component.editRealParty(partyToEdit, action);
  });



  it('should call editCounsel', () => {
    component.loggedInUser = {
      "loginId": "sbartlett"
    };
    const action = 'edit';
    const partyToEdit = {"identifier":"15884357","submitterType":"PETITIONER","orgType":[],"partySubTypeDescription":"Pro se","registrationNo":"00000","partySubType":"PROSE","partyType":"COUNSEL","personType":[{"identifier":"15886434","firstName":"Patrick","lastName":"Michael","electronicAddress":[{"identifier":"10351693","emailType":"WE","email":"test1_pmichael@jonesday.com"}],"mailingAddress":[{"identifier":"12169651","streetLineOneText":"    ","city":"    ","addressType":"BUS"}]}],"rankNo":1};
    component.editCounsel(partyToEdit, action);
  });




  it('should call cancelAddRealParty', () => {
    component.cancelAddRealParty();
    expect(component.partyType).toBeNull();
    expect(component.unsavedChanges).toBeFalse();
    expect(component.addMode).toBeFalse();
    expect(component.editMode).toBeFalse();
    expect(component.disableDoneBtn).toBeFalse();
    expect(component.actionToPerform).toBeNull();
    expect(component.enableAdd).toBeFalse();
  });



  it('should call validateRequiredRealParty', () => {
    component.validateRequiredRealParty();
  });



  it('should call seeVals', () => {
    component.modal = {
      counselInfo: false
    };
    component.seeVals();
    expect(component.disableBackup).toBeTrue();
  });


  // it('should call checkForUnsavedChanges', () => {
  //   component.modal = modal;
  //   fixture.detectChanges();
  //   component.checkForUnsavedChanges(true);
  //   expect(component.unsavedChanges).toBeTrue();
  // });


  // it('should call close with unsavedChanges', () => {
  //   component.unsavedChanges = true;
  //   const initialState: any = {
  //     title: "Abandon unsaved information?",
  //       subText: "You have document information that has not been saved to the docket. Your changes will be lost.",
  //       closeBtnName: "No, return to page",
  //       yesBtnName: "Yes, abandon changes",
  //       yesBtnClass: "btn-danger",
  //       isConfirm: false
  //   };
  //   modalService.show = (): BsModalRef => {
  //     return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
  //       animated: true,
  //       backdrop: 'static',
  //       class: 'modal-audit-size',
  //       initialState
  //     }}
  //   }
  //   component.close(true);
  //   expect(component.openAbandonChangesModal).toHaveBeenCalled();
  // });


  // it('should call close without unsaved changes', () => {
  //   component.unsavedChanges = false;
  //   component.modal = {
  //     isConfirm: true
  //   }
  //   // spyOn(modalService, 'hide');
  //   component.close(false);
  //   expect(component.modal.isConfirm).toBeFalse();
  //   // expect(modalService.hide).toHaveBeenCalled();
  // });
});
