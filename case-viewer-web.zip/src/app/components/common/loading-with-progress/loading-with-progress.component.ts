import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-loading-with-progress',
  templateUrl: './loading-with-progress.component.html',
  styleUrls: ['./loading-with-progress.component.less']
})
export class LoadingWithProgressComponent implements OnInit {

  @Input() loadingMessage: string;

  value: number = 0;
  step: number = 0.25; //the smaller this is the slower the progress bar
  current_progress: number = 0;

  constructor() { }

  ngOnInit(): void {

    let interval = setInterval(() => {
      this.current_progress += this.step;
      this.value = Math.trunc(Math.round(Math.atan(this.current_progress) / (Math.PI / 2) * 100 * 1000) / 1000);
      if (this.value >= 100){
          clearInterval(interval);
      }else if(this.value >= 40) {
          this.step = 0.1
      }
    }, 100)
  }

}
