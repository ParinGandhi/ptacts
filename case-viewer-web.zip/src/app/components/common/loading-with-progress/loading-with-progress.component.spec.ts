import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoadingWithProgressComponent } from './loading-with-progress.component';


/**
 * 91.67%
 */
describe('LoadingWithProgressComponent', () => {
  let component: LoadingWithProgressComponent;
  let fixture: ComponentFixture<LoadingWithProgressComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoadingWithProgressComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoadingWithProgressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


});
