import { Component, OnInit, Input } from '@angular/core';
import AlertModel from '../../../models/common/Alert.model';

@Component({
  selector: 'app-alerts',
  templateUrl: './alerts.component.html',
  styleUrls: ['./alerts.component.less']
})
export class AlertsComponent implements OnInit {

  @Input() alertOptions: AlertModel;

  constructor() { }

  ngOnInit(): void {
  }

}
