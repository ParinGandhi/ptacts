import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Select2OptionData } from 'ng-select2';
import { Options } from 'select2';

@Component({
  selector: 'app-type-ahead',
  templateUrl: './type-ahead.component.html',
  styleUrls: ['./type-ahead.component.less']
})
export class TypeAheadComponent implements OnInit {

  @Input() dataList: Array<Select2OptionData>
  @Input() selectedItem: string
  @Output()
  valueChanged: EventEmitter<any> = new EventEmitter<any>();



  constructor() { }

  ngOnInit(): void {
  }

  options = {
    multiple: false,
    closeOnSelect: true,
    width: '100%',
    allowClear: true,
    theme: 'bootstrap',
  }

  updateValue() {
    // let selectedItem;
    // this.dataList.forEach((item) => {
    //   if (item.id === this.selectedItem) {
    //     selectedItem = item;
    //   }
    // })
    this.valueChanged.emit(this.selectedItem);
  }

}
