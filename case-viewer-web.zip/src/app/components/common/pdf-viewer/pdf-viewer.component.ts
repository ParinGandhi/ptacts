import { Component, Input, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';


@Component({
  selector: 'app-pdf-viewer',
  templateUrl: './pdf-viewer.component.html',
  styleUrls: ['./pdf-viewer.component.less']
})
export class PdfViewerComponent implements OnInit {

  @Input() fileToView;

  constructor(private sanitize: DomSanitizer) { }

  ngOnInit(): void {
    // return this.sanitize.bypassSecurityTrustResourceUrl(this.fileToView);
  }


}
