import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-expand-collapse',
  templateUrl: './expand-collapse.component.html',
  styleUrls: ['./expand-collapse.component.less']
})
export class ExpandCollapseComponent implements OnInit {

  constructor() { }

  @Input() expandCollapseLinkList: Array<string>;

  ngOnInit(): void {
  }

  expandCollapseAll(expectedAction) {
    this.expandCollapseLinkList.forEach(element => {
      let currentLink = document.getElementById(element);
      if (expectedAction === "expand") {
        if (currentLink.classList.contains('collapsed')) {
          currentLink.click();
        }
      } else if (expectedAction === "collapse") {
        if (!currentLink.classList.contains('collapsed')) {
          currentLink.click();
        }
      }
    });
  };

}
