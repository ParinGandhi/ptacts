import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GridRefreshComponent } from './grid-refresh.component';

xdescribe('GridRefreshComponent', () => {
  let component: GridRefreshComponent;
  let fixture: ComponentFixture<GridRefreshComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GridRefreshComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GridRefreshComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
