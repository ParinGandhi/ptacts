import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import GridRefreshModel from 'src/app/models/common/GridRefresh.model';

@Component({
  selector: 'app-grid-refresh',
  templateUrl: './grid-refresh.component.html',
  styleUrls: ['./grid-refresh.component.less']
})
export class GridRefreshComponent implements OnInit {

  @Input() gridRefreshValues: GridRefreshModel;
  @Output() refreshFunction: EventEmitter<any> = new EventEmitter();

  constructor() { }

  ngOnInit(): void {
  }


  onRefresh() {
    this.refreshFunction.emit();
  }

}
