import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JudgePanelRendererComponent } from './judge-panel-renderer.component';

xdescribe('JudgePanelRendererComponent', () => {
  let component: JudgePanelRendererComponent;
  let fixture: ComponentFixture<JudgePanelRendererComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JudgePanelRendererComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JudgePanelRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
