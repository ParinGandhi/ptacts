import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';

interface ToolTipParams extends ICellRendererParams {
  lineBreak?: boolean;
  tooltipType?: string;
  toolTipArray?: any[];
  commentList?: any[];
  toolTip?: string;
  petitionVsPo?: string;
}



@Component({
  selector: 'app-judge-panel-renderer',
  templateUrl: './judge-panel-renderer.component.html',
  styleUrls: ['./judge-panel-renderer.component.less']
})
export class JudgePanelRendererComponent implements ICellRendererAngularComp  {


  public params: ToolTipParams;
  public data: any;
  public toolTip: any;

  constructor() { }

  agInit(params: ToolTipParams): void {
    this.params = params;
    if (params.tooltipType === 'petitionerVsPo') {
      this.toolTip = params.petitionVsPo;
    } else if (params.lineBreak === true) {
      this.toolTip = params.toolTipArray;
      // (<string>params.toolTipArray).join("\r\n")
      // (params.toolTipArray).split(',').join("\r\n")
      // params.toolTipArray.replace(",", "<br />");
      // params.toolTipArray.join('\r\n');
    } else {
      this.toolTip = params.commentList;
    }
    // else if (params.lineBreak === false) {
    //   this.toolTip = params.toolTip;
    // } else {
    //   this.toolTip = params.value;
    // }
  }

  refresh(params: ToolTipParams): boolean {
    this.params = params;
    return true;
  }


}
