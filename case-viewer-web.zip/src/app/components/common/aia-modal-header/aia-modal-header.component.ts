import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-aia-modal-header',
  templateUrl: './aia-modal-header.component.html',
  styleUrls: ['./aia-modal-header.component.less']
})
export class AiaModalHeaderComponent implements OnInit {

  @Input() title: string;
  @Input() proceedingNo: string;

  @Output() closeFunction: EventEmitter<any> = new EventEmitter();

  constructor() { }

  ngOnInit(): void {
  }

  close() {
    this.closeFunction.emit();
  }

}
