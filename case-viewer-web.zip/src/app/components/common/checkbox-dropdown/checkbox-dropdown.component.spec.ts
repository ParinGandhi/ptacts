import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckboxDropdownComponent } from './checkbox-dropdown.component';

/** 100% */
describe('CheckboxDropdownComponent', () => {
  let component: CheckboxDropdownComponent;
  let fixture: ComponentFixture<CheckboxDropdownComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CheckboxDropdownComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckboxDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check the checkbox', () => {
    const selectedItem = {
      val: true,
      description: "Testing"
    };
    component.selectedValues = [];
    component.toggleSelect(selectedItem);
    expect(component.selectedValues.length).toBe(1);
  });


  it('should uncheck the checkbox', () => {
    const selectedValues = [];
    const selectedItem = {
      val: false,
      description: "Testing"
    };
    selectedValues.push(selectedItem);
    component.toggleSelect(selectedItem);
    expect(component.selectedValues.length).toBe(0);
  })


  it('should check all checkboxes', () => {
    const selection = 'all';
    component.selectedValues = [];
    component.dropdownValues = [{
      val: false,
      description: "TestingTrue"
    }, {
      val: false,
      description: "TestingFalse"
      }];
    component.toggleAll(selection);
    expect(component.selectedValues.length).toBe(2);
    expect(component.dropdownValues[0].val).toBe(true);
    expect(component.dropdownValues[1].val).toBe(true);
  });


  it('should uncheck all checkboxes', () => {
    const selection = 'some';
    component.selectedValues = [];
    component.dropdownValues = [{
      val: true,
      description: "TestingTrue"
    }, {
      val: true,
      description: "TestingFalse"
      }];
    component.toggleAll(selection);
    expect(component.selectedValues.length).toBe(0);
    expect(component.dropdownValues[0].val).toBe(false);
    expect(component.dropdownValues[1].val).toBe(false);
  });


  it('should clear all selections', () => {
    const selectedValues = [];
    const selectedItem = {
      val: false,
      description: "Testing"
    };
    selectedValues.push(selectedItem);

    component.dropdownValues = [{
      val: true,
      description: "TestingTrue"
    }, {
      val: true,
      description: "TestingFalse"
      }];

    component.clearSelection();
    expect(component.selectedValues.length).toBe(0);
    expect(component.dropdownValues[0].val).toBe(false);
    expect(component.dropdownValues[1].val).toBe(false);
  });
});
