import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {  } from 'events';

@Component({
  selector: 'app-checkbox-dropdown',
  templateUrl: './checkbox-dropdown.component.html',
  styleUrls: ['./checkbox-dropdown.component.less']
})
export class CheckboxDropdownComponent implements OnInit {

  @Input() dropdownValues;
  @Input() disableDropdown;
  @Output() selectedValueEmitter: EventEmitter<Array<string>> = new EventEmitter();

  selectedValues: Array<string> = [];
  selectedDescriptions: Array<string> = [];

  constructor() { }

  ngOnInit(): void {
    this.toggleAll('all');
  }

  toggleSelect(selectedItem) {
    if (selectedItem.val) {
      this.selectedValues.push(selectedItem.code);
      this.selectedDescriptions.push(selectedItem.description);
    } else {
      this.selectedValues.splice(this.selectedValues.indexOf(selectedItem.code), 1);
      this.selectedDescriptions.splice(this.selectedDescriptions.indexOf(selectedItem.description), 1);
    }
    this.selectedValueEmitter.emit(this.selectedValues);
  }

  toggleAll(selection) {
    this.selectedValues = [];
    this.selectedDescriptions = [];
    if (this.dropdownValues && this.dropdownValues.length > 0) {
      if (selection === 'all') {
        this.dropdownValues.forEach(item => {
          item.val = true;
          // this.selectedValues.push(item.description);
          this.selectedValues.push(item.code);
          this.selectedDescriptions.push(item.description);
        });
      } else {
        this.dropdownValues.forEach(item => {
          item.val = false;
        });
      }
    }
    this.selectedValueEmitter.emit(this.selectedValues);
  }


  clearSelection() {
    this.selectedValues = [];
    this.selectedDescriptions = [];
    this.dropdownValues.forEach(item => {
      item.val = false;
    });
  }

}
