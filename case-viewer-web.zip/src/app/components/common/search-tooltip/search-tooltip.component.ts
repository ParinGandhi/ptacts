import { Component, OnInit } from '@angular/core';
import { ITooltipAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';
import { GridHelperService } from 'src/app/services/grid-helper.service';

interface ToolTipParams extends ICellRendererParams {
  lineBreak?: boolean;
  tooltipType?: string;
  toolTipArray?: any[];
  commentList?: any[];
  toolTip?: string;
  petitionVsPo?: string;
  stringValue?: string;
}

@Component({
  selector: 'app-search-tooltip',
  templateUrl: './search-tooltip.component.html',
  styleUrls: ['./search-tooltip.component.less']
})
export class SearchTooltipComponent implements ITooltipAngularComp {

  private params: any;
  private data: any;
  public displayText: Array<string> = [];

  constructor(private gridHelper: GridHelperService) {

  }

  agInit(params): void {
    // this.params = params;
    this.data = params.api.getDisplayedRowAtIndex(params.rowIndex).data;
    if (params.data.judge1) {
      this.displayText.push(params.data.judge1);
      this.displayText.push(params.data.judge2);
      this.displayText.push(params.data.judge3);
    }
  }

}

