import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DatePipe } from '@angular/common';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ToastrMock } from 'src/app/models/Testing/ToastrMock.model';
import { SearchTooltipComponent } from './search-tooltip.component';

/**
 * !100.00%
 */
describe('SearchTooltipComponent', () => {
  let component: SearchTooltipComponent;
  let fixture: ComponentFixture<SearchTooltipComponent>;

  const toastrService: ToastrMock = new ToastrMock();

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [SearchTooltipComponent],
      providers: [DatePipe,
        { provide: BsModalRef, useValue: {} },
        { provide: BsModalService, useValue: {} },
        { provide: ToastrService, useValue: toastrService }]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchTooltipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    const params = {
      rowIndex: 1,
      api: {
        getDisplayedRowAtIndex: function() {
      return 5
        }
      },
      data: {
        judge1: "TestOne",
        judge2: "TestTwo",
        judge3: "TestThree"
      }
    }
    component.agInit(params);
    expect(component).toBeTruthy();
  });
});
