import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { CommonService } from 'src/app/services/common.service';
import { JpViewService } from 'src/app/services/jpview.service';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';


@Component({
  selector: 'app-open-document',
  templateUrl: './open-document.component.html',
  styleUrls: ['./open-document.component.less']
})
export class OpenDocumentComponent implements OnInit {

  docTitle: any;
  params: any;
  petitionerIdentifier: any;
  constructor(
    private store: Store<CaseViewerState>,
    private jpViewService: JpViewService,
    private commonService: CommonService,
    private commonUtils: CommonUtilitiesService
  ) { }

  agInit(params) {
    this.params = params;
    this.docTitle = params.value.docTitle;
  }

  ngOnInit(): void {
    this.getPetitionIdentifier()
  }

  getPetitionIdentifier() {
    // this.jpViewService.getCaseInfoByProceedingNo(`${PtabTrialConstants.COMMON_SERVICES_URL}/petitions?proceedingNumberText=${this.params.value.proceedingNumber}`).subscribe((caseInfoByProceedingResponse) => {
    this.commonService.getCaseInfoByProceedingNo(this.params.value.proceedingNumber).subscribe((caseInfoByProceedingResponse) => {
      this.petitionerIdentifier = caseInfoByProceedingResponse.petitionIdentifier;
    });
  }

  openDocument() {
    this.commonService.openPdf(`/petitions/${this.petitionerIdentifier}/download-documents?contentManagementId=${this.params.value.contentManagementId}`);
  }


}
