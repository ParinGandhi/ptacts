import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DataTableComponent } from './data-table.component';
import { FilterPipe } from "../../../utilities/table-filter-pipe";
import { DatePipe } from '@angular/common'

xdescribe('DataTableComponent', () => {
  let component: DataTableComponent;
  let fixture: ComponentFixture<DataTableComponent>;
  const testData = {
    tableId: "papersTable",
    tableHeaderClass: "papersTableHeader",
    tableBodyClass: "papersTableBody",
    columnDefs: [
      {
        name: "Column 1",
        displayName: "Column 1",
        field: "columnOne",
        width: 6,
        type: "string",
        searchText: null
      },
      {
        name: "Column 2",
        displayName: "Column 2",
        field: "columnTwo",
        width: 8,
        type: "date",
        searchText: "Testing search"
      },
      {
        name: "Column 3",
        displayName: "Column 3",
        field: "columnThree",
        width: 8,
        type: "string",
        searchText: null
      }],
    data: [
      {
        "columnOne": "Test1",
        "columnTwo": "Test2",
        "columnThree": "Test3"
      },
      {
        "columnOne": "Test4",
        "columnTwo": "Test5",
        "columnThree": "Test6"
      },
      {
        "columnOne": "Test7",
        "columnTwo": "Test8",
        "columnThree": "Test9"
      }
    ]
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DataTableComponent, FilterPipe],
      providers:[ DatePipe]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DataTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getNumberOfFilters and return 1', () => {
    component.tableOptions = testData;
    let results = component.getNumberOfFilters();
    expect(results).toBe(1);
  });

  it('should call clearAll and return value of 0', () => {
    component.tableOptions = {
      tableId: "papersTable",
      tableHeaderClass: "papersTableHeader",
      tableBodyClass: "papersTableBody",
      columnDefs: [
        {
          name: "Column 1",
          displayName: "Column 1",
          field: "columnOne",
          width: 6,
          type: "string",
          searchText: "Test one"
        },
        {
          name: "Column 2",
          displayName: "Column 2",
          field: "columnTwo",
          width: 8,
          type: "date",
          searchText: null
        },
        {
          name: "Column 3",
          displayName: "Column 3",
          field: "columnThree",
          width: 8,
          type: "string",
          searchText: "Test three"
        }],
      data: [
        {
          "columnOne": "Test1",
          "columnTwo": "Test2",
          "columnThree": "Test3"
        },
        {
          "columnOne": "Test4",
          "columnTwo": "Test5",
          "columnThree": "Test6"
        },
        {
          "columnOne": "Test7",
          "columnTwo": "Test8",
          "columnThree": "Test9"
        }
      ]
    };;
    component.clearAll();
    let results = component.getNumberOfFilters();
    expect(results).toBe(0);
  });

  it('should emit value', () => {
    spyOn(component.sortColumnEmitter, 'emit');
    fixture.detectChanges();
    component.sortColumn('papers');
    expect(component.sortColumnEmitter.emit).toHaveBeenCalled();
  });


});
