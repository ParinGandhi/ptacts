import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import * as CaseViewerActions from 'src/app/store/case-viewer/case-viewer.actions';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import { JpViewService } from 'src/app/services/jpview.service';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { CaseViewerService } from 'src/app/services/case-viewer.service';

@Component({
  selector: 'app-open-caseviewer',
  templateUrl: './open-caseviewer.component.html',
  styleUrls: ['./open-caseviewer.component.less']
})
export class OpenCaseviewerComponent implements OnInit {

  proceedingNo: any;
  params: any;

  constructor(
    private store: Store<CaseViewerState>,
    private jpViewService: JpViewService,
    private caseViewerService: CaseViewerService,
    private commonUtils: CommonUtilitiesService
  ) { }

  agInit(params) {
    this.params = params;
    this.proceedingNo = params.value;
  }

  ngOnInit(): void {
  }

  openCaseViewer() {

    // this.jpViewService.getDocuments(`${PtabTrialConstants.CASE_VIEWER_URL}/case-viewer/caseNumber-search?caseNumber=${this.proceedingNo}`).subscribe((caseInfoResponse) => {
    this.caseViewerService.caseSearch(this.proceedingNo).subscribe((caseInfoResponse) => {
      console.log('caseInfoResponse: ', caseInfoResponse);
      console.log("Params: ", this.params);
      // let caseInfo = {
      //   "serialNo": this.params.data.petitionerApplicationIdentifier? this.params.data.petitionerApplicationIdentifier :this.params.data.poApplicationIdentifier,
      //   "proceedingNo": this.params.data.proceedingNumber,
      //   "scrollToId": this.params.data.taskTypeName === PtabTrialConstants.TASK_TYPES.MANDATORY_NOTICE ? "mandatoryNotice" : "documents"
      // }
      let caseInfo = {
        "serialNo": caseInfoResponse.serialNumber[0],
        "proceedingNo": caseInfoResponse.appealNumber[0],
        "scrollToId": this.params.data.taskTypeName === PtabTrialConstants.TASK_TYPES.MANDATORY_NOTICE ? "mandatoryNotices" : "documents"
      }

      if (caseInfo.proceedingNo && caseInfo.serialNo) {
        this.store.dispatch(CaseViewerActions.setCaseInfoAction({ payload: caseInfo }));
        window.sessionStorage.setItem('caseInfo', JSON.stringify(caseInfo));
        let currentUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
        // this.caseNumberSearch = null;
        let newTabUrl = `${window.location.protocol}//${window.location.hostname}`;
        newTabUrl += window.location.port !== "" ? `:${window.location.port}` : "";
        // if (this.params.data.poApplicationIdentifier && this.params.data.proceedingNumber) {
        //   newTabUrl += window.location.hostname === 'localhost' ? "/#/case-viewer/" + this.params.data.poApplicationIdentifier + "/" + this.params.data.proceedingNumber + "/" + caseInfo.scrollToId: `${PtabTrialConstants.BASE_URL}/#` + "/case-viewer/" + this.params.data.poApplicationIdentifier + "/" + this.params.data.proceedingNumber + "/" + caseInfo.scrollToId;
        // } else if (this.params.data.proceedingMetadata) {
        //   newTabUrl += window.location.hostname === 'localhost' ? "/#/case-viewer/" + this.params.data.proceedingMetadata.poApplicationId + "/" + this.params.data.proceedingMetadata.proceedingNumber + "/" + caseInfo.scrollToId: `${PtabTrialConstants.BASE_URL}/#` + "/case-viewer/" + this.params.data.proceedingMetadata.poApplicationId + "/" + this.params.data.proceedingMetadata.proceedingNumber + "/" + caseInfo.scrollToId;
        // }
        newTabUrl += window.location.hostname === 'localhost' ? "/#/case-viewer/" + caseInfo.serialNo + "/" + caseInfo.proceedingNo + "/" + caseInfo.scrollToId: `${PtabTrialConstants.BASE_URL}/#` + "/case-viewer/" + caseInfo.serialNo + "/" + caseInfo.proceedingNo + "/" + caseInfo.scrollToId;
        window.open(newTabUrl);
      } else {
        // this.jpViewService.getDocuments(`${PtabTrialConstants.CASE_VIEWER_URL}/case-viewer/caseNumber-search?caseNumber=${caseInfo.proceedingNo}`).subscribe((caseInfoResponse) => {
        this.caseViewerService.caseSearch(caseInfo.proceedingNo).subscribe((caseInfoResponse) => {
          if (caseInfoResponse.serialNumber && caseInfoResponse.serialNumber[0]) {
            let caseInfoResp = {
              "serialNo": caseInfoResponse.serialNumber[0].trim(),
              "proceedingNo": caseInfoResponse.appealNumber[0],
              "scrollToId": 'documents'
            };

            this.store.dispatch(CaseViewerActions.setCaseInfoAction({ payload: caseInfoResp }));
            window.sessionStorage.setItem('caseInfo', JSON.stringify(caseInfoResp));
            let currentUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
            // this.caseNumberSearch = null;
            let newTabUrl = `${window.location.protocol}//${window.location.hostname}`;
            newTabUrl += window.location.port !== "" ? `:${window.location.port}` : "";
          newTabUrl += window.location.hostname === 'localhost' ? "/#/case-viewer/" + caseInfoResp.serialNo + "/" + caseInfoResp.proceedingNo + "/" + caseInfoResp.scrollToId: `${PtabTrialConstants.BASE_URL}/#` + "/case-viewer/" + caseInfoResp.serialNo + "/" + caseInfoResp.proceedingNo + "/" + caseInfoResp.scrollToId;
            window.open(newTabUrl);
          } else {
            this.commonUtils.setToastr("error", "No serial number found for this case.");
          }
        })
      }
    }, (caseInfoFailure) => {
      this.commonUtils.setToastr("error", `Case number ${this.proceedingNo} not found. Please check the number and try again.`);
    });



  }

}
