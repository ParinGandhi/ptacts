import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpenCaseviewerComponent } from './open-caseviewer.component';

xdescribe('OpenCaseviewerComponent', () => {
  let component: OpenCaseviewerComponent;
  let fixture: ComponentFixture<OpenCaseviewerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OpenCaseviewerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OpenCaseviewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
