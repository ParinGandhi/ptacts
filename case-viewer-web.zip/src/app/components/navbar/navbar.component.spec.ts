import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideMockStore, MockStore } from "@ngrx/store/testing";
import { NavbarComponent } from './navbar.component';
import { RouterTestingModule } from "@angular/router/testing";
import { Router } from "@angular/router";
import { Location } from "@angular/common";
import { JpViewService } from 'src/app/services/jpview.service';
import { of, BehaviorSubject, Observable } from 'rxjs';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import {
  routes
} from "../../app-routing.module"
import UserInfoModel from 'src/app/models/UserInfo.model';

// class MockJPViewService {

//   whoAmI(): Observable<any> {
//     let whoAmIResp = {
//       ptabLoginModalAccess: false
//     }

//     return of(whoAmIResp);
//   }
// }



const jpViewServiceMock = {
  whoAmI: new BehaviorSubject<any>('whoAmIResp').asObservable()
}



xdescribe('NavbarComponent', () => {
  let location: Location;
  let router: Router;
  let component: NavbarComponent;
  let fixture: ComponentFixture<NavbarComponent>;
  let store: MockStore;
  let jpViewService: JpViewService;
  const initialState = {
    userInfo: {
      activeIn: "",
    apjSeniorityRank: "",
    disiplanceCd: "",
    emailAddress: "",
    firstName: "",
    fullName: "",
    jobClassificationCode: "",
    lastName: "",
    leadApjIndicator: "",
    loginId: "",
    preferredFullName: "",
    privileges: [],
    roleDescription: "",
    trialJudgeIndicator: "",
    userIdentiifier: "",
    userWorkerNumber: "",
    isAdmin: ""
   }
  }


  const userInfo = { "loginId": "jbisk", "userWorkerNumber": "88548", "userIdentiifier": 5017, "firstName": "Jennifer", "lastName": "Bisk", "disiplanceCd": "Electrical", "fullName": "Bisk, Jennifer S.", "activeIn": "Active", "emailAddress": "Test_Jennifer.Bisk@USPTO.GOV", "roleDescription": "Judge", "jobClassificationCode": "APJ", "privileges": [], "preferredFullName": "Bisk, Jennifer S.", "apjSeniorityRank": 85, "isAdmin": false }

  const loggedInUserInfo = {
    caseDetailsData:
      [{
        activeIn: "Active",
        apjSeniorityRank: 85,
        disiplanceCd: "Electrical",
        emailAddress: "Test_Jennifer.Bisk@USPTO.GOV",
        firstName: "Jennifer",
        fullName: "Bisk, Jennifer S.",
        jobClassificationCode: "APJ",
        lastName: "Bisk",
        leadApjIndicator: "APJ1",
        loginId: "jbisk",
        preferredFullName: "Bisk, Jennifer S.",
        privileges: null,
        roleDescription: "Judge",
        trialJudgeIndicator: "Judge",
        userIdentiifier: 5017,
        userWorkerNumber: "88548",
        isAdmin: false
        }
      ]
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes(routes), HttpClientTestingModule],
      declarations: [NavbarComponent],
      providers: [provideMockStore({ initialState }), JpViewService]
    }).compileComponents()
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NavbarComponent);
    jpViewService = TestBed.inject(JpViewService);
    // router.initialNavigation();
    component = fixture.componentInstance;
    router = TestBed.inject(Router);
    location = TestBed.inject(Location);
    store = TestBed.inject(MockStore);
    fixture.detectChanges();
  });


  // it('should create', () => {
  //   let whoAmIResp = {
  //     ptabLoginModalAccess: false,
  //     userId: userInfo.loginId
  //   }
  //   spyOn(jpViewService, 'whoAmI').and.returnValue(of(whoAmIResp));
  //   spyOn(jpViewService, 'getUserInfo').and.returnValue(of(loggedInUserInfo));
  //   component.callWhoAmI();
  //   expect(component).toBeTruthy();

  // });


  // it('should create', () => {
  //   let whoAmIResp = {
  //     ptabLoginModalAccess: true
  //   }
  //   spyOn(jpViewService, 'whoAmI').and.returnValue(of(whoAmIResp));
  //   component.callWhoAmI();
  //   expect(component).toBeTruthy();
  // });


  // it('should call whoAmI with a logged in user', () => {
	// 	userInfo.
	// 	expect(component._jpViewService).toHaveBeenCalledTimes(1);
	// });


  // it('should call logout', () => {
  //   component.loggedInUser = "jbisk";
  //   component.logout();
  //   expect(component.loggedInUser).toBeFalsy();
  // })


  // it('should call caseSearch', () => {
  //   component.caseNumberSearch = "IPR2020-123456";
  //   let searchDetails = {
  //     serialNumber: [
  //       "012345678"
  //     ],
  //     appealNumber: [
  //       "IPR2020-123456"
  //     ]
  //   }
  //   spyOn(jpViewService, 'getDocuments').and.returnValue(of(searchDetails));
  //   component.caseSearch();
  //   expect(component._jpViewService.getDocuments).toHaveBeenCalledTimes(1);
  //   expect(component.caseNumberSearch).toBeFalsy();
  // })

});
