import { Component, OnInit } from '@angular/core';
import { NgbModal} from '@ng-bootstrap/ng-bootstrap';


import { Store, select } from '@ngrx/store';
import { ActivatedRoute, NavigationEnd, Router } from "@angular/router";
import { JpViewService } from "../../services/jpview.service";
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import * as CaseViewerActions from 'src/app/store/case-viewer/case-viewer.actions';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import { ToastrService } from "ngx-toastr";
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { getUserInfoAction } from 'src/app/store/case-viewer/case-viewer.actions';
import { CaseViewerService } from 'src/app/services/case-viewer.service';
import { SuccessGetUserInfoAction } from 'src/app/store/case-viewer/case-viewer.actions';
import UserInfoModel from 'src/app/models/UserInfo.model';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.less']
})
export class NavbarComponent implements OnInit {

  closeResult = null;
  loggedInUser = null;
  loggedInUser$ = this.store.pipe(select(CaseViewerSelectors.userInfoData));
  caseNumberSearch = null;
  // userInfo$ = this.store.pipe(select(userInfoData));
  _jpViewService: JpViewService;
  isSplAdmin: boolean = false;
  isPanelingMember: boolean = false;
  isJudge: boolean = false;
  workspace: boolean = false;
  scrollToId: string = null
  userName: string = null;
  caseInfoData: { serialNo: any; proceedingNo: any; };
  helpUrls: any;
  userManualUrl: any;
  showCaseViewerLink = false;
  trialsActiveTab = false
  appealUrls: any;
  sortedHelpUrls: any = [];
  prefix: any = 'fromJudgePortal';
  showLogin = false;


  constructor(
    private modal: NgbModal,
    private store: Store<CaseViewerState>,
    public router: Router,
    private jpViewService: JpViewService,
    private toastr: ToastrService,
    private activatedRoute: ActivatedRoute,
    private commonUtils: CommonUtilitiesService,
    private caseViewerService: CaseViewerService
  ) {
    this._jpViewService = jpViewService;
   }

  ngOnInit(): void {

    // console.log("Activate route: ", this.activatedRoute)
    let url = window.location.href;
    this.showCaseViewerLink = url.toLowerCase().includes('case-viewer');
    this.trialsActiveTab = url.toLowerCase().includes('aiatrialsworkspace');



    // this.scrollToId = this.activatedRoute.snapshot.params['scrollToId'];
    // this.store.pipe(select(CaseViewerSelectors.userInfoData)).subscribe(data => {
    //   this.loggedInUser = data.caseDetailsData[0];

    //   this.isSplAdmin = data.isSplAdmin;
    //   this.isJudge = data.isJudge;
    //   if (!this.loggedInUser) {
    //     this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
    //   }
    //   // if(this.loggedInUser.roleDescription  == 'Business Administrator' || this.loggedInUser.roleDescription == 'Supervisor' || this.loggedInUser.roleDescription == 'PTABE2E_Administrator'){
    //   //   this.isSplAdmin = true;
    //   // }
    //   if (this.loggedInUser && this.loggedInUser.roleDescription) {
    //     // this.isSplAdmin = PtabTrialConstants.ROLES.ADMIN_SPL.includes(this.loggedInUser.roleDescription);
    //     // this.isJudge = PtabTrialConstants.ROLES.JPVIEW.includes(this.loggedInUser.roleDescription);
    //   }
    //   this.isPanelingMember = this.commonUtils.checkIfPanelingMember(this.loggedInUser);
    // })
    // if(!this.loggedInUser){
    //   this.router.navigate(['login']);
    //   return;
    // }
    // this.userName = this.loggedInUser.loginId;
    // this.getUserInfo();
    // // if (!this.loggedInUser) {
    // //   this.callWhoAmI();
    // // }


    // this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
    // let caseInfo = JSON.parse(window.sessionStorage.getItem('caseInfo'));
    // this.getCaseData(caseInfo);
    // !this.loggedInUser?this.callWhoAmI():this.setRedirect(caseInfo);
    this.appealsUrl();
   this.getHelpUrls();
    this.loggedInUser = this.commonUtils.getFromSession();
    console.log(this.loggedInUser);
    if (this.loggedInUser && this.loggedInUser.caseDetailsData && this.loggedInUser.caseDetailsData.length > 0 && this.loggedInUser.caseDetailsData[0].loginId) {
      this.store.dispatch(SuccessGetUserInfoAction({ payload: this.loggedInUser }));
      // this.store.dispatch(getUserInfoAction({ url: this.loggedInUser.caseDetailsData[0].loginId }));
    } else if (this.loggedInUser && window.name.substr(0, this.prefix.length) == this.prefix) {
      this.setRedirect(window.sessionStorage.getItem('caseInfo'))
    } else {
      this.callWhoAmI();
    }
    // if (this.loggedInUser && this.loggedInUser.caseDetailsData && this.loggedInUser.caseDetailsData.length > 0 && this.loggedInUser.caseDetailsData[0].loginId) {
    //   this.store.dispatch(SuccessGetUserInfoAction({ payload: this.loggedInUser }));
    //   // this.store.dispatch(getUserInfoAction({ url: this.loggedInUser.caseDetailsData[0].loginId }));
    // } else if (this.loggedInUser && window.name.substr(0, this.prefix.length) == this.prefix) {
    //   this.setRedirect(window.sessionStorage.getItem('caseInfo'))
    // } else {
    //   this.callWhoAmI();
    // }

  }

  appealsUrl() {
    this.caseViewerService.getAppealsUrl().subscribe((response) => {
      this.appealUrls = response[0].descriptionText;

    });
  }
  getHelpUrls() {
    // this.caseViewerService.getHelpUrl('https://ptab-q121-trial-services-wildfly-0.sit.uspto.gov:8443/PTABCaseViewer/reference-data/code-reference-types?typeCode=HELP_LINKS').subscribe((response) => {
    this.caseViewerService.getHelpUrl().subscribe((response) => {
      this.helpUrls = response;
      this.sortedHelpUrls.push(this.helpUrls[2])
      this.sortedHelpUrls.push(this.helpUrls[0])
      this.sortedHelpUrls.push(this.helpUrls[1])

    });

  }

  getCaseData(caseInfo) {
    // this.jpViewService.getDocuments(`${PtabTrialConstants.CASE_VIEWER_URL}/case-viewer/caseNumber-search?caseNumber=${caseInfo.proceedingNo}`).subscribe((caseInfoResponse) => {
    this.caseViewerService.caseSearch(caseInfo.proceedingNo).subscribe((caseInfoResponse) => {

      this.caseInfoData = {
        "serialNo": caseInfoResponse.serialNumber[0],
        "proceedingNo": caseInfoResponse.appealNumber[0],
      }

    });
  }
  getUserInfo() {
    // let urlString = `${PtabTrialConstants.CASE_VIEWER_URL}${PtabTrialConstants.USER_INFO}${this.userName}`;
    // this.store.dispatch(getUserInfoAction({ url: urlString }));
    this.store.dispatch(getUserInfoAction({ url: this.userName }));
    // console.log(this.userInfo$)
    // this.jpViewService.getUserInfo(urlString).subscribe((userInfoResponse) => {
    this.caseViewerService.getUserInfo(this.userName).subscribe((userInfoResponse) => {
      // this.loginInfoEmitter.emit(userInfoResponse.caseDetailsData[0]);
      // window.sessionStorage.setItem('userInfo', JSON.stringify(userInfoResponse.caseDetailsData[0]));
      // this.router.navigate(['/case-viewer']);
    })
  }

  setRedirect(caseInfo) {
    let path =[];
    if (caseInfo && caseInfo.serialNo && caseInfo.proceedingNo && window.location.hash.indexOf('case-viewer') > -1) {
      // path=[`/case-viewer/${caseInfo.serialNo}/${caseInfo.proceedingNo}/documents`];
      path=[`/case-viewer/${caseInfo.serialNo}/${caseInfo.proceedingNo}/${caseInfo.scrollToId}`];
      this.workspace = false;
    }else if (!caseInfo.serialNo) {
          if (this.caseInfoData && this.caseInfoData.proceedingNo && this.caseInfoData.serialNo) {
            path=[`/case-viewer/${this.caseInfoData.serialNo}/${this.caseInfoData.proceedingNo}/${caseInfo.scrollToId}`];
          }else if(window.sessionStorage.getItem('caseInfo') && window.name.substr(0, this.prefix.length) == this.prefix && window.sessionStorage.getItem('path')) {
            path=[window.sessionStorage.getItem('path')]
          }
      } else if (window.location.hash.indexOf('aiaTrialsWorkspace') > -1){
        path=[`/aiaTrialsWorkspace/`+window.location.hash.split('/')[2]];
      } else if (window.sessionStorage.getItem('path')){
        path=[window.sessionStorage.getItem('path')];
        this.workspace = true;
    }
      window.localStorage.setItem('localPath',path[0]);
      window.localStorage.getItem('localPath') !=""?this.router.navigate([window.localStorage.getItem('localPath')]):this.router.navigate(path);
  }

  callWhoAmI() {
    // this.jpViewService.whoAmI().subscribe(whoAmIResp => {
    this.caseViewerService.whoAmI().subscribe(whoAmIResp => {
      console.log(whoAmIResp);
      // whoAmIResp = {
      //   "workerNumber": null,
      //   "firstName": "Arjun",
      //   "lastName": "Nannuru",
      //   "ptabLoginModalAccess": false,
      //   "ptabDefaultRefreshTime": 300000,
      //   "ptabRole": null,
      //   "ptabReadOnlyUser": false,
      //   "patronIdentifier": null,
      //   "middleName": null,
      //   "userId": "bahlstrom",
      //   "ptabModifiers": null,
      //   "employeeNumber": 150556
      // };
      if (!whoAmIResp.userId.trim()) {
        if (environment.showLogin) {
          this.showLogin = environment.showLogin;
          this.router.navigate(['/login']);
          window.localStorage.setItem('localPath','/login');
        } else {
          this.commonUtils.setToastr('error', 'Single sign on failed. Please try again later');
        }
        // this.router.navigate(['/login']);
        // window.localStorage.setItem('localPath','/login');

      } else {
        // let urlString = `${PtabTrialConstants.CASE_VIEWER_URL}${PtabTrialConstants.USER_INFO}${whoAmIResp.userId}`;
        // this.jpViewService.getUserInfo(urlString).subscribe((userInfoResponse) => {
        this.caseViewerService.getUserInfo(whoAmIResp.userId).subscribe((userInfoResponse) => {
          window.sessionStorage.setItem('userInfo', JSON.stringify(userInfoResponse.caseDetailsData[0]));
          // this.router.navigate(['/case-viewer']);
          this.router.navigate(['/aiaTrialsWorkspace/aiaSearch']);
          window.localStorage.setItem('localPath','/aiaTrialsWorkspace/aiaSearch');
        })
        this.store.dispatch(getUserInfoAction({ url: whoAmIResp.userId }));
      }
    })
  }

  logout() {
    window.sessionStorage.removeItem('userInfo');
    window.sessionStorage.removeItem('caseInfo');
    window.sessionStorage.removeItem('up');
    let initialState: UserInfoModel = {
        "userPermissionDetailsList": [],
      "caseDetailsData": [{
        "leadApjIndicator": null,
        "preferredFullName": null,
        "trialJudgeIndicator": null,
        "isAdmin": null,
          "userIdentiifier":  null,
          "activeIn":  null,
          "lastName":  null,
          "privileges": [],
          "loginId":  null,
          "fullName":  null,
          "disiplanceCd":  null,
          "jobClassificationCode":  null,
          "firstName":  null,
          "emailAddress":  null,
          "userWorkerNumber":  null,
          "roleDescription":  null,
          "apjSeniorityRank":  null,
      }],
      "isSplAdmin": null,
    "isJudge": null,
    "isPanelingMember": null,
    "isPl": null,
        "permissions": {}
    }
    this.store.dispatch(SuccessGetUserInfoAction({ payload: initialState }));
    this.loggedInUser = null;
    this.isSplAdmin = false;
    this.isJudge = false;
    this.router.navigate(['/login']);
  }

  redirectToWorspace () {
    let newUrl = `${window.location.protocol}//${window.location.hostname}`;
    newUrl += window.location.port !== "" ? `:${window.location.port}` : "";
    newUrl += window.location.hostname === 'localhost' ? "/#/aiaTrialsWorkspace/aiaSearch" : `${PtabTrialConstants.BASE_URL}/#/aiaTrialsWorkspace/aiaSearch`;
    window.sessionStorage.setItem('path', '/aiaTrialsWorkspace/aiaSearch');
    window.open(newUrl);
  }

  redirectToAppeals () {
    // let newUrl = `${window.location.protocol}//${window.location.hostname}`;
    // newUrl += window.location.port !== "" ? `:${window.location.port}` : "";
    // newUrl += window.location.hostname === 'localhost' ? "/PTABAppeals" : this.appealUrls;
    window.sessionStorage.setItem('path', this.appealUrls);
    window.open(this.appealUrls);
  }
  redirectToJPView() {
    let newUrl = `${window.location.protocol}//${window.location.hostname}`;
    newUrl += window.location.port !== "" ? `:${window.location.port}` : "";
    newUrl += window.location.hostname === 'localhost' ? "/#/judge-portal" : `${PtabTrialConstants.DOCKET_VIEWER}/#/judge-portal`;
    window.sessionStorage.setItem('path', '/judge-portal');
    window.open(newUrl);
  }

  caseSearch() {
    // http://localhost:8080/case-viewer/caseNumber-search?caseNumber=IPR2019-01581�
    // let url = `/case-information/caseNumber-search?caseNumber=${this.caseNumberSearch}`
    let isTrials = this.caseNumberSearch.match(/[a-z]/i) ? true : false;
    if (!this.caseNumberSearch.includes("-") && isTrials) {
      this.toastr.error(`Case number format is incorrect. Please check the number and try again.`, "", {
        closeButton: true
      } );
    } else {
    // let url = isTrials ? `${PtabTrialConstants.CASE_VIEWER_URL}/case-viewer/caseNumber-search?caseNumber=${this.caseNumberSearch}` : `${PtabTrialConstants.CASE_VIEWER_URL}/case-information/caseNumber-search?caseNumber=${this.caseNumberSearch}`;
      if (isTrials) {
        // this.jpViewService.getDocuments(url).subscribe((searchDetails) => {
        // this.jpViewService.getDocuments(`${PtabTrialConstants.CASE_VIEWER_URL}/case-viewer/caseNumber-search?caseNumber=${this.caseNumberSearch}`).subscribe((searchDetails) => {
        this.caseViewerService.caseSearch(this.caseNumberSearch).subscribe((searchDetails) => {
          console.log(searchDetails);
          this.workspace = false;
          let caseInfo = {
            "serialNo": searchDetails.serialNumber[0].trim(),
            "proceedingNo": searchDetails.appealNumber[0],
            "scrollToId": 'documents'
          }
          // this.store.dispatch(CaseViewerActions.setCaseInfoAction({ payload: caseInfo }));
          let tempCaseInfo = JSON.parse(window.sessionStorage.getItem('caseInfo'));
          window.sessionStorage.setItem('caseInfo', JSON.stringify(caseInfo));
          let currentUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
          this.caseNumberSearch = null;
          let newTabUrl = `${window.location.protocol}//${window.location.hostname}`;
          newTabUrl += window.location.port !== "" ? `:${window.location.port}` : "";
          newTabUrl += window.location.hostname === 'localhost' ? `/#/case-viewer/${caseInfo.serialNo}/${caseInfo.proceedingNo}/documents` :
           `${PtabTrialConstants.BASE_URL}/#` +`/case-viewer/${caseInfo.serialNo}/${caseInfo.proceedingNo}/documents`;

          let prefix = "fromJudgePortal"
            window.open(newTabUrl, prefix + JSON.stringify({
                    "caseInfo": caseInfo,
                    "currentUser": currentUser
            }));
            window.sessionStorage.setItem('caseInfo', JSON.stringify(tempCaseInfo));
        }, (caseSearchError) => {
          console.log('caseSearchError: ', caseSearchError);
          this.toastr.error(`Case number ${this.caseNumberSearch} not found. Please check the number and try again.`, "", {
            closeButton: true
          } );
        })
      } else {
        // this.jpViewService.getAppealsCaseData(`${PtabTrialConstants.APPEALS_BASE_URL}/case-information/caseNumber-search?caseNumber=${this.caseNumberSearch}`).subscribe((appealsCaseData) => {
        //   console.log('appealsCaseData: ', appealsCaseData);
        //   let caseInfo = {
        //     "serialNo": appealsCaseData.serialNumber[0],
        //     "proceedingNo": appealsCaseData.appealNumber[0],
        //     "scrollToId": 'documents'
        //   }
        //   // this.store.dispatch(CaseViewerActions.setCaseInfoAction({ payload: caseInfo }));
        //   let tempCaseInfo = JSON.parse(window.sessionStorage.getItem('caseInfo'));
        //   window.sessionStorage.setItem('caseInfo', JSON.stringify(caseInfo));
        //   let currentUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
        //   this.caseNumberSearch = null;
        //   let newTabUrl = `${window.location.protocol}//${window.location.hostname}`;
        //   newTabUrl += window.location.port !== "" ? `:${window.location.port}` : "";
        //   newTabUrl += window.location.hostname === 'localhost' ? "/#/case-viewer/" : `${PtabTrialConstants.BASE_URL}/#/case-viewer/`;
        //   newTabUrl += `${caseInfo.serialNo}/${caseInfo.proceedingNo}/documents`;

        //   let prefix = "fromJudgePortal"
        //     window.open(newTabUrl, prefix + JSON.stringify({
        //             "caseInfo": caseInfo,
        //             "currentUser": currentUser
        //     }));
        //     window.sessionStorage.setItem('caseInfo', JSON.stringify(tempCaseInfo));
        // }, (caseSearchError) => {
        //   console.log('caseSearchError: ', caseSearchError);
        //   this.toastr.error(`Case number ${this.caseNumberSearch} not found. Please check the number and try again.`, "", {
        //     closeButton: true
        //   } );
        // })
        this.toastr.error(`Case number ${this.caseNumberSearch} not found. Please check the number and try again.`, "", {
          closeButton: true
        } );
    }
  }
      // let newTabUrl = this.getCaseViewerUrl()
      // this.jpViewService.getReferenceData(PtabTrialConstants.REFERENCE_DATA + PtabTrialConstants.CASE_VIEWER_URL).subscribe((urlResponse) => {
      //   console.log(urlResponse);
      //   let prefix = "fromJudgePortal"
      //   window.open(urlResponse[0].descriptionText, prefix + JSON.stringify({
      //           "caseInfo": caseInfo,
      //           "currentUser": currentUser
      //         }));
      // });

      // this.router.navigateByUrl('/', {skipLocationChange: true}).then(() => this.router.navigate(['/case-viewer']));
      // let routeToNavigate: any = "/case-viewer/" + caseInfo.serialNo + "/" + caseInfo.proceedingNo + "/documents";
      // this.router.navigate(routeToNavigate);
      // window.open("http://localhost:4201/case-viewer/" + caseInfo.serialNo + "/" + caseInfo.proceedingNo + "/documents", "_self");
      // window.open("http://localhost:4201/case-viewer/" + caseInfo.serialNo + "/" + caseInfo.proceedingNo + "/documents");


      // let prefix = "fromJudgePortal"
      // window.open('http://localhost:4201', prefix + JSON.stringify({
      //         "caseInfo": caseInfo,
      //         "currentUser": currentUser
      //       }));


  };






}
