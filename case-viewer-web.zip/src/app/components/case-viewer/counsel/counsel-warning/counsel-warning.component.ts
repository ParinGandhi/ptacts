import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-counsel-warning',
  templateUrl: './counsel-warning.component.html',
  styleUrls: ['./counsel-warning.component.less']
})
export class CounselWarningComponent implements OnInit {

  modal: any
  selectedCounsel: any;
  selectedCounselString: string;
  showSelection: boolean = false;
  emailList: Array<any> = [];

  constructor(public bsModalRef: BsModalRef) { }

  ngOnInit(): void {
    console.log(this.modal);
  }
/* istanbul ignore next */ 
  close(value) {
    this.modal.isConfirm = value;
    this.bsModalRef.hide()
  }

/* istanbul ignore next */ 
  useSelectedEmail() {
    // this.modal.selectedCounselInfo = JSON.parse(JSON.stringify(this.modal.allCounselInfo));
    // this.modal.selectedCounselInfo.parties = [];
    // this.modal.selectedCounselInfo.parties.push(this.modal.allCounselInfo[this.selectedCounsel.index]);
    // this.modal.selectedCounselInfo = this.selectedCounsel.index;
    this.close(true);
  }

}
