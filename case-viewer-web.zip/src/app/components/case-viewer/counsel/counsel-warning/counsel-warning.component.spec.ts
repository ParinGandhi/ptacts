import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { CounselWarningComponent } from './counsel-warning.component';


/**
 * 66.67%
 */
describe('CounselWarningComponent', () => {
  let component: CounselWarningComponent;
  let modalService: BsModalService;
  let modal;
  let fixture: ComponentFixture<CounselWarningComponent>;

  let modalMock = {
    title: "Testing",
    partyType: "Party",
    exists: "true"
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CounselWarningComponent],
      providers: [
        BsModalService,
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useValue: {}
        }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CounselWarningComponent);
    modalService = TestBed.inject(BsModalService);
    component = fixture.componentInstance;
    component.modal = modalMock;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.modal.title = "Testing";
    component.modal.partyType = "PartyType";
    component.modal.exists = "True";
    expect(component).toBeTruthy();
  });


  // it('should call useSelectedEmail', () => {
  //   spyOn(component.bsModalRef,'hide').and.callThrough();
  //   component.useSelectedEmail();
  //   expect(component.close).toHaveBeenCalled();
  // });
});
