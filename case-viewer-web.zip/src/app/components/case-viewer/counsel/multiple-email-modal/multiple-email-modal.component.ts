import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-multiple-email-modal',
  templateUrl: './multiple-email-modal.component.html',
  styleUrls: ['./multiple-email-modal.component.less']
})
export class MultipleEmailModalComponent implements OnInit {

  modal: any
  selectedCounsel: any;
  selectedCounselString: string;
  showSelection: boolean = false;
  emailList: Array<any> = [];

  constructor(public bsModalRef: BsModalRef) { }

  ngOnInit(): void {
    console.log(this.modal);
    this.generateListForDisplay();
  }


  generateListForDisplay() {
    for (let i = 0; i < this.modal.allCounselInfo.length; i++) {
      let emailRecord = {
        email: this.modal.allCounselInfo[i].personType[0].electronicAddress[0].email,
        index: i
      }
      this.emailList.push(emailRecord);
    }
  }
/* istanbul ignore next */ 
  close(value) {
    this.modal.isConfirm = value;
    this.bsModalRef.hide()
  }

/* istanbul ignore next */ 
  useSelectedEmail() {
    // this.modal.selectedCounselInfo = JSON.parse(JSON.stringify(this.modal.allCounselInfo));
    // this.modal.selectedCounselInfo.parties = [];
    // this.modal.selectedCounselInfo.parties.push(this.modal.allCounselInfo[this.selectedCounsel.index]);
    this.modal.selectedCounselInfo = this.selectedCounsel.index;
    this.close(true);
  }

}
