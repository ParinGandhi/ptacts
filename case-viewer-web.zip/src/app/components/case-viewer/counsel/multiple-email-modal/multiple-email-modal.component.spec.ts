import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { MultipleEmailModalComponent } from './multiple-email-modal.component';

/**
 * 73.33%
 */
describe('MultipleEmailModalComponent', () => {
  let component: MultipleEmailModalComponent;
  let modalService: BsModalService;
  let fixture: ComponentFixture<MultipleEmailModalComponent>;

  const modalMock = {
    title: "Testing",
    regNo: "00000",
    allCounselInfo: [
      {
        personType: [
          {
            electronicAddress: [
              {
                email: "someone@somewhere.com"
              }
            ]
          }
        ]
      }
    ]
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MultipleEmailModalComponent],
      providers: [
        BsModalService,
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useValue: {}
        }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MultipleEmailModalComponent);
    modalService = TestBed.inject(BsModalService);
    component = fixture.componentInstance;
    component.modal = modalMock;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
