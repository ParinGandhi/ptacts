import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap } from '@angular/router';
import { JpViewService } from 'src/app/services/jpview.service';
import { CounselComponent } from './counsel.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Observable, of } from 'rxjs';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { provideMockStore } from '@ngrx/store/testing';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { TrialsService } from 'src/app/services/trials.service';
// import * as counselResp from 'src/assets/test_data/counselRealPartyResponse.json';
import { UpdatePartiesModalComponent } from '../../common/update-parties-modal/update-parties-modal.component';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { EventEmitter } from '@angular/core';


/**
 * 88.89%
 */
describe('CounselComponent', () => {
  let component: CounselComponent;
  let fixture: ComponentFixture<CounselComponent>;
  let trialsService: TrialsService;
  let activatedRoute: ActivatedRoute;
  let modalService: BsModalService;
  let updateCounselModelRef: BsModalRef;

  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "123456789",
        caseNumber: "IPR2020-123456"
      }
    }
  };

  const counselResp = {
    "poCounsel": {
      "parties": [
        {
          "identifier": "15892294",
          "submitterType": "PATENTOWNER",
          "orgType": [],
          "partySubTypeDescription": "Lead Counsel",
          "registrationNo": "74621",
          "partySubType": "LEAD",
          "partyType": "COUNSEL",
          "personType": [
            {
              "identifier": "15894448",
              "firstName": "Philip",
              "lastName": "Wang",
              "electronicAddress": [
                {
                  "identifier": "12940766",
                  "telephoneNumber": "3108267474",
                  "teleCommAddresType": "W"
                },
                {
                  "identifier": "12940767",
                  "telephoneNumber": "3108266991",
                  "teleCommAddresType": "F"
                },
                {
                  "identifier": "10358758",
                  "emailType": "WE",
                  "email": "test4_pwang@raklaw.com"
                }
              ],
              "mailingAddress": [
                {
                  "identifier": "12177580",
                  "zipCode": "90025",
                  "country": "US",
                  "streetLineTwoText": "12th Fl.",
                  "streetLineOneText": "12424 Wilshire Blvd.",
                  "city": "Los Angeles",
                  "addressType": "BUS",
                  "state": "CA"
                }
              ]
            }
          ],
          "rankNo": 1
        },
        {
          "identifier": "15892295",
          "submitterType": "PATENTOWNER",
          "orgType": [],
          "partySubTypeDescription": "First Back Up Counsel",
          "registrationNo": "71007",
          "partySubType": "FIRSTBKUP",
          "partyType": "COUNSEL",
          "personType": [
            {
              "identifier": "15894449",
              "firstName": "C. Jay",
              "lastName": "Chung",
              "electronicAddress": [
                {
                  "identifier": "12940768",
                  "telephoneNumber": "3108267474",
                  "teleCommAddresType": "W"
                },
                {
                  "identifier": "12940769",
                  "telephoneNumber": "3108266991",
                  "teleCommAddresType": "F"
                },
                {
                  "identifier": "10358759",
                  "emailType": "WE",
                  "email": "test4_jchung@raklaw.com"
                }
              ],
              "mailingAddress": [
                {
                  "identifier": "12177581",
                  "zipCode": "90025",
                  "country": "US",
                  "streetLineTwoText": "12th Fl.",
                  "streetLineOneText": "12424 Wilshire Blvd.",
                  "city": "Los Angeles",
                  "addressType": "BUS",
                  "state": "CA"
                }
              ]
            }
          ],
          "rankNo": 2
        }
      ],
      "caseNo": "IPR2021-00409"
    },
    "ptabReadOnlyUser": true,
    "poRealParty": {
      "parties": [
        {
          "identifier": "15892293",
          "submitterType": "PATENTOWNER",
          "orgType": [
            {
              "identifier": "15894447",
              "electronicAddress": [
                {
                  "identifier": "10358757",
                  "emailType": "WE",
                  "email": "test4_ecofactor@raklaw.com"
                }
              ],
              "legalname": "EcoFactor, Inc.",
              "orgAddress": []
            }
          ],
          "partyType": "REAL PARTY",
          "personType": [],
          "rankNo": 1
        }
      ],
      "caseNo": "IPR2021-00409"
    },
    "petitionRealParty": {
      "parties": [
        {
          "identifier": "15890795",
          "submitterType": "PETITIONER",
          "orgType": [
            {
              "identifier": "15892969",
              "electronicAddress": [
                {
                  "identifier": "12939494",
                  "telephoneNumber": "2026696207",
                  "teleCommAddresType": "W"
                },
                {
                  "identifier": "10357648",
                  "emailType": "WE",
                  "email": "test4_smith@smithbaluch.com"
                }
              ],
              "legalname": "Google LLC",
              "orgAddress": [
                {
                  "identifier": "12175887",
                  "zipCode": "94043",
                  "country": "US",
                  "streetLineOneText": "1600 Ampitheatre Pkwy",
                  "city": "Mountain View",
                  "addressType": "RES",
                  "state": "CA"
                }
              ]
            }
          ],
          "partyType": "REAL PARTY",
          "personType": [],
          "rankNo": 1
        }
      ],
      "caseNo": "IPR2021-00409"
    },
    "petitionCounsel": {
      "parties": [
        {
          "identifier": "15890814",
          "submitterType": "PETITIONER",
          "orgType": [],
          "partySubTypeDescription": "First Back Up Counsel",
          "registrationNo": "70484",
          "partySubType": "FIRSTBKUP",
          "partyType": "COUNSEL",
          "personType": [
            {
              "identifier": "15892988",
              "firstName": "Elizabeth",
              "lastName": "Laughton",
              "electronicAddress": [
                {
                  "identifier": "12939514",
                  "telephoneNumber": "7035858839",
                  "teleCommAddresType": "W"
                },
                {
                  "identifier": "10357668",
                  "emailType": "WE",
                  "email": "test4_laughton@smithbaluch.com"
                }
              ],
              "mailingAddress": [
                {
                  "identifier": "12175907",
                  "zipCode": "94025",
                  "country": "US",
                  "streetLineOneText": "1100 Alma St., Ste. 109",
                  "city": "Menlo Park",
                  "addressType": "BUS",
                  "state": "CA"
                }
              ]
            }
          ],
          "rankNo": 2
        },
        {
          "identifier": "15890796",
          "submitterType": "PETITIONER",
          "orgType": [],
          "partySubTypeDescription": "Lead Counsel",
          "registrationNo": "49003",
          "partySubType": "LEAD",
          "partyType": "COUNSEL",
          "personType": [
            {
              "identifier": "15892970",
              "firstName": "MATTHEW",
              "lastName": "SMITH",
              "electronicAddress": [
                {
                  "identifier": "12939495",
                  "telephoneNumber": "20206696027",
                  "teleCommAddresType": "W"
                },
                {
                  "identifier": "10357649",
                  "emailType": "WE",
                  "email": "test4_smith@smithbaluch.com"
                }
              ],
              "mailingAddress": [
                {
                  "identifier": "12175888",
                  "zipCode": "94025",
                  "country": "US",
                  "streetLineOneText": "1100 Alma St., Ste. 109",
                  "city": "Menlo Park",
                  "addressType": "BUS",
                  "state": "CA"
                }
              ]
            }
          ],
          "rankNo": 1
        }
      ],
      "caseNo": "IPR2021-00409"
    }
  };

  const initialState = {
    modal: {
      title: `Update`,
      interestedParty: 'counsel',
      partyType: 'petitioner',
      closeBtnName: "Done",
      isConfirm: false,
      counselInfo: null,
     // caseInfo: this.CaseInfoModel,
      modalType: 'counsel',
      completeCounsel: null
    }
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [CounselComponent],
      providers: [
        TrialsService, provideMockStore({
          selectors: [
            { selector: CaseViewerSelectors.caseInfoData, value: { proceedingNo: '37553565' } },
            {selector: CaseViewerSelectors.userInfoData,value:{caseDetailsData: []}}
          ]
        }),
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        },
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useValue: {}
        }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CounselComponent);
    trialsService = TestBed.inject(TrialsService);
    modalService = TestBed.inject(BsModalService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getCounseInfo and get successResponse', () => {
    spyOn(trialsService, 'getCounselInfo').and.returnValue(of(counselResp));
    component.getCounselInfo();
    expect(component.counselInfo).toEqual(counselResp)
  });

  it('should show modal and update', () => {
    let interestedParty = 'counsel';
    let partyType ='petitioner';
    const emitter = new EventEmitter();
    emitter.emit(true);

    modalService.show = (): BsModalRef => {
      return ({ id: null, hide: null, setClass: null, onHide: emitter, onHidden: null });
    };
    spyOn(component, "updateCounsel").and.callThrough();
    component.updateCounsel(interestedParty, partyType);
    expect(component.updateCounsel).toHaveBeenCalled();
  });

});
