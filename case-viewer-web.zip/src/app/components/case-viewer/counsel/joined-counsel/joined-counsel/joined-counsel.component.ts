import { Component, Input, OnInit } from '@angular/core';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { TrialsService } from 'src/app/services/trials.service';

@Component({
  selector: 'app-joined-counsel',
  templateUrl: './joined-counsel.component.html',
  styleUrls: ['./joined-counsel.component.less']
})
export class JoinedCounselComponent implements OnInit {

  @Input() joinedProceedingNo: string;

  petitionerCounselInfo: any;
  counselInfo: any;

  constructor(
    private trialsService: TrialsService,
    private commonUtils: CommonUtilitiesService,
  ) { }

  ngOnInit(): void {
    this.getCounselInfo();
  }

  getCounselInfo() {
    // this.jpViewService.getCounselInfo(`${PtabTrialConstants.TRIAL_SERVICES_URL}/proceeding-party-details?proceedingNumber=${this.caseInfo.proceedingNo}`).subscribe((counselInfoResponse) => {
    // this.jpViewService.getCounselInfo(`/proceeding-party-details?proceedingNumber=${this.caseInfo.proceedingNo}`).subscribe((counselInfoResponse) => {
    this.trialsService.getCounselInfo(`${this.joinedProceedingNo}`).subscribe((counselInfoResponse) => {
      if (counselInfoResponse.petitionCounsel) {
        counselInfoResponse.petitionCounsel.parties.sort(this.sortCounselType);
      }
      // if (counselInfoResponse.poCounsel) {
      //   counselInfoResponse.poCounsel.parties.sort(this.sortCounselType);
      // }
      // counselInfoResponse.poCounsel.parties[1].registrationNo = null;
      this.counselInfo = counselInfoResponse;
      this.petitionerCounselInfo = counselInfoResponse.petitionCounsel ? counselInfoResponse.petitionCounsel.parties : [];
    });
  }


  sortCounselType(a, b) {
    const rankA = a.rankNo;
    const rankB = b.rankNo;

    let comparison = 0;
    if (rankA > rankB) {
      comparison = 1;
    } else if (rankA < rankB) {
      comparison = -1;
    }
    return comparison;
  }


  openInCaseViewer(proceedingNo) {
    this.commonUtils.openInCaseViewer(proceedingNo);
  }


  copyEmailsToClipboard(counselType) {
    // console.log(this.counselInfo[counselType].parties);
    let emails = [];
    if (this.counselInfo[counselType] && this.counselInfo[counselType].parties.length > 0) {
      this.counselInfo[counselType].parties.forEach((party) => {
        party.personType[0].electronicAddress.forEach((electronicAddress) => {
          if (electronicAddress.hasOwnProperty('email')) {
            emails.push(electronicAddress.email);
          }
        });
      });
    }
    this.commonUtils.copyToClipboard(emails.join(", "), counselType);
  }

}
