import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { JpViewService } from 'src/app/services/jpview.service';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
// import { UpdatePartiesModalComponent } from '../../common/update-parties-modal/update-parties-modal.component';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import { UpdatePartiesModalComponent } from '../../common/update-parties-modal/update-parties-modal.component';
import { TrialsService } from 'src/app/services/trials.service';
import { Store, select } from '@ngrx/store';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';

@Component({
  selector: 'app-counsel',
  templateUrl: './counsel.component.html',
  styleUrls: ['./counsel.component.less']
})
export class CounselComponent implements OnInit {

  @Input() counselProceedingNos;

  counselInfo = null;
  petitionerCounselInfo: Array<any>;
  caseInfo: CaseInfoModel = {
    serialNo: null,
    proceedingNo: null
  };
  updateCounselModelRef: BsModalRef;
  loggedInUser$ = this.store.pipe(select(CaseViewerSelectors.userInfoData));
  lastRefresh = new Date();

  constructor(
    private jpViewService: JpViewService,
    private trialsService: TrialsService,
    public activatedRoute: ActivatedRoute,
    private modalService: BsModalService,
    private store: Store,
    private commonUtils: CommonUtilitiesService
  ) { }

  ngOnInit(): void {
    // this.activatedRoute.params.subscribe((params) => {
    //   console.log('params: ', params);
    //   this.caseInfo = {
    //     serialNo: params.applicationNumber,
    //     proceedingNo: params.caseNumber
    //   }
    // });
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };
    this.getCounselInfo();
    // setInterval(()=>{
    //   this.refresh();
    // },300000)
  }

  refresh(){
    this.getCounselInfo();
    this.lastRefresh = new Date();
  }

  getCounselInfo() {
    // this.jpViewService.getCounselInfo(`${PtabTrialConstants.TRIAL_SERVICES_URL}/proceeding-party-details?proceedingNumber=${this.caseInfo.proceedingNo}`).subscribe((counselInfoResponse) => {
    // this.jpViewService.getCounselInfo(`/proceeding-party-details?proceedingNumber=${this.caseInfo.proceedingNo}`).subscribe((counselInfoResponse) => {
    this.trialsService.getCounselInfo(`${this.caseInfo.proceedingNo}`).subscribe((counselInfoResponse) => {
      if (counselInfoResponse.petitionCounsel) {
        counselInfoResponse.petitionCounsel.parties.sort(this.sortCounselType);
      }
      if (counselInfoResponse.poCounsel) {
        counselInfoResponse.poCounsel.parties.sort(this.sortCounselType);
      }
      // counselInfoResponse.poCounsel.parties[1].registrationNo = null;
      this.counselInfo = counselInfoResponse;
      this.petitionerCounselInfo = counselInfoResponse.petitionCounsel ? counselInfoResponse.petitionCounsel.parties : [];
    });
  }

  sortCounselType(a, b) {
    const rankA = a.rankNo;
    const rankB = b.rankNo;

    let comparison = 0;
    if (rankA > rankB) {
      comparison = 1;
    } else if (rankA < rankB) {
      comparison = -1;
    }
    return comparison;
  }

/* istanbul ignore next */
  updateCounsel(interestedParty, partyType) {
    let counselInfo = null;
    let completeCounsel = this.counselInfo;
    if (partyType === 'petitioner') {
      counselInfo = this.counselInfo ? this.counselInfo.petitionCounsel : null;
    } else {
      counselInfo = this.counselInfo ? this.counselInfo.poCounsel : null;
    }
    // counselInfo.parties[1].registrationNo = null
    const initialState = {
      modal: {
        title: `Update`,
        interestedParty: interestedParty,
        partyType: partyType,
        closeBtnName: "Done",
        isConfirm: false,
        counselInfo: counselInfo,
        caseInfo: this.caseInfo,
        modalType: 'counsel',
        completeCounsel: completeCounsel
      }
    };
    this.updateCounselModelRef = this.modalService.show(UpdatePartiesModalComponent, {
      animated: true,
      backdrop: true,
      ignoreBackdropClick: true,
      class: 'add-update-parties-modal-content',
      initialState
    });
    this.updateCounselModelRef.onHide.subscribe((reason: string | any) => {
      console.log('reason: ', reason);
      this.getCounselInfo();
      if (reason.initialState.modal.isConfirm) {
        // this.pushToList();
      }
    })
  }


  copyEmailsToClipboard(counselType) {
    // console.log(this.counselInfo[counselType].parties);
    let emails = [];
    if (this.counselInfo[counselType] && this.counselInfo[counselType].parties.length > 0) {
      this.counselInfo[counselType].parties.forEach((party) => {
        party.personType[0].electronicAddress.forEach((electronicAddress) => {
          if (electronicAddress.hasOwnProperty('email')) {
            emails.push(electronicAddress.email);
          }
        });
      });
    }
    this.commonUtils.copyToClipboard(emails.join(", "), counselType);
  }

}
