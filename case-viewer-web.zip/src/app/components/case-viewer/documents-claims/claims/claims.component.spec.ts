import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { MockStore,provideMockStore } from '@ngrx/store/testing';
import { of } from 'rxjs/internal/observable/of';
import { JpViewService } from 'src/app/services/jpview.service';
import * as claimsResponse from 'src/assets/test_data/claims.json';
import { ClaimsComponent } from './claims.component';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ClaimsUploadComponent } from '../claims-upload/claims-upload.component';
import { EventEmitter } from '@angular/core';
import { TrialsService } from 'src/app/services/trials.service';

/**
 * 71.64%
 */
describe('ClaimsComponent', () => {
  let component: ClaimsComponent;
  let fixture: ComponentFixture<ClaimsComponent>;
  let jpViewService: JpViewService;
  let trialsService: TrialsService;
  let activatedRoute: ActivatedRoute;
  let modalService: BsModalService;
  let store$: MockStore;
  let tempData = [];
  const claimMetaData =[{"reasonText":"Clarot, et.al., U.S. Patent No. 9,034,401 - Claim 1","statutoryGndSummary":{"identifier":1,"code":"35USC102","descriptionText":"35 USC § 102"},"challengedGroupClaimList":"7","claimIdentifier":1887619},{"reasonText":"Clarot, et.al., U.S. Patent Application Publication No. 2004/0166066\n(Exhibit 2019)","statutoryGndSummary":{"identifier":2,"code":"35USC103","descriptionText":"35 USC § 103"},"challengedGroupClaimList":"1-7","claimIdentifier":1887604},{"reasonText":"Weiser, M1, et.al., \"A randomized equivalence trial comparing the efficacy and safety of Luffa comp.-Heel nasal spray with cromolyn sodium spray in the treatment of seasonal allergic rhinitis,\" Forsch Komplementamed, 1999 Jun;9(3): 142-8 (Exhibit 2008)","statutoryGndSummary":{"identifier":2,"code":"35USC103","descriptionText":"35 USC § 103"},"challengedGroupClaimList":"1-7","claimIdentifier":1887609},{"reasonText":"Clymer, et.al., U.S. Patent Application Publication No. 2007/0110676 (Exhibit 2013)","statutoryGndSummary":{"identifier":2,"code":"35USC103","descriptionText":"35 USC § 103"},"challengedGroupClaimList":"1-7","claimIdentifier":1887614},{"reasonText":"Clarot, et.al., U.S. Patent Application Publication No. 2004/0219107\n(Exhibit 2020)","statutoryGndSummary":{"identifier":2,"code":"35USC103","descriptionText":"35 USC § 103"},"challengedGroupClaimList":"1-7","claimIdentifier":1887605},{"reasonText":"Davis, et.al., Abstract, \"Safety of an Alkalinizing Buffer Designed for Inhaled Medications in Humans,\" Respiratory Care July 2013, 58(7) 1226-1232\n(Exhibit 2016)","statutoryGndSummary":{"identifier":2,"code":"35USC103","descriptionText":"35 USC § 103"},"challengedGroupClaimList":"1,7","claimIdentifier":1887602},{"reasonText":"Clarke, J.H., \"Sabadilla,\" Materia Media, 1902 (Exhibit 2010)","statutoryGndSummary":{"identifier":2,"code":"35USC103","descriptionText":"35 USC § 103"},"challengedGroupClaimList":"1-7","claimIdentifier":1887612},{"reasonText":"Liu, U.S. Patent Application Publication No. 2013/0216574\n(Exhibit 2011)","statutoryGndSummary":{"identifier":2,"code":"35USC103","descriptionText":"35 USC § 103"},"challengedGroupClaimList":"1-7","claimIdentifier":1887613},{"reasonText":"Clarot, et.al., U.S. Patent Application Publication No. 2003/0059440\n(Exhibit 2018)","statutoryGndSummary":{"identifier":2,"code":"35USC103","descriptionText":"35 USC § 103"},"challengedGroupClaimList":"1-7","claimIdentifier":1887603},{"reasonText":"Davis, et.al., Abstract, \"Safety of an Alkalinizing Buffer Designed for Inhaled Medications in Humans,\" Respiratory Care July 2013, 58(7) 1226-1232 (Exhibit 2016)","statutoryGndSummary":{"identifier":2,"code":"35USC103","descriptionText":"35 USC § 103"},"challengedGroupClaimList":"1-7","claimIdentifier":1887615},{"reasonText":"Clymer, et.al., U.S. Patent Application Publication No. 2007/0110676\n(Exhibit 2013)","statutoryGndSummary":{"identifier":2,"code":"35USC103","descriptionText":"35 USC § 103"},"challengedGroupClaimList":"1,7","claimIdentifier":1887601},{"reasonText":"TeutM, et.al., \"A Homeopathic Proving of Galphimia glauca,\" Abstract, Forsch Komplementamed 2008:15:211-217 (Exhibit 2006)","statutoryGndSummary":{"identifier":2,"code":"35USC103","descriptionText":"35 USC § 103"},"challengedGroupClaimList":"1-7","claimIdentifier":1887610},{"reasonText":"Dorsch, et.al., \"New Histaminic Drugs from Traditional Medicine?,\" Abstract, Int. Arch. Allergy Immunol. 1991; 94:262-265 (Exhibit 2007)","statutoryGndSummary":{"identifier":2,"code":"35USC103","descriptionText":"35 USC § 103"},"challengedGroupClaimList":"1-7","claimIdentifier":1887611},{"reasonText":"Clarot, et.al., U.S. Patent Application Publication No. 2006/0275343\n(Exhibit 2022)","statutoryGndSummary":{"identifier":2,"code":"35USC103","descriptionText":"35 USC § 103"},"challengedGroupClaimList":"1-7","claimIdentifier":1887607},{"reasonText":"Clarot, et.al., U.S. Patent Application Publication No. 2010/0004628\n(Exhibit 2023)","statutoryGndSummary":{"identifier":2,"code":"35USC103","descriptionText":"35 USC § 103"},"challengedGroupClaimList":"1-7","claimIdentifier":1887608},{"reasonText":"Similasan Nasal Allergy Relief Website\nhttps://www.similasanusa.com/nasal-allergy-relief\nExhibit 2005 - Dating back to 12/26/2010","statutoryGndSummary":{"identifier":2,"code":"35USC103","descriptionText":"35 USC § 103"},"challengedGroupClaimList":"1,7","claimIdentifier":1887599},{"reasonText":"Ariza, et.al., \"The Succinate Receptor as a Novel Therapeutic Target for Oxidative and Metabolic Stress-Related Conditions,\" Front Endochronol (Lausanne) 2012:3:22, (Exhibit 2012)","statutoryGndSummary":{"identifier":2,"code":"35USC103","descriptionText":"35 USC § 103"},"challengedGroupClaimList":"1-7","claimIdentifier":1887600},{"reasonText":"Clarot, et.al., U.S. Patent Application Publication No. 2005/0180924\n(Exhibit 2021)","statutoryGndSummary":{"identifier":2,"code":"35USC103","descriptionText":"35 USC § 103"},"challengedGroupClaimList":"1-7","claimIdentifier":1887606}]
  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "14178064",
        caseNumber: "IPR2019-01363"
      }
    }
  };
  beforeEach( () => {
      TestBed.configureTestingModule({
      declarations: [ ClaimsComponent,ClaimsUploadComponent ],
      imports: [HttpClientTestingModule],
      providers: [
        JpViewService, TrialsService,
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        },
        BsModalService,
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useValue: {}
        },
        provideMockStore({
          selectors: [
            { selector: CaseViewerSelectors.userInfoData, value: { caseDetailsData: [] } }
          ],
          initialState: {
            claimsInfoTemp: { // Update name
              sort: []
            }
          }
      })
      ]
    })
    .compileComponents();
    fixture = TestBed.createComponent(ClaimsComponent);
    jpViewService = TestBed.inject(JpViewService);
    trialsService = TestBed.inject(TrialsService);
    modalService = TestBed.inject(BsModalService);
    store$ = TestBed.inject(MockStore);
    component = fixture.componentInstance;
    component.claimsInfo = claimsResponse.claimMetaData

    component.claimsInfoTemp = claimsResponse.claimMetaData;
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
    TestBed.resetTestingModule();
});
  // beforeEach(async() => {
  //   fixture = TestBed.createComponent(ClaimsComponent);
  //   jpViewService = TestBed.inject(JpViewService);
  //   modalService = TestBed.inject(BsModalService);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  it('should create', () => {
    component.claimsInfo= {
      data:[{},{}]
    };
    component.claimsInfoTemp =[{},{}]
    component.orderByField = ["challengedGroupClaimList"];
    expect(component).toBeTruthy();
  });


  // it('should call getClaims and get successResponse', () => {
  //   spyOn(trialsService, 'getClaims').and.returnValue(of(claimsResponse));
  //   component.claimsInfo= {
  //     data:[{},{}]
  //   };
  //   component.claimsInfoTemp =[{},{}]
  //   // component.claimsInfo = claimsResponse.claimMetaData

  //   // tempData = claimsResponse.claimMetaData;
  //   component.orderByField = ["challengedGroupClaimList"];
  //   component.compareValues("challengedGroupClaimList",null)
  //   component.getClaimsData();
  //   expect(component.claimsInfo).toBeDefined;
  //   //  component.sortColumns('ground');
  //   // component.sortColumns('challengedClaimNumber');
  // });


  // it('should call sortColClick', () => {
  //   let field = 'challengedGroupClaimList';
  //   component.claimsInfo= {
  //     data:[{},{}]
  //   };
  //   component.claimsInfoTemp =[{},{}]
  //   component.sortColClick(field);
  // });

  // it('should call correctOrder', () => {
  //   let field = 'desc';
  //   spyOn(component.claimsInfo, 'sort');
  //   component.correctOrder(field);
  //   expect(component.claimsInfoTemp).not.toBeNaN();
  // });

  // it('should call sortColumns', () => {
  //   let field = '-desc';
  //   component.sortColumns(field);
  // });


  it('should call openModal and return a success response for assignment', () => {

    const initialState = {
      modal: {
        isConfirm: false
      }
    };
    const emitter = new EventEmitter();
    emitter.emit(true);

    modalService.show = (): BsModalRef => {
      return ({ id: null, hide: null, setClass: null, onHide: emitter, onHidden: null});
    };
    spyOn(component.claimsInfo, 'sort');
    spyOn(component, "openModal").and.callThrough();
    component.openModal();
    expect(component.openModal).toHaveBeenCalled();

  });


});
