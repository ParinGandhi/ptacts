import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { tableOptions } from 'src/app/models/table-options.model';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import { JpViewService } from 'src/app/services/jpview.service';
import { ClaimsUploadComponent } from '../claims-upload/claims-upload.component';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import { select, Store } from '@ngrx/store';
import * as CaseViewerActions from 'src/app/store/case-viewer/case-viewer.actions';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
// import { getClaimsAction } from 'src/app/store/case-viewer/case-viewer.actions';
// import claimsListModal from 'src/app/models/cases/claimsDetails.model';
import claims from 'src/app/models/claims.model';
import { TrialsService } from 'src/app/services/trials.service';



@Component({
  selector: 'app-claims',
  templateUrl: './claims.component.html',
  styleUrls: ['./claims.component.less']
})
export class ClaimsComponent implements OnInit {
  modalRef: BsModalRef;
  caseInfo: CaseInfoModel;
  claimsInfo: any;
  orderByField: any[] = [];
  claims: any;
  claimsInfoTemp: any[] = [];
  sortCount: boolean = false;
  totalClaim: any;
  // claimsData: claimsListModal;
  // claimsDataArr: claims[] = []
  // claimMetaData: any[];
  // claimObj ={
  //   ground:null,
  //   challengedGroupClaimList:null,
  //   reasonText:null
  // }
  claimsList: any;
  loggedInUser$ = this.store.pipe(select(CaseViewerSelectors.userInfoData));
  lastRefresh = new Date();

  constructor(private store: Store<CaseViewerState>,private jpViewService: JpViewService, private trialsService: TrialsService, private activatedRoute: ActivatedRoute, private modalService: BsModalService) { }

  ngOnInit(): void {
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };

    this.getClaimsData();
    this.sortCount = true;
    // setInterval(()=>{
    //   this.refresh();
    // },300000)
  }

  refresh(){
    this.getClaimsData();
    this.lastRefresh = new Date();
  }

/*istanbul ignore next*/
  getClaimsData() {
    let url = PtabTrialConstants.CLAIMS+ this.caseInfo.proceedingNo;
    this.trialsService.getClaims(url).subscribe((claimsResponse) => {
      this.totalClaim = claimsResponse.totalClaims;
      this.claimsList = claimsResponse.claimMetaData;
      if(claimsResponse.claimMetaData && claimsResponse.claimMetaData.length){
      for(let i=0; i < claimsResponse.claimMetaData.length; i++){
        claimsResponse.claimMetaData[i].ground = claimsResponse.claimMetaData[i].statutoryGndSummary.descriptionText;
      }
    }
      this.claimsInfo = {
        tableId: "claimsTable",
        tableHeaderClass: "claimsTableHeader",
        tableBodyClass: "claimsTableBody",
        sortCount: true,
        columnDefs: [
          {
            name: "Challenged claim number",
            displayName: "Challenged claim number",
            field: "challengedGroupClaimList",
            width: '16%',
            type: "string",
            searchText: null
          },
          {
            name: "Ground",
            displayName: "Ground",
            field: "ground",
            width: '9%',
            type: "string",
            searchText: null
          },
          {
            name: "Prior art",
            displayName: "Prior art",
            field: "reasonText",
            width: null,
            type: "string",
            searchText: null
          }
        ],
        data: claimsResponse.claimMetaData
      };

      this.sortColumns('ground');
      this.sortColumns('challengedGroupClaimList');
    });
  }
/*istanbul ignore next*/
  correctOrder(field) {
    let tempData = [];
      tempData = this.claimsInfo.data;
      this.claimsInfo.data = [];
      let order = field.charAt(0) === '-' ? "desc" : "asc"
      if(this.claimsInfoTemp && this.claimsInfoTemp.length > 0){
        this.claimsInfoTemp.sort(this.compareValues(field, order));
      }else {
        tempData.sort(this.compareValues(field, order));
      }

      this.claimsInfoTemp = tempData;
      this.claimsInfo.data = this.claimsInfoTemp;
  }
/*istanbul ignore next*/
  sortColClick(field) {
    !this.orderByField.includes(field) ? this.correctOrder(field) : this.correctOrder('-' + field);
    this.orderByField = !this.orderByField.includes(field) ? [field] : ['-' + field];
    this.claimsInfo.sortCount = false;
  }
/* istanbul ignore next */
  sortColumns(field) {
      !this.orderByField.includes(field) ? this.correctOrder(field) : this.correctOrder('-' + field);
      field = !this.orderByField.includes(field) ? field : '-' + field;
      // this.orderByField = !this.orderByField.includes(field) ? [field] : ['-' + field];
      if(field.includes('-')){
        let indx = this.orderByField.indexOf(field.substring(1));
        if(indx != -1){
        this.orderByField.splice(indx);
        }
      }
      if(!field.includes('-')){
        let indx = this.orderByField.indexOf('-'+field);
        if(indx != -1){
          this.orderByField.splice(indx);
        }

      }
      if(this.orderByField.indexOf(field) == -1){
        this.orderByField.push(field);
      }
  }
/* istanbul ignore next */
  compareValues(key, order = 'asc') {
    if (key.charAt(0) === '-') {
      key = key.substring(1);
    }
    return function innerSort(a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        // property doesn't exist on either object
        return 0;
      }

      const varA = (typeof a[key] === 'string')
        ? a[key].toUpperCase() : a[key];
      const varB = (typeof b[key] === 'string')
        ? b[key].toUpperCase() : b[key];

      let comparison = 0;
      if (varA > varB) {
        comparison = 1;
      } else if (varA < varB) {
        comparison = -1;
      }
      return (
        (order === 'desc') ? (comparison * -1) : comparison
      );
    };
  }
/* istanbul ignore next */
  openModal() {
    const initialState = {
      modal: {
        isConfirm: false
      }
    };
    this.modalRef = this.modalService.show(ClaimsUploadComponent, {
      animated: true,
      backdrop: true,
      ignoreBackdropClick: true,
      class: 'add-doc-modal-content',
      initialState
    });

    this.modalRef.onHide.subscribe((reason: string | any) => {
      console.log('reason: ', reason);
      if (reason.initialState.modal.isConfirm) {
        this.orderByField = [];
        this.getClaimsData();
      }
    })

  }
}
