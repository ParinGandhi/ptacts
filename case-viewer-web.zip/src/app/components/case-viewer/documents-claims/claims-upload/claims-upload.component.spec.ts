import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { provideMockStore } from '@ngrx/store/testing';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import * as claimsResponse from 'src/assets/test_data/claims.json';
import { JpViewService } from 'src/app/services/jpview.service';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { ClaimsUploadComponent } from './claims-upload.component';
import { of } from 'rxjs';
import { InfoModalComponent } from 'src/app/components/common/info-modal/info-modal.component';
import { EventEmitter } from '@angular/core';
import { emit } from 'process';
import { TrialsService } from 'src/app/services/trials.service';


/**
 * 76.6%
 */
describe('ClaimsUploadComponent', () => {
  let component: ClaimsUploadComponent;
  let fixture: ComponentFixture<ClaimsUploadComponent>;
  let jpViewService: JpViewService;
  let trialsService: TrialsService;
  let activatedRoute: ActivatedRoute;
  let modalService: BsModalService;
  let toastr: ToastrService;
  let groundResponse = [{"id":1,"code":"35USC102","description":"35 USC § 102"},
  {"id":2,"code":"35USC103","description":"35 USC § 103"},
  {"id":3,"code":"35USC112","description":"35 USC § 112"},
  {"id":4,"code":"35USC101","description":"35 USC § 101"}]

  let row = {challengedGroupClaimList: [],
    reasonText: "",
    statutoryGndSummary: {identifier:1},
    claimIdentifier:1234
  };

  let claimsUpload = {
    claims:[]
  }
   let claimUploadObj ={
    asCaptured: null,
    category: null,
    statGroundId: null,
    identifier: null
   }
  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => {},
    error: (
      message?: string,
      title?: string
    ) => {},
  };

  let reason ={
    initialState: {
      modal:{
        isConfirm: true
      }
    }
  }
  class modalServiceMock  {
    // hide: () => {},
    // show:() => {return {onHide:() => {return of(reason)}}}
    show = (infoModalComponent:InfoModalComponent)=>{return {onHide:() => {return of(reason)}}}
    hide = () =>{return {}}
  };
  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "14178064",
        caseNumber: "IPR2019-01363"
      }
    }
  };
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClaimsUploadComponent, InfoModalComponent ],
      imports: [HttpClientTestingModule],
      providers: [
        JpViewService, TrialsService,
        {
          provide: ToastrService,
          useValue: toastrService
        },
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        },
        BsModalService,
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useClass: modalServiceMock
        },
        provideMockStore({
          selectors: [
            { selector: CaseViewerSelectors.caseInfoData, value: { serialNo: null,proceedingNo: null}},
            { selector: CaseViewerSelectors.userInfoData, value: { caseDetailsData: [{}] } }
          ]
      })
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimsUploadComponent);
    component = fixture.componentInstance;
    jpViewService = TestBed.inject(JpViewService);
    trialsService = TestBed.inject(TrialsService);
    modalService = TestBed.inject(BsModalService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getClaims and get successResponse', () => {
    spyOn(trialsService, 'getClaims').and.returnValue(of(claimsResponse));
    component.getClaimsData();
    component.claimsUploadObjList = claimsResponse.claimMetaData
    expect(component.claimsUploadObjList).toBeDefined;
  });

   it('should call getGroundList and get groundslist', () => {
    // spyOn(jpViewService, 'getGround').and.returnValue(of(groundResponse));
    spyOn(trialsService, 'getGround').and.returnValue(of(groundResponse));
    component.getGroundList();
    component.groundList = groundResponse;
    expect(component.groundList).toBeDefined;
   });

   it('should call cancelAdd', () => {
     component.cancelAdd();
   })

   it('should call edit row', () => {
     component.groundList = groundResponse;
     component.editRow(row,'1');
   });

   it('should call add', () => {
     component.add();
    //  spyOn(jpViewService, 'uploadClaims').and.returnValue(of(claimsResponse));
   });

   it('should call validate', () => {
     component.validationObject = {
      ground: false,
      claimNum: false,
      priorArt: false
    }
    component.validate();

   //  spyOn(jpViewService, 'uploadClaims').and.returnValue(of(claimsResponse));
  });

  it('should call selectedGroundVal', () => {
    component.selectedGroundVal(1);
    expect(component.claimUploadObj.statGroundId).toEqual(1);
  });

  it('should call checkEnableAdd', ()=> {
    component.checkEnableAdd();
  });
   it('should call close with true', () => {
     component.modal = {
       isConfirm: null
     }
     component.close(true);
   });
   it('should call saveAdd', () =>{
    let userName ={}
    spyOn(window.sessionStorage, 'getItem').and.callFake((key)=>{
      return userName[key];
    })
    spyOn(jpViewService, 'uploadClaims').and.returnValue(of({test:''}));
     component.saveAdd();
   })

   it('should call editClaim', ()=>{
    let userName ={}
    spyOn(window.sessionStorage, 'getItem').and.callFake((key)=>{
      return userName[key];
    })
    spyOn(jpViewService, 'editClaims').and.returnValue(of({test:''}));
    component.editClaim(claimsUpload);
   });

   it('should call openConfirmDeleteModal' , () =>{

    const initialState = {
      modal: {
        isConfirm: false
      }
    };
    const emitter = new EventEmitter();
    emitter.emit(true);

    modalService.show = (): BsModalRef => {
      return ({ id: null, hide: null, setClass: null, onHide: emitter, onHidden: null});
    };

    spyOn(component, "openConfirmDeleteModal").and.callThrough();
    component.openConfirmDeleteModal(claimsUpload);
    expect(component.openConfirmDeleteModal).toHaveBeenCalled();


   });

   it('should call openConfirmDeleteModal' , () =>{

    const initialState = {
      modal: {
        title: "Abandon unsaved information?",
        subText: "You have claims information that has not been saved. Your changes will be lost.",
        closeBtnName: "No, return to page",
        yesBtnName: "Yes, abandon changes",
        yesBtnClass: "btn-danger",
        isConfirm: false
      },
      animated: true,
      backdrop: 'static',
      class: 'modal-xlg'
    };

    const emitter = new EventEmitter();
    emitter.emit(true);

    modalService.show = (): BsModalRef => {
      return ({ id: null, hide: null, setClass: null, onHide: emitter, onHidden: null});
    };

    spyOn(component, "openAbandonChangesModal").and.callThrough();
    component.openAbandonChangesModal();
    expect(component.openAbandonChangesModal).toHaveBeenCalled();

   });

   afterAll(() => {
    TestBed.resetTestingModule();
  });

});
