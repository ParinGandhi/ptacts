import { Component, Input, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Subscription } from 'rxjs';
import { take } from 'rxjs/operators';
import { Store, select } from '@ngrx/store';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import { JpViewService } from 'src/app/services/jpview.service';
import { ToastrService } from 'ngx-toastr';
import { claimUpload } from 'src/app/models/claims.model';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import AlertModel from 'src/app/models/common/Alert.model';
import { InfoModalComponent } from 'src/app/components/common/info-modal/info-modal.component';
import { ConfirmDialogComponent } from 'src/app/shared/confirm-dialog/confirm-dialog.component';
import { TrialsService } from 'src/app/services/trials.service';

@Component({
  selector: 'app-claims-upload',
  templateUrl: './claims-upload.component.html',
  styleUrls: ['./claims-upload.component.less']
})
export class ClaimsUploadComponent implements OnInit {

  // claimUploadObj = claimUpload;
  validationObject = {
      ground: false,
      claimNum: false,
      priorArt: false
  };

  global = {
    edit: {
      enableEdit: false,
      editIndex: null,
      originalRow: {},
      rowToEdit: null
    }
  };
  alertOptions: AlertModel;
  proceedingNumberText: string;
  selectedGround: string ="Choose a statutory ground";
  modal: any;
  claimsUploadObjList: any;
  petitionerIdentifier: any;
  groundList: Array<any>;
  disableAdd: boolean = true;
  loggedInUser: any = null;
  deleteModelRef: BsModalRef;
  claimsUpload = {
    "caseNo":null,
    "claims": [],
    "audit": {
      "lastModifiedUserIdentifier": null,
      "createUserIdentifier": null
  },
    "lifeCycle": null
  }
  tempSelectedGround: any;
  // initiatePartiesModal() {
    claimUploadObj = {
      asCaptured: null,
      category: null,
      statGroundId: null,
      identifier: null
    // };
  }
  // claimsUploadObjList: Array<claimUpload> = [];
  constructor(private modalService: BsModalService,public bsModalRef: BsModalRef, private store: Store <CaseViewerState> , private jpViewService: JpViewService, private trialsService: TrialsService, private toastr: ToastrService) { }

  ngOnInit(): void {

    this.store.pipe(select(CaseViewerSelectors.caseInfoData)).pipe(take(1)).subscribe((value) => {
      this.proceedingNumberText = value.proceedingNo;
      this.claimsUpload.caseNo = this.proceedingNumberText;
    });

    this.store.pipe(select(CaseViewerSelectors.userInfoData)).subscribe(data => {
      this.loggedInUser = data.caseDetailsData[0];
      if (!this.loggedInUser) {
        this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
        this.claimsUpload.audit.lastModifiedUserIdentifier = this.loggedInUser.loginId;
        this.claimsUpload.audit.createUserIdentifier = this.loggedInUser.loginId;
      }
    })
    this.getClaimsData();
    this. getGroundList();
  }


  getGroundList() {
    // this.jpViewService.getGround('/src/assets/test_data/ground.json').subscribe((groundResponse) => {
    // this.jpViewService.getGround('/pcdng-claims/statutory-grounds').subscribe((groundResponse) => {
    this.trialsService.getGround().subscribe((groundResponse) => {
      this.groundList = groundResponse;
    });
  }

  cancelAdd() {
    this.selectedGround = "Choose a statutory ground";
    this.claimUploadObj = {
      asCaptured: null,
      category: null,
      statGroundId: null,
      identifier: null
    };
    this.disableAdd = true;
  }

  getClaimsData() {
    let url = PtabTrialConstants.CLAIMS + this.proceedingNumberText;
    this.trialsService.getClaims(url).subscribe((claimsResponse) => {
      this.claimsUploadObjList = claimsResponse.claimMetaData;

    });
  }

  editRow(row, index) {
    // this.editMode.emit(true);

    this.claimUploadObj = {
      asCaptured: row.challengedGroupClaimList,
      category: row.reasonText,
      statGroundId: row.statutoryGndSummary.identifier,
      identifier: row.claimIdentifier
    };
    this.tempSelectedGround = this.groundList.find(element => element.id === row.statutoryGndSummary.identifier)
    this.selectedGround = this.tempSelectedGround.id;
    this.disableAdd = false;

  }

  validate() {
      this.validationObject.ground = this.checkFormModel(this.claimUploadObj.statGroundId);
      this.validationObject.claimNum = this.checkFormModel(this.claimUploadObj.asCaptured);
      this.validationObject.priorArt = this.checkFormModel(this.claimUploadObj.category);
      return this.validationObject.claimNum || this.validationObject.priorArt || this.validationObject.ground;
      };

  checkFormModel(formModel) {
    if (!formModel) {
      return true;
    }
    return false;
  };

  add() {
    if (this.validate()) {
      return;
    }
     else {
      this.saveAdd();
    }
  };

  selectedGroundVal(value) {
  this.claimUploadObj.statGroundId = value;
  };

  checkEnableAdd() {
    if(this.claimUploadObj.category && this.claimUploadObj.asCaptured && this.claimUploadObj.statGroundId){
      this.disableAdd = false;
    }else {
      this.disableAdd = true;
    }
  };

  editClaim(editValue) {
    this.claimsUpload.claims.push(editValue)
    // this.jpViewService.editClaims(`/pcdng-claims`,this.claimsUpload).subscribe(data => {
    this.trialsService.editClaims(this.claimsUpload).subscribe(data => {
      this.disableAdd = true;
      this.claimsUpload.claims = [];
      this.claimUploadObj = {
        asCaptured: null,
        category: null,
        statGroundId: null,
        identifier: null
      };
      this.selectedGround = null;
      this.getClaimsData();
      this.toastr.success(`Claim successfully saved`, "", {
        closeButton: true
      });

    }, (failureResponse) => {
      this.toastr.error(failureResponse.error.message, "", {
        closeButton: true
      });
      this.disableAdd = false;
      this.claimsUpload.claims = [];
    })

  }

  saveAdd() {
    this.claimsUpload.claims.push(this.claimUploadObj)
    this.disableAdd = true;
    // this.jpViewService.uploadClaims(`/pcdng-claims`,this.claimsUpload).subscribe(data => {
    this.trialsService.uploadClaims(this.claimsUpload).subscribe(data => {
      this.disableAdd = true;
      this.claimsUpload.claims = [];
      this.claimUploadObj = {
        asCaptured: null,
        category: null,
        statGroundId: null,
        identifier: null
      };
      this.selectedGround = null;
      this.getClaimsData();
      this.toastr.success(`Claim successfully saved`, "", {
        closeButton: true
      });

    }, (failureResponse) => {
      this.toastr.error(failureResponse.error.message, "", {
        closeButton: true
      });
      this.disableAdd = false;
      this.claimsUpload.claims = [];
    })
  }
  close(refreshValue) {
    if ((this.claimsUpload.claims && this.claimsUpload.claims.length > 0) || (this.claimUploadObj.category && this.claimUploadObj.asCaptured && this.claimUploadObj.statGroundId)) {
      this.openAbandonChangesModal();
    } else {
      this.modal.isConfirm = refreshValue;
      this.modalService.hide();
    }
  }

  openAbandonChangesModal() {
    const initialState = {
      modal: {
        title: "Abandon unsaved information?",
        subText: "You have claims information that has not been saved. Your changes will be lost.",
        closeBtnName: "No, return to page",
        yesBtnName: "Yes, abandon changes",
        yesBtnClass: "btn-danger",
        isConfirm: false
      },
      animated: true,
      backdrop: 'static',
      class: 'modal-xlg'
    };
    this.bsModalRef = this.modalService.show(ConfirmDialogComponent, {
      initialState
    });

    this.bsModalRef.onHide.subscribe((reason: string | any) => {
      console.log('reason: ', reason);
      if (reason.initialState.modal.isConfirm) {
        this.modalService.hide();
      }
    })
  }
/* istanbul ignore next */
  openConfirmDeleteModal(data) {
    const initialState: any = {
      modal: {
        isConfirm: false,
        title: "Delete this claim?",
        infoText: ['This claim information will be removed from the table view.'],
        showLeftBtn: true,
        leftBtnClass: 'btn-default',
        leftBtnLabel: 'No, return to page',
        showRightBtn: true,
        rightBtnClass: 'btn-danger',
        rightBtnLabel: 'Yes, delete this record',
        modalHeight: 100,
      }
    };
    this.deleteModelRef = this.modalService.show(InfoModalComponent, {
      animated: true,
      backdrop: 'static',
      class: 'confirm-delete-modal',
      initialState
    });
    this.deleteModelRef.onHide.subscribe((reason: string | any) => {
      console.log('reason: ', reason);
      if (reason.initialState.modal.isConfirm) {
        // Add delete code here
        // this.modalService.hide();
        // let url = /delete-partyinfo/TRIALS
        let url = "/pcdng-claims/" + data.claimIdentifier
        // + claimsIdentifier
        //1889178
        // this.jpViewService.deleteClaim(url).subscribe((Response)=>{
        this.trialsService.deleteClaim(data.claimIdentifier).subscribe((Response)=>{
          this.getClaimsData();
          this.toastr.success(`Claim successfully removed`, "", {
            closeButton: true
          });
        })
      }
    })
  }

}
