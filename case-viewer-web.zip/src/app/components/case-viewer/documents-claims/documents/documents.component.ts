import { Component, EventEmitter, Input, OnInit, Output, TemplateRef, ViewChild } from '@angular/core';
import { JpViewService } from "../../../../services/jpview.service";
import { PtabTrialConstants } from "../../../../constants/ptab-trials.constants";
// import { Store } from '@ngrx/store';
// import { State } from '../../../../store';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import PaperCasesModel from "src/app/models/cases/PaperCases.model";
import ExhibitCasesModel from "src/app/models/cases/ExhibitCases.model";
import CaseModel from "src/app/models/cases/Case.model";
import CaseDetailsModel from "src/app/models/cases/CaseDetails.model";
import { ActivatedRoute } from '@angular/router';
import { tableOptions } from 'src/app/models/table-options.model';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { DocumentUploadComponent } from 'src/app/document-upload/document-upload.component';
import { UpdateDocumentsComponent } from 'src/app/components/documents-claims/documents/update-documents/update-documents.component';
import { TrialsService } from 'src/app/services/trials.service';
import { CommonService } from 'src/app/services/common.service';
import { CaseviewerHeaderComponent } from '../../caseviewer-header/caseviewer-header.component';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import { Store, select } from '@ngrx/store';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { GetCasePhaseAction } from 'src/app/store/case-viewer/case-viewer.actions';
import * as CaseViewerActions from 'src/app/store/case-viewer/case-viewer.actions';

@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.less']
})
export class DocumentsComponent implements OnInit {

  @ViewChild(CaseviewerHeaderComponent)
  public caseviewerHeaderComponent: CaseviewerHeaderComponent;

  @Input() isOriginalJoinedCase;

  @Output() invokeJoinedCasesDropdownEmitter: EventEmitter<boolean> = new EventEmitter();
  @Output() milestonePoprEmitter:EventEmitter<any> = new EventEmitter();

  loggedInUser$ = this.store.pipe(select(CaseViewerSelectors.userInfoData));
  modalRef: BsModalRef;
  allPaperCases: any;
  originalAllPaperCases: PaperCasesModel;
  allExhibitCases: any;
  originalAllExhibitCases: ExhibitCasesModel;
  papers: any = [];
  exhibits: any = [];
  orderByField: any[] = [];
  orderByExhibitField: any[] = [];
  caseDetails: CaseDetailsModel;
  caseInfo: CaseInfoModel = {
    serialNo: null,
    proceedingNo: null
  };
  selectedCases: Array<any> = [];
  filterObj: any = {};
  papersCount = {
    all: 0,
    board: 0,
    po: 0,
    petitioner: 0
  };
  exhibitsCount = {
    all: 0,
    thousand: 0,
    twoThousand: 0,
    threeThousand: 0
  };
  documentTable: tableOptions;
  selectedParty: string;
  selectedExhibit: string;
  petitionerIdentifier: any;
  pdfData: any;
  pdfContent: any;
  contentsPreview: string;
  nextPaperNumber: string;
  papersToDownload: Array<string> = [];
  exhibitsToDownload: Array<string> = [];
  documentSelected = false;
  downloading = false;
  lastRefresh = new Date();

  // To refresh header - delete when integrated into header call
  // store: Store<CaseViewerState>;

  constructor(
    private jpViewService: JpViewService,
    private activatedRoute: ActivatedRoute,
    private modalService: BsModalService,
    private trialsService: TrialsService,
    private commonService: CommonService,
    private commonUtils: CommonUtilitiesService,
    private store: Store
  ) { }

  ngOnInit(): void {

    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };

    this.store.dispatch(GetCasePhaseAction({url: this.caseInfo.proceedingNo}));
  this.orderByField = [];
  this.orderByExhibitField = [];
    this.getDocuments();
    this.getPetitionIdentifier();
    this.getNextPaperNumber(this.caseInfo.proceedingNo)
    // setInterval(()=>{
    //   this.refresh();
    // },300000)
  }

  refresh(){
    this.orderByField = [];
    this.orderByExhibitField = [];
    this.getDocuments();
    this.lastRefresh = new Date();
  }

  /**
  * Retrieve paper documents based on proceeding number
  *
  * @param proceedingNo
  */
  getPaperDocuments() {
      this.papers = {
        tableId: "papersTable",
        tableHeaderClass: "papersTableHeader",
        tableBodyClass: "papersTableBody",
        checkboxClass: "paperTableCheckbox",
        headerCheckboxId: "paperHeaderCheckbox",
        cellCheckboxId: "paperCheckbox",
        columnDefs: [
          {
            name: "Paper #",
            displayName: "Paper #",
            field: "documentNumber",
            width: '6%',
            type: "string",
            searchText: null
          },
          {
            name: "Filing date",
            displayName: "Filing date",
            field: "filingDate",
            width: '8%',
            type: "date",
            searchText: null
          },
          {
            name: "Paper type",
            displayName: "Paper type",
            field: "documentTypeDescription",
            width: '8%',
            type: "string",
            searchText: null
          },
          {
            name: "Title",
            displayName: "Document name",
            field: "name",
            width: '13%',
            type: "string",
            searchText: null
          },
          {
            name: "Pages",
            displayName: "Pages",
            field: "pageCount",
            width: '6%',
            type: "string",
            searchText: ""
          },
          {
            name: "Filing party",
            displayName: "Filing party",
            field: "filingParty",
            width: '9%',
            type: "string",
            searchText: ""
          },
          {
            name: "Availability",
            displayName: "Availability",
            field: "availability",
            width: '9%',
            type: "string",
            searchText: ""
          }
        ],
        data: JSON.parse(JSON.stringify(this.allPaperCases.allPapersBag))
      };
      this.sortColumns('-documentNumber', 'p');
      this.selectedParty = "allPapersBag";
  }


  setPapersCount() {
    this.papersCount = {
      all: this.allPaperCases.allPapersCount,
      board: this.allPaperCases.boardPapersCount,
      po: this.allPaperCases.patentOwnerPapersCount,
      petitioner: this.allPaperCases.petitionerPapersCount
    }
  }

  /** Retrieve new Paper number
   * @param proceedingNo
   */
  getNextPaperNumber(proceedingNo) {
    // this.jpViewService.getDocuments(`${PtabTrialConstants.TRIAL_SERVICES_URL}${PtabTrialConstants.NEXT_PAPER_NUM_URL}${proceedingNo}`).subscribe((paperSequenceResponse) => {
    this.trialsService.getNextPaperNumber(proceedingNo).subscribe((paperSequenceResponse) => {
    this.nextPaperNumber=paperSequenceResponse.paperSequence;
    }, (paperNumberError) => {
      // Intentionally blank
    });
  }


  /**
   * Retrieve exhibit documents based on proceeding number
   *
   * @param proceedingNo
   */
  getExhibitDocuments() {
        this.exhibits = {
          tableId: "exhibitsTable",
          tableHeaderClass: "exhibitsTableHeader",
          tableBodyClass: "exhibitsTableBody",
          checkboxClass: "exhibitsTableCheckbox",
          headerCheckboxId: "exhibitsHeaderCheckbox",
        cellCheckboxId: "exhibitsCheckbox",
          columnDefs: [
            {
              name: "Exhibit #",
              displayName: "Exhibit #",
              field: "exhibitNumber",
              width: '5%',
              type: "string",
              searchText: null
            },
            {
              name: "Filing date",
              displayName: "Filing date",
              field: "filingDate",
              width: '6%',
              type: "date",
              searchText: null
            },
            {
              name: "Document name",
              displayName: "Document name",
              field: "name",
              width: '13%',
              type: "string",
              searchText: null
            },
            {
              name: "Pages",
              displayName: "Pages",
              field: "pageCount",
              width: '4%',
              type: "string",
              searchText: ""
            },
            {
              name: "Filing party",
              displayName: "Filing party",
              field: "filingParty",
              width: '6%',
              type: "string",
              searchText: ""
            },
            {
              name: "Availability",
              displayName: "Availability",
              field: "availability",
              width: '6%',
              type: "string",
              searchText: ""
            }
          ],
          data: JSON.parse(JSON.stringify(this.allExhibitCases.allExhibitsBag))
        };
        this.sortColumns('-exhibitNumber', 'e');
        this.selectedExhibit = "allExhibitsBag";

  }


  getDocuments() {
    this.trialsService.getDocumentsForUpdate(`${PtabTrialConstants.TRIALS_URLS.GET_DOCUMENTS}${this.caseInfo.proceedingNo}`).subscribe((documentSuccess) => {
      let paperDocs = [];
      let exhibitDocs = [];
      this.papersCount = {
        all: 0,
        board: 0,
        po: 0,
        petitioner: 0
      }
      this.allPaperCases = {
        allPapersBag: [],
        boardPapersBag: [],
        petitionerPapersBag: [],
        patentOwnerPapersBag: []
      }
      this.exhibitsCount = {
        all: 0,
      thousand: 0,
      twoThousand: 0,
      threeThousand: 0
      }
      this.allExhibitCases = {
        allExhibitsBag: [],
        thousandsExhibitsBag: [],
        twoThousandsExhibitsBag: [],
        threeThousandsExhibitsBag: []
      }
      let milestonePopr = {
        poprWaivedResponse: null,
        poprFileResponse: null
      }
      documentSuccess.forEach((doc) => {
        // for milestone page
        if (doc?.documentTypeIdentifier == '18' || doc?.documentTypeIdentifier == '203') {
          milestonePopr.poprWaivedResponse = 'No';
        }
        else if (doc?.documentTypeIdentifier == '38' || doc?.documentTypeIdentifier == '204') {
          milestonePopr.poprWaivedResponse = 'Yes';
        }

        if (doc.filingDate && doc.filingDate.toString().length <= 10) {
          doc.filingDate = parseInt(doc.filingDate.toString() + "000");
        }
        if (doc.category && doc.category.toLowerCase() === 'paper') {
          this.papersCount.all++;
          this.allPaperCases.allPapersBag.push(doc);
          switch (doc.filingParty.toLowerCase()) {
            case 'board':
              this.papersCount.board++;
              this.allPaperCases.boardPapersBag.push(doc);
              break;
            case 'petitioner':
              this.papersCount.petitioner++;
              this.allPaperCases.petitionerPapersBag.push(doc);
              break;
              case 'patent owner':
                this.papersCount.po++;
                this.allPaperCases.patentOwnerPapersBag.push(doc);
          }
        } else if (doc.category && doc.category.toLowerCase() === 'exhibits') {
          this.exhibitsCount.all++;
            this.allExhibitCases.allExhibitsBag.push(doc);
          if (doc.exhibitNumber.toString().startsWith('1')) {
            this.exhibitsCount.thousand++;
            this.allExhibitCases.thousandsExhibitsBag.push(doc);
          } else if (doc.exhibitNumber.toString().startsWith('2')) {
            this.exhibitsCount.twoThousand++;
            this.allExhibitCases.twoThousandsExhibitsBag.push(doc);
          } else if (doc.exhibitNumber.toString().startsWith('3')) {
            this.exhibitsCount.threeThousand++;
            this.allExhibitCases.threeThousandsExhibitsBag.push(doc);
          }

        }
      });

      documentSuccess.forEach((poprElement, index, arr) => {
        if (poprElement?.documentTypeIdentifier == '38' || poprElement?.documentTypeIdentifier == '204' || poprElement?.documentTypeIdentifier == '18' || poprElement?.documentTypeIdentifier == '203') {
          milestonePopr.poprFileResponse = 'Yes';
          arr.length = index + 1;
        }
        else {
          milestonePopr.poprFileResponse = 'No';
        }
      });

      this.milestonePoprEmitter.emit(milestonePopr);
      this.getPaperDocuments();
      this.getExhibitDocuments();
    });
  }

  setExhibitsCount() {
    this.exhibitsCount = {
      all: this.allExhibitCases.allExhibitsCount,
      thousand: this.allExhibitCases.thousandsExhibitsCount,
      twoThousand: this.allExhibitCases.twoThousandsExhibitsCount,
      threeThousand: this.allExhibitCases.threeThousandsExhibitsCount
    }
  }

  changeParty(partyType) {
    this.selectedParty = partyType;
    this.orderByField = [];
    this.papers.data = JSON.parse(JSON.stringify(this.allPaperCases[partyType]));
    this.sortColumns('-documentNumber', 'p');
  }


  changeExhibits(exhibitNumber) {
    this.selectedExhibit = exhibitNumber;
    this.orderByExhibitField = [];
    this.exhibits.data = JSON.parse(JSON.stringify(this.allExhibitCases[exhibitNumber]));
    this.sortColumns('-exhibitNumber', 'e');
  }

  sortColumns(field, sortType) {
    if (sortType === 'p') {
      !this.orderByField.includes(field) ? this.correctOrder(field, sortType) : this.correctOrder('-' + field, sortType);
      this.orderByField = !this.orderByField.includes(field) ? [field] : ['-' + field];
    } else if (sortType === 'e') {
      !this.orderByExhibitField.includes(field) ? this.correctOrder(field, sortType) : this.correctOrder('-' + field, sortType);
      this.orderByExhibitField = !this.orderByExhibitField.includes(field) ? [field] : ['-' + field];
    }
  }

  correctOrder(field, sortType) {
    let tempData;
    if (sortType === 'p') {
      tempData = [...this.papers.data];
      this.papers.data = [];
      let order = field.charAt(0) === '-' ? "desc" : "asc"
      tempData.sort(this.compareValues(field, order, sortType));
      this.papers.data = [...tempData];
    } else if (sortType === 'e') {
      tempData = [...this.exhibits.data];
      this.exhibits.data = [];
      let order = field.charAt(0) === '-' ? "desc" : "asc"
      tempData.sort(this.compareValues(field, order, sortType));
      this.exhibits.data = [...tempData];
    }
  }


  compareValues(key, order = 'asc', sortType) {
    if (key.charAt(0) === '-') {
      key = key.substring(1);
    }

    return function innerSort(a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        // property doesn't exist on either object
        return 0;
      }

      const varA = (typeof a[key] === 'string')
        ? a[key].toUpperCase() : a[key];
      const varB = (typeof b[key] === 'string')
        ? b[key].toUpperCase() : b[key];


        let comparison = 0;
        if (varA > varB) {
          comparison = 1;
        } else if (varA < varB) {
          comparison = -1;
        } else {
          let numberA = sortType === 'p' ? a.docNo : a.exhibitNumber;
        let numberB = sortType === 'p' ? b.docNo : b.exhibitNumber;

        if (numberA > numberB) {
          comparison = 1;
        } else if (numberA < numberB) {
          comparison = -1;
        } else {
          return 0;
        }
        }
        return (
          (order === 'desc') ? (comparison * -1) : comparison
        );
    };
  }

  openModal() {
    const initialState = {
      modal: {
        isConfirm: false.valueOf,
        isOriginalJoinedCase: this.isOriginalJoinedCase
      }
    };
    this.modalRef = this.modalService.show(DocumentUploadComponent, {
      animated: true,
      backdrop: true,
      ignoreBackdropClick: true,
      class: 'add-doc-modal-content',
      initialState
    });
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        this.orderByField = [];
        this.orderByExhibitField = [];
        this.getNextPaperNumber(this.caseInfo.proceedingNo);
        this.getDocuments();
        this.invokeJoinedCasesDropdownEmitter.emit(true);
        this.store.dispatch(CaseViewerActions.GetCasePhaseAction({url: this.caseInfo.proceedingNo}));
      }
    })
  }

  getPetitionIdentifier() {
    // this.jpViewService.getCaseInfoByProceedingNo(`${PtabTrialConstants.COMMON_SERVICES_URL}/petitions?proceedingNumberText=${this.caseInfo.proceedingNo}`).subscribe((caseInfoByProceedingResponse) => {
    this.commonService.getCaseInfoByProceedingNo(this.caseInfo.proceedingNo).subscribe((caseInfoByProceedingResponse) => {
      this.petitionerIdentifier = caseInfoByProceedingResponse.petitionIdentifier;
    });
  }

  openPdfFile(data) {
    this.commonService.openPdf(`/petitions/${this.petitionerIdentifier}/download-documents?contentManagementId=${data.contentManagementId}`);
  }

  openUpdateDocumentsModal() {

    const initialState = {
      modal: {
        isConfirm: false,
        // documentData: documentData,
        caseInfo: this.caseInfo,
        petitionerIdentifier: this.petitionerIdentifier
      }
    };
    this.modalRef = this.modalService.show(UpdateDocumentsComponent, {
      animated: true,
      backdrop: true,
      ignoreBackdropClick: true,
      class: 'add-doc-modal-content',
      initialState
    });
     this.modalRef.onHide.subscribe((reason: string | any) => {
      this.orderByField = [];
        this.orderByExhibitField = [];
        this.getNextPaperNumber(this.caseInfo.proceedingNo);
       this.getDocuments();
      if (reason.initialState.modal.isConfirm) {
        this.orderByField = [];
        this.orderByExhibitField = [];
      }
    })
  }

  rowSelectionForPapers(selectedDocs) {
    if (typeof(selectedDocs?.valueToEmit) === 'string') {
      if (selectedDocs?.valueToEmit === "all") {
        this.papersToDownload = [];
        this.papersToDownload = [...this.allPaperCases.allPapersBag];
        // this.allPaperCases.allPapersBag.forEach((paper) => {
        //   this.papersToDownload.push(paper.contentManagementId);
        // });
      } else if (selectedDocs?.valueToEmit === "none") {
        this.papersToDownload = [];
      }
    } else {
      const contentManagementId = selectedDocs.valueToEmit.contentManagementId;
      if (selectedDocs?.row?.target?.checked) {
        // this.papersToDownload.push(contentManagementId);
        this.papersToDownload.push(selectedDocs.valueToEmit);
      } else {
        // const indexToRemove = this.papersToDownload.indexOf(contentManagementId);
        const indexToRemove = this.papersToDownload.indexOf(selectedDocs.valueToEmit);
        this.papersToDownload.splice(indexToRemove, 1);
      }
    }
    this.checkIfDocumentIsSelected();
    console.log("Papers to download:", this.papersToDownload);
  }


  rowSelectionForExhibits(selectedDocs) {
    // console.log('selectedDocs: ', selectedDocs);
    // const contentManagementId = selectedDocs.valueToEmit.contentManagementId;
    if (typeof(selectedDocs?.valueToEmit) === 'string') {
      if (selectedDocs?.valueToEmit === "all") {
        this.exhibitsToDownload = [];
        this.exhibitsToDownload = [...this.allExhibitCases.allExhibitsBag];
        // this.allExhibitCases.allExhibitsBag.forEach((exhibit) => {
        //   this.exhibitsToDownload.push(exhibit.contentManagementId);
        // });
      } else if (selectedDocs?.valueToEmit === "none") {
        this.exhibitsToDownload = [];
      }
    } else {
      const contentManagementId = selectedDocs.valueToEmit.contentManagementId;
      if (selectedDocs?.row?.target?.checked) {
        // this.exhibitsToDownload.push(contentManagementId);
        this.exhibitsToDownload.push(selectedDocs.valueToEmit);
      } else {
        // const indexToRemove = this.exhibitsToDownload.indexOf(contentManagementId);
        const indexToRemove = this.exhibitsToDownload.indexOf(selectedDocs.valueToEmit);
        this.exhibitsToDownload.splice(indexToRemove, 1);
      }
    }
    this.checkIfDocumentIsSelected();
    console.log("Exhibits to download:", this.exhibitsToDownload);
  }


  checkIfDocumentIsSelected() {
    this.documentSelected = this.papersToDownload.length > 0 || this.exhibitsToDownload.length > 0;
  }

  sortPapers(papersToSort) {
    let docsToUpload = [];
    papersToSort.sort((a, b) => {
      let docNoA = a.documentNumber;
      let docNoB = b.documentNumber;
      if (docNoA < docNoB) {
        return -1;
      }
      if (docNoA > docNoB) {
        return 1;
      }

      // names must be equal
      return 0;
    })
    papersToSort.forEach((paper) => {
      docsToUpload.push(paper.contentManagementId);
    });
    return docsToUpload;
  }


  sortExhibits(exhibitsToSort) {
    let docsToUpload = [];
    exhibitsToSort.sort((a, b) => {
      let docNoA = a.exhibitNumber;
      let docNoB = b.exhibitNumber;
      if (docNoA < docNoB) {
        return -1;
      }
      if (docNoA > docNoB) {
        return 1;
      }

      // names must be equal
      return 0;
    })
    exhibitsToSort.forEach((paper) => {
      docsToUpload.push(paper.contentManagementId);
    });
    return docsToUpload;
  }



  downloadEwf(downloadSelection: string) {
    this.downloading = true;
    let docsToUpload = null;
    let fileName = `${this.caseInfo.proceedingNo}`;
    switch (downloadSelection) {
      case 'selected':
        fileName += ` - selected docs`;
        const sortedDocs = this.sortPapers(this.papersToDownload);
        // docsToUpload = this.papersToDownload.concat(this.exhibitsToDownload);
        const sortedExhibits = this.sortExhibits(this.exhibitsToDownload);
        // docsToUpload = sortedDocs.concat(this.exhibitsToDownload);
        docsToUpload = sortedDocs.concat(sortedExhibits);
        break;
      case 'papers':
        fileName += ` - all papers`;
        docsToUpload = [];
        docsToUpload = this.sortPapers(this.allPaperCases.allPapersBag);
        break;
      case 'exhibits':
        fileName += ` - all exhibits`;
        docsToUpload = [];
        docsToUpload = this.sortExhibits(this.allExhibitCases.allExhibitsBag);
        // this.allExhibitCases.allExhibitsBag.forEach((exhibit) => {
        //   docsToUpload.push(exhibit.contentManagementId);
        // });
        break;
      case 'case':
        fileName += ` - entire case`;
        docsToUpload = [];
        docsToUpload = this.sortPapers(this.allPaperCases.allPapersBag);
        // this.allPaperCases.allPapersBag.forEach((paper) => {
        //   docsToUpload.push(paper.contentManagementId);
        // });
        const allSortedPapers = this.sortPapers(this.allPaperCases.allPapersBag);
        const allSortedExhibits = this.sortExhibits(this.allExhibitCases.allExhibitsBag);
        docsToUpload = allSortedPapers.concat(allSortedExhibits);
        // this.allExhibitCases.allExhibitsBag.forEach((exhibit) => {
        //   docsToUpload.push(exhibit.contentManagementId);
        // });
        break;
      default:
        break;
    }


    this.trialsService.downloadEwf(docsToUpload).subscribe((downloadEwfSuccess) => {
      let blob = new Blob([downloadEwfSuccess], {
        type: "application/pdf"
      });
      let a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `${fileName}${PtabTrialConstants.DOWNLOAD_TYPE.PDF}`;
      a.click();
      this.downloading = false;
    }, (downloadEwfFailure) => {
      console.log('downloadEwfFailure: ', downloadEwfFailure);
      let blob = new Blob([downloadEwfFailure.error.text], {
        type: "application/pdf"
      });
      let a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `${fileName}${PtabTrialConstants.DOWNLOAD_TYPE.PDF}`;
      a.click();
      this.downloading = false;
    });
  };


  exportAsExcel() {
    this.downloading = true;
    this.trialsService.downloadExcel(this.caseInfo.proceedingNo).subscribe((excelResponse) => {
      let blob = new Blob([excelResponse], {
        type: "application/pdf"
      });
      let a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `${this.caseInfo.proceedingNo} - all document list${PtabTrialConstants.DOWNLOAD_TYPE.EXCEL}`;
      a.click();
      this.downloading = false;
    }, (csvFailure) => {
      console.log('csvFailure: ', csvFailure);
      this.commonUtils.setToastr('error', 'Failed to generate report');
      this.downloading = false;
    });
  }
}