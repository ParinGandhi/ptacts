import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { JpViewService } from 'src/app/services/jpview.service';
import { TrialsService } from 'src/app/services/trials.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { of, throwError } from 'rxjs';
import * as paperCasesResp from 'src/assets/test_data/paperCases.json';
import * as exhibitCasesResp from 'src/assets/test_data/exhibitCases.json';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { provideMockStore } from '@ngrx/store/testing';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';

import { DocumentsComponent } from './documents.component';
import { ComponentSource } from 'ag-grid-community/dist/lib/components/framework/userComponentFactory';


/**
 * 48.25%
 */
describe('DocumentsComponent', () => {
  let component: DocumentsComponent;
  let modalService: BsModalService;
  let commonUtils: CommonUtilitiesService;
  let fixture: ComponentFixture<DocumentsComponent>;
  let jpViewService: JpViewService;
  let trialsService: TrialsService;


  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => {},
    error: (
      message?: string,
      title?: string
    ) => {},
  };

  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "123456789",
        caseNumber: "IPR2020-123456"
      }
    }
  };

  const allExhibitsObj = {
    "allExhibitsCount": 5,
    "allExhibitsBag": [{
      "filingDate": 1548997200000,
      "proceedingNumber": "IPR2019-00652",
      "artifactTypeCd": "EXHIBITS",
      "filingParty": "PETITIONER",
      "documentTitle": "Exhibit 1001 - U.S. Patent No. 9,834,822",
      "contentManagementId": "workspace://SpacesStore/669082fd-4492-4346-9110-22519c86c377;1.0",
      "pageCountQt": 56,
      "statusCode": "PENDING",
      "availability": "PUBLIC",
      "exhibitNumber": 1001
    }, {
      "filingDate": 1548997200000,
      "proceedingNumber": "IPR2019-00652",
      "artifactTypeCd": "EXHIBITS",
      "filingParty": "PETITIONER",
      "documentTitle": "Exhibit 1002 - Gabriel Declaration",
      "contentManagementId": "workspace://SpacesStore/2970f0a5-cfde-489f-9299-766a566dd0c7;1.0",
      "pageCountQt": 104,
      "statusCode": "PENDING",
      "availability": "PUBLIC",
      "exhibitNumber": 1002
    }, {
      "filingDate": 1548997200000,
      "proceedingNumber": "IPR2019-00652",
      "artifactTypeCd": "EXHIBITS",
      "filingParty": "PETITIONER",
      "documentTitle": "Exhibit 1003 - Gabriel CV",
      "contentManagementId": "workspace://SpacesStore/3f938e5a-1abd-46a9-9c36-de33d00971d6;1.0",
      "pageCountQt": 17,
      "statusCode": "PENDING",
      "availability": "PUBLIC",
      "exhibitNumber": 1003
    }, {
      "filingDate": 1548997200000,
      "proceedingNumber": "IPR2019-00652",
      "artifactTypeCd": "EXHIBITS",
      "filingParty": "PETITIONER",
      "documentTitle": "Exhibit 1004 - Forshew",
      "contentManagementId": "workspace://SpacesStore/92e84c8f-f3bc-4210-8abf-dcc4fe53775e;1.0",
      "pageCountQt": 34,
      "statusCode": "PENDING",
      "availability": "PUBLIC",
      "exhibitNumber": 1004
    }, {
      "filingDate": 1548997200000,
      "proceedingNumber": "IPR2019-00652",
      "artifactTypeCd": "EXHIBITS",
      "filingParty": "PETITIONER",
      "documentTitle": "Exhibit 1005 - Meyerson",
      "contentManagementId": "workspace://SpacesStore/9aff9fc0-d890-4732-ac75-bde90ba98aa5;1.0",
      "pageCountQt": 12,
      "statusCode": "PENDING",
      "availability": "PUBLIC",
      "exhibitNumber": 1005
    }],
    "thousandsExhibitsCount": 4,
    "thousandsExhibitsBag": [{
      "filingDate": 1548997200000,
      "proceedingNumber": "IPR2019-00652",
      "artifactTypeCd": "EXHIBITS",
      "filingParty": "PETITIONER",
      "documentTitle": "Exhibit 1001 - U.S. Patent No. 9,834,822",
      "contentManagementId": "workspace://SpacesStore/669082fd-4492-4346-9110-22519c86c377;1.0",
      "pageCountQt": 56,
      "statusCode": "PENDING",
      "availability": "PUBLIC",
      "exhibitNumber": 1001
    }, {
      "filingDate": 1548997200000,
      "proceedingNumber": "IPR2019-00652",
      "artifactTypeCd": "EXHIBITS",
      "filingParty": "PETITIONER",
      "documentTitle": "Exhibit 1002 - Gabriel Declaration",
      "contentManagementId": "workspace://SpacesStore/2970f0a5-cfde-489f-9299-766a566dd0c7;1.0",
      "pageCountQt": 104,
      "statusCode": "PENDING",
      "availability": "PUBLIC",
      "exhibitNumber": 1002
    }, {
      "filingDate": 1548997200000,
      "proceedingNumber": "IPR2019-00652",
      "artifactTypeCd": "EXHIBITS",
      "filingParty": "PETITIONER",
      "documentTitle": "Exhibit 1003 - Gabriel CV",
      "contentManagementId": "workspace://SpacesStore/3f938e5a-1abd-46a9-9c36-de33d00971d6;1.0",
      "pageCountQt": 17,
      "statusCode": "PENDING",
      "availability": "PUBLIC",
      "exhibitNumber": 1003
    }, {
      "filingDate": 1548997200000,
      "proceedingNumber": "IPR2019-00652",
      "artifactTypeCd": "EXHIBITS",
      "filingParty": "PETITIONER",
      "documentTitle": "Exhibit 1004 - Forshew",
      "contentManagementId": "workspace://SpacesStore/92e84c8f-f3bc-4210-8abf-dcc4fe53775e;1.0",
      "pageCountQt": 34,
      "statusCode": "PENDING",
      "availability": "PUBLIC",
      "exhibitNumber": 1004
    }],
    "twoThousandsExhibitsCount": 3,
    "twoThousandsExhibitsBag": [{
      "filingDate": 1558324800000,
      "proceedingNumber": "IPR2019-00652",
      "artifactTypeCd": "EXHIBITS",
      "filingParty": "PATENT OWNER",
      "documentTitle": "EX2001 - REDACTED - Guardant opening CC brief",
      "contentManagementId": "workspace://SpacesStore/465b2a32-1b37-4cdb-b744-4a767ec2e331;1.0",
      "pageCountQt": 24,
      "statusCode": "PENDING",
      "availability": "PUBLIC",
      "exhibitNumber": 2001
    }, {
      "filingDate": 1558324800000,
      "proceedingNumber": "IPR2019-00652",
      "artifactTypeCd": "EXHIBITS",
      "filingParty": "PATENT OWNER",
      "documentTitle": "EX2002 - Perakis",
      "contentManagementId": "workspace://SpacesStore/bffd4d58-d5f0-4be5-8f5e-09a86bbe0401;1.0",
      "pageCountQt": 81,
      "statusCode": "PENDING",
      "availability": "PUBLIC",
      "exhibitNumber": 2002
    }, {
      "filingDate": 1558324800000,
      "proceedingNumber": "IPR2019-00652",
      "artifactTypeCd": "EXHIBITS",
      "filingParty": "PATENT OWNER",
      "documentTitle": "EX2003 - Lennon 2016",
      "contentManagementId": "workspace://SpacesStore/d6a49910-676a-45bb-8eed-8204acf61098;1.0",
      "pageCountQt": 10,
      "statusCode": "PENDING",
      "availability": "PUBLIC",
      "exhibitNumber": 2003
    }],
    "threeThousandsExhibitsCount": 1,
    "threeThousandsExhibitsBag": [{
      "filingDate": 1569384000000,
      "proceedingNumber": "IPR2019-00652",
      "artifactTypeCd": "EXHIBITS",
      "filingParty": "BOARD",
      "documentTitle": "Exhibit 3001",
      "contentManagementId": "workspace://SpacesStore/20456c20-6877-40d1-bceb-cd1b03b95ce8;1.0",
      "pageCountQt": 5,
      "statusCode": "PENDING",
      "availability": "PUBLIC",
      "exhibitNumber": 3001
    }]
  };
  const allaPapersObj =  {
    allPapersCount: 3,
    allPapersBag: [
        {
      "filingDate": 1548997200000,
      "proceedingNumber": "IPR2019-00652",
      "artifactTypeCd": "PAPER",
      "filingParty": "PETITIONER",
      "fileName": "Power of Attorney",
      "documentTitle": "Petitioner's Power of Attorney",
      "contentManagementId": "workspace://SpacesStore/2bd09bd2-e401-4cd3-b62e-c110e2c79710;1.0",
      "paperNumber": 1,
      "pageCountQt": 2,
      "statusCode": "PENDING",
      "availability": "PUBLIC"
    }, {
      "filingDate": 1548997200000,
      "proceedingNumber": "IPR2019-00652",
      "artifactTypeCd": "PAPER",
      "filingParty": "PETITIONER",
      "fileName": "Petition",
      "documentTitle": "Petition for Inter Partes Review",
      "contentManagementId": "workspace://SpacesStore/1f962780-74d1-4bb8-877b-9fa2b50d3d5e;1.0",
      "paperNumber": 2,
      "pageCountQt": 90,
      "statusCode": "PENDING",
      "availability": "PUBLIC"
    }]
  };


  const allPapersMock = paperCasesResp.allPapersBag;
  const allExhibitsMock = exhibitCasesResp.allExhibitsBag;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, NgbModule],
      declarations: [DocumentsComponent],
      providers: [
        CommonUtilitiesService,
        DatePipe,
        JpViewService,
        TrialsService,
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        },
        BsModalService,
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useValue: {}
        },
        {
          provide: ToastrService,
          useValue: toastrService
        },
        provideMockStore({
          selectors: [
            { selector: CaseViewerSelectors.caseInfoData, value: { proceedingNo: '37553565' } },
            {selector: CaseViewerSelectors.userInfoData,value:{caseDetailsData: []}}
          ]
        }),
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [CommonUtilitiesService] });
    fixture = TestBed.createComponent(DocumentsComponent);
    commonUtils = TestBed.inject(CommonUtilitiesService);
    jpViewService = TestBed.inject(JpViewService);
    trialsService = TestBed.inject(TrialsService);
    modalService = TestBed.inject(BsModalService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });



  it('should create', () => {
    expect(component).toBeTruthy();
  });



  it('should call getPaperDocuments and get response', () => {
    spyOn(jpViewService, 'getDocuments').and.returnValue(of(paperCasesResp));
    component.allPaperCases = allaPapersObj;

    component.getPaperDocuments();
//    expect(component.allPaperCases).toEqual(paperCasesResp);
  });



  it('should call getExhibitDocuments and get response', () => {
    spyOn(jpViewService, 'getDocuments').and.returnValue(of(exhibitCasesResp));
    component.allExhibitCases = allExhibitsObj;
    component.getExhibitDocuments();
  //  expect(component.allExhibitCases).toEqual(exhibitCasesResp);
  });


  it('should change to all papers', () => {
    component.allPaperCases = {
      "allPapersCount": 3,
      "allPapersBag": [
          {
        "filingDate": 1548997200000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "PAPER",
        "filingParty": "PETITIONER",
        "fileName": "Power of Attorney",
        "documentTitle": "Petitioner's Power of Attorney",
        "contentManagementId": "workspace://SpacesStore/2bd09bd2-e401-4cd3-b62e-c110e2c79710;1.0",
        "paperNumber": 1,
        "pageCountQt": 2,
        "statusCode": "PENDING",
        "availability": "PUBLIC"
      }, {
        "filingDate": 1548997200000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "PAPER",
        "filingParty": "PETITIONER",
        "fileName": "Petition",
        "documentTitle": "Petition for Inter Partes Review",
        "contentManagementId": "workspace://SpacesStore/1f962780-74d1-4bb8-877b-9fa2b50d3d5e;1.0",
        "paperNumber": 2,
        "pageCountQt": 90,
        "statusCode": "PENDING",
        "availability": "PUBLIC"
      }, {
        "filingDate": 1550638800000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "PAPER",
        "filingParty": "BOARD",
        "fileName": "Notice of Filing Date Accorded to Petition",
        "documentTitle": "Notice of Accord Filing Date",
        "contentManagementId": "workspace://SpacesStore/d678d8e5-a71a-417c-b108-cc026248b993;1.0",
        "paperNumber": 3,
        "pageCountQt": 5,
        "statusCode": "PENDING",
        "availability": "PUBLIC"
      }],
      "boardPapersCount": 3,
      "boardPapersBag": [{
        "filingDate": 1550638800000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "PAPER",
        "filingParty": "BOARD",
        "fileName": "Notice of Filing Date Accorded to Petition",
        "documentTitle": "Notice of Accord Filing Date",
        "contentManagementId": "workspace://SpacesStore/d678d8e5-a71a-417c-b108-cc026248b993;1.0",
        "paperNumber": 3,
        "pageCountQt": 5,
        "statusCode": "PENDING",
        "availability": "PUBLIC"
      }, {
        "filingDate": 1560139200000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "PAPER",
        "filingParty": "BOARD",
        "fileName": "Order",
        "documentTitle": "Granting Petitioner's Motion for Pro Hac Vice\nAdmission of Eric J. Marandett\n37 C.F.R. sec. 42.10",
        "contentManagementId": "workspace://SpacesStore/1eeadb4d-391a-40a0-9101-0706cb2a6b68;1.0",
        "paperNumber": 8,
        "pageCountQt": 4,
        "statusCode": "PENDING",
        "availability": "PUBLIC"
      }, {
        "filingDate": 1560484800000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "PAPER",
        "filingParty": "BOARD",
        "fileName": "Order",
        "documentTitle": "Conduct of the Proceeding\n37 C.F.R. sec. 42.5",
        "contentManagementId": "workspace://SpacesStore/ccfd388e-3cf4-4543-b020-f9357e132cf7;1.0",
        "paperNumber": 9,
        "pageCountQt": 3,
        "statusCode": "PENDING",
        "availability": "PUBLIC"
      }],
      "petitionerPapersCount": 3,
      "petitionerPapersBag": [{
        "filingDate": 1548997200000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "PAPER",
        "filingParty": "PETITIONER",
        "fileName": "Power of Attorney",
        "documentTitle": "Petitioner's Power of Attorney",
        "contentManagementId": "workspace://SpacesStore/2bd09bd2-e401-4cd3-b62e-c110e2c79710;1.0",
        "paperNumber": 1,
        "pageCountQt": 2,
        "statusCode": "PENDING",
        "availability": "PUBLIC"
      }, {
        "filingDate": 1548997200000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "PAPER",
        "filingParty": "PETITIONER",
        "fileName": "Petition",
        "documentTitle": "Petition for Inter Partes Review",
        "contentManagementId": "workspace://SpacesStore/1f962780-74d1-4bb8-877b-9fa2b50d3d5e;1.0",
        "paperNumber": 2,
        "pageCountQt": 90,
        "statusCode": "PENDING",
        "availability": "PUBLIC"
      }, {
        "filingDate": 1559016000000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "PAPER",
        "filingParty": "PETITIONER",
        "fileName": "Motion",
        "documentTitle": "PETITIONER¿¿¿S MOTION FOR PRO HAC VICE ADMISSION - Marandett",
        "contentManagementId": "workspace://SpacesStore/250be8b5-daf3-4574-877a-c023e3d771b1;1.0",
        "paperNumber": 7,
        "pageCountQt": 12,
        "statusCode": "PENDING",
        "availability": "PUBLIC"
      }],
      "patentOwnerPapersCount": 3,
      "patentOwnerPapersBag": [{
        "filingDate": 1550811600000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "PAPER",
        "filingParty": "PATENT OWNER",
        "fileName": "Mandatory Notice",
        "documentTitle": "Patent Owner's Mandatory Notices",
        "contentManagementId": "workspace://SpacesStore/1cacc396-da89-45f6-abb5-1389f1a8e3f2;1.0",
        "paperNumber": 4,
        "pageCountQt": 5,
        "statusCode": "PENDING",
        "availability": "PUBLIC"
      }, {
        "filingDate": 1550811600000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "PAPER",
        "filingParty": "PATENT OWNER",
        "fileName": "Power of Attorney",
        "documentTitle": "Patent Owner's Power of Attorney",
        "contentManagementId": "workspace://SpacesStore/0e949c01-3193-4f1f-a855-1f824f242d0c;1.0",
        "paperNumber": 5,
        "pageCountQt": 2,
        "statusCode": "PENDING",
        "availability": "PUBLIC"
      }, {
        "filingDate": 1558324800000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "PAPER",
        "filingParty": "PATENT OWNER",
        "fileName": "Preliminary Response",
        "documentTitle": "Patent Owner's Preliminary Response",
        "contentManagementId": "workspace://SpacesStore/b374296f-be35-4143-b886-fdc4e4e9d218;1.0",
        "paperNumber": 6,
        "pageCountQt": 46,
        "statusCode": "PENDING",
        "availability": "PUBLIC"
      }]
    };
    component.changeParty('allPapersBag');
    // expect(component.papers.length).toEqual(allPapersMock.length);
    // expect(component.papers.length).toEqual(component.allPaperCases.allPapersBag.length);
  });


  it('should change to all exhibits', () => {
    component.allExhibitCases = {
      "allExhibitsCount": 5,
      "allExhibitsBag": [{
        "filingDate": 1548997200000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "EXHIBITS",
        "filingParty": "PETITIONER",
        "documentTitle": "Exhibit 1001 - U.S. Patent No. 9,834,822",
        "contentManagementId": "workspace://SpacesStore/669082fd-4492-4346-9110-22519c86c377;1.0",
        "pageCountQt": 56,
        "statusCode": "PENDING",
        "availability": "PUBLIC",
        "exhibitNumber": 1001
      }, {
        "filingDate": 1548997200000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "EXHIBITS",
        "filingParty": "PETITIONER",
        "documentTitle": "Exhibit 1002 - Gabriel Declaration",
        "contentManagementId": "workspace://SpacesStore/2970f0a5-cfde-489f-9299-766a566dd0c7;1.0",
        "pageCountQt": 104,
        "statusCode": "PENDING",
        "availability": "PUBLIC",
        "exhibitNumber": 1002
      }, {
        "filingDate": 1548997200000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "EXHIBITS",
        "filingParty": "PETITIONER",
        "documentTitle": "Exhibit 1003 - Gabriel CV",
        "contentManagementId": "workspace://SpacesStore/3f938e5a-1abd-46a9-9c36-de33d00971d6;1.0",
        "pageCountQt": 17,
        "statusCode": "PENDING",
        "availability": "PUBLIC",
        "exhibitNumber": 1003
      }, {
        "filingDate": 1548997200000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "EXHIBITS",
        "filingParty": "PETITIONER",
        "documentTitle": "Exhibit 1004 - Forshew",
        "contentManagementId": "workspace://SpacesStore/92e84c8f-f3bc-4210-8abf-dcc4fe53775e;1.0",
        "pageCountQt": 34,
        "statusCode": "PENDING",
        "availability": "PUBLIC",
        "exhibitNumber": 1004
      }, {
        "filingDate": 1548997200000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "EXHIBITS",
        "filingParty": "PETITIONER",
        "documentTitle": "Exhibit 1005 - Meyerson",
        "contentManagementId": "workspace://SpacesStore/9aff9fc0-d890-4732-ac75-bde90ba98aa5;1.0",
        "pageCountQt": 12,
        "statusCode": "PENDING",
        "availability": "PUBLIC",
        "exhibitNumber": 1005
      }],
      "thousandsExhibitsCount": 4,
      "thousandsExhibitsBag": [{
        "filingDate": 1548997200000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "EXHIBITS",
        "filingParty": "PETITIONER",
        "documentTitle": "Exhibit 1001 - U.S. Patent No. 9,834,822",
        "contentManagementId": "workspace://SpacesStore/669082fd-4492-4346-9110-22519c86c377;1.0",
        "pageCountQt": 56,
        "statusCode": "PENDING",
        "availability": "PUBLIC",
        "exhibitNumber": 1001
      }, {
        "filingDate": 1548997200000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "EXHIBITS",
        "filingParty": "PETITIONER",
        "documentTitle": "Exhibit 1002 - Gabriel Declaration",
        "contentManagementId": "workspace://SpacesStore/2970f0a5-cfde-489f-9299-766a566dd0c7;1.0",
        "pageCountQt": 104,
        "statusCode": "PENDING",
        "availability": "PUBLIC",
        "exhibitNumber": 1002
      }, {
        "filingDate": 1548997200000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "EXHIBITS",
        "filingParty": "PETITIONER",
        "documentTitle": "Exhibit 1003 - Gabriel CV",
        "contentManagementId": "workspace://SpacesStore/3f938e5a-1abd-46a9-9c36-de33d00971d6;1.0",
        "pageCountQt": 17,
        "statusCode": "PENDING",
        "availability": "PUBLIC",
        "exhibitNumber": 1003
      }, {
        "filingDate": 1548997200000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "EXHIBITS",
        "filingParty": "PETITIONER",
        "documentTitle": "Exhibit 1004 - Forshew",
        "contentManagementId": "workspace://SpacesStore/92e84c8f-f3bc-4210-8abf-dcc4fe53775e;1.0",
        "pageCountQt": 34,
        "statusCode": "PENDING",
        "availability": "PUBLIC",
        "exhibitNumber": 1004
      }],
      "twoThousandsExhibitsCount": 3,
      "twoThousandsExhibitsBag": [{
        "filingDate": 1558324800000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "EXHIBITS",
        "filingParty": "PATENT OWNER",
        "documentTitle": "EX2001 - REDACTED - Guardant opening CC brief",
        "contentManagementId": "workspace://SpacesStore/465b2a32-1b37-4cdb-b744-4a767ec2e331;1.0",
        "pageCountQt": 24,
        "statusCode": "PENDING",
        "availability": "PUBLIC",
        "exhibitNumber": 2001
      }, {
        "filingDate": 1558324800000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "EXHIBITS",
        "filingParty": "PATENT OWNER",
        "documentTitle": "EX2002 - Perakis",
        "contentManagementId": "workspace://SpacesStore/bffd4d58-d5f0-4be5-8f5e-09a86bbe0401;1.0",
        "pageCountQt": 81,
        "statusCode": "PENDING",
        "availability": "PUBLIC",
        "exhibitNumber": 2002
      }, {
        "filingDate": 1558324800000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "EXHIBITS",
        "filingParty": "PATENT OWNER",
        "documentTitle": "EX2003 - Lennon 2016",
        "contentManagementId": "workspace://SpacesStore/d6a49910-676a-45bb-8eed-8204acf61098;1.0",
        "pageCountQt": 10,
        "statusCode": "PENDING",
        "availability": "PUBLIC",
        "exhibitNumber": 2003
      }],
      "threeThousandsExhibitsCount": 1,
      "threeThousandsExhibitsBag": [{
        "filingDate": 1569384000000,
        "proceedingNumber": "IPR2019-00652",
        "artifactTypeCd": "EXHIBITS",
        "filingParty": "BOARD",
        "documentTitle": "Exhibit 3001",
        "contentManagementId": "workspace://SpacesStore/20456c20-6877-40d1-bceb-cd1b03b95ce8;1.0",
        "pageCountQt": 5,
        "statusCode": "PENDING",
        "availability": "PUBLIC",
        "exhibitNumber": 3001
      }]
    };
    component.changeExhibits('allExhibitsBag');
    // expect(component.exhibits.length).toEqual(allExhibitsMock.length);
  });



  it('should sort columns ascending with paper', () => {
    component.orderByField = ["filingDate"];
    component.papers.data = allaPapersObj.allPapersBag;
    component.sortColumns('filingDate', 'p');
  });


  it('should sort columns decending with paper', () => {
    component.orderByField = ["-filingDate"];
    component.papers.data = allaPapersObj.allPapersBag;
    component.sortColumns('-filingDate', 'p');
  });


  it('should sort columns ascending with exhibit', () => {
    component.orderByField = ["filingDate"];
    component.exhibits.data = allExhibitsObj.allExhibitsBag;
    component.sortColumns('filingDate', 'e');
  });


  it('should sort columns decending with exhibit', () => {
    component.orderByField = ["-filingDate"];
    component.exhibits.data = allExhibitsObj.allExhibitsBag;
    component.sortColumns('-filingDate', 'e');
  });

  it('should setup papers count', () => {
    component.allPaperCases=allaPapersObj;
    component.setPapersCount();
  });

  it('should setup papers count', () => {
const getDocs = [{"documentNumber":3,"name":"Notice of Accord Filing Date","category":"PAPER","fileName":"IPR2020-01453 NOFDA.pdf","filingParty":"BOARD","availability":"Public","documentTypeIdentifier":7,"documentTypeCode":"NOFDA","documentTypeDescription":"Notice of Filing Date Accorded to Petition","pageCount":5,"contentManagementId":"workspace://SpacesStore/0dc6c06b-470f-4152-a2ce-fef7de7ae516;1.0","artifactIdentifer":170008652,"artifactSubmissionIdentifier":85357176,"filingDate":1599747857,"filingDateString":"09/10/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"BOARD","descriptionText":"Board","displayNameText":"Board"},"artifactSummary":{"code":"PAPER","descriptionText":"Paper"}},{"name":"File History of U.S. Patent No. 8,900,294_Part 2","category":"EXHIBITS","fileName":"Ex. 1003 US8900294_FH_Part2.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1003,"pageCount":1019,"contentManagementId":"workspace://SpacesStore/f4056a1d-2e17-439b-8bec-80cfaf776683;1.0","artifactIdentifer":170005786,"artifactSubmissionIdentifier":85354230,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"U.S. Patent No. 4,056,854_Boretos","category":"EXHIBITS","fileName":"Ex. 1004 US4056854_Boretos.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1004,"pageCount":6,"contentManagementId":"workspace://SpacesStore/6954d721-104a-4fcc-89e9-8aae4ee87fba;1.0","artifactIdentifer":170005787,"artifactSubmissionIdentifier":85354231,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"WO0015147_Phelps","category":"EXHIBITS","fileName":"Ex. 1010 WO2000015147_Phelps.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1010,"pageCount":80,"contentManagementId":"workspace://SpacesStore/67c6de0c-2db0-4d49-887e-1ccebb577446;1.0","artifactIdentifer":170005788,"artifactSubmissionIdentifier":85354232,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"WO9829057_Letac","category":"EXHIBITS","fileName":"Ex. 1012 WO1998029057_Letac.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1012,"pageCount":67,"contentManagementId":"workspace://SpacesStore/9b35b757-b542-4fbf-b40d-c52e174c3cca;1.0","artifactIdentifer":170005789,"artifactSubmissionIdentifier":85354233,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"U.S. Patent No. 5,840,081_Andersen","category":"EXHIBITS","fileName":"Ex. 1013 US5840081_Andersen.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1013,"pageCount":10,"contentManagementId":"workspace://SpacesStore/fed0885c-e832-4b4f-bfa7-524a0d30a0d7;1.0","artifactIdentifer":170005791,"artifactSubmissionIdentifier":85354235,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"U.S. Patent No. 6,676,698_McGuckin","category":"EXHIBITS","fileName":"Ex. 1014 US6676698_McGuckin.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1014,"pageCount":48,"contentManagementId":"workspace://SpacesStore/0beb1760-b91d-44ab-bf2f-02e3189a470f;1.0","artifactIdentifer":170005792,"artifactSubmissionIdentifier":85354236,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"U.S. Patent No. 8,900,294","category":"EXHIBITS","fileName":"Ex. 1001 US8900294.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1001,"pageCount":26,"contentManagementId":"workspace://SpacesStore/bdea425d-5516-4738-ac18-f94f88720072;1.0","artifactIdentifer":170005802,"artifactSubmissionIdentifier":85354215,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Declaration of William J. Drasler","category":"EXHIBITS","fileName":"Ex. 1002 Drasler Declaration.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1002,"pageCount":133,"contentManagementId":"workspace://SpacesStore/fdf89b09-5283-43bf-9998-6e217e7702c3;1.0","artifactIdentifer":170005803,"artifactSubmissionIdentifier":85354216,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"File History of U.S. Patent No. 8,900,294_Part 1","category":"EXHIBITS","fileName":"Ex. 1003 US8900294_FH_Part1.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1003,"pageCount":1020,"contentManagementId":"workspace://SpacesStore/c8e1d0d3-0da2-4d6c-a482-3e8800e815ca;1.0","artifactIdentifer":170005804,"artifactSubmissionIdentifier":85354237,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"U.S. Patent No. 6,425,916_Garrison","category":"EXHIBITS","fileName":"Ex. 1005 US6425916_Garrison.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1005,"pageCount":30,"contentManagementId":"workspace://SpacesStore/cff03fa1-2c65-45d3-8e87-560025706e7a;1.0","artifactIdentifer":170005805,"artifactSubmissionIdentifier":85354238,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"U.S. Patent No. 5,957,949_Leonhardt","category":"EXHIBITS","fileName":"Ex. 1006 US5957949_Leonhardt.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1006,"pageCount":18,"contentManagementId":"workspace://SpacesStore/c3679557-dc3b-4a7d-893e-5947c55ae4a8;1.0","artifactIdentifer":170005806,"artifactSubmissionIdentifier":85354239,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"U.S. Patent No. 6,440,164_DiMatteo","category":"EXHIBITS","fileName":"Ex. 1007 US6440164_DiMatteo.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1007,"pageCount":18,"contentManagementId":"workspace://SpacesStore/8d3db54a-2401-4213-918e-bcce340a52aa;1.0","artifactIdentifer":170005807,"artifactSubmissionIdentifier":85354240,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"U.S. Patent No. 6,077,295_Limon","category":"EXHIBITS","fileName":"Ex. 1008 US6077295_Limon.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1008,"pageCount":14,"contentManagementId":"workspace://SpacesStore/aaaa998c-4f85-4c55-8aa3-a3da7e1fbdcf;1.0","artifactIdentifer":170005808,"artifactSubmissionIdentifier":85354241,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"U.S. Patent No. 7,025,780_Gabbay","category":"EXHIBITS","fileName":"Ex. 1009 US7025780_Gabbay.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1009,"pageCount":13,"contentManagementId":"workspace://SpacesStore/8e2be28e-bc17-4e13-aa41-87ce6e9d3f8d;1.0","artifactIdentifer":170005809,"artifactSubmissionIdentifier":85354242,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"File History of U.S. Patent 9,125,739_Part 1","category":"EXHIBITS","fileName":"Ex. 1011 US9125739_ FH_Part1.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1011,"pageCount":1109,"contentManagementId":"workspace://SpacesStore/57ee0349-4477-4dda-9833-2fa2b8ba13a4;1.0","artifactIdentifer":170005810,"artifactSubmissionIdentifier":85354243,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"File History of U.S. Patent 9,125,739_Part 2","category":"EXHIBITS","fileName":"Ex. 1011 US9125739_ FH_Part2.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1011,"pageCount":1109,"contentManagementId":"workspace://SpacesStore/10d2d0f6-44bc-4c80-9b2d-7df9d1b32283;1.0","artifactIdentifer":170005811,"artifactSubmissionIdentifier":85354244,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"File History of U.S. Patent Application No. 09/659,882","category":"EXHIBITS","fileName":"Ex. 1015 US09659882_FH.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1015,"pageCount":134,"contentManagementId":"workspace://SpacesStore/3b9f3f87-6798-40c7-995d-d834fc55faff;1.0","artifactIdentifer":170005812,"artifactSubmissionIdentifier":85354245,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"File History of U.S. Patent Application No. 10/887,688_Part 1","category":"EXHIBITS","fileName":"Ex. 1016 US10887688_FH_Part1.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1016,"pageCount":721,"contentManagementId":"workspace://SpacesStore/5f16b03a-0259-4e42-a22c-4d0f483a642a;1.0","artifactIdentifer":170005813,"artifactSubmissionIdentifier":85354246,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"File History of U.S. Patent Application No. 10/887,688_Part 2","category":"EXHIBITS","fileName":"Ex. 1016 US10887688_FH_Part2.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1016,"pageCount":720,"contentManagementId":"workspace://SpacesStore/0db87059-a1f4-442a-8b81-9f4f206c227d;1.0","artifactIdentifer":170005814,"artifactSubmissionIdentifier":85354247,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"File History of U.S. Patent Application No. 13/675,665_Part 1","category":"EXHIBITS","fileName":"Ex. 1017 US13675665_FH_Part1.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1017,"pageCount":1160,"contentManagementId":"workspace://SpacesStore/dadc8d46-1891-4c0d-8e84-9f10b5d1a039;1.0","artifactIdentifer":170005815,"artifactSubmissionIdentifier":85354248,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"AneuRX Stent Graft System","category":"EXHIBITS","fileName":"Ex. 1019 AneuRX Stent Graft System.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1019,"pageCount":41,"contentManagementId":"workspace://SpacesStore/702f7acb-5e8a-422d-8cea-749f5af3746f;1.0","artifactIdentifer":170005816,"artifactSubmissionIdentifier":85354249,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"U.S. Patent No. 5,713,950_Cox","category":"EXHIBITS","fileName":"Ex. 1021 US5713950_Cox.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1021,"pageCount":21,"contentManagementId":"workspace://SpacesStore/a2f649fb-374a-4db9-8936-14d76a45dc21;1.0","artifactIdentifer":170005817,"artifactSubmissionIdentifier":85354250,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"documentNumber":2,"name":"Petition for Inter Partes Review of U.S. Patent No. 8,900,294","category":"PAPER","fileName":"IPR2020-01453 Petition.pdf","filingParty":"PETITIONER","availability":"Public","documentTypeIdentifier":16,"documentTypeCode":"PETITION","documentTypeDescription":"Petition","pageCount":80,"contentManagementId":"workspace://SpacesStore/ee48a498-4d14-4af4-bb32-f1eca8a0ea23;1.0","artifactIdentifer":170005818,"artifactSubmissionIdentifier":85354251,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"PAPER","descriptionText":"Paper"}},{"name":"File History of U.S. Patent Application No. 13/675,665_Part 2","category":"EXHIBITS","fileName":"Ex. 1017 US13675665_FH_Part2.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1017,"pageCount":1159,"contentManagementId":"workspace://SpacesStore/11863f52-e81d-4754-8f87-085355003cea;1.0","artifactIdentifer":170005833,"artifactSubmissionIdentifier":85354257,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"File History of U.S. Patent Application No. 10/037,266","category":"EXHIBITS","fileName":"Ex. 1018 US10037266_FH.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1018,"pageCount":115,"contentManagementId":"workspace://SpacesStore/13b2318f-ab14-4b7a-b1a8-871008e816db;1.0","artifactIdentifer":170005834,"artifactSubmissionIdentifier":85354258,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Screenshot of Docket Navigator","category":"EXHIBITS","fileName":"Ex. 1022 Screenshot of Docket Navigator.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1022,"pageCount":1,"contentManagementId":"workspace://SpacesStore/c8423abb-27e1-4a43-a16d-0b9ef2cda4e8;1.0","artifactIdentifer":170005835,"artifactSubmissionIdentifier":85354259,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Stipulation Regarding IPRs","category":"EXHIBITS","fileName":"Ex. 1023 Stipulation.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1023,"pageCount":1,"contentManagementId":"workspace://SpacesStore/5b7c6e7c-6dbe-4294-b092-ab70c0d21efc;1.0","artifactIdentifer":170005836,"artifactSubmissionIdentifier":85354260,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Declaration of Crena Pacheco","category":"EXHIBITS","fileName":"Ex. 1024 Declaration of Crena Pacheco.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1024,"pageCount":8,"contentManagementId":"workspace://SpacesStore/13dc54c3-bd11-45a9-9c39-0cd468b8cd1b;1.0","artifactIdentifer":170005837,"artifactSubmissionIdentifier":85354261,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"documentNumber":1,"name":"Power of Attorney","category":"PAPER","fileName":"IPR2020-01453 Power of Attorney.pdf","filingParty":"PETITIONER","availability":"Public","documentTypeIdentifier":17,"documentTypeCode":"PWR ATTY","documentTypeDescription":"Power of Attorney","pageCount":3,"contentManagementId":"workspace://SpacesStore/372aa5fc-410e-4f5b-b1b7-e2036465be17;1.0","artifactIdentifer":170005838,"artifactSubmissionIdentifier":85354262,"filingDate":1599086668,"filingDateString":"09/02/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"PAPER","descriptionText":"Paper"}},{"documentNumber":4,"name":"Patent Owner's Mandatory Notices","category":"PAPER","fileName":"2020.09.23 Patent Owner's Mandatory Notice 294 (IPR2020-01453).pdf","filingParty":"PATENT OWNER","availability":"Public","documentTypeIdentifier":37,"documentTypeCode":"MN","documentTypeDescription":"Mandatory Notice","pageCount":4,"contentManagementId":"workspace://SpacesStore/804d1bf5-fbf8-4d8f-a492-96dd87f5f1c6;1.0","artifactIdentifer":170015015,"artifactSubmissionIdentifier":85363459,"filingDate":1600891055,"filingDateString":"09/23/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"PAPER","descriptionText":"Paper"}},{"documentNumber":5,"name":"Patent Owner's Power of Attorney","category":"PAPER","fileName":"2020.09.23 Patent Owner's POA 294 (IPR2020-01453).pdf","filingParty":"PATENT OWNER","availability":"Public","documentTypeIdentifier":17,"documentTypeCode":"PWR ATTY","documentTypeDescription":"Power of Attorney","pageCount":4,"contentManagementId":"workspace://SpacesStore/c8f8b9d5-4b74-4651-a319-66ef9bcfe45f;1.0","artifactIdentifer":170015016,"artifactSubmissionIdentifier":85363460,"filingDate":1600891055,"filingDateString":"09/23/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"PAPER","descriptionText":"Paper"}},{"documentNumber":6,"name":"Patent Owner's Preliminary Response","category":"PAPER","fileName":"2020.12.10 POPR for IPR2020-01453 (Medtronic 294).pdf","filingParty":"PATENT OWNER","availability":"Public","documentTypeIdentifier":18,"documentTypeCode":"PREL RESPONSE","documentTypeDescription":"Preliminary Response","pageCount":78,"contentManagementId":"workspace://SpacesStore/53dbded7-1b7a-47ac-9198-e4881fc57a86;1.0","artifactIdentifer":170053435,"artifactSubmissionIdentifier":85395884,"filingDate":1607625027,"filingDateString":"12/10/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"PAPER","descriptionText":"Paper"}},{"name":"Complaint for Patent Infringement","category":"EXHIBITS","fileName":"Ex. 2001 2020.05.04 D1 Complaint for Patent Infringement.pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2001,"pageCount":22,"contentManagementId":"workspace://SpacesStore/709675a9-831a-450c-b52d-7afb445ac869;1.0","artifactIdentifer":170053438,"artifactSubmissionIdentifier":85395887,"filingDate":1607625104,"filingDateString":"12/10/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Joint Rule 26(f) Report","category":"EXHIBITS","fileName":"Ex. 2002 2020.08.31 D48 Joint Rule 26(f) Report.pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2002,"pageCount":10,"contentManagementId":"workspace://SpacesStore/81dfd665-3253-41ef-ad2a-d23143d6a3f6;1.0","artifactIdentifer":170053439,"artifactSubmissionIdentifier":85395888,"filingDate":1607625174,"filingDateString":"12/10/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Scheduling Order & Order re Pretrial and Trial Procedures","category":"EXHIBITS","fileName":"Ex. 2003 2020.09.04 D53 Scheduling Order & Order re Pretrial and Trial Procedures.pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2003,"pageCount":11,"contentManagementId":"workspace://SpacesStore/57a4786d-dd82-40d2-926e-fa0e043bf829;1.0","artifactIdentifer":170053440,"artifactSubmissionIdentifier":85395889,"filingDate":1607625214,"filingDateString":"12/10/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Joint Stipulation and Request to Enter Proposed Orders","category":"EXHIBITS","fileName":"Ex. 2004 2020.11.20 D71 Joint Stipulation and Request to Enter [Proposed] Orders.pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2004,"pageCount":5,"contentManagementId":"workspace://SpacesStore/f740017a-cd8e-4536-9048-a65f51df36d5;1.0","artifactIdentifer":170053441,"artifactSubmissionIdentifier":85395890,"filingDate":1607625250,"filingDateString":"12/10/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Order Regarding Case Schedule","category":"EXHIBITS","fileName":"Ex. 2005 2020.11.24 D73 Order Regarding Case Schedule (Granting D71-1).pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2005,"pageCount":4,"contentManagementId":"workspace://SpacesStore/8a594088-3d47-4c83-bb7e-b1da1ad3992d;1.0","artifactIdentifer":170053442,"artifactSubmissionIdentifier":85395891,"filingDate":1607625287,"filingDateString":"12/10/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Medtronic's Notice of Motion and Motion to Stay Pending IPR Review","category":"EXHIBITS","fileName":"Ex. 2008 2020.09.04 D50 Medtronic's Notice of Motion and Motion to Stay Pending IPR Review.pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2008,"pageCount":13,"contentManagementId":"workspace://SpacesStore/cd79b189-235f-400b-a1c4-3300fd1992c5;1.0","artifactIdentifer":170053443,"artifactSubmissionIdentifier":85395892,"filingDate":1607625406,"filingDateString":"12/10/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Order Appointing Technical Special Master","category":"EXHIBITS","fileName":"Ex. 2006 2020.11.24 D75 Order Appointing Technical Special Master (71-3).pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2006,"pageCount":3,"contentManagementId":"workspace://SpacesStore/5ebc9cad-a717-4a37-8e57-25567d622a58;1.0","artifactIdentifer":170053451,"artifactSubmissionIdentifier":85395900,"filingDate":1607625314,"filingDateString":"12/10/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Medtronic's Proposed Claim Constructions","category":"EXHIBITS","fileName":"Ex. 2007 Medtronic's Claim Construction Chart (2020-12-02).pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2007,"pageCount":5,"contentManagementId":"workspace://SpacesStore/b66daa18-8b8a-457d-b79e-f5fc5063e531;1.0","artifactIdentifer":170053453,"artifactSubmissionIdentifier":85395902,"filingDate":1607625370,"filingDateString":"12/10/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Declaration of Mieke K. Malmberg in Support of POPR (IPR2020-1453)","category":"EXHIBITS","fileName":"Ex. 2009 2020.12.10 Declaration of M. Malmberg in Support of POPR for IPR2020-01453 (Medtronic 294).pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2009,"pageCount":4,"contentManagementId":"workspace://SpacesStore/28023325-0822-45df-b3dd-5306caf83916;1.0","artifactIdentifer":170053455,"artifactSubmissionIdentifier":85395904,"filingDate":1607625471,"filingDateString":"12/10/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Declaration of Sarah E. Spires in Support of POPR (IPR2020-1453)","category":"EXHIBITS","fileName":"Ex. 2011 2020.12.10 Declaration of S. Spires in Support of POPR for IPR2020-01453 (Medtronic 294).pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2011,"pageCount":5,"contentManagementId":"workspace://SpacesStore/246ebf0f-45e3-4e6d-8b8e-0b907d3826aa;1.0","artifactIdentifer":170053456,"artifactSubmissionIdentifier":85395905,"filingDate":1607625582,"filingDateString":"12/10/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Notice of Clerical Error","category":"EXHIBITS","fileName":"Ex. 2010 2020.09.08 D54 Notice of Clerical Error.pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2010,"pageCount":1,"contentManagementId":"workspace://SpacesStore/74043d11-1d3d-4c04-9661-59cee5a044ea;1.0","artifactIdentifer":170053465,"artifactSubmissionIdentifier":85395914,"filingDate":1607625544,"filingDateString":"12/10/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"documentNumber":7,"name":"Patent Owner's Exhibit List","category":"PAPER","fileName":"2020.12.10 Patent Owner's Exhibit List 294 (IPR2020-01453).pdf","filingParty":"PATENT OWNER","availability":"Public","documentTypeIdentifier":95,"documentTypeCode":"EXHIBIT LIST","documentTypeDescription":"Exhibit List","pageCount":5,"contentManagementId":"workspace://SpacesStore/80679a4a-e90a-45ce-810c-af2bc8e2e908;1.0","artifactIdentifer":170053535,"artifactSubmissionIdentifier":85395984,"filingDate":1607630101,"filingDateString":"12/10/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"PAPER","descriptionText":"Paper"}},{"documentNumber":8,"name":"Petitioners Reply Brief","category":"PAPER","fileName":"IPR2020-01453 Petitioners Reply.pdf","filingParty":"PETITIONER","availability":"Public","documentTypeIdentifier":19,"documentTypeCode":"REPLY","documentTypeDescription":"Reply","pageCount":11,"contentManagementId":"workspace://SpacesStore/144cf840-d77c-4f72-a9b2-59a513f94341;1.0","artifactIdentifer":170064301,"artifactSubmissionIdentifier":85406970,"filingDate":1610151336,"filingDateString":"01/08/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"PAPER","descriptionText":"Paper"}},{"name":"Stipulation Regarding IPRs","category":"EXHIBITS","fileName":"Ex. 1025 Stipulation.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1025,"pageCount":1,"contentManagementId":"workspace://SpacesStore/04f95d42-2e72-4d5a-a165-80c2b4972622;1.0","artifactIdentifer":170064302,"artifactSubmissionIdentifier":85406971,"filingDate":1610151377,"filingDateString":"01/08/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Shuthima_U.S. District Court Docket","category":"EXHIBITS","fileName":"Ex. 1027 8_19cv1628, Shuthima Pongsai V. American Express Company Et Al.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1027,"pageCount":18,"contentManagementId":"workspace://SpacesStore/40b56a05-0716-4793-bdfd-c728ea60804d;1.0","artifactIdentifer":170064303,"artifactSubmissionIdentifier":85406972,"filingDate":1610151582,"filingDateString":"01/08/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"General Order 20-12","category":"EXHIBITS","fileName":"Ex. 1028 General Order 20-12.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1028,"pageCount":3,"contentManagementId":"workspace://SpacesStore/8def9e3d-0d32-4320-986a-e7bb166847a9;1.0","artifactIdentifer":170064304,"artifactSubmissionIdentifier":85406973,"filingDate":1610151605,"filingDateString":"01/08/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Jane Doe_U.S. District Court Docket","category":"EXHIBITS","fileName":"Ex. 1026 Jane Doe Et Al V. Xavier Becerra - Continuous punting of trial.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1026,"pageCount":16,"contentManagementId":"workspace://SpacesStore/8619ba2f-f152-45ab-96d1-120f0be2b7f3;1.0","artifactIdentifer":170064307,"artifactSubmissionIdentifier":85406976,"filingDate":1610151546,"filingDateString":"01/08/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"General Order 20-15","category":"EXHIBITS","fileName":"Ex. 1029 General Order 20-15.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1029,"pageCount":2,"contentManagementId":"workspace://SpacesStore/4f9d1ddd-58d2-4ce3-844a-9aada3295f28;1.0","artifactIdentifer":170064308,"artifactSubmissionIdentifier":85406977,"filingDate":1610151624,"filingDateString":"01/08/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"General Order 20-05","category":"EXHIBITS","fileName":"Ex. 1030 GO 20-05_0.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1030,"pageCount":3,"contentManagementId":"workspace://SpacesStore/dfd8f17b-ea6a-425c-a605-a06cccdee63f;1.0","artifactIdentifer":170064309,"artifactSubmissionIdentifier":85406978,"filingDate":1610151658,"filingDateString":"01/08/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"General Order 20-08","category":"EXHIBITS","fileName":"Ex. 1031 GO 20-08 Amended.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1031,"pageCount":4,"contentManagementId":"workspace://SpacesStore/95ff00f6-8be1-463e-9504-41e5742808f4;1.0","artifactIdentifer":170064310,"artifactSubmissionIdentifier":85406979,"filingDate":1610151683,"filingDateString":"01/08/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Order of the Chief Judge 20-042","category":"EXHIBITS","fileName":"Ex. 1033 Order_20-042.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1033,"pageCount":3,"contentManagementId":"workspace://SpacesStore/0bef3db0-f65b-4373-ac07-0f13e8de14f8;1.0","artifactIdentifer":170064311,"artifactSubmissionIdentifier":85406980,"filingDate":1610151720,"filingDateString":"01/08/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Activation of Continuity of Operations Plan","category":"EXHIBITS","fileName":"Ex. 1034 Activation of the COOP Plan.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1034,"pageCount":2,"contentManagementId":"workspace://SpacesStore/141810a9-e9dd-4499-902a-6afcba53216d;1.0","artifactIdentifer":170064312,"artifactSubmissionIdentifier":85406981,"filingDate":1610151741,"filingDateString":"01/08/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Colibri Heart Valve_U.S. District Court Docket","category":"EXHIBITS","fileName":"Ex. 1036 CDCAL Docket.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1036,"pageCount":11,"contentManagementId":"workspace://SpacesStore/d6071786-34de-4842-81b2-7a2a84ede551;1.0","artifactIdentifer":170064313,"artifactSubmissionIdentifier":85406982,"filingDate":1610151832,"filingDateString":"01/08/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Extension of Continuity of Operations Plan","category":"EXHIBITS","fileName":"Ex. 1037 Extension of COOP.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1037,"pageCount":2,"contentManagementId":"workspace://SpacesStore/ba2a6dc1-f04e-4d8f-9a67-5417a673130b;1.0","artifactIdentifer":170064314,"artifactSubmissionIdentifier":85406983,"filingDate":1610151853,"filingDateString":"01/08/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Scheduling Order","category":"EXHIBITS","fileName":"Ex. 1038 Scheduling Order.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1038,"pageCount":4,"contentManagementId":"workspace://SpacesStore/53fbe592-2c72-4726-a73a-8af14213b233;1.0","artifactIdentifer":170064315,"artifactSubmissionIdentifier":85406984,"filingDate":1610151904,"filingDateString":"01/08/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"General Order 20-09","category":"EXHIBITS","fileName":"Ex. 1032 GO 20-09.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1032,"pageCount":4,"contentManagementId":"workspace://SpacesStore/cdbc3d6d-49b6-4c11-a23e-319496660483;1.0","artifactIdentifer":170064325,"artifactSubmissionIdentifier":85406994,"filingDate":1610151702,"filingDateString":"01/08/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Press Release_Activation of Continuity of Operations Plan","category":"EXHIBITS","fileName":"Ex. 1035 Press Release - Activation of the COOP Plan.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1035,"pageCount":1,"contentManagementId":"workspace://SpacesStore/ee8ba6f1-bb4d-402b-84ee-94414283265a;1.0","artifactIdentifer":170064326,"artifactSubmissionIdentifier":85406995,"filingDate":1610151786,"filingDateString":"01/08/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Order Granting Defendants Motion to Stay","category":"EXHIBITS","fileName":"Ex. 1039 05-08-2020 Civil Minutes.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1039,"pageCount":5,"contentManagementId":"workspace://SpacesStore/02fe177b-3207-4069-bfff-869ed4e7de4a;1.0","artifactIdentifer":170064327,"artifactSubmissionIdentifier":85406996,"filingDate":1610151971,"filingDateString":"01/08/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Declaration of Crena Pacheco","category":"EXHIBITS","fileName":"Ex. 1040 Declaration of Crena Pacheco.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1040,"pageCount":7,"contentManagementId":"workspace://SpacesStore/ed474c77-7e3e-45ad-9926-b48f85449a65;1.0","artifactIdentifer":170064328,"artifactSubmissionIdentifier":85406997,"filingDate":1610152014,"filingDateString":"01/08/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Judge Carter's Amended Calendar for Wednesday, January 13, 2021","category":"EXHIBITS","fileName":"Ex. 2014 - January 13, 2021 AMENDED CALENDAR.pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2014,"pageCount":2,"contentManagementId":"workspace://SpacesStore/dda7e07a-77cb-4cd3-a2a0-4804a4475a32;1.0","artifactIdentifer":170069302,"artifactSubmissionIdentifier":85411991,"filingDate":1611338972,"filingDateString":"01/22/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Declaration of Sarah E. Spires in Support of Sur-Reply to Patent Owner¿¿¿s Preliminary Response","category":"EXHIBITS","fileName":"Ex. 2018 2021.1.22 Declaration of S Spires in Support of Sur-Reply for IPR2020-01453 (Medtronic 294).pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2018,"pageCount":4,"contentManagementId":"workspace://SpacesStore/752f470b-3605-4528-9092-84d6081c5d94;1.0","artifactIdentifer":170069303,"artifactSubmissionIdentifier":85411992,"filingDate":1611339094,"filingDateString":"01/22/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"documentNumber":9,"name":"Sur-Reply to Patent Owner's Preliminary Response","category":"PAPER","fileName":"2021.01.22 Patent Owner's Sur-Reply to POPR for IPR2020-01453 (Medtronic 294).pdf","filingParty":"PATENT OWNER","availability":"Public","documentTypeIdentifier":19,"documentTypeCode":"REPLY","documentTypeDescription":"Reply","pageCount":8,"contentManagementId":"workspace://SpacesStore/c49a2bdd-7700-4e10-aca9-c7558e39a6d1;1.0","artifactIdentifer":170069311,"artifactSubmissionIdentifier":85412019,"filingDate":1611338802,"filingDateString":"01/22/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"PAPER","descriptionText":"Paper"}},{"documentNumber":10,"name":"Patent Owner's Updated Exhibit List","category":"PAPER","fileName":"2021.01.22 Patent Owner's Updated Exhibit List 294 (IPR2020-01453).pdf","filingParty":"PATENT OWNER","availability":"Public","documentTypeIdentifier":95,"documentTypeCode":"EXHIBIT LIST","documentTypeDescription":"Exhibit List","pageCount":5,"contentManagementId":"workspace://SpacesStore/10824a76-474c-4ad0-b747-a5da16626ce4;1.0","artifactIdentifer":170069312,"artifactSubmissionIdentifier":85412020,"filingDate":1611338839,"filingDateString":"01/22/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"PAPER","descriptionText":"Paper"}},{"name":"Stipulated Request to Suspend Case Schedule","category":"EXHIBITS","fileName":"Ex. 2012 Stipulated Request to Suspend Case Schedule.pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2012,"pageCount":5,"contentManagementId":"workspace://SpacesStore/f67425fd-910d-4539-9de7-be26c1e49414;1.0","artifactIdentifer":170069314,"artifactSubmissionIdentifier":85412022,"filingDate":1611338890,"filingDateString":"01/22/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Judge Carter's \"Judges' Requirements\"","category":"EXHIBITS","fileName":"Ex. 2013 - Honorable David O. Carter _ Central District of California _ United States District Court.pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2013,"pageCount":9,"contentManagementId":"workspace://SpacesStore/9d345c75-9a93-4169-b039-ffa285fea50c;1.0","artifactIdentifer":170069315,"artifactSubmissionIdentifier":85412023,"filingDate":1611338933,"filingDateString":"01/22/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Anthony Fauci offers a timeline for ending COVID-19 pandemic","category":"EXHIBITS","fileName":"Ex. 2015 - Anthony Fauci offers a timeline for ending COVID-19 pandemic ¿¿¿ Harvard Gazette.pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2015,"pageCount":4,"contentManagementId":"workspace://SpacesStore/3ff3826d-2654-474c-ac1d-f31faf043917;1.0","artifactIdentifer":170069317,"artifactSubmissionIdentifier":85412025,"filingDate":1611338995,"filingDateString":"01/22/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Email correspondence dated January 21, 2021","category":"EXHIBITS","fileName":"Ex. 2016 -  Re_ Colibri v. Medtronic, 8_20-cv-847 (C.D. Cal.) - Medtronic's Rebuttal Claim Construction Brief.pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2016,"pageCount":5,"contentManagementId":"workspace://SpacesStore/8141973e-5d72-4702-9119-db8d2e7693bc;1.0","artifactIdentifer":170069319,"artifactSubmissionIdentifier":85412027,"filingDate":1611339042,"filingDateString":"01/22/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Email correspondence dated December 2, 2020","category":"EXHIBITS","fileName":"Ex. 2017 Stipulation Regarding IPRs.pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2017,"pageCount":1,"contentManagementId":"workspace://SpacesStore/d67f09d6-4017-49b2-8597-eaf2123a9855;1.0","artifactIdentifer":170069320,"artifactSubmissionIdentifier":85412028,"filingDate":1611339061,"filingDateString":"01/22/2021","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}}]

    spyOn(trialsService, 'getDocumentsForUpdate').and.returnValue(of(getDocs));
    component.getDocuments();
  });

  it('should deselect all papers', () => {
    const selectedDocs = {
      valueToEmit: "none"
    };
    // component.allPaperCases = allaPapersObj;
    component.rowSelectionForPapers(selectedDocs);
  });


  it('should add to papers', () => {
    const selectedDocs = {
      valueToEmit: {
        contentManagementId: "workspace://SpacesStore/1eeadb4d-391a-40a0-9101-0706cb2a6b68;1.0"
      },
      row: {
        target: {
          checked: true
        }
      }
    };
    component.rowSelectionForPapers(selectedDocs);
  });


  it('should remove from papers', () => {
    const selectedDocs = {
      valueToEmit: {
        contentManagementId: "workspace://SpacesStore/1eeadb4d-391a-40a0-9101-0706cb2a6b68;1.0"
      },
      row: {
        target: {
          checked: false
        }
      }
    };
    component.papersToDownload.push("workspace://SpacesStore/1eeadb4d-391a-40a0-9101-0706cb2a6b68;1.0");
    component.rowSelectionForPapers(selectedDocs);
  });


  it('should select all exhibits', () => {
    const selectedDocs = {
      valueToEmit: "all"
    };
    component.allExhibitCases = allExhibitsObj;
    component.rowSelectionForExhibits(selectedDocs);
  });




  it('should deselect all exhibits', () => {
    const selectedDocs = {
      valueToEmit: "none"
    };
    // component.allPaperCases = allaPapersObj;
    component.rowSelectionForExhibits(selectedDocs);
  });


  it('should add to papers', () => {
    const selectedDocs = {
      valueToEmit: {
        contentManagementId: "workspace://SpacesStore/1eeadb4d-391a-40a0-9101-0706cb2a6b68;1.0"
      },
      row: {
        target: {
          checked: true
        }
      }
    };
    component.rowSelectionForExhibits(selectedDocs);
  });


  it('should remove from papers', () => {
    const selectedDocs = {
      valueToEmit: {
        contentManagementId: "workspace://SpacesStore/1eeadb4d-391a-40a0-9101-0706cb2a6b68;1.0"
      },
      row: {
        target: {
          checked: false
        }
      }
    };
    component.exhibitsToDownload.push("workspace://SpacesStore/1eeadb4d-391a-40a0-9101-0706cb2a6b68;1.0");
    component.rowSelectionForExhibits(selectedDocs);
  });



  it('should download selected documents', () => {
    component.papersToDownload.push("workspace://SpacesStore/1eeadb4d-391a-40a0-9101-0706cb2a6b68;1.0");
    component.exhibitsToDownload.push("workspace://SpacesStore/1eeadb4d-391a-40a0-9101-0706cb2a6b68;2.0");
    component.caseInfo.proceedingNo = "12345";
    const downloadEwfSuccessMock = "";
    let userName = {};
    spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
        return userName[key];
    });
    spyOn(trialsService, 'downloadEwf').and.returnValue(of(downloadEwfSuccessMock));
    component.downloadEwf('selected');
  });


  it('should download all papers', () => {
    component.allPaperCases = allaPapersObj;
    component.caseInfo.proceedingNo = "12345";
    const downloadEwfSuccessMock = "";
    let userName = {};
    spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
        return userName[key];
    });
    spyOn(trialsService, 'downloadEwf').and.returnValue(of(downloadEwfSuccessMock));
    component.downloadEwf('papers');
  });


  it('should download all exhibits', () => {
    component.allExhibitCases = allExhibitsObj;
    component.caseInfo.proceedingNo = "12345";
    const downloadEwfSuccessMock = "";
    let userName = {};
    spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
        return userName[key];
    });
    spyOn(trialsService, 'downloadEwf').and.returnValue(of(downloadEwfSuccessMock));
    component.downloadEwf('exhibits');
  });


  it('should download entire case', () => {
    component.allPaperCases = allaPapersObj;
    component.allExhibitCases = allExhibitsObj;
    component.caseInfo.proceedingNo = "12345";
    const downloadEwfSuccessMock = "";
    let userName = {};
    spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
        return userName[key];
    });
    spyOn(trialsService, 'downloadEwf').and.returnValue(of(downloadEwfSuccessMock));
    component.downloadEwf('case');
  });


  it('should fail trying to download', () => {
    component.allPaperCases = allaPapersObj;
    component.allExhibitCases = allExhibitsObj;
    component.caseInfo.proceedingNo = "12345";
    const downloadEwfSuccessMock = "";
    let userName = {};
    spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
        return userName[key];
    });
    const downloadEwfFailureMock = {
      error: {
        text: ""
      }
    }
    spyOn(trialsService, 'downloadEwf').and.returnValue(throwError(downloadEwfFailureMock));
    component.downloadEwf('selected');
  });

});
