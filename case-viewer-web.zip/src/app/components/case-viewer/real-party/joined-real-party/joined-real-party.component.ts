import { Component, Input, OnInit } from '@angular/core';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { JpViewService } from 'src/app/services/jpview.service';
import { TrialsService } from 'src/app/services/trials.service';

@Component({
  selector: 'app-joined-real-party',
  templateUrl: './joined-real-party.component.html',
  styleUrls: ['./joined-real-party.component.less']
})
export class JoinedRealPartyComponent implements OnInit {

  @Input() joinedProceedingNo: string;

  petitionerRealPartyInfo: any;
  realPartyInfo: any;

  constructor(private trialsService: TrialsService, private commonUntils: CommonUtilitiesService) { }

  ngOnInit(): void {
    this.getRealPartyInfo();
  }

  getRealPartyInfo() {
    // this.jpViewService.getCounselInfo(`${PtabTrialConstants.TRIAL_SERVICES_URL}/proceeding-party-details?proceedingNumber=${this.caseInfo.proceedingNo}`).subscribe((counselInfoResponse) => {
    // this.jpViewService.getCounselInfo(`/proceeding-party-details?proceedingNumber=${this.caseInfo.proceedingNo}`).subscribe((counselInfoResponse) => {
    this.trialsService.getCounselInfo(`${this.joinedProceedingNo}`).subscribe((counselInfoResponse) => {
      if (counselInfoResponse.petitionRealParty) {
        counselInfoResponse.petitionRealParty.parties.sort(this.sortCounselType);
      }
      // if (counselInfoResponse.poCounsel) {
      //   counselInfoResponse.poCounsel.parties.sort(this.sortCounselType);
      // }
      // counselInfoResponse.poCounsel.parties[1].registrationNo = null;
      this.realPartyInfo = counselInfoResponse;
      this.petitionerRealPartyInfo = counselInfoResponse.petitionRealParty ? counselInfoResponse.petitionRealParty.parties : [];
    });
  }


  sortCounselType(a, b) {
    const rankA = a.rankNo;
    const rankB = b.rankNo;

    let comparison = 0;
    if (rankA > rankB) {
      comparison = 1;
    } else if (rankA < rankB) {
      comparison = -1;
    }
    return comparison;
  }


  openInCaseViewer(proceedingNo) {
    this.commonUntils.openInCaseViewer(proceedingNo);
  }

}
