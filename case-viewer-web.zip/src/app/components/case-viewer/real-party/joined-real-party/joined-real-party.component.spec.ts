import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DatePipe } from '@angular/common';
import { TrialsService } from 'src/app/services/trials.service';
import { ToastrService } from 'ngx-toastr';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { of } from 'rxjs';

import { JoinedRealPartyComponent } from './joined-real-party.component';

/** 100% */
describe('JoinedRealPartyComponent', () => {
  let component: JoinedRealPartyComponent;
  let trialsService: TrialsService;
  let modalService: BsModalService;
  let fixture: ComponentFixture<JoinedRealPartyComponent>;

  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => {},
    error: (
      message?: string,
      title?: string
    ) => {},
  };

  const realPartyInfoResponseMock = {
    "ptabReadOnlyUser": true,
    "petitionRealParty": {
      "identifier": null,
      "supplementaryIdType": null,
      "audit": null,
      "parties": [{
        "identifier": "15896040",
        "submitterType": "PETITIONER",
        "orgType": [{
          "identifier": "15898195",
          "electronicAddress": [],
          "legalname": "Paper Mate",
          "orgAddress": []
        }],
        "partySubTypeDescription": null,
        "registrationNo": null,
        "partySubType": null,
        "partyReference": null,
        "partyType": "REAL PARTY",
        "personType": [],
        "rankNo": 1,
        "proseIndicator": "N"
      }, {
        "identifier": "15896075",
        "submitterType": "PETITIONER",
        "orgType": [{
          "identifier": "15898230",
          "electronicAddress": [],
          "legalname": "Apple",
          "orgAddress": [{
            "identifier": "12180337",
            "streetLineOneText": "   ",
            "city": "  ",
            "addressType": "RES"
          }]
        }],
        "partySubTypeDescription": null,
        "registrationNo": null,
        "partySubType": null,
        "partyReference": null,
        "partyType": "REAL PARTY",
        "personType": [],
        "rankNo": 3,
        "proseIndicator": "N"
        }, {
          "identifier": "15896040",
          "submitterType": "PETITIONER",
          "orgType": [{
            "identifier": "15898195",
            "electronicAddress": [],
            "legalname": "Paper Mate",
            "orgAddress": []
          }],
          "partySubTypeDescription": null,
          "registrationNo": null,
          "partySubType": null,
          "partyReference": null,
          "partyType": "REAL PARTY",
          "personType": [],
          "rankNo": 2,
          "proseIndicator": "N"
        }],
      "proceedingSupplementaryIdList": null,
      "caseNo": "IPR2021-00727",
      "caseType": null,
      "status": null
    },
    "petitionCounsel": {
      "identifier": null,
      "supplementaryIdType": null,
      "audit": null,
      "parties": [{
        "identifier": "15896041",
        "submitterType": "PETITIONER",
        "orgType": [],
        "partySubTypeDescription": "Lead Counsel",
        "registrationNo": "00000",
        "partySubType": "LEAD",
        "partyReference": null,
        "partyType": "COUNSEL",
        "personType": [{
          "identifier": "15898196",
          "firstName": "James R.",
          "lastName": "Batchelder",
          "electronicAddress": [{
            "identifier": "12943701",
            "telephoneNumber": "8901135633",
            "teleCommAddresType": "W"
          }, {
            "identifier": "10361375",
            "emailType": "WE",
            "email": "test1_james.batchelder@ropesgray.com"
          }],
          "mailingAddress": [{
            "identifier": "12180317",
            "zipCode": "90475",
            "country": "US",
            "streetLineOneText": "15 Bald Hill Dr.",
            "city": "Framingham",
            "addressType": "BUS",
            "state": "MD"
          }]
        }],
        "rankNo": 1,
        "proseIndicator": "N"
      }, {
        "identifier": "15896076",
        "submitterType": "PETITIONER",
        "orgType": [],
        "partySubTypeDescription": "First Back Up Counsel",
        "registrationNo": "00000",
        "partySubType": "FIRSTBKUP",
        "partyReference": null,
        "partyType": "COUNSEL",
        "personType": [{
          "identifier": "15898231",
          "firstName": "Alexander",
          "lastName": "Walden",
          "electronicAddress": [{
            "identifier": "10361390",
            "emailType": "WE",
            "email": "test1_alexander.walden@bryancave.com"
          }],
          "mailingAddress": [{
            "identifier": "12180338",
            "streetLineOneText": "   ",
            "city": "  ",
            "addressType": "BUS"
          }]
        }],
        "rankNo": 3,
        "proseIndicator": "N"
      }, {
        "identifier": "15896076",
        "submitterType": "PETITIONER",
        "orgType": [],
        "partySubTypeDescription": "First Back Up Counsel",
        "registrationNo": "00000",
        "partySubType": "FIRSTBKUP",
        "partyReference": null,
        "partyType": "COUNSEL",
        "personType": [{
          "identifier": "15898231",
          "firstName": "Alexander",
          "lastName": "Walden",
          "electronicAddress": [{
            "identifier": "10361390",
            "emailType": "WE",
            "email": "test1_alexander.walden@bryancave.com"
          }],
          "mailingAddress": [{
            "identifier": "12180338",
            "streetLineOneText": "   ",
            "city": "  ",
            "addressType": "BUS"
          }]
        }],
        "rankNo": 2,
        "proseIndicator": "N"
      }],
      "proceedingSupplementaryIdList": null,
      "caseNo": "IPR2021-00727",
      "caseType": null,
      "status": null
    }
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [JoinedRealPartyComponent],
      providers: [DatePipe, TrialsService,
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useValue: {}
        },
        {
          provide: ToastrService,
          useValue: toastrService
        }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JoinedRealPartyComponent);
    trialsService = TestBed.inject(TrialsService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should get counsel info', () => {
    component.joinedProceedingNo = "IPR2021-00739";
    spyOn(trialsService, 'getCounselInfo').and.returnValue(of(realPartyInfoResponseMock));
    component.getRealPartyInfo();
    expect(component.realPartyInfo ).toEqual(realPartyInfoResponseMock);
  });


  it('should open caseviewer with provided proceedingNo', () => {
    const proceedingNo = "IPR2021-00739";
    component.openInCaseViewer(proceedingNo);
  });
});
