import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap } from '@angular/router';
import { JpViewService } from 'src/app/services/jpview.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Observable, of } from 'rxjs';
import * as realPartyResp from 'src/assets/test_data/counselRealPartyResponse.json';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { RealPartyComponent } from './real-party.component';
import { provideMockStore } from '@ngrx/store/testing';
import { TrialsService } from 'src/app/services/trials.service';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';

/**
 * 57.5%
 */
describe('RealPartyComponent', () => {
  let component: RealPartyComponent;
  let fixture: ComponentFixture<RealPartyComponent>;
  let jpViewService: JpViewService;
  let trialsService: TrialsService;

  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "123456789",
        caseNumber: "IPR2020-123456"
      }
    }
  };

  const realPartyRespMock = { "poCounsel": { "parties": [{ "identifier": "15890850", "submitterType": "PATENTOWNER", "orgType": [], "partySubTypeDescription": "Lead Counsel", "registrationNo": "42,866", "partySubType": "LEAD", "partyType": "COUNSEL", "personType": [{ "identifier": "15893024", "firstName": "Scott", "lastName": "McKeown", "electronicAddress": [{ "identifier": "12939556", "telephoneNumber": "2025084740", "teleCommAddresType": "W" }, { "identifier": "12939557", "telephoneNumber": "6172359492", "teleCommAddresType": "F" }, { "identifier": "10357709", "emailType": "WE", "email": "test4_scott.mckeown@ropesgray.com" }], "mailingAddress": [{ "identifier": "12175988", "zipCode": "20006-6807", "country": "US", "streetLineTwoText": "2099 Pennsylvania Avenue, N.W.", "streetLineOneText": "ROPES & GRAY LLP", "city": "Washington", "addressType": "BUS", "state": "DC" }] }], "rankNo": 1 }, { "identifier": "15890851", "submitterType": "PATENTOWNER", "orgType": [], "partySubTypeDescription": "First Back Up Counsel", "registrationNo": "57565", "partySubType": "FIRSTBKUP", "partyType": "COUNSEL", "personType": [{ "identifier": "15893025", "firstName": "Matthew J.", "lastName": "Rizzolo", "electronicAddress": [{ "identifier": "12939558", "telephoneNumber": "2025084735", "teleCommAddresType": "W" }, { "identifier": "12939559", "telephoneNumber": "6172359492", "teleCommAddresType": "F" }, { "identifier": "10357710", "emailType": "WE", "email": "test4_matthew.rizzolo@ropesgray.com" }], "mailingAddress": [{ "identifier": "12175989", "zipCode": "20006-6807", "country": "US", "streetLineTwoText": "2099 Pennsylvania Avenue, N.W.", "streetLineOneText": "ROPES & GRAY LLP", "city": "Washington", "addressType": "BUS", "state": "DC" }] }], "rankNo": 2 }, { "identifier": "15890887", "submitterType": "PATENTOWNER", "orgType": [], "partySubTypeDescription": "Back Up Counsel", "registrationNo": "63307", "partySubType": "BACKUP", "partyType": "COUNSEL", "personType": [{ "identifier": "15893061", "firstName": "Christopher", "lastName": "Bonny", "electronicAddress": [{ "identifier": "12939575", "telephoneNumber": "6506174011", "teleCommAddresType": "W" }, { "identifier": "12939576", "telephoneNumber": "6172359492", "teleCommAddresType": "F" }, { "identifier": "10357700", "emailType": "WE", "email": "test4_christopher.bonny@ropesgray.com" }], "mailingAddress": [{ "identifier": "12175972", "zipCode": "94303-2284", "country": "US", "streetLineTwoText": "1900 University Ave., 6th Floor", "streetLineOneText": "ROPES & GRAY LLP", "city": "East Palo Alto", "addressType": "BUS", "state": "CA" }] }], "rankNo": 3 }], "caseNo": "IPR2021-00350" }, "ptabReadOnlyUser": true, "poRealParty": { "parties": [{ "identifier": "15890886", "submitterType": "PATENTOWNER", "orgType": [{ "identifier": "15893060", "electronicAddress": [{ "identifier": "12939553", "telephoneNumber": "2025084740", "teleCommAddresType": "W" }, { "identifier": "12939574", "telephoneNumber": "6172359492", "teleCommAddresType": "F" }, { "identifier": "10357699", "emailType": "WE", "email": "test4_Scott.McKeown@ropesgray.com" }], "legalname": "Teradyne, Inc.", "orgAddress": [{ "identifier": "12175971", "zipCode": "01864", "country": "US", "streetLineOneText": "600 Riverpark Drive", "city": "North Reading", "addressType": "RES", "state": "MA" }] }], "partyType": "REAL PARTY", "personType": [], "rankNo": 1 }], "caseNo": "IPR2021-00350" }, "petitionRealParty": { "parties": [{ "identifier": "15889173", "submitterType": "PETITIONER", "orgType": [{ "identifier": "15891367", "electronicAddress": [], "legalname": "Astronics Test Systems, Inc.", "orgAddress": [] }], "partyType": "REAL PARTY", "personType": [], "rankNo": 1 }, { "identifier": "15889195", "submitterType": "PETITIONER", "orgType": [{ "identifier": "15891389", "electronicAddress": [], "legalname": "Astronics Corporation", "orgAddress": [] }], "partyType": "REAL PARTY", "personType": [], "rankNo": 2 }], "caseNo": "IPR2021-00350" }, "petitionCounsel": { "parties": [{ "identifier": "15894255", "submitterType": "PETITIONER", "orgType": [], "partySubTypeDescription": "Lead Counsel", "registrationNo": "17438", "partySubType": "LEAD", "partyType": "COUNSEL", "personType": [{ "identifier": "15896369", "firstName": "Heather", "lastName": "Herndon", "electronicAddress": [{ "identifier": "12942495", "telephoneNumber": "571-272-4136", "teleCommAddresType": "W" }, { "identifier": "10360010", "emailType": "WE", "email": "hherndonlaw@gmail.com" }], "mailingAddress": [{ "identifier": "12178848", "streetLineOneText": "   ", "city": "  ", "addressType": "BUS" }] }], "rankNo": 1 }, { "identifier": "15889197", "submitterType": "PETITIONER", "orgType": [], "partySubTypeDescription": "Back Up Counsel", "registrationNo": "69770", "partySubType": "BACKUP", "partyType": "COUNSEL", "personType": [{ "identifier": "15891391", "firstName": "Yimeng", "lastName": "Dou", "electronicAddress": [{ "identifier": "12938291", "telephoneNumber": "2136808400", "teleCommAddresType": "W" }, { "identifier": "10356330", "emailType": "WE", "email": "test4_yimeng.dou@kirkland.com" }], "mailingAddress": [{ "identifier": "12174288", "zipCode": "90071", "country": "US", "streetLineOneText": "555 South Flower Street, Suite 3700", "city": "Los Angeles", "addressType": "BUS", "state": "NY" }] }], "rankNo": 3 }, { "identifier": "15889185", "submitterType": "PETITIONER", "orgType": [], "partySubTypeDescription": "Back Up Counsel", "registrationNo": "45265", "partySubType": "BACKUP", "partyType": "COUNSEL", "personType": [{ "identifier": "15891379", "firstName": "W Todd", "lastName": "Baker", "electronicAddress": [{ "identifier": "12938294", "telephoneNumber": "2023895000", "teleCommAddresType": "W" }, { "identifier": "10356300", "emailType": "WE", "email": "test4_todd.baker@kirkland.com" }], "mailingAddress": [{ "identifier": "12174221", "zipCode": "20004", "country": "US", "streetLineOneText": "1301 Pennsylvania Avenue, N.W.", "city": "Washington, D.C.", "addressType": "BUS", "state": "DC" }] }], "rankNo": 4 }], "caseNo": "IPR2021-00350" } };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [RealPartyComponent],
      providers: [
        provideMockStore({
          selectors: [
            { selector: CaseViewerSelectors.caseInfoData, value: { proceedingNo: '37553565' } },
            {selector: CaseViewerSelectors.userInfoData,value:{caseDetailsData: []}}
          ]
        }),
        JpViewService,
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        },
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useValue: {}
        }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RealPartyComponent);
    trialsService = TestBed.inject(TrialsService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should call getCounseInfo and get successResponse', () => {
    spyOn(trialsService, 'getCounselInfo').and.returnValue(of(realPartyRespMock));
    component.getRealPartyInfo();
    expect(component.realPartyInfo).toEqual(realPartyRespMock)
  });


});
