import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { JpViewService } from 'src/app/services/jpview.service';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import { UpdatePartiesModalComponent } from '../../common/update-parties-modal/update-parties-modal.component';
import { TrialsService } from 'src/app/services/trials.service';
import { Store, select } from '@ngrx/store';
import * as CaseViewerActions from 'src/app/store/case-viewer/case-viewer.actions';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';

@Component({
  selector: 'app-real-party',
  templateUrl: './real-party.component.html',
  styleUrls: ['./real-party.component.less']
})
export class RealPartyComponent implements OnInit {

  @Input() realPartyProceedingNos;

  @Output() updateHeaderEvent = new EventEmitter<any>();

  realPartyInfo: any;
  caseInfo: CaseInfoModel = {
    serialNo: null,
    proceedingNo: null
  };
  updateRealPartyModelRef: BsModalRef;
  loggedInUser$ = this.store.pipe(select(CaseViewerSelectors.userInfoData));
  lastRefresh = new Date();


  constructor(
    private jpViewService: JpViewService,
    private trialsService: TrialsService,
    private activatedRoute: ActivatedRoute,
    private modalService: BsModalService,
    private store: Store
  ) { }

  ngOnInit(): void {
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };
    this.getRealPartyInfo();
    // setInterval(()=>{
    //   this.refresh();
    // },300000)
  }

  refresh(){
    this.getRealPartyInfo();
    this.lastRefresh = new Date();
  }

  getRealPartyInfo() {
    // let url = '/counsel?proceedingCoreId=' + this.caseInfo.serialNo + '&proceedingSupplementaryId=' + this.caseInfo.proceedingNo;
    // this.jpViewService.getCounselInfo(`${PtabTrialConstants.CASE_VIEWER_URL}/counsel?proceedingCoreId=${this.caseInfo.serialNo}&proceedingSupplementaryId=${this.caseInfo.proceedingNo}`).subscribe((counselInfoResponse) => {
    // this.jpViewService.getCounselInfo(`/proceeding-party-details?proceedingNumber=${this.caseInfo.proceedingNo}`).subscribe((counselInfoResponse) => {
    this.trialsService.getCounselInfo(`${this.caseInfo.proceedingNo}`).subscribe((counselInfoResponse) => {
      if (counselInfoResponse.petitionRealParty) {
        counselInfoResponse.petitionRealParty.parties.sort(this.sortRealPartyType);
      }
      if (counselInfoResponse.poRealParty) {
        counselInfoResponse.poRealParty.parties.sort(this.sortRealPartyType);

      }
      this.realPartyInfo = counselInfoResponse;
    });
  }


  sortRealPartyType(a, b) {
    const rankA = a.rankNo;
    const rankB = b.rankNo;

    let comparison = 0;
    if (rankA > rankB) {
      comparison = 1;
    } else if (rankA < rankB) {
      comparison = -1;
    }
    return comparison;
  }

/* istanbul ignore next */
  updateRealParty(interestedParty, partyType) {
    let realPartyInfo = null;
    if (partyType.toLowerCase() === 'petitioner') {
      realPartyInfo = this.realPartyInfo ? this.realPartyInfo.petitionRealParty : null;
    } else {
      realPartyInfo = this.realPartyInfo ? this.realPartyInfo.poRealParty : null;
    }
    const initialState = {
      modal: {
        title: `Update`,
        interestedParty: interestedParty,
        partyType: partyType,
        closeBtnName: "Done",
        isConfirm: false,
        counselInfo: realPartyInfo,
        caseInfo: this.caseInfo,
        modalType: 'realParty'
      }
    };
    this.updateRealPartyModelRef = this.modalService.show(UpdatePartiesModalComponent, {
      animated: true,
      backdrop: true,
      ignoreBackdropClick: true,
      class: 'add-update-parties-modal-content',
      initialState
    });
    this.updateRealPartyModelRef.onHide.subscribe((reason: string | any) => {
      console.log('reason: ', reason);
      let urlString = PtabTrialConstants.CASE_HEADER + `${this.caseInfo.serialNo}&proceedingSupplementaryId=${this.caseInfo.proceedingNo}`;
    // this.store.dispatch(CaseViewerActions.GetCaseHeaderAction({urlSuffix: urlString}));
      this.getRealPartyInfo();
      this.getHeaderPartiesInfo();
      if (reason.initialState.modal.isConfirm) {
        // this.pushToList();
      }
    })
  }
/* istanbul ignore next */
  getHeaderPartiesInfo() {
    // let urlString =PtabTrialConstants.CASE_HEADER + `${this.caseInfo.serialNo}&proceedingSupplementaryId=${this.caseInfo.proceedingNo}`;
    // this.jpViewService.getCaseHeader(urlString).subscribe((partiesResponse) => {
    //   this.updateHeaderEvent.emit(partiesResponse.parties);
    // })
    this.trialsService.getCaseHeaderInfo(this.caseInfo.proceedingNo).subscribe((partiesResponse) => {
      console.log(partiesResponse);
      if (partiesResponse && partiesResponse[0]) {
        this.updateHeaderEvent.emit(partiesResponse[0].parties);
        // this.parties = partiesResponse[0].parties
      }
    });
  }

}
