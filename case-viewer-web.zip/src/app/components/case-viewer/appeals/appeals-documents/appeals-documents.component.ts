import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';
import { PtabTrialConstants } from '../../../../constants/ptab-trials.constants';
import CaseInfoModel from '../../../../models/CaseInfo.model';
import { JpViewService } from '../../../../services/jpview.service';


@Component({
  selector: 'app-appeals-documents',
  templateUrl: './appeals-documents.component.html',
  styleUrls: ['./appeals-documents.component.less']
})
export class AppealsDocumentsComponent implements OnInit {

  caseInfo: CaseInfoModel;
  appealsDocuments: any;
  orderByField: any[] = [];
  pdfToView: any = null;
  enableCheckbox: boolean = true;
  documentsToDownload: Array<any> = [];

  constructor(private readonly activatedRoute: ActivatedRoute, private readonly jpViewService: JpViewService, private readonly sanitize: DomSanitizer) { }

  ngOnInit(): void {
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };

    this.getDocuments();
  }

  getDocuments() {
    this.jpViewService.getAppealsCaseData(`${PtabTrialConstants.APPEALS_BASE_URL}/data-documents/application-doc-info/${this.caseInfo.serialNo}`).subscribe((documentsResponse) => {
      if (documentsResponse && documentsResponse.resultBag.length > 0 && documentsResponse.resultBag[0].documentBag.length > 0) {
        this.openPdfFile({data: documentsResponse.resultBag[0].documentBag[0], colName: null});
      }
      this.appealsDocuments = {
        tableId: "appealsDocTable",
        tableHeaderClass: "appealsDocTableHeader",
        tableBodyClass: "appealsDocTableBody",
        columnDefs: [
          {
            name: "documentCode",
            displayName: "Document Code",
            field: "documentCode",
            width: '150px',
            type: "string",
            searchText: null,
            link: true,
            icon: null
          },
          {
            name: "documentDescription",
            displayName: "Document Description",
            field: "documentDescription",
            width: null,
            type: "string",
            searchText: null,
            link: false,
            icon: null
          },
          {
            name: "document",
            displayName: "Open in new tab",
            field: "documentDescription",
            width: '150px',
            type: "string",
            searchText: null,
            link: false,
            icon: "fas fa-external-link-alt"
          },
          {
            name: "officialDateEpoch",
            displayName: "Official Date",
            field: "officialDateEpoch",
            width: '150px',
            type: "date",
            searchText: "",
            link: false,
            icon: null
          }
        ],
        data: JSON.parse(JSON.stringify(documentsResponse?.resultBag[0].documentBag))
      };
    })
  };


  openPdfFile(data) {
    const sr = this.caseInfo.serialNo;
    const docCode = data.data.documentCode;
    const epoch = data.data.officialDateEpoch;
    this.jpViewService.getAppeals(
      `${PtabTrialConstants.APPEALS_BASE_URL}/data-documents/pdf?serialNumber=${sr}&docCode=${docCode}&officialStrtDate=${epoch}`).subscribe((pdfPreviewResponse) => {
      if (data.colName === 'documentDescription') {
        const byteCharacters = atob(pdfPreviewResponse.fileContent);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const file = new Blob([byteArray], { type: 'application/pdf;base64' });
        const fileURL = URL.createObjectURL(file);
        window.open(fileURL);
      } else {
         /* istanbul ignore next  */
        this.pdfToView = this.sanitize.bypassSecurityTrustResourceUrl('data:application/pdf;base64,' + pdfPreviewResponse.fileContent);
      }
    });
  }

  rowSelection(rowData) {
    console.log(rowData);
    if (rowData.valueToEmit === 'all') {
      this.documentsToDownload = JSON.parse(JSON.stringify(this.appealsDocuments.data))
    } else if (rowData.valueToEmit === 'none') {
      this.documentsToDownload = [];
    } else if (rowData.row.target.checked) {
      this.documentsToDownload.push(rowData.valueToEmit);
    } else if (!rowData.row.target.checked) {
      const index = this.documentsToDownload.indexOf(rowData.valueToEmit);
      this.documentsToDownload.splice(index, 1);
      console.log('index: ', index);
    }
    console.log(this.documentsToDownload);
  }


  constructAllDocuments() {
    const downloadAppealList: Array<any> = [];
    this.appealsDocuments.data.forEach((element) => {
      const downloadAppealZip = {
        "serialNumber": this.caseInfo.serialNo,
        "docCode": element.documentCode,
        "officialStrtDate": element.officialDateEpoch,
      };
      downloadAppealList.push(downloadAppealZip);
    });
    this.downloadDocuments(downloadAppealList, "AllAppealfiles");
  }


  constructSelectedDocuments() {
    const downloadAppealList: Array<any> = [];
    this.documentsToDownload.forEach((element) => {
      const downloadAppealZip = {
        "serialNumber": this.caseInfo.serialNo,
        "docCode": element.documentCode,
        "officialStrtDate": element.officialDateEpoch,
      };
      downloadAppealList.push(downloadAppealZip);
    });
    this.downloadDocuments(downloadAppealList, "SelectedAppealfiles");
  }


  downloadDocuments(docList, fileName) {
    this.jpViewService.downloadZip(`${PtabTrialConstants.APPEALS_BASE_URL}/data-documents/download-zip`, docList).subscribe((docListResponse) => {
      const blob = new Blob([docListResponse], {
        type: "application/zip"
      });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = fileName + new Date() + ".zip";
      a.click();
    }, (docListFailure) => {
        console.log('docListFailure: ', docListFailure);
    });
  }

}
