import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { JpViewService } from 'src/app/services/jpview.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AppealsDocumentsComponent } from './appeals-documents.component';
import { DomSanitizer } from '@angular/platform-browser';
import { of, throwError } from 'rxjs';


/**
 * 70.18%
 */
describe('AppealsDocumentsComponent', () => {
  let component: AppealsDocumentsComponent;
  let fixture: ComponentFixture<AppealsDocumentsComponent>;
  let jpViewService: JpViewService;
  let sanitize: DomSanitizer;
  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "08423235",
        caseNumber: "2020005372"
      }
    }
  };

  const appealsDocumentsMock = {
    tableId: "appealsDocTable",
    tableHeaderClass: "appealsDocTableHeader",
    tableBodyClass: "appealsDocTableBody",
    columnDefs: [
      {
        name: "documentCode",
        displayName: "Document Code",
        field: "documentCode",
        width: '150px',
        type: "string",
        searchText: null,
        link: true,
        icon: null
      },
      {
        name: "documentDescription",
        displayName: "Document Description",
        field: "documentDescription",
        width: null,
        type: "string",
        searchText: null,
        link: false,
        icon: null
      },
      {
        name: "document",
        displayName: "Open in new tab",
        field: "documentDescription",
        width: '150px',
        type: "string",
        searchText: null,
        link: false,
        icon: "fas fa-external-link-alt"
      },
      {
        name: "officialDateEpoch",
        displayName: "Official Date",
        field: "officialDateEpoch",
        width: '150px',
        type: "date",
        searchText: "",
        link: false,
        icon: null
      }
    ],
    data: []
  };

  const documentsResponseMock = { "resultBag": [{ "applicationNumberText": "13390821", "documentBag": [{ "documentIdentifier": "JW0UYOB4RXEAPX3", "documentCode": "AP_DK_M", "officialDateEpoch": 1559060158000, "documentDescription": "Appeal Docketing Notice", "officialDateStr": "2019-05-28", "officialDate": "2019-05-28T12:15:58.000+0000" }, { "documentIdentifier": "JWQFJWJBRXEAPX0", "documentCode": "APDA", "officialDateEpoch": 1560347195000, "documentDescription": "Patent Board Decision - Examiner Affirmed", "officialDateStr": "2019-06-12", "officialDate": "2019-06-12T09:46:35.000+0000" }] }], "ptabReadOnlyUser": true, "errorBag": [], "status": "SUCCESS" };


  const pdfResponseMock = { "ptabReadOnlyUser": true, "fileContent": "JVBERi0xLjINJdTSpMsNMSAwIG9iag08PA0KCS9DcmVhdGlvbkRhdGUgKE1hciAxMSwgMjAyMSwgMzo1ODo0MCBQTSkNCgkvUHJvZHVjZXIgKFVTUFRPKQ0KCS9UaXRsZSAoMTMzOTA4MjEpDQoJL0NyZWF0b3IgKFVTUFRPIFBERiBCdWlsZGVyKQ0KPj4NCg1lbmRvYmoNCjIgMCBvYmoNWyAvUERGIC9JbWFnZUIgXQ1lbmRvYmoNCjMgMCBvYmoNPDwNCgkvUGFnZXMgNCAwIFINCgkvVHlwZSAvQ2F0YWxvZw0KCS9QYWdlTW9kZSAvVXNlT3V0bGluZXMNCgkvT3V0bGluZXMgNSAwIFINCj4+DQoNZW5kb2JqDQo3IDAgb2JqDTw8DQoJL1R5cGUgL1BhZ2UNCgkvQ29udGVudHMgWyA4IDAgUiBdDQoJL1BhcmVudCA0IDAgUg0KCS9SZXNvdXJjZXMgPDwgIC9Qcm9jU2V0IDIgMCBSICAvWE9iamVjdCA8PCAgL2ltNyA5IDAgUiA+PiAgPj4gDQoJL01lZGlhQm94IFsgMCAwIDYxMiA3OTIgXQ0KPj4NCg1lbmRvYmoNCjggMCBvYmoNPDwgIC9MZW5ndGggNjEgPj4gDXN0cmVhbQ1xIDYxMi4wMDAwIDAuMDAwMCAwLjAwMDAgNzkyLjAwMDAgMC4wMDAwIDAuMDAwMCBjbSAvaW03IERvDVENCmVuZHN0cmVhbQ0KZW5kb2JqDQo5IDAgb2JqDTw8ICAvVHlwZSAvWE9iamVjdCAgL0xlbmd0aCAyMjA2NiAgL0ZpbHRlciAvQ0NJVFRGYXhEZWNvZGUgIC9Db2xvclNwYWNlIC9EZXZpY2VHcmF5ICAvRGVjb2RlUGFybXMgPDwgIC9Db2x1bW5zIDI1NTAgIC9LIC0xICAvUm93cyAzMzAwID4+ICAgL0hlaWdodCAzMzAwICAvU3VidHlwZSAvSW1hZ2UgIC9XaWR0aCAyNTUwICAvQml0c1BlckNvbXBvbmVudCAxICAvTmFtZSAvaW03ID4+IA1zdHJlYW0N" };


  const rowDataOneMock = {
    "row": {
      "isTrusted": true,
      "target": {
        "checked": true
      }
    },
    "valueToEmit": {
      "documentIdentifier": "JW0UYOB4RXEAPX3",
      "documentCode": "AP_DK_M",
      "officialDateEpoch": 1559060158000,
      "documentDescription": "Appeal Docketing Notice",
      "officialDateStr": "2019-05-28",
      "officialDate": "2019-05-28T12:15:58.000+0000"
    }
  };


  const rowDataAllMock = { "row": { "isTrusted": true }, "valueToEmit": "all" };


  const rowDataNoneMock = { "row": { "isTrusted": true }, "valueToEmit": "none" };


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [AppealsDocumentsComponent],
      providers: [
        JpViewService,
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        },
        {
          provide: DomSanitizer,
          useValue: {
            sanitize: (ctx: any, val: string) => val,
            bypassSecurityTrustResourceUrl: (val: string) => val,
          },
       }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppealsDocumentsComponent);
    jpViewService = TestBed.inject(JpViewService);
    sanitize = TestBed.inject(DomSanitizer);
    component = fixture.componentInstance;
    component.appealsDocuments = appealsDocumentsMock;
    fixture.detectChanges();
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should get list of documents', () => {
    spyOn(jpViewService, 'getAppealsCaseData').and.returnValue(of(documentsResponseMock));
    component.getDocuments();
  });


  it('should call open pdf without documentDescription', () => {
    const data = { "colName": "documentCode", "data": { "documentIdentifier": "JW0UYOB4RXEAPX3", "documentCode": "AP_DK_M", "officialDateEpoch": 1559060158000, "documentDescription": "Appeal Docketing Notice", "officialDateStr": "2019-05-28", "officialDate": "2019-05-28T12:15:58.000+0000" } };
    spyOn(jpViewService, 'getAppeals').and.returnValue(of(pdfResponseMock));
    component.openPdfFile(data);

  });


  it('should call open pdf with documentDescription', () => {
    const data = { "colName": "documentDescription", "data": { "documentIdentifier": "JW0UYOB4RXEAPX3", "documentCode": "AP_DK_M", "officialDateEpoch": 1559060158000, "documentDescription": "Appeal Docketing Notice", "officialDateStr": "2019-05-28", "officialDate": "2019-05-28T12:15:58.000+0000" } };
    spyOn(jpViewService, 'getAppeals').and.returnValue(of(pdfResponseMock));
    component.openPdfFile(data);

  });


  it('should call rowSelected with all', () => {
    component.appealsDocuments.data = documentsResponseMock.resultBag[0].documentBag;
    component.rowSelection(rowDataAllMock);
    expect(component.documentsToDownload).toEqual(component.appealsDocuments.data);
  });


  it('should call rowSelected with none', () => {
    component.appealsDocuments.data = documentsResponseMock.resultBag[0].documentBag;
    component.rowSelection(rowDataNoneMock);
    expect(component.documentsToDownload.length).toBe(0);
  });


  it('should call rowSelected with one checked', () => {
    component.rowSelection(rowDataOneMock);
    expect(component.documentsToDownload[0]).toEqual(rowDataOneMock.valueToEmit);
  });


  it('should call rowSelected with one unchecked', () => {
    const rowDataOneUncheckedMock = {
      "row": {
        "isTrusted": true,
        "target": {
          "checked": false
        }
      },
      "valueToEmit": {
        "documentIdentifier": "JW0UYOB4RXEAPX3",
        "documentCode": "AP_DK_M",
        "officialDateEpoch": 1559060158000,
        "documentDescription": "Appeal Docketing Notice",
        "officialDateStr": "2019-05-28",
        "officialDate": "2019-05-28T12:15:58.000+0000"
      }
    };
    component.documentsToDownload[0] = rowDataOneUncheckedMock.valueToEmit;
    component.rowSelection(rowDataOneUncheckedMock);
    expect(component.documentsToDownload.length).toBe(0);
  });


  it('should construct all documents', () => {
    component.appealsDocuments.data = documentsResponseMock.resultBag;
    component.constructAllDocuments();
  })


  it('should construct selected documents', () => {
    component.documentsToDownload = documentsResponseMock.resultBag;
    component.constructSelectedDocuments();
  })


  it('should download documents successfully', () => {
    const docListResponseMock = new File([""], "filename", { type: 'text/html' });
    const docListMock = [{ "serialNumber": "14515074", "docCode": "AP_DK_M", "officialStrtDate": 1552507218000 }];
    spyOn(jpViewService, 'downloadZip').and.returnValue(of(docListResponseMock));
    component.downloadDocuments(docListMock, "Testing");
  });


  it('should try to download documents and fail', () => {
    const docListMock = [{ "serialNumber": "14515074", "docCode": "AP_DK_M", "officialStrtDate": 1552507218000 }];
    spyOn(jpViewService, 'downloadZip').and.returnValue(throwError(""));
    component.downloadDocuments(docListMock, "Testing");
  });

});
