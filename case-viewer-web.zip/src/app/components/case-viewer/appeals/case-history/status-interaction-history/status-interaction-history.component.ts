import { Component, OnInit } from '@angular/core';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import { ActivatedRoute } from '@angular/router';
import { JpViewService } from 'src/app/services/jpview.service';
import AppealStatusHistoryModel from 'src/app/models/appeals/AppealStatusHistory.model';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';

// declare let $: any;

@Component({
  selector: 'app-status-interaction-history',
  templateUrl: './status-interaction-history.component.html',
  styleUrls: ['./status-interaction-history.component.less']
})
export class StatusInteractionHistoryComponent implements OnInit {

  caseInfo: CaseInfoModel;
  statusInteractionHistory: Array<AppealStatusHistoryModel>;

  constructor(
    private readonly activatedRoute: ActivatedRoute,
    private readonly jpViewService: JpViewService
  ) { }

  ngOnInit(): void {
    // $(function () {
    //   $('[data-toggle="tooltip"]').tooltip()
    // })
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };
    this.getStatusInteractionHistory();
  }

  getStatusInteractionHistory() {
    const url = `${PtabTrialConstants.APPEALS_BASE_URL}/case-information/status-history?serialNumber=${this.caseInfo.serialNo}&appealNumber=${this.caseInfo.proceedingNo}`;
    this.jpViewService.getAppeals(url).subscribe((statusInteractionHistoryResponse) => {
      this.statusInteractionHistory = statusInteractionHistoryResponse.caseDetailsData;
    });
  }




}
