import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { JpViewService } from 'src/app/services/jpview.service';
import { StatusInteractionHistoryComponent } from './status-interaction-history.component';
import AppealStatusHistoryModel from 'src/app/models/appeals/AppealStatusHistory.model';

/**
 * 100%
 */
describe('StatusInteractionHistoryComponent', () => {
  let component: StatusInteractionHistoryComponent;
  let fixture: ComponentFixture<StatusInteractionHistoryComponent>;
  let jpViewService: JpViewService;
  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "08423235",
        caseNumber: "2020005372"
      }
    }
  };

  const statusInteractionHistoryMockResponse = { "ptabReadOnlyUser": true, "columDetails": null, "caseDetailsData": [{ "date": 1603481751000, "sequenceNumber": 7, "lastModifiedTimeStamp": 1603481751000, "appealNumber": 2019004249, "lastModifiedUserIdentifier": "McKeown, Jennifer L.", "description": "Decision draft in circulation", "typeCode": "Decision draft in circulation", "creditGrantedUserIdentifier": "McKeown, Jennifer L." }, { "date": 1600690715000, "sequenceNumber": 6, "lastModifiedTimeStamp": 1603481751000, "appealNumber": 2019004249, "lastModifiedUserIdentifier": "McKeown, Jennifer L.", "description": "Awaiting decision draft to be created by APJ1/PA", "typeCode": "Awaiting decision draft to be created by APJ1/PA", "creditGrantedUserIdentifier": "Chrisp, Carla " }, { "date": 1576413307000, "sequenceNumber": 5, "lastModifiedTimeStamp": 1600690714000, "appealNumber": 2019004249, "lastModifiedUserIdentifier": "Chrisp, Carla ", "description": "Awaiting paneling", "typeCode": "Prepping - awaiting panel assignment (selected by prepper)", "creditGrantedUserIdentifier": "Fleming, Tracey " }, { "date": 1562731105000, "sequenceNumber": 4, "lastModifiedTimeStamp": 1576413307000, "appealNumber": 2019004249, "lastModifiedUserIdentifier": "Fleming, Tracey ", "description": "Awaiting eWF creation", "typeCode": "Awaiting eWF creation", "creditGrantedUserIdentifier": "Sys, PTAB " }, { "date": 1557720000000, "sequenceNumber": 3, "lastModifiedTimeStamp": 1562731105000, "appealNumber": 2019004249, "lastModifiedUserIdentifier": "Sys, PTAB ", "description": "Pending on Master Docket", "typeCode": "Pending on master docket", "creditGrantedUserIdentifier": "Beyene, Marta M." }, { "date": 1557720000000, "sequenceNumber": 2, "lastModifiedTimeStamp": 1557754450000, "appealNumber": 2019004249, "lastModifiedUserIdentifier": "Beyene, Marta M.", "description": "Reviewing checklist", "typeCode": "Reviewing checklist", "creditGrantedUserIdentifier": "Beyene, Marta M." }, { "date": 1557720000000, "sequenceNumber": 1, "lastModifiedTimeStamp": 1557754308000, "appealNumber": 2019004249, "lastModifiedUserIdentifier": "Beyene, Marta M.", "description": "Mailing docketing notice", "typeCode": "Mailing docketing notice", "creditGrantedUserIdentifier": "Beyene, Marta M." }] };


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [StatusInteractionHistoryComponent],
      providers: [
        JpViewService,
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StatusInteractionHistoryComponent);
    component = fixture.componentInstance;
    jpViewService = TestBed.inject(JpViewService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getStatusInteractionHistory and return success response', () => {
    spyOn(jpViewService, 'getAppeals').and.returnValue(of(statusInteractionHistoryMockResponse));
    component.getStatusInteractionHistory();
    expect(component.statusInteractionHistory).toEqual(statusInteractionHistoryMockResponse.caseDetailsData);
  })

});
