import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-case-history',
  templateUrl: './case-history.component.html',
  styleUrls: ['./case-history.component.less']
})
export class CaseHistoryComponent implements OnInit {

  expandCollapseLinkList: Array<string> = ["assignmentHistoryLink", "statusInteractionHistoryLink", "decisionHistoryLink"];

  constructor() { }

  ngOnInit(): void {
  }

}
