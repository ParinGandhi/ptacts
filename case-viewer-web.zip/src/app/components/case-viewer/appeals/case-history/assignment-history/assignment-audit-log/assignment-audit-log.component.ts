import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { InfoModalComponent } from 'src/app/components/common/info-modal/info-modal.component';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import { JpViewService } from 'src/app/services/jpview.service';



@Component({
  selector: 'app-assignment-audit-log',
  templateUrl: './assignment-audit-log.component.html',
  styleUrls: ['./assignment-audit-log.component.less']
})
export class AssignmentAuditLogComponent implements OnInit {

  constructor(
    public bsModalRef: BsModalRef,
    private readonly jpViewService: JpViewService,
    private readonly modalService: BsModalService
  ) { }

  assignmentInfo: any = {
    assignmentIdentifier: null,
    appealNumber: null,
    completionDate: null,
    assignmentTypeDescription: null,
    audit: {
      createTimestamp: null
    }
  };
  assignmentHistory: any;
  modalRef: BsModalRef;

  ngOnInit(): void {
    this.getAssignmentAuditHistory();
  }

  close() {
    this.bsModalRef.hide();
  }

  getAssignmentAuditHistory() {
    const url =`${PtabTrialConstants.APPEALS_BASE_URL}/assignments-history/${this.assignmentInfo.assignmentIdentifier}`;
    this.jpViewService.getAppeals(url).subscribe((assignmentHistoryAuditResponse) => {
      this.assignmentHistory = assignmentHistoryAuditResponse.caseDetailsData;
    });
  }

  openAssignmentNote(noteText) {
    const initialState: any = {
      infoText: noteText,
      title: "Assignment update note",
      showLeftBtn: false,
      leftBtnClass: null,
      leftBtnLabel: null,
      showRightBtn: true,
      rightBtnClass: 'btn-default',
      rightBtnLabel: 'Close',
      modalHeight: 300
    };
    this.modalRef = this.modalService.show(InfoModalComponent, {
      animated: true,
      backdrop: 'static',
      class: 'modal-lg',
      initialState
    });
  }


}
