import { Component, OnInit } from '@angular/core';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import { ActivatedRoute } from '@angular/router';
import { JpViewService } from 'src/app/services/jpview.service';
import AssignmentModel from 'src/app/models/common/Assignment.model';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { AssignmentAuditLogComponent } from './assignment-audit-log/assignment-audit-log.component';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';

@Component({
  selector: 'app-assignment-history',
  templateUrl: './assignment-history.component.html',
  styleUrls: ['./assignment-history.component.less']
})
export class AssignmentHistoryComponent implements OnInit {

  caseInfo: CaseInfoModel;
  assignmentHistory: Array<AssignmentModel>;
  modalRef: BsModalRef;

  constructor(
    private readonly activatedRoute: ActivatedRoute,
    private readonly jpViewService: JpViewService,
    private readonly modalService: BsModalService
  ) { }

  ngOnInit(): void {
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };
    this.getAssignmentHistory();
  }

  getAssignmentHistory() {
    const url = `${PtabTrialConstants.APPEALS_BASE_URL}/case-information/assignment-history?serialNumber=${this.caseInfo.serialNo}&appealNumber=${this.caseInfo.proceedingNo}`;
    this.jpViewService.getAppeals(url).subscribe((assignmentHistoryResponse) => {
      this.assignmentHistory = assignmentHistoryResponse.caseDetailsData;
    });
  }

  openModal(assignment) {
    const url = `${PtabTrialConstants.APPEALS_BASE_URL}/assignments/${assignment.assignmentIdentifier}`;
    this.jpViewService.getAppeals(url).subscribe((assignmentResponse) => {
      const initialState: any = {
        assignmentInfo: assignmentResponse
      };
      this.modalRef = this.modalService.show(AssignmentAuditLogComponent, {
        animated: true,
        backdrop: 'static',
        class: 'modal-audit-size',
        initialState
      });
})


  }

}
