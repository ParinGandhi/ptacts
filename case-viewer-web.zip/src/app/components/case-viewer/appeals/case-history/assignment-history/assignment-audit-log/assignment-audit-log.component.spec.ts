import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { JpViewService } from 'src/app/services/jpview.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';

import { AssignmentAuditLogComponent } from './assignment-audit-log.component';

/**
 * 92.31%
 */
describe('AssignmentAuditLogComponent', () => {
  let component: AssignmentAuditLogComponent;
  let fixture: ComponentFixture<AssignmentAuditLogComponent>;
  let jpViewService: JpViewService;
  let modalService: BsModalService;
  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "08423235",
        caseNumber: "2020005372"
      }
    }
  };

  const assignmentHistoryAuditMockResponse: any = { "ptabReadOnlyUser": true, "columnDetails": [{ "typeDefinition": "Date", "name": "lastModifiedDate", "label": "When updated" }, { "typeDefinition": "String", "name": "lastModifierName", "label": "Who changed " }, { "typeDefinition": "String", "name": "titleText", "label": "Title " }, { "typeDefinition": "String", "name": "descriptionText", "label": "Description" }, { "typeDefinition": "String", "name": "priorityIn", "label": "Critical" }, { "typeDefinition": "String", "name": "assignedToName", "label": "Assigned to " }, { "typeDefinition": "Date", "name": "dueDate", "label": "Due date" }, { "typeDefinition": "String", "name": "noteText", "label": "Update" }], "caseDetailsData": [{ "workerNumber": "11356", "lastModifiedDate": 1607547902000, "assignedToName": "Appeals Decisions, PTAB ", "titleText": "Paralegal review decision draft - 2019004249", "dueDate": 1603943999000, "priorityIn": "No", "lastModifierName": "Bartlett, Stevenn ", "descriptionText": "Paralegal review decision draft", "assignmentType": "Paralegal review decision draft" }, { "workerNumber": "11356", "lastModifiedDate": 1603481750000, "assignedToName": "Appeals Decisions, PTAB ", "titleText": "Paralegal review decision draft - 2019004249", "dueDate": 1603857600000, "priorityIn": "No", "lastModifierName": "McKeown, Jennifer L.", "descriptionText": "Paralegal review decision draft", "assignmentType": "Paralegal review decision draft" }] };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [AssignmentAuditLogComponent],
      providers: [
        JpViewService,
        BsModalService,
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        },
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useValue: {}
        }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignmentAuditLogComponent);
    jpViewService = TestBed.inject(JpViewService);
    modalService = TestBed.inject(BsModalService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.assignmentInfo = {
      "assignmentIdentifier": "1143956"
    };
    expect(component).toBeTruthy();
  });

  it('should call getAssignmentAuditHistory and return a success response', () => {
    spyOn(jpViewService, 'getAppeals').and.returnValue(of(assignmentHistoryAuditMockResponse));
    component.assignmentInfo.assignmentIdentifier = "1143956";
    component.getAssignmentAuditHistory();
    expect(component.assignmentHistory).toEqual(assignmentHistoryAuditMockResponse.caseDetailsData);
  });


  it('should call openModal and return a success response for assignment', () => {
    let noteText = "Testing";
    const initialState: any = {
      infoText: noteText,
      title: "Assignment update note",
      showClose: true
    };
    modalService.show = (): BsModalRef => {
      return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
        animated: true,
        backdrop: 'static',
        class: 'modal-audit-size',
        initialState
      }}
    }
    component.openAssignmentNote(noteText);
  });



});
