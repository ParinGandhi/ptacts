import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { JpViewService } from 'src/app/services/jpview.service';

import { DecisionHistoryComponent } from './decision-history.component';

/**
 * 97.22%
 */
describe('DecisionHistoryComponent', () => {
  let component: DecisionHistoryComponent;
  let fixture: ComponentFixture<DecisionHistoryComponent>;
  let jpViewService: JpViewService;
  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "08423235",
        caseNumber: "2020005372"
      }
    }
  };

  const decisionHistoryMockResponse = { "ptabReadOnlyUser": true, "decisions": [{ "adSequenceNumber": 1, "serialNumber": "14833621", "displaySerialNo": 1, "lastModifiedTimestamp": "2019-05-13T13:31:48.000+0000", "adReconsiderSequenceNumber": 0, "audit": { "createUserIdentifier": null, "createdUserName": null, "lockControlNumber": 0, "lastModifiedUserIdentifier": "mbeyene3", "lastModifiedUserName": null, "lastModifiedTimestamp": 1557754308000, "createTimestamp": null }, "requesterName": "", "decisionCategoryName": "Initial decision", "appealNumber": "2019004249", "judgePanel": [{ "assignedDate": 1600690714000, "panelSequenceNumber": 1, "identifier": "89392", "panelRank": 1, "reConsiderSeqNumber": 0, "panelName": "McKeown, Jennifer L." }, { "assignedDate": 1600690714000, "panelSequenceNumber": 1, "identifier": "94526", "panelRank": 2, "reConsiderSeqNumber": 0, "panelName": "Belisle, Stephen E." }, { "assignedDate": 1600690714000, "panelSequenceNumber": 1, "identifier": "79099", "panelRank": 3, "reConsiderSeqNumber": 0, "panelName": "Hughes, James R." }], "location": "D1R0", "lifeCycle": { "beginEffectiveDate": 1562717157000 }, "decisionCategory": "D", "show":null }] };



  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [DecisionHistoryComponent],
      providers: [
        JpViewService,
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DecisionHistoryComponent);
    component = fixture.componentInstance;
    jpViewService = TestBed.inject(JpViewService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getDecisionHistory and return success response', () => {
    spyOn(jpViewService, 'getAppeals').and.returnValue(of(decisionHistoryMockResponse));
    component.getDecisionHistory();
    expect(component.decisionHistory).toEqual(decisionHistoryMockResponse.decisions);
  })

  it('should call getAPJ1 and return a found judge', () => {
    let result = component.getAPJ1(decisionHistoryMockResponse.decisions[0].judgePanel);
    expect(result).toEqual(decisionHistoryMockResponse.decisions[0].judgePanel[0].panelName);
  });


  it('should call getAPJ1 and with empty judge panel and return empty string', () => {
    let result = component.getAPJ1([]);
    expect(result).toEqual("");
  });


  it('should call getAPJ1AssignedDate and return the assigned date', () => {
    let result = component.getAPJ1AssignedDate(decisionHistoryMockResponse.decisions[0].judgePanel);
    expect(result).toEqual(decisionHistoryMockResponse.decisions[0].judgePanel[0].assignedDate);
  });


  it('should call getAPJ1AssignedDate and return a found judge', () => {
    let result = component.getAPJ1AssignedDate([]);
    expect(result).toEqual("");
  });

  it('should call expand while it is collapsed', () => {
    decisionHistoryMockResponse.decisions[0].show = 0;
    let result = component.expand(decisionHistoryMockResponse.decisions[0]);
    expect(result).toEqual('expandRow');
    expect(decisionHistoryMockResponse.decisions[0].show).toBe(1);
  });

  it('should call expand while it is expanded', () => {
    decisionHistoryMockResponse.decisions[0].show = 1;
    let result = component.expand(decisionHistoryMockResponse.decisions[0]);
    expect(result).toEqual('');
    expect(decisionHistoryMockResponse.decisions[0].show).toBe(0);
  });

  it('should call isExpanded while collapsed', () => {
    decisionHistoryMockResponse.decisions[0].show = 0;
    let result = component.isExpanded(decisionHistoryMockResponse.decisions[0]);
    expect(result).toEqual('');
  });


  it('should call isExpanded for the first time', () => {
    decisionHistoryMockResponse.decisions[0].show = null;
    let result = component.isExpanded(decisionHistoryMockResponse.decisions[0]);
    expect(result).toEqual('');
    expect(decisionHistoryMockResponse.decisions[0].show).toBe(0);
  });


  it('should call isExpanded while expanded', () => {
    decisionHistoryMockResponse.decisions[0].show = 1;
    let result = component.isExpanded(decisionHistoryMockResponse.decisions[0]);
    expect(result).toEqual('expandRow');
  });


  it('should call decisionExpandAll', () => {
    decisionHistoryMockResponse.decisions[0].show = 0;
    component.decisionHistory = decisionHistoryMockResponse.decisions;
    component.decisionExpandAll();
    expect(component.decisionHistory[0].show).toBe(1);
  });

  it('should call decisionCollapseAll', () => {
    decisionHistoryMockResponse.decisions[0].show = 1;
    component.decisionHistory = decisionHistoryMockResponse.decisions;
    component.decisionCollapseAll();
    expect(component.decisionHistory[0].show).toBe(0);
  });


});
