import { Component, OnInit } from '@angular/core';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import { ActivatedRoute } from '@angular/router';
import { JpViewService } from 'src/app/services/jpview.service';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';

@Component({
  selector: 'app-decision-history',
  templateUrl: './decision-history.component.html',
  styleUrls: ['./decision-history.component.less']
})
export class DecisionHistoryComponent implements OnInit {

  caseInfo: CaseInfoModel;
  decisionHistory: any;

  constructor(private readonly activatedRoute: ActivatedRoute, private readonly jpViewService: JpViewService) { }

  ngOnInit(): void {
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };
    this.getDecisionHistory();
  }

  getDecisionHistory() {
    const url = `${PtabTrialConstants.APPEALS_BASE_URL}/decision-history?serialNumber=${this.caseInfo.serialNo}&appealNumber=${this.caseInfo.proceedingNo}`;
    this.jpViewService.getAppeals(url).subscribe((decisionHistoryResponse) => {
      this.decisionHistory = decisionHistoryResponse.decisions;
    });
  }

  getAPJ1(panel) {
    if (panel.length !== 0) {
      let foundJudge;
      panel.forEach(judge => {
        if (judge.panelRank === 1) {
          foundJudge = judge;
        }
      });
      return foundJudge.panelName;
    }
    return "";
  }

  getAPJ1AssignedDate(panel) {
    if (panel.length !== 0) {
      let foundJudge;
      panel.forEach((judge) => {
        if (judge.panelRank === 1) {
          foundJudge = judge;
        }
      });
      return foundJudge.assignedDate;
    }
    return "";
  }

  expand(data) {
    if (data.show && data.show === 1) {
      data.show = 0;
      return '';
    }
    data.show = 1;
    return 'expandRow';
  };

  isExpanded(data) {
    if (!data.show) {
      data.show = 0;
      return '';
    }
    if (data.show && data.show === 1) {
      return 'expandRow';
    }
    return '';
  };

  decisionExpandAll() {
    this.decisionHistory.forEach(row => {
      row.show = 1;
    });
  };


  decisionCollapseAll() {
    this.decisionHistory.forEach(row => {
      row.show = 0;
    });
  };

}
