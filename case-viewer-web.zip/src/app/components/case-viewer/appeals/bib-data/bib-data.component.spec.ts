import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { JpViewService } from 'src/app/services/jpview.service';
// import * as bibDataResponse from 'src/assets/test_data/bibDataResponse.json';
import { of } from 'rxjs';
import { BibDataComponent } from './bib-data.component';
import DescriptiveInfoModel from 'src/app/models/appeals/DescriptiveInfo.model';
import { DescriptiveInfoComponent } from '../bib-data/descriptive-info/descriptive-info.component';
import { ParentInfoComponent } from '../bib-data/parent-info/parent-info.component';
import { CorrespondenceInfoComponent } from '../bib-data/correspondence-info/correspondence-info.component';
import { ThirdPartyInfoComponent } from '../bib-data/third-party-info/third-party-info.component';
import { CaseNotesComponent } from '../bib-data/case-notes/case-notes.component';
import ParentInfoModel from 'src/app/models/appeals/ParentInfo.model';
import CorrespondenceInfoModel from 'src/app/models/appeals/CorrespondenceInfo.mode';
import ThirdPartyInfoModel from 'src/app/models/appeals/ThirdPartyInfo.model';

describe('BibDataComponent', () => {
  let component: BibDataComponent;
  let fixture: ComponentFixture<BibDataComponent>;
  let jpViewService: JpViewService;
  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "08423235",
        caseNumber: "2020005372"
      }
    }
	};
	const bibDataResponse = { "corrAddress": { "streetAddressLineOneText": "PO Box 81230", "cityName": "Las Vegas", "geographicRegionName": "NV", "streetAddressLineTwoText": "", "customerNumberText": "116573", "postalCode": "89180", "nameLineOneText": "Gilbert P. Hyatt", "nameLineTwoText": "" }, "ptabReadOnlyUser": true, "thirdPartyInfo": { "cityName": null, "geographicRegionName": null, "geographicRegionCode": null, "postalCode": null, "nameLineOneText": null, "nameLineTwoText": null, "customerNumber": "116573", "worker": { "activeIndicator": false }, "addressLineOneText": null, "addressLineTwoText": null }, "descriptiveInfo": { "applicationType": "REGULAR", "panellingDisciplineDescriptionText": "Electrical", "appellantsDetails": ["GILBERT HYATT"], "inventors": [{ "persons": { "firstName": "GILBERT", "lastName": "HYATT", "identifier": "8242316", "address": { "emails": [], "physicalAddress": [{ "addressCategory": "residence", "cityName": "LAS VEGAS", "geographicRegionName": "NEVADA", "geographicRegionCode": "NV", "countryCode": "US", "nameLineOneText": "HYATT", "nameLineTwoText": "GILBERT P.", "countryName": "UNITED STATES" }], "telecommunication": [] }, "middleName": "P." }, "audit": { "lastModifiedTime": 951022800, "lastModifiedUser": "PREXAM 1 CONVERSION" }, "interestedParty": { "sequenceNumber": 1, "interestedPartyType": "IND", "referenceType": "AP", "authorityType": "INV", "partyIdentifier": "8242316", "status": "F" }, "lifeCycle": { "beginDate": 798091200 } }], "realPartiesDetails": ["GILBERT P. HYATT"], "artUnit": "2615", "artClassNumber": "382", "cpcCodeFirst": null, "caseDisciplineCode": "E", "proceedingType": null, "proceedingNumber": null, "specialType": "Petition,Prior Decision", "appealType": "Heard", "panelingDisciplineCode": "E", "ptabReceivedDate": 1594800032000, "techCenterNumber": "2600", "artSubClassNumber": "260000", "worker": { "workerNumber": "84822", "activeIndicator": false, "fullName": "DIVECHA, NISHANT B." }, "appealNumberText": "2020005372", "caseDiscipline": "Electrical" }, "parentInfo": { "inventionTitleText": "IMAGE PROCESSING SYSTEM HAVING A SAMPLED FILTER", "inventors": [{ "persons": { "firstName": "GILBERT", "lastName": "HYATT", "identifier": "5098758", "address": { "emails": [], "physicalAddress": [{ "addressCategory": "residence", "cityName": "LA PALMA", "geographicRegionName": "CALIFORNIA", "geographicRegionCode": "CA", "countryCode": "US", "nameLineOneText": "HYATT", "nameLineTwoText": "GILBERT P.", "countryName": "UNITED STATES" }], "telecommunication": [] }, "middleName": "P." }, "audit": { "lastModifiedTime": 951022800, "lastModifiedUser": "PREXAM 1 CONVERSION" }, "interestedParty": { "sequenceNumber": 1, "interestedPartyType": "IND", "referenceType": "AP", "authorityType": "INV", "partyIdentifier": "5098758", "status": "F" }, "lifeCycle": { "beginDate": 513234000 } }], "artUnit": "2606", "artClassNumber": "382", "techCenterNumber": "2600", "artSubClassNumber": "069000", "applicationNumberText": "06849243" } };
  const descriptiveInfoMock: DescriptiveInfoModel = {
		"applicationType": "REGULAR",
		"panellingDisciplineDescriptionText": "Electrical",
		"appellantsDetails": ["GILBERT HYATT"],
		"inventors": [{
			"persons": {
				"firstName": "GILBERT",
				"lastName": "HYATT",
				"identifier": "8242316",
				"address": {
					"emails": [],
					"physicalAddress": [{
						"addressCategory": "residence",
						"cityName": "LAS VEGAS",
						"geographicRegionName": "NEVADA",
						"geographicRegionCode": "NV",
						"countryCode": "US",
						"nameLineOneText": "HYATT",
						"nameLineTwoText": "GILBERT P.",
						"countryName": "UNITED STATES"
					}],
					"telecommunication": []
				},
				"middleName": "P."
			},
			"audit": {
				"lastModifiedTime": 951022800,
				"lastModifiedUser": "PREXAM 1 CONVERSION"
			},
			"interestedParty": {
				"sequenceNumber": 1,
				"interestedPartyType": "IND",
				"referenceType": "AP",
				"authorityType": "INV",
				"partyIdentifier": "8242316",
				"status": "F"
			},
			"lifeCycle": {
				"beginDate": 798091200
			}
		}],
		"realPartiesDetails": ["GILBERT P. HYATT"],
		"artUnit": "2615",
		"artClassNumber": "382",
		"cpcCodeFirst": null,
		"caseDisciplineCode": "E",
		"proceedingType": null,
		"proceedingNumber": null,
		"specialType": "Petition,Prior Decision",
		"appealType": "Heard",
		"panelingDisciplineCode": "E",
		"ptabReceivedDate": 1594800032000,
		"techCenterNumber": "2600",
		"artSubClassNumber": "260000",
		"worker": {
			"workerNumber": "84822",
			"activeIndicator": false,
			"fullName": "DIVECHA, NISHANT B."
		},
		"appealNumberText": "2020005372",
		"caseDiscipline": "Electrical"
	};
	const parentInfoMock: ParentInfoModel = {
		"inventionTitleText": "IMAGE PROCESSING SYSTEM HAVING A SAMPLED FILTER",
		"inventors": [{
			"persons": {
				"firstName": "GILBERT",
				"lastName": "HYATT",
				"identifier": "5098758",
				"address": {
					"emails": [],
					"physicalAddress": [{
						"addressCategory": "residence",
						"cityName": "LA PALMA",
						"geographicRegionName": "CALIFORNIA",
						"geographicRegionCode": "CA",
						"countryCode": "US",
						"nameLineOneText": "HYATT",
						"nameLineTwoText": "GILBERT P.",
						"countryName": "UNITED STATES"
					}],
					"telecommunication": []
				},
				"middleName": "P."
			},
			"audit": {
				"lastModifiedTime": 951022800,
				"lastModifiedUser": "PREXAM 1 CONVERSION"
			},
			"interestedParty": {
				"sequenceNumber": 1,
				"interestedPartyType": "IND",
				"referenceType": "AP",
				"authorityType": "INV",
				"partyIdentifier": "5098758",
				"status": "F"
			},
			"lifeCycle": {
				"beginDate": 513234000
			}
		}],
		"artUnit": "2606",
		"artClassNumber": "382",
		"techCenterNumber": "2600",
		"artSubClassNumber": "069000",
		"applicationNumberText": "06849243"
	};
	const correspondenceInfoMock: CorrespondenceInfoModel = {
		"streetAddressLineOneText": "PO Box 81230",
		"cityName": "Las Vegas",
		"geographicRegionName": "NV",
		"streetAddressLineTwoText": "",
		"customerNumberText": "116573",
		"postalCode": "89180",
		"nameLineOneText": "Gilbert P. Hyatt",
		"nameLineTwoText": ""
	};
	const thirdPartyInfoMock: ThirdPartyInfoModel = {
		"cityName": null,
		"geographicRegionName": null,
		"geographicRegionCode": null,
		"postalCode": null,
		"nameLineOneText": null,
		"nameLineTwoText": null,
		"customerNumber": "116573",
		"worker": {
			"activeIndicator": false
		},
		"addressLineOneText": null,
		"addressLineTwoText": null
	};
	const externalUrlMock = [{ "valueText": "INVENTOR_URL", "descriptionText": "http://palmapps-fqt.etc.uspto.gov/cgi-bin/expo/GenInfo/sninventors.pl?" }, { "valueText": "PHASE_VALUES", "descriptionText": "{\"Preappeal\":\"Pre-appeal\",\"PendingDocketing\":\"Pending Master Docketing\",\"PendingMasterDocketing\":\"Pending Master Docketing\",\"PendingPaneling\":\"Pending Paneling\",\"PendingHearing\":\"Pending Hearing\",\"PendingDecision\":\"Pending Decision\",\"PendingRehearingDecision\":\"Pending Rehearing Decision\",\"PendingSubDecision\":\"Pending Subsequent Decision\",\"PendingRehDecision\":\"Pending Rehearing Decision\",\"PendingDisposal\":\"Pending Disposal\",\"panelTab\":\"Pending Paneling\",\"PendingAdminRemand\":\"Pending Admin Remand\",\"PendingDismissal\":\"Pending Dismissal\",\"decisionClosed\":\"Decision Rendered->Closed\",\"PendingDisp\":\"Pending Disposal\",\"rehearingDecisionRendered\":\"Rehearing Decision Rendered\",\"decisionRend\":\"Decision Rendered\",\"SubDecisionRend\":\"Subsequent Decision Rendered\",\"penPaneling\":\"Pending Paneling\",\"penHearing\":\"Pending Hearing\",\"onBrief\":\"On brief\",\"heard\":\"Heard\",\"caseDisposed\":\"Disposed\",\"penDicision\":\"Pending Decision\",\"casePaneled\":\"Paneled\",\"masterDocket\":\"Master Docket\",\"hearingComplete\":\"Hearing Complete\",\"dismissed\":\"Dismissed\",\"remanded\":\"Remanded\",\"penRehaering\":\"Pending Rehearing\",\"decision\":\"DECISION\"}" }, { "valueText": "Panel", "descriptionText": "ADDC,ADDR,DDIC,ADM,ADDAPJ,ASDDP,SDDIC,PSDP,PSDAP,PAPJ,RDDIC,APLGD,RPWF,PSD,PAD,NOHM,NOHMNO,PVHR,PTHR,PRR,AHA,UHADDC" }, { "valueText": "Rehearing", "descriptionText": "DECISION,DISP" }, { "valueText": "Reorder", "descriptionText": "ADDC,DDIC,UHADDC,RDDIC,SDDIC,APLGD" }, { "valueText": "SHORT_PHASE_VALUES", "descriptionText": "{\"PendingDocketingCollapse\":\"PD\",\"PendingPanelingCollapse\":\"PP\",\"PendingHearingCollapse\":\"PH\",\"PendingDecisionCollapse\":\"PD\",\"PendingRehearingDecisionCollapse\":\"PRD\",\"PendingDisposalCollapse\":\"PD\",\"masterDocCollapse\":\"MD\",\"pendingAdminRemCollapse\":\"PAR\",\"pendingDocollapse\":\"PD\",\"pendingHRCollapse\":\"PH\",\"pendingREHCollapse\":\"PRD\",\"pendingSUBCollapse\":\"PSD\",\"pendingPanelCollapse\":\"PP\",\"decisionRenCollapse\":\"DR\",\"decisionDisCollapse\":\"DI\",\"statusCodeADM\":\"ADM\",\"remandCollapse\":\"REM\",\"hearingCollapse\":\"HC\",\"panelCollapse\":\"PL\",\"pendingMasterCollapse\":\"PM\",\"rehearingRenderedSmall\":\"RDR\",\"subsequentRenderedSmall\":\"SDR\"}" }, { "valueText": "Subsequent", "descriptionText": "DECISION,DISP" }, { "valueText": "UPDATE_PANEL_ACCESS", "descriptionText": "ADDC,ADDR,DDIC,ADM,ADDAPJ,ASDDP,SDDIC,PSDP,PSDAP,PAPJ,RDDIC,APLGD,RPWF,PSD,PAD,NOHM,NOHMNO,PVHR,PTHR,PRR,AHA,UHADDC" }, { "valueText": "Update_Rehearing", "descriptionText": "DECISION,AWRP,DISP" }, { "valueText": "Vacate", "descriptionText": "DECISION,DISP" }];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [BibDataComponent, DescriptiveInfoComponent, ParentInfoComponent, CorrespondenceInfoComponent, ThirdPartyInfoComponent, CaseNotesComponent],
      providers: [
        JpViewService,
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BibDataComponent);
    jpViewService = TestBed.inject(JpViewService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getBibDataInfo and return success response', () => {
    spyOn(jpViewService, 'getBibData').and.returnValue(of(bibDataResponse));
    component.getBibDataInfo();
    console.log("Real: ", component.descriptiveInfo);
    console.log("Mock: ", descriptiveInfoMock)
	  expect(component.descriptiveInfo).toEqual(descriptiveInfoMock);
	  expect(component.parentInfo).toEqual(parentInfoMock);
	  expect(component.correspondenceInfo).toEqual(correspondenceInfoMock);
	  expect(component.thirdPartyInfo).toEqual(thirdPartyInfoMock);
  });


	it('should call getExternalUrl and return success response', () => {
		spyOn(jpViewService, 'getBibData').and.returnValue(of(externalUrlMock));
		component.getExternalUrl();
		expect(component.inventorUrl).toBe("http://palmapps-fqt.etc.uspto.gov/cgi-bin/expo/GenInfo/sninventors.pl?");
	});

	it('should expand all the sections', () => {
		component.expandCollapseAll('expand');
	});

	it('should collapse all the sections', () => {
		component.expandCollapseAll('collapse');
	});

});
