import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';

import { DescriptiveInfoComponent } from './descriptive-info.component';

xdescribe('DescriptiveInfoComponent', () => {
  let component: DescriptiveInfoComponent;
  let fixture: ComponentFixture<DescriptiveInfoComponent>;
  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "08423235",
        caseNumber: "2020005372"
      }
    }
	};

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DescriptiveInfoComponent],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DescriptiveInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
