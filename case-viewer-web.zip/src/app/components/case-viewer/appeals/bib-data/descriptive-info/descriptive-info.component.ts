import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import DescriptiveInfoModel from 'src/app/models/appeals/DescriptiveInfo.model';
import CaseInfoModel from 'src/app/models/CaseInfo.model';


@Component({
  selector: 'app-descriptive-info',
  templateUrl: './descriptive-info.component.html',
  styleUrls: ['./descriptive-info.component.less']
})
export class DescriptiveInfoComponent implements OnInit {



  constructor(private activatedRoute: ActivatedRoute) { }

  @Input() descriptiveInfo: DescriptiveInfoModel;
  @Input() inventorUrl: string;
  caseInfo: CaseInfoModel;

  ngOnInit(): void {
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };
  }

}
