import { Component, OnInit } from '@angular/core';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import { ActivatedRoute } from '@angular/router';
import { JpViewService } from 'src/app/services/jpview.service';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';

@Component({
  selector: 'app-case-notes',
  templateUrl: './case-notes.component.html',
  styleUrls: ['./case-notes.component.less']
})
export class CaseNotesComponent implements OnInit {

  caseInfo: CaseInfoModel;
  caseNotes = [];
  caseComments = [];
  notesTable = [];

  constructor(private activatedRoute: ActivatedRoute, private jpViewService: JpViewService) { }

  ngOnInit(): void {
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };
    this.getCaseNotes();
    // this.getCaseComments();
  }

  getCaseNotes() {
    let url = `${PtabTrialConstants.APPEALS_BASE_URL}/case-information/notes?serialNumber=${this.caseInfo.serialNo}&appealNumber=${this.caseInfo.proceedingNo}`;
    this.jpViewService.getCaseNotes(url).subscribe((caseNotesResponse) => {
      console.log('caseNotesResponse: ', caseNotesResponse);
      if (caseNotesResponse.appealNoteHistoryList) {
        caseNotesResponse.appealNoteHistoryList.sort(function (a, b) {
          return b.sequenceNumber - a.sequenceNumber;
        });
        this.caseNotes = caseNotesResponse.appealNoteHistoryList;
        this.caseNotes.forEach((caseNote) => {
          let html = caseNote.noteText;
          let div = document.createElement("div");
          div.innerHTML = html;
          caseNote.caseNotesRaw = div.innerText;
        });
        console.log(JSON.stringify(this.caseNotes));
        this.getCaseComments();
      }
    });
  }

  getCaseComments() {
    let url = `${PtabTrialConstants.APPEALS_BASE_URL}/appeal-comment-history?serialNumber=${this.caseInfo.serialNo}&appealNumber=${this.caseInfo.proceedingNo}`;
    this.jpViewService.getCaseComments(url).subscribe((caseCommentsResponse) => {
      console.log('caseCommentsResponse: ', caseCommentsResponse);
      if (caseCommentsResponse) {
        caseCommentsResponse.sort((a, b) => {
          return b.sequenceNumber - a.sequenceNumber;
        });
        this.caseComments = caseCommentsResponse;
        console.log(JSON.stringify(this.caseComments));
        this.createTableData();
      }
    });
  }

  createTableData() {
    this.notesTable = [];
          this.caseNotes.forEach((note) => {
            let tempNote = {
              "caseNotesRaw": note.caseNotesRaw,
              "text": note.noteText,
              "type": "Note",
              "lastModifiedUserId": note.audit.lastModifiedUserIdentifier,
              "lastModifiedTime": note.audit.lastModifiedTimestamp
            };
            this.notesTable.push(tempNote);
          });
          this.caseComments.forEach((comment) => {
            let tempComment = {
              "caseNotesRaw": comment.commentText,
              "text": comment.commentText,
              "type": "Comment",
              "lastModifiedUserId": comment.audit.lastModifiedUserIdentifier,
              "lastModifiedTime": comment.audit.lastModifiedTimestamp
            };
            this.notesTable.push(tempComment);
          });
          this.notesTable.sort(function (a, b) {
            return b.lastModifiedTime - a.lastModifiedTime;
          });
    console.log(JSON.stringify(this.notesTable));
  }

}
