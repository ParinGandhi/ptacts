import { Component, OnInit } from '@angular/core';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import { ActivatedRoute } from '@angular/router';
import { JpViewService } from 'src/app/services/jpview.service';
import DescriptiveInfoModel from 'src/app/models/appeals/DescriptiveInfo.model';
import ParentInfoModel from 'src/app/models/appeals/ParentInfo.model';
import CorrespondenceInfoModel from 'src/app/models/appeals/CorrespondenceInfo.mode';
import ThirdPartyInfoModel from 'src/app/models/appeals/ThirdPartyInfo.model';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';

@Component({
  selector: 'app-bib-data',
  templateUrl: './bib-data.component.html',
  styleUrls: ['./bib-data.component.less']
})
export class BibDataComponent implements OnInit {

  caseInfo: CaseInfoModel;
  descriptiveInfo: DescriptiveInfoModel;
  parentInfo: ParentInfoModel;
  correspondenceInfo: CorrespondenceInfoModel;
  thirdPartyInfo: ThirdPartyInfoModel;
  inventorUrl: string;
  _jpViewService: JpViewService;
  expandCollapseLinkList: Array<string> = ["descriptiveInformationLink", "parentInformationLink", "correspondenceInformationLink", "thirdPartyInformationLink", "caseNotesLink"];


  constructor(private activatedRoute: ActivatedRoute, private jpViewService: JpViewService) {
    this._jpViewService = jpViewService;
   }

  ngOnInit(): void {
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };

    this.getBibDataInfo();
    this.getExternalUrl();
  }

  getBibDataInfo() {
    let url = `${PtabTrialConstants.APPEALS_BASE_URL}/case-information/bib-data?serialNumber=${this.caseInfo.serialNo}&appealNumber=${this.caseInfo.proceedingNo}&proceedingType=APPEAL`;
    this.jpViewService.getBibData(url).subscribe((bibDataResponse) => {
      this.descriptiveInfo = bibDataResponse.descriptiveInfo;
      this.parentInfo = bibDataResponse.parentInfo;
      this.correspondenceInfo = bibDataResponse.corrAddress;
      this.thirdPartyInfo = bibDataResponse.thirdPartyInfo;
    })
  };

  getExternalUrl() {
    let url = `${PtabTrialConstants.APPEALS_BASE_URL}/reference-data/code-reference-types?typeCode=CHEVRON_PHASES`;
    this.jpViewService.getBibData(url).subscribe((externalUrlResponse) => {
      console.log('externalUrlResponse: ', externalUrlResponse);
      if (externalUrlResponse.length > 0) {
        externalUrlResponse.forEach(item => {
          switch (item.valueText) {
            case "INVENTOR_URL":
              this.inventorUrl = item.descriptionText;
              break;
            default:
              break;
          }
        });
      }
      console.log("Inventor URL: ", this.inventorUrl);
    });
  };

  expandCollapseAll(status) {
    let idList = ["descriptiveInformation", "parentInformation", "correspondenceInformation", "thirdPartyInformation", "caseNotes"];
    let linksList = ["descriptiveInformationLink", "parentInformationLink", "correspondenceInformationLink", "thirdPartyInformationLink", "caseNotesLink"];
    for (let j = 0; j < linksList.length; j++) {
      // let el = document.getElementById(linksList[j]);
      // el.classList.add('collapsed');
      if (status === 'expand') {
        // let currentLink = document.getElementById(linksList[j]).classList.remove('collapsed');
        let currentLink = document.getElementById(linksList[j]);
        currentLink.classList.remove('collapsed');
      } else if (status === 'collapse') {
        document.getElementById(linksList[j]).classList.add('collapsed');
      }
    }
    for (let i = 0; i < idList.length; i++) {
      // let el = document.getElementById(idList[i]);
      // el.classList.remove('in');
      if (status === 'expand') {
        // document.getElementById(idList[i]).classList.add('in');
        let currentId = document.getElementById(idList[i]);
        currentId.classList.add('in');
        console.log(currentId.classList);
      } else if (status === 'collapse') {
        document.getElementById(idList[i]).classList.remove('in');
      }
    }
  }

}
