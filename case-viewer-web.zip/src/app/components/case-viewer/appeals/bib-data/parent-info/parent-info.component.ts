import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import ParentInfoModel from 'src/app/models/appeals/ParentInfo.model';
import CaseInfoModel from 'src/app/models/CaseInfo.model';

@Component({
  selector: 'app-parent-info',
  templateUrl: './parent-info.component.html',
  styleUrls: ['./parent-info.component.less']
})
export class ParentInfoComponent implements OnInit {

  constructor(private activatedRoute: ActivatedRoute) { }

  @Input() parentInfo: ParentInfoModel;
  @Input() inventorUrl: string;
  caseInfo: CaseInfoModel;

  ngOnInit(): void {
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };
  }

}
