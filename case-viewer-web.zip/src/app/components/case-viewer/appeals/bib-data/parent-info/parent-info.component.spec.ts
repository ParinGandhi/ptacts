import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { ParentInfoComponent } from './parent-info.component';

xdescribe('ParentInfoComponent', () => {
  let component: ParentInfoComponent;
  let fixture: ComponentFixture<ParentInfoComponent>;
  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "08423235",
        caseNumber: "2020005372"
      }
    }
	};

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ParentInfoComponent],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ParentInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
