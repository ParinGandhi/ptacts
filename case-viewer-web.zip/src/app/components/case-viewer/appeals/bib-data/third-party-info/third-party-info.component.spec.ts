import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ThirdPartyInfoComponent } from './third-party-info.component';

xdescribe('ThirdPartyInfoComponent', () => {
  let component: ThirdPartyInfoComponent;
  let fixture: ComponentFixture<ThirdPartyInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ThirdPartyInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ThirdPartyInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
