import { Component, OnInit, Input } from '@angular/core';
import ThirdPartyInfoModel from 'src/app/models/appeals/ThirdPartyInfo.model';

@Component({
  selector: 'app-third-party-info',
  templateUrl: './third-party-info.component.html',
  styleUrls: ['./third-party-info.component.less']
})
export class ThirdPartyInfoComponent implements OnInit {

  constructor() { }

  @Input() thirdPartyInfo: ThirdPartyInfoModel;

  ngOnInit(): void {
  }

}
