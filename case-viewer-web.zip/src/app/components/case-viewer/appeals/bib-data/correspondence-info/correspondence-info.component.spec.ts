import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CorrespondenceInfoComponent } from './correspondence-info.component';

xdescribe('CorrespondenceInfoComponent', () => {
  let component: CorrespondenceInfoComponent;
  let fixture: ComponentFixture<CorrespondenceInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CorrespondenceInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CorrespondenceInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
