import { Component, OnInit, Input } from '@angular/core';
import CorrespondenceInfoModel from 'src/app/models/appeals/CorrespondenceInfo.mode';

@Component({
  selector: 'app-correspondence-info',
  templateUrl: './correspondence-info.component.html',
  styleUrls: ['./correspondence-info.component.less']
})
export class CorrespondenceInfoComponent implements OnInit {

  @Input() correspondenceInfo: CorrespondenceInfoModel;

  constructor() { }

  ngOnInit(): void {
  }

}
