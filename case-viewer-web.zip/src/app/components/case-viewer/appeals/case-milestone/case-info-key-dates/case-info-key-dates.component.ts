import { Component, OnInit, Input } from '@angular/core';
import MilestoneDatesModel from 'src/app/models/appeals/MilestoneDates.model';


@Component({
  selector: 'app-case-info-key-dates',
  templateUrl: './case-info-key-dates.component.html',
  styleUrls: ['./case-info-key-dates.component.less']
})
export class CaseInfoKeyDatesComponent implements OnInit {

  constructor() { }

  @Input() caseInfoKeyDates: MilestoneDatesModel;

  ngOnInit(): void {
  }

}
