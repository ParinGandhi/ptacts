import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { provideMockStore } from '@ngrx/store/testing';
import { TrialsService } from 'src/app/services/trials.service';
import { CommonService } from 'src/app/services/common.service';
import { ToastrService } from 'ngx-toastr';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import MilestoneDatesModel from 'src/app/models/appeals/MilestoneDates.model';
import { CaseMilestoneComponent } from './case-milestone.component';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { DatePipe } from '@angular/common';
import { EventEmitter } from '@angular/core';
import { throwError } from 'rxjs';


/**
 * 92.55%
 */
fdescribe('CaseMilestoneComponent', () => {
  let component: CaseMilestoneComponent;
  let fixture: ComponentFixture<CaseMilestoneComponent>;
  let modalService: BsModalService;
  let trialsService: TrialsService;
  let commonUtils: CommonUtilitiesService;
  let toastr: ToastrService;
  let commonService: CommonService;

  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => { },
    error: (
      message?: string,
      title?: string
    ) => { },
  };

  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "08423235",
        caseNumber: "DER2014-00355"
      }
    }
  };

  const mockToutcomeList = [{ "decisionOutcomeGroupTypes": [{ "decisionOutComeTypes": [{ "identifier": 4, "code": "ADVRSBINST", "descriptionText": "Request for adverse judgment before institution", "beginingEffectiveDate": "2021-03-15", "outComeCategoryType": 2, "outComeCategoryDesc": "Termination Decision" }, { "identifier": 5, "code": "ADVRSAINST", "descriptionText": "Request For Adverse Judgment After Institution", "beginingEffectiveDate": "2021-03-15", "outComeCategoryType": 2, "outComeCategoryDesc": "Termination Decision" }, { "identifier": 6, "code": "SETLBINST", "descriptionText": "Settled Before Institution", "beginingEffectiveDate": "2021-03-15", "outComeCategoryType": 2, "outComeCategoryDesc": "Termination Decision" }, { "identifier": 7, "code": "SETLAINST", "descriptionText": "Settled After Institution", "beginingEffectiveDate": "2021-03-15", "outComeCategoryType": 2, "outComeCategoryDesc": "Termination Decision" }, { "identifier": 8, "code": "DISMBINST", "descriptionText": "Dismissed Before Institution", "beginingEffectiveDate": "2021-03-15", "outComeCategoryType": 2, "outComeCategoryDesc": "Termination Decision" }, { "identifier": 9, "code": "VACT INST Decision", "descriptionText": "Vacate Institution Decision", "beginingEffectiveDate": "2021-03-15", "outComeCategoryType": 2, "outComeCategoryDesc": "Termination Decision" }, { "identifier": 10, "code": "Vacate FWD", "descriptionText": "Vacate FWD", "beginingEffectiveDate": "2021-03-15", "outComeCategoryType": 2, "outComeCategoryDesc": "Termination Decision" }, { "identifier": 11, "code": "DISAInstitution", "descriptionText": "Dismissed After Institution", "beginingEffectiveDate": "2021-03-15", "outComeCategoryType": 2, "outComeCategoryDesc": "Termination Decision" }, { "identifier": 12, "code": "FWD", "descriptionText": "Final Written Decision", "beginingEffectiveDate": "2021-03-15", "outComeCategoryType": 2, "outComeCategoryDesc": "Termination Decision" }, { "identifier": 14, "code": "FWD On CAFC Remand", "descriptionText": "Final Written Decision On CAFC Remand", "beginingEffectiveDate": "2021-03-15", "outComeCategoryType": 2, "outComeCategoryDesc": "Termination Decision" }, { "identifier": 17, "code": "SUB FWD AFT RHR", "descriptionText": "Subsequent Final Written Decision After Rehearing", "beginingEffectiveDate": "2021-03-15", "outComeCategoryType": 2, "outComeCategoryDesc": "Termination Decision" }] }] }]


  const aSection = {
    "categoryType": "POPR",
    "categoryDescription": "PO Preliminary Response",
    "proceedingMileStoneDetails": [
      {
        "mileStoneDate": 1398826298000,
        "mileStoneTypeName": "Preliminary Response",
        "mileStoneDescription": "Notice of accorded filing date (NOFDA)",
        "audit": {
          "lastModifiedTimestamp": 1468190956172,
          "lastModifiedUserIdentifier": "1",
          "createUserIdentifier": "1",
          "createTimestamp": 1468190956172
        },
        "referenceMileStoneDate": 1398744000000,
        "referenceMileStoneTypeName": "Preliminary Response Due Date",
        "referenceMileStoneDescription": "Proceeding Preliminary Response Due Date"
      }
    ]
  };

  const mockSection = {
    "categoryType": "DI",
    "categoryDescription": "Decision to institute",
    "proceedingMileStoneDetails": [
      {
        "audit": {
          "lastModifiedTimestamp": 1617243000869,
          "lastModifiedUserIdentifier": "3572",
          "createUserIdentifier": "3572",
          "createTimestamp": 1617243000459
        },
        "dateCalculationReferenceIdentifier": 7,
        "decisionOutcomeDetails": {
          "descriptionText": "Institution Denied",
          "label": "Institution decision outcome",
          "outcomeType": "Granted"
        },
        "mileStoneDate": 1617249600000,
        "mileStoneDateString": "2021-04-01",
        "mileStoneDescription": "Institution decision date",
        "mileStoneTypeName": "Decision to Institute",
        "proceedingNumber": "IPR2021-00552",
        "referenceMileStoneDate": 1617336000000,
        "referenceMileStoneDateString": "2021-04-02",
        "referenceMileStoneDescription": "Institution decision due date",
        "referenceMileStoneTypeName": "Decision to Institute Due Date"
      },
      {
        "audit": {
          "lastModifiedUserIdentifier": "sbartlett",
          "createUserIdentifier": "sbartlett",
          "createTimestamp": 1617163200000,
          "lastModifiedTimestamp": 1617163200000
        },
        "mileStoneDate": 1621051200000,
        "mileStoneDateString": "2021-05-15",
        "mileStoneDescription": "Hearing date",
        "mileStoneTypeName": "Hearing date",
        "proceedingNumber": "IPR2021-00552",
        "referenceMileStoneDateString": ""
      }
    ]
  }

  const mockSection2 = {
    categoryDescription: "Petition filing and review",
    categoryType: "Review",
    proceedingMileStoneDetails: [{
      audit: { lastModifiedTimestamp: 1614462368291, lastModifiedUserIdentifier: "100850", createUserIdentifier: "100850", createTimestamp: 1614462368291 },
      mileStoneDate: 1613365200000,
      mileStoneDateString: "2021-02-15",
      mileStoneDescription: "Filing date",
      mileStoneTypeName: "Filing Date",
      proceedingNumber: "IPR2021-00552",
      referenceMileStoneDateString: ""
    }, {
      audit: { lastModifiedTimestamp: 1619552551478, lastModifiedUserIdentifier: "5041", createUserIdentifier: "5041", createTimestamp: 1619552518466 },
      mileStoneDate: 1610686800000,
      mileStoneDateString: "2021-01-15",
      mileStoneDescription: "Accorded filing date",
      mileStoneTypeName: "Accorded Filing Date",
      proceedingNumber: "IPR2021-00552",
      referenceMileStoneDateString: ""
    }, {
      audit: { lastModifiedTimestamp: 1619552551556, lastModifiedUserIdentifier: "5041", createUserIdentifier: "5041", createTimestamp: 1619552551555 },
      dateCalculationReferenceIdentifier: 12,
      mileStoneDate: 1618459200000,
      mileStoneDateString: "2021-04-15",
      mileStoneDescription: "Notice of accorded filing date (NOFDA)",
      mileStoneTypeName: "Notice of Accorded Filing Date",
      proceedingNumber: "IPR2021-00552",
      referenceMileStoneDateString: ""
    }]
  }

  const mockSection3 = {
    categoryDescription: "Termination decision",
    categoryType: "Termination",
    proceedingMileStoneDetails: [{
      audit: { lastModifiedTimestamp: 1619577415262, lastModifiedUserIdentifier: "3572", createUserIdentifier: "3572", createTimestamp: 1619577415160 },
      decisionOutcomeDetails: { outcomeType: "Vacate FWD", descriptionText: "Dismissed Before Institution", label: "Termination decision or final decision outcome" },
      mileStoneDate: 1618545600000,
      mileStoneDateString: "2021-04-16",
      mileStoneDescription: "Termination decision or final decision date",
      mileStoneTypeName: "Termination Decision",
      proceedingNumber: "DER2018-00019",
      referenceMileStoneDate: 1617249600000,
      referenceMileStoneDateString: "2021-04-01",
      referenceMileStoneDescription: "Final written decision due date",
      referenceMileStoneTypeName: "Final Decision Due Date"
    }]
  }

  const mockAppealsSection = {
    categoryDescription: "Appeals",
    categoryType: "CAFC",
    proceedingMileStoneDetails: [{
      audit: { lastModifiedTimestamp: 1614462368291, lastModifiedUserIdentifier: "100850", createUserIdentifier: "100850", createTimestamp: 1614462368291 },
      mileStoneDate: "",
      mileStoneDateString: "",
      mileStoneDescription: "FWD Remand Due Date",
      mileStoneTypeName: "FWD Remand Due Date",
      referenceMileStoneDateString: ""
    }, {
      audit: { lastModifiedTimestamp: 1619552551478, lastModifiedUserIdentifier: "5041", createUserIdentifier: "5041", createTimestamp: 1619552518466 },
      mileStoneDate: "",
      mileStoneDateString: "",
      mileStoneDescription: "Notice of Appeal due date",
      mileStoneTypeName: "Notice of Appeal due date",
      referenceMileStoneDateString: ""
    }, {
      audit: { lastModifiedTimestamp: 1619552551556, lastModifiedUserIdentifier: "5041", createUserIdentifier: "5041", createTimestamp: 1619552551555 },
      mileStoneDate: "",
      mileStoneDateString: "",
      mileStoneDescription: "PO's notice of appeal filing date",
      mileStoneTypeName: "PO NOAFD",
      referenceMileStoneDateString: ""
    }, {
      audit: { lastModifiedTimestamp: 1619552551556, lastModifiedUserIdentifier: "5041", createUserIdentifier: "5041", createTimestamp: 1619552551555 },
      mileStoneDate: "",
      mileStoneDateString: "",
      mileStoneDescription: "Petitioner's notice of appeal filing date",
      mileStoneTypeName: "Petitioner NOAFD",
      referenceMileStoneDateString: ""
    }, {
      audit: { lastModifiedTimestamp: 1619552551556, lastModifiedUserIdentifier: "5041", createUserIdentifier: "5041", createTimestamp: 1619552551555 },
      mileStoneDate: "",
      mileStoneDateString: "",
      mileStoneDescription: "CAFC Decision date",
      mileStoneTypeName: "CAFC Decision date",
      referenceMileStoneDateString: ""
    }, {
      audit: { lastModifiedTimestamp: 1619552551556, lastModifiedUserIdentifier: "5041", createUserIdentifier: "5041", createTimestamp: 1619552551555 },
      mileStoneDate: "",
      mileStoneDateString: "",
      mileStoneDescription: "CAFC Mandate date",
      mileStoneTypeName: "CAFC Mandate date",
      referenceMileStoneDateString: ""
    }]
  }

  const caseMilestoneMockResponse2 =
    [
      {
        "categoryType": "POPR",
        "categoryDescription": "PO Preliminary Response",
        "proceedingMileStoneDetails": [
          {
            "mileStoneDate": 1398826298000,
            "mileStoneTypeName": "Preliminary Response",
            "mileStoneDescription": "Proceeding Preliminary Response",
            "audit": {
              "lastModifiedTimestamp": 1468190956172,
              "lastModifiedUserIdentifier": "1",
              "createUserIdentifier": "1",
              "createTimestamp": 1468190956172
            },
            "referenceMileStoneDate": 1398744000000,
            "referenceMileStoneTypeName": "Preliminary Response Due Date",
            "referenceMileStoneDescription": "Proceeding Preliminary Response Due Date"
          }
        ]
      },
      {
        "categoryType": "DI",
        "categoryDescription": "Decision to Institute",
        "proceedingMileStoneDetails": [
          {
            "mileStoneDate": 1405437720000,
            "mileStoneTypeName": "Decision to Institute",
            "mileStoneDescription": "Proceeding Decision to Institute",
            "audit": {
              "lastModifiedTimestamp": 1615836946521,
              "lastModifiedUserIdentifier": "1",
              "createUserIdentifier": "1",
              "createTimestamp": 1468190956172
            },
            "referenceMileStoneDate": 1406606400000,
            "referenceMileStoneTypeName": "Decision to Institute Due Date",
            "referenceMileStoneDescription": "Proceeding Decision to Institute Due Date"
          }
        ]
      },
      {
        "categoryType": "Standard Life Cycle",
        "categoryDescription": "Standard Life Cycle",
        "proceedingMileStoneDetails": [
          {
            "mileStoneDate": 1405437720000,
            "mileStoneTypeName": "Hearing Date",
            "mileStoneDescription": "Proceeding Institution Decision Hearing Date",
            "outcomeStatus": "test",
            "decisionOutcomeDetails": {
              "outcomeType": "Instuited",
              "descriptionText": "Instuited"
            },
            "audit": {
              "lastModifiedTimestamp": 1615840804195,
              "lastModifiedUserIdentifier": "1",
              "createUserIdentifier": "1",
              "createTimestamp": 1615838070521
            }
          }
        ]
      },
      {
        "categoryType": "Review",
        "categoryDescription": "Petition filing and review",
        "proceedingMileStoneDetails": [
          {
            "mileStoneDate": 1389762000000,
            "mileStoneTypeName": "Filing Date",
            "mileStoneDescription": "Proceeding Filing Date",
            "audit": {
              "lastModifiedTimestamp": 1468190956171,
              "lastModifiedUserIdentifier": "1",
              "createUserIdentifier": "1",
              "createTimestamp": 1468190956171
            }
          }
        ]
      },
      {
        "categoryType": "Review",
        "categoryDescription": "Petition filing and review",
        "proceedingMileStoneDetails": [
          {
            "mileStoneDate": 1389762000000,
            "mileStoneTypeName": "Accorded Filing Date",
            "mileStoneDescription": "Proceeding Accorded Filing Date",
            "audit": {
              "lastModifiedTimestamp": 1468190956171,
              "lastModifiedUserIdentifier": "1",
              "createUserIdentifier": "1",
              "createTimestamp": 1468190956171
            }
          }
        ]
      },
      {
        "categoryType": "Review",
        "categoryDescription": "Petition filing and review",
        "proceedingMileStoneDetails": [
          {
            "mileStoneDate": 1391031420000,
            "mileStoneTypeName": "Notice of Accorded Filing Date",
            "mileStoneDescription": "Proceeding Notice of Accorded Filing Date",
            "audit": {
              "lastModifiedTimestamp": 1468190956171,
              "lastModifiedUserIdentifier": "1",
              "createUserIdentifier": "1",
              "createTimestamp": 1468190956171
            }
          }
        ]
      },
      {
        "categoryType": "Termination",
        "categoryDescription": "Termination Decision",
        "proceedingMileStoneDetails": [
          {
            "mileStoneDate": 1436932800000,
            "mileStoneTypeName": "Final Decision Due Date",
            "mileStoneDescription": "Proceeding Final Decision Due Date",
            "audit": {
              "lastModifiedTimestamp": 1468190956173,
              "lastModifiedUserIdentifier": "1",
              "createUserIdentifier": "1",
              "createTimestamp": 1468190956173
            }
          }
        ]
      },
      {
        "categoryType": "Termination",
        "categoryDescription": "Termination Decision",
        "proceedingMileStoneDetails": [
          {
            "mileStoneDate": 1405437720000,
            "mileStoneTypeName": "Termination Decision",
            "mileStoneDescription": "Proceeding Termination Decision",
            "audit": {
              "lastModifiedTimestamp": 1468190956173,
              "lastModifiedUserIdentifier": "1",
              "createUserIdentifier": "1",
              "createTimestamp": 1468190956173
            }
          }
        ]
      }
    ];

  const caseMilestoneMockResponse3 =
    [
      {
        "categoryType": "POPR",
        "categoryDescription": "PO Preliminary Response",
        "proceedingMileStoneDetails": [
          {
            "mileStoneDate": 1398826298000,
            "mileStoneTypeName": "Preliminary Response",
            "mileStoneDescription": "Proceeding Preliminary Response",
            "audit": {
            },
            "referenceMileStoneDate": 1398744000000,
            "referenceMileStoneTypeName": "Preliminary Response Due Date",
            "referenceMileStoneDescription": "Proceeding Preliminary Response Due Date"
          }
        ]
      },
      {
        "categoryType": "DI",
        "categoryDescription": "Decision to Institute",
        "proceedingMileStoneDetails": [
          {
            "mileStoneDate": 1405437720000,
            "mileStoneTypeName": "Decision to Institute",
            "mileStoneDescription": "Proceeding Decision to Institute",
            "audit": {
            },
            "referenceMileStoneDate": 1406606400000,
            "referenceMileStoneTypeName": "Decision to Institute Due Date",
            "referenceMileStoneDescription": "Proceeding Decision to Institute Due Date"
          }
        ]
      },
      {
        "categoryType": "Standard Life Cycle",
        "categoryDescription": "Standard Life Cycle",
        "proceedingMileStoneDetails": [
          {
            "mileStoneDate": 1405437720000,
            "mileStoneTypeName": "Hearing Date",
            "mileStoneDescription": "Proceeding Institution Decision Hearing Date",
            "outcomeStatus": "test",
            "decisionOutcomeDetails": {
              "outcomeType": "Instuited",
              "descriptionText": "Instuited"
            },
            "audit": {
            }
          }
        ]
      },
      {
        "categoryType": "Review",
        "categoryDescription": "Petition filing and review",
        "proceedingMileStoneDetails": [
          {
            "mileStoneDate": 1389762000000,
            "mileStoneTypeName": "Filing Date",
            "mileStoneDescription": "Proceeding Filing Date",
            "audit": {
            }
          }
        ]
      },
      {
        "categoryType": "Review",
        "categoryDescription": "Petition filing and review",
        "proceedingMileStoneDetails": [
          {
            "mileStoneDate": 1389762000000,
            "mileStoneTypeName": "Accorded Filing Date",
            "mileStoneDescription": "Proceeding Accorded Filing Date",
            "audit": {
            }
          }
        ]
      },
      {
        "categoryType": "Review",
        "categoryDescription": "Petition filing and review",
        "proceedingMileStoneDetails": [
          {
            "mileStoneDate": 1391031420000,
            "mileStoneTypeName": "Notice of Accorded Filing Date",
            "mileStoneDescription": "Proceeding Notice of Accorded Filing Date",
            "audit": {
            }
          }
        ]
      },
      {
        "categoryType": "Termination",
        "categoryDescription": "Termination Decision",
        "proceedingMileStoneDetails": [
          {
            "mileStoneDate": 1436932800000,
            "mileStoneTypeName": "Final Decision Due Date",
            "mileStoneDescription": "Proceeding Final Decision Due Date",
            "audit": {
              "lastModifiedTimestamp": 1468190956173,
              "lastModifiedUserIdentifier": "1",
              "createUserIdentifier": "1",
              "createTimestamp": 1468190956173
            }
          }
        ]
      },
      {
        "categoryType": "Termination",
        "categoryDescription": "Termination Decision",
        "proceedingMileStoneDetails": [
          {
            "mileStoneDate": 1405437720000,
            "mileStoneTypeName": "Termination Decision",
            "mileStoneDescription": "Proceeding Termination Decision",
            "audit": {
              "lastModifiedTimestamp": 1468190956173,
              "lastModifiedUserIdentifier": "1",
              "createUserIdentifier": "1",
              "createTimestamp": 1468190956173
            }
          }
        ]
      },
      {
        "categoryType": "Derivation",
        "categoryDescription": "Derivation availability",
        "proceedingMileStoneDetails": [
          {
            "mileStoneTypeName": "Derivation availability",
            "mileStoneDescription": "Derivation availability",
            "audit": {
              "lastModifiedUserIdentifier": "sbartlett",
              "createUserIdentifier": "sbartlett",
              "createTimestamp": 1617163200000,
              "lastModifiedTimestamp": 1617163200000
            },
            "mileStoneDateString": "",
            "referenceMileStoneDateString": ""
          }
        ]
      },
      {
        "categoryType": "Rehearing",
        "categoryDescription": "Rehearing request due date",
        "proceedingMileStoneDetails": [
          {
            "mileStoneTypeName": "Rehearing request due date",
            "mileStoneDescription": "Rehearing request due date",
            "audit": {
              "lastModifiedUserIdentifier": "sbartlett",
              "createUserIdentifier": "sbartlett",
              "createTimestamp": 1617163200000,
              "lastModifiedTimestamp": 1617163200000
            },
            "mileStoneDate": 1617163200000
          }
        ]
      }
    ];

  const MockMilestoneDetails = [
    {
      "categoryType": "Review",
      "categoryDescription": "Petition filing and review",
      "proceedingMileStoneDetails": [
        {
          "mileStoneDate": 1553745600000,
          "mileStoneTypeName": "Filing Date",
          "mileStoneDescription": "Filing date",
          "audit": {
            "lastModifiedTimestamp": 1617052610218,
            "lastModifiedUserIdentifier": "3572",
            "createUserIdentifier": "11066",
            "createTimestamp": 1551803181569
          },
          "mileStoneDateString": "2019-03-28",
          "referenceMileStoneDateString": ""
        },
        {
          "mileStoneDate": 1617249600000,
          "mileStoneTypeName": "Accorded Filing Date",
          "mileStoneDescription": "Accorded filing date",
          "audit": {
            "lastModifiedTimestamp": 1617237991507,
            "lastModifiedUserIdentifier": "3572",
            "createUserIdentifier": "3572",
            "createTimestamp": 1617235376749
          },
          "mileStoneDateString": "2021-04-01",
          "referenceMileStoneDateString": "1633249600000"
        },
        {
          "mileStoneTypeName": "Notice of Accorded Filing Date",
          "mileStoneDescription": "Notice of accorded filing date (NOFDA)",
          "audit": {
            "lastModifiedUserIdentifier": "sbartlett",
            "createUserIdentifier": "sbartlett",
            "createTimestamp": 1617163200000,
            "lastModifiedTimestamp": 1617163200000
          },
          "dateCalculationReferenceIdentifier": 12,
          "mileStoneDateString": "",
          "referenceMileStoneDateString": ""
        }
      ]
    },
    {
      "categoryType": "POPR",
      "categoryDescription": "PO preliminary response",
      "proceedingMileStoneDetails": [
        {
          "mileStoneTypeName": "Preliminary Response",
          "mileStoneDescription": "PO preliminary response filing or waiver date",
          "audit": {
            "lastModifiedUserIdentifier": "sbartlett",
            "createUserIdentifier": "sbartlett",
            "createTimestamp": 1617163200000,
            "lastModifiedTimestamp": 1617163200000
          },
          "referenceMileStoneTypeName": "Preliminary Response Due Date",
          "referenceMileStoneDescription": "PO preliminary response due date",
          "dateCalculationReferenceIdentifier": 11,
          "mileStoneDateString": "",
          "referenceMileStoneDateString": ""
        }
      ]
    },
    {
      "categoryType": "DI",
      "categoryDescription": "Decision to institute",
      "proceedingMileStoneDetails": [
        {
          "mileStoneDate": 1617249600000,
          "mileStoneTypeName": "Decision to Institute",
          "mileStoneDescription": "Institution decision date",
          "decisionOutcomeDetails": {
            "outcomeType": "Granted",
            "descriptionText": "Institution Granted",
            "label": "Institution decision outcome"
          },
          "audit": {
            "lastModifiedTimestamp": 1617243000869,
            "lastModifiedUserIdentifier": "3572",
            "createUserIdentifier": "3572",
            "createTimestamp": 1617243000459
          },
          "referenceMileStoneDate": 1617336000000,
          "referenceMileStoneTypeName": "Decision to Institute Due Date",
          "referenceMileStoneDescription": "Institution decision due date",
          "dateCalculationReferenceIdentifier": 7,
          "mileStoneDateString": "2021-04-01",
          "referenceMileStoneDateString": "2021-04-02"
        },
        {
          "mileStoneTypeName": "Hearing date",
          "mileStoneDescription": "Hearing date",
          "audit": {
            "lastModifiedUserIdentifier": "sbartlett",
            "createUserIdentifier": "sbartlett",
            "createTimestamp": 1617163200000,
            "lastModifiedTimestamp": 1617163200000
          },
          "mileStoneDateString": "",
          "referenceMileStoneDateString": ""
        }
      ]
    },
    {
      "categoryType": "Termination",
      "categoryDescription": "Termination decision",
      "proceedingMileStoneDetails": [
        {
          "mileStoneTypeName": "Termination Decision",
          "mileStoneDescription": "Termination decision or final decision date",
          "audit": {
            "lastModifiedUserIdentifier": "sbartlett",
            "createUserIdentifier": "sbartlett",
            "createTimestamp": 1617163200000,
            "lastModifiedTimestamp": 1617163200000
          },
          "decisionOutcomeDetails": { "outcomeType": "Vacate FWD Test", "descriptionText": "Dismissed After Institution", label: "Termination decision or final decision outcome" },
          "referenceMileStoneDate": 1648785600000,
          "referenceMileStoneTypeName": "Final Decision Due Date",
          "referenceMileStoneDescription": "Final written decision due date",
          "mileStoneDateString": "",
          "referenceMileStoneDateString": "2022-04-01"
        }
      ]
    },
    {
      "categoryType": "Rehearing",
      "categoryDescription": "Rehearing request  (after DI, Motion or FWD) - multiple",
      "proceedingMileStoneDetails": [
        {
          "mileStoneTypeName": "Rehearing request due date",
          "mileStoneDescription": "PO's Rehearing request date",
          "audit": {
            "lastModifiedUserIdentifier": "sbartlett",
            "createUserIdentifier": "sbartlett",
            "createTimestamp": 1617163200000,
            "lastModifiedTimestamp": 1617163200000
          },
          "mileStoneDateString": "",
          "referenceMileStoneDateString": ""
        },
        {
          "mileStoneTypeName": "Petitioners request due date",
          "mileStoneDescription": "Petitioners rehearing request date",
          "audit": {
            "lastModifiedUserIdentifier": "sbartlett",
            "createUserIdentifier": "sbartlett",
            "createTimestamp": 1617163200000,
            "lastModifiedTimestamp": 1617163200000
          },
          "mileStoneDateString": "",
          "referenceMileStoneDateString": ""
        },
        {
          "mileStoneTypeName": "Rehearing decision date",
          "mileStoneDescription": "Rehearing decision date",
          "audit": {
            "lastModifiedUserIdentifier": "sbartlett",
            "createUserIdentifier": "sbartlett",
            "createTimestamp": 1617163200000,
            "lastModifiedTimestamp": 1617163200000
          },
          "mileStoneDateString": "",
          "referenceMileStoneDateString": ""
        }
      ]
    },
    {
      "categoryType": "CAFC",
      "categoryDescription": "CAFC Appeal",
      "proceedingMileStoneDetails": [
        {
          "mileStoneTypeName": "PO NOAFD",
          "mileStoneDescription": "PO's notice of appeal filing date",
          "audit": {
            "lastModifiedUserIdentifier": "sbartlett",
            "createUserIdentifier": "sbartlett",
            "createTimestamp": 1617163200000,
            "lastModifiedTimestamp": 1617163200000
          },
          "mileStoneDateString": "",
          "referenceMileStoneDateString": ""
        },
        {
          "mileStoneTypeName": "Petioner NOAFD",
          "mileStoneDescription": "Petioner's notice of appeal filing date",
          "audit": {
            "lastModifiedUserIdentifier": "sbartlett",
            "createUserIdentifier": "sbartlett",
            "createTimestamp": 1617163200000,
            "lastModifiedTimestamp": 1617163200000
          },
          "mileStoneDateString": "",
          "referenceMileStoneDateString": ""
        },
        {
          "mileStoneTypeName": "CAFC Decision date",
          "mileStoneDescription": "CAFC Decision date",
          "audit": {
            "lastModifiedUserIdentifier": "sbartlett",
            "createUserIdentifier": "sbartlett",
            "createTimestamp": 1617163200000,
            "lastModifiedTimestamp": 1617163200000
          },
          "mileStoneDateString": "",
          "referenceMileStoneDateString": ""
        },
        {
          "mileStoneTypeName": "CAFC Mandate date",
          "mileStoneDescription": "CAFC Mandate date",
          "audit": {
            "lastModifiedUserIdentifier": "sbartlett",
            "createUserIdentifier": "sbartlett",
            "createTimestamp": 1617163200000,
            "lastModifiedTimestamp": 1617163200000
          },
          "mileStoneDateString": "",
          "referenceMileStoneDateString": ""
        }
      ]
    },
    {
      "categoryType": "Trial",
      "categoryDescription": "Trial Certificate",
      "proceedingMileStoneDetails": [
        {
          "mileStoneTypeName": "Trial Certificate Date",
          "mileStoneDescription": "Trial certificate checklist date",
          "audit": {
            "lastModifiedUserIdentifier": "sbartlett",
            "createUserIdentifier": "sbartlett",
            "createTimestamp": 1617163200000,
            "lastModifiedTimestamp": 1617163200000
          },
          "mileStoneDateString": "",
          "referenceMileStoneDateString": ""
        }
      ]
    },
    {
      "categoryType": "Derivation",
      "categoryDescription": "Derivation availability",
      "proceedingMileStoneDetails": [
        {
          "mileStoneTypeName": "Derivation availability",
          "mileStoneDescription": "Derivation availability",
          "audit": {
            "lastModifiedUserIdentifier": "sbartlett",
            "createUserIdentifier": "sbartlett",
            "createTimestamp": 1617163200000,
            "lastModifiedTimestamp": 1617163200000
          },
          "mileStoneDateString": "",
          "referenceMileStoneDateString": ""
        }
      ]
    },
    {
      "categoryType": "Trial Checklist",
      "categoryDescription": "Trial certificate checklist",
      "proceedingMileStoneDetails": [
        {
          "mileStoneTypeName": "Trial Certificate Upload Date",
          "mileStoneDescription": "Trial certificate checklist upload date",
          "audit": {
            "lastModifiedUserIdentifier": "sbartlett",
            "createUserIdentifier": "sbartlett",
            "createTimestamp": 1617163200000,
            "lastModifiedTimestamp": 1617163200000
          },
          "mileStoneDateString": "",
          "referenceMileStoneDateString": ""
        }
      ]
    }
  ]

  const loggedInUserMock = {
    loginId: 'sbartlett'
  }

  const loggedInUserInfo = {
    caseDetailsData:
      [{
        activeIn: "Active",
        apjSeniorityRank: 85,
        disiplanceCd: "Electrical",
        emailAddress: "Test_Jennifer.Bisk@USPTO.GOV",
        firstName: "Jennifer",
        fullName: "Bisk, Jennifer S.",
        jobClassificationCode: "APJ",
        lastName: "Bisk",
        leadApjIndicator: "APJ1",
        loginId: "jbisk",
        preferredFullName: "Bisk, Jennifer S.",
        privileges: null,
        roleDescription: "Judge",
        trialJudgeIndicator: "Judge",
        userIdentiifier: 5017,
        userWorkerNumber: "88548",
        isAdmin: false
      }
      ]
  };

  const mockOutcomeList = [
    {
      "decisionOutcomeGroupTypes":
        [{
          "decisionOutComeTypes":
            [{
              "identifier": 13, "code": "Pet Inst Grant RHR",
              "descriptionText": "Petitioner's Rehearing Request Granted On Institution Decision Denied (Reinstituted)",
              "beginingEffectiveDate": "2021-03-15", "outComeCategoryType": 1,
              "outComeCategoryDesc": "Institution Decision"
            },
            {
              "identifier": 1, "code": "PO INST Grant RHR",
              "descriptionText": "PO Rehearing Request Granted On Institution Decision Granted (Trial Denied)",
              "beginingEffectiveDate": "2021-03-15",
              "outComeCategoryType": 1,
              "outComeCategoryDesc": "Institution Decision"
            },
            {
              "identifier": 2, "code": "Denied",
              "descriptionText": "Institution Denied",
              "beginingEffectiveDate": "2021-03-15",
              "outComeCategoryType": 1,
              "outComeCategoryDesc": "Institution Decision"
            },
            {
              "identifier": 3, "code": "Granted",
              "descriptionText": "Institution Granted",
              "beginingEffectiveDate": "2021-03-15",
              "outComeCategoryType": 1,
              "outComeCategoryDesc": "Institution Decision"
            }]
        }]
    }];

  const mockAIADocsInfo = [{
    "documentNumber": 4,
    "name": "Notice:  Notice filing date accorded",
    "category": "PAPER",
    "fileName": "test.pdf",
    "filingParty": "BOARD",
    "availability": "Public",
    "documentTypeIdentifier": 204,
    "documentTypeCode": "NOT:NOFDA",
    "documentTypeDescription": "Notice:  Notice filing date accorded",
    "pageCount": 1,
    "contentManagementId": "workspace://SpacesStore/146f2e4d-cd76-4c03-911e-d509cec08cbe;1.0",
    "artifactIdentifer": 170084482,
    "artifactSubmissionIdentifier": 85426961,
    "filingDate": 1616373630,
    "filingDateString": "03/21/2021",
    "fileSize": 0,
    "documentStatus": "PENDING",
    "directionCode": "INCOMING",
    "warningMessageList": [],
    "availablitySummary": {
      "code": "PUBLIC",
      "descriptionText": "Available for everyone.",
      "displayNameText": "Public"
    },
    "roleSummary": {
      "code": "BOARD",
      "descriptionText": "Board",
      "displayNameText": "Board"
    },
    "artifactSummary": {
      "code": "PAPER",
      "descriptionText": "Paper"
    }
  }
  ]

  const mockRehearingInfo1 = [{
    "petitionIdentifier": null,
    "patentNumber": null,
    "proceedingNumberText": null,
    "lifeCycle": null,
    "audit": null,
    "rehearingId": 315609,
    "proceedingNumber": "IPR2021-00333",
    "rehearingTypeName": "Institution Decision",
    "filedDate": 1615207752000,
    "decisionDate": 1617391002000,
    "rehearingTypeId": 1,
    "requestorTypeName": "Petitioner",
    "rehearingStatusId": 6,
    "rehearingStatus": "Granted In Part",
    "rehearingStatusDisplayName": "Granted In Part",
    "rehearingDocuments": [{}]
  }]

  const mockRehearingInfo2 = [{
    "petitionIdentifier": null,
    "patentNumber": null,
    "proceedingNumberText": null,
    "lifeCycle": null,
    "audit": null,
    "rehearingId": 315609,
    "proceedingNumber": "IPR2021-00333",
    "rehearingTypeName": "Institution Decision",
    "filedDate": 1615207752000,
    "decisionDate": 1617391002000,
    "rehearingTypeId": 1,
    "requestorTypeName": "Patent Owner",
    "rehearingStatusId": 6,
    "rehearingStatus": "Granted In Part",
    "rehearingStatusDisplayName": "Granted In Part",
    "rehearingDocuments": [{}]
  }]

  const mockRehearingInfo3 = [{
    "petitionIdentifier": null,
    "patentNumber": null,
    "proceedingNumberText": null,
    "lifeCycle": null,
    "audit": null,
    "rehearingId": 315609,
    "proceedingNumber": "IPR2021-00333",
    "rehearingTypeName": "Final Written Decision",
    "filedDate": 1615207752000,
    "decisionDate": 1617391002000,
    "rehearingTypeId": 1,
    "requestorTypeName": "Petitioner",
    "rehearingStatusId": 6,
    "rehearingStatus": "Granted In Part",
    "rehearingStatusDisplayName": "Granted In Part",
    "rehearingDocuments": [{}]
  }]

  const mockRehearingInfo4 = [{
    "petitionIdentifier": null,
    "patentNumber": null,
    "proceedingNumberText": null,
    "lifeCycle": null,
    "audit": null,
    "rehearingId": 315609,
    "proceedingNumber": "IPR2021-00333",
    "rehearingTypeName": "Final Written Decision",
    "filedDate": 1615207752000,
    "decisionDate": 1617391002000,
    "rehearingTypeId": 1,
    "requestorTypeName": "Patent Owner",
    "rehearingStatusId": 6,
    "rehearingStatus": "Granted In Part",
    "rehearingStatusDisplayName": "Granted In Part",
    "rehearingDocuments": [{}]
  }]

  const mockrehearingObj = [
    {
      "rehearingId": 315714,
      "rehearingStatus": "Granted",
      "notificationRequiredIndicator": "N",
      "decisionDate": 1624507200000,
      "filedDate": 1616644800000,
      "audit": {
        "lastModifiedUserIdentifier": "sbartlett",
        "lastModifiedTimestamp": 1622768317229
      }
    }
  ]

  const rehearingDIList = {
    "proceedingMileStoneDetails": [
      {
        "mileStoneDate": "1622768317229",
        "mileStoneDateString": "06/03/2021",
        "mileStoneDescription": "PO rehearing request date",
        "audit": {
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedTimestamp": 1622768317229
        }
      },
      {
        "mileStoneDate": "1622768317229",
        "mileStoneDateString": "06/03/2021",
        "mileStoneDescription": "Petitioner's rehearing request date",
        "audit": {
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedTimestamp": 1622768317229
        }
      },
      {
        "mileStoneDate": "1622768317229",
        "mileStoneDateString": "06/03/2021",
        "mileStoneDescription": "Rehearing decision date",
        "audit": {
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedTimestamp": 1622768317229
        }
      },
      {
        "mileStoneDate": "1622768317229",
        "mileStoneDateString": "06/03/2021",
        "mileStoneDescription": "Rehearing request due date",
        "audit": {
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedTimestamp": 1622768317229
        }
      },
      {
        "descriptionText": "Granted"
      }
    ]
  }

  const rehearingDIListPost = {
    "proceedingMileStoneDetails": [
      {
        "mileStoneDate": "1622868317229",
        "mileStoneDateString": "06/03/2021",
        "mileStoneDescription": "PO rehearing request date",
        "audit": {
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedTimestamp": 1622868317229
        }
      },
      {
        "mileStoneDate": "1622868317229",
        "mileStoneDateString": "06/03/2021",
        "mileStoneDescription": "Petitioner's rehearing request date",
        "audit": {
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedTimestamp": 1622868317229
        }
      },
      {
        "mileStoneDate": "1622868317229",
        "mileStoneDateString": "06/03/2021",
        "mileStoneDescription": "Rehearing decision date",
        "audit": {
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedTimestamp": 1622868317229
        }
      },
      {
        "mileStoneDate": "1622868317229",
        "mileStoneDateString": "06/03/2021",
        "mileStoneDescription": "Rehearing request due date",
        "audit": {
          "lastModifiedUserIdentifier": "sbartlett",
          "lastModifiedTimestamp": 1622868317229
        }
      },
      {
        "descriptionText": "Granted"
      }
    ]
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [CaseMilestoneComponent],
      providers: [CommonUtilitiesService, DatePipe,
        provideMockStore({
          selectors: [{ selector: CaseViewerSelectors.userInfoData, value: { caseDetailsData: [] } },
          {
            selector: CaseViewerSelectors.userInfoData, value: {
              caseDetailsData: [{
                activeIn: "Active",
                apjSeniorityRank: 85,
                disiplanceCd: "Electrical",
                emailAddress: "Test_Jennifer.Bisk@USPTO.GOV",
                firstName: "Jennifer",
                fullName: "Bisk, Jennifer S.",
                jobClassificationCode: "APJ",
                lastName: "Bisk",
                leadApjIndicator: "APJ1",
                loginId: "jbisk",
                preferredFullName: "Bisk, Jennifer S.",
                privileges: null,
                roleDescription: "Judge",
                trialJudgeIndicator: "Judge",
                userIdentiifier: 5017,
                userWorkerNumber: "88548",
                isAdmin: false
              }]
            }
          }]
        }),
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useValue: {}
        },
        TrialsService, {
          provide: ToastrService,
          useValue: toastrService
        },

        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        }
      ]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseMilestoneComponent);
    trialsService = TestBed.inject(TrialsService);
    commonService = TestBed.inject(CommonService);
    modalService = TestBed.inject(BsModalService);
    commonUtils = TestBed.inject(CommonUtilitiesService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should getOutcomeList', () => {

    component.getOutcomeDropDown();
    expect(component.outcomeList).toBeDefined();
  });

  it('should call getMilestoneData and return success response', () => {
    spyOn(trialsService, 'getMilestoneData').and.returnValue(of(caseMilestoneMockResponse2));
    component.getMilestoneData();
    expect(component.milestoneData).toEqual(caseMilestoneMockResponse2);
  });

  it('should call getMilestoneData without audit data', () => {
    component.caseHeaderInfo = {
      joinderTypes: [],
      petitionerPatentNumber: null,
      petitionerinventionTitle: "test",
      petitionerTechCenterNum: 1234,
      petitionerArtUnit: 1234,
      patentNumberText: 7123699,
      proceedingNumber: "DER2021-00333",
      derproceedingTypeDetails: {
        firstListedPetitionerApplicationNumber: "string",
        firstListedPatentOwnerRespondentApplicationNumber: "string",
        aiaReviewConfidentiality: "string"
      },
      techCenterNum: 1234,
      ptabReadOnlyUser: true,
      mileStoneDates: null,
      parties: "Real",
      attorneys: [],
      artUnit: 1234,
      casePhase: "new",
      inventionTitle: "test",
      keyDates: []
    };
    component.caseInfo = {
      serialNo: "7123699",
      proceedingNo: "DER2021-00333",
      scrollToId: "1234"
    }
    spyOn(trialsService, 'getMilestoneData').and.returnValue(of(caseMilestoneMockResponse3));
    component.getMilestoneData();
    expect(component.milestoneData).toEqual(caseMilestoneMockResponse3);
  });

  it('verify expandPane', () => {
    let id = 1;
    let link = 'dtiLink';
    component.expandPane(id);
  });

  it('verify collapsedPane', () => {
    let id = 1;
    let link = 'dtiLink';
    component.collapsePane(id);
  });

  it('verify expandCollapseAll', () => {
    spyOn(trialsService, 'getMilestoneData').and.returnValue(of(caseMilestoneMockResponse2));
    component.getMilestoneData();
    component.expandCollapseAll(true);
    component.expandCollapseAll(false);
  });

  it('verify getMilestoneDate', () => {
    let date = component.getMilestoneDate("2021-02-04");
    expect(date).toBeTruthy();
  });

  it("verifies getPageElement", () => {
    let theId = "none";
    let element = component.getPageElement(theId);
    expect(element).toBeFalsy();
  });

  it("verifies isInEditMode sets the correct section", () => {
    component.editModeNumber = 2;
    component.isInEditMode(2);
    expect(component.editModeNumber).toEqual(2);
  });

  it("verifies getDateString get correct date value", () => {
    let date = new Date();
    let dateString = component.getDateString(date.getUTCMilliseconds(), "MM/dd/yyyy");

    expect(dateString).toBeTruthy();
  });

  it("verifies getHeaderValue get correct date value", () => {

    let sectionHeader = component.getHeaderValue(aSection);

    expect(sectionHeader).toBeTruthy();
  });

  it('should call getOutcomeDropDown', () => {
    spyOn(commonService, 'getDecisionOutcomeTypes').and.returnValue(of(mockOutcomeList));
    component.getOutcomeDropDown();
    expect(component.outcomeListTemp).not.toEqual('');
  });

  it('should call getTerminatinOutcomeDropDown', () => {
    spyOn(commonService, 'getDecisionOutcomeTypes').and.returnValue(of(mockToutcomeList));
    component.getTerminatinOutcomeDropDown();
    expect(component.tOutcomeListTemp).not.toEqual('');
  });

  it('should call getAppealOutcomeDropdown', () => {
    spyOn(commonService, 'getDecisionOutcomeTypes').and.returnValue(of(mockToutcomeList));
    component.getAppealOutcomeDropdown();
    expect(component.appealsOutcomeListTemp).not.toEqual('');
  });

  it('should call getOutComeCode', () => {
    component.outcomeListTemp = mockOutcomeList;
    let outcomeCode = component.getOutComeCode("Institution Granted", "DI");
    expect(outcomeCode).toBeTruthy();
  });

  it('should call getOutComeCode with termination type', () => {
    component.tOutcomeListTemp = mockToutcomeList;
    let outcomeCode = component.getOutComeCode("Vacate FWD", "Termination");
    expect(outcomeCode).toBeTruthy();
  });

  it('should call getOutComeCode with CAFC type', () => {
    component.appealsOutcomeListTemp = mockToutcomeList;
    let outcomeCode = component.getOutComeCode("Vacate FWD", "CAFC");
    expect(outcomeCode).toBeTruthy();
  });

  it('should call getProceedingArtifactsInfo', () => {
    spyOn(trialsService, 'getDocumentsForUpdate').and.returnValue(of(mockAIADocsInfo));
    component.getProceedingArtifactsInfo();
  });

  it('should call getOutcomeLabel', () => {
    component.getOutcomeLabel("CAFC Mandate");
  });

  it('should call getPoprInfo', () => {
    spyOn(trialsService, 'getDocumentsForUpdate').and.returnValue(of(mockAIADocsInfo));
    component.getPoprInfo();
  });

  it('should call saveData', () => {
    let obj = [{ "mileStoneDate": 1622433600000, "mileStoneTypeName": "Notice of Accorded Filing Date", "audit": { "lastModifiedTimestamp": 1617120362475, "lastModifiedUserIdentifier": "3572", "createUserIdentifier": "3572", "createTimestamp": 1617112313731 }, "proceedingNumber": "IPR2019-00789", "dateCalculationReferenceIdentifier": 12 }]
    spyOn(trialsService, 'updateMilestoneData').and.returnValue(of("success"));
    component.saveData(obj);
    expect(component.inEditMode).toBeFalse();
  });

  it('should call saveData with error', () => {
    let obj = [{ "mileStoneDate": 1622433600000, "mileStoneTypeName": "Notice of Accorded Filing Date", "audit": { "lastModifiedTimestamp": 1617120362475, "lastModifiedUserIdentifier": "3572", "createUserIdentifier": "3572", "createTimestamp": 1617112313731 }, "proceedingNumber": "IPR2019-00789", "dateCalculationReferenceIdentifier": 12 }]
    spyOn(trialsService, 'updateMilestoneData').and.returnValue(throwError(""));
    component.saveData(obj);
  });

  it('should call createObjWithDescriptionText', () => {
    component.auditObject = {
      "lastModifiedTimestamp": 1616001688007,
      "lastModifiedUserIdentifier": "3572",
      "createUserIdentifier": "1",
      "createTimestamp": 1468190956173
    };
    let elementOrig = component.createObjWithDescriptionText('01/01/2021',
      'Institution Granted',
      'Institution decision outcome',
      'Decision to Institute',
      '', '7', 'DI');
    expect(elementOrig).toBeTruthy();
  });

  it('should call createObjWithoutDescriptionText', () => {
    component.auditObject = {
      "lastModifiedTimestamp": 1616001688007,
      "lastModifiedUserIdentifier": "3572",
      "createUserIdentifier": "1",
      "createTimestamp": 1468190956173
    };
    let elementOrig = component.createObjWithoutDescriptionText('01/01/2021',
      'Decision to Institute',
      '', '7');
    expect(elementOrig).toBeTruthy();
  });

  // it('should call saveInfo', () => {
  //   let userName = {}
  //   spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
  //     return userName[key];
  //   })
  //   spyOn(trialsService, 'updateMilestoneData').and.returnValue(of("success"));
  //   component.milestoneDataPost = MockMilestoneDetails;
  //   component.saveInfo(mockSection,rehearingDIList,rehearingDIList);
  //   expect(component.editModeNumber).toBe(-1);
  // });

  it('should call saveInfo with different input', () => {
    let userName = {}
    spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
      return userName[key];
    })
    spyOn(trialsService, 'updateMilestoneData').and.returnValue(of("success"));
    component.milestoneDataPost = MockMilestoneDetails;
    component.saveInfo(mockSection2, rehearingDIList, rehearingDIList);
    expect(component.editModeNumber).toBe(-1);
  });

  // it('should call saveInfo with termination section', () => {
  //   let userName = {}
  //   spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
  //     return userName[key];
  //   })
  //   spyOn(trialsService, 'updateMilestoneData').and.returnValue(of("success"));
  //   component.milestoneDataPost = MockMilestoneDetails;
  //   component.saveInfo(mockSection3,rehearingDIList,rehearingDIList);
  //   expect(component.editModeNumber).toBe(-1);
  // });

  it('should call saveDerivation', () => {
    let section = {
      "categoryDescription": "Derivation availability",
      "categoryType": "Derivation",
      "proceedingMileStoneDetails": [{
        "mileStoneDateString": "PUBLIC",
        "mileStoneDescription": "Derivation availability",
        "mileStoneTypeName": "Derivation availability",
        "referenceMileStoneDateString": "",
        "audit": {
          "lastModifiedTimestamp": 1617120362475,
          "lastModifiedUserIdentifier": "3572",
          "createUserIdentifier": "3572",
          "createTimestamp": 1617112313731
        }
      }]
    };
    spyOn(trialsService, 'updateDerivation').and.returnValue(of("success"));
    component.saveDerivation(section);
    expect(component.inEditMode).toBeFalse();
  })

  it('should call saveDerivation with error', () => {
    let section = {
      "categoryDescription": "Derivation availability",
      "categoryType": "Derivation",
      "proceedingMileStoneDetails": [{
        "mileStoneDateString": "PUBLIC",
        "mileStoneDescription": "Derivation availability",
        "mileStoneTypeName": "Derivation availability",
        "referenceMileStoneDateString": "",
        "audit": {
          "lastModifiedTimestamp": 1617120362475,
          "lastModifiedUserIdentifier": "3572",
          "createUserIdentifier": "3572",
          "createTimestamp": 1617112313731
        }
      }]
    };
    spyOn(trialsService, 'updateDerivation').and.returnValue(throwError(""));
    component.saveDerivation(section);
    expect(component.inEditMode).toBeFalse();
  })

  it('should call getRehearings with DI Petitioner', () => {
    spyOn(trialsService, 'getRehearingList').and.returnValue(of(mockRehearingInfo1));
    component.getRehearings('all', 'rehearing(s)');
  });

  it('should call getRehearings with DI PO', () => {
    spyOn(trialsService, 'getRehearingList').and.returnValue(of(mockRehearingInfo2));
    component.getRehearings('all', 'rehearing(s)');
  });

  it('should call getRehearings with TD Petitioner', () => {
    spyOn(trialsService, 'getRehearingList').and.returnValue(of(mockRehearingInfo3));
    component.getRehearings('all', 'rehearing(s)');
  });

  it('should call getRehearings with TD PO', () => {
    spyOn(trialsService, 'getRehearingList').and.returnValue(of(mockRehearingInfo4));
    component.getRehearings('all', 'rehearing(s)');
  });

  it('should call getCaseHeaderInfo', () => {
    const mockCaseHeaderInfo = [{
      patentNumberText: 7123699,
      proceedingNumber: "DER2021-00333",
      techCenterNum: 1234,
      ptabReadOnlyUser: true,
      mileStoneDates: null,
      parties: "Real",
      attorneys: [],
      artUnit: 1234,
      casePhase: "new",
      inventionTitle: "test",
      keyDates: null,
      joinderTypes: null,
      petitionerPatentNumber: null,
      petitionerinventionTitle: "test",
      petitionerTechCenterNum: 1234,
      petitionerArtUnit: 1234,
      derproceedingTypeDetails: {
        firstListedPetitionerApplicationNumber: "123456",
        firstListedPatentOwnerRespondentApplicationNumber: "123456",
        aiaReviewConfidentiality: "Public"
      }
    }];
    component.caseInfo = {
      serialNo: "7123699",
      proceedingNo: "DER2021-00333",
      scrollToId: "1234"
    }
    spyOn(trialsService, 'getCaseHeaderInfo').and.returnValue(of(mockCaseHeaderInfo));
    component.getCaseHeaderInfo(component.caseInfo);
    expect(component.caseHeaderInfo).toEqual(mockCaseHeaderInfo[0]);
  });

  it('should call getAppealsData', () => {
    let mockAppealsList = [
      {
        "audit": {
          "lastModifiedTimestamp": 1430170576800,
          "lastModifiedUserIdentifier": "5041",
          "createdUserName": "16348",
          "createTimestamp": 1430170576800
        },
        "proceedingAppealId": 164954,
        "proceedingNumber": "IPR2013-00290",
        "appealPartyTypeCode": "PATENTOWNER",
        "appealPartyTypeDescription": "Party group belongs to Patent Owner party",
        "appealNoticeDate": 1430170808000,
        "courtDecisionDate": 1621310400000,
        "appealStatusCode": "Completed",
        "appealStatusDescription": "Appeal Completed",
        "appealTypeName": "AIA REVIEW APPEAL",
        "appealTypeDescription": "AIA REVIEW APPEAL",
        "externalCourtName": "CAFC",
        "externalCourtDescription": "CAFC"
      },
      {
        "audit": {
          "lastModifiedTimestamp": 1431117943215,
          "lastModifiedUserIdentifier": "5041",
          "createdUserName": "15588",
          "createTimestamp": 1431117943215
        },
        "proceedingAppealId": 164956,
        "proceedingNumber": "IPR2013-00290",
        "appealPartyTypeCode": "PETITIONER",
        "appealPartyTypeDescription": "Party group belongs to Petitioner party",
        "appealNoticeDate": 1431117990000,
        "courtDecisionDate": 1620878400000,
        "appealStatusCode": "Awaiting Decision",
        "appealStatusDescription": "Appeal Awaiting Decision",
        "appealTypeName": "AIA REVIEW APPEAL",
        "appealTypeDescription": "AIA REVIEW APPEAL",
        "externalCourtName": "Supreme Court",
        "externalCourtDescription": "Supreme Court"
      }
    ]


    spyOn(trialsService, 'getAppealsList').and.returnValue(of(mockAppealsList));
    component.getAppealsData();
    expect(component.appealsList).not.toEqual('');
  });

  it('should call getAppealsStatuses', () => {
    let mockAppealStatusList = [
      {
        "Id": 1,
        "code": "Initiated",
        "Description": "Appeal Initiated"
      },
      {
        "Id": 2,
        "code": "Completed",
        "Description": "Appeal Completed"
      },
      {
        "Id": 3,
        "code": "Awaiting Decision",
        "Description": "Appeal Awaiting Decision"
      },
    ]

    spyOn(commonService, 'getAppealsStatuses').and.returnValue(of(mockAppealStatusList));
    component.getAppealsStatuses();
    expect(component.appealStatuses).not.toEqual('');
  });

  it('should call saveAppealsInfo', () => {
    let mockAppealsList = [
      {
        "audit": {
          "lastModifiedTimestamp": 1430170576800,
          "lastModifiedUserIdentifier": "5041",
          "createdUserName": "16348",
          "createTimestamp": 1430170576800
        },
        "proceedingAppealId": 164954,
        "proceedingNumber": "IPR2013-00290",
        "appealPartyTypeCode": "PATENTOWNER",
        "appealPartyTypeDescription": "Party group belongs to Patent Owner party",
        "appealNoticeDate": 1430170808000,
        "courtDecisionDate": 1621310400000,
        "courtDecisionDateString": "01/01/2020",
        "courtMandateDate": 1621310400000,
        "courtMandateDateString": "01/01/2020",
        "appealStatusCode": "Initiated",
        "appealStatusDescription": "Appeal Initiated",
        "appealTypeName": "AIA REVIEW APPEAL",
        "appealTypeDescription": "AIA REVIEW APPEAL",
        "externalCourtName": "Supreme Court",
        "externalCourtDescription": "Supreme Court"
      }
    ]
    let mockAppealsPostList = [
      {
        "audit": {
          "lastModifiedTimestamp": 1621310400000,
          "lastModifiedUserIdentifier": "5041",
          "createdUserName": "16348",
          "createTimestamp": 1621310400000
        },
        "proceedingAppealId": 164954,
        "proceedingNumber": "IPR2013-00290",
        "appealPartyTypeCode": "PATENTOWNER",
        "appealPartyTypeDescription": "Party group belongs to Patent Owner party",
        "appealNoticeDate": 1621210400000,
        "courtDecisionDate": 1621210400000,
        "courtDecisionDateString": "01/01/2021",
        "courtMandateDate": 1621310400000,
        "courtMandateDateString": "01/01/2021",
        "appealStatusCode": "Completed",
        "appealStatusDescription": "Appeal Completed",
        "appealTypeName": "AIA REVIEW APPEAL",
        "appealTypeDescription": "AIA REVIEW APPEAL",
        "externalCourtName": "CAFC",
        "externalCourtDescription": "CAFC"
      }
    ]
    component.appealsListPost = mockAppealsPostList;
    spyOn(trialsService, 'updateAppeals').and.returnValue(of("success"));
    component.saveAppealsInfo(mockAppealsList, mockAppealsSection);
    expect(component.inEditMode).toBeFalse();
  });

  it('should call saveAppealsInfo with error', () => {
    let mockAppealsList = [
      {
        "audit": {
          "lastModifiedTimestamp": 1430170576800,
          "lastModifiedUserIdentifier": "5041",
          "createdUserName": "16348",
          "createTimestamp": 1430170576800
        },
        "proceedingAppealId": 164954,
        "proceedingNumber": "IPR2013-00290",
        "appealPartyTypeCode": "PATENTOWNER",
        "appealPartyTypeDescription": "Party group belongs to Patent Owner party",
        "appealNoticeDate": 1430170808000,
        "courtDecisionDate": 1621310400000,
        "courtDecisionDateString": "01/01/2020",
        "courtMandateDate": 1621310400000,
        "courtMandateDateString": "01/01/2020",
        "appealStatusCode": "Initiated",
        "appealStatusDescription": "Appeal Initiated",
        "appealTypeName": "AIA REVIEW APPEAL",
        "appealTypeDescription": "AIA REVIEW APPEAL",
        "externalCourtName": "Supreme Court",
        "externalCourtDescription": "Supreme Court"
      }
    ]
    let mockAppealsPostList = [
      {
        "audit": {
          "lastModifiedTimestamp": 1621310400000,
          "lastModifiedUserIdentifier": "5041",
          "createdUserName": "16348",
          "createTimestamp": 1621310400000
        },
        "proceedingAppealId": 164954,
        "proceedingNumber": "IPR2013-00290",
        "appealPartyTypeCode": "PATENTOWNER",
        "appealPartyTypeDescription": "Party group belongs to Patent Owner party",
        "appealNoticeDate": 1621210400000,
        "courtDecisionDate": 1621210400000,
        "courtDecisionDateString": "01/01/2021",
        "courtMandateDate": 1621310400000,
        "courtMandateDateString": "01/01/2021",
        "appealStatusCode": "Completed",
        "appealStatusDescription": "Appeal Completed",
        "appealTypeName": "AIA REVIEW APPEAL",
        "appealTypeDescription": "AIA REVIEW APPEAL",
        "externalCourtName": "CAFC",
        "externalCourtDescription": "CAFC"
      }
    ]
    component.appealsListPost = mockAppealsPostList;
    spyOn(trialsService, 'updateAppeals').and.returnValue(throwError(""));
    component.saveAppealsInfo(mockAppealsList, mockAppealsSection);
  });

  it('should call saveRehearingInfo', () => {
    let userName = {}
    spyOn(window.sessionStorage, 'getItem').and.callFake((key) => {
      return userName[key];
    })
    component.rehearingDIPostList = rehearingDIListPost;
    component.rehearingTerminationPostList = rehearingDIListPost;
    component.rehearingRes = [
      {
        audit: null,
        decisionDate: 1623211200000,
        filedDate: 1618977600000,
        lifeCycle: null,
        notificationRequiredIndicator: null,
        patentNumber: null,
        petitionIdentifier: null,
        proceedingNumber: "IPR2020-01619",
        proceedingNumberText: null,
        rehearingId: 315814,
        rehearingStatus: "Granted",
        rehearingStatusDisplayName: "Granted",
        rehearingStatusId: 2,
        rehearingTypeId: 1,
        rehearingTypeName: "Institution Decision",
        requestorTypeName: "Petitioner",
        "rehearingDocuments": [
          {
            "documentNumber": 12,
            "name": "ccc",
            "category": "PAPER",
            "fileName": "Expunged_blank.pdf",
            "filingParty": "PETITIONER",
            "availability": "Public",
            "documentTypeIdentifier": 34,
            "documentTypeCode": "REHEARING DECN",
            "documentTypeDescription": "Rehearing Decision - in re Institution Decision Granted",
            "pageCount": 1,
            "contentManagementId": "workspace://SpacesStore/9bc7bace-da38-44aa-be70-6466d7e63eeb;1.0",
            "artifactIdentifer": 170111086,
            "artifactSubmissionIdentifier": 85453306,
            "filingDate": 1622727590,
            "filingDateString": "06/03/2021",
            "fileSize": 0,
            "documentStatus": "PENDING",
            "directionCode": "INCOMING",
            "warningMessageList": [],
            "availablitySummary": {
              "code": "PUBLIC",
              "descriptionText": "Available for everyone.",
              "displayNameText": "Public"
            },
            "roleSummary": {
              "code": "PETITIONER",
              "descriptionText": "Indicates artifact was submitted on behalf of Petitioner.",
              "displayNameText": "Petitioner"
            },
            "artifactSummary": {
              "code": "PAPER",
              "descriptionText": "Paper"
            }
          }
        ]
      }
    ]
    spyOn(trialsService, 'updateMotionRehearing').and.returnValue(of("success"));
    component.saveRehearingInfo(rehearingDIList, rehearingDIList, 'DI');
    expect(component.inEditMode).toBeFalse();
  });


});
