import { Component, OnInit, Input } from '@angular/core';
import MilestoneDatesModel from 'src/app/models/appeals/MilestoneDates.model';

@Component({
  selector: 'app-application-dates',
  templateUrl: './application-dates.component.html',
  styleUrls: ['./application-dates.component.less']
})
export class ApplicationDatesComponent implements OnInit {

  constructor() { }

  @Input() applicationDates: MilestoneDatesModel;

  ngOnInit(): void {
  }

}
