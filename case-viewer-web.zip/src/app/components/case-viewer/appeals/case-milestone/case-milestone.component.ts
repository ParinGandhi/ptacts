import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { TrialsService } from 'src/app/services/trials.service';
import { CommonService } from 'src/app/services/common.service';
import { ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import MilestoneDatesModel from 'src/app/models/appeals/MilestoneDates.model';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { typePropertyIsNotAllowedMsg } from '@ngrx/store/src/models';
import CaseHeaderModel from 'src/app/models/cases/CaseHeader.model';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ConfirmDialogComponent } from 'src/app/shared/confirm-dialog/confirm-dialog.component';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import InfoModalModel from 'src/app/models/common/InfoModal.model';
import { element } from 'protractor';
import * as CaseViewerActions from 'src/app/store/case-viewer/case-viewer.actions';

@Component({
  selector: 'app-case-milestone',
  templateUrl: './case-milestone.component.html',
  styleUrls: ['./case-milestone.component.less']
})
export class CaseMilestoneComponent implements OnInit {

  @Input() milestonePoprInput;
  caseInfo: CaseInfoModel;
  @Output() updateUnsavedEvent = new EventEmitter<any>();
  hasChanges: boolean = false;
  unsavedChanges: boolean;
  caseHeaderInfo: CaseHeaderModel;
  derivationWarningModelRef: BsModalRef;

  constructor(
    private readonly activatedRoute: ActivatedRoute,
    private store: Store<CaseViewerState>,
    private toastr: ToastrService,
    private trialsService: TrialsService,
    private commonService: CommonService,
    private commonUtils: CommonUtilitiesService) { }


  ngOnInit(): void {
    console.log(this.milestonePoprInput);
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };

    this.store.pipe(select(CaseViewerSelectors.userInfoData)).subscribe(data => {
      this.loggedInUser = data.caseDetailsData[0];
      if (!this.loggedInUser) {
        this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
      }
      this.canEdit = this.loggedInUser.roleDescription === PtabTrialConstants.ROLES.ADMIN || this.loggedInUser.roleDescription === PtabTrialConstants.ROLES.SPL;

    });

    let ele: any = document.getElementsByClassName('fa-times-circle')[0];
    ele?.click();
    this.getCaseHeaderInfo(this.caseInfo);
    this.getMilestoneData();
    this.getOutcomeDropDown();
    this.getTerminatinOutcomeDropDown();
    this.getAppealOutcomeDropdown();
    this.getDerivationAvailabilityDropDown();
    // this.getProceedingArtifactsInfo();
    // this.getPoprInfo();
    this.getRehearings('all', 'rehearing(s)');
    this.getAppealsData();
    this.getAppealsStatuses();
    this.getMotionStatusTypes();
    this.getDecisionHistory();
    // setInterval(()=>{
    //   this.refresh();
    // },300000)
  }

  refresh(){
    this.getMilestoneData();
    this.getAppealsData();
    this.lastRefresh = new Date();
  }

  ngAfterContentChecked() {
    if (document.getElementsByClassName('fas fa-save')[0]) {
      this.unsavedChanges = false;
      this.updateUnsavedEvent.emit(!this.unsavedChanges);
    }
  }


  auditObject: any;
  editModePFAR: boolean = false;
  pfarSection = null;
  outcomeList: Array<any> = [];
  derivationAvailability: Array<any> = [];
  outcomeListTemp: Array<any> = [];
  tOutcomeListTemp: Array<any> = [];
  loggedInUser = null;
  canEdit: boolean = false;
  institutionOutcomeList: Array<any> = [];
  terminationOutcomeList: Array<any> = [];
  rehearingOutcomeList: Array<any> = [];
  derivationAvailabilityList: Array<any> = [];
  milestoneData = null;
  milestoneDataPost = null;
  inEditMode: boolean = false;
  parameter1: any;
  editModeNumber: number = -1;
  tempSelect: any;
  outComeCode = '';
  descriptionText = '';
  label = '';
  poprWaivedResponse = '';
  poprFileResponse = '';
  rehearingDIList = {
    "proceedingMileStoneDetails": [
      {
        "mileStoneDate": "",
        "mileStoneDateString": "",
        "mileStoneDescription": "PO rehearing request date",
        "audit": {}
      },
      {
        "mileStoneDate": "",
        "mileStoneDateString": "",
        "mileStoneDescription": "Petitioner's rehearing request date",
        "audit": {}
      },
      {
        "mileStoneDate": "",
        "mileStoneDateString": "",
        "mileStoneDescription": "Rehearing decision date",
        "audit": {}
      },
      {
        "mileStoneDate": "",
        "mileStoneDateString": "",
        "mileStoneDescription": "Rehearing request due date",
        "audit": {}
      },
      {
        "descriptionText": " "
      }
    ]
  }
  rehearingTerminationList = {
    "proceedingMileStoneDetails": [
      {
        "mileStoneDate": "",
        "mileStoneDateString": "",
        "mileStoneDescription": "PO rehearing request date",
        "audit": {}
      },
      {
        "mileStoneDate": "",
        "mileStoneDateString": "",
        "mileStoneDescription": "Petitioner's rehearing request date",
        "audit": {}
      },
      {
        "mileStoneDate": "",
        "mileStoneDateString": "",
        "mileStoneDescription": "Rehearing decision date",
        "audit": {}
      },
      {
        "mileStoneDate": "",
        "mileStoneDateString": "",
        "mileStoneDescription": "Rehearing request due date",
        "audit": {}
      },
      {
        "descriptionText": " "
      }
    ]
  }
  appealsList: Array<any> = [];
  appealStatuses: Array<any> = [];
  rehearingRes: any;
  appealsListPost: Array<any> = [];
  rehearingDIPostList: any;
  rehearingTerminationPostList: any;
  motionStatusTypes:Array<any> = [];
  appealsOutcomeList:any;
  appealsOutcomeListTemp:any;
  decisionHistory:any;
  lastRefresh = new Date();

  getMilestoneData() {
    this.trialsService.getMilestoneData(`/proceeding-milestone-details/category?caseNumber=${this.caseInfo.proceedingNo}`).subscribe((milestonesSuccess) => {
      this.milestoneData = milestonesSuccess;
      this.milestoneData.forEach(mileStoneElement => {
        mileStoneElement.proceedingMileStoneDetails.forEach(mileStoneRow => {
          if (mileStoneRow.audit && !this.auditObject) {
            this.auditObject = mileStoneRow.audit;
          }
          if (!mileStoneRow.audit.createTimestamp) {
            mileStoneRow.audit.lastModifiedUserIdentifier = this.loggedInUser.loginId;
            mileStoneRow.audit.createUserIdentifier = this.loggedInUser.loginId;
            let currentDate: any = new Date();
            mileStoneRow.audit.createTimestamp = this.getMilestoneDate(this.getDateString(currentDate / 1000, 'yyyy-MM-dd'));
            mileStoneRow.audit.lastModifiedTimestamp = this.getMilestoneDate(this.getDateString(currentDate / 1000, 'yyyy-MM-dd'));
            this.auditObject = mileStoneRow.audit;
          }
          mileStoneRow.mileStoneDateString = this.getDateString(mileStoneRow.mileStoneDate / 1000, 'yyyy-MM-dd');
          this.parameter1 = mileStoneRow.mileStoneDateString;
          mileStoneRow.referenceMileStoneDateString = this.getDateString(mileStoneRow.referenceMileStoneDate / 1000, 'yyyy-MM-dd');
          if (mileStoneRow.decisionOutcomeDetails) {
            mileStoneRow.decisionOutcomeDetails.label = this.getOutcomeLabel(mileStoneRow.mileStoneDescription);
          }
          if ((mileStoneRow.mileStoneTypeName == "Derivation availability")) {
            let confidentiality: any;
            confidentiality = this.caseHeaderInfo?.derproceedingTypeDetails;
            if(confidentiality?.poConfidentialityIn == null){
              mileStoneRow.mileStoneDateString = "Not Public";
              this.commonUtils.confidentialityInfo = "Not Public";
            }
            else{
              mileStoneRow.mileStoneDateString = confidentiality?.poConfidentialityIn;
              this.commonUtils.confidentialityInfo = confidentiality?.poConfidentialityIn;
            }
          }
          if (mileStoneRow.mileStoneTypeName == "Rehearing request due date") {
            this.rehearingDIList.proceedingMileStoneDetails.forEach(DIList => {
              if (DIList.mileStoneDescription == "Rehearing request due date") {
                DIList.mileStoneDate = mileStoneRow.mileStoneDate;
                DIList.mileStoneDateString = this.getDateString(mileStoneRow.mileStoneDate / 1000, 'yyyy-MM-dd');
              }
            })
            this.rehearingTerminationList.proceedingMileStoneDetails.forEach(TerminationList => {
              if (TerminationList.mileStoneDescription == "Rehearing request due date") {
                TerminationList.mileStoneDate = mileStoneRow.mileStoneDate;
                TerminationList.mileStoneDateString = this.getDateString(mileStoneRow.mileStoneDate / 1000, 'yyyy-MM-dd');
              }
            })
          }
        });

      });
      this.milestoneDataPost = JSON.parse(JSON.stringify(this.milestoneData));
    });
  }

  isInEditMode(i) {
    return i === this.editModeNumber;
  }

  getHeaderValue(section) {
    let returnHeaderValue = "";
    section.proceedingMileStoneDetails.forEach(headerSectionElement => {
      if (headerSectionElement.referenceMileStoneDescription && headerSectionElement.referenceMileStoneDate) {
        returnHeaderValue = headerSectionElement.referenceMileStoneDescription + ": " + this.getDateString(headerSectionElement.referenceMileStoneDate / 1000, 'MM/dd/yyyy');
      }
      if (headerSectionElement.mileStoneDescription && headerSectionElement.mileStoneDescription.indexOf("Notice of") >= 0 && headerSectionElement.mileStoneDate) {
        returnHeaderValue = headerSectionElement.mileStoneDescription + ": " + this.getDateString(headerSectionElement.mileStoneDate / 1000, 'MM/dd/yyyy');
      }

      if (section.categoryDescription && section.categoryDescription.indexOf("filing and review") < 0 && headerSectionElement.mileStoneDate) {
        returnHeaderValue = headerSectionElement.mileStoneDescription + ": " + this.getDateString(headerSectionElement.mileStoneDate / 1000, 'MM/dd/yyyy');
      }
    });
    return returnHeaderValue;
  }

  getDateString(milleseconds, pipeValue) {
    if (!milleseconds) {
      return "";
    }
    const datepipe: DatePipe = new DatePipe('en-US');
    let aDate = new Date(0); // The 0 there is the key, which sets the date to the epoch
    aDate.setUTCSeconds(milleseconds);
    return datepipe.transform(aDate, pipeValue);
  }

  getPageElement(theId) {
    let pgElement = document.getElementById(theId);
    return pgElement;
  }

  expandPane(sectionNumber: number) {
    let theId = "caseMilestonesAccordian" + sectionNumber;
    let theLink = "caseMilestonesAccordianLink" + sectionNumber;
    let currentLink = this.getPageElement(theLink);
    if (currentLink) {
      currentLink.classList.remove('collapsed');
    }
    let secElement = this.getPageElement(theId);
    if (secElement) {
      secElement.classList.add('in');
    }
  }

  collapsePane(sectionNumber: number) {
    let theId = "caseMilestonesAccordian" + sectionNumber;
    let theLink = "caseMilestonesAccordianLink" + sectionNumber;
    let currentLink = this.getPageElement(theLink);
    if (currentLink) {
      currentLink.classList.add('collapsed');
    }
    let collapseElement = this.getPageElement(theId);
    if (collapseElement) {
      collapseElement.classList.remove('in');
    }

  }

  expandCollapseAll(status) {
    let index = 0;
    this.milestoneData.forEach(collapseAllElement => {
      if (status) {
        this.expandPane(index);
      } else {
        this.collapsePane(index);
      }
      index++;
    });
  }

  getOutcomeLabel(description) {
    let label = description.replace("date", "outcome");
    if (description.indexOf("CAFC") >= 0) {
      label = "Fed circuit decision outcome"
    }
    return label;
  }

  getMilestoneDate(dateString: string) {
    let dateValue = Date.parse(dateString + "T00:00");
    return dateValue;
  }

  getOutComeCode(descriptionText: string, type: string) {
    let outcomeCode = '';
    if (type == "DI") {
      this.outcomeListTemp.forEach(outcomeGroupTypes => {
        outcomeGroupTypes.decisionOutcomeGroupTypes.forEach(types => {
          types.decisionOutComeTypes.forEach(elementCode => {
            if (elementCode.descriptionText == descriptionText) {
              outcomeCode = elementCode.code;
            }
          });
        });
      });
    }
    else if (type == "Termination") {
      this.tOutcomeListTemp.forEach(outcomeGroupTypes => {
        outcomeGroupTypes.decisionOutcomeGroupTypes.forEach(types => {
          types.decisionOutComeTypes.forEach(elementCode => {
            if (elementCode.descriptionText == descriptionText) {
              outcomeCode = elementCode.code;
            }
          });
        });
      });
    }
    else if (type == "CAFC") {
      this.appealsOutcomeListTemp.forEach(outcomeGroupTypes => {
        outcomeGroupTypes.decisionOutcomeGroupTypes.forEach(types => {
          types.decisionOutComeTypes.forEach(elementCode => {
            if (elementCode.descriptionText == descriptionText) {
              outcomeCode = elementCode.code;
            }
          });
        });
      });
    }
    return outcomeCode;
  }

  createObjWithDescriptionText(dateString: string, descriptionText: string, label: string, typeName: string, audit: any, identifier: string, type: string) {
    let elementOrig = {
      mileStoneDate: this.getMilestoneDate(dateString),
      decisionOutcomeDetails: {
        descriptionText: descriptionText,
        label: label,
        outcomeType: this.getOutComeCode(descriptionText, type)
      },
      mileStoneTypeName: typeName,
      audit: audit,
      proceedingNumber: this.caseInfo.proceedingNo,
      dateCalculationReferenceIdentifier: identifier
    };
    if (!audit.createTimestamp) {
      elementOrig.audit = this.auditObject;
    }
    return elementOrig;
  }

  createObjWithoutDescriptionText(dateString: string, typeName: string, audit: any, identifier: string) {
    let elementOrig = {
      mileStoneDate: this.getMilestoneDate(dateString),
      mileStoneTypeName: typeName,
      audit: audit,
      proceedingNumber: this.caseInfo.proceedingNo,
      dateCalculationReferenceIdentifier: identifier
    };
    if (!audit.createTimestamp) {
      elementOrig.audit = this.auditObject;
    }
    return elementOrig;
  }

  saveInfo(section, rehearingDIList, rehearingTerminationList) {
    if (section.categoryType == 'Derivation') {
      this.openWarningModal(section);
    }
    else {
      if (section.categoryType == 'DI' || section.categoryType == 'Termination') {
        this.saveRehearingInfo(rehearingDIList, rehearingTerminationList, section.categoryType);
      }
      let saveObject = [];
      let counter = 0;
      section.proceedingMileStoneDetails.forEach(element => {
        this.milestoneDataPost.forEach(newElement => {
          newElement.proceedingMileStoneDetails.forEach(milestoneDataelement => {
            if (element.mileStoneDescription && milestoneDataelement.mileStoneDescription == element.mileStoneDescription) {
              element.proceedingNumber = this.caseInfo.proceedingNo;
              element.mileStoneDate = this.getMilestoneDate(element.mileStoneDateString);
              if (element.referenceMileStoneDateString && milestoneDataelement.referenceMileStoneDateString != element.referenceMileStoneDateString) {
                if (element.decisionOutcomeDetails) {
                  if (milestoneDataelement.decisionOutcomeDetails.descriptionText != element.decisionOutcomeDetails.descriptionText) {
                    let org = this.createObjWithDescriptionText(element.referenceMileStoneDateString,
                      element.decisionOutcomeDetails.descriptionText,
                      element.decisionOutcomeDetails.label,
                      element.referenceMileStoneTypeName,
                      element.audit,
                      element.dateCalculationReferenceIdentifier,
                      section.categoryType)
                    saveObject.push(org);
                  }
                  else {
                    let org = this.createObjWithDescriptionText(element.referenceMileStoneDateString,
                      milestoneDataelement.decisionOutcomeDetails.descriptionText,
                      element.decisionOutcomeDetails.label,
                      element.referenceMileStoneTypeName,
                      element.audit,
                      element.dateCalculationReferenceIdentifier,
                      section.categoryType);
                    saveObject.push(org);
                  }
                }
                else {
                  let org = this.createObjWithoutDescriptionText(element.referenceMileStoneDateString,
                    element.referenceMileStoneTypeName,
                    element.audit,
                    element.dateCalculationReferenceIdentifier)
                  saveObject.push(org);
                }
              }

              if (element.mileStoneDateString && milestoneDataelement.mileStoneDateString != element.mileStoneDateString) {
                if (element.decisionOutcomeDetails && counter == 0) {
                  if (element.decisionOutcomeDetails.descriptionText && milestoneDataelement.decisionOutcomeDetails.descriptionText != element.decisionOutcomeDetails.descriptionText) {
                    let org = this.createObjWithDescriptionText(element.mileStoneDateString,
                      element.decisionOutcomeDetails.descriptionText,
                      element.decisionOutcomeDetails.label,
                      element.mileStoneTypeName,
                      element.audit,
                      element.dateCalculationReferenceIdentifier, section.categoryType);
                    saveObject.push(org);
                    counter++;
                  }
                  else {
                    let org = this.createObjWithDescriptionText(element.mileStoneDateString,
                      milestoneDataelement.decisionOutcomeDetails.descriptionText,
                      element.decisionOutcomeDetails.label,
                      element.mileStoneTypeName,
                      element.audit,
                      element.dateCalculationReferenceIdentifier, section.categoryType);
                    saveObject.push(org);
                    counter++;
                  }
                }

                else {
                  let org = this.createObjWithoutDescriptionText(element.mileStoneDateString,
                    element.mileStoneTypeName,
                    element.audit,
                    element.dateCalculationReferenceIdentifier)
                  saveObject.push(org);
                }
              }

              if (element.decisionOutcomeDetails && counter == 0 && milestoneDataelement.decisionOutcomeDetails) {
                if (element.decisionOutcomeDetails.descriptionText && milestoneDataelement.decisionOutcomeDetails.descriptionText != element.decisionOutcomeDetails.descriptionText) {
                  let org = this.createObjWithDescriptionText(element.mileStoneDateString,
                    element.decisionOutcomeDetails.descriptionText,
                    element.decisionOutcomeDetails.label,
                    element.mileStoneTypeName,
                    element.audit,
                    element.dateCalculationReferenceIdentifier, section.categoryType);
                  saveObject.push(org);
                }
              }
            }
          });
        });
      });
      this.saveData(saveObject);
    }
  }

  getOutcomeDropDown() {
    this.outcomeList = [];
    this.commonService.getDecisionOutcomeTypes('/references?typeCode=decisionOutcomeTypes&categoryType=Institution%20Decision').subscribe((milestoneDataOutcome) => {
      this.outcomeListTemp = milestoneDataOutcome;
      milestoneDataOutcome.forEach(outcomeGroupTypes => {
        outcomeGroupTypes.decisionOutcomeGroupTypes.forEach(types => {
          types.decisionOutComeTypes.forEach(drpElement => {
            this.outcomeList.push(drpElement.descriptionText);
          });
        });
      });
    });
  }

  getTerminatinOutcomeDropDown() {
    this.terminationOutcomeList = [];
    this.commonService.getDecisionOutcomeTypes('/references?typeCode=decisionOutcomeTypes&categoryType=Termination%20Decision').subscribe((milestoneDataOutcome) => {
      this.tOutcomeListTemp = milestoneDataOutcome;
      milestoneDataOutcome.forEach(outcomeGroupTypes => {
        outcomeGroupTypes.decisionOutcomeGroupTypes.forEach(types => {
          types.decisionOutComeTypes.forEach(terDrpElement => {
            this.terminationOutcomeList.push(terDrpElement.descriptionText);
          });
        });
      });
    });
  }

  getAppealOutcomeDropdown(){
    this.appealsOutcomeList = [];
    this.commonService.getDecisionOutcomeTypes('/references?typeCode=decisionOutcomeTypes&categoryType=Fed%20Circuit%20Decision').subscribe((milestoneDataOutcome) => {
      this.appealsOutcomeListTemp = milestoneDataOutcome;
      milestoneDataOutcome.forEach(outcomeGroupTypes => {
        outcomeGroupTypes.decisionOutcomeGroupTypes.forEach(types => {
          types.decisionOutComeTypes.forEach(terDrpElement => {
            this.appealsOutcomeList.push(terDrpElement.descriptionText);
          });
        });
      });
    });
  }

  getDerivationAvailabilityDropDown() {
    this.derivationAvailabilityList = [];
    this.derivationAvailabilityList.push("Public");
    this.derivationAvailabilityList.push("Not Public");
    this.rehearingOutcomeList = [];
    this.rehearingOutcomeList.push("Pending Review");
    this.rehearingOutcomeList.push("Denied");
    this.rehearingOutcomeList.push("Granted");
    this.rehearingOutcomeList.push("Granted In Part");
    this.rehearingOutcomeList.push("No Decision");
  }

  getCaseHeaderInfo(caseInfo) {
    this.trialsService.getCaseHeaderInfo(caseInfo.proceedingNo).subscribe((caseHeaderInfoResponse) => {
      this.caseHeaderInfo = caseHeaderInfoResponse[0];
    });
  }

  // getProceedingArtifactsInfo() {
  //   let aiaData;
  //   this.trialsService.getDocumentsForUpdate(`${PtabTrialConstants.TRIALS_URLS.GET_DOCUMENTS}${this.caseInfo.proceedingNo}`).subscribe((documentSuccess) => {
  //     aiaData = documentSuccess;
  //     aiaData.forEach(artiElement => {
  //       if (artiElement?.documentTypeIdentifier == '18' || artiElement?.documentTypeIdentifier == '203') {
  //         this.poprWaivedResponse = 'No';
  //       }
  //       else if (artiElement?.documentTypeIdentifier == '38' || artiElement?.documentTypeIdentifier == '204') {
  //         this.poprWaivedResponse = 'Yes';
  //       }
  //     });
  //   });
  // }

  // getPoprInfo() {
  //   let aiaData;
  //   this.trialsService.getDocumentsForUpdate(`${PtabTrialConstants.TRIALS_URLS.GET_DOCUMENTS}${this.caseInfo.proceedingNo}`).subscribe((documentSuccess) => {
  //     aiaData = documentSuccess;
  //     aiaData.forEach((poprElement, index, arr) => {
  //       if (poprElement?.documentTypeIdentifier == '38' || poprElement?.documentTypeIdentifier == '204' || poprElement?.documentTypeIdentifier == '18' || poprElement?.documentTypeIdentifier == '203') {
  //         this.poprFileResponse = 'Yes';
  //         arr.length = index + 1;
  //       }
  //       else {
  //         this.poprFileResponse = 'No';
  //       }
  //     });
  //   });
  // }

  saveData(objectToSave) {
    if (objectToSave.length && objectToSave.length != 0) {
      this.trialsService.updateMilestoneData(`/proceeding-milestone-details`, objectToSave).subscribe((saveMilestoneDataResponse) => {
        this.editModeNumber = -1;
        this.inEditMode = false;
        this.toastr.success(`Your Petition Milestones have been updated`, "", {
          closeButton: true
        });
        this.getMilestoneData();
        //this.milestoneDataPost = this.milestoneData;
        this.store.dispatch(CaseViewerActions.GetCasePhaseAction({ url: this.caseInfo.proceedingNo }));
        this.getDecisionHistory();
      }, (saveMilestoneDataResponse) => {
        this.toastr.error(saveMilestoneDataResponse.error.message, "", {
          closeButton: true
        });
      });
    }
  }

  saveDerivation(section) {
    let conf = "Y";
    section.proceedingMileStoneDetails.forEach(derElement => {
      if (derElement.mileStoneDateString == "Public") {
        conf = "N";
      }
    });
    let currentDate: any = new Date();
    let objToSave = {
      proceedingNumber: this.caseInfo.proceedingNo,
      confidentialityIn: conf,
      audit: {
        lastModifiedUserIdentifier: this.loggedInUser.loginId,
        createUserIdentifier: this.loggedInUser.loginId,
        createTimestamp: this.getMilestoneDate(this.getDateString(currentDate / 1000, 'yyyy-MM-dd')),
        lastModifiedTimestamp: this.getMilestoneDate(this.getDateString(currentDate / 1000, 'yyyy-MM-dd'))
      }
    };

    this.trialsService.updateDerivation('/prcdng-invention-disclosure', objToSave).subscribe((derivationDataResponse) => {
      this.editModeNumber = -1;
      this.inEditMode = false;
      this.toastr.success(`Your Petition Milestones have been updated`, "", {
        closeButton: true
      });
      this.getCaseHeaderInfo(this.caseInfo);
      setTimeout(() => {
        this.getMilestoneData();
      }, 1000);

      this.milestoneDataPost = this.milestoneData;
    }, (saveMilestoneDataResponse) => {
      this.toastr.error(`Unable to update milestone date(s).`, "", {
        closeButton: true
      });
    });
  }

  openWarningModal(section) {
    let modal: InfoModalModel = {
      infoText: ["This change will impact the public view and search of this AIA Review unless a different option is selected."],
      title: "Derivation Availability",
      showLeftBtn: true,
      leftBtnClass: 'btn-default',
      leftBtnLabel: 'Back',
      showRightBtn: true,
      rightBtnClass: 'btn-primary',
      rightBtnLabel: 'Yes, proceed',
      isConfirm: false,
      modalHeight: 100
    }
    let response = this.commonUtils.openConfirmModal(modal);
    response.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        this.saveDerivation(section);
      }
    })
  }

  getRehearings(statusVal, type) {
    let url = '/rehearing-info?proceedingNumber=' + this.caseInfo.proceedingNo + '&status=' + statusVal;
    this.trialsService.getRehearingList(url).subscribe((rehearing) => {
      this.rehearingRes = rehearing;
      rehearing.forEach(rehearingval => {
        if (rehearingval.rehearingTypeName == "Institution Decision" && rehearingval.requestorTypeName == "Patent Owner") {
          this.rehearingDIList.proceedingMileStoneDetails.forEach(DIList => {
            if (DIList.mileStoneDescription == "PO rehearing request date") {
              DIList.mileStoneDate = rehearingval.filedDate;
              DIList.mileStoneDateString = this.getDateString(rehearingval.filedDate / 1000, 'yyyy-MM-dd');
            }
            if (DIList.mileStoneDescription == "Rehearing decision date") {
              DIList.mileStoneDate = rehearingval.decisionDate;
              DIList.mileStoneDateString = this.getDateString(rehearingval.decisionDate / 1000, 'yyyy-MM-dd');
            }
            if (DIList.descriptionText) {
              DIList.descriptionText = rehearingval.rehearingStatusDisplayName;
            }
          })
        }
        if (rehearingval.rehearingTypeName == "Institution Decision" && rehearingval.requestorTypeName == "Petitioner") {
          this.rehearingDIList.proceedingMileStoneDetails.forEach(DIList => {
            if (DIList.mileStoneDescription == "Petitioner's rehearing request date") {
              DIList.mileStoneDate = rehearingval.filedDate;
              DIList.mileStoneDateString = this.getDateString(rehearingval.filedDate / 1000, 'yyyy-MM-dd');
            }
            if (DIList.mileStoneDescription == "Rehearing decision date") {
              DIList.mileStoneDate = rehearingval.decisionDate;
              DIList.mileStoneDateString = this.getDateString(rehearingval.decisionDate / 1000, 'yyyy-MM-dd');
            }
            if (DIList.descriptionText) {
              DIList.descriptionText = rehearingval.rehearingStatusDisplayName;
            }
          })
        }
        if (rehearingval.rehearingTypeName == "Final Written Decision" && rehearingval.requestorTypeName == "Patent Owner") {
          this.rehearingTerminationList.proceedingMileStoneDetails.forEach(TerminationList => {
            if (TerminationList.mileStoneDescription == "PO rehearing request date") {
              TerminationList.mileStoneDate = rehearingval.filedDate;
              TerminationList.mileStoneDateString = this.getDateString(rehearingval.filedDate / 1000, 'yyyy-MM-dd');
            }
            if (TerminationList.mileStoneDescription == "Rehearing decision date") {
              TerminationList.mileStoneDate = rehearingval.decisionDate;
              TerminationList.mileStoneDateString = this.getDateString(rehearingval.decisionDate / 1000, 'yyyy-MM-dd');
            }
            if (TerminationList.descriptionText) {
              TerminationList.descriptionText = rehearingval.rehearingStatusDisplayName;
            }
          })
        }
        if (rehearingval.rehearingTypeName == "Final Written Decision" && rehearingval.requestorTypeName == "Petitioner") {
          this.rehearingTerminationList.proceedingMileStoneDetails.forEach(TerminationList => {
            if (TerminationList.mileStoneDescription == "Petitioner's rehearing request date") {
              TerminationList.mileStoneDate = rehearingval.filedDate;
              TerminationList.mileStoneDateString = this.getDateString(rehearingval.filedDate / 1000, 'yyyy-MM-dd');
            }
            if (TerminationList.mileStoneDescription == "Rehearing decision date") {
              TerminationList.mileStoneDate = rehearingval.decisionDate;
              TerminationList.mileStoneDateString = this.getDateString(rehearingval.decisionDate / 1000, 'yyyy-MM-dd');
            }
            if (TerminationList.descriptionText) {
              TerminationList.descriptionText = rehearingval.rehearingStatusDisplayName;
            }
          })
        }
      }
      )
      this.rehearingDIPostList = JSON.parse(JSON.stringify(this.rehearingDIList));
      this.rehearingTerminationPostList = JSON.parse(JSON.stringify(this.rehearingTerminationList));
    }, (rehearingsFailure) => {
      console.log('rehearingsFailure: ', rehearingsFailure);
    })
  }

  getAppealsData() {
    let url = '/proceeding-appeal?proceedingNumber=' + this.caseInfo.proceedingNo;
    this.trialsService.getAppealsList(url).subscribe((appealsListResponse) => {
      this.appealsList = appealsListResponse;
      this.appealsList.forEach(appealElement => {
        appealElement.courtDecisionDateString = this.getDateString(appealElement.courtDecisionDate / 1000, 'yyyy-MM-dd');
        appealElement.courtMandateDateString = this.getDateString(appealElement.courtMandateDate / 1000, 'yyyy-MM-dd');
        if (appealElement.appealPartyTypeCode == "PETITIONER") {
          appealElement.appealPartyDescriptionText = "Petitioner"
        }
        if (appealElement.appealPartyTypeCode == "PATENTOWNER") {
          appealElement.appealPartyDescriptionText = "Patent Owner"
        }
        if (appealElement.appealStatusCode == "Initiated") {
          appealElement.appealStatusDescriptionText = "Appeal Initiated"
        }
        if (appealElement.appealStatusCode == "Completed") {
          appealElement.appealStatusDescriptionText = "Appeal Completed"
        }
        if (appealElement.appealStatusCode == "Awaiting Decision") {
          appealElement.appealStatusDescriptionText = "Appeal Awaiting Decision"
        }
      });
      this.appealsListPost = JSON.parse(JSON.stringify(this.appealsList));
    })
  }

  saveAppealsInfo(appealsList, section) {
    let obj = [];
    let call = false;
    section.proceedingMileStoneDetails.forEach((applElement,index, arr) => {
      if (applElement.mileStoneDate) {
        call = true;
      }
    })
    if(call){
        this.saveInfo(section, this.rehearingDIList, this.rehearingTerminationList);
    }

    if (JSON.stringify(this.appealsListPost) != JSON.stringify(appealsList)) {
      let counter = 0;
      appealsList.forEach(objElement => {
        if (objElement.appealStatusCode != this.appealsListPost[counter].appealStatusCode ||
          objElement.courtDecisionDateString != this.appealsListPost[counter].courtDecisionDateString ||
          objElement.courtMandateDateString != this.appealsListPost[counter].courtMandateDateString ||
          objElement.externalCourtName != this.appealsListPost[counter].externalCourtName) {

          if (objElement.courtDecisionDateString) {
            let date: any = Date.parse(objElement.courtDecisionDateString + "T00:00")
            objElement.courtDecisionDate = this.getMilestoneDate(this.getDateString(date / 1000, 'yyyy-MM-dd'))
          }
          if (objElement.courtMandateDateString) {
            let date: any = Date.parse(objElement.courtMandateDateString + "T00:00")
            objElement.courtMandateDate = this.getMilestoneDate(this.getDateString(date / 1000, 'yyyy-MM-dd'))
          }
          if (objElement.appealStatusCode == "Initiated") {
            objElement.appealStatusDescriptionText = "Appeal Initiated"
          }
          if (objElement.appealStatusCode == "Completed") {
            objElement.appealStatusDescriptionText = "Appeal Completed"
          }
          if (objElement.appealStatusCode == "Awaiting Decision") {
            objElement.appealStatusDescriptionText = "Appeal Awaiting Decision"
          }
          obj.push(objElement);
        }
        counter++;
      });
      this.trialsService.updateAppeals('/proceeding-appeal', obj).subscribe((derivationDataResponse) => {
        this.editModeNumber = -1;
        this.inEditMode = false;
        if (section.categoryType == 'CAFC' && !section.proceedingMileStoneDetails[0].mileStoneDate) {
          this.toastr.success(`Your Petition Milestones have been updated`, "", {
            closeButton: true
          });
        }
          this.getAppealsData();
          this.getMilestoneData();
          this.appealsListPost = JSON.parse(JSON.stringify(appealsList));
      }, (derivationDataResponse) => {
        this.toastr.error(`Unable to update milestone date(s).`, "", {
          closeButton: true
        });
      });
    }
  }

  getAppealsStatuses() {
    let url = '/references?typeCode=appealStatuses';
    this.commonService.getAppealsStatuses(url).subscribe((appealStatusesesponse) => {
      this.appealStatuses = [];
      appealStatusesesponse.forEach(ele => {
        if (ele.code != "Initiated") {
          this.appealStatuses.push(ele);
        }
      });
    })
  }

  saveRehearingInfo(rehearingDIList, rehearingTerminationList, categoryType) {
    let url = "/rehearing-info/milestone-dates";
    let updateObj = [];
    if (categoryType == "DI" && rehearingDIList.proceedingMileStoneDetails[3].mileStoneDateString && rehearingDIList.proceedingMileStoneDetails[3].mileStoneDateString != this.rehearingDIPostList.proceedingMileStoneDetails[3].mileStoneDateString) {
      let dateString = this.getMilestoneDate(this.getDateString(Date.parse(rehearingDIList.proceedingMileStoneDetails[3].mileStoneDateString + "T00:00") / 1000, 'yyyy-MM-dd'))
      this.saveMilestoneRehearingRequest(dateString);
      this.rehearingDIPostList.proceedingMileStoneDetails[3].mileStoneDateString = rehearingDIList.proceedingMileStoneDetails[3].mileStoneDateString;
    }
    if (categoryType == "Termination" && rehearingTerminationList.proceedingMileStoneDetails[3].mileStoneDateString && rehearingTerminationList.proceedingMileStoneDetails[3].mileStoneDateString != this.rehearingTerminationPostList.proceedingMileStoneDetails[3].mileStoneDateString) {
      let dateString = this.getMilestoneDate(this.getDateString(Date.parse(rehearingTerminationList.proceedingMileStoneDetails[3].mileStoneDateString + "T00:00") / 1000, 'yyyy-MM-dd'))
      this.saveMilestoneRehearingRequest(dateString);
      this.rehearingTerminationPostList.proceedingMileStoneDetails[3].mileStoneDateString = rehearingTerminationList.proceedingMileStoneDetails[3].mileStoneDateString;
    }
    if ((JSON.stringify(rehearingDIList) != JSON.stringify(this.rehearingDIPostList)) ||
      (JSON.stringify(rehearingTerminationList) != JSON.stringify(this.rehearingTerminationPostList))) {
      this.rehearingRes.forEach(el => {
        if (categoryType == "DI" && el.requestorTypeName == "Patent Owner" && el.rehearingTypeName == "Institution Decision") {
          updateObj = [{
            "rehearingId": el.rehearingId,
            "rehearingStatus": rehearingDIList.proceedingMileStoneDetails[4].descriptionText,
            "notificationRequiredIndicator": "N",
            "decisionDate": this.getMilestoneDate(this.getDateString(Date.parse(rehearingDIList.proceedingMileStoneDetails[2].mileStoneDateString + "T00:00") / 1000, 'yyyy-MM-dd')),
            "filedDate": this.getMilestoneDate(this.getDateString(Date.parse(rehearingDIList.proceedingMileStoneDetails[0].mileStoneDateString + "T00:00") / 1000, 'yyyy-MM-dd')),
            "audit": {
              "lastModifiedUserIdentifier": this.loggedInUser.loginId,
              "lastModifiedTimestamp": new Date().getTime()
            }
          }]
        }
        else if (categoryType == "DI" && el.requestorTypeName == "Petitioner" && el.rehearingTypeName == "Institution Decision") {
          updateObj = [{
            "rehearingId": el.rehearingId,
            "rehearingStatus": rehearingDIList.proceedingMileStoneDetails[4].descriptionText,
            "notificationRequiredIndicator": "N",
            "decisionDate": this.getMilestoneDate(this.getDateString(Date.parse(rehearingDIList.proceedingMileStoneDetails[2].mileStoneDateString + "T00:00") / 1000, 'yyyy-MM-dd')),
            "filedDate": this.getMilestoneDate(this.getDateString(Date.parse(rehearingDIList.proceedingMileStoneDetails[1].mileStoneDateString + "T00:00") / 1000, 'yyyy-MM-dd')),
            "audit": {
              "lastModifiedUserIdentifier": this.loggedInUser.loginId,
              "lastModifiedTimestamp": new Date().getTime()
            }
          }]
        }
        else if (categoryType == "Termination" && el.requestorTypeName == "Patent Owner" && el.rehearingTypeName == "Final Written Decision") {
          updateObj = [{
            "rehearingId": el.rehearingId,
            "rehearingStatus": rehearingTerminationList.proceedingMileStoneDetails[4].descriptionText,
            "notificationRequiredIndicator": "N",
            "decisionDate": this.getMilestoneDate(this.getDateString(Date.parse(rehearingTerminationList.proceedingMileStoneDetails[2].mileStoneDateString + "T00:00") / 1000, 'yyyy-MM-dd')),
            "filedDate": this.getMilestoneDate(this.getDateString(Date.parse(rehearingTerminationList.proceedingMileStoneDetails[0].mileStoneDateString + "T00:00") / 1000, 'yyyy-MM-dd')),
            "audit": {
              "lastModifiedUserIdentifier": this.loggedInUser.loginId,
              "lastModifiedTimestamp": new Date().getTime()
            }
          }]
        }
        else if (categoryType == "Termination" && el.requestorTypeName == "Petitioner" && el.rehearingTypeName == "Final Written Decision") {
          updateObj = [{
            "rehearingId": el.rehearingId,
            "rehearingStatus": rehearingTerminationList.proceedingMileStoneDetails[4].descriptionText,
            "notificationRequiredIndicator": "N",
            "decisionDate": this.getMilestoneDate(this.getDateString(Date.parse(rehearingTerminationList.proceedingMileStoneDetails[2].mileStoneDateString + "T00:00") / 1000, 'yyyy-MM-dd')),
            "filedDate": this.getMilestoneDate(this.getDateString(Date.parse(rehearingTerminationList.proceedingMileStoneDetails[1].mileStoneDateString + "T00:00") / 1000, 'yyyy-MM-dd')),
            "audit": {
              "lastModifiedUserIdentifier": this.loggedInUser.loginId,
              "lastModifiedTimestamp": new Date().getTime()
            }
          }]
        }
      });
      if (updateObj.length > 0 && (!isNaN(updateObj[0].decisionDate) || !isNaN(updateObj[0].filedDate))) {
        this.trialsService.updateMotionRehearing(url, updateObj).subscribe((res) => {
          this.editModeNumber = -1;
          this.inEditMode = false;
          this.toastr.success(`Rehearing(s) updated successfully`, "", {
            closeButton: true
          });
          this.getRehearings('all', 'rehearing(s)');
          //this.rehearingDIPostList = JSON.parse(JSON.stringify(rehearingDIList));
          //this.rehearingTerminationPostList = JSON.parse(JSON.stringify(rehearingTerminationList));
        })
      }
    }
  }

  saveMilestoneRehearingRequest(dateString) {
    let elementOrig = [{
      mileStoneDate: dateString,
      mileStoneTypeName: "Rehearing request due date",
      audit: this.auditObject,
      proceedingNumber: this.caseInfo.proceedingNo
    }];
    this.saveData(elementOrig);
  }

  getMotionStatusTypes(){
    let url = '/references?typeCode=motionStatusType';
    this.commonService.getMotionStatusTypes(url).subscribe((statusTypes) => {
      this.motionStatusTypes=statusTypes;
      statusTypes.forEach(se => {
        this.motionStatusTypes.push(se.code);
      });
    })
  }

  getDecisionHistory(){
    this.trialsService.getDecisionHistory(`/proceeding-milestone-details/history?caseNumber=${this.caseInfo.proceedingNo}&milestoneTypeIdentifier=5`).subscribe((historySuccess) => {
      this.decisionHistory = historySuccess;
    });
  }


  setMilestonePopr(e) {
    console.log(e);
  }

}