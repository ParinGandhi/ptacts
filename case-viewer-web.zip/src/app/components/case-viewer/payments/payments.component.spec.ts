import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { JpViewService } from 'src/app/services/jpview.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { of } from 'rxjs';
import * as paymentsRes from 'src/assets/test_data/payments.json';
import { PaymentsComponent } from './payments.component';
import { CaseViewerService } from 'src/app/services/case-viewer.service';

describe('PaymentsComponent', () => {
  let component: PaymentsComponent;
  let fixture: ComponentFixture<PaymentsComponent>;
  let jpViewService: JpViewService;
  let caseViewerService: CaseViewerService;
  let tempData = [];

  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "123456789",
        caseNumber: "IPR2020-123456"
      }
    }
  };

  beforeEach( () => {
     TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, NgbModule],
      declarations: [PaymentsComponent],
      providers: [
        JpViewService,
        CaseViewerService,
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        }
      ]
    })
    .compileComponents();
    fixture = TestBed.createComponent(PaymentsComponent);
    jpViewService = TestBed.inject(JpViewService);
    caseViewerService = TestBed.inject(CaseViewerService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  afterEach(() => {
    TestBed.resetTestingModule();
    fixture.destroy();
});
  // beforeEach(() => {
  //   fixture = TestBed.createComponent(PaymentsComponent);
  //   jpViewService = TestBed.inject(JpViewService);
  //   component = fixture.componentInstance;
  //   component.paymentsInfoTemp = [{},{}];
  //   tempData = [];
  //   fixture.detectChanges();
  // });

  it('should create', () => {
    // let tempData = paymentsRes;
    component.orderByField = ["-party"];
    component.paymentsInfoTemp = [{},{}];
    component.paymentsInfo = [{},{}];
    expect(component).toBeTruthy();
  });

  it('should call getPaymentsData and get response', () => {
    // spyOn(jpViewService, 'getPayments').and.returnValue(of(paymentsRes));
    // spyOn(jpViewService, 'getPayments').and.returnValue(of(paymentsRes));
    spyOn(caseViewerService, 'getPayments').and.returnValue(of(paymentsRes));
    component.orderByField = ["-party"];

    component.paymentsInfoTemp = [{},{}];
    component.paymentsInfo = [{},{}];
    component.getPaymentsData();
    expect(component.paymentsInfo).toBeDefined;
  });

  it('should call sortColClick', () => {
    component.orderByField=['-party']
    // let field = 'paymentMethod';
    component.paymentsInfoTemp = [{},{}];
    component.paymentsInfo = [{},{}];
    component.sortColClick('-party');
  });

 /* afterAll(() => {
    TestBed.resetTestingModule();
  });
*/

});
