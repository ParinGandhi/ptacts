import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import { CaseViewerService } from 'src/app/services/case-viewer.service';
import { JpViewService } from 'src/app/services/jpview.service';

@Component({
  selector: 'app-payments',
  templateUrl: './payments.component.html',
  styleUrls: ['./payments.component.less']
})
export class PaymentsComponent implements OnInit {
  caseInfo: CaseInfoModel;
  paymentsInfo: any;
  orderByField: any[] = [];
  payments: any;
  paymentsInfoTemp: any[] = [];
  sortCount: boolean = false;
  lastRefresh = new Date();

  constructor(
    private jpViewService: JpViewService,
    private caseViewerService: CaseViewerService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };
    this.getPaymentsData();
    this.sortCount = true;
    // setInterval(()=>{
    //   this.refresh();
    // },300000)
  }

  refresh(){
    this.getPaymentsData();
    this.lastRefresh = new Date();
  }

  getPaymentsData() {
    let url = PtabTrialConstants.PAYMENTS+ this.caseInfo.proceedingNo;
    // this.jpViewService.getPayments(url).subscribe((payentsResponse) => {
    this.caseViewerService.getPayments(this.caseInfo.proceedingNo).subscribe((payentsResponse) => {
      this.paymentsInfo = payentsResponse;
      this.sortColumns('-party');
      this.sortColumns('-transactionDate');
      // JSON.parse(JSON.stringify(payentsResponse));

    });
  }

  sortColClick(field) {
    !this.orderByField.includes(field) ? this.correctOrder(field) : this.correctOrder('-' + field);
    this.orderByField = !this.orderByField.includes(field) ? [field] : ['-' + field];
    this.sortCount = false;
  }

  correctOrder(field) {
    let tempData = [];
      tempData = this.paymentsInfo;
      this.paymentsInfo = [];
      let order = field.charAt(0) === '-' ? "desc" : "asc"
      if(this.paymentsInfoTemp.length > 0){
        this.paymentsInfoTemp.sort(this.compareValues(field, order));
      }else {
        tempData.sort(this.compareValues(field, order));
      }

      this.paymentsInfoTemp = tempData;
      this.paymentsInfo = this.paymentsInfoTemp;
  }
/* istanbul ignore next */
  sortColumns(field) {
      !this.orderByField.includes(field) ? this.correctOrder(field) : this.correctOrder('-' + field);
      field = !this.orderByField.includes(field) ? field : '-' + field;
      if(field.includes('-')){
        let indx = this.orderByField.indexOf(field.substring(1));
        if(indx != -1){
        this.orderByField.splice(indx);
        }
      }
      if(!field.includes('-')){
        let indx = this.orderByField.indexOf('-'+field);
        if(indx != -1){
          this.orderByField.splice(indx);
        }
      }
      if(this.orderByField.indexOf(field) == -1){
        this.orderByField.push(field);
      }
  }
/* istanbul ignore next */
  compareValues(key, order = 'asc') {
    if (key.charAt(0) === '-') {
      key = key.substring(1);
    }
    return function innerSort(a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        // property doesn't exist on either object
        return 0;
      }

      const varA = (typeof a[key] === 'string')
        ? a[key].toUpperCase() : a[key];
      const varB = (typeof b[key] === 'string')
        ? b[key].toUpperCase() : b[key];

      let comparison = 0;
      if (varA > varB) {
        comparison = 1;
      } else if (varA < varB) {
        comparison = -1;
      }
      return (
        (order === 'desc') ? (comparison * -1) : comparison
      );
    };
  }
}
