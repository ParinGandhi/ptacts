import { ComponentFixture, TestBed, tick } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { of, throwError } from 'rxjs';
import { JpViewService } from 'src/app/services/jpview.service';
import * as CaseViewerSelectors  from 'src/app/store/case-viewer/case-viewer.selectors';
import { CaseviewerHeaderComponent } from './caseviewer-header.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { EventEmitter } from '@angular/core';
import { TrialsService } from 'src/app/services/trials.service';


describe('CaseviewerHeaderComponent', () => {
  let component: CaseviewerHeaderComponent;
  let fixture: ComponentFixture<CaseviewerHeaderComponent>;
  let trialsService: TrialsService;
  let jpViewService: JpViewService;
  let modalService: BsModalService;
  let activatedRoute: ActivatedRoute;
  let store: MockStore<any>;

  const activatedRouteMock = {
    snapshot: {
      params: {
        serialNo: "123456789",
        proceedingNo: "DER2020-123456"
      },
      url:[
        {
          path: "case-viewer"
        }
      ]
    }
  }

  const OpenPalmResponse = [{
    "valueText": "APPL_ID",
    "descriptionText": "http://palmapps-fqt.etc.uspto.gov/cgi-bin/expo/GenInfo/snquery.pl?APPL_ID="
}, {
    "valueText": "PATENT_NUMBER",
    "descriptionText": "http://palmapps-fqt.etc.uspto.gov/cgi-bin/expo/GenInfo/pnquery.pl?PAT_ID="
}];

const caseStatusMockData = [{
      "nameText": "Petition",
      "descriptionText": "Initiated"
  }];

  const paneledJudge = {
    "supplementaryIdType": "PATENT",
    "listofJudges": [
        {
            "activeIndicator": "Y",
            "identifier": "5032",
            "firstName": "Stephen",
            "lastName": "Siu",
            "activeJudgeIndicator": "N",
            "electronicAddress": [
                {
                    "email": "TEST_stephen.siu@USPTO.GOV"
                }
            ],
            "prefferedName": "Siu, Stephen",
            "audit": {
                "createUserIdentifier": "sbartlett",
                "lastModifiedUserIdentifier": "sbartlett",
                "lastModifiedTimestamp": 1615779223000,
                "createTimestamp": 1615779223000
            },
            "rank": "1",
            "lifeCycle": {
                "beginEffectiveDate": 1516770000000
            }
        },
        {
            "activeIndicator": "Y",
            "identifier": "9951",
            "firstName": "Jennifer",
            "lastName": "Bahr",
            "activeJudgeIndicator": "Y",
            "middleInitial": "D.",
            "electronicAddress": [
                {
                    "email": "TEST_jennifer.bahr@uspto.gov"
                }
            ],
            "prefferedName": "Bahr, Jennifer D.",
            "audit": {
                "createUserIdentifier": "sbartlett",
                "lastModifiedUserIdentifier": "sbartlett",
                "lastModifiedTimestamp": 1615779223000,
                "createTimestamp": 1615779223000
            },
            "rank": "2",
            "lifeCycle": {
                "beginEffectiveDate": 1516770000000
            }
        },
        {
            "activeIndicator": "Y",
            "identifier": "5014",
            "firstName": "Ken",
            "lastName": "Barrett",
            "activeJudgeIndicator": "Y",
            "middleInitial": "B.",
            "electronicAddress": [
                {
                    "email": "TEST_Ken.Barrett@USPTO.GOV"
                }
            ],
            "prefferedName": "Barrett, Ken B.",
            "audit": {
                "createUserIdentifier": "sbartlett",
                "lastModifiedUserIdentifier": "sbartlett",
                "lastModifiedTimestamp": 1615779223000,
                "createTimestamp": 1615779223000
            },
            "rank": "3",
            "lifeCycle": {
                "beginEffectiveDate": 1516770000000
            }
        },
        {
            "activeIndicator": "Y",
            "identifier": "1809",
            "firstName": "Charles",
            "lastName": "Boudreau",
            "activeJudgeIndicator": "Y",
            "middleInitial": "J.",
            "electronicAddress": [
                {
                    "email": "TEST_Charles.Boudreau@USPTO.GOV"
                }
            ],
            "prefferedName": "Boudreau, Charles J.",
            "audit": {
                "createUserIdentifier": "sbartlett",
                "lastModifiedUserIdentifier": "sbartlett",
                "lastModifiedTimestamp": 1615779223000,
                "createTimestamp": 1615779223000
            },
            "rank": "4",
            "lifeCycle": {
                "beginEffectiveDate": 1516770000000
            }
        },
        {
            "activeIndicator": "Y",
            "identifier": "1806",
            "firstName": "Daniel",
            "lastName": "Fishman",
            "activeJudgeIndicator": "N",
            "middleInitial": "N.",
            "electronicAddress": [
                {
                    "email": "TEST_Daniel.Fishman@USPTO.GOV"
                }
            ],
            "prefferedName": "Fishman, Daniel N.",
            "audit": {
                "createUserIdentifier": "sbartlett",
                "lastModifiedUserIdentifier": "sbartlett",
                "lastModifiedTimestamp": 1615779223000,
                "createTimestamp": 1615779223000
            },
            "rank": "5",
            "lifeCycle": {
                "beginEffectiveDate": 1516770000000
            }
        }
    ],
    "ptabReadOnlyUser": true,
    "proceedingSupplementaryIdList": [
        "7337241"
    ],
    "caseNo": "IPR2018-00328",
    "caseType": "TRIALS"
}

  const assignmentMockResponse = { "assignedDate": 1603481750000, "preExistentAssignmentId": null, "notes": null, "dueDate": 1603943999999, "parentCirculationAssignment": false, "circulationPanelReorder": null, "assignmentTypeIdentifier": "111", "noOfActiveCases": 0, "documentReviewDate": null, "assignmentTypeDescription": "Paralegal review decision draft", "appealNumber": "2019004249", "assignmentFullName": null, "actionCode": null, "assignmentStatusCode": "A", "activeIndicator": "A", "sequenceNumber": 0, "artifactUrlText": null, "serialNumber": "14833621", "assigneeRoleCode": "Paralegal/LIE", "circulationMailingNotes": null, "assignmentIdentifier": 1143956, "nextAssignee": null, "pageNumberQuantity": null, "ptabReadOnlyUser": true, "priorityIndicator": "N", "completionCode": null, "assignee": "11356", "documentReviewerName": null, "assignmentExist": false, "artifactTitleName": null, "description": "Paralegal review decision draft", "palmMailedDate": null, "title": "Paralegal review decision draft - 2019004249", "reassignDueDate": null, "assignmentType": "CIRPR", "caseType": "APPEAL", "globalMetaData": { "briefHearingType": "On brief", "applicationNumber": "14833621", "caseStatusDate": 1603481751000, "caseNumber": "2019004249", "caseStatus": "Decision draft in circulation", "applicationStatusDescriptionText": "Final Rejection Mailed", "merge": false, "parties": null, "panel": [{ "employeeName": "McKeown, Jennifer L.", "rank": 1 }, { "employeeName": "Belisle, Stephen E.", "rank": 2 }, { "employeeName": "Hughes, James R.", "rank": 3 }], "caseType": "REGULAR" }, "audit": { "createUserIdentifier": "jmckeown", "createdUserName": "McKeown, Jennifer L.", "lockControlNumber": 1, "lastModifiedUserIdentifier": "jmckeown", "lastModifiedUserName": "McKeown, Jennifer L.", "lastModifiedTimestamp": 1603481750000, "createTimestamp": 1603481750646 }, "standardAssignmentType": { "ASSIGNMENTINFO": "Assignment info" }, "pendingLocationText": null, "hearingIndicator": null, "circulationInProcess": false, "assignor": "10825", "assigneeRoleDescription": null, "lastModifiedUserName": null, "message": null, "transactionDate": null, "completedUserName": null, "reconsiderSequence": null, "proceedingType": null, "assignmentSequence": null, "clearPanelIndicator": null, "circulation": false, "completionDate": null, "lifeCycle": null };

  const headerInfoResponseMock = {
    artUnit: 2826,
    attorneys: null,
    casePhase: null,
    derproceedingTypeDetails: "Public",
    inventionTitle: "AN INTERPOSING STRUCTURE",
    keyDates: null,
    mileStoneDates: null,
    parties: null,
    patentNumberText: 7566960,
    proceedingNumber: "IPR2012-00008",
    ptabReadOnlyUser: true,
    techCenterNum: 2800
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [ CaseviewerHeaderComponent ],
      providers: [
        JpViewService,provideMockStore({
          selectors: [
            { selector: CaseViewerSelectors.caseInfoData, value: { proceedingNo: 'DER2020-123456' } },
            { selector: CaseViewerSelectors.userInfoData,value:{caseDetailsData: []}},
            { selector: CaseViewerSelectors.caseHeaderData, value: { caseHeaderData: [] } },
            { selector: CaseViewerSelectors.casePhaseData, value: { casePhaseData: [] } }
          ]
        }),
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        },
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useValue: {}
        },
        {
          provide:DatePipe,
          useValue:{}
        },
        { provide: ToastrService,
          useValue: {}
        }
       ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseviewerHeaderComponent);
    trialsService = TestBed.inject(TrialsService);
    jpViewService = TestBed.inject(JpViewService);
    modalService = TestBed.inject(BsModalService);
    component = fixture.componentInstance;
    component.loggedInUser ={ loginId: "akellogg",privileges: "PanelMember"};
    component.caseInfo =  {
      serialNo: '14178064',
      proceedingNo: 'DER2018-00328'
    };
    store = TestBed.inject(MockStore);
    let store2 = {};
    const mockSessionStorage = {
      getItem: (key: string): string => {
        return key in store2 ? store2[key] : null;
      },
      setItem: (key: string, value: string) => {
        store2[key] = `${value}`;
      },
      removeItem: (key: string) => {
        delete store2[key];
      },
      clear: () => {
        store2 = {};
      }
    };
    spyOn(sessionStorage, 'getItem')
      .and.callFake(mockSessionStorage.getItem);
    spyOn(sessionStorage, 'setItem')
      .and.callFake(mockSessionStorage.setItem);
    spyOn(sessionStorage, 'removeItem')
      .and.callFake(mockSessionStorage.removeItem);
    spyOn(sessionStorage, 'clear')
        .and.callFake(mockSessionStorage.clear);

      let userName = {
        loginId: "sbartlett"
      };
      mockSessionStorage.setItem('userInfo', JSON.stringify(userName));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('should get Case Header Info', () => {
  //   spyOn(trialsService, 'getCaseHeaderInfo').and.returnValue(of(headerInfoResponseMock));
  //   component.getCaseHeaderInfo(component.caseInfo);
  //   expect(component.caseHeaderInfo).toEqual(headerInfoResponseMock);
  // });

  it('should call getPaneledJudges and get successResponse', () => {
    spyOn(trialsService, 'getPaneledJudges').and.returnValue(of(paneledJudge));
    component.getPanelInfo();
    expect(component.panelOnCase).toEqual(paneledJudge.listofJudges)
  });

  it('should call getPanelInfo and fail', () => {
    spyOn(trialsService, 'getPaneledJudges').and.returnValue(throwError(""));
    component.getPanelInfo();
    expect(component.panelOnCase).toEqual([]);
  });

  it('should call getCaseStatus and get successResponse', () => {
    spyOn(trialsService, 'getCaseStatus').and.returnValue(of(caseStatusMockData))
    component.getCaseStatus();
    expect(component.casePhase).not.toBeNull();
  });

  it('should call getPalmUrls and get successResponse', () => {
    spyOn(jpViewService, 'getOpenPalm').and.returnValue(of(OpenPalmResponse));
    component.getPalmUrls();
    expect(component.palmUrls).toEqual(OpenPalmResponse)
  });

  it('should show modal and update', () => {
    const initialState: any = {
      assignmentInfo: assignmentMockResponse
    };
    const emitter = new EventEmitter();
    emitter.emit(true);

    modalService.show = (): BsModalRef => {
      return ({ id: null, hide: null, setClass: null, onHide: emitter, onHidden: null,content: {
        animated: true,
        backdrop: true,
        ignoreBackdropClick: true,
        class: 'add-update-parties-modal-content',
        initialState
      } });
    };
    spyOn(component, "openUpdatePanelingModal").and.callThrough();
    component.openUpdatePanelingModal();
    expect(component.openUpdatePanelingModal).toHaveBeenCalled();
  });

});
