import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { Store, select } from '@ngrx/store';
// import { State } from '../../store';
import * as CaseViewerActions from 'src/app/store/case-viewer/case-viewer.actions';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ActivatedRoute, Router } from '@angular/router';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import CaseHeaderModel from 'src/app/models/cases/CaseHeader.model';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { JpViewService } from 'src/app/services/jpview.service';
import { PanelingComponent } from '../../workspace/modals/paneling/paneling.component';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { TrialsService } from 'src/app/services/trials.service';
import { Observable, Subject } from 'rxjs';
import { CaseViewerService } from 'src/app/services/case-viewer.service';

@Component({
  selector: 'app-caseviewer-header',
  templateUrl: './caseviewer-header.component.html',
  styleUrls: ['./caseviewer-header.component.less']
})
export class CaseviewerHeaderComponent implements OnInit {

  @Input() parties: string;

  @Output() showJoinedCasesTabEmitter: EventEmitter<boolean> = new EventEmitter();
  @Output() joinedCaseNumbersEmitter: EventEmitter<any> = new EventEmitter();

  caseInfo: CaseInfoModel;
  loggedInUser: any;
  expanded: boolean = false ;
  // getCaseHeader$ = this.store.select(CaseViewerSelectors.caseHeaderData);
  getCaseHeader$: Observable<any>;
  getCasePhase$ = this.store.pipe(select(CaseViewerSelectors.casePhaseData));
  loggedInUser$ = this.store.pipe(select(CaseViewerSelectors.userInfoData));
  caseHeaderData: CaseHeaderModel;
  palmUrls: any;
  updatePanelModalRef: BsModalRef;
  isPanelMember: boolean = false;
  panelOnCase: Array<any> = [];
  casePhase: string = null;
  caseHeaderInfo: CaseHeaderModel;
  caseHeaderSubject = new Subject<any>();
  originalCase: Array<any> = [];
  joinedCases: Array<any> = [];
  relatedCases = {
    originalCase: [],
    joinedCases: []
  };
  isOriginalCase = false;
  showJoinedCasesDropdown = false;

  constructor(
    private store: Store<CaseViewerState>,
    private activatedRoute: ActivatedRoute,
    private jpViewService: JpViewService,
    private caseViewerService: CaseViewerService,
    private trialsService: TrialsService,
    private modalService: BsModalService,
    private commonUtils: CommonUtilitiesService
  ) {
    this.getCaseHeader$ = this.store.pipe(select(CaseViewerSelectors.caseHeaderData));
  }

  ngOnInit(): void {
    this.store.select(CaseViewerSelectors.userInfoData).subscribe(data => {
      this.caseInfo = {
        serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
        proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
      };

      if(this.activatedRoute.snapshot.url[0].path == 'case-viewer') {

        window.document.title = this.caseInfo.proceedingNo + "- Case Viewer - P-TACTS".replace("-"," -");
      }

      if(this.caseInfo.proceedingNo && this.caseInfo.proceedingNo.indexOf('DER') > -1){
        this.expanded = true;
      }
      this.loggedInUser = data.caseDetailsData[0];
      if (!this.loggedInUser) {
        this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
      }
      this.isPanelMember = this.commonUtils.checkIfPanelingMember(this.loggedInUser);
    });

    this.getCaseHeaderInfo(this.caseInfo);
    // this.receiveCaseHeaderInfo();
    this.getPalmUrls();
    this.getPanelInfo();
    this.getCaseStatus();
    this.getJoinderRelatedCases();
  }



  getCaseHeaderInfo(caseInfo) {
    // let urlString =PtabTrialConstants.CASE_HEADER + `${caseInfo.serialNo}&proceedingSupplementaryId=${caseInfo.proceedingNo}`;
    // this.store.dispatch(CaseViewerActions.GetCaseHeaderAction({urlSuffix: urlString}));
    this.trialsService.getCaseHeaderInfo(caseInfo.proceedingNo).subscribe((caseHeaderInfoResponse) => {
      this.caseHeaderInfo = caseHeaderInfoResponse[0];
      window.sessionStorage.setItem('caseInfo', JSON.stringify(caseHeaderInfoResponse[0]));
      let confidentiality: any;
      confidentiality = this.caseHeaderInfo ? this.caseHeaderInfo.derproceedingTypeDetails : null;
      this.commonUtils.confidentialityInfo = confidentiality?.poConfidentialityIn;
    });
  }

  // receiveCaseHeaderInfo() {
  //   this.trialsService.receiveCaseHeaderInfo().subscribe((caseHeaderInfoResponse) => {
  //     this.caseHeaderInfo = caseHeaderInfoResponse;
  //   })
  // }

  getPanelInfo() {
    this.trialsService.getPaneledJudges(this.caseInfo.proceedingNo, false).subscribe((paneledJudgesResponse) => {
      this.panelOnCase = paneledJudgesResponse.listofJudges;
    }, (paneledJudgesFailure) => {
        this.panelOnCase = [];
    });
  }

  getCaseStatus() {
    this.trialsService.getCaseStatus(this.caseInfo.proceedingNo).subscribe((casePhaseResponse) => {
      this.casePhase = casePhaseResponse[casePhaseResponse.length - 1];
    });
  }

  getPalmUrls() {
    // this.jpViewService.getOpenPalm().subscribe((response) => {
    this.caseViewerService.getOpenPalm().subscribe((response) => {
      this.palmUrls = response;
      console.log(this.palmUrls);
    });

  }

  // getJoinderRelatedCases() {
  //   this.trialsService.getJoinderRelatedCases(this.caseInfo.proceedingNo).subscribe((relatedCasesResponse) => {
  //     // this.relatedCases = relatedCasesResponse;
  //     this.showJoinedCasesDropdown = false;
  //     this.isOriginalCase = false;
  //     if (relatedCasesResponse.length > 1) {
  //       this.showJoinedCasesDropdown = true;
  //       relatedCasesResponse.forEach((element) => {
  //         // element.id = element.proceedingNo;
  //         if (element.joinderType && element.joinderType.toLowerCase() === 'original') {
  //           this.relatedCases.originalCase.push(element.proceedingNo);
  //           if (this.caseInfo.proceedingNo === element.proceedingNo) {
  //             this.isOriginalCase = true;
  //             this.showJoinedCasesTabEmitter.emit(true);
  //           }
  //           } else {
  //           this.relatedCases.joinedCases.push(element.proceedingNo);
  //           }
  //       });
  //    }
  //   }, (relatedCasesFailure) =>{
  //     this.commonUtils.setToastr('error', relatedCasesFailure.error.message)
  //   });
  // }


  getJoinderRelatedCases() {
    this.trialsService.getJoinedCaseDetails(this.caseInfo.proceedingNo).subscribe((relatedCasesResponse) => {
      // this.relatedCases = relatedCasesResponse;
      this.relatedCases.originalCase = [];
      this.relatedCases.joinedCases = [];
      this.showJoinedCasesDropdown = false;
      this.isOriginalCase = false;
      // relatedCasesResponse = [ {
      //   "proceedingNo": "IPR2020-01403",
      //   "relatedProceedingNo": "PGR2021-01234",
      //   "poRealParty": "Varian Medical Systems, Inc.",
      //   "petitionerRealParty": "ViewRay, Inc. et al.",
      //   "descriptionText": "Terminated-Dismissed",
      //   "beginEffectiveDate": 1621786127000
      // },
      // {
      //   "proceedingNo": "IPR2020-01403",
      //   "relatedProceedingNo": "CBM2021-00035",
      //   "poRealParty": "Varian Medical Systems, Inc.",
      //   "petitionerRealParty": "ViewRay, Inc. et al.",
      //   "descriptionText": "Terminated-Dismissed",
      //   "beginEffectiveDate": 1621739646000
      //   },
      //   {
      //     "proceedingNo": "IPR2020-01403",
      //     "relatedProceedingNo": "IPR2021-00023",
      //     "poRealParty": "Varian Medical Systems, Inc.",
      //     "petitionerRealParty": "ViewRay, Inc. et al.",
      //     "descriptionText": "Terminated-Dismissed",
      //     "beginEffectiveDate": 1621526927000
      // }, {
      //   "proceedingNo": "IPR2020-01403",
      //   "relatedProceedingNo": "IPR2021-00567",
      //   "poRealParty": "Varian Medical Systems, Inc.",
      //   "petitionerRealParty": "ViewRay, Inc. et al.",
      //   "descriptionText": "Terminated-Dismissed",
      //   "beginEffectiveDate": 1621739646000
      //   },
      //   {
      //     "proceedingNo": "IPR2020-01403",
      //     "relatedProceedingNo": "IPR2020-00567",
      //     "poRealParty": "Varian Medical Systems, Inc.",
      //     "petitionerRealParty": "ViewRay, Inc. et al.",
      //     "descriptionText": "Terminated-Dismissed",
      //     "beginEffectiveDate": 1621739646000
      // }];
      if (relatedCasesResponse.length >= 1) {
        this.showJoinedCasesDropdown = true;

        for (let i = 0; i < relatedCasesResponse.length; i++) {
          if (i == 0) {
            let tempOriginalCase = {
              "caseNo": relatedCasesResponse[i].proceedingNo,
              "joinedDate": relatedCasesResponse[i].beginEffectiveDate
            };
            // this.relatedCases.originalCase.push(relatedCasesResponse[i].proceedingNo);
            this.relatedCases.originalCase.push(tempOriginalCase);
            if (this.caseInfo.proceedingNo === relatedCasesResponse[i].proceedingNo) {
                    this.isOriginalCase = true;
                    this.showJoinedCasesTabEmitter.emit(true);
                  }
          }
          let tempJoinedCase = {
            "caseNo": relatedCasesResponse[i].relatedProceedingNo,
            "joinedDate": relatedCasesResponse[i].beginEffectiveDate
          };
          // this.relatedCases.joinedCases.push(relatedCasesResponse[i].relatedProceedingNo);
          this.relatedCases.joinedCases.push(tempJoinedCase);
        }


        this.relatedCases.joinedCases.sort(this.subsortByCaseNumber("joinedDate", "asc"));

        this.joinedCaseNumbersEmitter.emit(this.relatedCases);

        // relatedCasesResponse.forEach((element) => {
        //   // element.id = element.proceedingNo;
        //   if (element.joinderType && element.joinderType.toLowerCase() === 'original') {
        //     this.relatedCases.originalCase.push(element.proceedingNo);
        //     if (this.caseInfo.proceedingNo === element.proceedingNo) {
        //       this.isOriginalCase = true;
        //       this.showJoinedCasesTabEmitter.emit(true);
        //     }
        //     } else {
        //     this.relatedCases.joinedCases.push(element.proceedingNo);
        //     }
        // });
     }
    }, (relatedCasesFailure) => {
      console.log('relatedCasesFailure: ', relatedCasesFailure);
      this.relatedCases.originalCase = [];
      this.relatedCases.joinedCases = [];
      this.relatedCases.originalCase.push(this.caseInfo.proceedingNo);
      this.joinedCaseNumbersEmitter.emit(this.relatedCases);
    });
  }



  subsortByCaseNumber(key, order = 'asc') {

    return function innerSort(a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        // property doesn't exist on either object
        return 0;
      }

      // const joinedDateA = a[key];
      // const joinedDateB = b[key];
      const joinedDateA = new Date(new Date(a[key]).toDateString()).getTime();
      const joinedDateB = new Date(new Date(b[key]).toDateString()).getTime();


        let comparison = 0;
        if (joinedDateA > joinedDateB) {
          comparison = 1;
        } else if (joinedDateA < joinedDateB) {
          comparison = -1;
        } else {
          let caseNoA = a.caseNo;
          let caseNoB = b.caseNo;

        if (caseNoA > caseNoB) {
          comparison = 1;
        } else if (caseNoA < caseNoB) {
          comparison = -1;
        } else {
          return 0;
        }
        }
        return (
          (order === 'desc') ? (comparison * -1) : comparison
        );
    };
  }



/* istanbul ignore next */
  openUpdatePanelingModal() {
    const initialState = {
      paneling: {
        title: 'Update',
        showClearPanelBtn: true,
        isConfirm: false,
        caseToPanel: this.caseInfo
      }
    };
    this.updatePanelModalRef = this.modalService.show(PanelingComponent, {
      animated: true,
      backdrop: true,
      ignoreBackdropClick: true,
      class: 'add-update-parties-modal-content',
      initialState
    });
    this.updatePanelModalRef.onHide.subscribe((reason: string | any) => {
      console.log('reason: ', reason);
      if (reason.initialState.paneling.isConfirm) {
        this.getPanelInfo();
      }
    })
  }


  openCase(caseToOpen) {
    this.commonUtils.openInCaseViewer(caseToOpen);
    // this.jpViewService.getDocuments(`${PtabTrialConstants.CASE_VIEWER_URL}/case-viewer/caseNumber-search?caseNumber=${caseToOpen}`).subscribe((caseInfoResponse) => {
    //   let caseInfo = {
    //     "serialNo": caseInfoResponse.serialNumber[0],
    //     "proceedingNo": caseInfoResponse.appealNumber[0],
    //     "scrollToId": "documents"
    //   }

    //   if (caseInfo.proceedingNo && caseInfo.serialNo) {
    //     this.store.dispatch(CaseViewerActions.setCaseInfoAction({ payload: caseInfo }));
    //     window.sessionStorage.setItem('caseInfo', JSON.stringify(caseInfo));
    //     let newTabUrl = `${window.location.protocol}//${window.location.hostname}`;
    //     newTabUrl += window.location.port !== "" ? `:${window.location.port}` : "";
    //     newTabUrl += window.location.hostname === 'localhost' ? "/#/case-viewer/" + caseInfo.serialNo + "/" + caseInfo.proceedingNo + "/" + caseInfo.scrollToId: `${PtabTrialConstants.BASE_URL}/#` + "/case-viewer/" + caseInfo.serialNo + "/" + caseInfo.proceedingNo + "/" + caseInfo.scrollToId;
    //     window.open(newTabUrl);
    //   } else {
    //     this.jpViewService.getDocuments(`${PtabTrialConstants.CASE_VIEWER_URL}/case-viewer/caseNumber-search?caseNumber=${caseInfo.proceedingNo}`).subscribe((caseInfoResponse) => {
    //       if (caseInfoResponse.serialNumber && caseInfoResponse.serialNumber[0]) {
    //         let caseInfoResp = {
    //           "serialNo": caseInfoResponse.serialNumber[0].trim(),
    //           "proceedingNo": caseInfoResponse.appealNumber[0],
    //           "scrollToId": 'documents'
    //         };

    //         this.store.dispatch(CaseViewerActions.setCaseInfoAction({ payload: caseInfoResp }));
    //         window.sessionStorage.setItem('caseInfo', JSON.stringify(caseInfoResp));
    //         let currentUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
    //         // this.caseNumberSearch = null;
    //         let newTabUrl = `${window.location.protocol}//${window.location.hostname}`;
    //         newTabUrl += window.location.port !== "" ? `:${window.location.port}` : "";
    //       newTabUrl += window.location.hostname === 'localhost' ? "/#/case-viewer/" + caseInfoResp.serialNo + "/" + caseInfoResp.proceedingNo + "/" + caseInfoResp.scrollToId: `${PtabTrialConstants.BASE_URL}/#` + "/case-viewer/" + caseInfoResp.serialNo + "/" + caseInfoResp.proceedingNo + "/" + caseInfoResp.scrollToId;
    //         window.open(newTabUrl);
    //       } else {
    //         this.commonUtils.setToastr("error", "No serial number found for this case.");
    //       }
    //     })
    //   }
    // });
  }


}
