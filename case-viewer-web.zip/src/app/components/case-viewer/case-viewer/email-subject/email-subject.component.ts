import { Component, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from 'src/app/services/common.service';
import { DomSanitizer } from '@angular/platform-browser';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { Store, select } from '@ngrx/store';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';

@Component({
  selector: 'app-email-subject',
  templateUrl: './email-subject.component.html',
  styleUrls: ['./email-subject.component.less']
})

export class EmailSubjectComponent implements OnInit {
  modal: any;
  emailContent: any;
  imgSrcValue: any;
  loggedInUser: any;
  isSplAdmin: any = false;
  notResent: boolean = false;
  isLoading: boolean = true;
  noData: boolean = false;
  emailResponse: any;
  isPrint: boolean = true;
  printEmailBody: any = "";
  theHtmlString: any;
  constructor(private modalService: BsModalService, private store: Store<CaseViewerState>, private commonService: CommonService, private toastr: ToastrService, private domSanitizer: DomSanitizer) { }

  ngOnInit(): void {

    this.store.pipe(select(CaseViewerSelectors.userInfoData)).subscribe(data => {
      this.loggedInUser = data.caseDetailsData[0];

      this.isSplAdmin = data.isSplAdmin;
      if (!this.loggedInUser) {
        this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
      }
    });
    this.notResent = this.emailContent.notificationStatus && this.emailContent.notificationStatus == 'SENT' ? true : false;
    this.getEmailBody();
  }


  close(refreshValue) {
    this.modal.isConfirm = refreshValue;
    this.modalService.hide();
  }


  /*istanbul ignore next*/
  getEmailBody() {

    this.commonService.getNotificationsList('/notificationemail/' + this.emailContent.notificationId).subscribe((response) => {

      this.emailResponse = response;
    this.theHtmlString = response.htmlDocumentData


      this.imgSrcValue = this.domSanitizer.bypassSecurityTrustResourceUrl('data:text/html;base64,' + response.encodedDocumentData);
      setTimeout(() => {
        if (document.getElementById('email')) {
          this.isLoading = false;
          let simulateMouseEvent = function (element, eventName, coordX, coordY) {
            element.dispatchEvent(new MouseEvent(eventName, {
              view: window,
              bubbles: true,
              cancelable: true,
              clientX: coordX,
              clientY: coordY,
              button: 0
            }));
          };

          let theButton = document.querySelector('div');

          let box = theButton.getBoundingClientRect(),
            coordX = box.left + (box.right - box.left) / 2,
            coordY = box.top + (box.bottom - box.top) / 2;

          simulateMouseEvent(theButton, "mousedown", coordX, coordY);
          simulateMouseEvent(theButton, "mouseup", coordX, coordY);
          simulateMouseEvent(theButton, "click", coordX, coordY);

        }
      }, 1000);


    }, (failureResponse) => {
      this.isLoading = false;
      this.noData = true;
      this.toastr.error(failureResponse.error.message, "", {
        closeButton: true
      });
    })

  }
/*istanbul ignore next*/
  htmlContentVal() {
    return this.domSanitizer.bypassSecurityTrustHtml(this.theHtmlString)
  }
 /*istanbul ignore next*/
  printDiv (divName) {
  
    this.isPrint = false;
    // const isIFrame = (input: HTMLElement | null): input is HTMLIFrameElement =>input !== null && input.tagName === 'IFRAME';
    if(document.getElementById('emailBody')){
      let frame = document.getElementById('emailBody');
      if (frame) {
        this.printEmailBody = frame.innerHTML
    }
    
      // this.printEmailBody = document.getElementById('iFramee').contentWindow.document.body.innerHTML
    }
    if(document.getElementsByClassName(divName) && this.noData){
      this.printEmailBody = document.getElementsByClassName(divName)[1].innerHTML
    }
    // let printContents = document.getElementsByClassName(divName)[0].innerHTML + "" + this.printEmailBody.contentWindow.print();
    // let printBody = document.getElementById('emailBody');
    let popupWin = window.open('','','height:1500,width=1000,scrollbars=yes');
    popupWin.document.write(
      '<html><head><style>table { border-collapse: collapse; width: 100%;} @media print{th, td { text-align: left; padding: 8px;}label { display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold;} .format {width:8%;padding-left: 8px;text-align: right;}}@media print' +
      '{body {font-family: "Segoe UI",Helvetica Neue,Tahoma,Arial,sans-serif;font-size: 13px;line-height: 1.4;color: #444; width:511pt} tr.vendorListHeading { background-color: #e9eaeb !important; row:flex; -webkit-print-color-adjust: exact;} .format {width:8%;padding-left: 8px;text-align: right;}.formatSent{width:8%;padding-left: 8px;text-align: right; }}'
      // .col-print-1 {width:8%;  float:left;}.col-print-2 {width:16%; float:left;}.col-print-6 {width:50%; float:left;}.col-print-9' +
      // '{width:75%; float:left;}
      +'.col-print-12{width:100%; float:left;}</style></head><body>'
    );
    popupWin.document.write(document.getElementsByClassName(divName)[0].innerHTML + "" + this.printEmailBody);
    popupWin.document.write('</body></html>');
    popupWin.document.title = this.emailContent.subjectText;
    // popupWin.document.close();
    setTimeout(function () { popupWin.print(); }, 300);
    popupWin.onfocus = function () { setTimeout(function () { popupWin.close(); },500); }
    
  };


}
