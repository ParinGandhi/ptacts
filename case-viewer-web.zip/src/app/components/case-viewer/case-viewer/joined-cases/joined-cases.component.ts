import { Component, Input, OnInit } from '@angular/core';
import { OpenCaseviewerComponent } from 'src/app/components/common/open-caseviewer/open-caseviewer.component';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { TrialsService } from 'src/app/services/trials.service';


@Component({
  selector: 'app-joined-cases',
  templateUrl: './joined-cases.component.html',
  styleUrls: ['./joined-cases.component.less']
})
export class JoinedCasesComponent implements OnInit {

  @Input() caseInfo: any;

  /**
   *  Grid
   */
   gridApi;
   gridColumnApi;
   noRowsTemplate = "No cases have been promoted for paneling";

   defaultColDef = {
     filter: true,
     sortable: true,
     floatingFilter: true,
     suppressMenu: true,
   };

   rowSelection = 'single';
   showLoading = false;


  columnDefs = [
    {
      headerName: 'Case #',
      field: 'relatedProceedingNo',
      // width: 130,
      // maxWidth: 130,
      resizable: true,
      cellRendererFramework: OpenCaseviewerComponent,
      tooltipField: 'Case #'
    },
    {
       headerName: 'Petitioner',
      field: 'petitionerRealParty',
      //  minWidth: 200,
       resizable: true,
       wrapText: false,
       autoHeight: false
     },
     {
       headerName: 'Petition filed date',
       field: PtabTrialConstants.KEY_DATES.FILING_DATE.KEY,
       resizable: true,
       comparator: this.gridHelper.dateComparator,
       headerCheckboxSelection: false,
       tooltipField: 'Petition filed date',
       type: 'timestamp'
     },
     {
      headerName: 'Joined date',
      field: 'joinedDate',
      // width: 190,
      // minWidth: 190,
      resizable: true,
      comparator: this.gridHelper.dateComparator,
      headerCheckboxSelection: false,
      tooltipField: 'Joined date',
      type: 'date'
    },
     {
       headerName: 'Case status',
       field: 'descriptionText',
      //  width: 150,
      //  minWidth: 150,
       resizable: true
     }
   ];

  rowData: Array<any> = [];

  joinedCases: any = null;
  orderByField: any[] = [];
  lastRefresh = new Date();

  constructor(private gridHelper: GridHelperService, private trialsService: TrialsService, private commonUtils: CommonUtilitiesService) { }

  ngOnInit(): void {
    this.orderByField = [];
    this.getJoinedCaseDetails();
    // setInterval(()=>{
    //   this.refresh();
    // },300000)
  }

  refresh(){
    this.getJoinedCaseDetails();
    this.lastRefresh = new Date();
  }


  getJoinedCaseDetails() {

    this.trialsService.getJoinedCaseDetails(this.caseInfo.proceedingNo).subscribe((joinedCasesDetails) => {
      joinedCasesDetails.forEach((element) => {
        element[PtabTrialConstants.KEY_DATES.FILING_DATE.KEY] = this.commonUtils.parseKeyDatesTemp(element.milestoneDate, PtabTrialConstants.KEY_DATES.FILING_DATE.DESC, PtabTrialConstants.DATE_TYPE.DATE);
      });
      this.rowData = joinedCasesDetails;
      this.setTableData(joinedCasesDetails);
      this.sortColumns("beginEffectiveDate", "p");
    })
  }



  setTableData(joinedCasesDetails) {
    this.joinedCases = {
      tableId: "joinedCasesTable",
      tableHeaderClass: "joinedCasesTableHeader",
      tableBodyClass: "joinedCasesTableBody",
      checkboxClass: "joinedCasesTableCheckbox",
      headerCheckboxId: "joinedCasesTableHeaderCheckbox",
    cellCheckboxId: "joinedCasesCheckbox",
      columnDefs: [
        {
          name: "Case #",
          displayName: "Case #",
          field: "relatedProceedingNo",
          width: '4%',
          type: "string",
          link: true,
          searchText: null
        },
        {
          name: "Petitioner",
          displayName: "Petitioner",
          field: "petitionerRealParty",
          width: '20%',
          type: "string",
          searchText: null
        },
        {
          name: "Petition filed date",
          displayName: "Petition filed date",
          field: PtabTrialConstants.KEY_DATES.FILING_DATE.KEY,
          width: '5%',
          type: "date",
          searchText: null
        },
        {
          name: "Joined date",
          displayName: "Joined date",
          field: "beginEffectiveDate",
          width: '2%',
          type: "date",
          searchText: ""
        },
        {
          name: "Case status",
          displayName: "Case status",
          field: "descriptionText",
          width: '8%',
          type: "string",
          searchText: ""
        }
      ],
      data: JSON.parse(JSON.stringify(joinedCasesDetails))
    };
  }



  sortColumns(field, sortType) {
      !this.orderByField.includes(field) ? this.correctOrder(field, sortType) : this.correctOrder('-' + field, sortType);
      this.orderByField = !this.orderByField.includes(field) ? [field] : ['-' + field];
  }

  correctOrder(field, sortType) {
    let tempData;
      tempData = [...this.joinedCases.data];
      this.joinedCases.data = [];
      let order = field.charAt(0) === '-' ? "desc" : "asc"
      tempData.sort(this.compareValues(field, order, sortType));
      this.joinedCases.data = [...tempData];
  }


  compareValues(key, order = 'asc', sortType) {
    if (key.charAt(0) === '-') {
      key = key.substring(1);
    }

    return function innerSort(a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        // property doesn't exist on either object
        return 0;
      }

      // const varA = (typeof a[key] === 'string') ? a[key].toUpperCase() : a[key];
      // const varB = (typeof b[key] === 'string') ? b[key].toUpperCase() : b[key];
      const varA = new Date(new Date(a[key]).toDateString()).getTime();
      const varB = new Date(new Date(b[key]).toDateString()).getTime();


        let comparison = 0;
        if (varA > varB) {
          comparison = 1;
        } else if (varA < varB) {
          comparison = -1;
        } else {
          // let numberA = sortType === 'p' ? a.docNo : a.exhibitNumber;
          // let numberB = sortType === 'p' ? b.docNo : b.exhibitNumber;
          let numberA = a.relatedProceedingNo;
          let numberB = b.relatedProceedingNo;

        if (numberA > numberB) {
          comparison = 1;
        } else if (numberA < numberB) {
          comparison = -1;
        } else {
          return 0;
        }
        }
        return (
          (order === 'desc') ? (comparison * -1) : comparison
        );
    };
  }



  // onGridReady(params) {
  //   this.gridApi = params.api;
  //   this.gridColumnApi = params.columnApi;
  //   this.gridApi.sizeColumnsToFit();
  // }


  // onRowSelected() {
  //   // this.selectedCaseToPanel = this.gridApi.getSelectedRows();

  // }

  // onFilterChanged() {
  //   console.log("On filter changed: ", this.gridApi.getDisplayedRowCount());
  //   const filterModel = this.gridApi.getFilterModel();
  //   // this.numberOfFilters = Object.keys(filterModel).length;
  // }



  // isFirstColumn(params) {
  //   const displayedColumns = params.columnApi.getAllDisplayedColumns();
  //   const thisIsFirstColumn = displayedColumns[0] === params.column;
  //   return thisIsFirstColumn;
  // }



  // clearGridFilters() {
  //   this.gridApi.setFilterModel(null);
  // }


  // exportDataAsCsv() {
  //   const fileName = `AIA Trials Pending Paneling`;
  //   // this.gridHelper.exportDataAsCsv(this.gridApi, fileName);
  // }

}
