import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DatePipe } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TrialsService } from 'src/app/services/trials.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { CommonService } from 'src/app/services/common.service';
import { ToastrService } from 'ngx-toastr';

import { JoinedCasesComponent } from './joined-cases.component';
import { of } from 'rxjs';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';


/** 87.23% */
describe('JoinedCasesComponent', () => {
  let component: JoinedCasesComponent;
  let trialsService: TrialsService;
  let commonService: CommonService;
  let modalService: BsModalService;
  let fixture: ComponentFixture<JoinedCasesComponent>;

  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => {},
    error: (
      message?: string,
      title?: string
    ) => {},
  };

  const joinedCases = {
    tableId: "joinedCasesTable",
    tableHeaderClass: "joinedCasesTableHeader",
    tableBodyClass: "joinedCasesTableBody",
    checkboxClass: "joinedCasesTableCheckbox",
    headerCheckboxId: "joinedCasesTableHeaderCheckbox",
  cellCheckboxId: "joinedCasesCheckbox",
    columnDefs: [
      {
        name: "Case #",
        displayName: "Case #",
        field: "relatedProceedingNo",
        width: '4%',
        type: "string",
        link: true,
        searchText: null
      },
      {
        name: "Petitioner",
        displayName: "Petitioner",
        field: "petitionerRealParty",
        width: '20%',
        type: "string",
        searchText: null
      },
      {
        name: "Petition filed date",
        displayName: "Petition filed date",
        field: PtabTrialConstants.KEY_DATES.FILING_DATE.KEY,
        width: '5%',
        type: "date",
        searchText: null
      },
      {
        name: "Joined date",
        displayName: "Joined date",
        field: "beginEffectiveDate",
        width: '2%',
        type: "date",
        searchText: ""
      },
      {
        name: "Case status",
        displayName: "Case status",
        field: "descriptionText",
        width: '8%',
        type: "string",
        searchText: ""
      }
    ],
    data: []
  };

  const joinedCaseDetailsResponseMock = [{ "proceedingNo": "IPR2021-00297", "relatedProceedingNo": "IPR2020-00905", "poRealParty": "Corephotonics, Ltd.", "petitionerRealParty": "Apple Inc.", "descriptionText": "Terminated-Settled", "milestoneDate": "[{\"mileStoneDate\":\"Aug 12, 2021, 12:00:00 AM\",\"mileStoneTypeName\":\"Hearing Date\",\"mileStoneDescription\":\"Proceeding Institution Decision Hearing Date\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"Nov 12, 2020, 11:26:02 AM\",\"lastModifiedUserIdentifier\":\"29\",\"createUserIdentifier\":\"29\",\"createTimestamp\":\"Nov 12, 2020, 11:26:02 AM\"}},{\"mileStoneDate\":\"Jul 19, 2021, 12:00:00 AM\",\"mileStoneTypeName\":\"Notice of Appeal due date\",\"mileStoneDescription\":\"Notice of Appeal due date\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"May 17, 2021, 4:08:59 PM\",\"lastModifiedUserIdentifier\":\"3572\",\"createUserIdentifier\":\"3572\",\"createTimestamp\":\"May 17, 2021, 4:08:59 PM\"}},{\"mileStoneDate\":\"Jun 16, 2021, 12:00:00 AM\",\"mileStoneTypeName\":\"Rehearing request due date\",\"mileStoneDescription\":\"Rehearing request due date\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"May 17, 2021, 4:08:59 PM\",\"lastModifiedUserIdentifier\":\"3572\",\"createUserIdentifier\":\"3572\",\"createTimestamp\":\"May 17, 2021, 11:55:17 AM\"}},{\"mileStoneDate\":\"May 17, 2021, 12:00:00 AM\",\"mileStoneTypeName\":\"Termination Decision\",\"mileStoneDescription\":\"Termination decision or final decision date\",\"decisionOutcomeDetails\":{\"outcomeType\":\"SETLAINST\",\"descriptionText\":\"Settled After Institution\"},\"audit\":{\"lastModifiedTimestamp\":\"May 17, 2021, 4:09:48 PM\",\"lastModifiedUserIdentifier\":\"3572\",\"createUserIdentifier\":\"3572\",\"createTimestamp\":\"May 17, 2021, 11:55:17 AM\"}},{\"mileStoneDate\":\"Nov 13, 2020, 12:00:00 AM\",\"mileStoneTypeName\":\"Decision to Institute Due Date\",\"mileStoneDescription\":\"Institution decision due date\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"Aug 13, 2020, 7:11:42 PM\",\"lastModifiedUserIdentifier\":\"10637\",\"createUserIdentifier\":\"5046\",\"createTimestamp\":\"May 13, 2020, 11:36:33 AM\"}},{\"mileStoneDate\":\"Aug 13, 2020, 12:00:00 AM\",\"mileStoneTypeName\":\"Preliminary Response\",\"mileStoneDescription\":\"PO preliminary response filing or waiver date\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"Aug 13, 2020, 7:11:40 PM\",\"lastModifiedUserIdentifier\":\"10637\",\"createUserIdentifier\":\"10637\",\"createTimestamp\":\"Aug 13, 2020, 6:56:57 PM\"}},{\"mileStoneDate\":\"Aug 13, 2020, 12:00:00 AM\",\"mileStoneTypeName\":\"Preliminary Response Due Date\",\"mileStoneDescription\":\"PO preliminary response due date\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"May 13, 2020, 11:36:33 AM\",\"lastModifiedUserIdentifier\":\"5046\",\"createUserIdentifier\":\"5046\",\"createTimestamp\":\"May 13, 2020, 11:36:33 AM\"}},{\"mileStoneDate\":\"May 13, 2020, 12:00:00 AM\",\"mileStoneTypeName\":\"Notice of Accorded Filing Date\",\"mileStoneDescription\":\"Notice of accorded filing date (NOFDA)\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"May 13, 2020, 11:36:33 AM\",\"lastModifiedUserIdentifier\":\"5046\",\"createUserIdentifier\":\"5046\",\"createTimestamp\":\"May 13, 2020, 11:36:33 AM\"}},{\"mileStoneDate\":\"May 6, 2020, 12:00:00 AM\",\"mileStoneTypeName\":\"Filing Date\",\"mileStoneDescription\":\"Filing date\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"May 6, 2020, 4:34:04 PM\",\"lastModifiedUserIdentifier\":\"15796\",\"createUserIdentifier\":\"15796\",\"createTimestamp\":\"May 6, 2020, 4:34:04 PM\"}},{\"mileStoneDate\":\"May 5, 2020, 12:00:00 AM\",\"mileStoneTypeName\":\"Accorded Filing Date\",\"mileStoneDescription\":\"Accorded filing date\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"May 13, 2020, 11:36:33 AM\",\"lastModifiedUserIdentifier\":\"5046\",\"createUserIdentifier\":\"5046\",\"createTimestamp\":\"May 13, 2020, 11:36:33 AM\"}}]", "beginEffectiveDate": 1620266104000 }, { "proceedingNo": "IPR2021-00297", "relatedProceedingNo": "IPR2020-00905", "poRealParty": "Corephotonics, Ltd.", "petitionerRealParty": "Apple Inc.", "descriptionText": "Terminated-Settled", "milestoneDate": "[{\"mileStoneDate\":\"Aug 12, 2021, 12:00:00 AM\",\"mileStoneTypeName\":\"Hearing Date\",\"mileStoneDescription\":\"Proceeding Institution Decision Hearing Date\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"Nov 12, 2020, 11:26:02 AM\",\"lastModifiedUserIdentifier\":\"29\",\"createUserIdentifier\":\"29\",\"createTimestamp\":\"Nov 12, 2020, 11:26:02 AM\"}},{\"mileStoneDate\":\"Jul 19, 2021, 12:00:00 AM\",\"mileStoneTypeName\":\"Notice of Appeal due date\",\"mileStoneDescription\":\"Notice of Appeal due date\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"May 17, 2021, 4:08:59 PM\",\"lastModifiedUserIdentifier\":\"3572\",\"createUserIdentifier\":\"3572\",\"createTimestamp\":\"May 17, 2021, 4:08:59 PM\"}},{\"mileStoneDate\":\"Jun 16, 2021, 12:00:00 AM\",\"mileStoneTypeName\":\"Rehearing request due date\",\"mileStoneDescription\":\"Rehearing request due date\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"May 17, 2021, 4:08:59 PM\",\"lastModifiedUserIdentifier\":\"3572\",\"createUserIdentifier\":\"3572\",\"createTimestamp\":\"May 17, 2021, 11:55:17 AM\"}},{\"mileStoneDate\":\"May 17, 2021, 12:00:00 AM\",\"mileStoneTypeName\":\"Termination Decision\",\"mileStoneDescription\":\"Termination decision or final decision date\",\"decisionOutcomeDetails\":{\"outcomeType\":\"SETLAINST\",\"descriptionText\":\"Settled After Institution\"},\"audit\":{\"lastModifiedTimestamp\":\"May 17, 2021, 4:09:48 PM\",\"lastModifiedUserIdentifier\":\"3572\",\"createUserIdentifier\":\"3572\",\"createTimestamp\":\"May 17, 2021, 11:55:17 AM\"}},{\"mileStoneDate\":\"Nov 13, 2020, 12:00:00 AM\",\"mileStoneTypeName\":\"Decision to Institute Due Date\",\"mileStoneDescription\":\"Institution decision due date\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"Aug 13, 2020, 7:11:42 PM\",\"lastModifiedUserIdentifier\":\"10637\",\"createUserIdentifier\":\"5046\",\"createTimestamp\":\"May 13, 2020, 11:36:33 AM\"}},{\"mileStoneDate\":\"Aug 13, 2020, 12:00:00 AM\",\"mileStoneTypeName\":\"Preliminary Response\",\"mileStoneDescription\":\"PO preliminary response filing or waiver date\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"Aug 13, 2020, 7:11:40 PM\",\"lastModifiedUserIdentifier\":\"10637\",\"createUserIdentifier\":\"10637\",\"createTimestamp\":\"Aug 13, 2020, 6:56:57 PM\"}},{\"mileStoneDate\":\"Aug 13, 2020, 12:00:00 AM\",\"mileStoneTypeName\":\"Preliminary Response Due Date\",\"mileStoneDescription\":\"PO preliminary response due date\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"May 13, 2020, 11:36:33 AM\",\"lastModifiedUserIdentifier\":\"5046\",\"createUserIdentifier\":\"5046\",\"createTimestamp\":\"May 13, 2020, 11:36:33 AM\"}},{\"mileStoneDate\":\"May 13, 2020, 12:00:00 AM\",\"mileStoneTypeName\":\"Notice of Accorded Filing Date\",\"mileStoneDescription\":\"Notice of accorded filing date (NOFDA)\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"May 13, 2020, 11:36:33 AM\",\"lastModifiedUserIdentifier\":\"5046\",\"createUserIdentifier\":\"5046\",\"createTimestamp\":\"May 13, 2020, 11:36:33 AM\"}},{\"mileStoneDate\":\"May 6, 2020, 12:00:00 AM\",\"mileStoneTypeName\":\"Filing Date\",\"mileStoneDescription\":\"Filing date\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"May 6, 2020, 4:34:04 PM\",\"lastModifiedUserIdentifier\":\"15796\",\"createUserIdentifier\":\"15796\",\"createTimestamp\":\"May 6, 2020, 4:34:04 PM\"}},{\"mileStoneDate\":\"May 5, 2020, 12:00:00 AM\",\"mileStoneTypeName\":\"Accorded Filing Date\",\"mileStoneDescription\":\"Accorded filing date\",\"decisionOutcomeDetails\":{},\"audit\":{\"lastModifiedTimestamp\":\"May 13, 2020, 11:36:33 AM\",\"lastModifiedUserIdentifier\":\"5046\",\"createUserIdentifier\":\"5046\",\"createTimestamp\":\"May 13, 2020, 11:36:33 AM\"}}]", "beginEffectiveDate": 1620266104000 }];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [JoinedCasesComponent],
      providers: [DatePipe, TrialsService, CommonService, BsModalService,
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useValue: {}
        },
        {
          provide: ToastrService,
          useValue: toastrService
        }]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JoinedCasesComponent);
    trialsService = TestBed.inject(TrialsService);
    commonService = TestBed.inject(CommonService);
    modalService = TestBed.inject(BsModalService);
    component = fixture.componentInstance;
    component.caseInfo =  {
      serialNo: '14178064',
      proceedingNo: 'DER2018-00328'
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should get joined case details', () => {
    spyOn(trialsService, 'getJoinedCaseDetails').and.returnValue(of(joinedCaseDetailsResponseMock));
    component.getJoinedCaseDetails();
    expect(component.rowData).toEqual(joinedCaseDetailsResponseMock);
  });



  it('should sort columns ascending', () => {
    component.orderByField = ['relatedProceedingNo'];
    component.joinedCases = joinedCases;
    component.joinedCases.data = joinedCaseDetailsResponseMock;
    component.sortColumns('relatedProceedingNo', 'e');
  });


  it('should sort columns descending', () => {
    component.orderByField = ['-relatedProceedingNo'];
    component.joinedCases = joinedCases;
    component.joinedCases.data = joinedCaseDetailsResponseMock;
    component.sortColumns('relatedProceedingNo', 'e');
  });


});
