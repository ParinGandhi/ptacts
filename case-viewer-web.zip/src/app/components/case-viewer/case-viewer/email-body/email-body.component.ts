import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { JpViewService } from 'src/app/services/jpview.service';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import { EmailSubjectComponent } from '../email-subject/email-subject.component';

@Component({
  selector: 'app-email-body',
  templateUrl: './email-body.component.html',
  styleUrls: ['./email-body.component.less']
})
export class EmailBodyComponent {
  params: any;
  subject: any;
  modalRef: BsModalRef;
  modal: any;

  constructor(
    private store: Store<CaseViewerState>,
    private jpViewService: JpViewService,
    private commonUtils: CommonUtilitiesService,
    private modalService: BsModalService,
  ) { }
 
/*istanbul ignore next*/
  agInit(params) {
    this.params = params.data;
    this.subject = params.value;
  }

/*istanbul ignore next*/
  openEmailSubject() {
    const initialState = {
      modal: {
        isConfirm: false
      },
      emailContent: this.params
    };
    this.modalRef = this.modalService.show(EmailSubjectComponent, {
      animated: true,
      backdrop: true,
      ignoreBackdropClick: true,
      class: 'add-doc-modal-content',
      initialState
    });
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        
      }
    })
  }

}
