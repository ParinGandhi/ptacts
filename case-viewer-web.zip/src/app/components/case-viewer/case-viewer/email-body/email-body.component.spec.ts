import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Store } from '@ngrx/store';
import { BsModalService } from 'ngx-bootstrap/modal';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { JpViewService } from 'src/app/services/jpview.service';
import { EmailBodyComponent } from './email-body.component';

describe('EmailBodyComponent', () => {
  let component: EmailBodyComponent;
  let fixture: ComponentFixture<EmailBodyComponent>;

  beforeEach(() => {
    const storeStub = () => ({});
    const bsModalServiceStub = () => ({
      show: (emailSubjectComponent, object) => ({})
    });
    const commonUtilitiesServiceStub = () => ({});
    const jpViewServiceStub = () => ({});
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [EmailBodyComponent],
      providers: [
        { provide: Store, useFactory: storeStub },
        { provide: BsModalService, useFactory: bsModalServiceStub },
        {
          provide: CommonUtilitiesService,
          useFactory: commonUtilitiesServiceStub
        },
        { provide: JpViewService, useFactory: jpViewServiceStub }
      ]
    });
    fixture = TestBed.createComponent(EmailBodyComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  
});
