import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { provideMockStore } from '@ngrx/store/testing';
import { RouterTestingModule } from "@angular/router/testing";
import { Router } from "@angular/router";
import { CounselComponent } from '../counsel/counsel.component';
import { Injectable, ViewChild } from '@angular/core';
import { RealPartyComponent } from '../real-party/real-party.component';
import { DocumentsComponent } from '../documents-claims/documents/documents.component';
import { Store, select } from '@ngrx/store';
import * as CaseViewerSelectors  from 'src/app/store/case-viewer/case-viewer.selectors';
import { routes } from "src/app/app-routing.module";
import { CaseViewerComponent } from './case-viewer.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DatePipe } from '@angular/common';
import { JpViewService } from 'src/app/services/jpview.service';
import { of } from 'rxjs';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { MotionRehearingComponent } from './motion-rehearing/motion-rehearing.component';

const toastrService = {
  success: (
    message?: string,
    title?: string
  ) => {},
  error: (
    message?: string,
    title?: string
  ) => {},
};

const activatedRouteMock = {
  snapshot: {
    params: {
      serialNo: "123456789",
      proceedingNo: "DER2020-123456"
    },
    url:[
      {
        path: "case-viewer"
      }
    ]
  }
}

const caseHeaderRes = {"patentNumberText":"7779983","proceedingNumber":"IPR2021-00531","derproceedingTypeDetails":null,"techCenterNum":"3600","ptabReadOnlyUser":true,"mileStoneDates":null,"parties":"FireKing Security Products, LLC et al.","attorneys":[],"artUnit":"3653","casePhase":"Not Instituted","inventionTitle":"TWO DOOR ELECTRONIC SAFE","keyDates":["04/05/2021-Rehearing Requests Due"]};


/**
 * 89.55%
 */
describe('CaseViewerComponent', () => {
  let component: CaseViewerComponent;
  let router: Router;
  let fixture: ComponentFixture<CaseViewerComponent>;
  let jpViewService: JpViewService;
  let modalService: BsModalService;
  let commonUtils: CommonUtilitiesService;
  const documentsComponent = jasmine.createSpyObj('DocumentsComponent', ['getDocuments','getNextPaperNumber', 'ngOnInit']);
  const counselComponent = jasmine.createSpyObj('CounselComponent', ['getCounselInfo']);
  const realPartyComponent = jasmine.createSpyObj('RealPartyComponent', ['getRealPartyInfo']);
  const rehearingInstance = jasmine.createSpyObj('MotionRehearingComponent',['ngOnInit']);
  const notRehearingInstance = jasmine.createSpyObj('MotionRehearingComponent',['ngOnInit']);
  const mandatoryNoticeComponent = jasmine.createSpyObj('MandatoryNoticeComponent', ['ngOnInit']);
  const caseMilestoneComponent = jasmine.createSpyObj('CaseMilestoneComponent',['ngOnInit']);
  const notificationsComponent = jasmine.createSpyObj('NotificationsComponent',['ngOnInit']);
  @Injectable()
  class StubbedModalService {
    public show(): void { }
  }
  let reason = {
    initialState: {
      modal: {
        isConfirm: true
      }
    }
  }
  class modalServiceMock {

    show = () => { return { onHide: () => { return of(reason) } } }
    hide = () => { return {} }
    onHide = () => {return of(reason) }
}

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule,RouterTestingModule.withRoutes([{path:"case-viewer/14178064/37553565/1",component:CaseViewerComponent}])],
      declarations: [ CaseViewerComponent,CounselComponent,RealPartyComponent,DocumentsComponent ],
      providers: [ provideMockStore({
        selectors: [
          { selector: CaseViewerSelectors.caseInfoData, value: { proceedingNo: '37553565' } },
          {selector: CaseViewerSelectors.userInfoData,value:{caseDetailsData: []}}
        ]
      }),
      BsModalService,
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        },
        {
          provide:DatePipe,
          useValue:{}
        },
        {
          provide: BsModalService,
          useClass: modalServiceMock
        },
        {
          provide: ToastrService,
          useValue: toastrService
        },
       ]
    })
    .compileComponents();
  });
  beforeEach(() => {
    fixture = TestBed.createComponent(CaseViewerComponent);
    jpViewService = TestBed.inject(JpViewService);
    component = fixture.componentInstance;
    commonUtils = TestBed.inject(CommonUtilitiesService);
    modalService = TestBed.inject(BsModalService);
    component.loggedInUser ={ loginId: "akellogg",privileges: "PanelMember"};
    component.caseInfo =  {
      serialNo: '14178064',
      proceedingNo: 'DER2018-00328'
    };
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });




  it('should call ChildComponents', () => {
    component['documentChildComponent'] = documentsComponent;
    component['realPartyChildComponent'] = realPartyComponent;
    component['counselChildComponent'] = counselComponent;
    component.callChildComponents('aiaReviewInformation');
    expect(documentsComponent.getDocuments).toBeDefined();
  });



  it('should call ChildComponents for rehearings', () => {
    component['rehearingInstance'] = rehearingInstance;
    component['notRehearingInstance'] = notRehearingInstance;
    component.callChildComponents('motionsRehearings');
    expect(notRehearingInstance.ngOnInit).toBeDefined();
  });


  it('should call ChildComponents mandatoryNotices', () => {
    component['mandatoryComponent'] = mandatoryNoticeComponent;
    component.callChildComponents('mandatoryNotices');
    expect(mandatoryNoticeComponent.ngOnInit).toBeDefined();
  });



  it('should call ChildComponents caseMilestones', () => {
    component['caseMilestoneComponent'] = caseMilestoneComponent;
    component.callChildComponents('caseMilestones');
    expect(caseMilestoneComponent.ngOnInit).toBeDefined();
  });


  it('should call ChildComponents caseHistory', () => {
    component['notificationsComponent'] = notificationsComponent;
    component.callChildComponents('caseHistory');
    expect(notificationsComponent.ngOnInit).toBeDefined();
  });


  it('should call setRedirect', () => {
    component['documentChildComponent'] = documentsComponent;
    component['realPartyChildComponent'] = realPartyComponent;
    component['counselChildComponent'] = counselComponent;
    component.caseInfo.serialNo="14178064";
    component.caseInfo.proceedingNo="37553565";
    spyOn(component.router,'navigate').and.returnValue(new Promise((resolve, reject) => { resolve(true); }));
    component.setRedirect(1,2);
    expect(component.router.navigate).toHaveBeenCalled();
  });

  it('should call expandAll', () => {
    let status ="expand";
    var dummyElement = document.createElement('paymentsLink');
    document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(dummyElement);
    component.expandCollapseAll(status);
    expect(document.getElementById).toHaveBeenCalled();
  });

  it('should call CollapseAll', () => {
    let status ="collapse";
    var dummyElement = document.createElement('paymentsLink');
    document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(dummyElement);
    component.expandCollapseAll(status);
    expect(document.getElementById).toHaveBeenCalled();
  });

  it('should call AfterView', () => {
    component.caseInfo.scrollToId ="mandatoryNotice";
    var dummyElement = document.createElement('mandatoryNoticesTab');
    document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(dummyElement);
    component.ngAfterViewInit();
    expect(component.ngAfterViewInit).toBeTruthy();
  });

  it('should call AfterView', () => {
    component.caseInfo.scrollToId ="motionsRehearing";
    var dummyElement = document.createElement('motionsRehearingTab');
    document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(dummyElement);
    component.ngAfterViewInit();
    expect(component.ngAfterViewInit).toBeTruthy();
  });

  it('should call updateHeaderEvent', () => {
    let event = new Event('click');
    component.updateHeaderEvent(event);
    expect(component.parties).not.toBeNull();
  });

  it('should call updateUnsavedEvent', () => {
    let event = new Event('click');
    component.updateUnsavedEvent(event);
    expect(component.unsavedChanges).not.toBeNull();
  });
});
