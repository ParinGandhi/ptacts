import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { ToastrService } from 'ngx-toastr';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { TrialsService } from 'src/app/services/trials.service';
import { FormsModule } from '@angular/forms';
import { AuditHistoryComponent } from './audit-history.component';

fdescribe('AuditHistoryComponent', () => {
  let component: AuditHistoryComponent;
  let fixture: ComponentFixture<AuditHistoryComponent>;

  beforeEach(() => {
    const activatedRouteStub = () => ({ snapshot: { params: {} } });
    const storeStub = () => ({});
    const toastrServiceStub = () => ({});
    const gridHelperServiceStub = () => ({
      convertDateToTimeStamp: createTs => ({}),
      exportDataAsCsv: (gridApi, fileName) => ({})
    });
    const trialsServiceStub = () => ({
      getAuditList: arg => ({ subscribe: f => f({}) })
    });
    TestBed.configureTestingModule({
      imports: [FormsModule],
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [AuditHistoryComponent],
      providers: [
        { provide: ActivatedRoute, useFactory: activatedRouteStub },
        { provide: Store, useFactory: storeStub },
        { provide: ToastrService, useFactory: toastrServiceStub },
        { provide: GridHelperService, useFactory: gridHelperServiceStub },
        { provide: TrialsService, useFactory: trialsServiceStub }
      ]
    });
    fixture = TestBed.createComponent(AuditHistoryComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`recipientList has default value`, () => {
    expect(component.recipientList).toEqual([]);
  });

  it(`tooltipList has default value`, () => {
    expect(component.tooltipList).toEqual([]);
  });

  it(`filterOn has default value`, () => {
    expect(component.filterOn).toEqual(false);
  });

  it(`numberOfFilters has default value`, () => {
    expect(component.numberOfFilters).toEqual(0);
  });

  it(`noRowsTemplate has default value`, () => {
    expect(component.noRowsTemplate).toEqual(`No notifications found`);
  });

  it(`columnDefs has default value`, () => {
    expect(component.columnDefs).toEqual([, , ,]);
  });

  it(`showLoading has default value`, () => {
    expect(component.showLoading).toEqual(true);
  });

  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      spyOn(component, 'getAudit').and.callThrough();
      component.ngOnInit();
      expect(component.getAudit).toHaveBeenCalled();
    });
  });

  describe('getAudit', () => {
    it('makes expected calls', () => {
      const gridHelperServiceStub: GridHelperService = fixture.debugElement.injector.get(
        GridHelperService
      );
      const trialsServiceStub: TrialsService = fixture.debugElement.injector.get(
        TrialsService
      );
      spyOn(component, 'setPaginationDetails').and.callThrough();
      spyOn(component, 'setPageSize').and.callThrough();
      spyOn(gridHelperServiceStub, 'convertDateToTimeStamp').and.callThrough();
      spyOn(trialsServiceStub, 'getAuditList').and.callThrough();
      component.getAudit();
      expect(component.setPaginationDetails).toHaveBeenCalled();
      expect(component.setPageSize).toHaveBeenCalled();
      expect(gridHelperServiceStub.convertDateToTimeStamp).toHaveBeenCalled();
      expect(trialsServiceStub.getAuditList).toHaveBeenCalled();
    });
  });

  describe('setPageSize', () => {
    it('makes expected calls', () => {
      spyOn(component, 'setPaginationDetails').and.callThrough();
      component.setPageSize();
      expect(component.setPaginationDetails).toHaveBeenCalled();
    });
  });

  describe('exportDataAsCsv', () => {
    it('makes expected calls', () => {
      const gridHelperServiceStub: GridHelperService = fixture.debugElement.injector.get(
        GridHelperService
      );
      spyOn(gridHelperServiceStub, 'exportDataAsCsv').and.callThrough();
      component.exportDataAsCsv();
      expect(gridHelperServiceStub.exportDataAsCsv).toHaveBeenCalled();
    });
  });
});
