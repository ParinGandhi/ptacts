import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from 'src/app/services/common.service';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import { GridPagination } from 'src/app/models/grid/GridPagination';
import { TrialsService } from 'src/app/services/trials.service';

@Component({
  selector: 'app-audit-history',
  templateUrl: './audit-history.component.html',
  styleUrls: ['./audit-history.component.less']
})

export class AuditHistoryComponent implements OnInit {

  notifications: any;
  recipientList: any[] = [];
  tooltipList: any[] = [];

  gridApi;
  gridColumnApi;
  frameworkComponents;
  finalCount: any;
  filterOn: boolean = false;
  numberOfFilters: number = 0;
  recp;
  toRecp;
  ccRecp;
  bccRecp;

  defaultColDef = {
    filter: true,
    sortable: true,
    floatingFilter: true,
    suppressMenu: true,
    allColumns: true,
    tooltipComponent: 'customTooltip',
    // headerCheckboxSelection: this.isFirstColumn,
    //   checkboxSelection: this.isFirstColumn,
  };
  noRowsTemplate = "No notifications found";

  columnDefs = [
    {
      headerName: 'Date',
      field: 'createTsStr',
      width: 200,
      minWidth: 200,
      resizable: true,
      sort: 'desc',
      comparator: this.gridHelper.dateComparator,
      type: 'date'
    }, {
      headerName: 'Action',
      field: 'changeOperationCt',
      width: 90,
      minWidth: 90,
      resizable: true,
      autoHeight: false
    },
    {
      headerName: 'Description',
      field: 'descText',
      // width: 1050,
      flex: 2,
      resizable: true
    },
     {
      headerName: 'Performed by',
      field: 'createEmailAddressTx',
      // width: 290,
      minWidth: 280,
      resizable: true
    }
  ];
  showLoading: boolean = true;
  refreshFailed: boolean;
  rowData: any;
  caseInfo: { serialNo: any; proceedingNo: any; };
  allAudits: any;
  lastRefresh = new Date();

  constructor(private store: Store<CaseViewerState>, private activatedRoute: ActivatedRoute,
    private trialsService: TrialsService, private gridHelper: GridHelperService,private toastr: ToastrService,) { }
  gridPagination: GridPagination = new GridPagination();

  ngOnInit(): void {
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };
    // this.frameworkComponents = { customTooltip: NotificationTooltipComponent };
    this.getAudit();
    this.gridPagination.pageSize = 25;
    // setInterval(()=>{
    //   this.refresh();
    // },300000)
  }

 refresh(){
    this.getAudit();
    this.lastRefresh = new Date();
  }

/*istanbul ignore next*/
  getAudit() {
    // this.trialsService.getAuditList('https://ptab-q121-trial-services-wildfly-0.sit.uspto.gov:8443/PTABTrialsServices/audit-trail?caseNumber='+this.caseInfo.proceedingNo).subscribe((auditData) => {

    this.trialsService.getAuditList('/audit-trail?caseNumber='+this.caseInfo.proceedingNo).subscribe((auditData) => {
      this.showLoading = false;
      this.refreshFailed = false;
      this.allAudits = auditData

    
      for (let i = 0; i < this.allAudits.length; i++) {
        this.allAudits[i].createTsStr = this.gridHelper.convertDateToTimeStamp(this.allAudits[i].createTs);
      
        this.allAudits[i].descText = (this.allAudits[i].changeObjectNm && this.allAudits[i].changeObjectNm == 'N/A' ? '' : this.allAudits[i].changeObjectNm ) + (this.allAudits[i].changeDescriptionTx && this.allAudits[i].changeObjectNm != 'N/A' ? " : " : '') + (this.allAudits[i].changeDescriptionTx);

      };
      this.rowData = this.allAudits
      this.gridPagination.totalItems = this.allAudits.length;
      setTimeout(() => {
      this.gridPagination.totalPages = this.gridApi.paginationGetTotalPages();
      this.gridPagination.currentPage = 1;
      this.setPaginationDetails();
      this.setPageSize();
      }, 200);
    }, (failureResponse) => {
      // this.toastr.error(failureResponse.error.message, "", {
      //   closeButton: true
      // });
       
    })

  };


  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.gridPagination.totalPages = this.gridApi.paginationGetTotalPages();
    this.gridPagination.currentPage = 1;
    this.setPaginationDetails();
    this.setPageSize();
  }
/*istanbul ignore next*/
  paginationControls(step) {
    switch (step) {
      case 'first':
        this.gridApi.paginationGoToFirstPage();
        break;
      case 'previous':
        this.gridApi.paginationGoToPreviousPage();
        break;
      case 'next':
        this.gridApi.paginationGoToNextPage();
        break;
      case 'last':
        this.gridApi.paginationGoToLastPage();
        break;
      default:
        break;
    }
    this.gridPagination.currentPage = this.gridApi.paginationGetCurrentPage() + 1;
    this.setPaginationDetails();
  };

/*istanbul ignore next*/
  goToPage(e) {
    this.gridApi.paginationGoToPage(parseInt(this.gridPagination.currentPage) - 1);
    this.setPaginationDetails();
  }

/*istanbul ignore next*/
  setPageSize() {
    this.gridApi.paginationSetPageSize(parseInt(this.gridPagination.pageSize));
    this.gridPagination.totalPages = this.gridApi.paginationGetTotalPages();
    this.setPaginationDetails();
  }

/*istanbul ignore next*/
  setPaginationDetails() {
    let tempTo = this.gridPagination.pageSize * this.gridPagination.currentPage;
    this.gridPagination.to = this.gridPagination.totalItems > tempTo ? this.gridPagination.pageSize * this.gridPagination.currentPage : this.gridPagination.totalItems;
    this.gridPagination.from = (tempTo - this.gridPagination.pageSize) + 1
  }


  onFilterChanged() {
    this.filterOn = true;
    console.log("On filter changed: ", this.gridApi.getDisplayedRowCount());
    this.finalCount = this.gridApi.getDisplayedRowCount();
    const filterModel = this.gridApi.getFilterModel();
    this.numberOfFilters = Object.keys(filterModel).length;
  }


/*istanbul ignore next*/
  isFirstColumn(params) {
    let displayedColumns = params.columnApi.getAllDisplayedColumns();
    let thisIsFirstColumn = displayedColumns[0] === params.column;
    return thisIsFirstColumn;
  }


/*istanbul ignore next*/
  clearGridFilters() {
    this.gridApi.setFilterModel(null);
  }


  exportDataAsCsv() {
    let fileName: string = this.caseInfo.proceedingNo+`_AuditHistory`;
    this.gridHelper.exportDataAsCsv(this.gridApi, fileName);
  }


}