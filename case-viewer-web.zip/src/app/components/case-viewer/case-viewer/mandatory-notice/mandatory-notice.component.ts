import { Component, OnInit, Input } from '@angular/core';
import { TrialsService } from 'src/app/services/trials.service';
import { Store, select } from '@ngrx/store';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { ToastrService } from 'ngx-toastr';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import { JpViewService } from 'src/app/services/jpview.service';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-mandatory-notice',
  templateUrl: './mandatory-notice.component.html',
  styleUrls: ['./mandatory-notice.component.less']
})
export class MandatoryNoticeComponent implements OnInit {

  @Input() caseInfo: any;

  loggedInUser$ = this.store.pipe(select(CaseViewerSelectors.userInfoData));
  mandatoryNotices: Array<any> = [];
  allNotices: Array<any> = [];
  pendingNotices: Array<any> = [];
  mandatoryNotice: any;
  showAll = true;
  counts = {
    all: 0,
    pending: 0
  };
  loggedInUser: any;
  petitionerIdentifier: any;
  orderByField: any[] = [];
  lastRefresh = new Date();

  constructor(
    private store: Store<CaseViewerState>,
    private trialsService: TrialsService,
    private jpViewService: JpViewService,
    private commonService: CommonService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {

    this.store.pipe(select(CaseViewerSelectors.userInfoData)).subscribe(data => {
      this.loggedInUser = data.caseDetailsData[0];
      if (!this.loggedInUser) {
        this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
      }
    })

    this.getPetitionIdentifier();
    this.setTable();
    this.getMandatoryNotices();
    // setInterval(()=>{
    //   this.refresh();
    // },300000)
  }

  refresh() {
    this.getMandatoryNotices();
    this.lastRefresh = new Date();
    document.getElementById('pendingMNListItem').classList.remove('active');
    document.getElementById('allMNListItem').classList.add('active');
  }
  getPetitionIdentifier() {
    // this.jpViewService.getCaseInfoByProceedingNo(`${PtabTrialConstants.COMMON_SERVICES_URL}/petitions?proceedingNumberText=${this.caseInfo.proceedingNo}`).subscribe((caseInfoByProceedingResponse) => {
    this.commonService.getCaseInfoByProceedingNo(this.caseInfo.proceedingNo).subscribe((caseInfoByProceedingResponse) => {
      this.petitionerIdentifier = caseInfoByProceedingResponse.petitionIdentifier;
    });
  }


  getMandatoryNotices() {
    this.trialsService.getMandatoryNotices(this.caseInfo.proceedingNo).subscribe((mnNotice) => {
      mnNotice.sort((a, b) => {
        return b.submittedDate - a.submittedDate;
      })
      mnNotice.forEach(mandatoryNotice => {
        if (mandatoryNotice.petitionDocuments && mandatoryNotice.petitionDocuments.length > 0) {
          mandatoryNotice.petitionDocuments.sort((a, b) => {
            const tempA = a.documentNumber ? a.documentNumber : a.exhibitNumber;
            const tempB = b.documentNumber ? b.documentNumber : b.exhibitNumber;
            return tempB - tempA;
          })
        }

        if (mandatoryNotice.proceedingParties.poCounsel && mandatoryNotice.proceedingParties.poCounsel.parties && mandatoryNotice.proceedingParties.poCounsel.parties.length > 0) {
          mandatoryNotice.proceedingParties.poCounsel.parties.sort((a, b) => {
            return a.rankNo - b.rankNo;
          });
        }
        if (mandatoryNotice.proceedingParties.poRealParty && mandatoryNotice.proceedingParties.poRealParty.parties && mandatoryNotice.proceedingParties.poRealParty.parties.length > 0) {
          mandatoryNotice.proceedingParties.poRealParty.parties.sort((a, b) => {
            return a.rankNo - b.rankNo;
          })
        }
        mandatoryNotice.counsel = mandatoryNotice.proceedingParties.poCounsel ? mandatoryNotice.proceedingParties.poCounsel.parties : [];
        mandatoryNotice.realParty = mandatoryNotice.proceedingParties.poRealParty ? mandatoryNotice.proceedingParties.poRealParty.parties : [];
      });
      this.setCounts(mnNotice)
      this.mandatoryNotices = mnNotice;
      this.allNotices = mnNotice;
      console.log('this.mandatoryNotices: ', this.mandatoryNotices);

    })
  }


  setCounts(mandatoryNotice) {
    this.pendingNotices = [];
    this.counts = {
      all: 0,
      pending: 0
    };
    this.counts.all = mandatoryNotice.length;
    mandatoryNotice.forEach(notice => {
      if (notice.mandatoryNoticeStatus.toLowerCase() === 'pending approval') {
        this.counts.pending++;
        this.pendingNotices.push(notice);
      }
    });
  }




  setTable() {
    this.mandatoryNotice = {
      tableId: "mnTable",
      tableHeaderClass: "mnTableHeader",
      tableBodyClass: "mnTableBody",
      columnDefs: [
        {
          name: "Mandatory notice submitted date",
          displayName: "Mandatory notice submitted date",
          field: "submittedDate",
          width: '250px',
          type: "string",
          searchText: null
        },
        {
          name: "Patent owner",
          displayName: "Patent owner",
          field: "patentOwner",
          width: null,
          type: "string",
          searchText: null
        },
        {
          name: "Mandatory notice submitter",
          displayName: "Mandatory notice submitter",
          field: "mandatoryNoticeSubmitter",
          width: null,
          type: "string",
          searchText: null
        },
        {
          name: "Mandatory notice status",
          displayName: "Mandatory notice status",
          field: "mandatoryNoticeStatus",
          width: '190px',
          type: "string",
          searchText: null
        },
        {
          name: "View mandatory notice",
          displayName: "View mandatory notice",
          field: "viewNotice",
          width: '175px',
          type: "string",
          searchText: null
        },
        {
          name: "Action(s)",
          displayName: "Action(s)",
          field: "action",
          width: '190px',
          type: "string",
          searchText: null
        }
      ],
      data: JSON.parse(JSON.stringify(this.mandatoryNotices))
    };
  }


  filterNotices(status) {
    if (status === 'all') {
      this.mandatoryNotices = JSON.parse(JSON.stringify(this.allNotices));
      this.showAll = true;
    } else if (status === 'pending') {
      this.mandatoryNotices = JSON.parse(JSON.stringify(this.pendingNotices));
      this.showAll = false;
    }
  }

  expandCollapseAll(val) {
    this.mandatoryNotices.forEach((notice) => {
      notice.expanded = val;
    })
  }


  openPdf(data) {
    this.commonService.openPdf(`/petitions/${this.petitionerIdentifier}/download-documents?contentManagementId=${data.contentManagementId}`);
  }


  approveOrReject(noticeToReject, action) {
    console.log('noticeToReject: ', noticeToReject);
    let partiesIdentifierList = [];
    if (noticeToReject.counsel && noticeToReject.counsel.length > 0) {
      noticeToReject.counsel.forEach(counsel => {
        const tempId = {
          "identifier": counsel.identifier
        };
        partiesIdentifierList.push(tempId);
      });
    }

    if (noticeToReject.realParty && noticeToReject.realParty.length > 0) {
      noticeToReject.realParty.forEach(realParty => {
        const tempId = {
          "identifier": realParty.identifier
        };
        partiesIdentifierList.push(tempId);
      });
    }

    const approveOrRejectObj = {
      "caseNo": this.caseInfo.proceedingNo,
      "status": action,
      "parties": partiesIdentifierList,
      "audit": {
        "lastModifiedUserIdentifier": this.loggedInUser.loginId,
        "createUserIdentifier": this.loggedInUser.loginId
      }
    };

    console.log('rejectObj: ', approveOrRejectObj);

    this.trialsService.approveOrRejectMandatoryNotice(approveOrRejectObj).subscribe((approveOrRejectResponse) => {
      console.log('approveOrRejectResponse: ', approveOrRejectResponse);
      this.toastr.success(`Mandatory notice has been ${action.toLowerCase()} and the task has been closed`, "", {
        closeButton: true
      });
      this.getMandatoryNotices();
    }, (failureResponse) => {
      console.log('failureResponse: ', failureResponse);

    })


  }


  sortColumn(field, sortType) {
      !this.orderByField.includes(field) ? this.correctOrder(field, sortType) : this.correctOrder('-' + field, sortType);
      this.orderByField = !this.orderByField.includes(field) ? [field] : ['-' + field];
  }

  correctOrder(field, sortType) {
    let tempData;
      tempData = [...this.mandatoryNotices];
      this.mandatoryNotices = [];
      let order = field.charAt(0) === '-' ? "desc" : "asc"
      tempData.sort(this.compareValues(field, order, sortType));
      this.mandatoryNotices = [...tempData];
  }


  compareValues(key, order = 'asc', sortType) {
    if (key.charAt(0) === '-') {
      key = key.substring(1);
    }

    return function innerSort(a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        return 0;
      }

      const varA = (typeof a[key] === 'string')
        ? a[key].toUpperCase() : a[key];
      const varB = (typeof b[key] === 'string')
        ? b[key].toUpperCase() : b[key];

        let comparison = 0;
        if (varA > varB) {
          comparison = 1;
        }
        return (
          (order === 'desc') ? (comparison * -1) : comparison
        );

    };
  }

}
