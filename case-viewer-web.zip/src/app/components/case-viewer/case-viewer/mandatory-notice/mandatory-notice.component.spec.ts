import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { ToastrService } from 'ngx-toastr';
import { JpViewService } from 'src/app/services/jpview.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';

import { MandatoryNoticeComponent } from './mandatory-notice.component';
import { FilterPipe } from 'src/app/utilities/table-filter-pipe';
import { DatePipe } from '@angular/common';
import { CommonService } from 'src/app/services/common.service';
import { of } from 'rxjs';
import { TrialsService } from 'src/app/services/trials.service';

describe('MandatoryNoticeComponent', () => {
  let component: MandatoryNoticeComponent;
  let jpViewService: JpViewService;
  let trialsService: TrialsService;
  let commonService: CommonService;
  let fixture: ComponentFixture<MandatoryNoticeComponent>;

  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => {},
    error: (
      message?: string,
      title?: string
    ) => {},
  };

  const caseInfoByProceedingResponse = {
    petitionIdentifier: "12345"
  }

  let caseInfoMock = {
    serialNo: "12345678",
    proceedingNo: "12345678"
  }

  const petitionNumberMock = { "petitionIdentifier": 1460057, "patentNumber": "7713698", "proceedingNumberText": "IPR2012-00006", "audit": { "lastModifiedDateTime": "1467840692", "createDateTime": "1347817942" }, "patentOwner": "The Trustees of Columbia University in the City of New York", "fiscalYear": 2012, "patentClaimQt": 12 };

  const mandatoryResponseMock = [{ "submittedDate": "1610491105", "petitioner": "Cisco Systems, Inc.", "patentOwner": "Estech Systems, Inc.", "mandatoryNoticeStatus": "Approved", "patentNumber": "6067349", "partyGroupId": 3532662, "partyGroupType": "PATENTOWNER", "petitionDocuments": [{ "documentNumber": 3, "name": "Mandatory Notice", "category": "PAPER", "fileName": "2021.01.12 Mandatory Notice IPR2021-00332.pdf", "filingParty": "PATENT OWNER", "availability": "Public", "documentTypeIdentifier": 37, "documentTypeCode": "MN", "documentTypeDescription": "Mandatory Notice", "pageCount": 7, "contentManagementId": "workspace://SpacesStore/38374bca-8f3f-400b-8079-24778b68bf6c;1.0", "artifactIdentifer": 170065259, "artifactSubmissionIdentifier": 85407908, "filingDate": 1610491702, "filingDateString": "01/12/2021", "fileSize": 0, "documentStatus": "PENDING", "directionCode": "INCOMING", "warningMessageList": [], "availablitySummary": { "code": "PUBLIC", "descriptionText": "Available for everyone.", "displayNameText": "Public" }, "roleSummary": { "code": "PATENT OWNER", "descriptionText": "Indicates artifact was submitted on behalf of Patent Owner.", "displayNameText": "Patent owner" }, "artifactSummary": { "code": "PAPER", "descriptionText": "Paper" } }, { "documentNumber": 4, "name": "Power of Attorney", "category": "PAPER", "fileName": "2021.01.12 Power of Attorney IPR2021-00332.pdf", "filingParty": "PATENT OWNER", "availability": "Public", "documentTypeIdentifier": 17, "documentTypeCode": "PWR ATTY", "documentTypeDescription": "Power of Attorney", "pageCount": 5, "contentManagementId": "workspace://SpacesStore/49f0ca77-510a-4d47-ad75-3ee43bb75973;1.0", "artifactIdentifer": 170065260, "artifactSubmissionIdentifier": 85407909, "filingDate": 1610491702, "filingDateString": "01/12/2021", "fileSize": 0, "documentStatus": "PENDING", "directionCode": "INCOMING", "warningMessageList": [], "availablitySummary": { "code": "PUBLIC", "descriptionText": "Available for everyone.", "displayNameText": "Public" }, "roleSummary": { "code": "PATENT OWNER", "descriptionText": "Indicates artifact was submitted on behalf of Patent Owner.", "displayNameText": "Patent owner" }, "artifactSummary": { "code": "PAPER", "descriptionText": "Paper" } }], "proceedingParties": { "poCounsel": { "caseNo": "IPR2021-00332", "parties": [{ "identifier": "15894628", "registrationNo": "100001", "rankNo": 1, "partyType": "COUNSEL", "partySubType": "LEAD", "partySubTypeDescription": "Lead Counsel", "submitterType": "PATENTOWNER", "proseIndicator": "N", "personType": [{ "identifier": "15896760", "firstName": "Mohit", "lastName": "Khurana", "mailingAddress": [{ "identifier": "12179162", "streetLineOneText": "   ", "city": "  ", "addressType": "BUS" }], "electronicAddress": [{ "identifier": "10360281", "email": "mohitk0525@gmail.com", "emailType": "WE" }] }], "orgType": [] }, { "identifier": "15894629", "registrationNo": "17438", "rankNo": 3, "partyType": "COUNSEL", "partySubType": "BACKUP", "partySubTypeDescription": "Back Up Counsel", "submitterType": "PATENTOWNER", "proseIndicator": "N", "personType": [{ "identifier": "15896761", "firstName": "Heather", "lastName": "Herndon", "mailingAddress": [{ "identifier": "12179163", "streetLineOneText": "   ", "city": "  ", "addressType": "BUS" }], "electronicAddress": [{ "identifier": "12942717", "telephoneNumber": "571-272-4136", "teleCommAddresType": "W" }, { "identifier": "10360282", "email": "hherndonlaw@gmail.com", "emailType": "WE" }] }], "orgType": [] }] }, "poRealParty": { "caseNo": "IPR2021-00332", "parties": [{ "identifier": "15891084", "rankNo": 1, "partyType": "REAL PARTY", "submitterType": "PATENTOWNER", "proseIndicator": "N", "personType": [], "orgType": [{ "legalname": "Estech Systems, Inc.", "identifier": "15893258", "orgAddress": [], "electronicAddress": [] }] }] } } }, { "submittedDate": "1616172766", "petitioner": "Cisco Systems, Inc.", "patentOwner": "Apple", "mandatoryNoticeStatus": "Revoked", "patentNumber": "6067349", "partyGroupId": 3533900, "partyGroupType": "PATENTOWNER", "petitionDocuments": [{ "documentNumber": 6, "name": "MN_test", "category": "PAPER", "fileName": "test.pdf", "filingParty": "PATENT OWNER", "availability": "Public", "documentTypeIdentifier": 37, "documentTypeCode": "MN", "documentTypeDescription": "Mandatory Notice", "pageCount": 1, "contentManagementId": "workspace://SpacesStore/0e9c5806-a496-4efe-9609-3c8c22c403e5;1.0", "artifactIdentifer": 170084343, "artifactSubmissionIdentifier": 85426899, "filingDate": 1616173873, "filingDateString": "03/19/2021", "fileSize": 0, "documentStatus": "PENDING", "directionCode": "INCOMING", "warningMessageList": [], "availablitySummary": { "code": "PUBLIC", "descriptionText": "Available for everyone.", "displayNameText": "Public" }, "roleSummary": { "code": "PATENT OWNER", "descriptionText": "Indicates artifact was submitted on behalf of Patent Owner.", "displayNameText": "Patent owner" }, "artifactSummary": { "code": "PAPER", "descriptionText": "Paper" } }], "proceedingParties": { "poCounsel": { "caseNo": "IPR2021-00332", "parties": [{ "identifier": "15894635", "registrationNo": "10001", "rankNo": 1, "partyType": "COUNSEL", "partySubType": "LEAD", "partySubTypeDescription": "Lead Counsel", "submitterType": "PATENTOWNER", "proseIndicator": "N", "personType": [{ "identifier": "15896767", "firstName": "frances", "lastName": "Han", "mailingAddress": [{ "identifier": "12179167", "streetLineOneText": "7872 street", "city": "Lorton", "state": "VA", "zipCode": "11234", "country": "US", "addressType": "BUS" }], "electronicAddress": [{ "identifier": "12942720", "telephoneNumber": "2345678901", "teleCommAddresType": "W" }, { "identifier": "10360286", "email": "fhanlawfirm@gmail.com", "emailType": "WE" }] }], "orgType": [] }, { "identifier": "15894634", "registrationNo": "68956", "rankNo": 2, "partyType": "COUNSEL", "partySubType": "FIRSTBKUP", "partySubTypeDescription": "First Back Up Counsel", "submitterType": "PATENTOWNER", "proseIndicator": "N", "personType": [{ "identifier": "15896766", "firstName": "Leonard", "lastName": "Park", "mailingAddress": [{ "identifier": "12179166", "streetLineOneText": "600 dunlay street", "city": "Alezandria", "state": "VA", "zipCode": "11465", "country": "US", "addressType": "BUS" }], "electronicAddress": [{ "identifier": "12942719", "telephoneNumber": "1234567890", "teleCommAddresType": "W" }, { "identifier": "10360285", "email": "ptabuser2@gmail.com", "emailType": "WE" }] }], "orgType": [] }] }, "poRealParty": { "caseNo": "IPR2021-00332", "parties": [{ "identifier": "15894633", "rankNo": 1, "partyType": "REAL PARTY", "submitterType": "PATENTOWNER", "proseIndicator": "N", "personType": [], "orgType": [{ "legalname": "Apple", "identifier": "15896765", "orgAddress": [], "electronicAddress": [] }] }] } } }];
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [MandatoryNoticeComponent, FilterPipe],
      providers: [DatePipe, JpViewService, TrialsService, CommonService, provideMockStore({
        selectors: [
          { selector: CaseViewerSelectors.caseInfoData, value: { proceedingNo: '37553565' } },
          {selector: CaseViewerSelectors.userInfoData,value:{caseDetailsData: []}}
        ]
      }),
      {
        provide: ToastrService,
        useValue: toastrService
      }]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MandatoryNoticeComponent);
    jpViewService = TestBed.inject(JpViewService);
    trialsService = TestBed.inject(TrialsService);
    commonService = TestBed.inject(CommonService);
    component = fixture.componentInstance;
    component.caseInfo = { proceedingNo: '37553565' };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should get petition identifier', () => {
    // spyOn(jpViewService, 'getCaseInfoByProceedingNo').and.returnValue(of(petitionNumberMock));
    spyOn(commonService, 'getCaseInfoByProceedingNo').and.returnValue(of(petitionNumberMock));
    component.getPetitionIdentifier();
    expect(component.petitionerIdentifier).toEqual(petitionNumberMock.petitionIdentifier);
  });


  it('should get mandatory notices', () => {
    spyOn(trialsService, 'getMandatoryNotices').and.returnValue(of(mandatoryResponseMock));
    component.getMandatoryNotices();
    expect(component.mandatoryNotices).not.toBeNull();
  });


  it('should filter notices with all', () => {
    component.filterNotices('all');
    expect(component.showAll).toBeTrue();
  });


  it('should filter notices with pending', () => {
    component.filterNotices('pending');
    expect(component.showAll).toBeFalse();
  });


  it('should expand all', () => {
    component.mandatoryNotices = mandatoryResponseMock;
    component.expandCollapseAll(true);
  });


  it('should collapse all', () => {
    component.mandatoryNotices = mandatoryResponseMock;
    component.expandCollapseAll(false);
  });


  it('should open pdf', () => {
    component.openPdf(mandatoryResponseMock[0].petitionDocuments[0]);
  });


  it('should approve mandatory notice', () => {
    let userName ={}
    spyOn(window.sessionStorage, 'getItem').and.callFake((key)=>{
      return userName[key];
    })
    spyOn(trialsService, 'approveOrRejectMandatoryNotice').and.returnValue(of(""));
    component.loggedInUser = {
      loginId: 'sbartlett'
    };
    let notice = mandatoryResponseMock[0];
    component.approveOrReject(notice, 'APPROVED');

  });


  it('should sort columns', () => {
    component.mandatoryNotices = mandatoryResponseMock;
    component.sortColumn('patentOwner', undefined);
  });


  it('should sort columns with orderByField', () => {
    component.mandatoryNotices = mandatoryResponseMock;
    component.orderByField.push("patentOwner");
    component.sortColumn('patentOwner', undefined);
  });


});
