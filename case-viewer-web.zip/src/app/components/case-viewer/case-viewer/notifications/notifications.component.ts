import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { ICellRendererParams } from 'ag-grid-community';
import { BsModalService } from 'ngx-bootstrap/modal';
import { CommonService } from 'src/app/services/common.service';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { JpViewService } from 'src/app/services/jpview.service';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import { GridPagination } from 'src/app/models/grid/GridPagination';
import { EmailBodyComponent } from '../email-body/email-body.component';
import { NotificationTooltipComponent } from '../notification-tooltip/notification-tooltip.component';
import { ToastrService } from 'ngx-toastr';
import GridRefreshModel from 'src/app/models/common/GridRefresh.model';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.less']
})
export class NotificationsComponent implements OnInit {

  notifications: any;
  recipientList: any[] = [];
  tooltipList: any[] = [];
  allNotification: any;
  gridApi;
  gridColumnApi;
  frameworkComponents;
  finalCount: any;
  filterOn: boolean = false;
  numberOfFilters: number = 0;
  noRowsTemplate = "No notifications found";
  recp;
  toRecp;
  ccRecp;
  bccRecp;
  popoverContent: string = `<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>`;

  gridRefreshValues: GridRefreshModel = {
    refreshFailed: false,
    showLoading: false,
    lastRefresh: null
   }

  defaultColDef = {
    filter: true,
    sortable: true,
    floatingFilter: true,
    suppressMenu: true,
    allColumns: true,
    tooltipComponent: 'customTooltip',
    // headerCheckboxSelection: this.isFirstColumn,
    //   checkboxSelection: this.isFirstColumn,
  };

  columnDefs = [
    {
      headerName: 'Sent date',
      field: 'sendTimeStampStr',
      width: 170,
      minWidth: 170,
      resizable: true,
      sort: 'desc',
      comparator: this.gridHelper.dateComparator,
      type: 'date'
    }, {
      headerName: 'Recipient(s)',
      field: 'allRecipientList',
      width: 490,
      minWidth: 490,
      resizable: true,
      autoHeight: false,
      tooltipField: 'allRecipientList',
      tooltipComponentParams: {color: 'black'},
      // cellRendererFramework: NotificationTooltipComponent, 
      // cellRendererParams: (params: ICellRendererParams) => this.gridHelper.formatRecipientsTooltip(params),
      cellRenderer: function (params) {//Only needed if you need some custom html control or something else

        let recp = '', toRecp, ccRecp, bccRecp;
        if(params.data.tolist && params.data.tolist.length > 0 && params.data.tolist != null){
          recp = "To: "+params.data.tolist.join(', ');
          toRecp = params.data.tolist.join('; ');
        }
        if(params.data.ccList && params.data.ccList.length > 0 &&  params.data.ccList != null){
          ccRecp = params.data.ccList.join('; ');
        }
        if(params.data.bccList && params.data.bccList.length > 0){
          bccRecp = params.data.bccList.join('; ');
        }
        return '<div id="recToolTip" class="truncate-tolist">'+recp+'</div>';
    },

    },
    {
      headerName: 'To recipient(s)',
      field: 'tolist',
      hide: true
    },
    {
      headerName: 'Cc recipient(s)',
      field: 'ccList',
      hide: true
    },
    {
      headerName: 'Bcc recipient(s)',
      field: 'bccList',
      hide: true
    },
    {
      headerName: 'Subject',
      field: 'subjectText',
      width: 743,
      minWidth: 743,
      resizable: true,
      wrapText: true,
      autoHeight: true,
      cellRendererFramework: EmailBodyComponent,

    }, {
      headerName: 'Initiated by',
      field: 'initiatedBy',
      width: 230,
      minWidth: 230,
      resizable: true
    },
    {
      headerName: 'Status',
      field: 'notificationStatus',
      resizable: true,
      width: 230,
      minWidth: 230,
      cellRenderer: function (params) {//Only needed if you need some custom html control or something else
        let status = "";
        if(params.data.notificationStatus && params.data.notificationStatus == "SENT"){
          status = "Successful";
        }
        if(params.data.notificationStatus && params.data.notificationStatus == "FAILED") {
          status = "Failed";
        }
        if(params.data.notificationStatus && params.data.notificationStatus == "PENDING") {
          status = "Pending";
        }
        return '<div class="status">'+status+'</div>';
    },
    }
  ];
  // showLoading: boolean = true;
  refreshFailed: boolean;
  rowData: any;
  caseInfo: { serialNo: any; proceedingNo: any; };
   lastRefresh = new Date();

  constructor(private store: Store<CaseViewerState>, private activatedRoute: ActivatedRoute,
    private commonService: CommonService, private gridHelper: GridHelperService,private toastr: ToastrService,) { }
  gridPagination: GridPagination = new GridPagination();

  ngOnInit(): void {
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber']
    };
    this.frameworkComponents = { customTooltip: NotificationTooltipComponent };
    this.getNotifications();
    this.gridPagination.pageSize = 10;
    // setInterval(()=>{
    //   this.refresh();
    // },300000)
  }

  refresh(){
    this.getNotifications();
    this.lastRefresh = new Date();
  }

/*istanbul ignore next*/
  getNotifications() {

    this.commonService.getNotificationsList('/notifications?proceedingNumber='+this.caseInfo.proceedingNo).subscribe((notificationData) => {
      // this.showLoading = false;
      this.refreshFailed = false;
      this.allNotification = notificationData

      // this.allNotification.recipientList = [];
      for (let i = 0; i < this.allNotification.length; i++) {
        this.allNotification[i].sendTimeStampStr = this.gridHelper.convertDateToTimeStamp(this.allNotification[i].sendTimeStamp * 1000);
        this.allNotification[i].allRecipientList = [];
        if (this.allNotification[i].tolist) {
          this.allNotification[i].tolist.forEach((id) => {
            this.allNotification[i].allRecipientList.push(id.trim());
          })
        }
        if (this.allNotification[i].ccList) {
          this.allNotification[i].ccList.forEach((id) => {
            this.allNotification[i].allRecipientList.push(id.trim());
          })
        }
        if (this.allNotification[i].bccList) {
          this.allNotification[i].bccList.forEach((id) => {
            this.allNotification[i].allRecipientList.push(id.trim());
          })
        }
      };
      this.rowData = this.allNotification
      this.gridPagination.totalItems = this.allNotification.length;
      setTimeout(() => {
      this.gridPagination.totalPages = this.gridApi.paginationGetTotalPages();
      this.gridPagination.currentPage = 1;
      this.setPaginationDetails();
      this.setPageSize();
      }, 200);
    }, (failureResponse) => {
      this.toastr.error(failureResponse.error.message, "", {
        closeButton: true
      });
       
    })

  };


  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.gridPagination.totalPages = this.gridApi.paginationGetTotalPages();
    this.gridPagination.currentPage = 1;
    this.setPaginationDetails();
    this.setPageSize();
  }
/*istanbul ignore next*/
  paginationControls(step) {
    switch (step) {
      case 'first':
        this.gridApi.paginationGoToFirstPage();
        break;
      case 'previous':
        this.gridApi.paginationGoToPreviousPage();
        break;
      case 'next':
        this.gridApi.paginationGoToNextPage();
        break;
      case 'last':
        this.gridApi.paginationGoToLastPage();
        break;
      default:
        break;
    }
    this.gridPagination.currentPage = this.gridApi.paginationGetCurrentPage() + 1;
    this.setPaginationDetails();
  };

/*istanbul ignore next*/
  goToPage(e) {
    this.gridApi.paginationGoToPage(parseInt(this.gridPagination.currentPage) - 1);
    this.setPaginationDetails();
  }

/*istanbul ignore next*/
  setPageSize() {
    this.gridApi.paginationSetPageSize(parseInt(this.gridPagination.pageSize));
    this.gridPagination.totalPages = this.gridApi.paginationGetTotalPages();
    this.setPaginationDetails();
  }

/*istanbul ignore next*/
  setPaginationDetails() {
    let tempTo = this.gridPagination.pageSize * this.gridPagination.currentPage;
    this.gridPagination.to = this.gridPagination.totalItems > tempTo ? this.gridPagination.pageSize * this.gridPagination.currentPage : this.gridPagination.totalItems;
    this.gridPagination.from = (tempTo - this.gridPagination.pageSize) + 1
  }


  onFilterChanged() {
    this.filterOn = true;
    console.log("On filter changed: ", this.gridApi.getDisplayedRowCount());
    this.finalCount = this.gridApi.getDisplayedRowCount();
    const filterModel = this.gridApi.getFilterModel();
    this.numberOfFilters = Object.keys(filterModel).length;
  }


/*istanbul ignore next*/
  isFirstColumn(params) {
    let displayedColumns = params.columnApi.getAllDisplayedColumns();
    let thisIsFirstColumn = displayedColumns[0] === params.column;
    return thisIsFirstColumn;
  }


/*istanbul ignore next*/
  clearGridFilters() {
    this.gridApi.setFilterModel(null);
  }


  exportDataAsCsv() {
    let fileName: string = this.caseInfo.proceedingNo+`_Notifications`;
    this.gridHelper.exportDataAsCsv(this.gridApi, fileName);
  }


}
