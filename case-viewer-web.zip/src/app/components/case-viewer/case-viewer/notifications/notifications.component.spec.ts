import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { BsModalService } from 'ngx-bootstrap/modal';
import { CommonService } from 'src/app/services/common.service';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { FormsModule } from '@angular/forms';
import { NotificationsComponent } from './notifications.component';
import { GridApi } from 'ag-grid-community';
import { ToastrService } from 'ngx-toastr';
import { GridApiMock } from 'src/app/models/Testing/GridApiMock.model';

describe('NotificationsComponent', () => {
  let component: NotificationsComponent;
  let fixture: ComponentFixture<NotificationsComponent>;

  beforeEach(() => {
    let caseInfoMock = {
      serialNo: "12345678",
      proceedingNo: "12345678"
    };
    const activatedRouteMock = {
      snapshot: {
        params: {
          applicationNumber: "08423235",
          caseNumber: "2020005372"
        }
      }
    };
    const toastrService = {
      success: (
        message?: string,
        title?: string
      ) => { },
      error: (
        message?: string,
        title?: string
      ) => { },
    };
    const gridApiMock = {
      paginationSetPageSize: () =>{ },
      setFilterModel: () => { },
      getDisplayedRowCount: () => {
        return 5;
      },
      paginationGetTotalPages: () => {},
      getFilterModel: () => {
        const filterModelMock = {
          status: {
            filter: "n",
            filterType: "text",
            type: "contains"
          }
        }
        return filterModelMock;
      },
      exportDataAsCsv: () => { },
      getSelectedRows: () => { }
    }
    const activatedRouteStub = () => ({});
    const storeStub = () => ({});
    const bsModalServiceStub = () => ({});
    const commonServiceStub = () => ({
      getNotificationsList: string => ({ subscribe: f => f({}) })
    });
    const gridHelperServiceStub = () => ({
      convertDateToTimeStamp: arg => ({}),
      exportDataAsCsv: (gridApi, fileName) => ({})
     
    });
    TestBed.configureTestingModule({
      imports: [FormsModule],
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [NotificationsComponent],
      providers: [
        { provide: ActivatedRoute, useValue: activatedRouteMock },
        { provide: Store, useFactory: storeStub },
        { provide: BsModalService, useFactory: bsModalServiceStub },
        { provide: CommonService, useFactory: commonServiceStub },
        { provide: GridHelperService, useFactory: gridHelperServiceStub },
        { provide: ToastrService, useValue: toastrService},
        { provide: GridApi, useValue: gridApiMock }
      ]
    });
    fixture = TestBed.createComponent(NotificationsComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`recipientList has default value`, () => {
    expect(component.recipientList).toEqual([]);
  });

  it(`tooltipList has default value`, () => {
    expect(component.tooltipList).toEqual([]);
  });

  it(`filterOn has default value`, () => {
    expect(component.filterOn).toEqual(false);
  });

  it(`numberOfFilters has default value`, () => {
    expect(component.numberOfFilters).toEqual(0);
  });

  it(`columnDefs has default value`, () => {
    expect(component.columnDefs).toBeDefined();
  });


  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      component.caseInfo = {
        serialNo: "12345678",
        proceedingNo: "12345678"
      }
      
      spyOn(component, 'getNotifications').and.callThrough();
      // component.ngOnInit();
      // expect(component.getNotifications).toBeDefined();
    });
  });

  // describe('getNotifications', () => {
  //   it('makes expected calls', () => {
  //     component.caseInfo = {
  //       serialNo: "12345678",
  //       proceedingNo: "12345678"
  //     }
  //     const commonServiceStub: CommonService = fixture.debugElement.injector.get(
  //       CommonService
  //     );
  //     const gridHelperServiceStub: GridHelperService = fixture.debugElement.injector.get(
  //       GridHelperService
  //     );
  //     spyOn(commonServiceStub, 'getNotificationsList').and.callThrough();
  //     spyOn(gridHelperServiceStub, 'convertDateToTimeStamp').and.callThrough();
  //     component.getNotifications();
  //     expect(commonServiceStub.getNotificationsList).toHaveBeenCalled();
  //     expect(gridHelperServiceStub.convertDateToTimeStamp).toBeDefined();
  //   });
  // });

  // describe('setPageSize', () => {
  //   it('makes expected calls', () => {
  //     // component.gridApi = gridApiMock;
  //     spyOn(component, 'setPaginationDetails').and.callThrough();
  //     component.setPageSize();
  //     // expect(component.setPaginationDetails).toBeDefined();
  //   });
  // });
  it('should invoke on grid ready', () => {
    const gridApiMock: GridApiMock = new GridApiMock();
    const params = {
      type: "gridReady",
      api: gridApiMock,
      columnApi: {}
    };
    component.onGridReady(params);
  });

  it('should invoke onFilterChanged', () => {
    const gridApiMock: GridApiMock = new GridApiMock();
    const data = {
      api: component.gridApi,
      columnApi: component.gridColumnApi
    }
    component.gridApi = gridApiMock;
    component.onFilterChanged();
    fixture.detectChanges();
  });

  describe('exportDataAsCsv', () => {
    it('makes expected calls', () => {
      component.caseInfo = {
        serialNo: "12345678",
        proceedingNo: "12345678"
      }
      const gridHelperServiceStub: GridHelperService = fixture.debugElement.injector.get(
        GridHelperService
      );
      spyOn(gridHelperServiceStub, 'exportDataAsCsv').and.callThrough();
      component.exportDataAsCsv();
      expect(gridHelperServiceStub.exportDataAsCsv).toBeDefined();
    });
  });
});
