import { AfterContentInit, AfterViewChecked, AfterViewInit, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import CaseInfoModel from 'src/app/models/CaseInfo.model';

import * as CaseViewerActions from 'src/app/store/case-viewer/case-viewer.actions';

import { Store, select } from '@ngrx/store';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { CounselComponent } from '../counsel/counsel.component';
import { ViewChild } from '@angular/core';
import { RealPartyComponent } from '../real-party/real-party.component';
import { DocumentsComponent } from '../documents-claims/documents/documents.component';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import { JpViewService } from 'src/app/services/jpview.service';
import InfoModalModel from 'src/app/models/common/InfoModal.model';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { MotionListComponent } from 'src/app/document-upload/motion-list/motion-list.component';
import { MotionRehearingComponent } from './motion-rehearing/motion-rehearing.component';
import { MandatoryNoticeComponent } from './mandatory-notice/mandatory-notice.component';
import { CaseMilestoneComponent } from '../appeals/case-milestone/case-milestone.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { CaseviewerHeaderComponent } from '../caseviewer-header/caseviewer-header.component';
import { JoinedCasesComponent } from './joined-cases/joined-cases.component';
import { AuditHistoryComponent } from './audit-history/audit-history.component';
import { TrialsService } from 'src/app/services/trials.service';

@Component({
  selector: 'app-case-viewer',
  templateUrl: './case-viewer.component.html',
  styleUrls: ['./case-viewer.component.less'],
})
export class CaseViewerComponent implements OnInit, AfterViewInit  {

  @ViewChild('rehearingInstance') rehearingInstance:MotionRehearingComponent;
  @ViewChild('notRehearingInstance') notRehearingInstance:MotionRehearingComponent;
  @ViewChild(CounselComponent)
  private counselChildComponent: CounselComponent;

  @ViewChild(RealPartyComponent)
  private realPartyChildComponent: RealPartyComponent;

  @ViewChild(DocumentsComponent)
  private documentChildComponent: DocumentsComponent;

  @ViewChild(MotionRehearingComponent)
  private motionsComponent: MotionRehearingComponent;

  @ViewChild(MandatoryNoticeComponent)
  private mandatoryComponent: MandatoryNoticeComponent;

  @ViewChild(CaseMilestoneComponent)
  private caseMilestoneComponent:  CaseMilestoneComponent;

   @ViewChild(NotificationsComponent)
  private notificationsComponent: NotificationsComponent;

  @ViewChild(AuditHistoryComponent)
  private auditHistoryComponent: AuditHistoryComponent;

  @ViewChild(CaseviewerHeaderComponent)
  private caseviewerHeaderComponent: CaseviewerHeaderComponent;

  @ViewChild(JoinedCasesComponent)
  private joinedCasesComponent: JoinedCasesComponent;

  loggedInUser = null;
  active = 1;
  public isCollapsed = false;
  isTrialsCase: boolean = false;
  selectedTab: string;
  caseInfo: CaseInfoModel = {
    serialNo: null,
    proceedingNo: null,
    scrollToId: null
  };
  trialCases = ["DER", "IPR", "CBM", "PGR"];
  showCaseViewer: boolean = false;
  isSplAdmin: boolean = false;
  isJudge: boolean = false;
  parties: string = null;
  unsavedChanges: boolean = true;
  selectedId: string;
  isRehearing: any = true;
  previousRehearingTab: string;
  previousCaseMilestoneTab: string;
  showJoinedCasesTab: false;
  counselProceedingNos: any = [];
  realPartyProceedingNos: any = [];
  loggedInUser$ = this.store.pipe(select(CaseViewerSelectors.userInfoData));
  lastRefresh = new Date();
  milestonePoprInput: any = null;

  constructor(
    private activatedRoute: ActivatedRoute,
    private store: Store<CaseViewerState>,
    public router: Router,
    private jpViewService: JpViewService,
    private modalService: BsModalService,
    private toastr: ToastrService,
    private commonUtils: CommonUtilitiesService,
    private trialsService: TrialsService
  ) { }

  ngOnInit(): void {
    this.selectedTab = 'aiaReviewInformation';
    this.selectedId = 'aiaReviewInformation'
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber'],
      scrollToId: this.activatedRoute.snapshot.params['scrollToId']
    };
    this.store.dispatch(CaseViewerActions.setCaseInfoAction({payload:this.caseInfo}));
    this.showCaseViewer = this.caseInfo.serialNo && this.caseInfo.proceedingNo ? true : false;
    if (this.showCaseViewer) {
      this.isTrialsCase = this.trialCases.includes(this.caseInfo.proceedingNo.substring(0, 3));
    }

    this.store.pipe(select(CaseViewerSelectors.userInfoData)).subscribe(data => {
      this.loggedInUser = data.caseDetailsData[0];
      this.isJudge = data.isJudge;
      this.isSplAdmin = data.isSplAdmin;
      if (!this.loggedInUser) {
        this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
      }
      if (this.loggedInUser && this.loggedInUser.roleDescription) {

      }
    })


    this.getPartiesInfo(this.caseInfo);
    // setInterval(()=>{
    //   this.refresh();
    // },300000)

  }
/*istanbul ignore next*/
  ngAfterViewInit(): void {
    setTimeout(() => {
    let arrays =  document.getElementsByClassName('caseTabs') as HTMLCollectionOf<HTMLLinkElement>;
    for (const tag of Array.from(arrays)) {
      tag.classList.remove('active')
    }
    let tabPan = document.getElementsByClassName('routeTab') as HTMLCollectionOf<HTMLLinkElement>;
    for (const tabP of Array.from(tabPan)) {
      tabP.classList.remove('active')
    }
    if(this.caseInfo.scrollToId == 'caseMilestones') {
      document.getElementById('caseMilestone')?.classList.add('active');

    }else if (this.activatedRoute.snapshot.params['scrollToId'] == 'motionsRehearings') {
      document.getElementById('motionsRehearing')?.classList.add('active');
    }else if (this.activatedRoute.snapshot.params['scrollToId'] == 'caseHistory') {
      document.getElementById('caseHistor')?.classList.add('active');
    }
    else if (this.activatedRoute.snapshot.params['scrollToId'] == 'mandatoryNotices') {
      document.getElementById('mandatoryNotice')?.classList.add('active');
    }
    else if (this.activatedRoute.snapshot.params['scrollToId'] == 'aiaReviewInformation' || this.activatedRoute.snapshot.params['scrollToId'] == 'documents') {
      document.getElementById('aiaReviewInformatio')?.classList.add('active');
      document.getElementById('aiaReviewInformation')?.classList.add('active');

    } else if(this.activatedRoute.snapshot.params['scrollToId'] == 'joinedCases') {
      document.getElementById('joinedCase')?.classList.add('active');
    }
    document.getElementById(`${this.activatedRoute.snapshot.params['scrollToId']}`)?.classList.add('active')
  }, 300);
  }

  expandCollapseAll(status) {
    let idList = ["payments", "counsel", "realParty", "docClaims"];
    let linksList = ["paymentsLink", "counselLink", "realPartyLink", "docClaimsLink"];
    for (let j = 0; j < linksList.length; j++) {
      // let el = document.getElementById(linksList[j]);
      // el.classList.add('collapsed');
      if (status === 'expand') {
        // let currentLink = document.getElementById(linksList[j]).classList.remove('collapsed');
        let currentLink = document.getElementById(linksList[j]);
        if (currentLink) {
        currentLink.classList.remove('collapsed');
        }
      } else if (status === 'collapse') {
        let currentLinkItem = document.getElementById(linksList[j]);
        if (currentLinkItem) {
          currentLinkItem.classList.add('collapsed');
        }
      }
    }
    for (let i = 0; i < idList.length; i++) {
      // let el = document.getElementById(idList[i]);
      // el.classList.remove('in');
      if (status === 'expand') {
        // document.getElementById(idList[i]).classList.add('in');
        let currentId = document.getElementById(idList[i]);
        if (currentId) {
          currentId.classList.add('in');
        }
      } else if (status === 'collapse') {
        let currentLinkItem = document.getElementById(idList[i]);
        if (currentLinkItem) {
          currentLinkItem.classList.remove('in');
        }
      }
    }

  }


  setRedirect(scrollToId,selectedId) {
    this.previousRehearingTab = document.getElementById('motionsRehearing')?.getAttribute('class');
    this.previousCaseMilestoneTab = document.getElementById('caseMilestone')?.getAttribute('class');
    this.selectedTab = scrollToId;
    this.selectedId = this.activatedRoute.snapshot.params['scrollToId']
    // if(document.getElementsByClassName('fas fa-save')[0]){
    //   this.unsavedChanges = false;
    // }
    // document.getElementById(this.selectedId.slice(0,-1)).classList.remove('disabled')
    if((!this.unsavedChanges) || document.getElementsByClassName('fas fa-save')[0]){
    //  && (this.selectedId != scrollToId)){
      this.openAbandonChangesModal(scrollToId,selectedId);
      return false;
    }
    // this.selectedId = this.activatedRoute.snapshot.params['scrollToId']
    // this.selectedTab = scrollToId;
    // this.selectedId = selectedId
    this.callChildComponents(this.selectedTab);
    let caseInfo = JSON.parse(JSON.stringify(this.caseInfo));
    caseInfo.scrollToId = scrollToId;
    // window.sessionStorage.removeItem('caseInfo');
    window.sessionStorage.setItem('caseInfo', JSON.stringify(caseInfo));
    let path = [`/case-viewer/${this.caseInfo.serialNo}/${this.caseInfo.proceedingNo}/${scrollToId}`];
    this.router.navigate(path);

  }


  getPartiesInfo(caseInfo) {
    // let urlString =PtabTrialConstants.CASE_HEADER + `${caseInfo.serialNo}&proceedingSupplementaryId=${caseInfo.proceedingNo}`;
    let urlString =`${PtabTrialConstants.CASE_HEADER}${caseInfo.proceedingNo}`;
    // this.store.dispatch(CaseViewerActions.GetCaseHeaderAction({urlSuffix: urlString}));
    // this.jpViewService.getCaseHeader(urlString).subscribe((partiesResponse) => {
      this.trialsService.getCaseHeaderInfo(caseInfo.proceedingNo).subscribe((partiesResponse) => {
      console.log(partiesResponse);
      this.parties = null;
      if (partiesResponse && partiesResponse[0]) {
        this.parties = partiesResponse[0].parties
      }
    });
  };

  updateHeaderEvent(event) {
    this.parties = event;
  }

  updateUnsavedEvent(val){
    this.unsavedChanges = val;
  }


  callChildComponents(val) {
    if(val == 'aiaReviewInformation'){
      this.documentChildComponent.ngOnInit()
    // this.documentChildComponent.getDocuments();
    // this.documentChildComponent.getNextPaperNumber(this.caseInfo.proceedingNo);
    this.realPartyChildComponent.getRealPartyInfo();
    this.counselChildComponent.getCounselInfo();
    }else if(val == 'motionsRehearings'){
      this.rehearingInstance.ngOnInit();
      this.notRehearingInstance.ngOnInit();
    } else if(val == 'mandatoryNotices'){

      this.mandatoryComponent.ngOnInit()
    } else if(val == 'caseMilestones'){
      this.caseMilestoneComponent.ngOnInit()
    } else if(val == 'caseHistory') {
      this.notificationsComponent.ngOnInit();
      this.auditHistoryComponent.ngOnInit();
    } else if (val == 'joinedCases') {
      this.joinedCasesComponent.ngOnInit();
    }
  };
/* istanbul ignore next */
  openAbandonChangesModal(scrollToId,selectedId) {
    let modal: InfoModalModel = {
      infoText: ["You have information that has not been saved. Your changes will be lost.", "Do you want to continue?"],
      title: "Abandon unsaved information?",
      showLeftBtn: true,
      leftBtnClass: 'btn-default',
      leftBtnLabel: 'No, return to page',
      showRightBtn: true,
      rightBtnClass: 'btn-danger',
      rightBtnLabel: 'Yes, abandon changes',
      isConfirm: false,
      modalHeight: 100
    }

    let response = this.commonUtils.openConfirmModal(modal);
    response.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        this.unsavedChanges = true;
        this.modalService.hide();
        let a = document.getElementById(scrollToId);
        a.classList.add("active");
        if(this.selectedId != scrollToId){
       document.getElementById(this.selectedId).classList.remove('active')
        }
        if(this.previousRehearingTab && this.previousRehearingTab == 'active'){
          document.getElementById('motionsRehearings').classList.remove('active');
        }
       let  c:any = document.getElementsByClassName('fas fa-times-circle')[0];
       c?.click();
       this.callChildComponents(scrollToId)

      //  document.getElementById(this.selectedId).classList.remove('disabled')

      }else {
        let idToFocus = this.selectedId.slice(0, -1);
        document.getElementById(selectedId).classList.remove('active');
        // document.getElementById(selectedId).classList.remove('disabled');
        if(this.selectedId != this.selectedTab){
          document.getElementById(this.selectedId).classList.add('active');
        document.getElementById(this.selectedTab).classList.remove('active');
        }
        // else  if(this.previousCaseMilestoneTab && this.previousCaseMilestoneTab == 'active'){
        //   document.getElementById('caseMileStones').classList.add('active');
        //   document.getElementById('caseMileStone').classList.add('active');
        // }
        else {
          document.getElementById(this.selectedId).classList.add('active');
          // document.getElementById(idToFocus).classList.add('active');
        }
        document.getElementById(idToFocus).classList.add('active');
        if(this.previousCaseMilestoneTab && this.previousCaseMilestoneTab == 'active'){
          document.getElementById(idToFocus).classList.remove('active');
          document.getElementById(this.selectedId).classList.remove('active');
            document.getElementById('caseMilestones')?.classList.add('active');
            document.getElementById('caseMilestone')?.classList.add('active');
          }

      }
    })
  }

  setShowJoinedCasesTab(e) {
    this.showJoinedCasesTab = e;
  }


  setJoinedCaseNos(e) {
    let joinedCases = {
      "originalCase": [],
      "joinedCases": []
    };
    e.joinedCases.forEach((joinedCase) => {
      joinedCases.joinedCases.push(joinedCase.caseNo);
    });
    e.originalCase.forEach((originalCase) => {
      joinedCases.originalCase.push(originalCase.caseNo);
    })
    this.counselProceedingNos = joinedCases;
    this.realPartyProceedingNos = joinedCases;
  }

  refreshJoinedCaseDropdown(e) {
    this.caseviewerHeaderComponent.getJoinderRelatedCases();
  }

  setMilestonePopr(e) {
    this.milestonePoprInput = e;
  }

  refresh(){
    this.getPartiesInfo(this.caseInfo);
    this.lastRefresh = new Date();
  }

}
