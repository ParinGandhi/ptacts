import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { TrialsService } from 'src/app/services/trials.service';
import { Store, select } from '@ngrx/store';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { ToastrService } from 'ngx-toastr';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import { JpViewService } from 'src/app/services/jpview.service';
import { CommonService } from 'src/app/services/common.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import InfoModalModel from 'src/app/models/common/InfoModal.model';
import * as CaseViewerActions from 'src/app/store/case-viewer/case-viewer.actions';


@Component({
  selector: 'app-motion-rehearing',
  templateUrl: './motion-rehearing.component.html',
  styleUrls: ['./motion-rehearing.component.less']
})


export class MotionRehearingComponent implements OnInit {

  @Input() caseInfo: any;
  @Input() unsavedChanges: any;
  @Output() updateUnsavedEvent = new EventEmitter<any>();
  @Input() isRehearing: boolean;
  mandatoryNotices: Array<any> = [];
  allNotices: Array<any> = [];
  pendingNotices: Array<any> = [];
  selectedFilingParty: string = "BOARD";
  showAll: boolean = true;
  counts = {
    all: 0,
    pending: 0
  };
  loggedInUser: any;
  petitionerIdentifier: any;
  tableOptions: any;
  dataList: any[] = [];
  motionList: any[] = [];
  pendingList: any[];
  rehearingList: any[] = [];
  orderByField: any[] = [];
  disableUpdate: boolean = true;
  selectedStatus: any;
  paperTypeFullList: any;
  loadingMotions: boolean;
  hasMotions: boolean;
  caseMotions: any[];
  editMotions: Array<any> = [];
  pendingMotionList: any[] = [];
  all: boolean;
  pendingFlag: boolean;
  motionsToUpdate: any[] = [];
  selectdRehearingStatus: any;
  highlightedDiv: any;
  motionIndicator = "N";
  rehearingIndicator = "N";
  confirmation: boolean = false;
  loggedInUser$ = this.store.pipe(select(CaseViewerSelectors.userInfoData));
  lastRefresh = new Date();

  constructor(
    private store: Store<CaseViewerState>,
    private trialsService: TrialsService,
    private jpViewService: JpViewService,
    private commonService: CommonService,
    private modalService: BsModalService,
    private toastr: ToastrService,
    private commonUtils: CommonUtilitiesService
  ) { }

  ngOnInit(): void {

    this.getPetitionIdentifier();

    this.disableUpdate = this.unsavedChanges;
    this.store.pipe(select(CaseViewerSelectors.userInfoData)).subscribe(data => {
      this.loggedInUser = data.caseDetailsData[0];
      if (!this.loggedInUser) {
        this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
      }
    })

    if (this.isRehearing) {
      this.setRehearingTable();
      this.getRehearings('all', 'rehearing(s)');
    } else {
      this.setMotionsTable();
      this.getMotions('all', 'motion(s)');
    }

    // setInterval(()=>{
    //   this.refresh();
    // },300000)

  }

  refresh() {
    console.log(this.tableOptions);
    if (this.isRehearing) {
      this.setRehearingTable();
      this.getRehearings('all', 'rehearing(s)');
      // document.getElementById(`${this.tableOptions.tableId}PendingListItem`).classList.remove('active');
      // document.getElementById(`${this.tableOptions.tableId}AllListItem`).classList.add('active');
    } else {
      this.setMotionsTable();
      this.getMotions('all', 'motion(s)');
      // document.getElementById(`${this.tableOptions.tableId}PendingListItem`).classList.remove('active');
      // document.getElementById(`${this.tableOptions.tableId}AllListItem`).classList.add('active');
    }
    this.lastRefresh = new Date();
    this.resetActivePill();
  }

  getPetitionIdentifier() {
    this.commonService.getCaseInfoByProceedingNo(this.caseInfo.proceedingNo).subscribe((caseInfoByProceedingResponse) => {
      this.petitionerIdentifier = caseInfoByProceedingResponse.petitionIdentifier;
    });
  }

  statusChange(val) {
    this.selectedStatus = val;
    let updateObj = {};
    if (val.motionId) {
      updateObj = {
        "motionId": val.motionId,
        "motionStatus": val.motionStatus,
        "notificationRequiredIndicator": this.motionIndicator,
        "proceedingNumberText": val.proceedingNumberText ? val.proceedingNumberText : val.proceedingNumber,
        "audit": {
          "lastModifiedUserIdentifier": this.loggedInUser.loginId,
          "lastModifiedTimestamp": new Date().getTime()
        }
      }
    } else {
      updateObj = {
        "rehearingId": val.rehearingId,
        "rehearingStatus": val.rehearingStatus,
        "notificationRequiredIndicator": this.rehearingIndicator,
        "proceedingNumberText":  val.proceedingNumberText ? val.proceedingNumberText : val.proceedingNumber,
        "decisionDate": val.rehearingStatus != 'Pending Review' ? new Date().getTime() : null,
        "audit": {
          "lastModifiedUserIdentifier": this.loggedInUser.loginId,
          "lastModifiedTimestamp": new Date().getTime()
        }
      }
    }
    let index = val.motionId ? this.motionsToUpdate.findIndex(it => it.motionId === val.motionId) : this.motionsToUpdate.findIndex(it => it.rehearingId === val.rehearingId);
    if (index === -1) {
      this.motionsToUpdate.push(updateObj);
    } else {
      this.motionsToUpdate[index] = updateObj;
      if ((val.motionStatus && val.motionStatus.toLowerCase() == val.motionStatusDisplayName.toLowerCase()) || (val.rehearingStatus && val.rehearingStatusDisplayName.toLowerCase() == val.rehearingStatus.toLowerCase())) {
        this.motionsToUpdate.splice(index);
      }
    }
    this.disableUpdate = this.motionsToUpdate.length == 0 ? true : false;
    this.updateUnsavedEvent.emit(this.disableUpdate);
  };

  updateMotions(val) {
    if (this.motionIndicator == "Y" || this.rehearingIndicator == "Y") {
      this.openWarningModal(val);
    }
    else if (this.motionIndicator == "N" || this.rehearingIndicator == "N") {
      this.saveChanges(val);
    }
  }

  saveChanges(val){
    let url = val == 'motion(s)' ? "/motions" : "/rehearing-info"
    this.motionsToUpdate.forEach(element => {
      if(val == 'motion(s)'){
      element.notificationRequiredIndicator = this.motionIndicator;
      }
      else{
        element.notificationRequiredIndicator = this.rehearingIndicator;
      }
    });
    this.trialsService.updateMotionRehearing(url, this.motionsToUpdate).subscribe((res) => {
      if (val == 'motion(s)') {
        this.toastr.success(`Motion(s) updated successfully`, "", {
          closeButton: true
        });
        this.disableUpdate = true;
        this.getMotions('all', 'motion(s)');
      } else {
        this.toastr.success(`Rehearing(s) updated successfully`, "", {
          closeButton: true
        });
        this.disableUpdate = true;
        this.getRehearings('all', 'rehearing(s)');
      }
      this.updateUnsavedEvent.emit(this.disableUpdate);
      this.motionsToUpdate = [];
      this.resetActivePill();
    })
  }


  getRehearings(statusVal, type) {
    if (this.disableUpdate) {
      let url = '/rehearing-info?proceedingNumber=' + this.caseInfo.proceedingNo + '&status=' + statusVal;
      this.trialsService.getRehearingList(url).subscribe((rehearing) => {
        this.highlightedDiv = statusVal;
        if (statusVal == 'all') {
          this.all = true;
          this.pendingFlag = false;
          this.rehearingList = rehearing;
          this.dataList = this.rehearingList;
          this.setCounts(this.rehearingList, 'rehearing')
        } else {
          this.pendingFlag = true;
          this.all = false;
          this.pendingList = rehearing;
          this.dataList = this.pendingList;
          this.setCounts(this.pendingList, 'rehearing')
        }
      }, (rehearingsFailure) => {
        if (statusVal == 'all') {
          this.all = true;
          this.pendingFlag = false;
          this.rehearingList = [];
          this.dataList = this.rehearingList;
          this.setCounts(this.rehearingList, 'rehearing')
        } else {
          this.pendingFlag = true;
          this.all = false;
          this.pendingList = [];
          this.dataList = this.pendingList;
          this.setCounts(this.pendingList, 'rehearing')
        }
      })
    } else {
      this.openAbandonChangesModal(statusVal, type);
      return;
    }
  this.orderByField=["-filedDate"];
  };

  getMotions(statusVal, type) {
    if (this.disableUpdate) {
      this.loadingMotions = true;
      this.highlightedDiv = statusVal
      let url = '/motions?proceedingNumber=' + this.caseInfo.proceedingNo
      this.trialsService.getMotionsList(url).subscribe((motionsResponse) => {
        // this.jpViewService.getTrialsInfo(`${PtabTrialConstants.TRIAL_SERVICES_URL}/partytype/motionstatus-info?proceedingNumber=${this.caseInfo.proceedingNo}&typeIds=${motions}`).subscribe((motionsResponse) => {
        this.dataList = []

        // this.pendingMotionList = [];
        let caseMotionsToCheck = motionsResponse;
        let i: number = 0;
        if (statusVal == 'all') {
          this.motionList = [];
          this.all = true;
          this.pendingFlag = false;
          caseMotionsToCheck.forEach(element => {
            if (element.motionStatusDisplayName.toLowerCase() != 'initiated') {
              this.motionList.push(element);
            }
          });
          // this.motionList = motionsResponse;
          this.dataList = this.motionList;
          this.setCounts(this.motionList, 'motion')
        } else {
          this.all = false;
          this.pendingFlag = true;
          this.pendingMotionList = []
          caseMotionsToCheck.forEach(element => {
            if (element.motionStatusDisplayName.toLowerCase() == 'pending review') {
              // this.hasMotions=true;
              this.pendingMotionList.push(element);
            }

          });
          // this.pendingMotionList = motionsResponse
          this.dataList = this.pendingMotionList;
          this.setCounts(this.pendingMotionList, 'motion')
        }
      });
      this.loadingMotions = false;
    } else {
      this.openAbandonChangesModal(statusVal, type);
      return;
    }
    this.orderByField=["-submittedDate"];
  }

  openAbandonChangesModal(statusVal, type) {
    let modal: InfoModalModel = {
      infoText: ["You have " + type + " information that has not been saved. Your changes will be lost.", "Do you want to continue?"],
      title: "Abandon unsaved information?",
      showLeftBtn: true,
      leftBtnClass: 'btn-default',
      leftBtnLabel: 'No, return to page',
      showRightBtn: true,
      rightBtnClass: 'btn-danger',
      rightBtnLabel: 'Yes, abandon changes',
      isConfirm: false,
      modalHeight: 100
    }

    let response = this.commonUtils.openConfirmModal(modal);
    response.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        this.modalService.hide();
        this.disableUpdate = true;
        this.updateUnsavedEvent.emit(this.disableUpdate);
        if (type == 'motion(s)') {
          this.getMotions(statusVal, type);
        } else {
          this.getRehearings(statusVal, type);
        }

      }
    })
  }

  setCounts(list, type) {
    this.pendingList = [];
    this.counts = {
      all: 0,
      pending: 0
    };
    if (type == 'rehearing') {
      this.counts.all = this.rehearingList.length;
    } else {
      this.counts.all = this.motionList.length;
    }
    list.forEach(el => {
      if ((el.status && el.status.toLowerCase() === 'pending approval') || (el.rehearingStatus && el.rehearingStatus.toLowerCase().indexOf('pending') > -1)) {
        this.counts.pending++;
        this.pendingList.push(el);
      } else if (el.motionStatus && el.motionStatus.toLowerCase().indexOf('pending') > -1) {
        this.counts.pending++;
      }
    });
  }

  setMotionsTable() {
    this.tableOptions = {
      btnId: "motion(s)",
      tableId: "motionTable",
      tableHeaderClass: "motionTableHeader",
      tableBodyClass: "motionTableBody",
      columnDefs: [
        {
          name: "Motion submitted date",
          displayName: "Motion submitted date",
          field: "submittedDate",
          width: '13%',
          type: "datetime",
          searchText: null
        },
        {
          name: "Filing party",
          displayName: "Filing party",
          field: "filingParty",
          width: '10%',
          type: "string",
          searchText: null
        },
        {
          name: "Motion type",
          displayName: "Motion type",
          field: "motionType",
          width: '25%',

          type: "string",
          searchText: null
        },
        {
          name: "Motion status",
          displayName: "Motion status",
          field: "motionStatusDisplayName",
          width: '12%',
          type: "string",
          searchText: null
        },
        {
          name: "Motion decision date",
          displayName: "Motion decision date",
          field: "motionStatusDate",
          width: '13%',
          type: "datetime",
          searchText: null
        },
        {
          name: "View motion",
          displayName: "View motion",
          field: "viewNotice",
          width: '10%',
          type: "string",
          searchText: null
        },
        {
          name: "Action(s)",
          displayName: "Action(s)",
          field: "action",
          width: '12%',
          type: "string",
          searchText: null
        }
      ],
      data: JSON.parse(JSON.stringify(this.dataList))
    };
  }
/*istanbul ignore next*/
  setRehearingTable() {
    this.tableOptions = {
      btnId: "rehearing(s)",
      tableId: "rehearingTable",
      tableHeaderClass: "rehearingTableHeader",
      tableBodyClass: "rehearingTableBody",
      columnDefs: [
        {
          name: "Rehearing submitted date",
          displayName: "Rehearing request submitted date",
          field: "filedDate",
          width: '13%',
          type: "datetime",
          searchText: null
        },
        {
          name: "Filing party",
          displayName: "Filing party",
          field: "requestorTypeName",
          width: '10%',
          type: "string",
          searchText: null
        },
        {
          name: "Rehearing type",
          displayName: "Rehearing request type",
          field: "rehearingTypeName",
          width: '20%',
          type: "string",
          searchText: null
        },

        {
          name: "Rehearing status",
          displayName: "Rehearing request status",
          field: "rehearingStatusDisplayName",
          width: '12%',
          type: "string",
          searchText: null
        },
        {
          name: "Rehearing decision date",
          displayName: "Rehearing decision date",
          field: "filedDate",
          width: '13%',
          type: "datetime",
          searchText: null
        },
        {
          name: "View Rehearing",
          displayName: "View rehearing request",
          field: "viewNotice",
          width: '10%',
          type: "string",
          searchText: null
        },
        {
          name: "Action(s)",
          displayName: "Action(s)",
          field: "action",
          width: '12%',
          type: "string",
          searchText: null
        }
      ],
      data: JSON.parse(JSON.stringify(this.dataList))
    };
  };


  expandCollapseAll(val) {
    this.dataList.forEach((notice) => {
      notice.expanded = val;
    })
  }

  sortColumn(field, sortType) {
    !this.orderByField.includes(field) ? this.correctOrder(field, sortType) : this.correctOrder('-' + field, sortType);
    this.orderByField = !this.orderByField.includes(field) ? [field] : ['-' + field];

  }

  correctOrder(field, sortType) {
    let tempData;
    this.dataList.forEach(ele =>
      {
        if(ele.motionStatusDate==undefined){
          ele.motionStatusDate=null;
        }
      })
    tempData = [...this.dataList];
    this.dataList = [];
    let order = field.charAt(0) === '-' ? "desc" : "asc"
    tempData.sort(this.compareValues(field, order));
    this.dataList = [...tempData];
  }

  compareValues(key, order = 'asc') {
    if (key.charAt(0) === '-') {
      key = key.substring(1);
    }
    return function innerSort(a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        // property doesn't exist on either object
        return 0;
      }

      const varA = (typeof a[key] === 'string')
        ? a[key].toUpperCase() : a[key];
      const varB = (typeof b[key] === 'string')
        ? b[key].toUpperCase() : b[key];

      let comparison = 0;
      if (varA > varB) {
        comparison = 1;
      } else if (varA < varB) {
        comparison = -1;
      }
      return (
        (order === 'desc') ? (comparison * -1) : comparison
      );
    };
  }
/*istanbul ignore next*/
  openWarningModal(val) {
    let modal: InfoModalModel = {
      infoText: ["Are you sure you want to notify external parties?"],
      title: "Confirmation",
      showLeftBtn: true,
      leftBtnClass: 'btn-default',
      leftBtnLabel: 'Cancel',
      showRightBtn: true,
      rightBtnClass: 'btn-primary',
      rightBtnLabel: 'Yes, proceed',
      isConfirm: false,
      modalHeight: 100
    }
    let response = this.commonUtils.openConfirmModal(modal);
    response.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
      this.saveChanges(val);
      }
      else
      {
        if(val == 'motion(s)'){
          this.motionIndicator="N";
          }
          else{
            this.rehearingIndicator="N";
          }
      }
    })
  }
/*istanbul ignore next*/
  updateIndicator(indicator, val) {
    if (val == "motion") {
      this.motionIndicator = indicator;
    }
    if (val == "rehearing") {
      this.rehearingIndicator = indicator;
    }
  }

  openPdf(data) {
    this.commonService.openPdf(`/petitions/${this.petitionerIdentifier}/download-documents?contentManagementId=${data.contentManagementId}`)
  }

  resetActivePill() {
    document.getElementById(`${this.tableOptions.tableId}PendingListItem`).classList.remove('active');
    document.getElementById(`${this.tableOptions.tableId}AllListItem`).classList.add('active');
  }


}