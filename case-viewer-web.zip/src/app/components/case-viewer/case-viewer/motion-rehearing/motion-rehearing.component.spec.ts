




import {​​​​​​​​ FilterPipe }​​​​​​​​ from"src/app/utilities/table-filter-pipe";
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { TrialsService } from 'src/app/services/trials.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DatePipe } from '@angular/common';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { ToastrService } from 'ngx-toastr';
import { of } from 'rxjs/internal/observable/of';
import { provideMockStore } from '@ngrx/store/testing';
import { MotionRehearingComponent } from './motion-rehearing.component';
import { JpViewService } from 'src/app/services/jpview.service';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { EventEmitter } from "@angular/core";

describe('MotionRehearingComponent', () => {
  let component: MotionRehearingComponent;
  let fixture: ComponentFixture<MotionRehearingComponent>;
  let trialsService: TrialsService;
  let gridHelper: GridHelperService;
  let modalService: BsModalService;
  let commonUtils: CommonUtilitiesService;
  let toastr: ToastrService;

  class commonUtilsMock {
    openConfirmModal = () => { return { onHide: () => { return of({}) } } }
  }
  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => {},
    error: (
      message?: string,
      title?: string
    ) => {},
  };

  const val = {
    "motionId": 1,
    "motionStatus":"denied",
    "motionStatusDisplayName":"Denied"
  }

  const rehearingVal = {
    "mrehearingId": 1,
    "rehearingStatus":"denied",
    "rehearingStatusDisplayName":"Denied"
  }

  const motions =[{"proceedingNumberText":"IPR2020-00738","audit":{"lastModifiedTimestamp":1586381728191,"lastModifiedUserIdentifier":"14973","createUserIdentifier":"14973","createTimestamp":1586381641241},"motionId":2704451,"submittedDate":1586381728102,"motionType":"Motion to Appear Pro Hac Vice","filingParty":"Patent Owner","motionStatus":"PENDING REVIEW","motionStatusDisplayName":"Pending review","submittedDateString":"04/08/2020 05:35 PM","motionDocuments":[{"documentNumber":6,"name":"PATENT OWNER'S UNOPPOSED MOTION FOR PRO HAC VICE ADMISSION OF PERRY M. GOLDBERG","category":"PAPER","fileName":"2020_4_8_KAN PHV Motion [Goldberg]_IPR2020-00738.pdf","filingParty":"PATENT OWNER","availability":"Public","documentTypeIdentifier":1,"documentTypeCode":"MOTION","documentTypeDescription":"Motion","pageCount":6,"contentManagementId":"workspace://SpacesStore/4bb89628-ff08-4104-922b-a58fd8dee830;1.0","artifactIdentifer":169935233,"artifactSubmissionIdentifier":85285381,"filingDate":1586381727,"filingDateString":"04/08/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"PAPER","descriptionText":"Paper"}},{"name":"DECLARATION OF PERRY M. GOLDBERG IN SUPPORT OF PATENT OWNER'S UNOPPOSED MOTION FOR PRO HAC VICE ADMISSION","category":"EXHIBITS","fileName":"2020_4_8_DLS Declaration ISO Motion for Admission PHV [Goldberg 738].pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2001,"pageCount":4,"contentManagementId":"workspace://SpacesStore/7255bc6c-caf7-45c8-84c2-78d9c6c94266;1.0","artifactIdentifer":169935234,"artifactSubmissionIdentifier":85285382,"filingDate":1586381727,"filingDateString":"04/08/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}}]},{"proceedingNumberText":"IPR2020-00738","audit":{"lastModifiedTimestamp":1586382009870,"lastModifiedUserIdentifier":"14973","createUserIdentifier":"14973","createTimestamp":1586381749857},"motionId":2704452,"submittedDate":1586382009832,"motionType":"Motion to Appear Pro Hac Vice","filingParty":"Patent Owner","motionStatus":"PENDING REVIEW","motionStatusDisplayName":"Pending review","submittedDateString":"04/08/2020 05:40 PM","motionDocuments":[{"documentNumber":7,"name":"PATENT OWNER'S UNOPPOSED MOTION FOR PRO HAC VICE ADMISSION OF TED SICHELMAN","category":"PAPER","fileName":"2020_4_8_KAN PHV Motion [Sichelman]_IPR2020-00738.pdf","filingParty":"PATENT OWNER","availability":"Public","documentTypeIdentifier":1,"documentTypeCode":"MOTION","documentTypeDescription":"Motion","pageCount":5,"contentManagementId":"workspace://SpacesStore/f679e9c7-cb76-44b4-b385-eed5d484d49f;1.0","artifactIdentifer":169935259,"artifactSubmissionIdentifier":85285373,"filingDate":1586382009,"filingDateString":"04/08/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"PAPER","descriptionText":"Paper"}},{"name":"DECLARATION OF TED SICHELMAN IN SUPPORT OF PATENT OWNER'S UNOPPOSED MOTION FOR PRO HAC VICE ADMISSION","category":"EXHIBITS","fileName":"2020_4_8_DLS Declaration ISO Motion for Admission PHV [Sichelman 738].pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2002,"pageCount":4,"contentManagementId":"workspace://SpacesStore/f9968e35-8af9-499d-b68b-961280137be1;1.0","artifactIdentifer":169935236,"artifactSubmissionIdentifier":85285384,"filingDate":1586382009,"filingDateString":"04/08/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}}]},{"proceedingNumberText":"IPR2020-00738","audit":{"lastModifiedTimestamp":1614927449909,"lastModifiedUserIdentifier":"5041","createUserIdentifier":"14672","createTimestamp":1588036182775},"motionId":2704807,"submittedDate":1588036246439,"motionType":"Motion to Appear Pro Hac Vice","filingParty":"Petitioner","motionStatus":"GRANTED","motionStatusDisplayName":"Granted","submittedDateString":"04/27/2020 09:10 PM","motionDocuments":[{"name":"Maroulis Declaration","category":"EXHIBITS","fileName":"IPR2020-00738 Decl ISO PHV Motion.pdf","filingParty":"PETITIONER","availability":"Public","exhibitNumber":1013,"pageCount":4,"contentManagementId":"workspace://SpacesStore/ea19c8cb-b500-49c3-b1d9-0a0dd0b8c96b;1.0","artifactIdentifer":169941476,"artifactSubmissionIdentifier":85291584,"filingDate":1588036246,"filingDateString":"04/27/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"documentNumber":10,"name":"Motion for Pro Hac Vice of Victoria F. Maroulis","category":"PAPER","fileName":"IPR2020-00738 Maroulis PHV Motion.pdf","filingParty":"PETITIONER","availability":"Public","documentTypeIdentifier":1,"documentTypeCode":"MOTION","documentTypeDescription":"Motion","pageCount":5,"contentManagementId":"workspace://SpacesStore/f852c24a-f885-4afa-89a9-e0f65060efbe;1.0","artifactIdentifer":169941491,"artifactSubmissionIdentifier":85291599,"filingDate":1588036246,"filingDateString":"04/27/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PETITIONER","descriptionText":"Indicates artifact was submitted on behalf of Petitioner.","displayNameText":"Petitioner"},"artifactSummary":{"code":"PAPER","descriptionText":"Paper"}}]},{"proceedingNumberText":"IPR2020-00738","audit":{"lastModifiedTimestamp":1614923725080,"lastModifiedUserIdentifier":"5041","createUserIdentifier":"14973","createTimestamp":1593060145417},"motionId":2705642,"submittedDate":1593060316507,"motionType":"Motion to Seal","filingParty":"Patent Owner","motionStatus":"GRANTED IN PART","motionStatusDisplayName":"Granted in part","submittedDateString":"06/25/2020 12:45 AM","motionDocuments":[{"documentNumber":14,"name":"PATENT OWNER¿¿¿S OPPOSED MOTION TO SEAL","category":"PAPER","fileName":"2020_6_24_KAN Motion to Seal_IPR2020-00738 (1).pdf","filingParty":"PATENT OWNER","availability":"Public","documentTypeIdentifier":1,"documentTypeCode":"MOTION","documentTypeDescription":"Motion","pageCount":6,"contentManagementId":"workspace://SpacesStore/30c9f1f3-f6c6-4ed0-8217-d67015c5789f;1.0","artifactIdentifer":169971738,"artifactSubmissionIdentifier":85319527,"filingDate":1593060315,"filingDateString":"06/25/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"PAPER","descriptionText":"Paper"}},{"documentNumber":15,"name":"PROTECTIVE ORDER","category":"PAPER","fileName":"2020_6_24_Default Protective Order (celan).pdf","filingParty":"PATENT OWNER","availability":"Public","documentTypeIdentifier":1,"documentTypeCode":"MOTION","documentTypeDescription":"Motion","pageCount":5,"contentManagementId":"workspace://SpacesStore/a8d1b4d5-369b-4f2b-98e8-05426d88066b;1.0","artifactIdentifer":169971739,"artifactSubmissionIdentifier":85319528,"filingDate":1593060315,"filingDateString":"06/25/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"PAPER","descriptionText":"Paper"}},{"name":"DECLARATION OF TODD K. VIEGUT IN SUPPORT OF PATENT OWNER¿¿¿S PRELIMINARY RESPONSE","category":"EXHIBITS","fileName":"2020_6_24_Declaration ISO POPR [Viegut] v3.pdf","filingParty":"PATENT OWNER","availability":"Parties and Board","exhibitNumber":2011,"pageCount":24,"contentManagementId":"workspace://SpacesStore/7e4b66e7-503c-4179-be87-771bac416e0f;1.0","artifactIdentifer":169971740,"artifactSubmissionIdentifier":85319529,"filingDate":1593060315,"filingDateString":"06/25/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PRIVATE","descriptionText":"Available to parties and board.","displayNameText":"Parties and Board"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}},{"name":"Kannuu KanWAS Lookup API","category":"EXHIBITS","fileName":"[Exhibit 2014] Kannuu KanWAS API Key Concepts 1_1 (1).pdf","filingParty":"PATENT OWNER","availability":"Parties and Board","exhibitNumber":2014,"pageCount":8,"contentManagementId":"workspace://SpacesStore/ff0d02b8-10fd-4eda-a522-6ecaeedf9231;1.0","artifactIdentifer":169971719,"artifactSubmissionIdentifier":85319547,"filingDate":1593060315,"filingDateString":"06/25/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PRIVATE","descriptionText":"Available to parties and board.","displayNameText":"Parties and Board"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}}]}]
  const rehearing = [{"rehearingId":314093,"proceedingNumber":"IPR2020-00738","rehearingTypeName":"Institution Decision","filedDate":1602043200000,"rehearingTypeId":1,"requestorTypeName":"Patent Owner","rehearingStatusId":1,"rehearingStatus":"Pending Review","rehearingStatusDisplayName":"Pending Review","rehearingDocuments":[{"documentNumber":24,"name":"Patent Owner's Rehearing Request","category":"PAPER","fileName":"2020_10_7_IPR2020-00738 Kannuu's Request for Rehearing FINAL v3.pdf","filingParty":"PATENT OWNER","availability":"Public","documentTypeIdentifier":29,"documentTypeCode":"HR","documentTypeDescription":"Rehearing Request - in re Institution Decision Granted","pageCount":24,"contentManagementId":"workspace://SpacesStore/79f6cffc-8699-4985-822b-334135341099;1.0","artifactIdentifer":170024836,"artifactSubmissionIdentifier":85370474,"filingDate":1602128937,"filingDateString":"10/07/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"PAPER","descriptionText":"Paper"}},{"name":"Excerpt of September 30, 2020 Initial Scheduling Conference Transcript in 1:19-cv-4297-ER (SDNY)","category":"EXHIBITS","fileName":"2020_10_7_Exhibit 2022.pdf","filingParty":"PATENT OWNER","availability":"Public","exhibitNumber":2022,"pageCount":3,"contentManagementId":"workspace://SpacesStore/c9b55884-4506-4c8c-adf9-990fa0f07389;1.0","artifactIdentifer":170024837,"artifactSubmissionIdentifier":85370475,"filingDate":1602128937,"filingDateString":"10/07/2020","fileSize":0,"documentStatus":"PENDING","directionCode":"INCOMING","warningMessageList":[],"availablitySummary":{"code":"PUBLIC","descriptionText":"Available for everyone.","displayNameText":"Public"},"roleSummary":{"code":"PATENT OWNER","descriptionText":"Indicates artifact was submitted on behalf of Patent Owner.","displayNameText":"Patent owner"},"artifactSummary":{"code":"EXHIBITS","descriptionText":"Exhibits"}}]}]
  const activatedRouteMock = {
    snapshot: {
      params: {
        applicationNumber: "08423235",
        caseNumber: "2020005372"
      }
    }
	}


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [MotionRehearingComponent,FilterPipe],
      providers: [
        DatePipe,
        TrialsService,
        BsModalService,
        CommonUtilitiesService,
        {
          provide: ToastrService,
          useValue: toastrService
        },
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        },
        {
          provide: BsModalRef,
          useValue: {}
        },
        {
          provide: BsModalService,
          useValue: {}
        },
        {
          provide: CommonUtilitiesService,
          useValue: commonUtilsMock
        },
        provideMockStore({
          selectors: [
             { selector: CaseViewerSelectors.caseInfoData, value: { proceedingNo: '37553565' } },
            { selector: CaseViewerSelectors.userInfoData, value: { caseDetailsData: [] } }
          ]
      }),
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MotionRehearingComponent);
    trialsService = TestBed.inject(TrialsService);
    modalService = TestBed.inject(BsModalService);
    commonUtils = TestBed.inject(CommonUtilitiesService);
    component = fixture.componentInstance;
    component.caseInfo = { proceedingNo: '37553565' };
    const emitter = new EventEmitter();
    emitter.emit(true);
    commonUtils.openConfirmModal = (): BsModalRef => {
      return ({ id: null, hide: null, setClass: null, onHide: emitter, onHidden: null });
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create', () => {
    component.isRehearing = true;
    expect(component).toBeTruthy();
  });

  it('should call statusChange',() =>{
    component.motionsToUpdate=[{"motionId":1}]
    component.loggedInUser ={ loginId: "akellogg"}
    component.statusChange(val);
  });

  it('should call statusChange with rehearing',() =>{
    component.motionsToUpdate=[{"rehearingId":1}]
    component.loggedInUser ={ loginId: "akellogg"}
    component.statusChange(val);
  });

  it('should call updateMotions with motions', () =>{
    let userName ={}
    spyOn(window.sessionStorage, 'getItem').and.callFake((key)=>{
      return userName[key];
    })
    spyOn(trialsService, 'updateMotionRehearing').and.returnValue(of({test:''}));
    component.updateMotions('motion(s)');
  });

  it('should call updateMotions with rehearings', () =>{
    let userName ={}
    spyOn(window.sessionStorage, 'getItem').and.callFake((key)=>{
      return userName[key];
    })
    spyOn(trialsService, 'updateMotionRehearing').and.returnValue(of({test:''}));
    component.updateMotions('rehearing(s)');
  });

  it('should call getRehearings for all tab', () =>{
    component.disableUpdate = true;
    let userName ={}
    spyOn(window.sessionStorage, 'getItem').and.callFake((key)=>{
      return userName[key];
    })
    spyOn(trialsService, 'getRehearingList').and.returnValue(of(rehearing));
    component.getRehearings("all",'rehearing(s)');
    expect(component.rehearingList).toBeDefined;
  });


  it('should call getRehearings for pending tab', () =>{
    component.disableUpdate = true;
    let userName ={}
    spyOn(window.sessionStorage, 'getItem').and.callFake((key)=>{
      return userName[key];
    })
    spyOn(trialsService, 'getRehearingList').and.returnValue(of(rehearing));
    component.getRehearings("pending",'rehearing(s)');
    expect(component.pendingList).toBeDefined;
  });

  it('should call getmotions for all tab', () =>{
    component.disableUpdate = true;
    let userName ={}
    spyOn(window.sessionStorage, 'getItem').and.callFake((key)=>{
      return userName[key];
    })
    spyOn(trialsService, 'getMotionsList').and.returnValue(of(motions));
    component.getMotions("all",'motion(s)');
    let caseMotionsToCheck = motions
    expect(caseMotionsToCheck).toBeDefined;
  });

  it('should call getmotions for pending tab', () =>{
    component.disableUpdate = true;
    let userName ={}
    spyOn(window.sessionStorage, 'getItem').and.callFake((key)=>{
      return userName[key];
    })
    spyOn(trialsService, 'getMotionsList').and.returnValue(of(motions));
    component.getMotions("pending",'motion(s)');
    let caseMotionsToCheck = motions
    expect(caseMotionsToCheck).toBeDefined;
  });

  it('should call setcounts with rehearing type', () =>{
    component.setCounts([],'rehearing');
  });

  it('should call setcounts with motion type', () =>{
    component.setCounts([],'motion');
  });

  it('should call expandCollapseAll', ()=> {
    component.dataList = [{"expanded": false}]
    component.expandCollapseAll(true);
  });

  it('should call sort', ()=>{
    component.orderByField = [];
    let tempData = [];
    component.dataList = motions
    component.sortColumn('motionStatusDisplayName','asc');
  })
});
