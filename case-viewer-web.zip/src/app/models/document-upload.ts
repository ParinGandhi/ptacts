export class DocumentUpload {

    name?: string;
    category?: string;
    fileName?: string;
    filingParty?: string;
    availability?: string;
    exhibitNumber?: string;
    documentTypeCode?: string;
    documentTypeIdentifier?: number;
    data?: any;
    filingPartyGroupIdentifier?: any;
    lastModifiedDateTime?: any;
    createUserIdentifier?: any;
    lastModifiedUserIdentifier?: string;
    proceedingNumberText?: string;
    sequenceNumber?: any;
    mimeType?: any;
    pageCount?: any;
    contentManagementId?: any;
    artifactSubmissionIdentifier?: any;
    filingDate?: any;
    proceedingArtifactIdentifier?: any;
    paperTypeParameter1?:any;
    paperTypeParameter2?:any;
    paperTypeParameter3?:any;
    motions?:Array<any>;
    rehearings?: Array<any>;
    documentTypeCustomAttributes?: any;
    tempDocument?: any;
    relatedProceedingNo?: string;
}