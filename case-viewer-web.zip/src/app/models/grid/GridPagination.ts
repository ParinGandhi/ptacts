export class GridPagination {
    pageSize = null;
    totalPages = null;
    totalItems = null;
    currentPage = null;
    from = null;
    to = null;

    constructor() {

    }
}