export class Motion {

    requestionTypeName?: string;
    motionTypeName?:string;
    filedTimeStamp?: any;
    action?: string;
    motionTypeId?:number;
    motionStatusId?:number;
}