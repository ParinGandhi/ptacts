export class CaseSearch {
    proceedingNumber = null
    patentNumber = null;
    applicationNumber = null;
    partyName = null;
    apj1Judge = null;
    apjXJudge = null;
    techCenterNum = null;
    trailTypes = [];
    inventionTitle = null;
    casePhase = null;
    artUnit = null;

    constructor() {

    }
}