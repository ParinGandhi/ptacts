export class FilterValidations {
    partyNameHasError = false;
    partyNameMessage = null;
    institutionToHasError = false;
    institutionFromHasError = false;
    institutionMessage = null;
    filingToHasError = false;
    filingFromHasError = false;
    filingMessage = null;
    terminationToHasError = false;
    terminationFromHasError = false;
    terminationMessage = null;

    constructor() {

    }

}