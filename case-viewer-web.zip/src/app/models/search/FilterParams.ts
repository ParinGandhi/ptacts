export class FilterParams {
    partyName = null;
    additionalRealParty = true;
    counsel = true;
    institutionDateFrom = null;
    institutionDateTo = null;
    filingDateFrom = null;
    filingDateTo = null;
    terminationDateFrom = null;
    terminationDateTo = null;
    decisionOutcome = null;


    constructor() {

    }
}