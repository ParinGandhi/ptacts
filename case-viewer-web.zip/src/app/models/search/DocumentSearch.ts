export class DocumentSearch {
    pageNo = 1;
    resultsPerPage = 1000;
    proceedingNumber = null;
    trailTypes = [];
    documentText = null;
    filingParties = [];
    visibilityOptions = [];
    uploadedStartDate = null;
    uploadedEndDate = null;

    constructor() {

    }
}