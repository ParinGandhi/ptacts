
 class UserInfoData {
    activeIn: string;
    apjSeniorityRank: number;
    disiplanceCd: string;
    emailAddress: string;
    firstName: string;
    fullName: string;
    jobClassificationCode: string;
    lastName: string;
    leadApjIndicator: string;
    loginId: string;
    preferredFullName: string;
    privileges: [];
    roleDescription: string;
    trialJudgeIndicator: string;
    userIdentiifier: number;
    userWorkerNumber: string;
    isAdmin: boolean;
}


export default interface UserInfoModel {
    caseDetailsData: Array<UserInfoData>;
    isSplAdmin: boolean;
    isJudge: boolean;
    isPanelingMember: boolean;
    isPl: boolean;
    userPermissionDetailsList: Array<{}>;
    permissions?: {};
}

