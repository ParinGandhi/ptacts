import JudgeRankModel from "../common/JudgeRank.model";
import CaseTransitionModel from "../common/CaseTransition.model";

export default interface CaseDetailsModel {

    appealNumberText: string,
    applicationTypeCategory: string,
    mileStoneDates: number,
    keyDates: number,
    patentNumberText: string,
    parties: string,
    inventionTitle: string,
    attorneys: Array<JudgeRankModel>,
    briefHearingTypeCode: string,
    casetransactionDetails: Array<CaseTransitionModel>,
    proceedingNumber: string,
    casePhase: string,
    fastTrackDesc: string,
    circulationViewable: boolean,
    interruptInProcess: boolean,
    circulationReorderExists: boolean

}