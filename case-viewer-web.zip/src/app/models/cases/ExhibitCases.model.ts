import CaseModel from "./Case.model";

export default interface ExhibitCasesModel {
    allExhibitsBag: Array<CaseModel>,
    allExhibitsCount?: number,
    thousandsExhibitsBag: Array<CaseModel>,
    thousandsExhibitsCount?: number,
    twoThousandsExhibitsBag: Array<CaseModel>,
    twoThousandsExhibitsCount?: number,
    threeThousandsExhibitsBag: Array<CaseModel>,
    threeThousandsExhibitsCount?: number
  }