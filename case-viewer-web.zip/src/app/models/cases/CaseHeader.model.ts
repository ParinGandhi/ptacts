// import AttorneyModel from "./CaseHeader.model";

export default interface CaseHeaderModel {
     patentNumberText: number,
     proceedingNumber: string,
     //derproceedingTypeDetails: string,
     techCenterNum: number,
     ptabReadOnlyUser:boolean,
     mileStoneDates: null,
     parties: string,
     attorneys: Array<AttorneyModel>,
     artUnit: number,
     casePhase: string,
     inventionTitle: string,
     keyDates: Array<string>,
    joinderTypes: [],
    petitionerPatentNumber: null,
    petitionerinventionTitle: string,
    petitionerTechCenterNum:  number,
    petitionerArtUnit:  number,
    derproceedingTypeDetails: {
        firstListedPetitionerApplicationNumber: string,
        firstListedPatentOwnerRespondentApplicationNumber: string,
        aiaReviewConfidentiality: string
    }
}

class AttorneyModel {
     employeeName: string;
     rank: number
}

