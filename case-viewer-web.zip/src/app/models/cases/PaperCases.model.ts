import CaseModel from "./Case.model";

export default interface PaperCasesModel {
    allPapersBag: Array<CaseModel>,
    allPapersCount?: number,
    boardPapersBag: Array<CaseModel>,
    boardPapersCount?: number,
    patentOwnerPapersBag: Array<CaseModel>,
    patentOwnerPapersCount?: number,
    petitionerPapersBag: Array<CaseModel>,
  petitionerPapersCount?: number,
  ptabReadOnlyUser?: boolean
  }