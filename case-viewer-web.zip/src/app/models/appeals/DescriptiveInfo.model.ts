import InventorModel from '../common/Inventor.model';
import WorkerModel from '../common/Worker.model';

export default interface DescriptiveInfoModel {
    appealNumberText: string,
    appealType: string,
    appellantsDetails: Array<String>,
    applicationType: string,
    artClassNumber: string,
    artSubClassNumber: string,
    artUnit: string,
    caseDiscipline: string,
    caseDisciplineCode: string,
    cpcCodeFirst?: string,
    inventors: Array<InventorModel>,
    panelingDisciplineCode: string,
    panellingDisciplineDescriptionText: string,
    proceedingNumber?: string,
    proceedingType?: string,
    ptabReceivedDate: number,
    realPartiesDetails: Array<String>,
    specialType: string,
    techCenterNumber: string,
    worker: WorkerModel
}