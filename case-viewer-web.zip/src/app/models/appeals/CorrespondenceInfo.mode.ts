export default interface CorrespondenceInfoModel {
    cityName: string,
    customerNumberText: string,
    geographicRegionName: string,
    nameLineOneText: string,
    nameLineTwoText: string,
    postalCode: string,
    streetAddressLineOneText: string,
    streetAddressLineTwoText: string
}