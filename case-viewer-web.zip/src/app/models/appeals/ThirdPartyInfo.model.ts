import WorkerModel from '../common/Worker.model';

export default interface ThirdPartyInfoModel {
    addressLineOneText: string,
    addressLineTwoText: string,
    cityName: string,
    customerNumber: string,
    geographicRegionCode: string,
    geographicRegionName: string,
    nameLineOneText: string,
    nameLineTwoText: string,
    postalCode: string,
    worker: WorkerModel
}