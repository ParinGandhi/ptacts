export default interface MilestoneDatesModel {
    appealBriefDate?: number,
    decisionDueDate?: number,
    decisionMailDate?: number,
    decisionRenderedDate?: number,
    disposedDate?: number,
    docketingNoticeDate?: number,
    docketingNoticeMailDate?: number,
    examinerAnswerDate?: number,
    filingDate?: number,
    hearingDate?: number,
    hearingStatus?: number,
    hearingTranscriptDate?: number,
    hearingTranscriptMailDate?: number
    noticeOfAppealDate?: number,
    noticeOfHearingDate?: number,
    noticeOfHearingMailDate?: number,
    oralHearingRequestDate?: number,
    receivedDate?: number,
    rehearingDecisionMailDate?: number,
    rehearingPaneledDate?: Array<number>,
    rehearingRenderedDate?: Array<number>,
    rehearingRequestDate?: Array<number>,
    rehearingRequestDueDate?: Array<number>,
    replyBriefDate?: number,
}




