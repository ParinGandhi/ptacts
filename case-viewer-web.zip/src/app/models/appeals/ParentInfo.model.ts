import InventorModel from '../common/Inventor.model';

export default interface ParentInfoModel {
    applicationNumberText: string,
    artClassNumber: string,
    artSubClassNumber: string,
    artUnit: string,
    inventionTitleText: string,
    inventors: Array<InventorModel>,
    techCenterNumber: string
}