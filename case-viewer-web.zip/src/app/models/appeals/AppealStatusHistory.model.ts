export default interface AppealStatusHistoryModel {
    sequenceNumber?: number,
    date?: number,
    typeCode?: string,
    serialNumber?: string,
    appealNumber?: number,
    aDsequenceNumber?: number,
    reconsiderSequenceNumber?: number,
    beginEffectiveDate?: number,
    endEffectiveDate?: number,
    lockControlNumber?: number,
    creditGrantedUserIdentifier?: string,
    lastModifiedUserIdentifier?: string,
    palmStatusMailedDate?: number,
    lastModifiedTimeStamp?: number,
    description?: string
}