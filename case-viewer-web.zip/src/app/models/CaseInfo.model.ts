export default interface CaseInfoModel {
    serialNo: string;
    proceedingNo: string;
    scrollToId?: string
}