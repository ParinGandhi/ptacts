export class GridApiMock {
    paginationSetPageSize = () => {};
    setFilterModel = () => {};
    getDisplayedRowCount = () => {
      return 5;
    };
    getFilterModel = () => {
        const filterModelMock = {
            status: {
                filter: "n",
                filterType: "text",
                type: "contains"
            }
        }
        return filterModelMock;
    };
    exportDataAsCsv = () => {};
    getSelectedRows = () => { };
    paginationGoToFirstPage = () => { };
    paginationGoToPreviousPage = () => { };
    paginationGoToNextPage = () => { };
    paginationGoToLastPage = () => { };
    paginationGetCurrentPage = () => {
        return 5;
    };
    paginationGoToPage = (pageToGo) => { };
    paginationGetTotalPages = () => {
        return 10;
    };
    sizeColumnsToFit = () => { };

constructor() {}
}