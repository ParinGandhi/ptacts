export class ToastrMock {
    success = (
        message?: string,
        title?: string
    ) => {};
    error = (
        message?: string,
        title?: string
    ) => {};

    constructor() {

    }
}