
 class jpViewData
{
    PROCEEDING_NO:string;
    INTERESTED_PARTY_NAME_TX:string;
    PROCEEDING_STATE_NM:string;
    PROCEEDING_FILING_DT:string;
    APJ2_WORKER_ID:string;
    PROCEEDING_TYPE_CT:string;
    PROCEEDING_STATUTORY_DT:number;
    INSTITUTION_DECISION_DT:number;
    ADDITIONAL_APJ_WORKER_ID_TX:Array<number>;
    APJ3_WORKER_ID:string;
    statutoryDateMinusYear:string;
    PATENT_NO:number;
    DECISION_DUE_DAYS:number;
    ATTORNEY_WORKER_ID:number;
    ID:string;
    PROCEEDING_STATUS_NM:string;
    APJ1_WORKER_ID:string;
    PROCEEDING_SUPPLEMENTARY_ID:string;
    PROCEEDING_CORE_ID:number;
    ALL_DISPOSITION_TX:string;
    APPEAL_SEQUENCE_NO:string;

}


export default interface jpViewModel {
    trialCertificateIssued:Array<jpViewData>;
       
  }
