export default interface PhysicalAddressModel {
    addressCategory: string;
    cityName: string;
    countryCode: string;
    countryName: string;
    geographicRegionCode: string;
    geographicRegionName: string;
    nameLineOneText: string;
    nameLineTwoText: string;
}