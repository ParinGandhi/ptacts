export default interface MailingAddressModel {
    addressType: string
    city: string,
    country: string,
    identifier: string,
    state: string,
    streetLineOneText: string,
    streetLineTwoText: string,
    zipCode: string,
}