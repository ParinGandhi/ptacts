export default interface ElectronicAddressModel {
    identifier: string,
    teleCommAddresType?: string,
    telephoneNumber?: string,
    email?: string,
    emailType?: string,
    extension: string,
    fax?: string
    // fax: string
}