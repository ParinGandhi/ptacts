import PhysicalAddress from "./PhysicalAddress.model";
export default interface AddressModel {
    emails: [];
    physicalAddress: Array<PhysicalAddress>;
    telecommunication: [];
}