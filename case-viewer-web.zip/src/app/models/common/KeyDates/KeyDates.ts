import { KeyDate } from "./KeyDate";

export class KeyDates {
    finalDecisionDueDate: KeyDate = new KeyDate();
    decisionToInstituteDate: KeyDate = new KeyDate();

    constructor() {

    }
}