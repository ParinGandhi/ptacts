export class KeyDate {
    propertyName = null;
    description = null;
    dateAsString = null;
    dateAsEpoch = null;

    constructor() {

    }
}