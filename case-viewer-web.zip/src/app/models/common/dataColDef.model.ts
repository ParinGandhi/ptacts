
export default interface  colDefModel {
    name: string,
    displayName: string,
    field: string,
    width: any,
    type: any,
    searchText: string,
    link: boolean,
    icon: any,
    count?: string
    tooltip?: any
}