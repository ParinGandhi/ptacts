export default interface GridRefreshModel {
    refreshFailed: boolean,
    showLoading: boolean,
    lastRefresh: number,
}