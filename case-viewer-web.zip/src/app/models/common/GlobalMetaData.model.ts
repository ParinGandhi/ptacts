import JudgeRankModel from './JudgeRank.model';

export default interface GlobalMetaDataModel {
    applicationNumber: string,
    caseNumber: string,
    parties: string,
    panel: Array<JudgeRankModel>
    briefHearingType: string,
    caseType: string,
    caseStatus: string,
    caseStatusDate: number
    applicationStatusDescriptionText: string,
    isMerge: boolean
}