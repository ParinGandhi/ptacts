import InterestedPartyModel from './InterestedParty.model';
import LifeCycleModel from './LifeCycle.model';
import OPSGAuditModel from './OPSGAudit.model';
import PersonModel from './Person.model';

export default interface InventorModel {
    audit: OPSGAuditModel,
    interestedParty: InterestedPartyModel,
    lifeCycle: LifeCycleModel,
    persons: PersonModel
}