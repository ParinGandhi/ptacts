export default interface JudgeRankModel {
    employeeName: string,
    rank: number
}