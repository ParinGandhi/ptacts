export default interface AuditModel {
    lastModifiedTimestamp: number,
    lastModifiedUserIdentifier: string,
    createUserIdentifier: string,
    createdUserName?: string,
    lastModifiedUserName?: string,
    createTimestamp?: number,
    lockControlNumber: number
}