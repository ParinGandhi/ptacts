import Address from "./Address/Address.model";

export default interface PersonModel {
    address: Address,
    firstName: string,
    identifier: string,
    lastName: string,
    middleName: string
}