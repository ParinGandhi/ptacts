export default interface InfoModalModel {
    infoText: Array<string>,
    title: string,
    showLeftBtn: boolean,
    leftBtnClass: string,
    leftBtnLabel: string
    showRightBtn: boolean,
    rightBtnClass: string,
    rightBtnLabel: string,
    isConfirm: boolean,
    modalHeight: number,
    showJoinderMessage?: boolean
}