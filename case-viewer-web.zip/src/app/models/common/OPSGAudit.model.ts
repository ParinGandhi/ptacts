export default interface OPSGAuditModel {
    lastModifiedTime: number,
    lastModifiedUser?: string
}