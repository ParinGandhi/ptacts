export default interface PanelJudgeModel {
    activeIndicator: string,
    identifier: string,
    firstName: string,
    lastName: string,
    activeJudgeIndicator: string,
    middleInitial: string,
    electronicAddress: Array<any>,
    prefferedName: string,
    rank: string,
    lifeCycle: any,
    audit: any
}