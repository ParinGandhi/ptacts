import colDefModel from './dataColDef.model';

export default interface DataTableModel {
    tableId: any,
    tableHeaderClass: any,
    tableBodyClass: any,
    checkboxClass?: string,
    columnDefs: Array<colDefModel>
    data: any
}
