import ElectronicAddressModel from "../Address/ElectronicAddress.model";
import MailingAddressModel from "../Address/MailingAddress.model"

export default interface PersonTypeModel {
    identifier: string,
    firstName: string,
    lastName: string,
    middleInitial?: string,
    prefferedName: string,
    mailingAddress: Array<MailingAddressModel>,
    electronicAddress: Array<ElectronicAddressModel>
}