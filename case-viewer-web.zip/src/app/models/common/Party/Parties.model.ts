import PersonTypeModel from "./PersonType.model";
import OrgTypeModel from "./OrgType.model";

export default interface PartiesModel {
    identifier: string,
    rankNo: string,
    partyType: string,
    partySubType: string,
    partySubTypeDescription: string,
    // partyReference: string,
    registrationNo: string,
    submitterType: string,
    personType: Array<PersonTypeModel>,
    orgType: Array<OrgTypeModel>
}