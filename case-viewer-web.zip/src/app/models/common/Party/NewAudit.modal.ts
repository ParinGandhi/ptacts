export class newAudit {
    lastModifiedUserIdentifier: string;
    createUserIdentifier: string
}