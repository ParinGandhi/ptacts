import { newAudit } from './NewAudit.modal';
import PartiesModel from "./Parties.model";

export default interface NewInterestedPartyModel {
    caseNo: string,
    proceedingSupplementaryIdList?: Array<string>,
    supplementaryIdType?: string,
    caseType?: string,
    identifier?: string,
    parties: Array<PartiesModel>,
    audit: newAudit,
}