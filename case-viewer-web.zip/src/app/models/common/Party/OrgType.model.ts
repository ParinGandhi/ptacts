import ElectronicAddressModel from "../Address/ElectronicAddress.model";
import MailingAddressModel from "../Address/MailingAddress.model"

export default interface OrgTypeModel {
    identifier: string,
    legalname: string,
    orgAddress: Array<MailingAddressModel>,
    electronicAddress: Array<ElectronicAddressModel>
}