export default interface JudgesModel {
    identifier: string,
    panelRank: number,
    panelType: string,
    hotellingIndicator: string,
    assignedDate: number,
    panelName: string,
    activeIndicator: string,
    panelMember: string,
    apjStatus: string,
    rulingCategory: string,
    panelSequenceNumber: number,
    reConsiderSeqNumber: number,
    lastModifiedTs: number,
    lastModifiedUserId: string,
    decisionCategoryName: string,
    location: string,
    assigneeStatus: string
}