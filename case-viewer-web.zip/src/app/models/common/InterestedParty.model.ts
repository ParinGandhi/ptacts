export default interface InterestedPartyModel {
    authorityType: string,
    interestedPartyType: string,
    partyIdentifier: string,
    referenceType: string,
    sequenceNumber: number
    status: string
}