export default interface AlertModel {
    showAlert: boolean,
    alertType: string,
    message: string,
}