export default interface WorkerModel {
    workerNumber?: string,
    activeIndicator: boolean,
    fullName?: string
}