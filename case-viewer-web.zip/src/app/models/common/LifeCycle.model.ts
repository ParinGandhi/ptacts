export default interface LifeCycleModel {
    beginDate: number
}