export default interface claims {
    ground?: any;
    challengedGroupClaimList?: any;
    priorArt?: string;
}

export class ClaimModel {

    claimData: Array<claims>;
   
}

export class claimUpload {
    asCaptured: any;
    category: any;
    statGroundId: any;
    identifier: any
}