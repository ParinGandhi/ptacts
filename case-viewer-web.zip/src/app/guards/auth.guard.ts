import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private store: Store<CaseViewerState>) {

  }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {
    let userInfo = null;
    this.store.pipe(select(CaseViewerSelectors.userInfoData)).subscribe(data => {
      userInfo = data.caseDetailsData[0];
    })
    if (!userInfo) {
      userInfo = JSON.parse(window.sessionStorage.getItem('userInfo'));
    }
    let boolVal = userInfo !== null;
    return boolVal;
  }

}
