// Arrange the imports in from node modules first and then local files and it should be in albhatical order
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Subscription } from 'rxjs';
import { take } from 'rxjs/operators';
import { Store, select } from '@ngrx/store';
import { DatePipe } from '@angular/common';
import { DocumentUpload } from '../models/document-upload';
import { Motion } from '../models/motion-model';
import { ConfirmDialogComponent } from '../shared/confirm-dialog/confirm-dialog.component';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { PtabTrialConstants } from "../constants/ptab-trials.constants";

import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import { JpViewService } from '../services/jpview.service';
import { TrialsService } from 'src/app/services/trials.service';
import { ToastrService } from 'ngx-toastr';
import { element } from 'protractor';
import AlertModel from '../models/common/Alert.model';
import { HttpEventType } from '@angular/common/http';
import { CommonUtilitiesService } from '../services/common-utilities.service';
import InfoModalModel from '../models/common/InfoModal.model';
import { CommonService } from '../services/common.service';
//declare let $: any;

@Component({
  selector: 'app-document-upload',
  templateUrl: './document-upload.component.html',
  styleUrls: ['./document-upload.component.less']
})

export class DocumentUploadComponent implements OnInit {
  // maintain the proper order
  global = {
    rangeForBoard: {
      min: PtabTrialConstants.EXHIBIT_RANGE.MIN.BOARD,
      max: PtabTrialConstants.EXHIBIT_RANGE.MAX.BOARD
    },
    rangeForPO: {
      min: PtabTrialConstants.EXHIBIT_RANGE.MIN.PO,
      max: PtabTrialConstants.EXHIBIT_RANGE.MAX.PO
    },
    rangeForPetitioner: {
      min: PtabTrialConstants.EXHIBIT_RANGE.MIN.PETITIONER,
      max: PtabTrialConstants.EXHIBIT_RANGE.MAX.PETITIONER
    },
    upload: {
      maxSize: PtabTrialConstants.UPLOAD.MAX_SIZE,
      acceptableTypes: PtabTrialConstants.UPLOAD.DEFAULT_TYPE,
      paperMimeTypes: PtabTrialConstants.UPLOAD.DEFAULT_TYPE,
      paperMimeTypeList: [PtabTrialConstants.UPLOAD.DEFAULT_TYPE],
      exhibitMimeTypes: PtabTrialConstants.UPLOAD.DEFAULT_TYPE,
      exhibitMimeTypeList: [PtabTrialConstants.UPLOAD.DEFAULT_TYPE],
      invalidChars: PtabTrialConstants.UPLOAD.INVALID_CHARS
    },
    edit: {
      enableEdit: false,
      editIndex: null,
      originalRow: {},
      rowToEdit: null
    },
    exhibitNumberSequence: {
      board: null,
      po: null,
      petitioner: null
    }
  };
  alert = false;
  alertMessage: string = null;
  fileFormat: string;
  selectedPaperType: string = null;
  selectedFilingParty: string = "BOARD";
  selectedAvailability: string;
  fileToUpload: any;
  petitionerIdentifier: number;
  patentNumber: any;
  subSetPapers:boolean;
  caseMotions:any[];
  caseRehearings:any[];

  // typecast
  fileByteArray: any[];
  validationObject = {
    paper: {
      paperType: false,
      filingParty: false,
      availability: false,
      documentName: false,
      fileName: false,
      paperTypeParameter1:false,
      paperTypeParameter2:false,
      paperTypeParameter3:false,
    },
    exhibits: {
      filingParty: false,
      exhibitNumber: false,
      availability: false,
      fileName: false,
      documentName: false,
      range1000: false,
      range2000: false,
      range3000: false
    }
  };

  options = {
    multiple: false,
    closeOnSelect: true,
    width: '100%',
    allowClear: true,
    theme: 'bootstrap',
    openOnEnter: true,
    // minimumResultsForSearch: Infinity - use to hide search box
  }

  option: any;
  fileName: string;
  subscriptions: Subscription[] = [];
  documentUploadObj: DocumentUpload = {
    name: null,
    category: "Paper",
    documentTypeCode: "",
    motions:[]
  };

  motionActions:number = 0;
  rehearingActions:number = 0;
  hasMotions:boolean = false;
  hasRehearings:boolean = false;
  hasNOFDA:boolean = false;
  selectedCases: Array<any> = [];
  paperTypeControls: Array<any> = [];
  paperDocumentTypes: Array<any> = [];
  editModeFromUpdate:boolean=false;
  editedIndex:number=-1;
  anItem:any;
  documentUploadObjList: Array<DocumentUpload> = [];
  documentUploadObjListBkup: Array<DocumentUpload> = [];
  paperTypeList: Array < any > ;
  paperTypeFullList: Array < any > ;
  paperTypeSubList: Array<any>;
  allPapersList: Array<any>;
  showJoinderDropdown = false;
  relatedCases: any = null;
  selectedRelatedCase = null;
  relatedProceedingNo = null;
  joinderType: string = null;
  joinderTypeCode: string = null;

  paperTypeListBRD: Array < any > ;
  paperTypeFullListBRD: Array < any >= [] ;
  paperTypeSubListBRD: Array < any > ;

  paperTypeListPO: Array < any > ;
  paperTypeFullListPO: Array < any >= [] ;
  paperTypeSubListPO: Array < any > ;

  paperTypeListPET: Array < any > ;
  paperTypeFullListPET: Array < any >= [] ;
  paperTypeSubListPET: Array < any > ;

  filingPartyList: Array < any > ;
  availabilityList: Array < any > ;
  availabilityListOriginal: Array < any > ;
  typeAheadOptions: any;
  paperTypeListResponse: any;
  bsModalRef: BsModalRef
  loggedInUser = null;
  adminLoggedIn = false;
  alertOptions: AlertModel;

  modal: any;
  addingToList: boolean = false;
  saving: boolean = false;
  failed: boolean = false;
  loadingMotions:boolean = false;
  loadingRehearings:boolean = false;
  editMotions:Array < any > =[];
  editRehearings:Array < any > =[];
  shouldJoinCases = false;
  acceptedJoinderStateChange = false;
  isJoinedCase = false;
  joinderOrginalIndicator: string = null;

  popoverContent: string = `<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>`;



  // all private variables should be prefixed with _
  constructor(
    private modalService: BsModalService,
    private store: Store<CaseViewerState>,
    private jpviewService: JpViewService,
    private trialsService: TrialsService,
    private commonService: CommonService,
    private toastr: ToastrService,
   private commonUtils: CommonUtilitiesService
  ) { }
  ngOnInit(): void {
 /*    try {
      $('#fileToolTip').popover()
    } catch (error) {

    } */


    this.store.pipe(select(CaseViewerSelectors.caseInfoData)).pipe(take(1)).subscribe((value) => {
      this.documentUploadObj.proceedingNumberText = value.proceedingNo;
    })

    this.store.pipe(select(CaseViewerSelectors.userInfoData)).subscribe(data => {
      this.loggedInUser = data.caseDetailsData[0];
      if (!this.loggedInUser) {
        this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
      }
    })


    this.typeAheadOptions = {
      multiple: false,
      closeOnSelect: true,
      width: '100%',
      allowClear: true,
      theme: 'bootstrap',
      minimumResultsForSearch: Infinity
    }

    this.joinderTypeCode = PtabTrialConstants.JOINDER_TYPE_CODE;

    this.getPaperTypeList();
    this.getMimeTypes();
    this.getPetitionIdentifier();
    this.getPaperDocs();
    this.getFilingPartyTypeList();
    this.getAvailabilityList();
    this.getNextExhibitNumber();
    this.getJoinderInfo();
  }

  getMotions(motions:string) {
    this.loadingMotions=true;
    // this.jpviewService.getTrialsInfo(`${PtabTrialConstants.TRIAL_SERVICES_URL}/partytype/motionstatus-info?proceedingNumber=${this.documentUploadObj.proceedingNumberText}&typeIds=${motions}`).subscribe((motionsResponse) => {
    this.trialsService.getTrialsInfo(`/partytype/motionstatus-info?proceedingNumber=${this.documentUploadObj.proceedingNumberText}&typeIds=${motions}`).subscribe((motionsResponse) => {
      this.caseMotions=[]
      let caseMotionsToCheck = motionsResponse;
      let i:number = 0;
      caseMotionsToCheck.forEach(element => {
        if (element.motionStatusName === 'PENDING REVIEW') {
          this.hasMotions=true;
          if ( this.editMotions.length>i) {
            element.action = this.editMotions[i].action;
          } else {
            element.action="No action";
          }
          this.caseMotions.push(element);
        }
        i++;

      });

    });

    this.loadingMotions=false;
  }

  getMotionValue() {
    this.motionActions=0;
    if (!this.caseMotions) {
      return;
    }
    this.caseMotions.forEach(element => {
      if (element.action !== 'No action') {
        this.motionActions++;
      }
    });
    return this.motionActions + " out of " + this.caseMotions.length + " motion(s) will be closed";
  }

  getRehearings(rehearings:string) {
    this.loadingRehearings=true;
    this.trialsService.getTrialsInfo(`/rehearing-info?status=Pending Review&proceedingNumber=${this.documentUploadObj.proceedingNumberText}&typeIds=${rehearings}`).subscribe((rehearingsResponse) => {
    // this.jpviewService.getTrialsInfo(`/rehearing-info?status=Pending Review&proceedingNumber=${this.documentUploadObj.proceedingNumberText}&typeIds=${rehearings}`).subscribe((rehearingsResponse) => {
      this.caseRehearings=[]
      let caseRehearingsToCheck = rehearingsResponse;
      let i:number = 0;
      caseRehearingsToCheck.forEach(element => {

          this.hasRehearings=true;
          if ( this.editRehearings.length>i) {
            element.action = this.editRehearings[i].action;
          } else {
            element.action="No action";
          }
          this.caseRehearings.push(element);

        i++;

      });

    });

    this.loadingRehearings=false;
  }

  getRehearingValue() {
    this.rehearingActions=0;
    if (!this.caseRehearings) {
      return;
    }
    this.caseRehearings.forEach(element => {
      if (element.action !== 'No action') {
        this.rehearingActions++;
      }
    });
    return this.rehearingActions + " out of " + this.caseRehearings.length + " rehearing(s) will be closed";
  }

  getDateString(milleseconds) {
    if (milleseconds && milleseconds !== "") {
      const datepipe: DatePipe = new DatePipe('en-US');
      // let aDate = new Date(0); // The 0 there is the key, which sets the date to the epoch
      // aDate.setUTCSeconds(milleseconds);
      // return datepipe.transform(aDate, 'yyyy-MM-dd');
      return datepipe.transform(milleseconds, 'yyyy-MM-dd');
    } else {
      return null;
    }
  }

  getPaperTypeComponents(value) {

    if (!value) {
      this.paperTypeControls=[];

      return;
    }

    this.paperTypeControls=[];

    this.paperTypeList.forEach(paperType => {
      if (paperType.code===value) {
        if (paperType.documentTypeCustomAttributes) {
          if (paperType.documentTypeCustomAttributes.attributes) {





            // paperType.documentTypeCustomAttributes.attributes = [{
            //   "id": 21,
            //   "label": "CAFC mandate date*",
            //   "dataType": "date",
            //   "uielementId": "ID_CAFC_MNDT",
            //   "value": "",
            //   "mandatory": false,
            //   "visibility": true,
            //   "userpicklist": {
            //     "dataType": "dropdown",
            //     "label": "Fed circuit judgement type",
            //     "refattribute": "outcomeTypeId",
            //     "values": [{
            //       "id": 24,
            //       "text": "Dismissed"
            //     }, {
            //       "id": 21,
            //       "text": "Affirmed"
            //     }, {
            //       "id": 22,
            //       "text": "Reversed"
            //     }, {
            //       "id": 25,
            //       "text": "Voluntarily Dismissed"
            //     }, {
            //       "id": 23,
            //       "text": "Affirmed/Reversed in Part"
            //     }, {
            //       "id": 26,
            //       "text": "Vacated/Remanded"
            //     }, {
            //       "id": 27,
            //       "text": "Remanded-in part"
            //     }]
            //   },

            //   "outcomeTypeId": 0,
            //   "rolesForEdit": [
            //     "Supervisor",
            //     "Paralegal/LIE"
            //   ]
            // },
            //   {
            //     "id": 20,
            //     "label": "CAFC decision date*",
            //     "dataType": "date",
            //     "uielementId": "ID_CAFC_DCDT",
            //     "value": "11",
            //     "mandatory": false,
            //     "visibility": true,
            //     "rolesForEdit": [
            //       "Paralegal/LIE",
            //       "Supervisor",
            //       "Patent Attorney",
            //       "Business Administrator",
            //       "Judge"
            //     ]
            //   }
            // ];


            let parameterNum=1;
            const datepipe: DatePipe = new DatePipe('en-US');
            paperType.documentTypeCustomAttributes.attributes.forEach(customAttribute => {


              if (customAttribute.dataType === 'date') {
                if (parameterNum===1) {
                  this.documentUploadObj.paperTypeParameter1=this.getDateString(customAttribute.value);
                  parameterNum++;
                } else if (parameterNum===2) {
                  this.documentUploadObj.paperTypeParameter2=this.getDateString(customAttribute.value);
                  parameterNum++;
                } else if (parameterNum===3) {
                  this.documentUploadObj.paperTypeParameter3=this.getDateString(customAttribute.value);
                }
              }


              if (!customAttribute.hasOwnProperty('visibility') || customAttribute.visibility === true) {
                customAttribute.visibility = true;
              } else {
                customAttribute.visibility = false;
              }

              customAttribute.readOnly=this.checkPermission(customAttribute);
              this.paperTypeControls.push(customAttribute);

            });
          }

        }
      }
    });
  }


  filterAvailabilityList(value) {
    if (value) {
      let availableFilterFound = false;
      this.paperTypeList.forEach(paperType => {
        if (paperType.code===value) {
          if (paperType.availableFilters && paperType.availableFilters.length > 0) {
            availableFilterFound = true;
            paperType.availableFilters.forEach((filterItem) => {
              console.log('filterItem: ', filterItem);
              console.log("Availability list:", this.availabilityList);
              let indexToRemove = this.availabilityList.map((item) => {
                return item.code;
              }).indexOf(filterItem.code);
              if (indexToRemove >= 0) {
                this.availabilityList.splice(indexToRemove, 1);
              }
            });
            let foundPublic = this.availabilityList.find((element) => element.code === "BOARD");
        this.selectedAvailability = foundPublic ? foundPublic.code : null;
        this.documentUploadObj.availability = foundPublic ? foundPublic.displayNameText : null;
          }
        }
      });
      if (!availableFilterFound) {
        this.availabilityList = [...this.availabilityListOriginal];
         let foundPublic = this.availabilityList.find((element) => element.code === "PUBLIC");
        this.selectedAvailability = foundPublic ? foundPublic.code : null;
        this.documentUploadObj.availability = foundPublic ? foundPublic.displayNameText : null;
      }
    }
  }


  checkPermission(attribute:any) {
    if (!attribute.rolesForEdit) {
      return true;
    }

    if (attribute.rolesForEdit.length == 0) {
      return true;
    }

    if (this.loggedInUser) {
      return !attribute.rolesForEdit.includes(this.loggedInUser.roleDescription);
    } else {
      return true;
    }

  }

  getMimeTypes() {
    if (!this.loggedInUser) {
      this.adminLoggedIn=false;
    } else {
      this.adminLoggedIn = this.loggedInUser.roleDescription === PtabTrialConstants.ROLES.ADMIN || this.loggedInUser.roleDescription === PtabTrialConstants.ROLES.SPL;
    }

    if (this.adminLoggedIn) {
      // this.jpviewService.getMimeTypes(`${PtabTrialConstants.COMMON_SERVICES_URL}/references?typeCode=mimeTypes`).subscribe((mimeTypesResponse) => {
      this.commonService.getFromCodeReference(PtabTrialConstants.REFERENCE_TYPES.MIME_TYPES).subscribe((mimeTypesResponse) => {
        this.global.upload.exhibitMimeTypeList = [];
        mimeTypesResponse.forEach(element => {
          this.global.upload.exhibitMimeTypeList.push(element.code);
        });
        this.global.upload.exhibitMimeTypes = this.global.upload.exhibitMimeTypeList.join();
      })
    }
  }

  getPetitionIdentifier() {
    // this.jpviewService.getCaseInfoByProceedingNo(`${PtabTrialConstants.COMMON_SERVICES_URL}/petitions?proceedingNumberText=${this.documentUploadObj.proceedingNumberText}`).subscribe((caseInfoByProceedingResponse) => {
    this.commonService.getCaseInfoByProceedingNo(this.documentUploadObj.proceedingNumberText).subscribe((caseInfoByProceedingResponse) => {
      this.petitionerIdentifier = caseInfoByProceedingResponse.petitionIdentifier;
      // this.patentNumber = caseInfoByProceedingResponse.patentNumber;
      const caseInfo = JSON.parse(window.sessionStorage.getItem('caseInfo'));
    this.patentNumber = caseInfo.patentNumberText;
    });

  }

  // Store paper type for selecrted filing party
  storeFetchedData() {
    switch(this.selectedFilingParty) {
      case "BOARD":
        this.paperTypeSubListBRD = this.paperTypeSubList;
        this.paperTypeFullListBRD = this.paperTypeFullList;
        this.paperTypeListBRD = this.paperTypeList;
        break;
      case "PATENT OWNER":
        this.paperTypeSubListPO = this.paperTypeSubList;
        this.paperTypeFullListPO = this.paperTypeFullList;
        this.paperTypeListPO = this.paperTypeList;
        break;
      case "PETITIONER":
        this.paperTypeSubListPET = this.paperTypeSubList;
        this.paperTypeFullListPET = this.paperTypeFullList;
        this.paperTypeListPET = this.paperTypeList;
        break;
      default:
        break;
    }
  }

  // If paper type for selected filing party has already been filled by service call.  Don't call again.
  getFetchedData() {
    switch(this.selectedFilingParty) {
      case "BOARD":
        if (this.paperTypeFullListBRD.length > 0) {
          this.paperTypeSubList = this.paperTypeSubListBRD;
          this.paperTypeFullList = this.paperTypeFullListBRD;
          this.paperTypeList = this.paperTypeListBRD;
          return true;
        }
        break;
      case "PATENT OWNER":
        if (this.paperTypeFullListPO.length > 0) {
          this.paperTypeSubList = this.paperTypeSubListPO;
          this.paperTypeFullList = this.paperTypeFullListPO;
          this.paperTypeList = this.paperTypeListPO;
          return true;
        }
        break;
      case "PETITIONER":
        if (this.paperTypeFullListPET.length > 0) {
          this.paperTypeSubList = this.paperTypeSubListPET;
          this.paperTypeFullList = this.paperTypeFullListPET;
          this.paperTypeList = this.paperTypeListPET;
          return true;
        }
        break;
      default:
        break;
    }
    return false;
  }

  getPartyType() {
    if (!this.selectedFilingParty) {
      return "BOARD";
    }
    return this.selectedFilingParty
  }
  getPaperTypeList() {
    if (this.getFetchedData()) {
      return;
    }
    let partyType = this.getPartyType();
    // this.jpviewService.getDropDownList(`${PtabTrialConstants.COMMON_SERVICES_URL}/references/proceeding-number?typeCode=documentTypes&proceedingNumber=${this.documentUploadObj.proceedingNumberText}&recipientType=${partyType}`).subscribe((paperTypeListResp) => {
    this.commonService.getPaperTypes(this.documentUploadObj.proceedingNumberText, partyType).subscribe((paperTypeListResp) => {
      this.processPaperTypeResonseServiceCall(paperTypeListResp);
    }, () => {
      this.toastr.error(`Unable to retrieve Paper type list.`, "", {
        closeButton: true
      });
    });
  }

  // This gets the list of filing parties for the drop down
  getFilingPartyTypeList() {
    // this.jpviewService.getDropDownList(`${PtabTrialConstants.COMMON_SERVICES_URL}/references?typeCode=proxySubmitterRoleType`).subscribe((filingPartyTypeListResp) => {
    this.commonService.getDropDownList(PtabTrialConstants.REFERENCE_TYPES.FILING_PARTY).subscribe((filingPartyTypeListResp) => {
      if (filingPartyTypeListResp && filingPartyTypeListResp.length > 0) {
        this.filingPartyList = filingPartyTypeListResp;
        let foundBoard = this.filingPartyList.find((element) => element.code === "BOARD");
        this.selectedFilingParty = foundBoard ? foundBoard.code : null;
        this.documentUploadObj.filingParty = foundBoard ? foundBoard.displayNameText : null;
      }
    }, () => {
      this.toastr.error(`Unable to retrieve Filing party list.`, "", {
        closeButton: true
      });
    });
  }

  processPaperTypeResonseServiceCall(paperTypeListResp) {
    if (paperTypeListResp && paperTypeListResp.moreDocumetnTypes &&  paperTypeListResp.moreDocumetnTypes.length > 0) {

      this.paperTypeListResponse = paperTypeListResp.moreDocumetnTypes;
      this.paperTypeFullList = paperTypeListResp.moreDocumetnTypes;

      if (paperTypeListResp.stateDocumentTypes && paperTypeListResp.stateDocumentTypes.length>0) {
        this.paperTypeSubList = paperTypeListResp.stateDocumentTypes;

        this.paperTypeSubList.forEach(paperType => {
          this.paperTypeFullList.push(paperType);
          paperType.id = paperType.code;
          if (this.hasNOFDA) {
            if (paperType.code.indexOf("NOFDA")>=0 || paperType.code.indexOf("DEFCTPET")>=0) {
              paperType.disabled=true;
            }
          }
          paperType.text = paperType.displayNameText;
        });
      }

      this.paperTypeFullList.forEach(paperType => {
        paperType.id = paperType.code;
        if (this.hasNOFDA) {
          if (paperType.code.indexOf("NOFDA")>=0 || paperType.code.indexOf("DEFCTPET")>=0) {
            paperType.disabled=true;
          }
        }
        paperType.text = paperType.displayNameText;
        if (paperType.documentTypeCustomAttributes && paperType.documentTypeCustomAttributes.motionTypeIds ) {
          if (paperType.documentTypeCustomAttributes.motionTypeIds.length>0) {
            this.getMotions(paperType.documentTypeCustomAttributes.motionTypeIds.join());
          }
        }
        if (paperType.documentTypeCustomAttributes && paperType.documentTypeCustomAttributes.rehearingIds ) {
          if (paperType.documentTypeCustomAttributes.rehearingIds.length>0) {
            this.getRehearings(paperType.documentTypeCustomAttributes.motionTypeIds.join());
          }
        }
      });
      this.paperTypeFullList.sort((a, b) => (a.displayNameText > b.displayNameText) ? 1 : -1);

      if (paperTypeListResp.stateDocumentTypes && paperTypeListResp.stateDocumentTypes.length>0) {
        this.subSetPapers=true;
        this.paperTypeSubList.forEach(paperType => {
          paperType.id = paperType.code;
          if (this.hasNOFDA) {
            if (paperType.code.indexOf("NOFDA")>=0 || paperType.code.indexOf("DEFCTPET")>=0) {
              paperType.disabled=true;
            }
          }
          paperType.text = paperType.displayNameText;
        });
        let moreType = {
          text:"More...",
          id:"morePaperType"
        };
        this.paperTypeSubList.push(moreType);
        this.paperTypeList = this.paperTypeSubList;
        this.paperTypeListResponse = this.paperTypeSubList;
      } else {
        this.paperTypeList = this.paperTypeFullList;
        this.paperTypeListResponse = this.paperTypeFullList;
      }

      this.storeFetchedData();

    }
  }

  getAvailabilityList() {
    // this.jpviewService.getDropDownList(`${PtabTrialConstants.COMMON_SERVICES_URL}/references?typeCode=availability`).subscribe((availabilityListResp) => {
      this.commonService.getDropDownList(PtabTrialConstants.REFERENCE_TYPES.AVAILABILITY).subscribe((availabilityListResp) => {
      if (availabilityListResp && availabilityListResp.length > 0) {
        this.availabilityList = availabilityListResp;
        this.availabilityListOriginal = [...availabilityListResp];
        let foundPublic = this.availabilityList.find((element) => element.code === "PUBLIC");
        this.selectedAvailability = foundPublic ? foundPublic.code : null;
        this.documentUploadObj.availability = foundPublic ? foundPublic.displayNameText : null;
      }
    }, () => {
      this.toastr.error(`Unable to retrieve Availability list.`, "", {
        closeButton: true
      });
    });
  }


  close(refreshValue) {
    if (this.documentUploadObjList && this.documentUploadObjList.length > 0) {
      this.openAbandonChangesModal();
    } else {
      this.modal.isConfirm = refreshValue;
      this.modalService.hide();
    }
  }


  fileChangeEvent(e) {
    if (this.editModeFromUpdate) {
      return;
    }
    let regex = /[‘!@#$%^&*(){}|]/g;
    let validFileName;
    let fileSizeInMB;
    this.alert = false;
    this.fileToUpload = e.target.files[0];
    this.fileName = e.target.files[0].name;
    this.fileFormat = this.fileName.substr(this.fileName.lastIndexOf('.') + 1).split('.')[0];
    fileSizeInMB = (e.target.files[0].size / (1024 * 1024)).toFixed(2);
    this.documentUploadObj.fileName = this.fileName.substr(this.fileName.lastIndexOf('\\') + 1).split('.')[0];
    this.documentUploadObj.mimeType = e.target.files[0].type;
    validFileName = this.fileName.match(regex);
    if (this.documentUploadObj.category === 'Paper') {
      if (!this.global.upload.paperMimeTypeList.includes(e.target.files[0].type)) {
        this.setAlert(true, 'danger', `.${this.fileFormat} is an invalid file format. Choose a file with the correct format.`);
        this.clearFile();
      }
    } else if (this.documentUploadObj.category === 'Exhibit') {
      if (!this.global.upload.exhibitMimeTypeList.includes(e.target.files[0].type)) {
        this.setAlert(true, 'danger', `.${this.fileFormat} is an invalid file format. Choose a file with the correct format.`);
        this.clearFile();
      }
    }
    if (validFileName && validFileName.length > 0) {
      this.setAlert(true, 'danger', `Special characters not allowed in filename: ${this.global.upload.invalidChars}`);
      this.clearFile();
    } else if (fileSizeInMB > 100.00) {
      this.setAlert(true, 'danger', `File size is ${fileSizeInMB} MB. Maximum file size allowed is ${this.global.upload.maxSize}`);
      this.clearFile();
    }
  }


  addToList() {
    console.log(this.documentUploadObj);
    if (this.isJoinedCase &&  this.documentUploadObj.tempDocument && this.documentUploadObj.tempDocument.code.toLowerCase() === this.joinderTypeCode.toLowerCase()) {
      this.setAlert(true, 'danger', `"${this.documentUploadObj.documentTypeCode}" paper type cannot be added to a joined case.`);
      return;
    }
    if (this.checkForMultipleJoinedDocuments()) {
      this.setAlert(true, 'danger', `"${this.documentUploadObj.documentTypeCode}" paper type has already been added to the list. Multiple "${this.documentUploadObj.documentTypeCode}" paper types cannot be added.`);
      return;
    }
    if (this.checkMultipleStateChangingDocuments()) {
      if (this.documentUploadObj && this.documentUploadObj.tempDocument && this.documentUploadObj.tempDocument.significantIndicator.toLowerCase() === 'y') {
        this.setAlert(true, 'danger', 'System cannot upload more than one document that changes the status.');
        return;
      }
    }
    if (this.validateForm()) {
      return;
    }
    if (this.documentUploadObj.availability.toLowerCase() == 'public' || this.documentUploadObj.availability.toLowerCase() == 'available for everyone.') {
      this.openConfirmPublicDocumentModal(true);
    } else {
      this.pushToList();
    }
  }


  checkMultipleStateChangingDocuments() {
    console.log(this.documentUploadObjList);
    let significantDocExists = false;
    if (this.documentUploadObjList && this.documentUploadObjList.length > 0) {
      this.documentUploadObjList.forEach((doc) => {
        if (doc.tempDocument && doc.tempDocument.significantIndicator.toLowerCase() === 'y') {
          significantDocExists = true;
        }
      });
    }
    return significantDocExists;
  }


  openConfirmPublicDocumentModal(add) {
    let modal: InfoModalModel = {
            infoText: ["Document can be viewed by the public unless a different option is chosen"],
            title: "Make document public?",
            showLeftBtn: true,
            leftBtnClass: 'btn-default',
            leftBtnLabel: 'No, change availability',
            showRightBtn: true,
            rightBtnClass: 'btn-primary',
            rightBtnLabel: 'Yes, make it public',
            isConfirm: false,
            modalHeight: 120
      }
      let response = this.commonUtils.openConfirmModal(modal);
      if (!response.onHide) {
        return;
      }
      response.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        if (add) {
          this.pushToList();
        } else {
          this.updateTheObject();
        }

      }
    })
  }

  openAbandonChangesModal() {
    let response = this.commonUtils.openAbandonChangesModal('You have document information that has not been saved to the docket.');
    response.onHide.pipe(take(1)).subscribe((reason: string | any) => {
         if (reason.initialState.modal.isConfirm) {
        this.modalService.hide();
      }
    })
  }

  checkPaperParamters() {
    if (this.paperTypeControls[0]) {
      if (!this.paperTypeControls[0].mandatory) {
        this.validationObject.paper.paperTypeParameter1 = false;
      } else {
        this.validationObject.paper.paperTypeParameter1 = this.checkFormModel(this.documentUploadObj.paperTypeParameter1) && this.paperTypeControls[0].mandatory;
        if (this.paperTypeControls[0].hasOwnProperty("userpicklist") && !this.validationObject.paper.paperTypeParameter1 && this.paperTypeControls[0].hasOwnProperty("userpicklist")) {
          this.validationObject.paper.paperTypeParameter1 = (typeof (this.paperTypeControls[0].outcomeTypeId) !== 'string');
        }
      }
    } else {
      return false;
    }

    if (this.paperTypeControls[1]) {
      if (!this.paperTypeControls[1].mandatory) {
        this.validationObject.paper.paperTypeParameter2 = false;
      } else {
        this.validationObject.paper.paperTypeParameter2 = this.checkFormModel(this.documentUploadObj.paperTypeParameter2)  && this.paperTypeControls[1].mandatory;
      }
    } else {
      this.validationObject.paper.paperTypeParameter2 = false;
    }

    if (this.paperTypeControls[2]) {
      if (!this.paperTypeControls[2].mandatory) {
        this.validationObject.paper.paperTypeParameter3 = false;
      } else {
        this.validationObject.paper.paperTypeParameter3 = this.checkFormModel(this.documentUploadObj.paperTypeParameter3 && this.paperTypeControls[2].mandatory);
      }
    } else {
      this.validationObject.paper.paperTypeParameter3 = false;
    }

    return this.validationObject.paper.paperTypeParameter1 || this.validationObject.paper.paperTypeParameter2 || this.validationObject.paper.paperTypeParameter3;
  }
  validateForm() {
    if (this.documentUploadObj.category === 'Paper') {
      this.validationObject.paper.filingParty = this.checkFormModel(this.documentUploadObj.filingParty);
      this.validationObject.paper.availability = this.checkFormModel(this.documentUploadObj.availability);
      this.validationObject.paper.fileName = this.checkFormModel(this.documentUploadObj.fileName);
      this.validationObject.paper.paperType = this.checkFormModel(this.documentUploadObj.documentTypeCode);
      this.validationObject.paper.documentName = this.checkFormModel(this.documentUploadObj.name);
      return this.validationObject.paper.paperType || this.validationObject.paper.documentName || this.validationObject.paper.filingParty || this.validationObject.paper.availability || this.validationObject.paper.fileName || this.checkPaperParamters();
    } else if (this.documentUploadObj.category === 'Exhibit') {
      this.validationObject.exhibits.filingParty = this.checkFormModel(this.documentUploadObj.filingParty);
      this.validationObject.exhibits.availability = this.checkFormModel(this.documentUploadObj.availability);
      this.validationObject.exhibits.fileName = this.checkFormModel(this.documentUploadObj.fileName);
      this.validationObject.exhibits.exhibitNumber = this.checkFormModel(this.documentUploadObj.exhibitNumber);
      if (!this.validationObject.exhibits.exhibitNumber) {
        this.validationObject.exhibits.range1000 = this.validateExhibitNumberRange(this.documentUploadObj.exhibitNumber, this.selectedFilingParty);
        this.validationObject.exhibits.range2000 = this.validateExhibitNumberRange(this.documentUploadObj.exhibitNumber, this.selectedFilingParty);
        this.validationObject.exhibits.range3000 = this.validateExhibitNumberRange(this.documentUploadObj.exhibitNumber, this.selectedFilingParty);
      }
      this.validationObject.exhibits.documentName = this.checkFormModel(this.documentUploadObj.name);
      return this.validationObject.exhibits.exhibitNumber || this.validationObject.exhibits.documentName || this.validationObject.exhibits.filingParty || this.validationObject.exhibits.availability || this.validationObject.exhibits.fileName || this.validationObject.exhibits.range1000 || this.validationObject.exhibits.range2000 || this.validationObject.exhibits.range3000;
    }
  }

  checkFormModel(formModel) {
    if (!formModel) {
      return true;
    }
    return false;
  }

  validateExhibitNumberRange(exhibitNumber, filingParty) {
    if (filingParty.toLowerCase() === 'board') {
      return exhibitNumber < this.global.rangeForBoard.min || exhibitNumber > this.global.rangeForBoard.max;
    } else if (filingParty.toLowerCase() === 'patent owner') {
      return exhibitNumber < this.global.rangeForPO.min || exhibitNumber > this.global.rangeForPO.max;
    } else if (filingParty.toLowerCase() === 'petitioner') {
      return exhibitNumber < this.global.rangeForPetitioner.min || exhibitNumber > this.global.rangeForPetitioner.max;
    } else {
      return false;
    }
  }

  validateExhibitNumberOnBlur(exhibitNumber, filingParty) {
    this.validationObject.exhibits.range1000 = this.validateExhibitNumberRange(exhibitNumber, filingParty);
        this.validationObject.exhibits.range2000 = this.validateExhibitNumberRange(exhibitNumber, filingParty);
        this.validationObject.exhibits.range3000 = this.validateExhibitNumberRange(exhibitNumber, filingParty);
  }

  resetForm(category) {
    this.global.edit.enableEdit=false;
    let tempProceedingNo = this.documentUploadObj.proceedingNumberText;

    this.documentUploadObj = {
      name: "",
      category: category,
      data: [],
      fileName: "",
      documentTypeCode: "",
      availability: "",
      filingParty: "",
      proceedingNumberText: tempProceedingNo,
      motions:[],
      rehearings:[]
    };
    this.selectedPaperType = null;
    let foundBoard = this.filingPartyList.find((element) => element.code === "BOARD");
    this.selectedFilingParty = foundBoard ? foundBoard.code : null;
    this.documentUploadObj.filingParty = foundBoard ? foundBoard.displayNameText : null;
    this.documentUploadObj.exhibitNumber = this.global.exhibitNumberSequence.board;
    let foundPublic = this.availabilityList.find((element) => element.code === "PUBLIC");
    this.selectedAvailability = foundPublic ? foundPublic.code : null;
    this.documentUploadObj.availability = foundPublic ? foundPublic.displayNameText : null;
    setTimeout(() => {
      (<HTMLInputElement>document.getElementById("file")).value = "";
    }, 200);
    this.fileName = null;
    this.alertOptions = {
      showAlert: false,
      alertType: null,
      message: null
    };

    this.paperTypeControls = [];
    this.global.upload.acceptableTypes = category === 'Exhibit' ? this.global.upload.exhibitMimeTypeList.join() : this.global.upload.paperMimeTypeList.join();
    this.showJoinderDropdown = false;
    // this.selectedRelatedCase = null;
    this.joinderType = null;
    this.resetValidation();
  }

  resetValidation() {
    this.validationObject = {
      paper: {
        paperType: false,
        filingParty: false,
        availability: false,
        documentName: false,
        fileName: false,
        paperTypeParameter1:false,
        paperTypeParameter2:false,
        paperTypeParameter3:false
      },
      exhibits: {
        filingParty: false,
        exhibitNumber: false,
        availability: false,
        fileName: false,
        documentName: false,
        range1000: false,
        range2000: false,
        range3000: false
      }
    };
  }

  pushToList() {
    this.addingToList = true;
    // this.jpviewService.uploadDocuments(`${PtabTrialConstants.COMMON_SERVICES_URL}/petitions/${this.petitionerIdentifier}/documents`, this.fileToUpload).subscribe(data => {
    this.commonService.uploadDocuments(`/petitions/${this.petitionerIdentifier}/documents`, this.fileToUpload).subscribe(data => {
      this.addingToList = false;
      this.failed = false;
      if (this.documentUploadObj.category === 'Exhibit') {
        this.documentUploadObj.documentTypeCode = 'N/A';
        this.storePreviousExhbitNumber(this.documentUploadObj);
      }
      if (!data.pageCount) {
        this.documentUploadObj.pageCount = '--';
      } else {
        this.documentUploadObj.pageCount = data.pageCount;
      }
      this.documentUploadObj.fileName = data.fileName;
      this.documentUploadObj.relatedProceedingNo = JSON.parse(JSON.stringify(this.selectedRelatedCase));
      this.documentUploadObjList.unshift(this.documentUploadObj);
      this.joinderType = null;
      this.relatedProceedingNo = this.selectedRelatedCase ? JSON.parse(JSON.stringify(this.selectedRelatedCase)) : this.relatedProceedingNo;
      this.selectedRelatedCase = null;
      this.resetForm('Paper');
    }, (failureResponse) => {
      this.toastr.error(failureResponse.error.message, "", {
        closeButton: true
      });
        this.addingToList = false;
    })
  }

  storePreviousExhbitNumber(documentUploadObj: DocumentUpload) {
    let getExhibitCount = {
      'Patent owner': () => this.global.exhibitNumberSequence.po = this.validateMaxRange(parseInt(documentUploadObj.exhibitNumber) + 1, this.global.rangeForPO.max),
      'Board': () => this.global.exhibitNumberSequence.board = this.validateMaxRange(parseInt(documentUploadObj.exhibitNumber) + 1, this.global.rangeForBoard.max),
      'Petitioner': () => this.global.exhibitNumberSequence.petitioner = this.validateMaxRange(parseInt(documentUploadObj.exhibitNumber) + 1, this.global.rangeForPetitioner.max)
    };
    if (documentUploadObj.filingParty) {
      return getExhibitCount[documentUploadObj.filingParty]();
    }
    return '';
  }
  validateMaxRange(currentValue, maxValue) {

    return currentValue && maxValue ? currentValue > maxValue ? maxValue : currentValue : 0;
  }


  setDropDownValue(value, attr, type) {
    this.showJoinderDropdown = false;
    if ( value==="morePaperType") {
      this.paperTypeList = this.paperTypeFullList;
      this.paperTypeListResponse = this.paperTypeFullList;
      return;
    }
    console.log(this.selectedRelatedCase);
    switch (type) {
      case "paperType":
        if (value==="moreValues") {
          this.subSetPapers=false;
        }
        if (value && value.toLowerCase() === this.joinderTypeCode.toLowerCase()) {
          this.getJoinderOriginalCase();
        }
        this.getPaperTypeComponents(value);
        this.filterAvailabilityList(value);
        this.paperTypeList.forEach((item) => {
          if (item.id === value) {
            if (this.modal.isOriginalJoinedCase && item.joinderCheckIndicator.toLowerCase() === 'y') {
              this.openJoinderStateChangeConfirmationModal(item.displayNameText);
            }
            this.documentUploadObj[attr] = item.displayNameText;
            this.documentUploadObj.tempDocument = item;
          }
        });
        if (this.documentUploadObj.category == 'Paper') {
          let tempDocName = this.paperTypeListResponse.find(element => element.code === value);
          this.documentUploadObj.name = tempDocName ? tempDocName.descriptionText : null;
          this.joinderType = tempDocName ? tempDocName.code.toLowerCase() : null;
        }
        break;
      case "filingParty":
        this.filingPartyList.forEach((item) => {

          if (item.code === value) {
            this.getPaperTypeList();
            this.documentUploadObj[attr] = item.displayNameText;
            if (value === "BOARD") {
              let foundPublic = this.availabilityList.find((element) => element.code === "PUBLIC");
              this.selectedAvailability = foundPublic ? foundPublic.code : null;
              this.setDropDownValue("PUBLIC", "availability", "availability");
            }
            // if (this.documentUploadObj.category === 'Exhibits') {
            if (this.documentUploadObj.category === 'Exhibit') {
              this.setExhibitNumber();
            }
          }
        });
        break;
      case "availability":
        this.availabilityList.forEach((item) => {
          if (item.code === value) {
            this.documentUploadObj[attr] = item.displayNameText;
          }
        });
        break;
    }
  }



  getJoinderOriginalCase() {
    this.trialsService.getJoinderRelatedCases(this.documentUploadObj.proceedingNumberText).subscribe((relatedCasesResponse) => {

      // relatedCasesResponse.sort((a, b) => (a.proceedingNo > b.proceedingNo) ? 1: -1);


      this.showJoinderDropdown = true;
      this.relatedCases = [];
      relatedCasesResponse.forEach((element) => {
        if (element.proceedingNo !== this.documentUploadObj.proceedingNumberText) {
          element.id = element.proceedingNo;
          if (element.joinderType && element.joinderType.toLowerCase() === 'original') {
            element.text = `${element.proceedingNo} (original)`;
          } else {
            element.text = element.proceedingNo;
          }
          if (element.joinderType.toLowerCase() !== "related") {
            let foundCase = this.relatedCases.find(x => x.text === element.text);
            if (!foundCase) {
              this.relatedCases.push(element);
            }
          }
        }
      });
      // this.relatedCases = relatedCasesResponse;

    });
  }

  setExhibitNumber() {
    switch (this.documentUploadObj.filingParty) {
      case 'Patent owner':
        this.documentUploadObj.exhibitNumber = this.global.exhibitNumberSequence.po;
        break;
      case 'Board':
        this.documentUploadObj.exhibitNumber = this.global.exhibitNumberSequence.board;
        break;
      case 'Petitioner':
        this.documentUploadObj.exhibitNumber = this.global.exhibitNumberSequence.petitioner;
        break;
      default:
        break;
    }
  }
  getNextExhibitNumber() {
    // this.jpviewService.getTrialsInfo(`${PtabTrialConstants.TRIAL_SERVICES_URL}/proceeding-party-details/exhibit-sequences?proceedingNumber=${this.documentUploadObj.proceedingNumberText}`).subscribe((exhibitSequenceResponse) => {
    this.trialsService.getTrialsInfo(`/proceeding-party-details/exhibit-sequences?proceedingNumber=${this.documentUploadObj.proceedingNumberText}`).subscribe((exhibitSequenceResponse) => {
      this.global.exhibitNumberSequence.board = this.validateMaxRange(exhibitSequenceResponse.Board, this.global.rangeForBoard.max);
      this.global.exhibitNumberSequence.po = this.validateMaxRange(exhibitSequenceResponse.Patentowner, this.global.rangeForPO.max);
      this.global.exhibitNumberSequence.petitioner = this.validateMaxRange(exhibitSequenceResponse.Petitioner, this.global.rangeForPetitioner.max);
    });
  }

  clearFile() {
    ( < HTMLInputElement > document.getElementById("file")).value = "";
    this.documentUploadObj.fileName = null;
    this.fileName = null;
  }

  toggleEditMode(e) {
    this.editModeFromUpdate = true;
    this.global.edit.enableEdit = e.flag;
    if (e.flag) {
      this.editedIndex=e.index;
      this.setEditParams(e.row);
    }
  }

  setEditParams(row) {
    let foundFilingParty = this.filingPartyList.find(element => element.displayNameText === row.filingParty);
    this.selectedFilingParty = foundFilingParty ? foundFilingParty.code : null;
    this.getPaperTypeList();
    let foundAvailability = this.availabilityList.find(element => element.displayNameText === row.availability);
    this.selectedAvailability = foundAvailability ? foundAvailability.code : null;

    if (row.category.toLowerCase()==='paper') {
      this.setPaperParameters(row);
    } else {
      this.setExhibitParameters(row);
    }

    setTimeout(() => {
      this.documentUploadObj.name=row.name;
    }, 100);
    this.documentUploadObj.availability=this.selectedAvailability;
    this.documentUploadObj.filingParty=this.selectedFilingParty;
    this.documentUploadObj.fileName="FakeName";  // Not editable.  Originial name is kept.
    this.fileName=row.fileName;
    this.documentUploadObj.category = row.category;
    // if (this.relatedProceedingNo) {
    if (row.relatedProceedingNo) {
      this.selectedRelatedCase = row.relatedProceedingNo;
      setTimeout(() => {
        this.joinderType = this.joinderTypeCode;
      }, 100);
    }
  }

  setExhibitParameters(row) {
    this.documentUploadObj.exhibitNumber = row.exhibitNumber;


  }

  setPaperParameters(row) {

    // this.paperTypeList = [...this.paperTypeFullList];
    // let foundPaperType = this.paperTypeList.find(element => element.displayNameText === row.documentTypeCode);
    // this.selectedPaperType = foundPaperType ? foundPaperType.code : null;
    this.editMotions = row.motions;
    // this.setDropDownValue(this.selectedPaperType, 'documentTypeCode','paperType');
    // this.setDropDownValue(row.documentTypeCode, 'documentTypeCode','paperType');
    this.setDropDownValue(row.tempDocument.code, 'documentTypeCode','paperType');
    this.documentUploadObj.paperTypeParameter1=row.paperTypeParameter1;
    this.documentUploadObj.paperTypeParameter2=row.paperTypeParameter2;
    this.documentUploadObj.paperTypeParameter3 = row.paperTypeParameter3;
    this.documentUploadObj.documentTypeCode = row.documentTypeCode;
    let foundPaperType = this.paperTypeList.find(element => element.displayNameText === row.documentTypeCode);
    setTimeout(() => {
      this.selectedPaperType = foundPaperType ? foundPaperType.code : null;
    }, 100);
  }

  setAlert(show, alertType, message) {
    this.alertOptions = {
      showAlert: show,
      alertType: alertType,
      message: message
    };
  }

  cancelEdit() {
    this.removeActiveClass();
    this.resetForm(this.documentUploadObj.category);
    this.editModeFromUpdate = false;
  }

  updateObject() {
    if (this.validateForm()) {
      return;
    }

    if (this.documentUploadObj.availability.toLowerCase() == 'public' || this.documentUploadObj.availability.toLowerCase() == 'available for everyone.') {
      this.openConfirmPublicDocumentModal(false);
    } else {
      this.updateTheObject();
    }
  }

  removeActiveClass() {
    let el = document.querySelector('.documentListActive');
    console.log(el);
    el.classList.remove('active');
    el.classList.remove('documentListActive');
  }

  updateTheObject() {
    let theIndex:number=0;
     this.documentUploadObjList.forEach((doc) => {
      if (theIndex===this.editedIndex) {
        let foundFilingParty = this.filingPartyList.find((element) => {
           let tempfp = element.displayNameText === this.documentUploadObj.filingParty || element.code === this.documentUploadObj.filingParty;
           return tempfp;
        });

        this.documentUploadObj.filingParty=foundFilingParty.displayNameText;
        let foundAvailability = this.availabilityList.find((element) => {
          let tempa = element.displayNameText ===this.documentUploadObj.availability || element.code === this.documentUploadObj.availability;
          return tempa;
        });

        if (doc.category === 'Exhibit') {
          doc.documentTypeCode = 'N/A';
          doc.exhibitNumber=this.documentUploadObj.exhibitNumber;
          this.storePreviousExhbitNumber(this.documentUploadObj);
        } else {
          doc.documentTypeCode=this.documentUploadObj.documentTypeCode;
        }

        doc.availability=foundAvailability.displayNameText;
        doc.filingParty=foundFilingParty.displayNameText;
        doc.name=this.documentUploadObj.name;
        doc.paperTypeParameter1= this.documentUploadObj.paperTypeParameter1;
        doc.paperTypeParameter2= this.documentUploadObj.paperTypeParameter2;
        doc.paperTypeParameter3= this.documentUploadObj.paperTypeParameter3;
        doc.motions = this.caseMotions;
        if (doc.relatedProceedingNo) {
          doc.relatedProceedingNo = this.selectedRelatedCase;
          this.relatedProceedingNo = JSON.parse(JSON.stringify(this.selectedRelatedCase));
        }
      }
      theIndex++;

     });
    this.removeActiveClass();
    this.editModeFromUpdate=false;
    this.global.edit.enableEdit = false;
    this.resetForm(this.documentUploadObj.category);
  }

  saveToDocket() {
    // this.openJoinderStateChangeConfirmationModal(null);
    let papersToUpload = {
      "partyRequestTypes":[],
      "proceedingNumberText": this.documentUploadObj.proceedingNumberText,
      "audit": {
          "lastModifiedUserIdentifier": this.loggedInUser.loginId,
          "createUserIdentifier": this.loggedInUser.loginId
      },
      "petitionDocuments": []
    };
    let exhibitsToUpload = {
      "proceedingNumberText": this.documentUploadObj.proceedingNumberText,
      "audit": {
          "lastModifiedUserIdentifier": this.loggedInUser.loginId,
          "createUserIdentifier": this.loggedInUser.loginId
      },
      "petitionDocuments": []
    };
    let allPaperAndExhibitsToUpload = {
      "proceedingNumberText": this.documentUploadObj.proceedingNumberText,
      "audit": {
          "lastModifiedUserIdentifier": this.loggedInUser.loginId,
          "createUserIdentifier": this.loggedInUser.loginId
      },
      "petitionDocuments": [],
      "joinderOrginalIndicator": null,
      "parentCaseNumber": null
    };



    if (this.caseRehearings && this.caseRehearings.length>0) {


      let rehearingsSave:Array<any>=[];
      this.caseRehearings.forEach(element => {
        if (element.action !== "No action") {
          let aRehearing = {
            "id":element.rehearingId,
            "type":"REHEARING",
            "status":element.action == 'Granted in part'? 'Granted In Part': element.action
          };
          rehearingsSave.push(aRehearing);
          papersToUpload.partyRequestTypes.push(aRehearing);
        }

      });

      // if (rehearingsSave.length>0) {
      //   papersToUpload.partyRequestTypes=rehearingsSave;
      // }

    }
    if (this.caseMotions && this.caseMotions.length>0) {


        let motionsSave:Array<any>=[];
        this.caseMotions.forEach(element => {
          if (element.action !== "No action") {
            let aMotion = {
              "id":element.motionId,
              "type":"MOTION",
              "status":element.action.toUpperCase()
            };
            motionsSave.push(aMotion);
            papersToUpload.partyRequestTypes.push(aMotion);
          }

        });

        // if (motionsSave.length>0) {
        //   papersToUpload.partyRequestTypes=motionsSave;
        // }

    }
    let seqNo = 0;
    this.documentUploadObjList.forEach((doc) => {
      let foundDocument: any;
      if (doc.category.toLowerCase() === 'exhibit') {
        seqNo++;
      }
      if (doc.category.toLowerCase() === 'paper') {
        // foundDocument = this.paperTypeFullList.find((element) => {
        //   return element.displayNameText === doc.documentTypeCode;
        // });

        // if (foundDocument && foundDocument.documentTypeCustomAttributes) {
        //   if (foundDocument.documentTypeCustomAttributes.attributes && foundDocument.documentTypeCustomAttributes.attributes.length>0) {
        //     if (doc.paperTypeParameter1) {
        //       if (foundDocument.documentTypeCustomAttributes.attributes[0].dataType==='date') {
        //         let dateValue = Date.parse(doc.paperTypeParameter1 + "T00:00");
        //         foundDocument.documentTypeCustomAttributes.attributes[0].value = dateValue/1000;
        //       } else {
        //         foundDocument.documentTypeCustomAttributes.attributes[0].value = doc.paperTypeParameter1;

        //       }
        //     }
        //     if (doc.paperTypeParameter2) {
        //       if (foundDocument.documentTypeCustomAttributes.attributes[1].dataType==='date') {
        //         let dateValue = Date.parse(doc.paperTypeParameter2 + "T00:00");
        //         foundDocument.documentTypeCustomAttributes.attributes[1].value = dateValue/1000;
        //       } else {
        //         foundDocument.documentTypeCustomAttributes.attributes[1].value = doc.paperTypeParameter2;
        //       }
        //     }
        //     if (doc.paperTypeParameter3) {
        //       if (foundDocument.documentTypeCustomAttributes.attributes[2].dateType==='date') {
        //         let dateValue = Date.parse(doc.paperTypeParameter3 + "T00:00");
        //         foundDocument.documentTypeCustomAttributes.attributes[2].value = dateValue/1000;
        //       } else {
        //         foundDocument.documentTypeCustomAttributes.attributes[2].value = doc.paperTypeParameter3;
        //       }
        //      }
        //   }
        // }

        //! New method below
        // foundDocument = this.paperTypeFullList.find((element) => {
        //   return element.displayNameText === doc.documentTypeCode;
        // });

        if (doc.tempDocument.documentTypeCustomAttributes) {
          if (doc.tempDocument.documentTypeCustomAttributes.attributes && doc.tempDocument.documentTypeCustomAttributes.attributes.length>0) {
            if (doc.paperTypeParameter1) {
              if (doc.tempDocument.documentTypeCustomAttributes.attributes[0].dataType==='date') {
                let dateValue = Date.parse(doc.paperTypeParameter1 + "T00:00");
                doc.tempDocument.documentTypeCustomAttributes.attributes[0].value = dateValue/1000;
              } else {
                doc.tempDocument.documentTypeCustomAttributes.attributes[0].value = doc.paperTypeParameter1;

              }
            }
            if (doc.paperTypeParameter2) {
              if (doc.tempDocument.documentTypeCustomAttributes.attributes[1].dataType==='date') {
                let dateValue = Date.parse(doc.paperTypeParameter2 + "T00:00");
                doc.tempDocument.documentTypeCustomAttributes.attributes[1].value = dateValue/1000;
              } else {
                doc.tempDocument.documentTypeCustomAttributes.attributes[1].value = doc.paperTypeParameter2;
              }
            }
            if (doc.paperTypeParameter3) {
              if (doc.tempDocument.documentTypeCustomAttributes.attributes[2].dateType==='date') {
                let dateValue = Date.parse(doc.paperTypeParameter3 + "T00:00");
                doc.tempDocument.documentTypeCustomAttributes.attributes[2].value = dateValue/1000;
              } else {
                doc.tempDocument.documentTypeCustomAttributes.attributes[2].value = doc.paperTypeParameter3;
              }
             }
          }
        }
      }

      let foundFilingParty = this.filingPartyList.find((element) => {
        let tempfp = element.displayNameText === doc.filingParty;
        return tempfp;
      });

      let foundAvailability = this.availabilityList.find((element) => {
        let tempa = element.displayNameText === doc.availability;
        return tempa;
      });



      const tempDoc: any = {
        "category": doc.category.toLowerCase() === 'paper' ? 'PAPER' : 'EXHIBITS',
        "exhibitNumber": doc.exhibitNumber ? doc.exhibitNumber : null,
        "sequenceNumber": doc.category.toLowerCase() === 'exhibit' ? seqNo : null,
        "name": doc.name,
        "fileName": doc.fileName,
        // "fileName": "NOTHINGISTHERE",
        "filingParty": foundFilingParty.code.toLowerCase(),
        "availability": foundAvailability.code.toUpperCase(),
        "documentTypeIdentifier": doc.category.toLowerCase() === 'paper' ? doc.tempDocument.identifier : null,
        "documentTypeCode": doc.category.toLowerCase() === 'paper' ? doc.tempDocument.code : null,
        // "joinderOrginalIndicator": "N",
        "documentTypeCustomAttributes":doc.category.toLowerCase() === 'paper' ? doc.tempDocument.documentTypeCustomAttributes : null,
        "mimeType": doc.mimeType
      };


      // Add outcomeTypeId
      if (doc.tempDocument && doc.tempDocument.documentTypeCustomAttributes) {
        if (doc.tempDocument.documentTypeCustomAttributes.attributes.length > 0) {
          if (doc.tempDocument.documentTypeCustomAttributes.attributes[0].outcomeTypeId && doc.tempDocument.code.toLowerCase() === PtabTrialConstants.FED_CIRCUIT_MANDATE_CODE.toLowerCase()) {
            tempDoc.outcomeTypeId = doc.tempDocument.documentTypeCustomAttributes.attributes[0].outcomeTypeId;
          }
        }
      }

      // delete doc.tempDocument;
      if (tempDoc.documentTypeCode && tempDoc.documentTypeCode.toLowerCase() === PtabTrialConstants.JOINDER_TYPE_CODE.toLowerCase()) {
        this.shouldJoinCases = true;
        // tempDoc.joinderOrginalIndicator = "N";
        this.joinderOrginalIndicator = "N";  //? When joining a new case to an original
      }

      if (this.modal.isOriginalJoinedCase && doc.tempDocument && doc.tempDocument.joinderCheckIndicator.toLowerCase() === 'y') {
        // tempDoc.joinderOrginalIndicator = "Y";
        this.joinderOrginalIndicator = "Y"; //? Is an original case of a joinder
      } else {
        if (tempDoc.hasOwnProperty('joinderOrginalIndicator') && !this.shouldJoinCases) {
          delete tempDoc.joinderOrginalIndicator; //? When a case has nothing to do with joinders
        }
      }

      if (doc.category.toLowerCase() === 'exhibit') {
        exhibitsToUpload.petitionDocuments.push(tempDoc);
      } else if (doc.category.toLowerCase() === 'paper') {
        papersToUpload.petitionDocuments.unshift(tempDoc);
      }

      // if (tempDoc.documentTypeCode && tempDoc.documentTypeCode.toLowerCase() === PtabTrialConstants.JOINDER_TYPE_CODE.toLowerCase()) {
      //   this.shouldJoinCases = true;
      // }
    });

    this.documentUploadObjListBkup = JSON.parse(JSON.stringify(this.documentUploadObjList));
      this.documentUploadObjList = [];

    // if (exhibitsToUpload.petitionDocuments.length > 0) {
    //   this.saveExhibitDocs(exhibitsToUpload, papersToUpload);
    // } else if (papersToUpload.petitionDocuments.length > 0) {
    //   this.savePaperDocs(papersToUpload);
    // }

    allPaperAndExhibitsToUpload = JSON.parse(JSON.stringify(papersToUpload));
    allPaperAndExhibitsToUpload.petitionDocuments = [];
    allPaperAndExhibitsToUpload.petitionDocuments = exhibitsToUpload.petitionDocuments.concat(papersToUpload.petitionDocuments);
    allPaperAndExhibitsToUpload.joinderOrginalIndicator = this.joinderOrginalIndicator;

    // if (this.shouldJoinCases) {
    //   this.joinCases(allPaperAndExhibitsToUpload);
    // } else {
    //   this.savePapersAndExhibits(allPaperAndExhibitsToUpload);
    // }

    if (this.shouldJoinCases) {
      allPaperAndExhibitsToUpload.parentCaseNumber = this.relatedProceedingNo;
    }
    this.savePapersAndExhibits(allPaperAndExhibitsToUpload);
  }

  savePapersAndExhibits(papersAndExhibitsToUpload) {
    console.log('papersAndExhibitsToUpload: ', papersAndExhibitsToUpload);
      this.saving = true;
    // this.jpviewService.saveToDocket(`${PtabTrialConstants.TRIAL_SERVICES_URL}/proceeding-artifacts`, papersAndExhibitsToUpload).subscribe((saveToDocketResponse) => {
    this.trialsService.saveToDocket(papersAndExhibitsToUpload).subscribe((saveToDocketResponse) => {
      saveToDocketResponse.petitionDocuments.forEach(element => {
        if (element.errorMessage) {
          this.failed = true;
          this.toastr.error(`${element.errorMessage}`, "", {
            closeButton: true
          });
          let found = this.documentUploadObjListBkup.find((origDoc) => {
            return parseInt(origDoc.exhibitNumber) == element.exhibitNumber && origDoc.name === element.name;
          })

          // delete element.errorMessage;
          this.documentUploadObjList.push(found);
        }
      });
      this.toastr.success(`Successfully saved papers and exhibits`, "", {
        closeButton: true
      });
      this.saving = false;
      // if (this.shouldJoinCases) {
      //   this.joinCases();
      // }
      if (this.documentUploadObjList.length <= 0) {
        this.close(true);
      }
    }, (saveToDocketFailure) => {
        this.failed = true;
      this.toastr.error(`${saveToDocketFailure.error.message}`, "", {
        closeButton: true
      });
      this.shouldJoinCases = false;
        // this.documentUploadObjListBkup.forEach((origDoc) => {
        //   if (origDoc.category.toLowerCase() === 'paper') {
        //     if (origDoc.exhibitNumber) {
        //       delete origDoc.exhibitNumber;
        //     }
        //     this.documentUploadObjList.push(origDoc);
        //   }
        // });
      this.documentUploadObjList = [...this.documentUploadObjListBkup];
        this.saving = false;
    });
  }

  // saveExhibitDocs (exhibitsToUpload, papersToUpload) {
  //   this.saving = true;
  //   this.jpviewService.saveToDocket(`${PtabTrialConstants.TRIAL_SERVICES_URL}/proceeding-artifacts`, exhibitsToUpload).subscribe((saveToDocketResponse) => {
  //     saveToDocketResponse.petitionDocuments.forEach(element => {
  //       if (element.errorMessage) {
  //         this.failed = true;
  //         this.toastr.error(`${element.errorMessage}`, "", {
  //           closeButton: true
  //         });
  //         let found = this.documentUploadObjListBkup.find((origDoc) => {
  //           return parseInt(origDoc.exhibitNumber) == element.exhibitNumber && origDoc.name === element.name;
  //         })

  //         // delete element.errorMessage;
  //         this.documentUploadObjList.push(found);
  //       }
  //     });
  //     if (this.documentUploadObjList.length <= 0) {
  //       this.toastr.success(`Successfully saved exhibits`, "", {
  //         closeButton: true
  //       });
  //     }
  //     if (papersToUpload.petitionDocuments.length <= 0) {
  //       this.saving = false;
  //       if (this.documentUploadObjList.length <= 0) {
  //         this.close(true);
  //       }
  //     } else {
  //       this.savePaperDocs(papersToUpload);
  //     }
  //   }, (saveToDocketFailure) => {
  //     this.toastr.error(`${saveToDocketFailure.error.message}`, "", {
  //       closeButton: true
  //     });
  //       if (papersToUpload.petitionDocuments.length <= 0) {
  //         this.saving = false;
  //       } else {
  //         this.savePaperDocs(exhibitsToUpload);
  //       }
  //   });
  // }

  getPaperDocs () {
    this.trialsService.getDocumentsForUpdate(`${PtabTrialConstants.TRIALS_URLS.GET_DOCUMENTS}${this.documentUploadObj.proceedingNumberText}`).subscribe((documentSuccess) => {
      documentSuccess.forEach(doc => {
        if (doc.category && doc.category.toLowerCase() === 'paper') {
          if (doc.documentTypeCode.indexOf('NOFDA')>=0) {
            this.hasNOFDA=true;
          }
        }
      });
      // this.getPaperTypeList();
    }, (documentFailure) => {
    });
  }

  joinCases(allPaperAndExhibitsToUpload) {
    let casesToJoin = {
      // "proceedingNo": this.documentUploadObj.proceedingNumberText,
      // "relatedProceedingNo": this.relatedProceedingNo,
      "proceedingNo": this.relatedProceedingNo,
      "relatedProceedingNo": this.documentUploadObj.proceedingNumberText,
      "audit": {
          "lastModifiedUserIdentifier": this.loggedInUser.loginId,
          "createUserIdentifier": this.loggedInUser.loginId
      }
    }
    this.trialsService.joinCases(casesToJoin).subscribe((joinCasesResponse) => {
      this.commonUtils.setToastr('success', `${this.documentUploadObj.proceedingNumberText} successfully joined with ${this.relatedProceedingNo}`);
      this.savePapersAndExhibits(allPaperAndExhibitsToUpload);
    }, (joinedCaseFailure) => {
      this.commonUtils.setToastr('error', joinedCaseFailure.error.message);
    });

  }


  openJoinderStateChangeConfirmationModal(paperTypeName) {
    let modal: InfoModalModel = {
            // infoText:[`Uploading "${paperTypeName}" paper type to the current case will update state/status of the current case and all of its joined cases.`, `Do you want to continue?` ],
            infoText:[`${paperTypeName}`],
            showJoinderMessage: true,
            title: "Status change",
            showLeftBtn: true,
            leftBtnClass: 'btn-default',
            leftBtnLabel: 'No, cancel',
            showRightBtn: true,
            rightBtnClass: 'btn-primary',
            rightBtnLabel: 'Yes, continue',
            isConfirm: false,
            modalHeight: 120
      }
      let response = this.commonUtils.openConfirmModal(modal);
      if (!response.onHide) {
        return;
      }
      response.onHide.subscribe((reason: string | any) => {
        if (!reason.initialState.modal.isConfirm) {
          console.log(reason.initialState.modal.isConfirm);
          this.selectedPaperType = null;
          this.documentUploadObj.name = null;
          this.paperTypeControls=[];
          this.global.edit.enableEdit = false;
      }
    })
  }


  getJoinderInfo() {
    this.trialsService.getJoinedCaseDetails(this.documentUploadObj.proceedingNumberText).subscribe((joinedCaseDetails) => {
      joinedCaseDetails.forEach((joinedCase) => {
        if (joinedCase.relatedProceedingNo === this.documentUploadObj.proceedingNumberText) {
          this.isJoinedCase = true;
        }
      });
    })
  }


  checkForMultipleJoinedDocuments() {
    console.log(this.documentUploadObjList);
    let joinderDocExists = false;
    if (this.documentUploadObjList && this.documentUploadObjList.length > 0) {
      this.documentUploadObjList.forEach((doc) => {
        if (doc.tempDocument && doc.tempDocument.code.toLowerCase() === this.joinderTypeCode.toLowerCase() && this.documentUploadObj && this.documentUploadObj.tempDocument && this.documentUploadObj.tempDocument.code.toLowerCase() === this.joinderTypeCode.toLowerCase()) {
          joinderDocExists = true;
        }
      });
    }
    return joinderDocExists;
  }

  // savePaperDocs (papersToUpload) {
  //   if (papersToUpload) {
  //     this.saving = true;
  //   }

  //   this.jpviewService.saveToDocket(`${PtabTrialConstants.TRIAL_SERVICES_URL}/proceeding-artifacts`, papersToUpload).subscribe((saveToDocketResponse) => {
  //     this.toastr.success(`Successfully saved papers`, "", {
  //       closeButton: true
  //     });
  //     this.saving = false;
  //     if (this.documentUploadObjList.length <= 0) {
  //       this.close(true);
  //     }
  //   }, (saveToDocketFailure) => {
  //       this.failed = true;
  //     this.toastr.error(`${saveToDocketFailure.error.message}`, "", {
  //       closeButton: true
  //     });
  //       this.documentUploadObjListBkup.forEach((origDoc) => {
  //         if (origDoc.category.toLowerCase() === 'paper') {
  //           if (origDoc.exhibitNumber) {
  //             delete origDoc.exhibitNumber;
  //           }
  //           this.documentUploadObjList.push(origDoc);
  //         }
  //       });
  //       this.saving = false;
  //   });
  // }
}