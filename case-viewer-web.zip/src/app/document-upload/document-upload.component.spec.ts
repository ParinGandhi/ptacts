import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DocumentUploadComponent } from './document-upload.component';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { InfoModalComponent } from 'src/app/components/common/info-modal/info-modal.component';
import { JpViewService } from '../services/jpview.service';
import { Observable, of } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { NgSelect2Module } from 'ng-select2';
import { DatePipe } from '@angular/common';
import { componentFactoryName } from '@angular/compiler';
import { ɵgetComponentViewDefinitionFactory } from '@angular/core';
import { TrialsService } from '../services/trials.service';
declare let $: any;

xdescribe('DocumentUploadComponent', () => {
  let component: DocumentUploadComponent;
  let fixture: ComponentFixture<DocumentUploadComponent>;
  let jpViewService: JpViewService;
  let trialsService: TrialsService;
  let modalService: BsModalService;
  let toastr: ToastrService


  const toastrService = {
    success: (
      message?: string,
      title?: string
    ) => {},
    error: (
      message?: string,
      title?: string
    ) => {},
  };

  let reason ={
    initialState: {
      modal:{
        isConfirm: true
      }
    }
  }

  class modalServiceMock  {
    // hide: () => {},
    // show:() => {return {onHide:() => {return of(reason)}}}
    show = (infoModalComponent:InfoModalComponent)=>{return {onHide:() => {return of(reason)}}}
    hide = () =>{return {}}
  };

  const paperTypeListRespMockResponse = {"stateDocumentTypes":[{"identifier":210,"code":"ID:RHGRNT","descriptionText":"Institution Decision:  granting institution on request for rehearing","displayNameText":"Institution Decision:  granting institution on request for rehearing"},{"identifier":255,"code":"NOT:PRATRFAPR","descriptionText":"Notice:  partial refund approved","displayNameText":"Notice:  partial refund approved"},{"identifier":253,"code":"NOT:RFNDAprv","descriptionText":"Notice:  refund approved","displayNameText":"Notice:  refund approved"}],"moreDocumetnTypes":[{"identifier":241,"code":"ADVR:POSTINST","descriptionText":"Adverse judgement:  post-institution","displayNameText":"Adverse judgement:  post-institution","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616170960","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":240,"code":"ADVR:PREINST","descriptionText":"Adverse judgment:  pre-institution","displayNameText":"Adverse judgment:  pre-institution","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616170960","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":212,"code":"FINAL:FW","descriptionText":"Final Written Decision:  original","displayNameText":"Final Written Decision:  original","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616170960","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":213,"code":"FINAL:RH","descriptionText":"Final Written Decision:  rehearing","displayNameText":"Final Written Decision:  rehearing","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616170960","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":214,"code":"FINAL:RMD","descriptionText":"Final written decision:  On remand","displayNameText":"Final written decision:  On remand"},{"identifier":209,"code":"ID:DENY","descriptionText":"Institution Decision:  Deny","displayNameText":"Institution Decision:  Deny","documentTypeCustomAttributes":{"motionTypeIds":[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23],"rehearingIds":[1,2,3],"attributes":[{"id":5,"label":"Decision to Institute","dataType":"date","uielementId":"ID_DEC_INST","value":"1616170960","mandatory":false,"rolesForEdit":["XXX"]},{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERMDT","value":"1616170960","mandatory":false,"rolesForEdit":["XXX"]}]}},{"identifier":208,"code":"ID:GRANT","descriptionText":"Institution Decision:  Grant","displayNameText":"Institution Decision:  Grant ","documentTypeCustomAttributes":{"motionTypeIds":[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23],"rehearingIds":[1,2,3],"attributes":[{"id":5,"label":"Decision to Institute","dataType":"date","uielementId":"ID_DEC_INST","value":"1616170960","mandatory":false,"rolesForEdit":["XXX"]},{"id":11,"label":"Hearing date","dataType":"date","uielementId":"ID_HRGDT","value":"1616170960","mandatory":false,"rolesForEdit":["Paralegal/LIE","Supervisor","Patent Attorney","Business Administrator","Judge"]}]}},{"identifier":211,"code":"ID:RHDENY","descriptionText":"Institution Decision:  denying institution on request for rehearing","displayNameText":"Institution Decision:  denying institution on request for rehearing"},{"identifier":244,"code":"NOT:NOFDA","descriptionText":"Notice:  Notice filing date accorded","displayNameText":"Notice:  Notice filing date accorded","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":2,"label":"Accorded filing date","dataType":"date","uielementId":"ID_NOFD","value":"1616170960","mandatory":true},{"id":3,"label":"Notice mailed date","dataType":"date","uielementId":"ID_MNOFD","value":"1616170960","mandatory":true}]}},{"identifier":257,"code":"NOTOTH","descriptionText":"Notice:  Other","displayNameText":"Notice:  Other"},{"identifier":247,"code":"NOT:ACPTCPET","descriptionText":"Notice:  acceptance corrected petition","displayNameText":"Notice:  acceptance corrected petition"},{"identifier":246,"code":"NOT:DEFCTPET","descriptionText":"Notice:  defective petition","displayNameText":"Notice:  defective petition","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":2,"label":"Accorded filing date","dataType":"date","uielementId":"ID_NOFD","value":"1616170960","mandatory":true},{"id":3,"label":"Notice mailed date","dataType":"date","uielementId":"ID_MNOFD","value":"1616170960","mandatory":true}]}},{"identifier":251,"code":"NOT:DEMNS","descriptionText":"Notice:  demonstratives","displayNameText":"Notice:  demonstratives"},{"identifier":245,"code":"NOT:INCMPLTPET","descriptionText":"Notice:  incomplete petition","displayNameText":"Notice:  incomplete petition"},{"identifier":256,"code":"NOT:RCPTPOPR","descriptionText":"Notice:  notice of receipt of POP request","displayNameText":"Notice:  notice of receipt of POP request"},{"identifier":254,"code":"NOT:RFNDDNY","descriptionText":"Notice:  refund denied","displayNameText":"Notice:  refund denied"},{"identifier":229,"code":"ORD:AddBRF","descriptionText":"Order:  Additional Briefing","displayNameText":"Order:  Additional Briefing"},{"identifier":234,"code":"ORD:OTH","descriptionText":"Order:  Other","displayNameText":"Order:  Other"},{"identifier":232,"code":"ORD:TERM","descriptionText":"Order:  Termination as to one party","displayNameText":"Order:  Termination as to one party"},{"identifier":233,"code":"ORD:GRANT","descriptionText":"Order:  granting POP Request ","displayNameText":"Order:  granting POP Request "},{"identifier":230,"code":"ORD:MOT","descriptionText":"Order:  on Motion","displayNameText":"Order:  on Motion"},{"identifier":231,"code":"ORD:REQHR","descriptionText":"Order:  on requet for rehearing","displayNameText":"Order:  on requet for rehearing"},{"identifier":259,"code":"OTH:HRTRANS","descriptionText":"Other:  Hearing transcript","displayNameText":"Other:  Hearing transcript"},{"identifier":260,"code":"OTH:AMBRF","descriptionText":"Other:  amicus brief","displayNameText":"Other:  amicus brief"},{"identifier":262,"code":"OTH:FEDCRTD","descriptionText":"Other:  fed circuit mandate","displayNameText":"Other:  fed circuit mandate"},{"identifier":264,"code":"OTH:OTH","descriptionText":"Other:  other","displayNameText":"Other:  other"},{"identifier":263,"code":"OTH:CRTD","descriptionText":"Other:  other court decision","displayNameText":"Other:  other court decision"},{"identifier":236,"code":"TERM:POSTSETL","descriptionText":"Termination Decision:  Post-DI Settlement","displayNameText":"Termination Decision:  Post-DI Settlement","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616170960","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":237,"code":"TERM:PREDIS","descriptionText":"Termination Decision:  Pre-DI dismissal","displayNameText":"Termination Decision:  Pre-DI dismissal","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616170960","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":235,"code":"TERM:PRESETL","descriptionText":"Termination Decision:  Pre-DI settlement","displayNameText":"Termination Decision:  Pre-DI settlement","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616170960","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":239,"code":"TERM:VACT","descriptionText":"Termination Decision:  Vacate","displayNameText":"Termination Decision:  Vacate","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616170960","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":238,"code":"TERM:POSTSDIS","descriptionText":"Termination Decision: Post-DI dismissal","displayNameText":"Termination Decision: Post-DI dismissal","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616170960","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":258,"code":"TCERT:CERT","descriptionText":"Trial Certificate Checklist","displayNameText":"Trial Certificate Checklist"}],"stndDecisonOutcomeType":null};

  const petitionIdentifierMockResponse = { "petitionIdentifier": 1533043, "patentNumber": "8590940", "proceedingNumberText": "CBM2020-00010", "audit": { "lastModifiedDateTime": "1584971288", "createDateTime": "1581016861" }, "fiscalYear": 2020, "patentClaimQt": 100 };

  const paperTypeListMockResponse = [{ "identifier": 125, "code": "APP", "descriptionText": "Appeal Document", "displayNameText": "Appeal Document" }, { "identifier": 26, "code": "ATTRIBUTABLE OWNER", "descriptionText": "Attributable Owner", "displayNameText": "Attributable Owner" }, { "identifier": 72, "code": "CP", "descriptionText": "Corrected Petition", "displayNameText": "Corrected Petition" }, { "identifier": 25, "code": "COURT DECN", "descriptionText": "Court Decision", "displayNameText": "Court Decision" },
   {"identifier":32, "code":"NDF", "descriptionText":"Notice of Defective Petition", "documentTypeCustomAttributes":[]}, { "identifier": 71, "code": "CM", "descriptionText": "Court Mandate", "displayNameText": "Court Mandate" }];

  const filingPartyListMockResponse = [{ "code": "BOARD", "descriptionText": "Board", "displayNameText": "Board" }, { "code": "PATENT OWNER", "descriptionText": "Indicates artifact was submitted on behalf of Patent Owner.", "displayNameText": "Patent owner" }, { "code": "PETITIONER", "descriptionText": "Indicates artifact was submitted on behalf of Petitioner.", "displayNameText": "Petitioner" }];

  const availabilityListMockResponse = [{ "code": "PUBLIC", "descriptionText": "Available for everyone.", "displayNameText": "Public" }, { "code": "PRIVATE", "descriptionText": "Available to parties and board.", "displayNameText": "Parties and Board" }, { "code": "CONFIDENTIAL", "descriptionText": "Available to filing party and board.", "displayNameText": "Filing party and Board" }, { "code": "BOARD", "descriptionText": "Available only to board.", "displayNameText": "Board " }];

  const boardPaperTypeMockResponse = {"stateDocumentTypes":null,"moreDocumetnTypes":[{"identifier":241,"code":"ADVR:POSTINST","descriptionText":"Adverse judgement:  post-institution","displayNameText":"Adverse judgement:  post-institution","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616115825","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":240,"code":"ADVR:PREINST","descriptionText":"Adverse judgment:  pre-institution","displayNameText":"Adverse judgment:  pre-institution","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616115825","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":212,"code":"FINAL:FW","descriptionText":"Final Written Decision:  original","displayNameText":"Final Written Decision:  original","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616115825","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":213,"code":"FINAL:RH","descriptionText":"Final Written Decision:  rehearing","displayNameText":"Final Written Decision:  rehearing","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616115825","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":214,"code":"FINAL:RMD","descriptionText":"Final written decision:  On remand","displayNameText":"Final written decision:  On remand"},{"identifier":209,"code":"ID:DENY","descriptionText":"Institution Decision:  Deny","displayNameText":"Institution Decision:  Deny","documentTypeCustomAttributes":{"motionTypeIds":[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23],"rehearingIds":[1,2,3],"attributes":[{"id":5,"label":"Decision to Institute","dataType":"date","uielementId":"ID_DEC_INST","value":"1616115825","mandatory":false,"rolesForEdit":["XXX"]},{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERMDT","value":"1616115825","mandatory":false,"rolesForEdit":["XXX"]}]}},{"identifier":208,"code":"ID:GRANT","descriptionText":"Institution Decision:  Grant","displayNameText":"Institution Decision:  Grant ","documentTypeCustomAttributes":{"motionTypeIds":[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23],"rehearingIds":[1,2,3],"attributes":[{"id":5,"label":"Decision to Institute","dataType":"date","uielementId":"ID_DEC_INST","value":"1616115825","mandatory":false,"rolesForEdit":["XXX"]},{"id":11,"label":"Hearing date","dataType":"date","uielementId":"ID_HRGDT","value":"1616115825","mandatory":false,"rolesForEdit":["Paralegal/LIE","Supervisor","Patent Attorney","Business Administrator","Judge"]}]}},{"identifier":211,"code":"ID:RHDENY","descriptionText":"Institution Decision:  denying institution on request for rehearing","displayNameText":"Institution Decision:  denying institution on request for rehearing"},{"identifier":210,"code":"ID:RHGRNT","descriptionText":"Institution Decision:  granting institution on request for rehearing","displayNameText":"Institution Decision:  granting institution on request for rehearing"},{"identifier":244,"code":"NOT:NOFDA","descriptionText":"Notice:  Notice filing date accorded","displayNameText":"Notice:  Notice filing date accorded","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":2,"label":"Accorded filing date","dataType":"date","uielementId":"ID_NOFD","value":"1616115825","mandatory":true},{"id":3,"label":"Notice mailed date","dataType":"date","uielementId":"ID_MNOFD","value":"1616115825","mandatory":true}]}},{"identifier":257,"code":"NOTOTH","descriptionText":"Notice:  Other","displayNameText":"Notice:  Other"},{"identifier":247,"code":"NOT:ACPTCPET","descriptionText":"Notice:  acceptance corrected petition","displayNameText":"Notice:  acceptance corrected petition"},{"identifier":246,"code":"NOT:DEFCTPET","descriptionText":"Notice:  defective petition","displayNameText":"Notice:  defective petition","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":2,"label":"Accorded filing date","dataType":"date","uielementId":"ID_NOFD","value":"1616115825","mandatory":true},{"id":3,"label":"Notice mailed date","dataType":"date","uielementId":"ID_MNOFD","value":"1616115825","mandatory":true}]}},{"identifier":251,"code":"NOT:DEMNS","descriptionText":"Notice:  demonstratives","displayNameText":"Notice:  demonstratives"},{"identifier":245,"code":"NOT:INCMPLTPET","descriptionText":"Notice:  incomplete petition","displayNameText":"Notice:  incomplete petition"},{"identifier":256,"code":"NOT:RCPTPOPR","descriptionText":"Notice:  notice of receipt of POP request","displayNameText":"Notice:  notice of receipt of POP request"},{"identifier":255,"code":"NOT:PRATRFAPR","descriptionText":"Notice:  partial refund approved","displayNameText":"Notice:  partial refund approved"},{"identifier":253,"code":"NOT:RFNDAprv","descriptionText":"Notice:  refund approved","displayNameText":"Notice:  refund approved"},{"identifier":254,"code":"NOT:RFNDDNY","descriptionText":"Notice:  refund denied","displayNameText":"Notice:  refund denied"},{"identifier":229,"code":"ORD:AddBRF","descriptionText":"Order:  Additional Briefing","displayNameText":"Order:  Additional Briefing"},{"identifier":234,"code":"ORD:OTH","descriptionText":"Order:  Other","displayNameText":"Order:  Other"},{"identifier":232,"code":"ORD:TERM","descriptionText":"Order:  Termination as to one party","displayNameText":"Order:  Termination as to one party"},{"identifier":233,"code":"ORD:GRANT","descriptionText":"Order:  granting POP Request ","displayNameText":"Order:  granting POP Request "},{"identifier":230,"code":"ORD:MOT","descriptionText":"Order:  on Motion","displayNameText":"Order:  on Motion"},{"identifier":231,"code":"ORD:REQHR","descriptionText":"Order:  on requet for rehearing","displayNameText":"Order:  on requet for rehearing"},{"identifier":259,"code":"OTH:HRTRANS","descriptionText":"Other:  Hearing transcript","displayNameText":"Other:  Hearing transcript"},{"identifier":260,"code":"OTH:AMBRF","descriptionText":"Other:  amicus brief","displayNameText":"Other:  amicus brief"},{"identifier":262,"code":"OTH:FEDCRTD","descriptionText":"Other:  fed circuit mandate","displayNameText":"Other:  fed circuit mandate"},{"identifier":264,"code":"OTH:OTH","descriptionText":"Other:  other","displayNameText":"Other:  other"},{"identifier":263,"code":"OTH:CRTD","descriptionText":"Other:  other court decision","displayNameText":"Other:  other court decision"},{"identifier":236,"code":"TERM:POSTSETL","descriptionText":"Termination Decision:  Post-DI Settlement","displayNameText":"Termination Decision:  Post-DI Settlement","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616115825","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":237,"code":"TERM:PREDIS","descriptionText":"Termination Decision:  Pre-DI dismissal","displayNameText":"Termination Decision:  Pre-DI dismissal","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616115825","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":235,"code":"TERM:PRESETL","descriptionText":"Termination Decision:  Pre-DI settlement","displayNameText":"Termination Decision:  Pre-DI settlement","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616115825","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":239,"code":"TERM:VACT","descriptionText":"Termination Decision:  Vacate","displayNameText":"Termination Decision:  Vacate","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616115825","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":238,"code":"TERM:POSTSDIS","descriptionText":"Termination Decision: Post-DI dismissal","displayNameText":"Termination Decision: Post-DI dismissal","documentTypeCustomAttributes":{"motionTypeIds":[],"rehearingIds":[],"attributes":[{"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616115825","mandatory":true,"rolesForEdit":["XXX"]}]}},{"identifier":258,"code":"TCERT:CERT","descriptionText":"Trial Certificate Checklist","displayNameText":"Trial Certificate Checklist"}],"stndDecisonOutcomeType":null}
  const loggedInUserMock = {
    loginId: 'sbartlett',
    roleDescription:'Supervisor'
  }

  const mimeTypesMockResponse = [{"identifier":16,"code":"video/mp4","descriptionText":"video/mp4"},{"identifier":1,"code":"video/avi","descriptionText":"video/avi"},{"identifier":2,"code":"image/bmp","descriptionText":"image/bmp"},{"identifier":3,"code":"image/jpeg","descriptionText":"image/jpeg"},{"identifier":4,"code":"video/mpeg","descriptionText":"video/mpeg"},{"identifier":5,"code":"text/plain","descriptionText":"text/plain"},{"identifier":6,"code":"image/tiff","descriptionText":"image/tiff"},{"identifier":7,"code":"application/pdf","descriptionText":"application/pdf"},{"identifier":8,"code":"image/png","descriptionText":"image/png"},{"identifier":9,"code":"application/vnd.ms-powerpoint","descriptionText":"application/powerpoint(ppt)"},{"identifier":10,"code":"application/msword","descriptionText":"application/msword"},{"identifier":11,"code":"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","descriptionText":"application/excel"},{"identifier":12,"code":"application/x-zip-compressed","descriptionText":"application/x-zip-compressed"},{"identifier":13,"code":"application/vnd.openxmlformats-officedocument.presentationml.presentation","descriptionText":"application/powerpoint(pptx)"},{"identifier":14,"code":"application/vnd.openxmlformats-officedocument.wordprocessingml.document","descriptionText":"application/docx"},{"identifier":15,"code":"video/x-ms-wmv","descriptionText":"video/wmv"}]


  const uploadDocumentMockResponse = {
    "pageCount": 1,
    "fileName": "TestPDF.pdf",
    "name": '',
    "category": 'Paper',
    "documentTypeCode": '',
    "proceedingNumberText": '37553565'
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DocumentUploadComponent,InfoModalComponent],
      imports: [HttpClientTestingModule, NgSelect2Module],
      providers: [
        JpViewService,
        TrialsService,
        DatePipe,
        provideMockStore({
        selectors: [
          { selector: CaseViewerSelectors.caseInfoData, value: { proceedingNo: '37553565' } },
          {selector: CaseViewerSelectors.userInfoData,value:{caseDetailsData: []}}
        ]
      }),
        {
          provide: ToastrService,
          useValue: toastrService
        },
      {
        provide: BsModalRef,
        useValue: {}
      },
      {
        provide: BsModalService,
        useClass: modalServiceMock

      }
      // {
      //   provide: JpViewService,
      //   useValue: {
      //     uploadDocuments:()=>{
      //       return of({data:"daat"})
      //     }
      //   }
      //   }
      ]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentUploadComponent);
    jpViewService = TestBed.inject(JpViewService);
    trialsService = TestBed.inject(TrialsService);
    modalService = TestBed.inject(BsModalService);
    toastr = TestBed.inject(ToastrService);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getPetitionIdentifier and return success response', () => {
    component.loggedInUser ={ loginId: "sbartlett"}
    component.documentUploadObj.proceedingNumberText = "1234567";
    spyOn(jpViewService, 'getCaseInfoByProceedingNo').and.returnValue(of(petitionIdentifierMockResponse));
    component.getPetitionIdentifier();
    expect(component.petitionerIdentifier).toBe(petitionIdentifierMockResponse.petitionIdentifier);
  })

  it('should call getPaperTypeList and return failed response', () => {
    component.loggedInUser ={ loginId: "sbartlett"}
    spyOn(jpViewService, 'getDropDownList').and.returnValue(of(Promise.reject({ message: 'failure' })));
    component.getPaperTypeList();
   // expect(component.paperTypeListResponse).toEqual(paperTypeListMockResponse);
   // expect(component.paperTypeList).toEqual(paperTypeListMockResponse);
  });

  it('should call getPaperTypeList and return success response', () => {
    component.loggedInUser ={ loginId: "sbartlett"}
    spyOn(jpViewService, 'getDropDownList').and.returnValue(of(paperTypeListMockResponse));
    component.getPaperTypeList();
   // expect(component.paperTypeListResponse).toEqual(paperTypeListMockResponse);
   // expect(component.paperTypeList).toEqual(paperTypeListMockResponse);
  });

  it('should call getPaperTypeList and return success response', () => {
    component.loggedInUser ={ loginId: "sbartlett"}
    spyOn(jpViewService, 'getDropDownList').and.returnValue(of(boardPaperTypeMockResponse));
    component.getPaperTypeList();
   // expect(component.paperTypeListResponse).toEqual(paperTypeListMockResponse);
   // expect(component.paperTypeList).toEqual(paperTypeListMockResponse);
  });


  it('should call getFilingPartyTypeList and return success response', () => {
    component.loggedInUser ={ loginId: "sbartlett"}
    spyOn(jpViewService, 'getDropDownList').and.returnValue(of(filingPartyListMockResponse));
    component.getFilingPartyTypeList();
    //expect(component.filingPartyList).toEqual(filingPartyListMockResponse);
  })


  it('should call getAvailabilityList and return success response', () => {
    spyOn(jpViewService, 'getDropDownList').and.returnValue(of(availabilityListMockResponse));
    component.getAvailabilityList();
    expect(component.availabilityList).toEqual(availabilityListMockResponse);
  });


   it('should call getFetchData', () => {
    component.paperTypeFullListBRD=[];
    let anObject ="BRD0";
    component.paperTypeFullListBRD.push(anObject);
    component.selectedFilingParty ="BOARD";
    component.getFetchedData();
    component.paperTypeFullListPET=[];
    let anObject2 ="BRD0";
    component.paperTypeFullListPET.push(anObject2);
    component.selectedFilingParty ="PETITIONER";
    component.getFetchedData();

    component.paperTypeFullListPO=[];
    let anObject3 ="BRD0";
    component.paperTypeFullListPO.push(anObject3);
    component.selectedFilingParty ="PATENT OWNER";
    component.getFetchedData();

    component.selectedFilingParty ="";
    component.getFetchedData();
    //expect(component.availabilityList).toEqual(availabilityListMockResponse);
   });


  it('should call storedFetchData', () => {

    component.selectedFilingParty ="PATENT OWNER";
    component.storeFetchedData();
    component.selectedFilingParty ="PETITIONER";
    component.storeFetchedData();
    component.selectedFilingParty ="";
    component.storeFetchedData();
    //expect(component.availabilityList).toEqual(availabilityListMockResponse);
  });

  it ('validate the dynamic parameter for paper type', () => {
    component.paperTypeList=[];
    let typeObject = {
      code:"NDF",
      documentTypeCustomAttributes: {
        attributes:[
          {"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616115825","mandatory":true,"rolesForEdit":["Paralegal"]},
          {"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616115825","mandatory":true,"rolesForEdit":["Paralegal"]},
          {"id":10,"label":"Termination date","dataType":"date","uielementId":"ID_TERM_DT","value":"1616115825","mandatory":true,"rolesForEdit":["Paralegal"]}

        ]
    }
    };

  //  typeObject.documentTypeCustomAttributes.push("hello");
    component.paperTypeList.push(typeObject)
    component.getPaperTypeComponents("NDF");
   // expect(component.paperTypeControls.length).toBe(1);

   component.getPaperTypeComponents("");
  });

  it ('validate a paper type has no value', () => {
    component.getPaperTypeComponents(null);
    expect(component.paperTypeControls.length).toBe(0);
  });

 /*  it ('validate the dynamic parameter for paper type', () => {
    component.paperTypeList=[];
    component.getPaperTypeComponents("");
    expect(component.paperTypeControls.length).toBe(0);
  });
 */
  it('should call addToList and exit', () => {
    component.documentUploadObj.documentTypeCode = null;
    let result = component.addToList();
    expect(result).toBeFalsy();
  });

  it("Test Validate method for Custom parameters1 for mandatory value", () => {
    component.paperTypeControls=[];
    let paperObject = {
      mandatory:true
    }

    component.paperTypeControls.push(paperObject);
    //component.validationObject.paper.paperTypeParameter1=false;

    let result = component.checkPaperParamters();
    expect(result).toBe(true);

  });

  it("Test Validate method for Custom parameters for not a mandatory value", () => {
    component.paperTypeControls=[];
    let validationFlag2 = component.checkPaperParamters();
    expect(validationFlag2).toBe(false);

    component.paperTypeControls=[];
    let paperObject = {
      mandatory:false
    }

    component.paperTypeControls.push(paperObject);

    //component.validationObject.paper.paperTypeParameter1=false;

    let validationFlag = component.checkPaperParamters();
//    expect(validationFlag).toBe(false);


    component.paperTypeControls=[];
    let paperObject2 = {
      mandatory:true
    }
    component.paperTypeControls.push(paperObject2);
    let validationFlag3 = component.checkPaperParamters();
//    expect(validationFlag3).toBe(false);


  });

  it("Test Validate method for 2 Custom parameters for a mandatory value", () => {
    component.paperTypeControls=[];
    let paperObject = {
      mandatory:false
    }

    component.paperTypeControls.push(paperObject);
    let paperObject2 = {
      mandatory:true
    }
    component.paperTypeControls.push(paperObject2);
    let validationFlag3 = component.checkPaperParamters();
    //expect(validationFlag3).toBe(false);
  });

  it("Test Validate method for 2 Custom parameters for a non mandatory value", () => {
    component.paperTypeControls=[];
    let paperObject = {
      mandatory:false
    }

    component.paperTypeControls.push(paperObject);
    let paperObject2 = {
      mandatory:false
    }
    component.paperTypeControls.push(paperObject2);
    let validationFlag3 = component.checkPaperParamters();
  //  expect(validationFlag3).toBe(false);
  });

  it("Test Validate method for 3 Custom parameters for a non mandatory value", () => {
    component.paperTypeControls=[];
    let paperObject = {
      mandatory:false
    }

    component.paperTypeControls.push(paperObject);
    let paperObject2 = {
      mandatory:false
    }
    component.paperTypeControls.push(paperObject2);

    let paperObject3 = {
      mandatory:false
    }
    component.paperTypeControls.push(paperObject3);


    let validationFlag3 = component.checkPaperParamters();
  //  expect(validationFlag3).toBe(false);
  });

  it("Test Validate method for 3 Custom parameters for mandatory value", () => {
    component.paperTypeControls=[];
    let paperObject = {
      mandatory:false
    }

    component.paperTypeControls.push(paperObject);
    let paperObject2 = {
      mandatory:false
    }
    component.paperTypeControls.push(paperObject2);

    let paperObject3 = {
      mandatory:true
    }
    component.paperTypeControls.push(paperObject3);


    let validationFlag3 = component.checkPaperParamters();
  //  expect(validationFlag3).toBe(false);
  });

  it("Test Validate method for 3 Custom parameters for 2nd mandatory value", () => {
    component.paperTypeControls=[];
    let paperObject = {
      mandatory:false
    }

    component.paperTypeControls.push(paperObject);
    let paperObject2 = {
      mandatory:true
    }
    component.paperTypeControls.push(paperObject2);

    let paperObject3 = {
      mandatory:true
    }
    component.paperTypeControls.push(paperObject3);


    let validationFlag3 = component.checkPaperParamters();
//    expect(validationFlag3).toBe(false);
  });


  it('should validate all mandatory values on the paper form', () => {
    component.documentUploadObj.name="Corrected Petition";
    let notValid = component.validateForm();
    expect(notValid).toBe(true);
  });

  // FIXME - TypeError: this.availabilityListOriginal is not iterable
  xit('should validate toggleEditMode', () => {
    component.filingPartyList = filingPartyListMockResponse;
    component.availabilityList = availabilityListMockResponse;
    component.paperTypeList = paperTypeListMockResponse;
    component.paperTypeListResponse = paperTypeListMockResponse;

    let e = {
      flag:true,
      index:1,
      row:{
        filingParty:"BOARD",
        availability:"PUBLIC",
        category:"Paper"
      }

    };
    component.toggleEditMode(e);
    let e2 = {
      flag:false,
      index:2,
      row: {
        filingParty:"PATENT OWNER",
        availability:"PUBLIC",
        category:"Paper"
      }
    };
    component.toggleEditMode(e2);
  });

  /*it('should validate setDropDownValue for more paper type', () => {
    component.documentUploadObjList.push(uploadDocumentMockResponse);
    component.filingPartyList=filingPartyListMockResponse;
    component.availabilityList=availabilityListMockResponse;
    component.editedIndex=0;
    component.updateTheObject();
  });*/


   it('should validate setDropDownValue for more paper type', () => {
    component.filingPartyList=filingPartyListMockResponse;
    component.availabilityList=availabilityListMockResponse;
    component.documentUploadObj.category="Exhibit";
    component.documentUploadObj.filingParty="Patent owner";
    component.setDropDownValue("BOARD", "", "filingParty");
    component.documentUploadObj.filingParty="Board";
    component.setDropDownValue("BOARD", "", "filingParty");
    component.documentUploadObj.filingParty="Petitioner";
    component.setDropDownValue("BOARD", "", "filingParty");
  });


  it('should validate setDropDownValue for more paper type', () => {

    component.setDropDownValue("morePaperType", "", "");
  });


  it('should validate all mandatory values on the exhibit form', () => {
    component.documentUploadObj.category = 'Exhibit';
    let notValid = component.validateForm();
    expect(notValid).toBe(true);
  });

  it('should validate all mandatory values on the exhibit with exhibit number', () => {
    component.documentUploadObj.category = 'Exhibit';
    component.documentUploadObj.exhibitNumber="123";
    let notValid = component.validateForm();
    expect(notValid).toBe(true);
  });


  it('should validate all mandatory values on the exhibit with no exhibit number', () => {
    component.documentUploadObj.category = 'Exhibit';
    component.documentUploadObj.exhibitNumber=null;
    component.selectedFilingParty="Board";
    let notValid = component.validateForm();
    expect(notValid).toBe(true);
  });



   it("Should handle the close button", () => {

    const initialState: any = {

    };
    component.modal = {};
    modalService.hide = (): BsModalRef => {
      return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
        animated: true,
        backdrop: 'static',
        class: 'modal-audit-size',
        initialState
      }}
    }


    modalService.show = (): BsModalRef => {
      return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
        animated: true,
        backdrop: 'static',
        class: 'modal-audit-size',
        initialState
      }}
    }


    component.close(100);
  });

  /* it("Should handle the close button", () => {
    component.modal = {};
    modalService.hide = (): BsModalRef => {
      return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
        animated: true,
        backdrop: 'static',
        class: 'modal-audit-size',
        initialState
      }}
    }
    modalService.show = (): BsModalRef => {
      return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
        animated: true,
        backdrop: 'static',
        class: 'modal-audit-size',
        initialState
      }}
    }
    const initialState: any = {

    };
    component.documentUploadObjList.push(uploadDocumentMockResponse);
    modalService.show = (): BsModalRef => {
      return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
        animated: true,
        backdrop: 'static',
        class: 'modal-audit-size',
        initialState
      }}
    }
    component.close(100);
  });
  */
  it("Verify the getRehearingValue", () => {
    component.caseRehearings=null;
    let rehearingText = component.getRehearingValue();
    expect(rehearingText).toMatch("");
  });


  it("Verify the getRehearingValue with rehearings", () => {
    const rehearing = {
      "action":"No action"
    }
    component.caseRehearings=[];
    component.caseRehearings.push(rehearing);
    let rehearingText = component.getRehearingValue();
    expect(rehearingText).toContain("0 out of 1");
  });

  it("Verify the getRehearingValue with rehearings", () => {
    const rehearing = {
      "action":"Granted"
    }
    component.caseRehearings=[];
    component.caseRehearings.push(rehearing);
    let rehearingText = component.getRehearingValue();
    expect(rehearingText).toContain("1 out of 1");
  });

  it("Verify the getMotionValue", () => {
    component.caseMotions=null;
    let motionsText = component.getMotionValue();
    expect(motionsText).toMatch("");
  });


  it("Verify the getMotionsValue with motions", () => {
    const motion = {
      "action":"No action"
    }
    component.caseMotions=[];
    component.caseMotions.push(motion);
    let motionText = component.getMotionValue();
    expect(motionText).toContain("0 out of 1");
  });

  it("Verify the getMotionValue with motions", () => {
    const motion = {
      "action":"Granted"
    }
    component.caseMotions=[];
    component.caseMotions.push(motion);
    let motionText = component.getMotionValue();
    expect(motionText).toContain("1 out of 1");
  });

  it("Verify the getDateString", () => {
    let date= new Date();
    let motionText = component.getDateString(date.getUTCMilliseconds());
    expect(motionText).toContain("-");
  });



  /* it("Verify the openAbandonChangesModal", () => {
    component.openAbandonChangesModal();
  }); */

  it("Verify file event change executes for Paper", () => {
    let evt = {
      target: {
      files:[
        {name:"lello.pdf"}]
      }
    };


    component.documentUploadObj.category="Paper";
    component.fileChangeEvent(evt)
  });

  it("Verify file event change executes for Exhibit", () => {
    let evt = {
      target: {
      files:[
        {name:"lello.pdf"}]
      }
    };

    component.documentUploadObj.filingParty="BOARD";
    component.documentUploadObj.category="Exhibit";
    component.fileChangeEvent(evt)
  });

  it("Validate exhibit number range method should validate range numbers for Board", () => {
    let valid = component.validateExhibitNumberRange("1000", "Board");
    expect(valid).toBe(true);
  });


  it("Validate exhibit number range method should validate range numbers for patent owner", () => {
    let valid = component.validateExhibitNumberRange("1000", "patent owner");
    expect(valid).toBe(true);
  });

  it("Validate exhibit number range method should validate range numbers for petitioner", () => {
    let valid = component.validateExhibitNumberRange("3000", "petitioner");
    expect(valid).toBe(true);
  });

  it("Validate exhibit number range method should validate range numbers for other", () => {
    let valid = component.validateExhibitNumberRange("3000", "other");
    expect(valid).toBe(false);
  });

  it("Validate exhibit number range method when exhibit number loses focus", () => {
     component.validateExhibitNumberOnBlur("3000", "Board");

  });


  it("Validate cancelEdit", () => {
    component.filingPartyList=filingPartyListMockResponse;
    component.selectedFilingParty="Patent Owner";
    component.availabilityList=availabilityListMockResponse;
    component.cancelEdit();

 });

 /*
      this.validationObject.paper.filingParty = this.checkFormModel(this.documentUploadObj.filingParty);
      this.validationObject.paper.availability = this.checkFormModel(this.documentUploadObj.availability);
      this.validationObject.paper.fileName = this.checkFormModel(this.documentUploadObj.fileName);
      this.validationObject.paper.paperType = this.checkFormModel(this.documentUploadObj.documentTypeCode);
      this.validationObject.paper.documentName = this.checkFormModel(this.documentUploadObj.name);
      return this.validationObject.paper.paperType || this.validationObject.paper.documentName || this.validationObject.paper.filingParty || this.validationObject.paper.availability || this.validationObject.paper.fileName || this.checkPaperParamters();
*/
 it("Validate updateObject exhibit form", () => {
  const initialState: any = {

  };
  component.modal = {};
  modalService.hide = (): BsModalRef => {
    return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
      animated: true,
      backdrop: 'static',
      class: 'modal-audit-size modal-md second-modal',
      initialState
    }}
  }

  component.editedIndex=0;
  modalService.show = (): BsModalRef => {
    return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
      animated: true,
      backdrop: 'static',
      class: 'modal-audit-size modal-md second-modal',
      initialState
    }}
  }
   const document = {
     category:"Exhibit",
     filingParty:"Board",
     availability:"BOARD",
     exhibitNumber:"3006",
     fileName:"test.pdf",
     documentTypeCode:"NDF",
     name:"Paper type name"
   };
   component.documentUploadObj=document;
   component.documentUploadObjList.push(component.documentUploadObj)
  component.filingPartyList=filingPartyListMockResponse;
  component.selectedFilingParty="board";
  component.availabilityList=availabilityListMockResponse;
  component.updateObject();


});

it("Validate updateObject paper form", () => {
  const initialState: any = {

  };
  component.modal = {};
  modalService.hide = (): BsModalRef => {
    return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
      animated: true,
      backdrop: 'static',
      class: 'modal-audit-size modal-md second-modal',
      initialState
    }}
  }

  component.editedIndex=0;
  modalService.show = (): BsModalRef => {
    return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
      animated: true,
      backdrop: 'static',
      class: 'modal-audit-size modal-md second-modal',
      initialState
    }}
  }
   const document = {
     category:"Paper",
     filingParty:"Board",
     availability:"BOARD",
     fileName:"test.pdf",
     documentTypeCode:"NDF",
     name:"Paper type name"
   };
   component.documentUploadObj=document;
   component.documentUploadObjList.push(component.documentUploadObj)
  component.filingPartyList=filingPartyListMockResponse;
  component.selectedFilingParty="Patent Owner";
  component.availabilityList=availabilityListMockResponse;
  component.updateObject();

  component.documentUploadObj.availability="Board";
  component.updateObject();

});


it("Validate saveToDocket paper form", () => {
  const saveMockResponse = {"allowedResourceObjectList":["panel_Update"],"ptabDefaultRefreshTime":300000,"ptabReadOnlyUser":false,"petitionIdentifier":1546822,"audit":{"createUserIdentifier":"sbartlett","lastModifiedUserIdentifier":"sbartlett"},"partyRequestTypes":[],"proceedingNumberText":"IPR2021-00532","petitionDocuments":[{"fileName":"PTAB_US207143_TC100305.pdf","pageCount":5,"warningMessageList":[],"availability":"PUBLIC","mimeType":"application/pdf","contentManagementId":"workspace://SpacesStore/ff9a47dc-6ee8-4627-b226-6feb909f0903;1.0","filingParty":"patent owner","documentTypeCode":"MOT:ADVRS","fileSize":0,"petitionIdentifier":1546822,"audit":{"createUserIdentifier":"sbartlett","lastModifiedUserIdentifier":"sbartlett"},"name":"Motion:  Motion for Adverse Judgment","category":"PAPER","documentTypeIdentifier":219}]};
  spyOn(trialsService, 'getDocumentsForUpdate').and.returnValue(of(saveMockResponse));
  spyOn(jpViewService, 'saveToDocket').and.returnValue(of(saveMockResponse));

  const initialState: any = {

  };


  component.modal = {};
  modalService.hide = (): BsModalRef => {
    return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
      animated: true,
      backdrop: 'static',
      class: 'modal-audit-size modal-md second-modal',
      initialState
    }}
  }

  component.editedIndex=0;
  modalService.show = (): BsModalRef => {
    return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
      animated: true,
      backdrop: 'static',
      class: 'modal-audit-size modal-md second-modal',
      initialState
    }}
  }
   const document = {
     category:"Paper",
     filingParty:"Board",
     availability:"Public",
     fileName:"test.pdf",
     documentTypeCode:"Corrected Petition",
     name:"Paper type name"
   };
   component.documentUploadObj=document;
   component.documentUploadObjList.push(component.documentUploadObj)
  component.filingPartyList=filingPartyListMockResponse;
  component.selectedFilingParty="Patent Owner";
  component.availabilityList=availabilityListMockResponse;
  component.loggedInUser =loggedInUserMock;
  component.paperTypeListResponse=paperTypeListMockResponse;

  //component.documentUploadObj.availability="Board ";
  const rehearing = {
    "action":"Granted"
  }
  component.caseRehearings=[];
  component.caseRehearings.push(rehearing);
  const motion = {
    "action":"Granted"
  }
  component.caseMotions=[];
  component.caseMotions.push(motion);

  component.saveToDocket();
});



it("Validate saveToDocket paper form", () => {
  const saveMockResponse = {"allowedResourceObjectList":["panel_Update"],"ptabDefaultRefreshTime":300000,"ptabReadOnlyUser":false,"petitionIdentifier":1546822,"audit":{"createUserIdentifier":"sbartlett","lastModifiedUserIdentifier":"sbartlett"},"partyRequestTypes":[],"proceedingNumberText":"IPR2021-00532","petitionDocuments":[{"fileName":"PTAB_US207143_TC100305.pdf","pageCount":5,"warningMessageList":[],"availability":"PUBLIC","mimeType":"application/pdf","contentManagementId":"workspace://SpacesStore/ff9a47dc-6ee8-4627-b226-6feb909f0903;1.0","filingParty":"patent owner","documentTypeCode":"MOT:ADVRS","fileSize":0,"petitionIdentifier":1546822,"audit":{"createUserIdentifier":"sbartlett","lastModifiedUserIdentifier":"sbartlett"},"name":"Motion:  Motion for Adverse Judgment","category":"PAPER","documentTypeIdentifier":219}]};
  spyOn(trialsService, 'getDocumentsForUpdate').and.returnValue(of(saveMockResponse));
  spyOn(jpViewService, 'saveToDocket').and.returnValue(of(saveMockResponse));

  const initialState: any = {

  };


  component.modal = {};
  modalService.hide = (): BsModalRef => {
    return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
      animated: true,
      backdrop: 'static',
      class: 'modal-audit-size modal-md second-modal',
      initialState
    }}
  }

  component.editedIndex=0;
  modalService.show = (): BsModalRef => {
    return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
      animated: true,
      backdrop: 'static',
      class: 'modal-audit-size modal-md second-modal',
      initialState
    }}
  }
   const document = {
     category:"Paper",
     filingParty:"Board",
     availability:"Public",
     fileName:"test.pdf",
     documentTypeCode:"Corrected Petition",
     name:"Paper type name"
   };
   component.documentUploadObj=document;
   component.documentUploadObjList.push(component.documentUploadObj)
  component.filingPartyList=filingPartyListMockResponse;
  component.selectedFilingParty="Patent Owner";
  component.availabilityList=availabilityListMockResponse;
  component.loggedInUser =loggedInUserMock;
  component.paperTypeListResponse=paperTypeListMockResponse;

  //component.documentUploadObj.availability="Board ";
  const rehearing = {
    "action":"Granted"
  }
  component.caseRehearings=[];
  component.caseRehearings.push(rehearing);
  const motion = {
    "action":"Granted"
  }
  component.caseMotions=[];
  component.caseMotions.push(motion);

  component.saveToDocket();
});



/*
      this.validationObject.exhibits.filingParty = this.checkFormModel(this.documentUploadObj.filingParty);
      this.validationObject.exhibits.availability = this.checkFormModel(this.documentUploadObj.availability);
      this.validationObject.exhibits.fileName = this.checkFormModel(this.documentUploadObj.fileName);
      this.validationObject.exhibits.exhibitNumber = this.checkFormModel(this.documentUploadObj.exhibitNumber);
      if (!this.validationObject.exhibits.exhibitNumber) {
        this.validationObject.exhibits.range1000 = this.validateExhibitNumberRange(this.documentUploadObj.exhibitNumber, this.selectedFilingParty);
        this.validationObject.exhibits.range2000 = this.validateExhibitNumberRange(this.documentUploadObj.exhibitNumber, this.selectedFilingParty);
        this.validationObject.exhibits.range3000 = this.validateExhibitNumberRange(this.documentUploadObj.exhibitNumber, this.selectedFilingParty);
      }
      this.validationObject.exhibits.documentName = this.checkFormModel(this.documentUploadObj.name);
*/


 it('should call addToList and openConfirmPublicDocumentModal', () => {
    component.documentUploadObj.availability = "PUBLIC";

    const document = {
      category:"Paper",
      filingParty:"Board",
      availability:"PUBLIC",
      exhibitNumber:"3006",
      fileName:"test.pdf",
      documentTypeCode:"NDF",
      name:"Paper type name"
    };
    component.documentUploadObj=document;
    component.documentUploadObjList.push(component.documentUploadObj)
   component.filingPartyList=filingPartyListMockResponse;
   component.selectedFilingParty="board";
   component.availabilityList=availabilityListMockResponse;

    const initialState = {
      modal: {
        title: "Make document public ?",
        subText: "Document can be viewed by the public unless a different option is chosen",
        closeBtnName: "No, change availability",
        yesBtnName: "Yes, make it public",
        yesBtnClass: "btn-primary",
        isConfirm: false
      }
    };
      modalService.show = (): BsModalRef => {
      return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
        animated: true,
        backdrop: 'static',
        class: 'modal-audit-size',
        initialState
      }}
    }

    modalService.hide = (): BsModalRef => {
      return {hide: null, id: null, setClass: null, onHide: null, onHidden: null, content: {
        animated: true,
        backdrop: 'static',
        class: 'modal-audit-size',
        initialState
      }}
    }
   // spyOn(modalService, 'onHide');
    component.addToList();
    //expect(component.openConfirmPublicDocumentModal(true)).toHaveBeenCalled();
  });

  it('should call fileChangeEvent with valid fileName', () => {
    const mockFile = {
      target: {
        files: [{
          "name": "TestPDF.pdf",
          "size": 14568
        }]
      }
    }
    component.fileChangeEvent(mockFile);
//   expect(component.fileToUpload).toEqual(mockFile.target.files[0]);
 //   expect(component.fileName).toEqual(mockFile.target.files[0].name);
//    expect(component.fileFormat).toEqual('pdf');
  });


  it('should call fileChangeEvent with invalid file format', () => {
    const mockFile = {
      target: {
        files: [{
          "name": "TestPDF.pdf",
          "size": 14568,
          "type": 'application/doc'
        }]
      }
    }
    component.fileFormat = "doc";
    component.fileChangeEvent(mockFile);
 //   expect(component.alert).toBeTrue();
  //  expect(component.alertMessage).toBe(`.${component.fileFormat} is an invalid file format. Choose a file with the correct format.`);
  });


  it('should call fileChangeEvent with special characters', () => {
    const mockFile = {
      target: {
        files: [{
          "name": "TestPDF@.pdf",
          "size": 14568,
          "type": 'application/pdf'
        }]
      }
    }
    component.fileChangeEvent(mockFile);
  //  expect(component.alert).toBeTrue();
   // expect(component.alertMessage).toBe(`Special characters not allowed in filename: ‘!@#$%^&*(){}|`);
  });


  it('should call fileChangeEvent with large file', () => {
    const mockFile = {
      target: {
        files: [{
          "name": "TestPDF.pdf",
          "size": 1863548465471357547,
          "type": 'application/pdf'
        }]
      }
    }
    component.fileChangeEvent(mockFile);
 //   expect(component.alert).toBeFalse();
  });


  it('should call getMotions with success response', () => {
    const mockMotionsGetResponse = [{"motionId":2630324,"proceedingNumber":"IPR2014-00355","motionTypeName":"Motion","filedTimeStamp":"2014-04-25 12:35:38.604","motionTypeId":15,"requestorTypeName":"Patent Owner","motionStatusId":4,"motionStatusName":"LEGACY DATA"}]
    spyOn(jpViewService, 'getTrialsInfo').and.returnValue(of(mockMotionsGetResponse));
   });

  it('should call getMotions with motions and a success response', () => {

  const mockMotionsGetResponse2 = [{"motionId":2630324,"proceedingNumber":"IPR2014-00355","motionTypeName":"Motion","filedTimeStamp":"2014-04-25 12:35:38.604","motionTypeId":15,"requestorTypeName":"Patent Owner","motionStatusId":4,"motionStatusName":"PENDING REVIEW"}]
  spyOn(jpViewService, 'getTrialsInfo').and.returnValue(of(mockMotionsGetResponse2));
  component.editMotions=[];
  let aMotion= {
    "action":"hello"
  }
  component.documentUploadObj.filingParty="BOARD";
  component.editMotions.push(aMotion);
  component.getMotions("1,2,3,4,5");


  });

  it('should call getNextExhibitNumber with success response', () => {
    const mockMotionsGetResponse = {"Patentowner":"2001","Board":"3001","ptabReadOnlyUser":true,"Petitioner":"1023"};
    spyOn(jpViewService, 'getTrialsInfo').and.returnValue(of(mockMotionsGetResponse));
    component.getNextExhibitNumber();
  });

  it('should call storeNPreviousExihibtNumber and verify value', () => {

    //=> this.global.exhibitNumberSequence.po = this.validateMaxRange(parseInt(documentUploadObj.exhibitNumber) + 1, this.global.rangeForPO.max),

    const mockMotionsGetResponse = {"Patentowner":"2001","Board":"3001","ptabReadOnlyUser":true,"Petitioner":"1023"};
    spyOn(jpViewService, 'getTrialsInfo').and.returnValue(of(mockMotionsGetResponse));
    component.documentUploadObj.exhibitNumber="3004";
    component.storePreviousExhbitNumber(component.documentUploadObj);
  });


  it('should call getMotions with motions and a success response', () => {

    const mockMotionsGetResponse2 = [{"motionId":2630324,"proceedingNumber":"IPR2014-00355","motionTypeName":"Motion","filedTimeStamp":"2014-04-25 12:35:38.604","motionTypeId":15,"requestorTypeName":"Patent Owner","motionStatusId":4,"motionStatusName":"PENDING REVIEW"}]
    spyOn(jpViewService, 'getTrialsInfo').and.returnValue(of(mockMotionsGetResponse2));
    component.documentUploadObj.filingParty="BOARD";
    component.getMotions("1,2,3,4,5");

   component.editMotions=[];
    });


  it('should call getMotions with motions and a success response', () => {

    const mockMotionsGetResponse2 = [{"motionId":2630324,"proceedingNumber":"IPR2014-00355","motionTypeName":"Motion","filedTimeStamp":"2014-04-25 12:35:38.604","motionTypeId":15,"requestorTypeName":"Patent Owner","motionStatusId":4,"motionStatusName":"PENDING REVIEW"}]
    spyOn(jpViewService, 'getTrialsInfo').and.returnValue(of(mockMotionsGetResponse2));
    component.documentUploadObj.filingParty="BOARD";
    component.getMotions("1,2,3,4,5");

   component.editMotions=[];
    });



it('should call getMotions with motions and a success response', () => {

    const mockMotionsGetResponse2 = [{"motionId":2630324,"proceedingNumber":"IPR2014-00355","motionTypeName":"Motion","filedTimeStamp":"2014-04-25 12:35:38.604","motionTypeId":15,"requestorTypeName":"Patent Owner","motionStatusId":4,"motionStatusName":"PENDING REVIEW"}]
    spyOn(jpViewService, 'getTrialsInfo').and.returnValue(of(mockMotionsGetResponse2));
    component.documentUploadObj.filingParty="BOARD";
    component.getMotions("1,2,3,4,5");

   component.editMotions=[];
    });


    it('should call getRehearings with success response', () => {
      const mockRehearingsGetResponse = [{"motionId":2630324,"proceedingNumber":"IPR2014-00355","rehearingTypeName":"Motion","filedTimeStamp":"2014-04-25 12:35:38.604","motionTypeId":15,"requestorTypeName":"Patent Owner","motionStatusId":4,"motionStatusName":"LEGACY DATA"}]
      spyOn(jpViewService, 'getTrialsInfo').and.returnValue(of(mockRehearingsGetResponse));
     });

    it('should call getRehearings with rehearings and a success response', () => {

    const mockMotionsGetResponse2 = [{"motionId":2630324,"proceedingNumber":"IPR2014-00355","rehearingTypeName":"Motion","filedTimeStamp":"2014-04-25 12:35:38.604","motionTypeId":15,"requestorTypeName":"Patent Owner","motionStatusId":4,"motionStatusName":"PENDING REVIEW"}]
    spyOn(jpViewService, 'getTrialsInfo').and.returnValue(of(mockMotionsGetResponse2));
    component.editRehearings=[];
    let aMotion= {
      "action":"hello"
    }
    component.editRehearings.push(aMotion);
    component.getRehearings("1,2,3,4,5");


    });

    it('should call getMimeTypes', () => {
      spyOn(jpViewService, 'getMimeTypes').and.returnValue(of(mimeTypesMockResponse));
      component.loggedInUser =loggedInUserMock;
      component.getMimeTypes();
     });


    it('should call getRehearings with rehearings and a success response', () => {

      const mockMotionsGetResponse2 = [{"motionId":2630324,"proceedingNumber":"IPR2014-00355","rehearingTypeName":"Motion","filedTimeStamp":"2014-04-25 12:35:38.604","motionTypeId":15,"requestorTypeName":"Patent Owner","motionStatusId":4,"motionStatusName":"PENDING REVIEW"}]
      spyOn(jpViewService, 'getTrialsInfo').and.returnValue(of(mockMotionsGetResponse2));
      component.getRehearings("1,2,3,4,5");

      });



      it('should call getMimeTypes', () => {
        let attributes={
          rolesForEdit:["Supervisor"]
        };
        component.loggedInUser=loggedInUserMock;
        component.checkPermission(attributes);

        let attributes2={
          rolesForEdit:[]
        };
        component.checkPermission(attributes2);

        let attributes3={

        };
        component.checkPermission(attributes3);
       });

       it('should call getMimeTypes', () => {
        let attributes={
          rolesForEdit:["Supervisor"]
        };
        component.checkPermission(attributes);
       });


       it('should call processPaperTypeResonseServiceCall with state documents', () => {
       component.hasNOFDA=true;
        component.processPaperTypeResonseServiceCall(paperTypeListRespMockResponse);
       });




    it('should call pushToList with success response', () => {
    spyOn(jpViewService, 'uploadDocuments').and.returnValue(of(uploadDocumentMockResponse));
    component.petitionerIdentifier = 1234567;
    component.fileToUpload = new File(["foo"], "TestPDF.pdf", {
      type: "application/pdf"
    });
    component.filingPartyList = filingPartyListMockResponse;
    component.availabilityList = availabilityListMockResponse;

    component.documentUploadObj.category="Exhibit";
    component.pushToList();
    // expect(component.documentUploadObj.pageCount).toEqual(uploadDocumentMockResponse.pageCount);
    // expect(component.documentUploadObj.fileName).toEqual(uploadDocumentMockResponse.fileName);
    // expect(component.documentUploadObjList[0]).toEqual(uploadDocumentMockResponse);
  });

  it('should call pushToList with success response for Exhibit', () => {
    spyOn(jpViewService, 'uploadDocuments').and.returnValue(of(uploadDocumentMockResponse));
    component.petitionerIdentifier = 1234567;
    component.fileToUpload = new File(["foo"], "TestPDF.pdf", {
      type: "application/pdf"
    });
    component.filingPartyList = filingPartyListMockResponse;
    component.availabilityList = availabilityListMockResponse;
    component.pushToList();
    // expect(component.documentUploadObj.pageCount).toEqual(uploadDocumentMockResponse.pageCount);
    // expect(component.documentUploadObj.fileName).toEqual(uploadDocumentMockResponse.fileName);
    // expect(component.documentUploadObjList[0]).toEqual(uploadDocumentMockResponse);
  });

  // FIXME - TypeError: this.availabilityListOriginal is not iterable
  xit('should call setDropdown for paperType', () => {
    component.paperTypeList = paperTypeListMockResponse;
    component.paperTypeListResponse = paperTypeListMockResponse;
    component.setDropDownValue("APP", "documentTypeCode", "paperType");
//    expect(component.documentUploadObj.documentTypeCode).toBe("Appeal Document");
  });


  it('should call setDropdown for filingParty', () => {
    component.filingPartyList = filingPartyListMockResponse;
    component.availabilityList = availabilityListMockResponse;
    component.setDropDownValue("BOARD", "filingParty", "filingParty");
    expect(component.documentUploadObj.filingParty).toBe("Board");
  });


  it('should call setDropdown for availability', () => {
    component.availabilityList = availabilityListMockResponse;
    component.setDropDownValue("PRIVATE", "availability", "availability");
    expect(component.documentUploadObj.availability).toBe("Parties and Board");
  });

  it('should call setDropdown for Paper type', () => {
    component.availabilityList = availabilityListMockResponse;
    component.setDropDownValue("PRIVATE", "availability", "availability");
    expect(component.documentUploadObj.availability).toBe("Parties and Board");
  });



 /*  it('should show parameters when paper type is Reconcile petition', () => {
    component.getPaperTypeComponents('CP');
    expect(component.paperTypeControls[0].componentType).toContain("dasdate");
  });
 */

  it('should call openPDFInNewTab', () => {
    const selectedDoc = {
      "fileName": "TestPDF.pdf"
    }
 //   component.openPDFInNewTab(selectedDoc);
  });
  // it('should call openPDFInNewTab', () => {
  //   const selectedDoc = {
  //     "fileName": "TestPDF.pdf"
  //   }
  //   component.openPDFInNewTab(selectedDoc);
  // });


  it('should clear file', () => {
    component.documentUploadObj.fileName = "Testing.pdf";
    component.clearFile();
    expect(component.documentUploadObj.fileName).toBeNull();
  })

  it('should test getmimetypes with a non admin', () => {
    component.loggedInUser=null;

    component.getMimeTypes();
   // expect(component.documentUploadObj.fileName).toBeNull();
  })

//   it('should call confirm dialog', () => {
//     component.documentUploadObj.availability ='public';
//     component.addToList();
//     expect(component).toBeTruthy();
//   });
//   it('should SET DROP DOWN list', () => {
//     component.documentUploadObj.category ='PAPER';
//     component.setDropDownValue('category','PAPER','paperType');
//     expect(component.documentUploadObj.name).toEqual("PAPER");
//   });
//   it('should add list', () => {
//     component.documentUploadObj.availability ='public';
//     document.createElement('div').setAttribute("id", "file");
//     component.pushToList();
//     expect(component.documentUploadObj.category).toEqual("PAPER");
//   });

//   it('should invoke filechange event', () => {

//     let blob = new Blob(["<html>…</html>"], {type: 'application/pdf'});
//     blob['name']="sample.pdf";
//     blob['lastModifiedDate'] = new Date();
//     let e = {
//  target:{
//    files:[blob]
//  }
//     }
//     component.fileChangeEvent(e)
//     expect(component.documentUploadObj.data.length).toBeDefined;
//   });
});
