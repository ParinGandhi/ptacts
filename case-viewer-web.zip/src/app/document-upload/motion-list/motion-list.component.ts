import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-motion-list',
  templateUrl: './motion-list.component.html',
  styleUrls: ['./motion-list.component.less']
})
export class MotionListComponent implements OnInit {
  @Input() motionObjList: Array<any>;
  @Input() type:string;
 
  global = {
    
  };

 
  constructor(
    
  ) { }

  ngOnInit(): void {
  }


 

}
