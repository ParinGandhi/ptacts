import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { PtabTrialConstants } from "../../constants/ptab-trials.constants";
import AlertModel from '../../models/common/Alert.model';

import { Store, select } from '@ngrx/store';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import { DatePipe } from '@angular/common'
import InfoModalModel from 'src/app/models/common/InfoModal.model';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';

@Component({
  selector: 'app-document-list',
  templateUrl: './document-list.component.html',
  styleUrls: ['./document-list.component.less']
})
export class DocumentListComponent implements OnInit {

  @Input() documentUploadObjList: Array<any>;
  @Input() editModeFromUpdate: boolean;
  @Input() addingToList: boolean;
  @Input() saving: boolean;
  @Input() failed: boolean;
  @Output() editMode: EventEmitter<any> = new EventEmitter<any>();

  global = {

    edit: {
      enableEdit: false,
      editIndex: null,
      originalRow: {},
      rowToEdit: null
    }
  };



   hoverClass: string = 'btn-default';


  constructor(

  ) { }

  ngOnInit(): void {

  }


  openPDFInNewTab(selectedDoc) {
 //   window.open(`https://ptab-q121-trial-intservices-wildfly-green-0.pvt.uspto.gov:8443/PTABE2ECommonServices/petitions/${this.petitionerIdentifier}/documents?fileName=${selectedDoc.fileName}`)
  }


  editRow(row, index) {
    let el = document.getElementById(`documentList${index}`);
    el.classList.add('active');
    el.classList.add('documentListActive');
    let dataObject = {
      flag:true,
      row:row,
      index:index
    }
    this.editMode.emit(dataObject);
    this.global.edit.enableEdit = true;


  }

   deleteDocument(selectedDoc) {
    // let documentToDelete = {
    //   "fileName": selectedDoc.fileName,
    //   "audit": {
    //     "lastModifiedUserIdentifier": this.loggedInUser.loginId,
    //     "createUserIdentifier": this.loggedInUser.loginId
    //   }
    // }
    // this.jpviewService.deleteDocument(`/PTABE2ECommonServices/petitions/${this.petitionerIdentifier}/documents`, documentToDelete).subscribe((documentDeleteResponse) => {
    //   alert("Successfully deleted document");
    //   let indexNo = this.documentUploadObjList.indexOf(selectedDoc);
    //   this.documentUploadObjList.splice(indexNo, 1);

    // });
    let indexNo = this.documentUploadObjList.indexOf(selectedDoc);
    this.documentUploadObjList.splice(indexNo, 1);
  }
}
