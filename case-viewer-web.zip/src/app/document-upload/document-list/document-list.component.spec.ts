import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { DocumentListComponent } from './document-list.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';

describe('DocumentListComponent', () => {
  let component: DocumentListComponent;
  let fixture: ComponentFixture<DocumentListComponent>;

/*  const paperTypeListMockResponse = [{ "identifier": 125, "code": "APP", "descriptionText": "Appeal Document", "displayNameText": "Appeal Document", "id":"APP" }, { "identifier": 26, "code": "ATTRIBUTABLE OWNER", "descriptionText": "Attributable Owner", "displayNameText": "Attributable Owner" }, { "identifier": 72, "code": "CP", "descriptionText": "Corrected Petition", "displayNameText": "Corrected Petition" }, { "identifier": 25, "code": "COURT DECN", "descriptionText": "Court Decision", "displayNameText": "Court Decision" }, { "identifier": 71, "code": "CM", "descriptionText": "Court Mandate", "displayNameText": "Court Mandate" }];

  const filingPartyListMockResponse = [{ "code": "BOARD", "descriptionText": "Board", "displayNameText": "Board" }, { "code": "PATENT OWNER", "descriptionText": "Indicates artifact was submitted on behalf of Patent Owner.", "displayNameText": "Patent owner" }, { "code": "PETITIONER", "descriptionText": "Indicates artifact was submitted on behalf of Petitioner.", "displayNameText": "Petitioner" }];

  const availabilityListMockResponse = [{ "code": "PUBLIC", "descriptionText": "Available for everyone.", "displayNameText": "Public" }, { "code": "PRIVATE", "descriptionText": "Available to parties and board.", "displayNameText": "Parties and Board" }, { "code": "CONFIDENTIAL", "descriptionText": "Available to filing party and board.", "displayNameText": "Filing party and Board" }, { "code": "BOARD", "descriptionText": "Available only to board.", "displayNameText": "Board " }];
*/

  const originalRowMock = { "name": "Court Decision", "category": "Paper", "data": [], "fileName": "DEMO - Test PDF.pdf", "documentTypeCode": "Court Decision", "availability": "Public", "filingParty": "Board", "exhibitNumber": "3001", "pageCount": 1 };

  const globalMock = {

    edit: {
      enableEdit: false,
      editIndex: null,
      originalRow: {},
      rowToEdit: null
    }
  };


  const dummyElement = document.createElement('paymentsLink');





  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DocumentListComponent],

      providers: [provideMockStore({
        selectors: [
          { selector: CaseViewerSelectors.caseInfoData, value: { proceedingNo: '37553565' } },
          {selector: CaseViewerSelectors.userInfoData,value:{caseDetailsData: [{
            activeIn: "Active",
            apjSeniorityRank: 85,
            disiplanceCd: "Electrical",
            emailAddress: "Test_Jennifer.Bisk@USPTO.GOV",
            firstName: "Jennifer",
            fullName: "Bisk, Jennifer S.",
            jobClassificationCode: "APJ",
            lastName: "Bisk",
            leadApjIndicator: "APJ1",
            loginId: "jbisk",
            preferredFullName: "Bisk, Jennifer S.",
            privileges: null,
            roleDescription: "Judge",
            trialJudgeIndicator: "Judge",
            userIdentiifier: 5017,
            userWorkerNumber: "88548",
            isAdmin: false
            }]}}
        ]
      })

        ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(dummyElement);
    component.documentUploadObjList=[];
    component.documentUploadObjList.push(originalRowMock);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call open PDF', () => {
    spyOn(window, 'open');
    //component.petitionerIdentifier = "123456";
    component.openPDFInNewTab({ fileName: "Testing" });
  });


  it('should call editRow', () => {


    component.global = globalMock;
    let rowToEdit = originalRowMock;

    component.editRow(rowToEdit, 0);
    expect(component.global.edit.enableEdit).toBeTrue();
   // expect(component.global.edit.editIndex).toBe(0);
    // expect(component.global.edit.originalRow).toEqual(row);
  });


  it('should verify delete document removes item from documentUploadObjectList returns ', () => {


    component.documentUploadObjList = [];
    component.documentUploadObjList.push(originalRowMock);
    expect(component.documentUploadObjList.length).toBe(1);
    component.deleteDocument(originalRowMock);
    expect(component.documentUploadObjList.length).toBe(0);
  });



/*
  it('should call getNextExhibiNumber as patent owner', () => {
    let value = "PATENT OWNER";
    let row = originalRowMock;
    component.nextExhibitNumbers = {};
    component.nextExhibitNumbers.po = 2005;

    component.getNextExhibitNumber(value, row);
    expect(row.exhibitNumber).toBe(component.nextExhibitNumbers.po);
  });


  it('should call getNextExhibiNumber as board', () => {
    let value = "PETITIONER";
    let row = originalRowMock;
    component.nextExhibitNumbers = {};
    component.nextExhibitNumbers.petitioner = 1005;

    component.getNextExhibitNumber(value, row);
    expect(row.exhibitNumber).toBe(component.nextExhibitNumbers.petitioner);
  });


  it('should call validateExhibitNumberRange as board with number below range', () => {
    component.global = globalMock;
    let rowToEdit = originalRowMock;
    rowToEdit.filingParty = "Board";
    rowToEdit.exhibitNumber = "50";
    spyOn(component, 'setAlert');

    let result = component.validateExhibitNumberRange(rowToEdit);
    expect(component.setAlert).toHaveBeenCalled();
    expect(result).toBeFalse();
  });

  it('should call validateExhibitNumberRange as board with number above range', () => {
    component.global = globalMock;
    let rowToEdit = originalRowMock;
    rowToEdit.filingParty = "Board";
    rowToEdit.exhibitNumber = "5000";
    spyOn(component, 'setAlert');

    let result = component.validateExhibitNumberRange(rowToEdit);
    expect(component.setAlert).toHaveBeenCalled();
    expect(result).toBeFalse();
  });


  it('should call validateExhibitNumberRange as patent owner with number below range', () => {
    component.global = globalMock;
    let rowToEdit = originalRowMock;
    rowToEdit.filingParty = "Patent owner";
    rowToEdit.exhibitNumber = "50";
    spyOn(component, 'setAlert');

    let result = component.validateExhibitNumberRange(rowToEdit);
    expect(component.setAlert).toHaveBeenCalled();
    expect(result).toBeFalse();
  });

  it('should call validateExhibitNumberRange as patent owner with number above range', () => {
    component.global = globalMock;
    let rowToEdit = originalRowMock;
    rowToEdit.filingParty = "Patent owner";
    rowToEdit.exhibitNumber = "5000";
    spyOn(component, 'setAlert');

    let result = component.validateExhibitNumberRange(rowToEdit);
    expect(component.setAlert).toHaveBeenCalled();
    expect(result).toBeFalse();
  });


  it('should call validateExhibitNumberRange as petitioner with number below range', () => {
    component.global = globalMock;
    let rowToEdit = originalRowMock;
    rowToEdit.filingParty = "Petitioner";
    rowToEdit.exhibitNumber = "50";
    spyOn(component, 'setAlert');

    let result = component.validateExhibitNumberRange(rowToEdit);
    expect(component.setAlert).toHaveBeenCalled();
    expect(result).toBeFalse();
  });

  it('should call validateExhibitNumberRange as petitioner with number above range', () => {
    component.global = globalMock;
    let rowToEdit = originalRowMock;
    rowToEdit.filingParty = "Petitioner";
    rowToEdit.exhibitNumber = "5000";
    spyOn(component, 'setAlert');

    let result = component.validateExhibitNumberRange(rowToEdit);
    expect(component.setAlert).toHaveBeenCalled();
    expect(result).toBeFalse();
  });


  it('should call validateExhibitNumberRange as board with a valid number', () => {
    component.global = globalMock;
    let rowToEdit = originalRowMock;
    rowToEdit.filingParty = "Board";
    rowToEdit.exhibitNumber = "3005";

    let result = component.validateExhibitNumberRange(rowToEdit);
    expect(result).toBeTrue();
  });

  it("should get error string when calling export errors", () => {
    let returnValue = component.exportErrors();
  });
*/
});
