import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from "../app/components/login/login.component";
import { AuthGuard } from './guards/auth.guard';
import { CaseViewerComponent } from './components/case-viewer/case-viewer/case-viewer.component';
import { WorkspacesComponent } from './components/workspace/workspaces/workspaces.component';

export const routes: Routes = [
  {
    path: '',
    // redirectTo: '/login',
    redirectTo: '',
   pathMatch: 'full'
  },
  // {
  //   path: 'judge-portal',
  //   component: JudgePortalComponent,
  //   canActivate: [AuthGuard]
  // },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'case-viewer',
    component: CaseViewerComponent,
    // canActivate: [AuthGuard],
    runGuardsAndResolvers: 'always'
  },
  {
    path: 'case-viewer/:applicationNumber/:caseNumber/:scrollToId',
    component: CaseViewerComponent,
    // canActivate: [AuthGuard],p
    runGuardsAndResolvers: 'always'
  },
  {
    path: 'case-viewer/:applicationNumber/:caseNumber',
    component: CaseViewerComponent,
    // canActivate: [AuthGuard],
    runGuardsAndResolvers: 'always'
  },
  {
    path: 'case-viewer/:applicationNumber',
    component: CaseViewerComponent,
    // canActivate: [AuthGuard],
    runGuardsAndResolvers: 'always'
  },
  // {
  //   path: 'aiaTrialsWorkspace',
  //   component: WorkspacesComponent,
  //   runGuardsAndResolvers: 'always'
  // },
  {
    path: 'aiaTrialsWorkspace/:scrollToId',
    component: WorkspacesComponent,
    runGuardsAndResolvers: 'always',
    canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    onSameUrlNavigation: 'reload', useHash:true
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
