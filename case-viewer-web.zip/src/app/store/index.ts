import { ActionReducerMap } from '@ngrx/store';

import { CaseViewerState } from './case-viewer/case-viewer.state';
import { caseViewerReducer } from './case-viewer/case-viewer.reducer';

export interface State {
  caseViewerState: CaseViewerState
}
export const reducers: ActionReducerMap<State> = {
  caseViewerState: caseViewerReducer
}