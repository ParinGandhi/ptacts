import CaseHeaderModel from 'src/app/models/cases/CaseHeader.model';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import UserInfoModel from 'src/app/models/UserInfo.model';
import CasePhaseModel from 'src/app/models/common/CasePhase.model';

export interface CaseViewerState {
    caseHeader: CaseHeaderModel;
    jpViewError: Error;
    isloading:false;
    caseInfo: CaseInfoModel;
    userInfo: UserInfoModel;
    casePhase: CasePhaseModel
}

export const initializeState = (): CaseViewerState => {
    return {
        caseHeader: {
            patentNumberText:null,
            proceedingNumber:null,
            //derproceedingTypeDetails: null,
            techCenterNum:null,
            ptabReadOnlyUser:null,
            mileStoneDates: null,
            parties:null,
            attorneys: [],
            artUnit:null,
            casePhase:null,
            inventionTitle:null,
            keyDates: [],
            joinderTypes: [],
            petitionerPatentNumber: null,
            petitionerinventionTitle: null,
            petitionerTechCenterNum: null,
            petitionerArtUnit: null,
            derproceedingTypeDetails: {
                firstListedPetitionerApplicationNumber: null,
                firstListedPatentOwnerRespondentApplicationNumber: null,
                aiaReviewConfidentiality: null
            }
        }, jpViewError: null,
           isloading:false,
           caseInfo: {
            serialNo: null,
            proceedingNo: null
        },
        userInfo: {
            caseDetailsData: [],
            isJudge: false,
            isPanelingMember: false,
            isSplAdmin: false,
            isPl: false,
            userPermissionDetailsList: [],
            permissions: {}
        },
        casePhase: {
            casePhaseData:[]
        }
    };
}