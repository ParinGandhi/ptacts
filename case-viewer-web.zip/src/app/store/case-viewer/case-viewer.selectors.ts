import { createFeatureSelector, createSelector } from '@ngrx/store';
import { CaseViewerState } from './case-viewer.state';


const caseViewerData = createFeatureSelector<CaseViewerState>('caseViewerState');

export const caseHeaderData = createSelector(caseViewerData, s => s.caseHeader);

export const caseInfoData = createSelector(caseViewerData, s => s.caseInfo);

export const userInfoData = createSelector(caseViewerData, s => s.userInfo);

export const casePhaseData = createSelector(caseViewerData, s => s.casePhase);