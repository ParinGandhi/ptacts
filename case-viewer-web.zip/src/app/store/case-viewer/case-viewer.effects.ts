import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Router } from "@angular/router";
import { ToastrService } from "ngx-toastr";
import { Observable, of } from 'rxjs';
import { catchError, map, concatMap } from 'rxjs/operators';

import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import caseHeaderModel from 'src/app/models/cases/CaseHeader.model';
import UserInfoModel from 'src/app/models/UserInfo.model';
import { JpViewService } from 'src/app/services/jpview.service';

import * as caseViewerActions from './case-viewer.actions';
import { TrialsService } from 'src/app/services/trials.service';
import CasePhaseModel from 'src/app/models/common/CasePhase.model';
import { CaseViewerService } from 'src/app/services/case-viewer.service';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';



@Injectable()
export class CaseViewerEffects {

  constructor(
    private actions: Actions,
    private jpViewService: JpViewService,
    private caseViewerService: CaseViewerService,
    private trialsServices: TrialsService,
    private router: Router,
    private toastr: ToastrService,
    private commonUtils: CommonUtilitiesService
  ) { }

  getCaseHeader$:Observable<Action> = createEffect(() =>
  this.actions.pipe(
    ofType(caseViewerActions.GetCaseHeaderAction),
    concatMap(_action =>
        this.jpViewService.getCaseHeader(_action.urlSuffix).pipe(
          map((data: caseHeaderModel) => {
            return caseViewerActions.setCaseHeaderAction({ payload: data });
          }),
          catchError((error: Error) => {
            return of(caseViewerActions.ErrorCaseHeaderAction(error));
          })
        )
      )
    ));

    getCasePhase$:Observable<Action> = createEffect(() =>
    this.actions.pipe(
      ofType(caseViewerActions.GetCasePhaseAction),
      concatMap(_action =>
          this.trialsServices.getCaseStatus(_action.url).pipe(
            map((data: CasePhaseModel) => {
              console.log('data: ', data);
              return caseViewerActions.SuccessGetCasePhaseAction({ payload: data });
            }),
            catchError((error: Error) => {
              // this.toastr.error(`Error retrieving case phase`,``, {
              //   closeButton: true
              // } );
              return of(caseViewerActions.ErrorUserInfoAction(error));
            })
          )
        )
    ));


  getUserInfo$:Observable<Action> = createEffect(() =>
  this.actions.pipe(
    ofType(caseViewerActions.getUserInfoAction),
    concatMap(_action =>
        // this.jpViewService.getUserInfo(_action.url).pipe(
        this.caseViewerService.getUserInfo(_action.url).pipe(
          map((data: UserInfoModel) => {
            //  data.caseDetailsData[0].isAdmin = data.caseDetailsData[0].roleDescription === PtabTrialConstants.ROLES.ADMIN;
            //  data.isJudge= PtabTrialConstants.ROLES.JPVIEW.includes(data.caseDetailsData[0].roleDescription);
            //  data.isSplAdmin= PtabTrialConstants.ROLES.ADMIN_SPL.includes(data.caseDetailsData[0].roleDescription)
            //  data.isPl= PtabTrialConstants.ROLES.PL.includes(data.caseDetailsData[0].roleDescription)
            //  window.sessionStorage.setItem('userInfo', JSON.stringify(data.caseDetailsData[0]));
              // this.router.navigate(['/case-viewer']);

              // this.toastr.success(`Successfully logged in as ${data.caseDetailsData[0].fullName}`, "Login", {
              //   closeButton: true
              // } );
              data.permissions = this.commonUtils.setUserPermissions(data.userPermissionDetailsList);
              this.commonUtils.saveToSession(data);
            return caseViewerActions.SuccessGetUserInfoAction({ payload: data });
          }),
          catchError((error: Error) => {
            this.toastr.error(`Failed to log in. Please try again`, "Login", {
              closeButton: true
            } );
            return of(caseViewerActions.ErrorUserInfoAction(error));
          })
        )
      )
    ));

        }
