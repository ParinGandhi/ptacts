import { createAction, props } from '@ngrx/store';

import CaseHeaderModel from "src/app/models/cases/CaseHeader.model";
import CaseInfoModel from "src/app/models/CaseInfo.model";
import UserInfoModel from 'src/app/models/UserInfo.model';
import CasePhaseModel from 'src/app/models/common/CasePhase.model';

// CaseHeader Actions
export const GetCaseHeaderAction = createAction(
    '[CaseHeader] Begin Get case header',
    props<{ urlSuffix?: string }>()
  );

export const setCaseHeaderAction = createAction(
    '[CaseHeader] Set Case header',
    props<{ payload: CaseHeaderModel }>()
)

export const ErrorCaseHeaderAction = createAction('[CaseHeader] - Error', props<Error>());

export const GetCasePhaseAction = createAction(
  '[CasePhase] Get Case Phase',
  props<{ url?: string }>()
)

export const SuccessGetCasePhaseAction = createAction(
  '[CasePhase] - Success Get case phase',
  props<{ payload: CasePhaseModel }>()
);

export const ErrorCasePhaseAction = createAction(
  '[CasePhase] - Error', props<Error>());

// CaseInfo Actions
export const setCaseInfoAction = createAction(
    '[Judge Portal] Set Case Details',
    props<{ payload: CaseInfoModel }>()
)

// UserInfo Actions
export const getUserInfoAction = createAction(
    '[USERINFO] Begin Set User info',
    props<{ url?: string }>()
  );

  export const SuccessGetUserInfoAction = createAction(
      '[USERINFO] - Sucess Get user info',
      props<{ payload: UserInfoModel }>()
  );

  export const removeUserInfoAction = createAction(
    '[USERINFO] Remove user info',
    props<{ url?: string }>()
  );

  export const ErrorUserInfoAction = createAction('[USERINFO] - Error', props<Error>());

  export const testingOutput = function () {
      console.log("Testing")
  }