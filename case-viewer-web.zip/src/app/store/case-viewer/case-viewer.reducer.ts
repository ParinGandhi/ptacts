import { Action, createReducer, on } from '@ngrx/store';
import * as CaseViewerActions from './case-viewer.actions';
import { CaseViewerState, initializeState } from './case-viewer.state';

const initialState = initializeState();

const reducer = createReducer(initialState,
  on(CaseViewerActions.setCaseHeaderAction, (state: CaseViewerState, { payload }) => {
    return { ...state, caseHeader: payload };
  }),
  on(CaseViewerActions.ErrorCaseHeaderAction, (state: CaseViewerState, error) => {
    return { ...state, jpViewError: error };
  }),
  on(CaseViewerActions.setCaseInfoAction, (state: CaseViewerState, { payload }) => {
    return { ...state, caseInfo: payload };
  }),
  on(CaseViewerActions.SuccessGetUserInfoAction, (state: CaseViewerState, { payload }) => {
    return { ...state, userInfo: payload };
  }),
  on(CaseViewerActions.SuccessGetCasePhaseAction, (state: CaseViewerState, { payload }) => {
    return { ...state, casePhase: payload };
  })
);

export function caseViewerReducer(state: CaseViewerState | undefined, action: Action) {
    return reducer(state, action);
}