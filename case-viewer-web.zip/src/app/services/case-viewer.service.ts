import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PtabTrialConstants } from '../constants/ptab-trials.constants';
import { environment } from 'src/environments/environment';
import CaseHeaderModel from '../models/cases/CaseHeader.model';
import UserInfoModel from '../models/UserInfo.model';

@Injectable({
  providedIn: 'root'
})
export class CaseViewerService {

  private CASEVIEWER_BASE_URL = environment.CASEVIEWER_SERVICE_API;

  getHeaders(addResponseType) {
    let userName = JSON.parse(window.sessionStorage.getItem('userInfo'));
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'user-name': userName.loginId,
      }),
      withCredentials: true,
      crossDomain: true
    };
    if (addResponseType) {
      httpOptions.headers.set('responseType', 'arraybuffer' as 'json')
    }
    return httpOptions;
    }

  constructor(private httpclient: HttpClient) { }


  getPayments(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(`${this.CASEVIEWER_BASE_URL}${PtabTrialConstants.PAYMENTS}${proceedingNo}`);
  }

  getUserInfo(userName: string): Observable<UserInfoModel> {
    return this.httpclient.get<UserInfoModel>(`${this.CASEVIEWER_BASE_URL}${PtabTrialConstants.USER_INFO}${userName}`);
  }

  whoAmI(): Observable<any> {
    return this.httpclient.get<any>(`${this.CASEVIEWER_BASE_URL}${PtabTrialConstants.WHO_AM_I}`);
  }

  getOpenPalm(): Observable<any> {
    return this.httpclient.get<any>(`${this.CASEVIEWER_BASE_URL}${PtabTrialConstants.PALM_URL}`);
  }

  getHelpUrl() : Observable<any> {
    return this.httpclient.get<any>(`${this.CASEVIEWER_BASE_URL}${PtabTrialConstants.HELP_URL}`);
  }
  caseSearch(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(`${this.CASEVIEWER_BASE_URL}${PtabTrialConstants.GENERAL.CASE_SEARCH}${proceedingNo}`, this.getHeaders(false));
  }

  getAppealsUrl() : Observable<any> {
    return this.httpclient.get<any>(`${this.CASEVIEWER_BASE_URL}${PtabTrialConstants.APPEALS_URL}`);
  }

}
