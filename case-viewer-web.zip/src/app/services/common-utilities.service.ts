import { Injectable } from '@angular/core';
import { PtabTrialConstants } from '../constants/ptab-trials.constants';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ConfirmDialogComponent } from '../shared/confirm-dialog/confirm-dialog.component';
import { take } from 'rxjs/internal/operators/take';
import { InfoModalComponent } from '../components/common/info-modal/info-modal.component';
import InfoModalModel from '../models/common/InfoModal.model';
import { DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { JpViewService } from './jpview.service';
import { CaseViewerService } from './case-viewer.service';
// import { ImportPanelComponent } from "../components/workspace/modals/import-panel/import-panel.component";

@Injectable({
  providedIn: 'root'
})
export class CommonUtilitiesService {

  modalRef: BsModalRef;
  confidentialityInfo:string;

  constructor(
    private modalService: BsModalService,
    private datePipe: DatePipe,
    private toastr: ToastrService,
    private jpViewService: JpViewService,
    private caseViewerService: CaseViewerService
  ) { }


  /**
   * This will set the default ngSelect2 typeahead options.
   */
  setTypeaheadOptions() {
    return {
      multiple: false,
      closeOnSelect: true,
      width: '100%',
      allowClear: true,
      theme: 'bootstrap',
      openOnEnter: true,
      // minimumResultsForSearch: Infinity - use to hide search box
    }
  };


  /**
   * This will set the ngSelect2 dropdown with the proper id and text values
   *
   * @param list : array - the list of items to be displayed in the dropdown
   * @param idProperty : string - the property that should be assigned to ID
   * @param descriptionProperty : string - the property that should be assigned to text
   */
  setTypeaheadList(list, idProperty, textProperty) {
    list.forEach(element => {
      element.id = element[idProperty];
      element.text = element[textProperty];
    });
    return list;
  }


  /** Set backdrop shadow for second modal */
  setSecondModalBackgroundColor() {
    let  element =  document.getElementsByClassName('second-modal')[0];
    if (!element) {
      return;
    }

    document.getElementsByClassName('second-modal')[0].parentElement.style.backgroundColor = PtabTrialConstants.MISC.SECOND_MODAL_BG_COLOR;
  }


  /**
   * This will open the abandon changes modal and return the modalRef
   *
   * @param message: string - message to be displayed on the modal
   */
  openAbandonChangesModal(message: string) {
    const initialState = {
      modal: {
        title: "Abandon unsaved information?",
        subText: `${message} Your changes will be lost.`,
        closeBtnName: "No, return to page",
        yesBtnName: "Yes, abandon changes",
        yesBtnClass: "btn-danger",
        isConfirm: false
      }
    };
    this.modalRef = this.modalService.show(ConfirmDialogComponent, {
      animated: true,
      backdrop: 'static',
      class: 'modal-md second-modal',
      initialState
    });
    this.setSecondModalBackgroundColor();
    return this.modalRef;
  }


  /**
   * This will open the confirmation modal with the appropriate params
   *
   * @param modal: InfoModalModel - modal params
   */
  openConfirmModal(modal: InfoModalModel) {
    const initialState: any = {
      modal: modal
    };
    this.modalRef = this.modalService.show(InfoModalComponent, {
      animated: true,
      backdrop: 'static',
      class: 'modal-md second-modal',
      initialState
    });
    this.setSecondModalBackgroundColor();
    return this.modalRef;
  };


  checkIfPanelingMember(loggedInUser) {
    let isPanelMember: boolean = false;
    if (loggedInUser && loggedInUser.privileges && loggedInUser.privileges.length > 0) {
      isPanelMember = loggedInUser.privileges.some(p => PtabTrialConstants.ROLES.PANEL.indexOf(p) >= 0);
    }
    return isPanelMember;
  }


  setDateOnDatePicker(date) {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }


  convertDatePickerToDisplayDate(datePickerDate) {
    // const newDate = new Date(datePickerDate);
    return this.datePipe.transform(datePickerDate, 'MM/dd/yyyy');
  }


  /**
   * This will convert the date picker date from 'yyyy-MM-dd' format to 13 digit epoch time.
   * This will set the time to 00:00 to compensate for timezone differences.
   *
   * @param datePickerDate : string - in the form of 'yyyy-MM-dd'
   */
  convertDatePickerToEpoch(datePickerDate) {
    return Date.parse(`${datePickerDate}T00:00`);
  }


  setToastr(status, message) {
    this.toastr[status](`${message}`, "", {
      closeButton: true
    });
  }


  formatNumber(numberToFormat) {
    let formatter = new Intl.NumberFormat('en-US');
    return formatter.format(numberToFormat);
  }


  openModal(modalComponent, initialState, modalClass) {
    this.modalRef = this.modalService.show(modalComponent, {
      animated: true,
      backdrop: true,
      ignoreBackdropClick: true,
      class: modalClass,
      initialState
    });
    return this.modalRef;
  }

  /**
   * Common function to return date string based on provided milestoneDate
   *
   * @param keyDates - milestoneDt string from service response
   * @param dateNeeded - name of date needed (names are in the constant file)
   * @returns - date string 'MM/dd/yyyy'
   */
  parseKeyDates(keyDates, dateNeeded) {
    let resp = null;
    if (keyDates) {
      const parsedKeyDates = JSON.parse(keyDates);
      if (parsedKeyDates && parsedKeyDates.proceedingMileStoneResponse) {
        const dateFound = parsedKeyDates.proceedingMileStoneResponse.find((keyDate) => {
          return keyDate.mileStoneTypeName ? keyDate.mileStoneTypeName.toLowerCase() === dateNeeded.toLowerCase() : null;
        });
        resp = dateFound ? this.datePipe.transform(new Date(dateFound.mileStoneDate).getTime() + 25200000, 'MM/dd/yyyy') : null;
        // if (dateFound) {
        //   const estDate = new Date(new Date(parseInt(dateFound.mileStoneDate)).toLocaleString('en-US', { timeZone: 'America/New_York' })).getTime();
        //   resp = this.datePipe.transform(estDate, 'MM/dd/yyyy');
        // }
      } else if (parsedKeyDates && Array.isArray(parsedKeyDates)) {
        const dateFound = parsedKeyDates.find((keyDate) => {
          return keyDate.mileStoneTypeName ? keyDate.mileStoneTypeName.toLowerCase() === dateNeeded.toLowerCase() : null;
        });
        // resp = dateFound ? this.datePipe.transform(new Date(dateFound.mileStoneDate).getTime(), 'MM/dd/yyyy hh:mm a') : null;
        resp = dateFound ? this.datePipe.transform(new Date(dateFound.mileStoneDate).getTime() + 25200000, 'MM/dd/yyyy') : null;
        // if (dateFound) {
        //   const estDate = new Date(new Date(parseInt(dateFound.mileStoneDate)).toLocaleString('en-US', { timeZone: 'America/New_York' })).getTime();
        //   resp = this.datePipe.transform(estDate, 'MM/dd/yyyy');
        // }
      }
    }
    return resp;
  }


   /**
   * Common function to return date string based on provided milestoneDate
   *
   * @param keyDates - milestoneDt string from service response
   * @param dateNeeded - name of date needed (names are in the constant file)
   * @returns - date string 'MM/dd/yyyy'
   */
    parseKeyDatesTemp(keyDates, dateNeeded, dateType) {
      let resp = null;
      if (keyDates) {
        const parsedKeyDates = JSON.parse(keyDates);
        if (parsedKeyDates && parsedKeyDates.proceedingMileStoneResponse) {
          const dateFound = parsedKeyDates.proceedingMileStoneResponse.find((keyDate) => {
            return keyDate.mileStoneTypeName ? keyDate.mileStoneTypeName.toLowerCase() === dateNeeded.toLowerCase() : null;
          });
          if (dateType === PtabTrialConstants.DATE_TYPE.DATE) {
            resp = dateFound ? this.datePipe.transform(new Date(dateFound.mileStoneDate).getTime(), 'MM/dd/yyyy') : null;
          } else if (dateType === PtabTrialConstants.DATE_TYPE.TIMESTAMP) {
            resp = dateFound ? this.datePipe.transform(new Date(dateFound.mileStoneDate).getTime(), 'MM/dd/yyyy hh:mm a') : null;
          }

        } else if (parsedKeyDates && Array.isArray(parsedKeyDates)) {
          const dateFound = parsedKeyDates.find((keyDate) => {
            return keyDate.mileStoneTypeName ? keyDate.mileStoneTypeName.toLowerCase() === dateNeeded.toLowerCase() : null;
          });
          if (dateType === PtabTrialConstants.DATE_TYPE.DATE) {
            resp = dateFound ? this.datePipe.transform(new Date(dateFound.mileStoneDate).getTime(), 'MM/dd/yyyy') : null;
          } else if (dateType === PtabTrialConstants.DATE_TYPE.TIMESTAMP) {
            resp = dateFound ? this.datePipe.transform(new Date(dateFound.mileStoneDate).getTime(), 'MM/dd/yyyy hh:mm a') : null;
          }
        }
      }
      return resp;
  }




  // findDecisionOutcome(decisionOutcome) {
  //   let resp = null;
  //   if (decisionOutcome) {
  //     let decisionOutcomeFound = null;
  //     const parsedDecisionOutcomes = JSON.parse(decisionOutcome);
  //     if (parsedDecisionOutcomes) {
  //       parsedDecisionOutcomes.forEach((element) => {

  //       });
  //       for (let i = 0; i < parsedDecisionOutcomes.length; i++) {
  //         if (parsedDecisionOutcomes[i].decisionOutcomeDetails && parsedDecisionOutcomes[i].decisionOutcomeDetails.descriptionText) {
  //           resp = parsedDecisionOutcomes[i].decisionOutcomeDetails.descriptionText;
  //         }
  //         if (resp) {
  //           break;
  //         }
  //       }
  //     }
  //   }
  //   return resp;
  // }



  findDecisionOutcome(decisionOutcome) {
    let resp = null;
    if (decisionOutcome) {
      let decisionOutcomeFound = null;
      const parsedDecisionOutcomes = JSON.parse(decisionOutcome);
      if (parsedDecisionOutcomes && parsedDecisionOutcomes.latestOutcomeDetails) {
        resp = parsedDecisionOutcomes.latestOutcomeDetails ? parsedDecisionOutcomes.latestOutcomeDetails.descriptionText : null;
        // parsedDecisionOutcomes.forEach((element) => {

        // });
        // for (let i = 0; i < parsedDecisionOutcomes.length; i++) {
        //   if (parsedDecisionOutcomes[i].decisionOutcomeDetails && parsedDecisionOutcomes[i].decisionOutcomeDetails.descriptionText) {
        //     resp = parsedDecisionOutcomes[i].decisionOutcomeDetails.descriptionText;
        //   }
        //   if (resp) {
        //     break;
        //   }
        // }
      } else if (parsedDecisionOutcomes && Array.isArray(parsedDecisionOutcomes)) {
         for (let i = 0; i < parsedDecisionOutcomes.length; i++) {
          if (parsedDecisionOutcomes[i].decisionOutcomeDetails && parsedDecisionOutcomes[i].decisionOutcomeDetails.descriptionText) {
            resp = parsedDecisionOutcomes[i].decisionOutcomeDetails ? parsedDecisionOutcomes[i].decisionOutcomeDetails.descriptionText : null;
          }
          if (resp) {
            break;
          }
        }
      }
    }
    return resp;
  }



/**
 * Common function to return key date with description based on provided date
 *
 * @param keyDates - milestoneDt string from service response
 * @param dateNeeded - name of the date needed (names are in the constant file)
 * @returns - date/descrption string 'Filing Date - MM/dd/yyyy'
 */
  parseKeyDatesDescription(keyDates, dateNeeded) {
    let resp = null;
    if (keyDates) {
      const parsedKeyDates = JSON.parse(keyDates);
      if (parsedKeyDates) {
        const dateFound = parsedKeyDates.find((keyDate) => {
          return keyDate.mileStoneTypeName.toLowerCase() === dateNeeded.toLowerCase();
        });
        if (dateFound && dateFound.mileStoneDate && dateFound.mileStoneDescription) {
          resp = `${dateFound.mileStoneDescription} - ${dateFound.mileStoneDate}`;
        }
      }
    }
    return resp;
  }


  // parseAllKeyDates(keyDates) {
  //   let resp = {};
  //   if (keyDates) {
  //     const parsedKeyDates = JSON.parse(keyDates);
  //     if (parsedKeyDates) {
  //       parsedKeyDates.forEach((keyDate) => {
  //         let tempDate = null;

  //       });
  //     }
  //   }
  // }


  parseAllPartiesInfo(allPartiesInfo) {
    // return allPartiesInfo ? JSON.parse(allPartiesInfo) : null;
    if (allPartiesInfo) {
      try {
        return JSON.parse(allPartiesInfo);
      } catch (e) {
        // console.error(e);
        return null;
      }
    } else {
      return null;
    }
  }


  openInCaseViewer(proceedingNo) {
    // this.jpViewService.getDocuments(`${PtabTrialConstants.CASE_VIEWER_URL}/case-viewer/caseNumber-search?caseNumber=${proceedingNo}`).subscribe((caseDetails) => {
    this.caseViewerService.caseSearch(proceedingNo).subscribe((caseDetails) => {
      let caseInfo = {
        "serialNo": caseDetails.serialNumber[0].trim(),
        "proceedingNo": caseDetails.appealNumber[0],
        "scrollToId": 'documents'
      }
      // this.store.dispatch(CaseViewerActions.setCaseInfoAction({ payload: caseInfo }));
      let tempCaseInfo = JSON.parse(window.sessionStorage.getItem('caseInfo'));
      window.sessionStorage.setItem('caseInfo', JSON.stringify(caseInfo));
      let currentUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
      // this.caseNumberSearch = null;
      let newTabUrl = `${window.location.protocol}//${window.location.hostname}`;
      newTabUrl += window.location.port !== "" ? `:${window.location.port}` : "";
      newTabUrl += window.location.hostname === 'localhost' ? `/#/case-viewer/${caseInfo.serialNo}/${caseInfo.proceedingNo}/documents` :
       `${PtabTrialConstants.BASE_URL}/#` +`/case-viewer/${caseInfo.serialNo}/${caseInfo.proceedingNo}/documents`;

      let prefix = "fromJudgePortal"
        window.open(newTabUrl, prefix + JSON.stringify({
                "caseInfo": caseInfo,
                "currentUser": currentUser
        }));
      window.sessionStorage.setItem('caseInfo', JSON.stringify(tempCaseInfo));
    })
  }

/** This will save user permission response to session
 * It will encode it twice before saving
 */
  saveToSession(data) {
    if (data) {
      let enc1 = window.btoa(JSON.stringify(data));
    let enc2 = window.btoa(enc1);
    window.sessionStorage.setItem("up", enc2);
    }
    // window.sessionStorage.setItem("up", JSON.stringify(data));
  }


  getFromSession() {
    let userPermissions = window.sessionStorage.getItem("up");
    let  dec2 = userPermissions ? window.atob(userPermissions) : null;
    let dec1 = dec2 ? window.atob(dec2) : null;
    return dec1 ? JSON.parse(dec1) : null;
    // let tempUp = window.sessionStorage.getItem("up");
    // return tempUp ? JSON.parse(tempUp) : null;
  }


  setUserPermissions(permissionsList) {
    let permList = {};
    if (permissionsList && permissionsList.length > 0) {
      permissionsList.forEach((perm) => {
        if (PtabTrialConstants.COMPONENT_IDS.includes(perm.objectUUID)) {
          if (!permList[perm.objectUUID]) {
            permList[perm.objectUUID] = {};
            permList[perm.objectUUID].readOnly = false;
            permList[perm.objectUUID].canPost = false;
            permList[perm.objectUUID].canEdit = false;
            permList[perm.objectUUID].canDelete = false;
          }
          switch (perm.permissionTypeNameText.toLowerCase()) {
            case "read":
              permList[perm.objectUUID].readOnly = true;
              break;
              case "insert":
                permList[perm.objectUUID].canPost = true;
              break;
              case "update":
                permList[perm.objectUUID].canEdit = true;
              break;
              case "delete":
                permList[perm.objectUUID].canDelete = true;
                break;
            default:
              break;
          }
        }
      });
    }
    return permList;
  }


  copyToClipboard(stringToCopy, counselType) {
    let counsel = counselType === 'petitionCounsel' ? 'Petitioner' : 'PO/Respondant';
    if (stringToCopy) {
      const body = document.querySelector('body');
      const area = document.createElement('textarea');
      body.appendChild(area);
      area.value = stringToCopy;
      area.select();
      document.execCommand('copy');
      body.removeChild(area);
      this.setToastr("success", `Copied all ${counsel} emails to clipboard`);
    } else {
      this.setToastr("warning", "No emails to copy");
    }
  }

}
