import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PtabTrialConstants } from '../constants/ptab-trials.constants';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  /** Location variables */

  private port: string = '8081';


  /**
 * * LOCAL DEVELOPMENT
 * ? Uncomment below ONLY if you are running Common Services locally.
 * ? Otherwise use the appropriate environment commands
 * ? DEV - npm run start:dev
 * ? PVT - npm run start:pvt
 */
  // private COMMON_BASE_URL: string = `${PtabTrialConstants.ENVIRONMENTS.LOCAL}${port}`;
  private COMMON_BASE_URL: string = environment.COMMON_SERVICE_API;

  getFileUploadHeaders() {
    let userName = JSON.parse(window.sessionStorage.getItem('userInfo'));
    const httpOptions = {
      headers: new HttpHeaders({
        // 'Content-Type': "",
        'user-name': userName.loginId,
      }),
      withCredentials: true,
      crossDomain: true
    };
    return httpOptions;
  }


  constructor(private httpclient: HttpClient) { }


/**
 * * CaseViewer - update documents modal */

getReferenceData(url: string): Observable<any> {
  return this.httpclient.get<any>(this.COMMON_BASE_URL + url);
  }


  openPdf(url: string) {
    window.open(this.COMMON_BASE_URL + url);
  }

  getDecisionOutcomeTypes(url: string): Observable<any> {
    return this.httpclient.get<any>(this.COMMON_BASE_URL + url);
    }

  getNotificationsList(url:string): Observable<any> {
    // return this.httpclient.get<any>('https://ptab-q121-trial-intservices-wildfly-green-0.pvt.uspto.gov:8443/PTABE2ECommonServices'+ url);
     return this.httpclient.get<any>(this.COMMON_BASE_URL + url);
  }


  getDropDownList(refType: string): Observable<any> {
    return this.httpclient.get<any>(`${this.COMMON_BASE_URL}${PtabTrialConstants.REFERENCE_TYPES.TYPE_CODE}${refType}`);
  }

  getAppealsStatuses(url: string): Observable<any> {
    return this.httpclient.get<any>(this.COMMON_BASE_URL + url);
  }

  getMotionStatusTypes(url: string): Observable<any> {
    return this.httpclient.get<any>(this.COMMON_BASE_URL + url);
  }

  getFromCodeReference(referenceType: string): Observable<any> {
    return this.httpclient.get<any>(`${this.COMMON_BASE_URL}${PtabTrialConstants.REFERENCE_TYPES.TYPE_CODE}${referenceType}`);
  }


  getCaseInfoByProceedingNo(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(`${this.COMMON_BASE_URL}${PtabTrialConstants.PETITIONS}${proceedingNo}`);
  }

  getPaperTypes(proceedingNo: string, recipientType: string): Observable<any> {
    return this.httpclient.get<any>(`${this.COMMON_BASE_URL}${PtabTrialConstants.REFERENCE_TYPES.PAPER_TYPE_BY_PROCEEDING_NO}${proceedingNo}${PtabTrialConstants.REFERENCE_TYPES.RECIPIENT_TYPE}${recipientType}`);
  }


  uploadDocuments(url: string, fileToUpload: any) {
    // console.log(fileToUpload);
    const formData: FormData = new FormData();
    formData.append('file', fileToUpload)
    return this.httpclient.post<any>(`${this.COMMON_BASE_URL}${url}`, formData, this.getFileUploadHeaders());
  }


}
