import { DatePipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { PtabTrialConstants } from '../constants/ptab-trials.constants';
import { CommonUtilitiesService } from './common-utilities.service';

@Injectable({
  providedIn: 'root'
})
export class GridHelperService {

  constructor(
    private datePipe: DatePipe,
    private commonUtils: CommonUtilitiesService
  ) { }


  sortedDates(date1, date2) {
    var a= new Date(date1), b = new Date(date2);
     if (a > b)
       return 1;
     if (a < b)
       return -1;

     return 0;
 };


    // DATE COMPARATOR FOR SORTING
    dateComparator(date1, date2) {
      // var date1Number = monthToNum(date1);
      // var date2Number = monthToNum(date2);
      var date1Number = new Date(date1).getTime();
      var date2Number = new Date(date2).getTime();

      if (date1Number === null && date2Number === null) {
        return 0;
      }
      if (date1Number === null) {
        return -1;
      }
      if (date2Number === null) {
        return 1;
      }

        return date1Number - date2Number;

        // HELPER FOR DATE COMPARISON
      // function monthToNum(date) {
      //   date = new Date(date);
      //     if (date === undefined || date === null) {
      //       return null;
      //     }

      //     var yearNumber = date.substring(6, 10);
      //     var monthNumber = date.substring(3, 5);
      //     var dayNumber = date.substring(0, 2);

      //     var result = yearNumber * 10000 + monthNumber * 100 + dayNumber;
      //     // 29/08/2004 => 20040829
      //     return result;
      //   }
    }


  convertDateToString(epochDate) {
      if (!epochDate) {
      return '';
    }
    return this.datePipe.transform(parseInt(epochDate) + 25200000, 'MM/dd/yyyy')
    // return epochDate ? this.datePipe.transform(parseInt(epochDate) + 25200000, 'MM/dd/yyyy') : null;
  //   if (!epochDate) {
  //     return '';
  //   }
  //   const estDate = new Date(new Date(parseInt(epochDate)).toLocaleString('en-US', { timeZone: 'America/New_York' })).getTime();
  // //  return new Date(new Date(value).toLocaleString('en-US', { timeZone: 'America/New_York' })).getTime();
  //   return this.datePipe.transform(estDate, 'MM/dd/yyyy');
  }

  convertDateToTimeStamp(epochDate) {
    // return epochDate ? this.datePipe.transform(epochDate, 'MM/dd/yyyy hh:mm:ss a') : null;
    if (!epochDate) {
      return '';
    }
    const estDate = new Date(new Date(parseInt(epochDate)).toLocaleString('en-US', { timeZone: 'America/New_York' })).getTime();
  //  return new Date(new Date(value).toLocaleString('en-US', { timeZone: 'America/New_York' })).getTime();
    return this.datePipe.transform(estDate, 'MM/dd/yyyy hh:mm:ss a');
  }

  formatJudgePanelTooltip(params) {
    let toolTipArray = [];
    if (params.data && params.data.judgePanelList && params.data.judgePanelList.length > 0) {
      params.data.judgePanelList.forEach((judge) => {
        let judgeName = (judge.lastName ? judge.lastName : "") + " " + (judge.firstName ? judge.firstName : "") + " " + (judge.middleInitial ? judge.middleInitial : "")
        toolTipArray.push(judgeName.trim());
      })
      const lineBreak = true;
      return { toolTipArray, lineBreak };
    } else if (params.data && params.data.judges && params.data.judges.length > 0) {
      params.data.judges.forEach((judge) => {
        if (judge) {
          toolTipArray.push(judge.trim());
        }
      })
      const lineBreak = true;
      return { toolTipArray, lineBreak };
    } else if (params.data && params.data.proceedingMetadata && params.data.proceedingMetadata.judges && params.data.proceedingMetadata.judges.length > 0) {
      params.data.proceedingMetadata.judges.forEach((judge) => {
        if (judge) {
          toolTipArray.push(judge.trim());
        }
      })
      const lineBreak = true;
      return { toolTipArray, lineBreak };
    }
  }


  formatSearchJudgeTooltip(params) {
    let toolTipArray = [];
    if (params.data.judges) {
      toolTipArray = [...params.data.judges];
      // toolTipArray.push(params.data.judge1);
      // toolTipArray.push(params.data.judge2);
      // toolTipArray.push(params.data.judge3);
    }
    const lineBreak = true;
    return {toolTipArray, lineBreak};
  }

  formatRecipientsTooltip(params) {

    let recipientList = [];
    let ccRecipientList = [];
    let bcRecipientcList = [];
    if(params.data.tolist && params.data.tolist.length > 0) {
      params.data.tolist.forEach((id) => {
        recipientList.push(id.trim());
      })
      if(params.data.ccList && params.data.ccList.length > 0) {
        params.data.ccList.forEach((id) => {
          ccRecipientList.push(id.trim());
        })
      }
      if(params.data.bccList && params.data.bccList.length > 0) {
        params.data.bccList.forEach((id) => {
          bcRecipientcList.push(id.trim());
        })
      }
      const lineBreak = false;
      return  {recipientList, ccRecipientList, bcRecipientcList, lineBreak}
    }
  };

  formatCommentsTooltip(params) {
    let commentList = [];
    if (params.data.comments && params.data.comments.length > 0) {
      params.data.comments.forEach((comment) => {
        commentList.push(comment.trim());
      })
      const lineBreak = false;
      return { commentList, lineBreak };
    }
  }

  formatPetVsPOTooltip(params) {
    let petitionVsPo = null;
    if (params.data.petitionerNameVsrespondentName) {
      petitionVsPo = params.data.petitionerNameVsrespondentName.trim();
      const lineBreak = false;
      const tooltipType = 'petitionerVsPo'
      return { petitionVsPo, lineBreak, tooltipType };
    }
  }


  formatStringTooltip(params, propName) {
    let stringValue: string = null;
    if (params.data[propName]) {
      stringValue = params.data[propName].trim();
      const lineBreak = false;
      const tooltipType = 'generalString'
      return { stringValue, lineBreak, tooltipType };
    }
  }




  exportDataAsCsv(gridApi, fileName: string) {
     gridApi.exportDataAsCsv(this.getExportParams(fileName));
  }

  getExportParams(fileName) {
    let currentTimeStamp = this.datePipe.transform(Date.now(), 'MM/dd/yyyy hh:mm:ss a')
    return {
      fileName: `${fileName} ${currentTimeStamp}`,
      allColumns: true,
      processCellCallback: this.judgePanelCallback,
      processHeaderCallback: this.recipientsHeaderCallback,
    }
  }

  judgePanelCallback(params) {
    if (params.column.colId === "judgePanel" || params.column.colId === "judges") {
      if (params.node.data.judgePanelList && params.node.data.judgePanelList.length > 0) {
        let judges = "";
        for (var i = 0; i < params.node.data.judgePanelList.length; i++) {
          if (i !== 0) {
            judges += ", ";
          }
          let firstName = params.node.data.judgePanelList[i].firstName ? params.node.data.judgePanelList[i].firstName : '';
          let lastName = params.node.data.judgePanelList[i].lastName ? params.node.data.judgePanelList[i].lastName : '';
          let middleInitial = params.node.data.judgePanelList[i].middleInitial ? params.node.data.judgePanelList[i].middleInitial : '';
          judges += `${lastName}, ${firstName} ${middleInitial}`;
        }
        return judges;
      } else if (params.node.data.judges && params.node.data.judges.length > 0) {
        let judgeList = [];
        params.node.data.judges.forEach(judge => {
          if (judge) {
            judgeList.push(judge);
          }
        });
        return judgeList.join(" | ");
      }
    } else if (params.column.userProvidedColDef.type === 'date' || params.column.userProvidedColDef.type === 'timestamp') {
      return params.value ? ` ${params.value}` : '';
    } else {
      return params.value;
    }
  }

  recipientsHeaderCallback(params) {
    if(params.column.colId === "allRecipientList") {
      params.column.colDef.headerName = "All recipient(s)";
     return  params.column.colDef.headerName;
      // return params.column.userProvidedColDef.headerName = "All recipient(s)"

    }else {
      return params.column.colDef.headerName;
    }
  }

  /**
   * Value gettger function to display petitioner patent number.
   * If patent number does not exist, it will return application number
   */
  valueGetterForPetitionerPatentNoAia(params) {
    if (!params.data.petiPatentNumber || params.data.petiPatentNumber === "") {
      return params.data.petiApplicationId;
    } else {
      return params.data.petiPatentNumber
    }
  }


  /**
   * Value gettger function to display petitioner patent number.
   * If patent number does not exist, it will return application number
   */
   valueGetterForPOPatentNoAia(params) {
    if (!params.data.poPatentNumber || params.data.poPatentNumber === "") {
      return params.data.poApplicationId;
    } else {
      return params.data.poPatentNumber
    }
  }

  valueGetterForPetitionerPatentNo(params) {
    if (!params.data.petitionerPatentNumber || params.data.petitionerPatentNumber === "") {
      return params.data.petitionerapplicationId;
    } else {
      return params.data.petitionerPatentNumber
    }
  }


  /**
   * Value gettger function to display petitioner patent number.
   * If patent number does not exist, it will return application number
   */
   valueGetterForPOPatentNo(params) {
    if (!params.data.patentNumber || params.data.patentNumber === "") {
      return params.data.applicationId;
    } else {
      return params.data.patentNumber
    }
  }
/*petitionerApplNumber*/
valueGetterForPetitionerInitiatedCase(params) {
  if (params && params.data && params.data) {
    // const caseType = ['IPR', 'PGR', 'CBM'];
    if (!params.data.proceedingNumber || PtabTrialConstants.CASE_TYPES.indexOf(params.data.proceedingNumber.slice(0, 3)) > -1) {
      return null;
    }
    else if (!params.data.petiPatentNumber || params.data.petiPatentNumber === "") {
    return params.data.petiApplicationId;
  } else {
    return params.data.petiPatentNumber
  }
  }
}
  valueGetterForPendingPanelingPatentNo(params) {
    if (!params.data.poPatentNumber || params.data.poPatentNumber === "") {
      return params.data.poApplicationId;
    } else {
      return params.data.poPatentNumber
    }
  }

  valueGetterPendingPanelingPetitionerNo(params) {
    const caseType = ['IPR', 'PGR', 'CBM'];
    if (caseType.indexOf(params.data.proceedingNumber.slice(0, 3)) > -1) {
      return null;
    }
    else if (!params.data.petitionerPatentNumber || params.data.petitionerPatentNumber === "") {
      return params.data.petitionerApplicationId;
    } else {
      return params.data.petitionerPatentNumber
    }
  }

  /* workqueue and tasks po patent / application number for tasks and workqueue*/
  valueGetterPOPatentNo(params) {
    if (!params.data.poPatentNumber || params.data.poPatentNumber === "") {
      return params.data.poApplicationIdentifier;
    } else {
      return params.data.poPatentNumber
    }
  }

  /* workqueue and tasks po patent / application number for tasks and workqueue*/
  valueGetterPetitionerPatentNo(params) {
    const caseType = ['IPR', 'PGR', 'CBM'];
    if (caseType.indexOf(params.data.proceedingNumber.slice(0, 3)) > -1) {
      return null;
    }
    else if (!params.data.petitionerPatentNumber || params.data.petitionerPatentNumber === "") {
      return params.data.petitionerApplicationIdentifier;
    } else {
      return params.data.petitionerPatentNumber
    }
  }

/* all initiated petitions POPatentNumber */
valueGetterPOPatentNumber(params) {

  if (!params.data.poPatentNumber || params.data.poPatentNumber === "") {
    return params.data.poApplicationId;
  } else {
    return params.data.poPatentNumber
  }
}
  /**
   * Default filter change function
   */
  onFilterChanged(gridApi) {
    const filterModel = gridApi.getFilterModel();
    const resp = {
      numberOfFilters: null,
      totalCount: null
    }
    resp.numberOfFilters = Object.keys(filterModel).length;
    resp.totalCount = this.commonUtils.formatNumber(gridApi.getDisplayedRowCount());
    return resp;
  }


}
