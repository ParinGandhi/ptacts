import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PtabTrialConstants } from '../constants/ptab-trials.constants';
import { environment } from 'src/environments/environment';
import CaseHeaderModel from '../models/cases/CaseHeader.model';

@Injectable({
  providedIn: 'root'
})
export class TrialsService {

  /** Location variables */

  private port: string = '8081';

  /**
 * * LOCAL DEVELOPMENT
 * ? Uncomment below ONLY if you are running Trials Services locally.
 * ? Otherwise use the appropriate environment commands
 * ? DEV - npm run start:dev
 * ? PVT - npm run start:pvt
 */
  // private TRIALS_BASE_URL: string = `${PtabTrialConstants.ENVIRONMENTS.LOCAL}${this.port}`;
  private TRIALS_BASE_URL = environment.TRIALS_SERVICE_API;



/** Header options */

getHeaders(addResponseType) {
  let userName = JSON.parse(window.sessionStorage.getItem('userInfo'));
  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'user-name': userName.loginId,
    }),
    withCredentials: true,
    crossDomain: true
  };
  if (addResponseType) {
    httpOptions.headers.set('responseType', 'arraybuffer' as 'json')
  }
  return httpOptions;
  }


  getFileUploadHeaders() {
    let userName = JSON.parse(window.sessionStorage.getItem('userInfo'));
    const httpOptions = {
      headers: new HttpHeaders({
        // 'Content-Type': "",
        'user-name': userName.loginId,
      }),
      withCredentials: true,
      crossDomain: true
    };
    return httpOptions;
  }


  getDownloadHeaders() {
    let userName = JSON.parse(window.sessionStorage.getItem('userInfo'));
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'user-name': userName.loginId,
      }),
      withCredentials: true,
      crossDomain: true,
      responseType: 'arraybuffer' as 'json'
    };
    return httpOptions;
  }

  constructor(private httpclient: HttpClient) { }



  /** Counsel */

  addCounsel(proSeVal: string, counselToAdd: any): Observable<any> {
    return this.httpclient.post<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.COUNSEL.ADD}${proSeVal}`, counselToAdd, this.getHeaders(false));
  }

  uploadRealParty(realPartyUpload:any): Observable<any> {
    return this.httpclient.post<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.COUNSEL.UPDATE}`, realPartyUpload, this.getHeaders(false));
  }

  findCounsel(emailOrRegNo: string): Observable<any> {
    return this.httpclient.get(`${this.TRIALS_BASE_URL}${PtabTrialConstants.COUNSEL.FIND_BY_EMAIL_OR_REGNO}` + emailOrRegNo);
    // return this.httpclient.get("http://localhost:8081" + url);
  }

  updateCounsel(counselToUpdate: any): Observable<any> {
    return this.httpclient.put<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.COUNSEL.UPDATE}`, counselToUpdate, this.getHeaders(false));
  }

  updateRealParty(url:string,updateParty:any): Observable<any> {
    return this.httpclient.put<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.COUNSEL.UPDATE}`, updateParty, this.getHeaders(false));
  }

  deleteCounsel(proceedingNo: string, proceedingPartyIdentifier: string): Observable<any> {
    return this.httpclient.delete<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.COUNSEL.DELETE}${proceedingNo}${PtabTrialConstants.GENERAL.PARTY_IDENTIFIER}${proceedingPartyIdentifier}`, this.getHeaders(false));
  }

  switchCounsel(url: any, counseltoSwitch: any): Observable<any> {
    return this.httpclient.put<any>(`${this.TRIALS_BASE_URL}${url}`, counseltoSwitch, this.getHeaders(false));
  }

  /** CaseViewer - update documents modal */

  getDocumentsForUpdate(url: string): Observable<any> {
    return this.httpclient.get<any>(this.TRIALS_BASE_URL + url);
  }

  expungeDocument(url: string, docToExpunge: any): Observable<any> {
    return this.httpclient.put<any>(this.TRIALS_BASE_URL + url, docToExpunge, this.getHeaders(false));
  }

  updateDocumentInfo(url: string, docToUpdate: any): Observable<any> {
    return this.httpclient.put<any>(this.TRIALS_BASE_URL + url, docToUpdate, this.getHeaders(false));
  }

  // getCaseHeaderInfo(serialNo: string, proceedingNo: string): Observable<any> {
  //   return this.httpclient.get<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.CASE_VIEWER.DETAILS}${serialNo}&proceedingSupplementaryId=${proceedingNo}`)
  // }

  getCaseHeaderInfo(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.CASE_VIEWER.DETAILS}${proceedingNo}`);
  }

/** AIA Trials Workspace */

reassignTasks(url: string, tasksToReassign: any): Observable<any> {
  return this.httpclient.put<any>(this.TRIALS_BASE_URL + url, tasksToReassign, this.getHeaders(false));
  }


/** Mandatory notices */
getMandatoryNotices(caseNumber: string): Observable<any> {
  return this.httpclient.get<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.MANDATORY_NOTICE.GET}${caseNumber}`);
  }

getRehearingList(url: string): Observable<any> {
  return this.httpclient.get<any>(this.TRIALS_BASE_URL + url);
}

getAppealsList(url: string): Observable<any> {
  return this.httpclient.get<any>(this.TRIALS_BASE_URL + url);
}

updateAppeals(url: string, appealsData: any): Observable<any> {
  return this.httpclient.put<any>(this.TRIALS_BASE_URL + url, appealsData, this.getHeaders(false));
}

updateMotionRehearing(url: string, recordsToUpdate: any): Observable<any> {
  return this.httpclient.put<any>(this.TRIALS_BASE_URL + url, recordsToUpdate, this.getHeaders(false));
}

getMotionsList(url: string): Observable<any> {
  return this.httpclient.get<any>(this.TRIALS_BASE_URL + url);
}

  approveOrRejectMandatoryNotice(noticeToApproveOrReject: any): Observable<any> {
    return this.httpclient.put<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.MANDATORY_NOTICE.APPROVE_REJECT}`, noticeToApproveOrReject, this.getHeaders(false));
  }

  /** Get milestone data */
  getMilestoneData(url: string): Observable<any> {
    return this.httpclient.get<any>(this.TRIALS_BASE_URL + url);
  }

  getDecisionHistory(url: string): Observable<any> {
    return this.httpclient.get<any>(this.TRIALS_BASE_URL + url);
  }

  updateMilestoneData(url: string, milestoneData: any): Observable<any> {
    // return this.httpclient.put<any>(this.TRIALS_BASE_URL + url, recordsToUpdate, this.getHeaders(false));
      return this.httpclient.post<any>(this.TRIALS_BASE_URL + url, milestoneData, this.getHeaders(false));
  }

  updateDerivation(url: string, derivationData: any): Observable<any> {
    return this.httpclient.put<any>(this.TRIALS_BASE_URL + url, derivationData, this.getHeaders(false));
}

/** Pending Paneling */
  getPendingPanelingCases(): Observable<any> {
    // return this.httpclient.get('../../assets/paneling/pendingPaneling.json');
    return this.httpclient.get(`${this.TRIALS_BASE_URL}${PtabTrialConstants.PANEL.GET_PENDING_PANEL}`);
  }

  getJudgeList(): Observable<any> {
    return this.httpclient.get(`${this.TRIALS_BASE_URL}${PtabTrialConstants.PANEL.GET_JUDGE_LIST}`);
  }

  getPaneledJudges(proceedingNo: string, includeInactive: boolean): Observable<any> {
    return this.httpclient.get(`${this.TRIALS_BASE_URL}${PtabTrialConstants.PANEL.GET_PANELED_JUDGES}/?${PtabTrialConstants.CASE_TYPE_TRIALS}&${PtabTrialConstants.CASE_NO}${proceedingNo}&${PtabTrialConstants.INCLUDE_INACTIVE}${includeInactive}`);
  }

  getDisciplineList(): Observable<any> {
    return this.httpclient.get(`${this.TRIALS_BASE_URL}${PtabTrialConstants.PANEL.GET_DISCIPLINES}`)
  }

  getSectionList(): Observable<any> {
    return this.httpclient.get(`${this.TRIALS_BASE_URL}${PtabTrialConstants.PANEL.GET_SECTIONS}`)
  }

  getHeaderInfo(proceedingNo: string): Observable<any> {
    return this.httpclient.get(`${this.TRIALS_BASE_URL}${PtabTrialConstants.CASE_HEADER}${proceedingNo}`)
  }

  assignPanelToCase(caseToPanel: any): Observable<any> {
    return this.httpclient.post(`${this.TRIALS_BASE_URL}${PtabTrialConstants.PANEL.ASSIGN_JUDGES}`, caseToPanel, this.getHeaders(false));
  }

  createTask(task: any):Observable<any> {
    return this.httpclient.post(`${this.TRIALS_BASE_URL}${PtabTrialConstants.CREATE_TASK}`, task, this.getHeaders(false));
  }

  updateTask(task: any):Observable<any> {
    return this.httpclient.put(`${this.TRIALS_BASE_URL}${PtabTrialConstants.UPDATE_TASK}`, task, this.getHeaders(false));
  }

  clearPanel(panelToClear: any): Observable<any> {
    return this.httpclient.post(`${this.TRIALS_BASE_URL}${PtabTrialConstants.PANEL.CLEAR_PANEL}`, panelToClear, this.getHeaders(false));
  }

  getFilteredList(url: string): Observable<any> {
    return this.httpclient.get<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.PANEL.FILTER_BY}${url}`);
  }

  getSheetNames(fileToUpload: any): Observable<any> {
    // const formData: FormData = new FormData();
    // formData.append('file', fileToUpload);
    return this.httpclient.post<any>(`${this.TRIALS_BASE_URL}/proceeding-judges/get-sheet-names`, fileToUpload, this.getFileUploadHeaders());
  }

  importPanel(formData: any): Observable<any> {
    return this.httpclient.post<any>(`${this.TRIALS_BASE_URL}/proceeding-judges/bulk-import`, formData, this.getFileUploadHeaders());
  }


  /** Counsel / Real party  */
  getCounselInfo(proceedingNumber: string): Observable<any> {
    return this.httpclient.get<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.COUNSEL.GET}${proceedingNumber}`);
  }


  /**
   * Header
   */

  getCaseStatus(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(`${this.TRIALS_BASE_URL}/ptab-state-role?caseNumber=${proceedingNo}`, this.getHeaders(false));
  }

  getCaseHeader(serialNumber: string, proceedingNumber: string): Observable<CaseHeaderModel> {
    return this.httpclient.get<CaseHeaderModel>(
      `${this.TRIALS_BASE_URL}
      ${PtabTrialConstants.CASE_HEADER}
      ${serialNumber}&proceedingSupplementaryId=${proceedingNumber}`);
  }


  /**
   * All AIA Reviews tab
   */
  getAIAReviewsColumnDefs(reviewType: string): Observable<any> {
    return this.httpclient.get<any>(`../../assets/columnDefs/${reviewType}.json`);
  }

  getAIAReviewsData(dataType: string): Observable<any> {
    return this.httpclient.get<any>(`../../assets/aiaReview/${dataType}Data.json`);
  }

  getAllAIAReviews(): Observable<any> {
    return this.httpclient.get<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.AIA_REVIEWS}`, this.getHeaders(false));
  }


  /**
   * All Initiated cases tab
   */
  getInitiatedCases() {
    return this.httpclient.get<any>(`${this.TRIALS_BASE_URL}/proceedings?caseType=TRIAL&caseStatus=Initiated`);
  }

  getInitiatedCasesNew(obj: any): Observable<any> {
    return this.httpclient.post<any>(`${this.TRIALS_BASE_URL}/meta-data`, obj, this.getHeaders(false));
  }

  /**
   * Documents
   */
  // downloadEwf(documentsToDownload: ArrayBuffer): Observable<any> {
  //   return this.httpclient.post<ArrayBuffer>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.DOCUMENTS.DOWNLOAD_EWF}`, documentsToDownload,{responseType: 'arraybuffer' as 'json'});
  // }
  downloadEwf(documentsToDownload: ArrayBuffer): Observable<any> {
    return this.httpclient.post<ArrayBuffer>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.DOCUMENTS.DOWNLOAD_EWF}`, documentsToDownload, this.getDownloadHeaders());
  }


  downloadExcel(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.DOCUMENTS.DOWNLOAD_EXCEL}${proceedingNo}`, this.getDownloadHeaders());
  }


  getTrialsInfo(url: string): Observable<any> {
    return this.httpclient.get<any>(`${this.TRIALS_BASE_URL}${url}`);
  }


  saveToDocket(docsToSave: any): Observable<any> {
    return this.httpclient.post<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.PROCEEDING_ARTIFACTS}`, docsToSave, this.getHeaders(false));
  }

  getNextPaperNumber(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.NEXT_PAPER_NUM_URL}${proceedingNo}`);
  }


  /** Advanced search */
  searchByCase(searchCriteria: any): Observable<any> {
    return this.httpclient.post<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.ADVANCED_SEARCH_URL}`, searchCriteria, this.getHeaders(false));
  }

  searchByDocument(searchCriteria: any): Observable<any> {
    return this.httpclient.post<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.DOCUMENT_SEARCH_URL}`, searchCriteria, this.getHeaders(false));
  }


  /** Claims */
  getClaims(url: string): Observable<any> {
    return this.httpclient.get<any>(`${this.TRIALS_BASE_URL}${url}`);
  }


  /** Joinders */
  getJoinderRelatedCases(caseNumber: string): Observable<any> {
    return this.httpclient.get<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.JOINDER.RELATED_CASES}${caseNumber}`);
  }


  getJoinedCaseDetails(caseNumber: string): Observable<any> {
    return this.httpclient.get<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.JOINDER.DETAILS}${caseNumber}`);
  }


  joinCases(casesToJoin: any): Observable<any> {
    return this.httpclient.post(`${this.TRIALS_BASE_URL}${PtabTrialConstants.JOINDER.JOIN_CASES}`, casesToJoin, this.getHeaders(false));
  }


  getAssignToList(url: string): Observable<any> {
    return this.httpclient.get<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.HIERARCHY.GET}${url}`, this.getHeaders(false));
  }


  markCompleteWorkQueue(dataObj: any): Observable<any> {
    return this.httpclient.put<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.UPDATE_TASK}`, dataObj, this.getHeaders(false));
  }

  markCompleteTaskWorkQueue(dataObj: any): Observable<any> {
    return this.httpclient.put<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.COMPLETE_TASK}`, dataObj, this.getHeaders(false));
  }

  getWorkQueue(filterData: any): Observable<any> {
    return this.httpclient.post<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.TASK_DETAILS}`, filterData, this.getHeaders(false));
  }

  /** Claims */

  uploadClaims(claimUpload:any ): Observable<any> {
    return this.httpclient.post<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.CLAIMS_UPLOAD}`, claimUpload, this.getHeaders(false));
  }

  editClaims(claimUpload:any ): Observable<any> {
    return this.httpclient.put<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.CLAIMS_UPLOAD}`, claimUpload, this.getHeaders(false));
  }

   deleteClaim(claimIdentifier: string) {
    return this.httpclient.delete<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.CLAIMS_UPLOAD}${claimIdentifier}`, this.getHeaders(false));
  }

  getGround(): Observable<any> {
    return this.httpclient.get(`${this.TRIALS_BASE_URL}${PtabTrialConstants.STATUTORY_GROUNDS}`, this.getHeaders(false));
  }


  /** General */

  getStates(countryCode: string): Observable<any> {
    return this.httpclient.get(`${this.TRIALS_BASE_URL}${PtabTrialConstants.GENERAL.STATES}${countryCode}`);
  }

  getCountries(): Observable<any> {
    return this.httpclient.get(`${this.TRIALS_BASE_URL}${PtabTrialConstants.GENERAL.COUNTRIES}`);
  }

  getAuditList(url: string): Observable<any> {

    return this.httpclient.get(`${this.TRIALS_BASE_URL}${url}`,this.getHeaders(false))
  }

  codeReference(typeCode:string): Observable<any> {
    return this.httpclient.get<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.REFERENCE_DATA}`+typeCode);
  }

}
