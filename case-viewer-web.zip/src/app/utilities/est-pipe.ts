import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
  name: 'estDate'
})
export class EstDatePipe implements PipeTransform {

  constructor(private datePipe: DatePipe,) {}

  transform(value: string, dateFormat: string): any {

    if (!value) {
      return '';
    }
   return this.datePipe.transform(new Date(new Date(value).toLocaleString('en-US', { timeZone: 'America/New_York' })).getTime(), dateFormat);
  }
}