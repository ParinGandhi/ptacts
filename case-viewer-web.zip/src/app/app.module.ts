import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { HttpClientModule } from '@angular/common/http';
import { reducers } from './store';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { DatePipe } from '@angular/common'
import { ScrollingModule } from '@angular/cdk/scrolling';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from "@angular/forms";
import { NavbarComponent } from './components/navbar/navbar.component';
import { LoginComponent } from './components/login/login.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { ToastrModule } from "ngx-toastr";
import { CaseViewerComponent } from './components/case-viewer/case-viewer/case-viewer.component';
import { RealPartyComponent } from './components/case-viewer/real-party/real-party.component';
import { CounselComponent } from './components/case-viewer/counsel/counsel.component';
import { PaymentsComponent } from './components/case-viewer/payments/payments.component';
import { DocumentsComponent } from './components/case-viewer/documents-claims/documents/documents.component';
import { ClaimsComponent } from './components/case-viewer/documents-claims/claims/claims.component';
import { ClaimsUploadComponent } from "./components/case-viewer/documents-claims/claims-upload/claims-upload.component";
import { DataTableComponent } from './components/common/data-table/data-table.component';
import { CaseviewerHeaderComponent } from './components/case-viewer/caseviewer-header/caseviewer-header.component';
import { FilterPipe } from "./utilities/table-filter-pipe";
import { PhonePipe } from "./utilities/phone-number-pipe";
import { BibDataComponent } from './components/case-viewer/appeals/bib-data/bib-data.component';
import { DescriptiveInfoComponent } from './components/case-viewer/appeals/bib-data/descriptive-info/descriptive-info.component';
import { ParentInfoComponent } from './components/case-viewer/appeals/bib-data/parent-info/parent-info.component';
import { CorrespondenceInfoComponent } from './components/case-viewer/appeals/bib-data/correspondence-info/correspondence-info.component';
import { ThirdPartyInfoComponent } from './components/case-viewer/appeals/bib-data/third-party-info/third-party-info.component';
import { CaseNotesComponent } from './components/case-viewer/appeals/bib-data/case-notes/case-notes.component';
import { DocumentUploadComponent } from './document-upload/document-upload.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ConfirmDialogComponent } from './shared/confirm-dialog/confirm-dialog.component';
import { CaseViewerEffects } from './store/case-viewer/case-viewer.effects';
import { CaseMilestoneComponent } from './components/case-viewer/appeals/case-milestone/case-milestone.component';
import { ApplicationDatesComponent } from './components/case-viewer/appeals/case-milestone/application-dates/application-dates.component';
import { CaseInfoKeyDatesComponent } from './components/case-viewer/appeals/case-milestone/case-info-key-dates/case-info-key-dates.component';
import { ExpandCollapseComponent } from './components/common/expand-collapse/expand-collapse.component';
import { CaseHistoryComponent } from './components/case-viewer/appeals/case-history/case-history.component';
import { AssignmentHistoryComponent } from './components/case-viewer/appeals/case-history/assignment-history/assignment-history.component';
import { StatusInteractionHistoryComponent } from './components/case-viewer/appeals/case-history/status-interaction-history/status-interaction-history.component';
import { DecisionHistoryComponent } from './components/case-viewer/appeals/case-history/decision-history/decision-history.component';
import { AssignmentAuditLogComponent } from './components/case-viewer/appeals/case-history/assignment-history/assignment-audit-log/assignment-audit-log.component';
import { TypeAheadComponent } from './components/common/type-ahead/type-ahead.component';
import { NgSelect2Module } from 'ng-select2';
import { InfoModalComponent } from './components/common/info-modal/info-modal.component';
import { DocumentListComponent } from './document-upload/document-list/document-list.component';
import { MotionListComponent } from './document-upload/motion-list/motion-list.component';
import { AlertsComponent } from './components/common/alerts/alerts.component';
import { AppealsDocumentsComponent } from './components/case-viewer/appeals/appeals-documents/appeals-documents.component';
import { PdfViewerComponent } from './components/common/pdf-viewer/pdf-viewer.component';
import { UpdatePartiesModalComponent } from './components/common/update-parties-modal/update-parties-modal.component';
import { MultipleEmailModalComponent } from './components/case-viewer/counsel/multiple-email-modal/multiple-email-modal.component';
import { UpdateDocumentsComponent } from './components/documents-claims/documents/update-documents/update-documents.component';
import { LoadingComponent } from './components/common/loading/loading.component';
import { TrialsWorkqueueComponent } from './components/workspace/trials-workqueue/trials-workqueue.component';
import { TrialsTasksComponent } from './components/workspace/trials-tasks/trials-tasks.component';
import { WorkspacesComponent } from './components/workspace/workspaces/workspaces.component';
import { BulkReassignComponent } from './components/workspace/modals/bulk-reassign/bulk-reassign.component';
import { AiaModalHeaderComponent } from './components/common/aia-modal-header/aia-modal-header.component';
import { AgGridModule } from 'ag-grid-angular';
import { OpenCaseviewerComponent } from './components/common/open-caseviewer/open-caseviewer.component';
import { ToolTipComponent } from './components/workspace/tool-tip/tool-tip.component';
import { MandatoryNoticeComponent } from './components/case-viewer/case-viewer/mandatory-notice/mandatory-notice.component';
import { PendingPanelingComponent } from './components/workspace/pending-paneling/pending-paneling.component';
import { PanelingComponent } from './components/workspace/modals/paneling/paneling.component';
import { ImportPanelComponent } from './components/workspace/modals/import-panel/import-panel.component';
import { GridRefreshComponent } from './components/common/grid-refresh/grid-refresh.component';
import { OrderModule } from 'ngx-order-pipe';
import { MotionRehearingComponent } from './components/case-viewer/case-viewer/motion-rehearing/motion-rehearing.component';
import { AiaReviewsComponent } from './components/workspace/aia-reviews/aia-reviews.component';
import { InitiatedPetitionsComponent } from './components/workspace/initiated-petitions/initiated-petitions.component';
import { JudgePanelRendererComponent } from './components/common/judge-panel-renderer/judge-panel-renderer.component';
import { CreateTaskComponent } from './components/workspace/create-task/create-task.component';
import { LoadingWithProgressComponent } from './components/common/loading-with-progress/loading-with-progress.component';
import { PanelHistoryComponent } from './components/workspace/modals/paneling/panel-history/panel-history.component';
import { NotificationsComponent } from './components/case-viewer/case-viewer/notifications/notifications.component';
import { AiaSearchComponent } from './components/workspace/aia-search/aia-search.component';
import { CheckboxDropdownComponent } from './components/common/checkbox-dropdown/checkbox-dropdown.component';
import { EmailBodyComponent } from './components/case-viewer/case-viewer/email-body/email-body.component';
import { NotificationTooltipComponent } from './components/case-viewer/case-viewer/notification-tooltip/notification-tooltip.component';
import { SearchTooltipComponent } from './components/common/search-tooltip/search-tooltip.component';
import { EmailSubjectComponent } from './components/case-viewer/case-viewer/email-subject/email-subject.component';
import { AdditionalFiltersComponent } from './components/workspace/aia-search/additional-filters/additional-filters.component';
import { JoinedCasesComponent } from './components/case-viewer/case-viewer/joined-cases/joined-cases.component';
import { JoinedCounselComponent } from './components/case-viewer/counsel/joined-counsel/joined-counsel/joined-counsel.component';
import { JoinedRealPartyComponent } from './components/case-viewer/real-party/joined-real-party/joined-real-party.component';
import { OpenDocumentComponent } from './components/common/open-document/open-document.component';
import { AuditHistoryComponent } from './components/case-viewer/case-viewer/audit-history/audit-history.component';
import { ReportsComponent } from './components/workspace/reports/reports.component';
import { EstDatePipe } from './utilities/est-pipe';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    LoginComponent,
    CaseViewerComponent,
    RealPartyComponent,
    CounselComponent,
    PaymentsComponent,
    DocumentsComponent,
    ClaimsComponent,
    ClaimsUploadComponent,
    DataTableComponent,
    CaseviewerHeaderComponent,
    FilterPipe,
    PhonePipe,
    BibDataComponent,
    DescriptiveInfoComponent,
    ParentInfoComponent,
    CorrespondenceInfoComponent,
    ThirdPartyInfoComponent,
    CaseNotesComponent,
    EstDatePipe,
    DocumentUploadComponent,
    ConfirmDialogComponent,
    CaseMilestoneComponent,
    ApplicationDatesComponent,
    CaseInfoKeyDatesComponent,
    ExpandCollapseComponent,
    CaseHistoryComponent,
    AssignmentHistoryComponent,
    StatusInteractionHistoryComponent,
    DecisionHistoryComponent,
    AssignmentAuditLogComponent,
    TypeAheadComponent,
    InfoModalComponent,
    DocumentListComponent,
    MotionListComponent,
    AlertsComponent,
    AppealsDocumentsComponent,
    PdfViewerComponent,
    UpdatePartiesModalComponent,
    MultipleEmailModalComponent,
    UpdateDocumentsComponent,
    LoadingComponent,
    TrialsWorkqueueComponent,
    TrialsTasksComponent,
    WorkspacesComponent,
    BulkReassignComponent,
    AiaModalHeaderComponent,
    OpenCaseviewerComponent,
    ToolTipComponent,
    MandatoryNoticeComponent,
    PendingPanelingComponent,
    PanelingComponent,
    ImportPanelComponent,
    GridRefreshComponent,
    MotionRehearingComponent,
    AiaReviewsComponent,
    ReportsComponent,
    InitiatedPetitionsComponent,
    JudgePanelRendererComponent,
    CreateTaskComponent,
    LoadingWithProgressComponent,
    PanelHistoryComponent,
    NotificationsComponent,
    AiaSearchComponent,
    CheckboxDropdownComponent,
    EmailBodyComponent,
    NotificationTooltipComponent,
    SearchTooltipComponent,
    EmailSubjectComponent,
    AdditionalFiltersComponent,
    JoinedCasesComponent,
    JoinedCounselComponent,
    JoinedRealPartyComponent,
    OpenDocumentComponent,
    AuditHistoryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    NgbModule,
    ScrollingModule,
    FormsModule,
    ModalModule.forRoot(),
    TooltipModule,
    EffectsModule.forRoot([CaseViewerEffects]),
    StoreModule.forRoot(reducers, {
      runtimeChecks: {
        strictActionImmutability: true,
        strictActionSerializability: true,
        strictStateImmutability: true,
        strictStateSerializability: true
      }
    }),
    StoreDevtoolsModule.instrument({ maxAge: 10 }),
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    NgSelect2Module,
    AgGridModule.withComponents([]),
    OrderModule
  ],
  providers: [DatePipe, NgbActiveModal],
  bootstrap: [AppComponent]
})
export class AppModule { }
