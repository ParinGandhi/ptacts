export const PtabTrialConstants = {
    BASE_URL: "/PTABCaseViewer",
    CASEVIEWER_BASE_URL: "/PTABCaseViewer",
    APPEALS_BASE_URL: "/PTABAppealsServices",
    APPEALS: "PTABAppeals",
    COMMON_SERVICES_URL: '/PTABE2ECommonServices',
    TRIAL_SERVICES_URL: '/PTABTrialsServices',
    USER_INFO: '/user-management/user-info?loginId=',
    WHO_AM_I: '/kerb/who-am-i',
    DOCKET_DETAILS: '/jpView/docket_details',
    CLOSED_CASES: '/closed/',
    OPEN_CASES: '/open/',
    CASE_DOCUMENTS: '/case-documents',
    AIA_PAPER: '/all-papers-with-count?proceedingNumber=',
    AIA_EXHIBITS: '/all-exhibits-with-count?proceedingNumber=',
    CASE_DETAILS: '/case-information/details?serialNumber=',
    // CASE_HEADER: '/case-viewer/details?proceedingCoreId=',
    CASE_HEADER: '/case-viewer/details?proceedingSupplementaryId=',
    DOWNLOAD_DOCS: '/artifacts/downloadMergedPdfFile',
    REFERENCE_DATA: "/reference-data/code-reference-types?typeCode=",
    CLAIMS: '/petition-claims?proceedingNumber=',
    NEXT_PAPER_NUM_URL: '/proceeding-artifacts/sequences?proceedingNumber=',
    PAYMENTS: '/reviewInfo?postingReferenceText=',
    CASE_VIEWER_URL: "/PTABCaseViewer",
    DOCKET_VIEWER: "/PTABDocketViewer",
    PALM_URL: '/reference-data/code-reference-types?typeCode=OPEN_PALM',
    HELP_URL: '/reference-data/code-reference-types?typeCode=HELP_LINKS',
    APPEALS_URL: '/reference-data/code-reference-types?typeCode=APPEALS_URL',
    CASE_TYPE_TRIALS: 'caseType=TRIALS',
    CASE_NO: 'caseNo=',
    INCLUDE_INACTIVE: 'includeInactive=',
    CREATE_TASK: '/worker-task/',
    UPDATE_TASK: '/worker-task',
    COMPLETE_TASK: '/worker-task/complete',
    TASK_DETAILS: '/worker-task/details',
    HIERARCHY: {
        GET: '/standard-hierarchy-group',
        MY_GROUP: '/my-group/',
        MY_TEAM: '/my-team/'
    },
    GENERAL: {
        PARTY_IDENTIFIER: '&proceedingPartyIdentifier=',
        COUNTRIES: '/geo-region/get-countriesinfo/TRAILS',
        STATES: '/geo-region/get-statesinfo/TRAILS/',
        CASE_SEARCH: '/case-viewer/caseNumber-search?caseNumber='
    },
    MISC: {
        SECOND_MODAL_BG_COLOR: 'rgba(0, 0, 0, 0.5)'
    },
    COUNSEL: {
        GET: '/proceeding-party-details?proceedingNumber=',
        ADD: '/proceeding-party-details?partyRepresentIndicator=',
        DELETE: '/proceeding-party-details?proceedingNumber=',
        UPDATE: '/proceeding-party-details',
        FIND_BY_EMAIL_OR_REGNO: '/proceeding-party-details/counsels/TRAILS?',
        SWITCH: '/proceeding-party-details/switch-counsels?isLeadCounsel='
    },
    REAL_PARTY: {
        SWITCH: '/proceeding-party-details/switch-real-party-details?isRealParty='
    },
    CLAIMS_UPLOAD: '/pcdng-claims/',
    STATUTORY_GROUNDS: '/pcdng-claims/statutory-grounds',
    DOCUMENTS: {
        DOWNLOAD_EWF: '/artifacts/downloadMergedPdfFile',
        DOWNLOAD_EXCEL: '/proceeding-artifacts/exportpaperexhibits-excel?proceedingNumber='
        // DOWNLOAD_EWF: '/data-documents/download-zip'
    },
    DOC_TYPE: '&docType=',
    DOWNLOAD_TYPE: {
        PDF: '.pdf',
        EXCEL: '.xlsx'
    },
    MANDATORY_NOTICE: {
        GET: '/mandatory-notice?caseNumber=',
        APPROVE_REJECT: '/mandatory-notice'
    },
    CASE_VIEWER: {
        // DETAILS: '/case-viewer/details?proceedingCoreId='
        DETAILS: '/case-viewer/details?proceedingSupplementaryId='
    },
    PANEL: {
        GET_PENDING_PANEL: '/proceeding-judges/TRIALS/pending-panel',
        GET_SECTIONS: '/standard-hierarchy-group/sections?identifier=Section',
        GET_DISCIPLINES: '/standard-hierarchy-group/user-disciplines',
        GET_JUDGE_LIST: '/proceeding-judges/TRIALS',
        GET_PANELED_JUDGES: '/proceeding-judges',
        ASSIGN_JUDGES: '/proceeding-judges/associate-judges',
        CLEAR_PANEL: '/proceeding-judges/dissociate-judges',
        FILTER_BY: '/standard-hierarchy-group/judges',
        SECTION: 'sectionText=',
        DISCIPLINE: 'disciplineCode=',
        GET_SHEET_NAMES: "/proceeding-judges/get-sheet-names"
    },
    JOINDER: {
        RELATED_CASES: '/joinder/related-cases?caseNumber=',
        DETAILS: '/joinder?caseNumber=',
        JOIN_CASES: '/joinder/associate-casenumber'
    },
    AIA_REVIEWS: '/proceeding-reviews/TRIALS',
    // AIA_REVIEWS: {
    //     BASE: '/proceeding-reviews/TRIALS',
    //     ALL: '/aia-reviews',
    //     WITHOUT_MN: '/mandatory-notice',
    //     REQUIRE_CLOSURE: '/closure',
    //     DEFECTIVE: '/defective',
    //     TRIALS_CERTIFICATE: '/trails-certificate'
    // },
    ALL_INITIATED: '/proceedings?caseType=TRIAL&caseStatus=Initiated',
    ADVANCED_SEARCH_URL: '/case-search',
    DOCUMENT_SEARCH_URL: '/case-search/document',
    PETITIONS: '/petitions?proceedingNumberText=',
    PROCEEDING_ARTIFACTS: '/proceeding-artifacts',
    ROLES: {
        ADMIN: 'Business Administrator',
        SPL: 'Supervisor',
        ADMIN_ONLY: ['Business Administrator', 'PTABE2E_Administrator'],
        ADMIN_SPL: ['Business Administrator', 'PTABE2E_Administrator', 'Supervisor'],
        PANEL: ['Panel Administrators', 'panel_Update'],
        JPVIEW: ['PTABE2E_Administrator', 'Business Administrator', 'Judge'],
        PL: ['Paralegal/LIE']

    },
    UPLOAD: {
        MAX_SIZE: '100 MB',
        DEFAULT_TYPE: 'application/pdf',
        INVALID_CHARS: `‘!@#$%^&*(){}|`
    },
    EXHIBIT_RANGE: {
        MIN: {
            BOARD: 3000,
            PO: 2000,
            PETITIONER: 1000
        },
        MAX: {
            BOARD: 3999,
            PO: 2999,
            PETITIONER: 1999
        }
    },
    ENVIRONMENTS: {
        LOCAL: 'http://localhost:',
        DEV: 'https://ptab-q121-trial-services-wildfly-0.dev.uspto.gov:8443',
        PVT: 'https://ptacts-intservices.pvt.uspto.gov',
        SIT: 'https://ptab-q121-trial-services-wildfly-0.sit.uspto.gov:8443',
        PVT_GREEN: 'https://ptab-q121-trial-services-wildfly-green-5.pvt.uspto.gov:8443'
    },
    REFERENCE_TYPES: {
        TYPE_CODE: '/references?typeCode=',
        PAPER_TYPE_BY_PROCEEDING_NO: '/references/proceeding-number?typeCode=documentTypes&proceedingNumber=',
        RECIPIENT_TYPE: '&recipientType=',
        PAPER_TYPE: 'documentTypes',
        FILING_PARTY: 'proxySubmitterRoleType',
        AVAILABILITY: 'availability',
        DECISION_OUTCOME: 'decisionOutcomeTypes',
        MIME_TYPES: 'mimeTypes'
    },
    TRIALS_URLS: {
        GET_DOCUMENTS: '/proceeding-artifacts?proceedingNumber=',
        EXPUNGE_UNEXPUNGE: '/artifact-submissions'
    },
    COMMON_URLS: {
        REFERENCE_BASE: '/references?typeCode='
    },
    TASK_TYPES: {
        MANDATORY_NOTICE: 'RMN'
    },
    GRID_COLUMN_NAMES: {
        AIA_REVIEW: 'AIA review #',
        PETITIONER_PATENT_NO: 'Petitioner patent / appln #',
        PO_PATENT_NO: 'PO / Respondent patent / appln #',
        PETITION_SUBMISSION_DT: 'Petition submission date',
        PETITIONER_TECH_CENTER: 'Petitioner tech center',
        PO_RESPONDENT: 'PO / Respondent',
        PO_RESPONDENT_TECH_CENTER: 'PO / Respondent tech center',
        JUDGE_PANEL: 'Judge panel'
    },
    KEY_DATES: {
        FINAL_DECISION_DUE_DATE: {
            DESC: 'Final Decision Due Date',
            KEY: 'finalDecisionDueDate',
        },
        PRELIMINARY_RESPONSE: {
            DESC: 'Preliminary Response',
            KEY: 'preliminaryResponseDate',
        },
        PRELIMINARY_RESPONSE_DUE_DATE: {
            DESC: 'Preliminary Response Due Date',
            KEY: 'preliminaryResponseDueDate',
        },
        TERMINATION_DECISION: {
            DESC: 'Termination Decision',
            KEY: 'terminationDecisionDate',
        },
        DECISION_TO_INSTITUE: {
            DESC: 'Decision to Institute',
            KEY: 'decisionToInstituteDate',
        },
        DECISION_TO_INSTITUTE_DUE_DATE: {
            DESC: 'Decision to Institute Due Date',
            KEY: 'decisionToInstituteDueDate',
        },
        ACCORD_FILING_DATE: {
            DESC: 'Accorded Filing Date',
            KEY: 'accordFilingDate',
        },
        NOTICE_OF_ACCORD_FILING_DATE: {
            DESC: 'Notice of Accorded Filing Date',
            KEY: 'noticeOfAccordFilingDate',
        },
        FILING_DATE: {
            DESC: 'Filing Date',
            KEY: 'filingDate',
        }
    },
    JOINDER_TYPE_CODE: 'JN:INST',
    FED_CIRCUIT_MANDATE_CODE: 'OTH:FEDCRTD',
    DATE_TYPE: {
        DATE: 'date',
        TIMESTAMP: 'time'
    },
    CASE_TYPES: ['IPR', 'PGR', 'CBM'],
    COMPONENT_IDS: [
        'AIA_REPORT_LINK',
        'PENDING_CASES_WITH_L3_JUDGES',
        'SUB_CASES_WITH_MILESTONE_DT',
        'DB_AVG_PENDENCY',
        'AIA_SEARCH_TAB',
        'AIA_SEARCH_TABLE',
        'AIA_WORK_QUEUE_TAB',
        'AIA_WORK_QUEUE_WIDGET',
        'AIA_TASKS_WIDGET',
        'AIA_PENDING_PANELING_WIDGET',
        'ALL_AIA_REVIEWS_TAB',
        'ALL_INITIATED_PETITIONS_TAB',
        'ALL_REVIEW_INFO_TAB',
        'DOC_CLAIMS_SECTION',
        'DOCUMENTS_SUBTAB',
        'CLAIMS_SUBTAB',
        'REAL_PARTY_SECTION',
        'PETITIONER_REAL_PARTY_TABLE',
        'PO_REAL_PARTY_TABLE',
        'COUNSEL_SECTION',
        'PETITIONER_COUNSEL_TABLE',
        'PO_COUNSEL_TABLE',
        'PAYMENTS_SECTION',
        'MANDATORY_NOTICE_TAB',
        'MANDATORY_NOTICE_TABLE',
        'MOTIONS_REHEARING_TAB',
        'MOTIONS_TABLE',
        'REHEARING_TABLE',
        'CASE_MILESTONE_TAB',
        'CASE_HISTORY_TAB',
        'NOTIFICATIONS_SUBTAB',
        'NOTIFICATIONS_TABLE',
        'AUDIT_HISTORY_SUBTAB',
        'AUDIT_HISTORY_TABLE',
        'JOINED_CASE_TAB',
        'JOINED_CASE_TABLE',
        'JPVIEW_NAVBAR_LINK',
        'WORKSPACE_NAVBAR_LINK',
        'PANEL_SECTION',
        'AIA_TRIALS_NAVBAR_LINK',
        'DB_REPORTS',
        'DB_AIA_REPORTS',
        'DB_MILESTONE',
        'DB_PENDING',
        'DB_AVG_PENDANCY',
        'DB_DATABRIDGE',
        'DB_HOTLIST'
    ]
}