(function () {
  "use strict";

  angular.module('ptabe2e')
    .controller('BulkAssignController', function ($scope, ngDialog, preAppeal, userId, toastr, HttpFactory, CONSTANTS, uiGridConstants) {

      var vm = this;
      vm.isSaved = false;
      vm.userId = userId;
      vm.selectedBulkData = preAppeal;
      vm.BulkData = [];
      vm.bulkDisable = false;
      for (var i = 0; i < vm.selectedBulkData.length; i++) {

        vm.BulkData.push(vm.selectedBulkData[i].assignmentData);
      }

      for (var j = 0; j < vm.BulkData.length; j++) {

        vm.originalBulkReassignData = angular.copy(vm.BulkData);
      }
      /*get reassign to values */
      $scope.getAssignedTo = function () {
        HttpFactory.getActions(CONSTANTS.URL.ASSIGNEEUSERS + vm.userId)
          .then(function (successResponse) {
              $scope.myMangers = successResponse.data.managersData;
              $scope.myTeamData = successResponse.data.teamData;
              $scope.myGroupData = successResponse.data.groupData;
              $scope.workQueueData = successResponse.data.workQueueData;
              if ($scope.myGroupData === null) {
                $scope.moreAssignees = true;
              } else {
                $scope.groupLength = $scope.myGroupData.length;
                if ($scope.groupLength === 0) {
                  $scope.moreAssignees = true;
                }
              }

              $scope.foundAssigne = false;
              $scope.scrollDisable = false;
              if (!$scope.foundAssigne) {
                $scope.currentAssignee = {
                  assigneeFullNameText: 'Select user',
                  activeCaseCount: '',
                  assigneeStatus: '',
                  assigneeNumberText: ""
                };
              }
              $scope.originalcurrentAssignee = angular.copy($scope.currentAssignee);
            },
            function (failureResponse) {
              $scope.currentAssignee = {
                assigneeFullNameText: 'Select user',
                activeCaseCount: '',
                assigneeStatus: '',
                assigneeNumberText: ""
              };
              $scope.myAssigne = {};
              $scope.scrollDisable = true;
              $scope.originalcurrentAssignee = angular.copy($scope.currentAssignee);
              $log.info(failureResponse);
            });
      };
      $scope.getAssignedTo();




      vm.change = function (content) {
        $scope.currentAssignee.assigneeFullNameText = content.assigneeFullNameText;
        $scope.currentAssignee.activeCaseCount = content.activeCaseCount;
        $scope.currentAssignee.assigneeStatus = content.assigneeStatus;
        $scope.currentAssignee.assigneeNumberText = content.assigneeNumberText;
      };



      $scope.reassignGridOptions = {
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        gridMenuShowHideColumns: false,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.WHEN_NEEDED,
        columnDefs: [{
            displayName: "Application #",
            headerTooltip: 'Application #',
            field: "serialNumber",
            type: "string",
            width: 140,
            enableColumnMenu: false
          },
          {
            displayName: "Assignment title",
            headerTooltip: 'Assignment title',
            field: "serialNumber",
            type: "string",
            cellTemplate: "<div style=\"margin-left: 8px; padding-top:5px;\" class=\"truncateTitle\">Promote to appeal - {{COL_FIELD}}</div>;",
            enableColumnMenu: false
          },
          {
            displayName: "Currently assigned to",
            headerTooltip: 'Currently assigned to',
            field: "assigneeFullName",
            type: "string",
            width: 300,
            enableColumnMenu: false
          }
        ],
        onRegisterApi: function (gridApi) {
          $scope.gridApi = gridApi;
        }
      };

      $scope.reassignGridOptions.data = vm.selectedBulkData;

      vm.cancelReassign = function () {
        ngDialog.close(lastDialog());
      };

      function lastDialog() {
        var openDialogs = ngDialog.getOpenDialogs();
        return openDialogs[openDialogs.length - 1];
      }

      vm.reassignWorkers = function () {
        var reAssignDataArray = [];
        vm.bulkDisable = true;
        vm.selectedBulkData.forEach(function (item) {

          var reAssignObject = {
            "assignee": $scope.currentAssignee.assigneeNumberText,
            "serialNumber": item.serialNumber,
            "title": item.assignmentData.title,
            "description": item.assignmentData.description,
            "dueDate": item.assignmentData.dueDate,
            "assignedDate": item.assignmentData.assignedDate,
            "completionDate": item.assignmentData.completionDate,
            "assignmentType": item.assignmentData.assignmentType,
            "appealNumber": item.assignmentData.appealNumber,
            "notes": item.assignmentData.notes,
            "priorityIndicator": item.assignmentData.priorityIndicator,
            "assignmentIdentifier": item.assignmentData.assignmentIdentifier,
            "assignmentTypeIdentifier": item.assignmentData.assignmentTypeIdentifier,
            "assignor": vm.userId,
            "activeIndicator": item.assignmentData.activeIndicator,
            "audit": {
              "createUserIdentifier": item.assignmentData.audit.createUserIdentifier,
              "lastModifiedUserIdentifier": vm.userId,
              "lockControlNumber": item.assignmentData.audit.lockControlNumber,
              "lastModifiedTimestamp": new Date().getTime()
            }
          };
          reAssignDataArray.push(reAssignObject);
        });
        HttpFactory.putActions(CONSTANTS.URL.IMPORT_BULK_REASSIGN, reAssignDataArray)
          .then(function (successResponse) {
            ngDialog.closeAll(successResponse);
          }, function (failureResponse) {
            vm.bulkDisable = false;
            toastr.error(CONSTANTS.TOASTER.reassign, {
              iconClass: 'toast-danger'
            });
          });
      };

      $scope.extraData = true;
      $scope.moreAssigneesData = function () {
        $scope.extraData = false;
        $scope.moreAssignees = true;
        $scope.myGroup = $scope.myGroupData;
      };



    });
})();
