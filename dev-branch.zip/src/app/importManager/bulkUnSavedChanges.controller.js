(function () {
  "use strict";

  angular
    .module('ptabe2e')
    .controller('BulkUnSavedChangesController', function (ngDialog, originalBulkcurrentAssignee, currentAssignee, originalBulkReassignData, BulkData) {
      var vm = this;

      vm.revertBulkchanges = function () {

        BulkData[0].assigneeRoleCode = originalBulkReassignData[0].assigneeRoleCode;
        BulkData[0].dueDate = originalBulkReassignData[0].dueDate;
        BulkData[0].notes = originalBulkReassignData[0].notes;
        currentAssignee.assigneeFullNameText = originalBulkcurrentAssignee.assigneeFullNameText;

        ngDialog.closeAll();
      };

      function closeBulkChangesDialog(popupsToClose) {

        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose]);
        } else {
          ngDialog.close();
        }
      }

      vm.closeCurrentBulkDialog = function () {
        closeBulkChangesDialog(1);
      };
    });
})();
