(function () {
  "use strict";

  angular
    .module('ptabe2e')
    .controller('ImportNewCaseController', function (ngDialog, userInfo) {
      var vm = this;
      vm.importData = userInfo;

      vm.cancelImportNumber = function () {
        ngDialog.closeAll();
      };

      vm.importNumber = function () {
        ngDialog.closeAll(vm.importData);
      };

    });
})();
