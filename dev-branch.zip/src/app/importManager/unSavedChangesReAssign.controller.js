(function () {
  "use strict";

  angular
    .module('ptabe2e')
    .controller('UnSavedChangesReAssignController', function (ngDialog, originalcurrentAssignee, currentAssignee, originalReassignData, reassignData) {
      var vm = this;

      vm.revertchanges = function () {
        reassignData.assigneeRoleCode = originalReassignData.assigneeRoleCode;
        currentAssignee.assigneeFullNameText = originalcurrentAssignee.assigneeFullNameText;
        reassignData.dueDate = originalReassignData.dueDate;
        reassignData.notes = originalReassignData.notes;
        ngDialog.closeAll();

      };

      function closeReAssignChangesDialog(popupsToClose) {


        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose]);
        } else {
          ngDialog.close();
        }
      }


      vm.closeCurrentDialog = function () {
        closeReAssignChangesDialog(1);
      };
    });
})();
