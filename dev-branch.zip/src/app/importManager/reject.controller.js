(function () {
  "use strict";

  angular
    .module('ptabe2e')
    .controller('RejectController', function ($scope, ngDialog, rejectData) {
      var vm = this;
      vm.rejectData = rejectData;
      vm.originalRejectData = angular.copy(vm.rejectData);
      $scope.rejectNumber = vm.rejectData.serialNumber;

      function closeBulkChangesDialog(popupsToClose) {

        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose]);
        } else {
          ngDialog.close();
        }
      }

      vm.cancelReject = function () {
        if (angular.equals(vm.rejectData, vm.originalRejectData)) {
          closeBulkChangesDialog(1);
        } else {
          ngDialog.open({
            template: 'app/importManager/rejectChanges.html',
            controller: 'RejectChangesController',
            controllerAs: 'vm',
            width: '25%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              rejectData: function () {
                return vm.rejectData;
              },
              originalRejectData: function () {
                return vm.originalRejectData;
              }
            }
          });
        }

      };

      vm.rejectNumber = function () {
        ngDialog.closeAll(vm.rejectData);
      };

    });
})();
