(function () {
  'use strict';

  describe('BulkUnSavedChangesController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close']);
    var BulkData, currentAssignee, originalBulkReassignData, originalBulkcurrentAssignee;
    var controller, scope;

    BulkData = [{
      'assigneeRoleCode': 'pgandhi',
      'dueDate': 1500000,
      'notes': 'hi'
    }]
    originalBulkReassignData = [{
      'assigneeRoleCode': 'pgandhi',
      'dueDate': 1500000,
      'notes': 'hi'
    }]
    currentAssignee = {
      'name': 'mmylar'
    }
    originalBulkcurrentAssignee = {
      'name': 'mmylar'
    }

    beforeEach(inject(function (_$controller_, _$rootScope_) {
      $controller = _$controller_;
      scope = _$rootScope_.$new();


      controller = $controller('BulkUnSavedChangesController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        BulkData: BulkData,
        currentAssignee: currentAssignee,
        originalBulkReassignData: originalBulkReassignData,
        originalBulkcurrentAssignee: originalBulkcurrentAssignee
      });
    }));

    describe('BulkUnSavedChangesController ', function () {


      it('it should call closeCurrentBulkDialog ', function () {

        var ngDialogArray = [ngDialog, ngDialog];
        expect(ngDialog.close).toBeDefined();
        expect(controller['closeCurrentBulkDialog']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        controller.closeCurrentBulkDialog();
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog);

        expect(ngDialog.close).toBeDefined();
        expect(controller['closeCurrentBulkDialog']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.closeCurrentBulkDialog();
        expect(ngDialog.close).toHaveBeenCalledWith();

      });

      it('it should call revertBulkchanges ', function () {

        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['revertBulkchanges']).toBeDefined();
        controller.revertBulkchanges();
        expect(ngDialog.closeAll).toHaveBeenCalledWith();

      });


    });
  });
})();
