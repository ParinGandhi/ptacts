(function () {
  "use strict";

  angular.module('ptabe2e')
    .controller('PostDecisionCaseManagerController', function ($scope, $log, ngDialog, SearchHelperService, AssignmentHelperService, uiGridConstants, $rootScope, HttpFactory, CONSTANTS, CommonHelperService, $window, toastr) {
      var vm = this;
      window.document.title = "Post Decision Case Manager";
      var workerNumber;
      $scope.refreshFailed = false;
      $scope.numberOfFilters = 0;
      ngDialog.closeAll();
vm.searchOption = "Case #";
vm.searchDone = false;
vm.urlForSearch =  CONSTANTS.URL.POST_DECISION_CASENUMBER;;
      /* istanbul ignore next */
      $scope.gridOptions = {
        enableGridMenu: true,
        enableSelectAll: true,
        enableFiltering: true,
        rowHeight: 35,
        useExternalFiltering: true,
        exporterCsvFilename: 'PostDecisionCases.csv',
        exporterOlderExcelCompatibility: true,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        paginationPageSizes: [10, 25, 50, 100],
        paginationPageSize: 25,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.WHEN_NEEDED,
        exporterSuppressColumns: ['actionsAvailable'],
        onRegisterApi: function (gridApi) {
          $scope.gridApi = gridApi;
          /* istanbul ignore next */
          $scope.gridApi.core.on.filterChanged($scope, function () {
            var grid = this.grid;
            $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
            if ($scope.numberOfFilters === 0) {
              $scope.gridOptions.data = $scope.myData;
            } else {
              $scope.gridOptions.data = SearchHelperService.filterGrid(grid, $scope.myData);
            }
          });

        }
      };

      vm.optionAll = function () {
        $scope.getPostDecisionData();
       vm.searchThis = null;
       vm.searchFor =vm.searchThis;
      };

      vm.optionCase = function () {
       vm.searchOption = "Case #";
       vm.searchThis = null;
       vm.urlForSearch = CONSTANTS.URL.POST_DECISION_CASENUMBER;
      };

      vm.optionApplication = function () {
        vm.searchOption = "Application #";
        vm.urlForSearch =  CONSTANTS.URL.POST_DECISION_APPNUMBER;
        vm.searchThis = null;
       };

      $scope.clearDocument = function(){
         vm.searchThis = null;
       }

       $scope.checkSearchInfo = function(){
        if (vm.searchThis == ""){
          vm.searchThis = null;
          vm.showCancel =false;
         }else{
           vm.showCancel =true;
         }
       }

       $scope.getPostDecisionDataForSpecificCase = function (fromRefresh) {
        vm.searchDone = true;
        /* istanbul ignore next*/
        if (fromRefresh) {
          $scope.gridApi.grid.clearAllFilters();
        }
        $scope.isLoading = true;
        $scope.$scope = false;
        $scope.updating = true;
        $scope.refreshDate = new Date();
        HttpFactory.getActions(vm.urlForSearch + vm.searchThis)
          .then(function (successResponse) {
            $scope.actionsMenuItems = successResponse.data.actions;
            $scope.myData = successResponse.data.caseDetailsData;
            $scope.gridOptions.columnDefs = successResponse.data.columnDetails;
            $scope.gridOptions.data = successResponse.data.caseDetailsData;
            $scope.refreshFailed = false;
          }, function (failureResponse) {
            toastr.error(failureResponse.data.message, {
              iconClass: 'toast-danger',
              timeOut: 10000
            });
            $scope.actionsMenuItems = [];
            $scope.myData =[];
            $scope.gridOptions.columnDefs =[];
            $scope.gridOptions.data = [];
            if (failureResponse.status === 404) {
             $scope.refreshFailed = false;
            } else {
$scope.refreshFailed = true;
            }
            
            $scope.updating = false;
            $scope.gridOptions.data.length =0;
          }).finally(function () {
            $scope.isLoading = false;
            $scope.updating = false;
          });
      };

      vm.advancedSearch = function () {
        vm.searchFor =vm.searchThis;
        $scope.getPostDecisionDataForSpecificCase();
      };

      vm.refreshGridData = function(){
        if (vm.searchFor != null){
          $scope.getPostDecisionDataForSpecificCase(true);
        } else{
          $scope.getPostDecisionData(true);
        }
      }
      vm.loadPostDecisionManager = function (userInfo) {

        $scope.isLoading = true;
        $scope.showFilters = false;

        workerNumber = userInfo.appUserInfo[0].loginId;
        $scope.workerNumber = workerNumber;
        $scope.userInfo = {
          "assigneeNumber": userInfo.appUserInfo[0].userIdentiifier,
          "loginId": userInfo.appUserInfo[0].loginId
        };

        $scope.getPostDecisionData = function (fromRefresh) {
          vm.searchDone = true;
          /* istanbul ignore if */
          if (fromRefresh) {
            $scope.gridApi.grid.clearAllFilters();
          }
          $scope.isLoading = true;
          $scope.$scope = false;
          $scope.updating = true;
          /* istanbul ignore next*/
          $scope.refreshDate = new Date();
          HttpFactory.getActions(CONSTANTS.URL.GET_POST_DECISIONS)
            .then(function (successResponse) {
           
              $scope.actionsMenuItems = successResponse.data.actions;
              $scope.myData = successResponse.data.caseDetailsData;
              $scope.gridOptions.columnDefs = successResponse.data.columnDetails;
              $scope.gridOptions.data = successResponse.data.caseDetailsData;
              $scope.refreshFailed = false;
            }, function (failureResponse) {
              toastr.error(failureResponse.data.message, {
                iconClass: 'toast-danger',
                timeOut: 10000
              });
              $scope.refreshFailed = true;
              $scope.updating = false;
            }).finally(function () {
              $scope.isLoading = false;
              $scope.updating = false;
            });
        };

        /* istanbul ignore next */
        // function getUserInfo() {
        //   HttpFactory.getActions(CONSTANTS.URL.DEAFULTS + workerNumber)
        //     .then(function (successResponse) {
        //       $scope.userInfo = {
        //         "userId": successResponse.data.caseDetailsData[0].userIdentiifier,
        //         "loginId": successResponse.data.caseDetailsData[0].loginId
        //       };
        //     }, function () {

        //     });
        // }
        // getUserInfo();

        $scope.showFilteringHelp = function () {
          ngDialog.open({
            template: 'app/components/helperComponents/filterHelp/filteringHelp.html',
            controller: 'CommonDialogController',
            controllerAs: 'vm',
            showClose: false
          }).then(function () {// Modal is display only.  No action needed.
          }, function () {// Cancel clicked on modal
          });
        };
        /* istanbul ignore next */
        $scope.checkAction = function (row, actionValueCode) {
          switch (actionValueCode) {
            case ("CRS"):
              break;
            case ("CRR"):
              $scope.rehearingRequest(row);
              break;
            case ("CSD"):
              $scope.createSubsequentDecision(row);
              break;
            case ("ERR"):
              break;
            case ("PDO"):
              break;
            case ("VD"):
              $scope.vacateDecision(row);
              break;
            case ("PPCJ"):
              initiatePetitionDraft(row);
              break;

            default:
              break;
          }
        };

        function initiatePetitionDraft(row) {
          var initiateInfo = {};
          initiateInfo.user = $scope.userInfo;
          initiateInfo.applicationNumber = row.entity.serialNumber;
          ngDialog.open({
            template: 'app/caseViewer/initiatePetitionRequest.modal.html',
            controller: 'InitiatePetitionRequestController',
            controllerAs: 'vm',
            showClose: false,
            width:"80%",
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              caseInfo: function () {
                return initiateInfo;
              }
            }
          }).closePromise.then(function (results) {
            if (results.value) {
              vm.interruptInProcess = true;
            }
          });
        }


        $scope.getAssignmentById = function (ptabID) {
          return HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTBYID + ptabID)
            .then(function (successResponse) {
                $scope.item = successResponse.data;
                $scope.itemsSelected = [];
                $scope.itemsSelected.push($scope.item);
                $scope.itemsSelected.isUpdateRehearing = $scope.isUpdateRehearing;
                if ($scope.isUpdateRehearing) {
                  $scope.itemsSelected.decisionData = [];
                  $scope.itemsSelected.decisionData.push($scope.decisionData);

                }
                return $scope.itemsSelected;
              },
              function (failureResponse) {
                $scope.itemsSelected = [];
                $log.info(failureResponse);
                return failureResponse;
              });
        };

        /* istanbul ignore next */
        $scope.getSelectedRow = function (row) {
          if (angular.isDefined(row)) {
            $scope.mySelectedRows = [];
            $scope.mySelectedRows.push(row.entity);
          } else {
            /* istanbul ignore next */
            $scope.mySelectedRows = $scope.gridApi.selection.getSelectedRows();
          }

          if ($scope.mySelectedRows.length === 0) {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.selectRow, "error");
          }
        };
        /* istanbul ignore next */
        $scope.rehearingRequest = function (row) {
          $scope.getSelectedRow(row);
          if ($scope.mySelectedRows.length > 0) {
            $scope.createRehearingAssignment();
          }

        };


        $scope.getVacateData = function () {
          HttpFactory.getActions(CONSTANTS.URL.DECISIONDATA + '?serialNumber=' + $scope.mySelectedRows[0].serialNumber + '&appealNumber=' + $scope.mySelectedRows[0].appealNumber)
            .then(function (successResponse) {
                $scope.decisionData = successResponse.data.decisions;

              },
              function () {
                // Empty response is ok
              });

        };
        /* istanbul ignore next */
        $scope.createRehearingAssignment = function () {
          HttpFactory.getActions(CONSTANTS.URL.DECISIONDATA + '?serialNumber=' + $scope.mySelectedRows[0].serialNumber + '&appealNumber=' + $scope.mySelectedRows[0].appealNumber)
            .then(function (successResponse) {
                $scope.decisionData = successResponse.data.decisions;
                if ($scope.decisionData.length === 0) {
                  $scope.completionCode = "Rehearing";
                  $scope.isUpdateRehearing = false;
                } else {
                  if ($scope.decisionData[0].hasOwnProperty('decisionDate')) {
                    $scope.completionCode = "Rehearing";
                    $scope.isUpdateRehearing = false;
                  } else {//null decisiondate
                    $scope.completionCode = "Update_Rehearing";
                    $scope.isUpdateRehearing = true;
                  }
                }
                $scope.getRehearingRequestModal();
              },
              function () {// Empty response is ok
              });

        };

        $scope.vacateDecision = function (row) {
          $scope.getSelectedRow(row);
          $scope.completionCode = "Vacate";
          $scope.getRehearingRequestModal();
          // var initiateInfo = vm.caseInfo;
          // initiateInfo.casePaneled = vm.caseInfo.attorneys ? vm.caseInfo.attorneys.length > 0 : false;
          // initiateInfo.applicationNumber = vm.applicationNumber;
        };

        $scope.createSubsequentDecision = function (row) {
          $scope.getSelectedRow(row);
          $scope.completionCode = 'Subsequent';
          $scope.getRehearingRequestModal();
        };
        /* istanbul ignore next */
        $scope.getRehearingRequestModal = function () {
          if($scope.userInfo.assigneeNumber == undefined){
            $scope.userInfo.assigneeNumber =   $scope.userInfo.userId;
          }
          var ptabAssignment = {
            "assignee": $scope.userInfo.assigneeNumber,
            "serialNumber": $scope.mySelectedRows[0].serialNumber,
            "caseType": $scope.mySelectedRows[0].caseType,
            "appealNumber": $scope.mySelectedRows[0].appealNumber,
            "actionCode": $scope.completionCode,
            "priorityIndicator": "N",
            "audit": {
              "createUserIdentifier": $scope.userInfo.loginId,
              "lastModifiedUserIdentifier": $scope.userInfo.loginId,
              "lockControlNumber": 0
            }
          };
          HttpFactory.postActions(CONSTANTS.URL.UPDATE_OR_CLEAR_PANEL, ptabAssignment)
            .then(function (successResponse) {

              $scope.itemsSelected = [];
              $scope.itemsSelected.push(successResponse.data);
              $window.sessionStorage.setItem("panelExists", successResponse.data.assignmentExist);

              $scope.getAssignmentById($scope.itemsSelected[0].assignmentIdentifier).then(function () {
                // $scope.itemsSelected[0].priorityIndicator = $scope.itemsSelected[0].priorityIndicator === 'Y' ? true : false;
                ngDialog.open({
                  template: "app/components/widgets/assignments/src/updateAssignmentModal.html",
                  controller: 'updateAssignmentManagementController',
                  scope: $scope,
                  width: '62%',
                  appendClassName: 'ngdialog-content-cust',
                  showClose: false,
                  closeByEscape: false,
                  closeByDocument: false,
                  resolve: {
                    items: function () {
                      return $scope.itemsSelected;
                    },
                    readOnly: function () {
                      return false;
                    }
                  }


                }).closePromise.then(function (refreshGrid) {
                  if (refreshGrid.value) {
                    // $scope.refreshGrid();
                    // $scope.$$childTail.$$prevSibling.searchText = null;
                  }
                  delete $rootScope.sharedItems;
                }, function () {
                  // Cancel button clicked
                });
              });
            }, function (failureResponse) {
              CommonHelperService.setToastr(failureResponse.data.message, "error");
            });
        };

        $scope.openCaseViewer = function (row) {
          $window.sessionStorage.setItem("id", row.entity.assignmentIdentifier);
          $window.open("#/caseViewer/" + row.entity.serialNumber + "/" + row.entity.appealNumber);
        };

      };

    });

})();
