(function () {
  "use strict";

  angular
    .module('ptabe2e')
    .controller('WarningBeforePromoteController', function ($scope, ngDialog, promoteToAppealWarning) {

      $scope.fromWorkQueue = promoteToAppealWarning.fromWorkQueue;
      function closeDialog(popupsToClose, data) {

        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose], data);
        } else {
          ngDialog.close(data);
        }
      }

      $scope.confirmWarning = function () {
        if($scope.fromWorkQueue){
          closeDialog(1,promoteToAppealWarning);
        }else {
          ngDialog.closeAll(promoteToAppealWarning);
        }
      };

      $scope.cancelWarning = function () {
        closeDialog(1);
        //ngDialog.closeAll();
      };

    });
})();
