(function () {
  'use strict';

  describe('PromoteTypesSelectController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll']);
    var controller, scope, $rootScope;
    var timeout;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;
    var showPromoteTypesValues;
    var promoteValue, firstAppeal;

    showPromoteTypesValues = {
      "serialNumber": "12717638",
      "sequenceNumber": 0,
      "appealNumber": "0",
      "assignmentIdentifier": 814,
      "assignmentType": "ATP1",
      "caseType": "PRE-APPEAL",
    }

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);


      controller = $controller('PromoteTypesSelectController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        showPromoteTypesValues: showPromoteTypesValues,
        HttpFactory: HttpFactory

      });
    }));

    describe('PromoteTypesSelectController ', function () {

      // it('it should call confirmPromoteOptions ', function () {
      //   promoteValue = 'System generated appeal number with this application';
      //   expect(scope['confirmPromoteOptions']).toBeDefined();
      //   scope.confirmPromoteOptions(firstAppeal, promoteValue)
      // });

      // it('it should call confirmPromoteOptions ', function () {
      //   promoteValue = 'Enter other appeal';
      //   expect(scope['confirmPromoteOptions']).toBeDefined();
      //   scope.confirmPromoteOptions(firstAppeal, promoteValue);
      // });

      // it('it should call cancelPromoteOptions ', function () {
      //   expect(scope['cancelPromoteOptions']).toBeDefined();
      //   scope.cancelPromoteOptions();
      // });

      it('it should call getValue ', function () {
        expect(scope['getValue']).toBeDefined();
        scope.getValue();
      });

      it('it should call getSystemValue ', function () {
        expect(scope['getSystemValue']).toBeDefined();
        scope.getSystemValue();
      });

      it('it should call pressEnterToCheckAppeal ', function () {
        var event = {};
        event.keyCode = 13;
        var appeal = '2019000008';
        spyOn(scope, 'enterAppealNumber');
        expect(scope['enterAppealNumber']).toBeDefined();
        expect(scope['pressEnterToCheckAppeal']).toBeDefined();
        scope.pressEnterToCheckAppeal(event, appeal);
        expect(scope.enterAppealNumber).toHaveBeenCalledWith(appeal);
      });

      it('it should call enterAppealNumber successResponse', function () {
        successResponse = {
          data: {

          }
        }
        var appeal = '2019000008';


        expect(scope['enterAppealNumber']).toBeDefined();
        scope.enterAppealNumber(appeal);


        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();
      });

      it('it should call enterAppealNumber failureResponse', function () {
        failureResponse = {
          data: {

          }
        }
        var appeal = '2019000008';

        expect(scope['enterAppealNumber']).toBeDefined();
        scope.enterAppealNumber(appeal);

        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });

    });
  });
})();
