(function () {
  "use strict";

  angular
    .module('ptabe2e')
    .controller('UnSavedChangesPromoteController', function (ngDialog, dataToPromote, originalDataToPromote, currentAssignee, originalcurrentAssignee) {
      var vm = this;

      vm.revertPromotechanges = function () {
        dataToPromote.assigneeRoleCode = originalDataToPromote.assigneeRoleCode;
        currentAssignee.assigneeFullNameText = originalcurrentAssignee.assigneeFullNameText;
        dataToPromote.dueDate = originalDataToPromote.dueDate;
        dataToPromote.notes = originalDataToPromote.notes;
        ngDialog.closeAll();
      };

      function closePromoteChangesDialog(popupsToClose) {


        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose]);
        } else {
          ngDialog.close();
        }
      }


      vm.closePromoteDialog = function () {
        closePromoteChangesDialog(1);
      };
    });
})();
