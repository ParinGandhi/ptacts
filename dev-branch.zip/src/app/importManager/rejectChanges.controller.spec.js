(function () {
  'use strict';

  describe('RejectChangesController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close']);
    var rejectData, originalRejectData;
    var controller, scope, $rootScope;
    var timeout;

    rejectData = {
      'notes': 'hi'
    }
    originalRejectData = {
      'notes': 'hi'
    }

    beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_) {
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      timeout = _$timeout_;


      controller = $controller('RejectChangesController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        rejectData: rejectData,
        originalRejectData: originalRejectData
      });
    }));

    describe('RejectChangesController ', function () {


      it('it should call closeCurrentDialog ', function () {

        var ngDialogArray = [ngDialog, ngDialog];
        expect(ngDialog.close).toBeDefined();
        expect(controller['closeCurrentDialog']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        controller.closeCurrentDialog();
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog);

        expect(ngDialog.close).toBeDefined();
        expect(controller['closeCurrentDialog']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.closeCurrentDialog();
        expect(ngDialog.close).toHaveBeenCalledWith();

      });

      it('it should call rejectchanges ', function () {

        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['rejectchanges']).toBeDefined();
        controller.rejectchanges();
        expect(ngDialog.closeAll).toHaveBeenCalledWith();

      });


    });
  });
})();
