(function () {
  'use strict';

  describe('ViewReassignController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close', 'open']);
    var reassignData, originalReassignData, currentAssignee, originalcurrentAssignee;
    var controller, scope, $rootScope;
    var timeout;
    var successResponse;
    var $httpBackend, spy, $q, HttpFactoryDeferred;

    reassignData = {
      "serialNumber": "10668133",
      "sequenceNumber": 0,
      "appealNumber": "0",
      "lifeCycle": null,
      "audit": {
        "lastModifiedTimestamp": 1536356614000,
        "lastModifiedUserIdentifier": "pgandhi",
        "createUserIdentifier": "pgandhi",
        "createdUserName": null,
        "lastModifiedUserName": null,
        "createTimestamp": 1536164268970,
        "lockControlNumber": 2
      },
      "assignmentIdentifier": 1724,
      "assignmentType": "ATP1",
      "assignee": "5830",
      "assignor": "5768",
      "caseType": "PRE-APPEAL",
      "priorityIndicator": "Y",
      "activeIndicator": "A",
      "title": "Import manager default title",
      "description": "Import manager default description",
      "notes": null,
      "assignedDate": 1536164268000,
      "dueDate": 1536164268000,
      "completionDate": 1536356614000,
      "palmMailedDate": 1496635200000,
      "completedUserName": null,
      "lastModifiedUserName": null,
      "noOfActiveCases": 0,
      "assignmentStatusCode": "A",
      "assigneeRoleCode": "PTABE2E_Administrator",
      "assignmentSequence": 0,
      "reconsiderSequence": 0,
      "pendingLocationText": null,
      "assignmentTypeDescription": null
    }


    beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      timeout = _$timeout_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      //   ngDialog.open.and.returnValue({
      //     closePromise: {
      //       then: function (callback) {

      //         callback({
      //           value: 1
      //         });
      //       }

      //     }
      //   });

      controller = $controller('ViewReassignController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        reassignData: reassignData,
        HttpFactory: HttpFactory

      });
    }));

    describe('ViewReassignController ', function () {

      it('it should call myUserRoleForReAssign ', function () {
        var selectedRole = "PTABE2E_Administrator";
        var selectedUser = "5768";

        expect(controller['myUserRoleForReAssign']).toBeDefined();
        successResponse = {
          //   data: {
          "assignees": [{
            "beNo": "5778",
            "name": "Baker, Patrick",
            "activeCases": "6",
            "assigneeStatus": "Active",
            "role": null,
            "description": null
          }, {
            "beNo": "1810",
            "name": "Bartlett, Steven",
            "activeCases": "0",
            "assigneeStatus": "Active",
            "role": null,
            "description": null
          }, {
            "beNo": "26",
            "name": "Brock, Alan",
            "activeCases": "0",
            "assigneeStatus": "InActive",
            "role": null,
            "description": null
          }, {
            "beNo": "5779",
            "name": "Bui, Jacqueline",
            "activeCases": "3",
            "assigneeStatus": "Active",
            "role": null,
            "description": null
          }]
          //   }

        };

        successResponse.data = {
          assignees: [{
            "beNo": "5768",
            "name": "Baker, Patrick",
            "activeCases": "6",
            "assigneeStatus": "Active",
            "role": null,
            "description": null
          }, {
            "beNo": "5779",
            "name": "Bui, Jacqueline",
            "activeCases": "3",
            "assigneeStatus": "Active",
            "role": null,
            "description": null
          }]
        }
        var item = {
          "beNo": "5768",
          "name": "Baker, Patrick",
          "activeCases": "6",
          "assigneeStatus": "Active",
          "role": null,
          "description": null
        }

        // controller.foundAssigne = false;

        controller.myUserRoleForReAssign(selectedRole, selectedUser);
        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();


      });

      it('it should call myUserRoleForReAssign found assignee false', function () {
        var selectedRole = "PTABE2E_Administrator";
        var selectedUser = "5778";

        expect(controller['myUserRoleForReAssign']).toBeDefined();
        successResponse = {
          "assignees": [{
            "beNo": "5778",
            "name": "Baker, Patrick",
            "activeCases": "6",
            "assigneeStatus": "Active",
            "role": null,
            "description": null
          }, {
            "beNo": "1810",
            "name": "Bartlett, Steven",
            "activeCases": "0",
            "assigneeStatus": "Active",
            "role": null,
            "description": null
          }, {
            "beNo": "26",
            "name": "Brock, Alan",
            "activeCases": "0",
            "assigneeStatus": "InActive",
            "role": null,
            "description": null
          }, {
            "beNo": "5779",
            "name": "Bui, Jacqueline",
            "activeCases": "3",
            "assigneeStatus": "Active",
            "role": null,
            "description": null
          }]

        };

        successResponse.data = {
          assignees: [{
            "beNo": "5768",
            "name": "Baker, Patrick",
            "activeCases": "6",
            "assigneeStatus": "Active",
            "role": null,
            "description": null
          }, {
            "beNo": "5779",
            "name": "Bui, Jacqueline",
            "activeCases": "3",
            "assigneeStatus": "Active",
            "role": null,
            "description": null
          }]
        }
        var item = {
          "beNo": "5768",
          "name": "Baker, Patrick",
          "activeCases": "6",
          "assigneeStatus": "Active",
          "role": null,
          "description": null
        }

        controller.myUserRoleForReAssign(selectedRole, selectedUser);
        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();


      });

      it('get Actions failureResponse ', function () {
        var selectedRole = "PTABE2E_Administrator";
        var selectedUser = "5768";
        var failureResponse = {
          data: {}
        };
        controller.myUserRoleForReAssign(selectedRole, selectedUser);
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });

      // it('it should call change   ', function () {
      //   var content = {
      //     "beNo": "5779",
      //     "name": "Bui, Jacqueline",
      //     "activeCases": "3",
      //     "assigneeStatus": "Active"
      //   }
      //   expect(controller['change']).toBeDefined();
      //   controller.change(content);
      // });


      // it('it should call saveReassign  ', function () {
      //   // $scope.readyToSaveDate === true
      //   // expect(controller['saveReassign']).toBeDefined();
      //   // controller.saveReassign();


      //   scope.readyToSaveDate === false
      //   spyOn(scope, 'checkDueDateResassign');
      //   expect(scope['checkDueDateResassign']).toBeDefined();
      //   expect(controller['saveReassign']).toBeDefined();
      //   controller.saveReassign();
      //   expect(scope.checkDueDateResassign).toHaveBeenCalled();
      // });

      // it('it should call reassignCase if  ', function () {

      //   controller.currentAssignee = {
      //     beNo: "5768"
      //   }
      //   scope.readyToSaveDate = true;
      //   expect(ngDialog.closeAll).toBeDefined();
      //   expect(controller['reassignCase']).toBeDefined();
      //   controller.reassignCase();
      //   expect(ngDialog.closeAll).toHaveBeenCalledWith(reassignData);
      // });


      // it('it should call reassignCase else block  ', function () {

      //   scope.readyToSaveDate === false
      //   controller.reassignData = {
      //     "dueDate": undefined
      //   }
      //   spyOn(scope, 'checkDueDateResassign');
      //   expect(scope['checkDueDateResassign']).toBeDefined();
      //   expect(controller['reassignCase']).toBeDefined();
      //   controller.reassignCase();
      //   expect(scope.checkDueDateResassign).toHaveBeenCalled();
      // });

      it('it should call checkDueDateResassign  ', function () {

        controller.reassignData = {
          "dueDate": undefined
        }

        expect(scope['checkDueDateResassign']).toBeDefined();
        scope.checkDueDateResassign();

      });

      it('it should call cancelReassign  if block', function () {

        controller.isSave = false;
        controller.reassignData = {};
        controller.currentAssignee = "pgandhi";
        controller.originalBulkcurrentAssignee = "mmylar";

        expect(controller['cancelReassign']).toBeDefined();
        controller.cancelReassign();

        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(1);
        var args = ngDialog.open.calls.argsFor(0);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('UnSavedChangesReAssignController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.reassignData();
        args[0].resolve.originalReassignData();
        args[0].resolve.currentAssignee();
        args[0].resolve.originalcurrentAssignee();
      });


      it('it should call cancelReassign  else block', function () {

        expect(controller['cancelReassign']).toBeDefined();
        expect(ngDialog.closeAll).toBeDefined();
        controller.cancelReassign();
        expect(ngDialog.closeAll).toHaveBeenCalledWith();
      });

      //   it('it should call checkDueDateResassign  ', function () {
      //     controller.reassignData = {
      //       "dueDate": "testDate"
      //     }
      //     expect(scope['checkDueDateResassign']).toBeDefined();
      //     controller.checkDueDateResassign();
      //   });

      it('it should call updateReAssignCase ', function () {
        var closeDlg = true;
        expect(scope['updateReAssignCase']).toBeDefined();
        expect(ngDialog.closeAll).toBeDefined();
        scope.updateReAssignCase(closeDlg);
        expect(ngDialog.closeAll).toHaveBeenCalledWith();
      });

      it('it should call updateReAssign if block ', function () {
        scope.readyToSaveDate = true;
        successResponse = {
          data: {
            "serialNumber": "10668133",
            "sequenceNumber": 0,
            "appealNumber": "0",
            "lifeCycle": null,
            "audit": {
              "lastModifiedTimestamp": 1536356614000,
              "lastModifiedUserIdentifier": "pgandhi",
              "createUserIdentifier": "pgandhi",
              "createdUserName": null,
              "lastModifiedUserName": null,
              "createTimestamp": 1536164268970,
              "lockControlNumber": 2
            },
            "assignmentIdentifier": 1724,
            "assignmentType": "ATP1",
            "assignee": "5830",
            "assignor": "5768",
            "caseType": "PRE-APPEAL",
            "priorityIndicator": "Y",
            "activeIndicator": "A",
            "title": "Import manager default title",
            "description": "Import manager default description",
            "notes": null,
            "assignedDate": 1536164268000,
            "dueDate": 1536164268000,
            "completionDate": 1536356614000,
            "palmMailedDate": 1496635200000,
            "completedUserName": null,
            "lastModifiedUserName": null,
            "noOfActiveCases": 0,
            "assignmentStatusCode": "A",
            "assigneeRoleCode": "PTABE2E_Administrator",
            "assignmentSequence": 0,
            "reconsiderSequence": 0,
            "pendingLocationText": null,
            "assignmentTypeDescription": null
          }
        }

        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();
        expect(scope['updateReAssign']).toBeDefined();
        // spyOn(scope, 'refreshData');
        // expect(scope['refreshData']).toBeDefined();
        scope.updateReAssign();
        // expect(scope['refreshData']).toHaveBeenCalled();



      });

      it('it should call updateReAssign else block ', function () {
        var saveflag = true;
        expect(scope['updateReAssign']).toBeDefined();
        expect(ngDialog.closeAll).toBeDefined();
        scope.updateReAssign(saveflag);
        expect(ngDialog.closeAll).toHaveBeenCalledWith();
      });

      it('it should call closeupdateReassigndlg ', function () {
        var closeDlg = true;
        expect(scope['closeupdateReassigndlg']).toBeDefined();
        expect(ngDialog.closeAll).toBeDefined();
        scope.closeupdateReassigndlg(closeDlg);
        expect(ngDialog.closeAll).toHaveBeenCalledWith();
      });

      it('it should call saveEnable   ', function () {
        controller.reassignData = {
          "name": "test"
        }
        controller.originalReassignData = {
          "name": "notTest"
        }
        expect(scope['saveEnable']).toBeDefined();
        scope.saveEnable();
      });



    });
  });
})();
