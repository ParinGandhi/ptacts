(function () {
  'use strict';

  describe('UnSavedChangesReAssignController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close']);
    var reassignData, currentAssignee, originalReassignData, originalcurrentAssignee;
    var controller, scope, $rootScope;
    var timeout;

    reassignData = {
      'assigneeRoleCode': 'PTABE2E_Administrator',
      'dueDate': 1500000,
      'notes': 'hi'
    }
    originalReassignData = {
      'assigneeRoleCode': 'PTABE2E_Administrator',
      'dueDate': 1500000,
      'notes': 'hi'
    }
    currentAssignee = {
      'name': 'mmylar'
    }
    originalcurrentAssignee = {
      'name': 'mmylar'
    }

    beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_) {
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      timeout = _$timeout_;


      controller = $controller('UnSavedChangesReAssignController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        reassignData: reassignData,
        currentAssignee: currentAssignee,
        originalReassignData: originalReassignData,
        originalcurrentAssignee: originalcurrentAssignee
      });
    }));

    describe('UnSavedChangesReAssignController ', function () {


      it('it should call closeCurrentDialog ', function () {

        var ngDialogArray = [ngDialog, ngDialog];
        expect(ngDialog.close).toBeDefined();
        expect(controller['closeCurrentDialog']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        controller.closeCurrentDialog();
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog);

        expect(ngDialog.close).toBeDefined();
        expect(controller['closeCurrentDialog']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.closeCurrentDialog();
        expect(ngDialog.close).toHaveBeenCalledWith();

      });

      it('it should call revertchanges ', function () {


        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['revertchanges']).toBeDefined();
        controller.revertchanges();
        // expect(reassignData.assigneeRoleCode).toBe(originalReassignData.assigneeRoleCode);
        // expect(currentAssignee.name).toBe(originalcurrentAssignee.name);
        // expect(reassignData.dueDate).toBe(originalReassignData.dueDate);
        // expect(reassignData.notes).toBe(originalReassignData.notes);
        expect(ngDialog.closeAll).toHaveBeenCalledWith();

      });


    });
  });
})();
