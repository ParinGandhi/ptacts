(function () {
  'use strict';

  describe('PromoteToAppealController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close', 'open']);
    var promoteToAppeal;
    var controller, scope, $rootScope;
    var timeout;
    var successResponse;
    var $httpBackend, spy, $q, HttpFactoryDeferred, appUserInfo;

    promoteToAppeal = {
      "ptabAssignmentId": 318,
      "sequenceNo": 0,
      "fkAssignmentTypeCd": "ATP4",
      "activeIn": "A",
      "assignedDt": "1494820800000",
      "pendingLocationTx": "Pending",
      "lastModifiedTs": "1532464761000",
      "lastModifiedUserId": "ptabadmin2",
      "assignee": "5780",
      "fkAdFkAppealNo": 0,
      "serialNumber": "11176702",
      "fkAdSequenceNo": 0,
      "fkAdReconsiderSequenceNo": 0,
      "assignmentNo": 0,
      "taskTitleTx": "assignements search to be tested",
      "taskDescTx": "Import manager default description",
      "fkAssignorBeNo": "91",
      "creatorUserId": "ptabadmin2",
      "createTs": "1532464761710",
      "assignmentDueDt": "1533328761000",
      "fkAssignmentStatusCd": "C",
      "fkTaskAssignmentCt": "PRE-APPEAL",
      "taskCreatedTs": "1532464761710",
      "lockControlNo": 0,
      "fkPreExistentId": 287,
      "assigneeRoleCode": "PTABE2E_Administrator",
      "assignmentDesc": "Assignment To POC4",
      "dueDate": 1532712182719,
      "priorityIndicator": "N",
      "userIdentifier": "ptabadmin2"
    }

    beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      timeout = _$timeout_;
      HttpFactoryDeferred = _$q_.defer();


      ngDialog.open.and.returnValue({
        then: function (callback1, callback2) {
          callback1();
          callback2();
        }
      });

      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);

      controller = $controller('PromoteToAppealController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        promoteToAppeal: promoteToAppeal,
        HttpFactory: HttpFactory,
        appUserInfo: appUserInfo

      });




    }));

    describe('PromoteToAppealController ', function () {


      it('it should call openPromoteToAppealCompleted ', function () {

        expect(scope['openPromoteToAppealCompleted']).toBeDefined();
        scope.openPromoteToAppealCompleted();

      });

      // it('it should call getUserRoleForPromote ', function () {
      //   var selectedRole = "PTABE2E_Administrator";
      //   var selectedUser = "5778";

      //   expect(scope['getUserRoleForPromote']).toBeDefined();
      //   successResponse = {
      //     //   data: {
      //     "assignees": [{
      //       "assigneeNumberText": "5778",
      //       "assigneeFullNameText": "Baker, Patrick",
      //       "activeCaseCount": "6",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "assigneeNumberText": "1810",
      //       "assigneeFullNameText": "Bartlett, Steven",
      //       "activeCaseCount": "0",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "assigneeNumberText": "26",
      //       "assigneeFullNameText": "Brock, Alan",
      //       "activeCaseCount": "0",
      //       "assigneeStatus": "InActive",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "assigneeNumberText": "5779",
      //       "assigneeFullNameText": "Bui, Jacqueline",
      //       "activeCaseCount": "3",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }]
      //     //   }

      //   };

      //   successResponse.data = {
      //     assignees: [{
      //       "assigneeNumberText": "5778",
      //       "assigneeFullNameText": "Baker, Patrick",
      //       "activeCaseCount": "6",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "assigneeNumberText": "5779",
      //       "assigneeFullNameText": "Bui, Jacqueline",
      //       "activeCaseCount": "3",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }]
      //   }

      //   scope.getUserRoleForPromote(selectedRole, selectedUser);
      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();


      // });

      // it('it should call getUserRoleForPromote found assignee false ', function () {
      //   var selectedRole = "PTABE2E_Administrator";
      //   var selectedUser = "5768";

      //   expect(scope['getUserRoleForPromote']).toBeDefined();
      //   successResponse = {
      //     "assignees": [{
      //       "assigneeNumberText": "5778",
      //       "assigneeFullNameText": "Baker, Patrick",
      //       "activeCaseCount": "6",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "assigneeNumberText": "1810",
      //       "assigneeFullNameText": "Bartlett, Steven",
      //       "activeCaseCount": "0",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "assigneeNumberText": "26",
      //       "assigneeFullNameText": "Brock, Alan",
      //       "activeCaseCount": "0",
      //       "assigneeStatus": "InActive",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "assigneeNumberText": "5779",
      //       "assigneeFullNameText": "Bui, Jacqueline",
      //       "activeCaseCount": "3",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }]

      //   };

      //   successResponse.data = {
      //     assignees: [{
      //       "assigneeNumberText": "5778",
      //       "assigneeFullNameText": "Baker, Patrick",
      //       "activeCaseCount": "6",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "assigneeNumberText": "5779",
      //       "assigneeFullNameText": "Bui, Jacqueline",
      //       "activeCaseCount": "3",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }]
      //   }

      //   scope.getUserRoleForPromote(selectedRole, selectedUser);
      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();
      // });

      // it('get Actions failureResponse ', function () {
      //   var selectedRole = "PTABE2E_Administrator";
      //   var selectedUser = "ptabadmin2";
      //   var failureResponse = {
      //     "message": "assignees not found "
      //   }
      //   scope.getUserRoleForPromote(selectedRole, selectedUser);
      //   HttpFactoryDeferred.reject(failureResponse);
      //   $rootScope.$apply();
      // });

      it('it should call checkDueDate ', function () {
        var dataToPromote;
        scope.dataToPromote = {
          "assignee": "5780",
          "assigneeRoleCode": undefined,
          "assignmentDesc": "Assignment To POC4",
          "dueDate": undefined
        }

        expect(scope['checkDueDate']).toBeDefined();
        // spyOn(scope, 'checkPromoteRole');
        // expect(scope['checkPromoteRole']).toBeDefined();
        scope.checkDueDate();
        // expect(scope['checkPromoteRole']).toHaveBeenCalled();
      });

      // it('it should call checkDueDate ', function () {
      //   var dataToPromote;
      //   scope.dataToPromote = {
      //     "assignee": "5780",
      //     "assigneeRoleCode": undefined,
      //     "assignmentDesc": "Assignment To POC4",
      //     "dueDate": undefined
      //   }

      //   expect(scope['checkPromoteRole']).toBeDefined();
      //   scope.checkPromoteRole();
      // });

      it('it should call assignPromote ', function () {

        var dataToPromote = {
          "assignee": "5780",
          "assigneeRoleCode": "PTABE2E_Administrator",
          "assignmentDesc": "Assignment To POC4",
          "dueDate": 1532712182719,
          "audit": {
            "lastModifiedTimestamp": 1536356614000,
            "lastModifiedUserIdentifier": "pgandhi",
            "createUserIdentifier": "pgandhi",
            "createdUserName": null,
            "lastModifiedUserName": null,
            "createTimestamp": 1536164268970,
            "lockControlNumber": 2
          }
        }
        var beNo = "5768";
        // scope.readyToSaveDate === true
        expect(scope['assignPromote']).toBeDefined();
        scope.assignPromote(dataToPromote, beNo);

        // HttpFactoryDeferred.resolve(successResponse);
        // $rootScope.$apply();

      });

      // it('get Actions failureResponse ', function () {

      //   var failureResponse = {
      //     data: {
      //       "message": "Application System Error.Please Contact PTAB Support Team"
      //     }

      //   }
      //   var dataToPromote = {
      //     "assignee": "5780",
      //     "assigneeRoleCode": "PTABE2E_Administrator",
      //     "assignmentDesc": "Assignment To POC4",
      //     "dueDate": 1532712182719
      //   }
      //   var beNo = "5768";

      //   expect(scope['assignPromote']).toBeDefined();
      //   scope.assignPromote(dataToPromote, beNo);

      //   HttpFactoryDeferred.reject(failureResponse);
      //   $rootScope.$apply();
      // });

      it('it should call assignPromote for appeal 0 ', function () {

        var dataToPromote = {
          "assignee": "5780",
          "appealNumber": "0",
          "assigneeRoleCode": "PTABE2E_Administrator",
          "assignmentDesc": "Assignment To POC4",
          "dueDate": 1532712182719,
          "audit": {
            "lastModifiedTimestamp": 1536356614000,
            "lastModifiedUserIdentifier": "pgandhi",
            "createUserIdentifier": "pgandhi",
            "createdUserName": null,
            "lastModifiedUserName": null,
            "createTimestamp": 1536164268970,
            "lockControlNumber": 2
          }
        }
        var beNo = "5768";
        // scope.readyToSaveDate === true
        expect(scope['assignPromote']).toBeDefined();
        scope.assignPromote(dataToPromote, beNo);

        // HttpFactoryDeferred.resolve(successResponse);
        // $rootScope.$apply();

      });

      it('it should call cancelPromote if block ', function () {

        scope.dataToPromote = {};
        scope.currentAssignee = "pgandhi";
        scope.originalcurrentAssignee = "mmylar";

        expect(scope['cancelPromote']).toBeDefined();
        scope.cancelPromote();

        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(2);
        var args = ngDialog.open.calls.argsFor(1);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('UnSavedChangesPromoteController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.dataToPromote();
        args[0].resolve.originalDataToPromote();
        args[0].resolve.currentAssignee();
        args[0].resolve.originalcurrentAssignee();

      });


      // it('it should call cancelPromote else block ', function () {

      //   expect(scope['cancelPromote']).toBeDefined();
      //   expect(ngDialog.closeAll).toBeDefined();
      //   scope.cancelPromote()
      //   expect(ngDialog.closeAll).toHaveBeenCalledWith();
      // });

      // it('it should call closePromoteDialog ', function () {

      //   expect(scope['closePromoteDialog']).toBeDefined();
      //   scope.closePromoteDialog();
      // });


      it('should call getAssignedTo', function () {
        // var successResponse = {
        //   data: {
        //     managersData: "managersData",

        //   }
        // }

        expect(scope.getAssignedTo).toBeDefined();
        scope.getAssignedTo();

      });


      it('should call getAssignedTo and fail', function () {

        expect(scope.getAssignedTo).toBeDefined();
        scope.getAssignedTo();
        HttpFactoryDeferred.reject();
        scope.$digest;

      });

      it('it should call moreAssigneesData ', function () {
        expect(scope['moreAssigneesData']).toBeDefined();
        scope.moreAssigneesData();
      });

    });
  });
})();
