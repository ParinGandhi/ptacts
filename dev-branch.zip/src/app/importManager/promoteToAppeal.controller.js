(function () {
  "use strict";

  angular
    .module('ptabe2e')
    .controller('PromoteToAppealController', function ($scope, ngDialog, promoteToAppeal, appUserInfo, HttpFactory, CONSTANTS, CommonHelperService, $window) {

      $scope.dataToPromote = promoteToAppeal;
      $scope.appUserInfo = appUserInfo;
      $scope.read = true;
      $scope.disablePromote = false;
      $scope.fromPTAassignment = $scope.dataToPromote.ptaAssignment;
      $scope.appUserRole = $window.sessionStorage.getItem("workerNumber");
      $scope.appUserIdentiifier = $window.sessionStorage.getItem("userIdentiifier");
      $scope.dataToPromote.dueDate = (new Date().getTime() / 1000) * 1000;
      $scope.originalDataToPromote = angular.copy($scope.dataToPromote);
      $scope.serialNumber = $scope.dataToPromote.serialNumber;
      $scope.appealNumber = $scope.dataToPromote.appealNumber;

      function closeDialog(popupsToClose, data) {

        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose], data);
        } else {
          ngDialog.close(data);
        }
      }

      if (appUserInfo === 'Business Administrator') {
        $scope.read = false;
      } else if (appUserInfo === 'Supervisor') {
        $scope.read = false;
      }
      $scope.openPromoteToAppealCompleted = function (number, appealNumber, assignedTo, textToDisplay) {

        $scope.successDataPromote = {
          "serialNumber": number,
          "newappealNumber": appealNumber,
          "userAssigned": assignedTo,
          "textToDisplay": textToDisplay
        };
        ngDialog.open({
          template: 'app/importManager/promoteToAppealCompleted.html',
          controller: 'ImportPreAppealManagerController',
          controllerAs: 'vm',
          width: '43%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          data: {
            resultNumber: $scope.successDataPromote
          }
        });
      };

      $scope.checkDueDate = function () {
        if (angular.isUndefined($scope.dataToPromote.dueDate) || isNaN($scope.dataToPromote.dueDate)) {
          $scope.showErrorMsgDueDate = true;
          $scope.errorMessageDueDate = "The due date cannot be empty.";
          $scope.readyToSaveDate = false;
        } else {
          $scope.readyToSaveDate = true;
          $scope.showErrorMsgDueDate = false;
        }
      };
      $scope.assignPromote = function (dataToPromote, beNo) {
        $scope.disablePromote = true;
        dataToPromote.dueDate = (new Date(dataToPromote.dueDate).getTime() / 1000) * 1000;
        dataToPromote.assignee = beNo;
        if (!dataToPromote.audit) {
          dataToPromote.audit = {};
        }
        dataToPromote.audit.lastModifiedTimestamp = new Date().getTime();
        dataToPromote.audit.lastModifiedUserIdentifier = dataToPromote.workerNumber;
        dataToPromote.audit.lockControlNumber = dataToPromote.preAppealLockControlNo;
        dataToPromote.ptaAssignment=true;
        var promoteDataObject;
        if (dataToPromote.appealNumber === "0") {
          promoteDataObject = {
            "serialNumber": dataToPromote.serialNumber,
            "sequenceNumber": dataToPromote.sequenceNumber,
            "currentAssignment": $scope.originalDataToPromote,
            "newAssignment": dataToPromote,
            "audit": {
              "createUserIdentifier": dataToPromote.audit.createUserIdentifier,
              "lastModifiedUserIdentifier": dataToPromote.workerNumber,
              "lastModifiedTimestamp": new Date().getTime(),
              "createdUserName": dataToPromote.audit.createdUserName,
              "lastModifiedUserName": dataToPromote.audit.lastModifiedUserName,
              "createTimestamp": dataToPromote.audit.createTimestamp,
              "lockControlNumber": dataToPromote.preAppealLockControlNo
            }
          };
          $scope.textToDisplay = 1;
        } else {
          promoteDataObject = {
            "serialNumber": dataToPromote.serialNumber,
            "sequenceNumber": dataToPromote.sequenceNumber,
            "appealNumber": dataToPromote.appealNumber,
            "currentAssignment": $scope.originalDataToPromote,
            "newAssignment": dataToPromote,
            "ptaAssignment":true,
            "audit": {
              "createUserIdentifier": dataToPromote.audit.createUserIdentifier,
              "lastModifiedUserIdentifier": dataToPromote.workerNumber,
              "lastModifiedTimestamp": new Date().getTime(),
              "createdUserName": dataToPromote.audit.createdUserName,
              "lastModifiedUserName": dataToPromote.audit.lastModifiedUserName,
              "createTimestamp": dataToPromote.audit.createTimestamp,
              "lockControlNumber": dataToPromote.preAppealLockControlNo
            }
          };
          $scope.textToDisplay = 2;
        }

        if ($scope.readyToSaveData) {
          return;
        }
        /* istanbul ignore if */
        if ($scope.readyToSaveDate === true) {

          if (!$scope.fromPTAassignment || $scope.fromPTAassignment == undefined) {
            ngDialog.closeAll(true);
            angular.element(document.getElementsByClassName('grid')).scope().isLoading = true;
          }

          HttpFactory.postActions(CONSTANTS.URL.IMPORT_PROMOTE, promoteDataObject)
            .then(function (successResponse) {

              $scope.newAppealNumberData = successResponse.data;
              $scope.appealNumber = $scope.newAppealNumberData.appealNumber;
              $scope.assignedToUser = $scope.currentAssignee.assigneeFullNameText;
              if (!$scope.fromPTAassignment || $scope.fromPTAassignment == undefined) {
                $scope.updatePromteData().then(function () {
                  $scope.openPromoteToAppealCompleted(promoteDataObject.serialNumber, $scope.appealNumber, $scope.assignedToUser, $scope.textToDisplay);
                  CommonHelperService.setToastr("Promote to appeal for application " + promoteDataObject.serialNumber + " was successful.", "success");
                });
              } else {
                ngDialog.closeAll(true);
                $scope.openPromoteToAppealCompleted(promoteDataObject.serialNumber, $scope.appealNumber, $scope.assignedToUser, $scope.textToDisplay);
                CommonHelperService.setToastr("Promote to appeal for application " + promoteDataObject.serialNumber + " was successful.", "success");
              }

            }, function (failureResponse) {
              $scope.dataToPromote.notes = $scope.originalDataToPromote.notes;
              if (!$scope.fromPTAassignment || $scope.fromPTAassignment == undefined) {
                $scope.updatePromteData().then(function () {
                  CommonHelperService.setToastr(failureResponse.data.message, "error", 9000000, 9000000);
                  if (failureResponse.status === 500) {
                    CommonHelperService.setToastr(CONSTANTS.TOASTER.promoteTo, "error", 9000000, 9000000);
                  }
                });
              } else {
                CommonHelperService.setToastr(failureResponse.data.message, "error", 9000000, 9000000);
                if (failureResponse.status === 500) {
                  CommonHelperService.setToastr(CONSTANTS.TOASTER.promoteTo, "error", 9000000, 9000000);
                }
              }
            });


        } else {
          $scope.checkDueDate();
        }
      };

      $scope.closePromoteDialog = function () {
        closeDialog(1);
        //ngDialog.closeAll();
      };

      $scope.cancelPromote = function () {
        if (!angular.equals($scope.dataToPromote, $scope.originalDataToPromote) || !angular.equals($scope.currentAssignee, $scope.originalcurrentAssignee)) {
          $scope.savePromoteChanges = true;
          ngDialog.open({
            template: 'app/importManager/unSavedPromoteChanges.html',
            controller: 'UnSavedChangesPromoteController',
            controllerAs: 'vm',
            width: '25%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              dataToPromote: function () {
                return $scope.dataToPromote;
              },
              originalDataToPromote: function () {
                return $scope.originalDataToPromote;
              },
              currentAssignee: function () {
                return $scope.currentAssignee;
              },
              originalcurrentAssignee: function () {
                return $scope.originalcurrentAssignee;
              }
            }
          });
        } else {
          closeDialog(1);
          // ngDialog.closeAll();
        }

      };

      $scope.getAssigneeInfo = function () {
        HttpFactory.getActions(CONSTANTS.URL.ASSIGNEEDETAILS + $scope.dataToPromote.assignee)
          .then(function (successResponse) {
              $scope.assigneeInfo = successResponse.data;
              // for (var k = 0; k <= $scope.myTeamData.length - 1; k++) {
              // if ($scope.myTeamData[k].assigneeNumberText === String($scope.appUserIdentiifier)) {
              $scope.currentAssignee = {
                assigneeFullNameText: $scope.assigneeInfo.fullName,
                activeCaseCount: $scope.assigneeInfo.activeCasesCount,
                assigneeStatus: $scope.assigneeInfo.activeIn,
                assigneeNumberText: $scope.assigneeInfo.userIdentiifier
              };
              // }
              // }
              $scope.originalcurrentAssignee = angular.copy($scope.currentAssignee);
              $scope.change($scope.currentAssignee);
            },
            function () {
              $scope.scrollDisable = true;
              $scope.currentAssignee = {
                assigneeFullNameText: 'Not assigned',
                activeCaseCount: '',
                assigneeStatus: '',
                assigneeNumberText: ""
              };
              $scope.myAssigne = {};
              $scope.originalcurrentAssignee = angular.copy($scope.currentAssignee);
            });
      };
      $scope.getAssigneeInfo();

      $scope.change = function (content) {
        $scope.currentAssignee.assigneeFullNameText = content.assigneeFullNameText;
        $scope.currentAssignee.activeCaseCount = content.activeCaseCount;
        $scope.currentAssignee.assigneeStatus = content.assigneeStatus;
        $scope.currentAssignee.assigneeNumberText = content.assigneeNumberText;
      };

      $scope.scrollDisable = true;
      $scope.caseRoleDisable = true;

      $scope.getAssignedTo = function () {
        HttpFactory.getActions(CONSTANTS.URL.ASSIGNEEUSERS + $scope.appUserRole)
          .then(function (successResponse) {
              $scope.myMangers = successResponse.data.managersData;
              $scope.myTeamData = successResponse.data.teamData;
              $scope.myGroupData = successResponse.data.groupData;
              $scope.workQueueData = successResponse.data.workQueueData;
              if ($scope.myGroupData === null) {
                $scope.moreAssignees = true;
              } else {
                $scope.groupLength = $scope.myGroupData.length;
                if ($scope.groupLength === 0) {
                  $scope.moreAssignees = true;
                }
              }
              // for (var k = 0; k <= $scope.myTeamData.length - 1; k++) {
              //   if ($scope.myTeamData[k].assigneeNumberText === String($scope.appUserIdentiifier)) {
              //     $scope.currentAssignee = {
              //       assigneeFullNameText: $scope.myTeamData[k].assigneeFullNameText,
              //       activeCaseCount: $scope.myTeamData[k].activeCaseCount,
              //       assigneeStatus: $scope.myTeamData[k].assigneeStatus,
              //       assigneeNumberText: $scope.myTeamData[k].assigneeNumberText
              //     }
              //   }
              // }
              // $scope.originalcurrentAssignee = angular.copy($scope.currentAssignee);
              // $scope.change($scope.currentAssignee);
            },
            function () {
              // $scope.scrollDisable = true;
              // $scope.currentAssignee = {
              //   assigneeFullNameText: 'Not assigned',
              //   activeCaseCount: '',
              //   assigneeStatus: '',
              //   assigneeNumberText: ""
              // }
              // $scope.myAssigne = {};
              // $scope.originalcurrentAssignee = angular.copy($scope.currentAssignee);
            });
      };
      $scope.getAssignedTo();

      $scope.moreAssigneesData = function () {
        $scope.extraData = false;
        $scope.moreAssignees = true;
        $scope.myGroup = $scope.myGroupData;
      };

    });
})();
