(function () {
  "use strict";

  angular
    .module('ptabe2e')
    .controller('ViewReassignController', function ($scope, ngDialog, reassignData, HttpFactory, CONSTANTS, CommonHelperService) {
      var vm = this;
      vm.isSave = false;
      vm.reassignData = reassignData;
      vm.originalReassignData = angular.copy(vm.reassignData);

      /* istanbul ignore next */
      vm.myUserRoleForReAssign = function (selectedRole, selectedUser) {
        vm.myReassignRole = selectedRole;
        vm.reassignData.assigneeRoleCode = selectedRole;
        HttpFactory.getActions(CONSTANTS.URL.ASSIGNEDTO + "roleCode=" + vm.myReassignRole)
          .then(function (successResponse) {
              vm.myAssigne = successResponse.data;
              vm.currentSelectedRole = selectedRole;
              vm.foundAssigne = false;
              angular.forEach(vm.myAssigne, function (item) {
                if (item.assigneeNumberText === selectedUser) {
                  vm.foundAssigne = true;
                  vm.currentAssignee = {
                    assigneeFullNameText: item.assigneeFullNameText,
                    activeCaseCount: item.activeCaseCount,
                    assigneeStatus: item.assigneeStatus,
                    assigneeNumberText: selectedUser
                  };
                }
              });
              vm.scrollDisable = false;
              if (!vm.foundAssigne) {
                vm.currentAssignee = {
                  assigneeFullNameText: 'Not assigned',
                  activeCaseCount: '',
                  assigneeStatus: '',
                  assigneeNumberText: ""
                };
              }
              vm.originalcurrentAssignee = angular.copy(vm.currentAssignee);
              vm.change(vm.currentAssignee);

            },
            function () {
              vm.currentAssignee = {
                assigneeFullNameText: 'Not assigned',
                activeCaseCount: '',
                assigneeStatus: '',
                assigneeNumberText: ""
              };
              vm.myAssigne = {};
              vm.scrollDisable = true;
              vm.originalcurrentAssignee = angular.copy(vm.currentAssignee);
            });
      };


      vm.change = function (content) {
        $scope.isSaveEnableButton = false;
        if (!angular.equals(content.assigneeNumberText, vm.reassignData.assignee)) {

          $scope.isSaveEnableButton = true;
        }
        vm.currentAssignee.assigneeFullNameText = content.assigneeFullNameText;
        vm.currentAssignee.activeCaseCount = content.activeCaseCount;
        vm.currentAssignee.assigneeStatus = content.assigneeStatus;
        vm.currentAssignee.assigneeNumberText = content.assigneeNumberText;
      };

      vm.cancelReassign = function () {
        if ((!vm.isSave && (!angular.equals(vm.currentAssignee, vm.originalcurrentAssignee) || !angular.equals(vm.reassignData, vm.originalReassignData))) && !$scope.saveChanges) {
          ngDialog.open({
            template: 'app/importManager/unSavedChanges.html',
            controller: 'UnSavedChangesReAssignController',
            controllerAs: 'vm',
            width: '25%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              reassignData: function () {
                return vm.reassignData;
              },
              originalReassignData: function () {
                return vm.originalReassignData;
              },
              currentAssignee: function () {
                return vm.currentAssignee;
              },
              originalcurrentAssignee: function () {
                return vm.originalcurrentAssignee;
              }
            }
          });
        } else {

          ngDialog.closeAll();
        }

      };

      $scope.checkDueDateResassign = function () {

        if (angular.isUndefined(vm.reassignData.dueDate) || isNaN(vm.reassignData.dueDate)) {
          $scope.showErrorMsgDueDate = true;
          $scope.errorMessageDueDate = "The due date cannot be empty.";
          $scope.readyToSaveDate = false;
        } else {
          $scope.readyToSaveDate = true;
          $scope.showErrorMsgDueDate = false;
        }

      };


      $scope.updateReAssignCase = function (saveflag, beNo, reassignFlag) {

        vm.reassignData.dueDate = new Date(vm.reassignData.dueDate).getTime();

        $scope.updateReAssigndata = {

          "assignmentType": vm.reassignData.assignmentType,
          "assignee": beNo,
          "serialNumber": vm.reassignData.serialNumber,
          "title": vm.reassignData.title,
          "description": vm.reassignData.description,
          "dueDate": vm.reassignData.dueDate,
          "completionDate": vm.reassignData.completionDate,
          "caseType": vm.reassignData.caseType,
          "appealNumber": vm.reassignData.appealNumber,
          "sequenceNumber": vm.reassignData.sequenceNumber,
          "notes": vm.reassignData.notes,
          "assigneeRoleCode": vm.reassignData.assigneeRoleCode,
          "priorityIndicator": (vm.reassignData.priorityIndicator) ? 'Y' : 'N',
          "assignmentIdentifier": vm.reassignData.assignmentIdentifier,
          "assignor": vm.reassignData.assignor,
          "activeIndicator": vm.reassignData.activeIndicator,
          "audit": {
            "createUserIdentifier": vm.reassignData.audit.createUserIdentifier,
            "lastModifiedUserIdentifier": vm.reassignData.workerNumber,
            "lockControlNumber": vm.reassignData.audit.lockControlNumber,
            "createTimestamp": vm.reassignData.audit.createTimestamp,
            "lastModifiedTimestamp": new Date().getTime()

          }

        };

        $scope.updateReAssign($scope.updateReAssigndata, saveflag, reassignFlag);
      };

      $scope.saveChanges = false;

      $scope.updateReAssign = function (data, saveflag, reassignFlag) {
        if ($scope.readyToSaveDate === true) {
          /* istanbul ignore next */
          HttpFactory.putActions(CONSTANTS.URL.UPDATE_ASSIGNMENT, data)
            .then(function (successResponse) {
              CommonHelperService.setToastr("", "clear");
              $scope.saveChanges = true;
              vm.reassignData.audit.lockControlNumber = successResponse.data.audit.lockControlNumber;
              vm.reassignData.assignmentIdentifier = successResponse.data.assignmentIdentifier;
              $scope.refreshData().then(function () {
                if (reassignFlag) {
                  CommonHelperService.setToastr("The case " + data.serialNumber + "  was successfully reassigned.", "success");
                } else {
                  CommonHelperService.setToastr("The case " + data.serialNumber + "  was successfully updated.", "success");
                }

              });
              $scope.closeupdateReassigndlg(saveflag);

            }, function (failureResponse) {
              CommonHelperService.setToastr("", "clear");
              $scope.closeupdateReassigndlg(saveflag);
              $scope.saveChanges = false;
              $scope.refreshData().then(function () {
                checkReassignFlag(reassignFlag, failureResponse, data);
              });

            });
        } else {
          $scope.checkDueDateResassign();
        }
      };
      /* istanbul ignore next */
      function checkReassignFlag(reassignFlag, failureResponse, data) {
        if (reassignFlag) {
          if (failureResponse.status === 404 || failureResponse.status === 500 || failureResponse.status === 400) {
            CommonHelperService.setToastr("Reassignment of application " + data.serialNumber + " has failed.  Please retry or contact your supervisor.", "error");
          }
        } else {
          CommonHelperService.setToastr(CONSTANTS.TOASTER.quickUpdateFail, "error");
        }
      }

      $scope.closeupdateReassigndlg = function (closedlg) {
        if (closedlg) {
          ngDialog.closeAll();
        }
      };

      $scope.isSaveEnableButton = false;
      $scope.saveEnable = function () {
        if (!angular.equals(vm.reassignData, vm.originalReassignData)) {
          $scope.isSaveEnableButton = true;
        }

      };


    });
})();
