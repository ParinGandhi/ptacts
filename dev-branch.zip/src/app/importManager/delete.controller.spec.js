(function () {
  'use strict';

  describe('DeleteController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll']);
    var deleteData;
    var controller, scope;


    beforeEach(inject(function (_$controller_, _$rootScope_) {
      $controller = _$controller_;
      scope = _$rootScope_.$new();



      controller = $controller('DeleteController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        deleteData: deleteData
      });
    }));

    describe('DeleteController ', function () {


      it('it should call cancelDelete ', function () {

        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['cancelDelete']).toBeDefined();
        controller.cancelDelete();
        expect(ngDialog.closeAll).toHaveBeenCalledWith();

      });

      it('it should call deleteNumber ', function () {

        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['deleteNumber']).toBeDefined();
        controller.deleteNumber();
        expect(ngDialog.closeAll).toHaveBeenCalledWith(deleteData);

      });


    });
  });
})();
