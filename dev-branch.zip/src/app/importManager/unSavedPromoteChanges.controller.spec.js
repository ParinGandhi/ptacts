(function () {
  'use strict';

  describe('UnSavedChangesPromoteController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close']);
    var dataToPromote, currentAssignee, originalDataToPromote, originalcurrentAssignee;
    var controller, scope, $rootScope;
    var timeout;

    dataToPromote = {
      'assigneeRoleCode': 'PTABE2E_Administrator',
      'dueDate': 1500000,
      'notes': 'hi'
    }
    originalDataToPromote = {
      'assigneeRoleCode': 'PTABE2E_Administrator',
      'dueDate': 1500000,
      'notes': 'hi'
    }
    currentAssignee = {
      'name': 'mmylar'
    }
    originalcurrentAssignee = {
      'name': 'mmylar'
    }

    beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_) {
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      timeout = _$timeout_;


      controller = $controller('UnSavedChangesPromoteController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        dataToPromote: dataToPromote,
        currentAssignee: currentAssignee,
        originalDataToPromote: originalDataToPromote,
        originalcurrentAssignee: originalcurrentAssignee
      });
    }));

    describe('UnSavedChangesPromoteController ', function () {


      it('it should call closePromoteDialog ', function () {

        var ngDialogArray = [ngDialog, ngDialog];
        expect(ngDialog.close).toBeDefined();
        expect(controller['closePromoteDialog']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        controller.closePromoteDialog();
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog);

        expect(ngDialog.close).toBeDefined();
        expect(controller['closePromoteDialog']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.closePromoteDialog();
        expect(ngDialog.close).toHaveBeenCalledWith();

      });

      it('it should call revertPromotechanges ', function () {

        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['revertPromotechanges']).toBeDefined();
        controller.revertPromotechanges();
        expect(ngDialog.closeAll).toHaveBeenCalledWith();

      });


    });
  });
})();
