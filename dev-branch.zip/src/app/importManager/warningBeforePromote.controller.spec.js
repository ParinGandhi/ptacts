(function () {
  'use strict';

  describe('WarningBeforePromoteController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll']);
    var promoteToAppealWarning;
    var controller, scope, $rootScope;
    var timeout;


    beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_) {
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      timeout = _$timeout_;


      controller = $controller('WarningBeforePromoteController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        promoteToAppealWarning: promoteToAppealWarning,
      });
    }));

    describe('WarningBeforePromoteController ', function () {


      // it('it should call cancelWarning ', function () {

      //   // expect(ngDialog.closeAll).toBeDefined();
      //   expect(scope['cancelWarning']).toBeDefined();
      //   scope.cancelWarning();
      //   // expect(ngDialog.closeAll).toHaveBeenCalledWith();

      // });

      // it('it should call confirmWarning ', function () {

      //   // expect(ngDialog.closeAll).toBeDefined();
      //   // expect(scope['confirmWarning']).toBeDefined();
      //   // scope.confirmWarning();
      //   // expect(ngDialog.closeAll).toHaveBeenCalledWith(promoteToAppealWarning);

      // });


    });
  });
})();
