(function () {
  "use strict";

  angular
    .module('ptabe2e')
    .controller('DeleteController', function (ngDialog, deleteData) {
      var vm = this;
      vm.caseNumber = deleteData;

      vm.cancelDelete = function () {
        ngDialog.closeAll();
      };

      vm.deleteNumber = function () {
        ngDialog.closeAll(vm.caseNumber);
      };

    });
})();
