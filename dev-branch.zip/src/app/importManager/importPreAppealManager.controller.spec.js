(function () {
  'use strict';

  describe('ImportPreAppealManagerController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var controller, scope, $rootScope, $window, $CommonHelperService;
    var successResponse, number, row, userInfo;
    var $httpBackend, spy, $q, HttpFactoryDeferred;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'close', 'closeAll']);

    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              getWidgetZone: function () {

              },
              setWidgetContentHeight: function () {

              }
            }
          }
        }
      }
    };

    var closeData = {
      value: {
        serialNumber: '0600006',
        notes: "hello",
        "audit": {
          "createUserIdentifier": "pgandhi",
          "lastModifiedUserIdentifier": "pgandhi",
          "lockControlNumber": 2
        }
      }
    }
    var newcase = {
      value: {
        "caseNumber": "90013458"
      }
    }
    var row = {
      "entity": {
        "assignmentData": {
          "serialNumber": "10668133",
          "sequenceNumber": 0,
          "appealNumber": "0",
          "lifeCycle": null,
          "audit": {
            "lastModifiedTimestamp": 1536356614000,
            "lastModifiedUserIdentifier": "pgandhi",
            "createUserIdentifier": "pgandhi",
            "createdUserName": null,
            "lastModifiedUserName": null,
            "createTimestamp": 1536164268970,
            "lockControlNumber": 2
          },
          "assignmentIdentifier": 1724,
          "assignmentType": "ATP1",
          "assignee": "5830",
          "assignor": "5768",
          "caseType": "PRE-APPEAL",
          "priorityIndicator": "Y",
          "activeIndicator": "A",
          "title": "Import manager default title",
          "description": "Import manager default description",
          "notes": null,
          "assignedDate": 1536164268000,
          "dueDate": 1536164268000,
          "completionDate": 1536356614000,
          "palmMailedDate": 1496635200000,
          "completedUserName": null,
          "lastModifiedUserName": null,
          "noOfActiveCases": 0,
          "assignmentStatusCode": "A",
          "assigneeRoleCode": "PTABE2E_Administrator",
          "assignmentSequence": 0,
          "reconsiderSequence": 0,
          "pendingLocationText": null,
          "assignmentTypeDescription": null
        }
      },
      "assigneeFullName": "Appeal Import"
    }

    beforeEach(inject(function (_$controller_, _$rootScope_, _$httpBackend_, _$q_, HttpFactory, $window, _CommonHelperService_) {
      $q = _$q_;
      scope = _$rootScope_.$new();
      $controller = _$controller_;
      $rootScope = _$rootScope_;
      $httpBackend = _$httpBackend_;
      $CommonHelperService = _CommonHelperService_;

      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback1, callback2) {
            callback1(closeData);
            callback2(newcase);
          }
        },
        then: function (callback3, callback4) {
          callback3();
          callback4();
        }
      });


      userInfo = {
        "userId": "sbartlett",
        "displayName": "Bartlett, Steven J",
        "appUserInfo": [{
          "userIdentiifier": 5850,
          "activeIn": "Active",
          "lastName": "Bartlett",
          "privileges": ["ImportManager_PostDecisionCaseManager Privileges", "panel_Update", "Paneling"],
          "loginId": "sbartlett",
          "fullName": "Bartlett, Steven J",
          "disiplanceCd": "Admin",
          "jobClassificationCode": "ADM",
          "firstName": "Steven",
          "emailAddress": "Jacqueline.Bui@USPTO.GOV",
          "userWorkerNumber": "83707",
          "roleDescription": "Business Administrator",
          "apjSeniorityRank": 0
        }]
      }

      $window.parent = "pgandhi";
      $window.opener = {
        userInfo: {
          "userId": "pgandhi",
          appUserInfo: {
            "roleDescription": "Admin",
            "userIdentiifier": 5768
          }
        }
      }
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'deleteActions').and.returnValue(HttpFactoryDeferred.promise);
      spy = spyOn(angular, 'element').and.callFake(fakeElement);
      spyOn($CommonHelperService, 'setToastr').and.callFake(function () {
        return "toastr";
      });

      controller = $controller('ImportPreAppealManagerController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory,
        $window: $window,
        userInfo: userInfo
      });
    }));

    describe('ImportPreAppealManagerController ', function () {

      //TODO - fix test case
      it('it should call gridOPtions', function () {

        var gridApi = {
          core: {
            on: {
              filterChanged: function ($scope, callback) {}
            },
          },
          selection: {
            on: {
              rowSelectionChanged: function ($scope, callback) {},
              rowSelectionChangedBatch: function ($scope, callback) {}
            }
          }
        };
        expect(scope.gridOptions).toBeDefined();
        expect(scope.gridOptions.onRegisterApi).toBeDefined();
        scope.gridOptions.onRegisterApi(gridApi);
        expect(scope.gridApi).toBe(gridApi);
        scope.gridApi.core.on.filterChanged();

      });


      it('should call loadImportManager', function () {

        expect(controller.loadImportManager).toBeDefined();
        controller.loadImportManager(userInfo);

      });

      //TODO - fix test case
      it('it should call toggleFilteringImport', function () {

        scope.gridOptions = {
          enableFiltering: true,
          data: "test"
        };
        scope.gridApi = {
          core: {
            notifyDataChange: function (val) {

            }
          },
          grid: {
            clearAllFilters: function () {

            }
          }
        };
        scope.myData = {
          caseDetailsData: {

          }
        }
        scope.showFilters = true;

        controller.loadImportManager(userInfo);
        expect(scope.toggleFilteringImport).toBeDefined();
        scope.toggleFilteringImport();

      });



      //TODO - fix test case
      it('it should open showFilteringPreAppeal ', function () {

        controller.loadImportManager(userInfo);

        var existingCount = ngDialog.open.calls.count();
        expect(scope.showFilteringPreAppeal).toBeDefined();
        scope.showFilteringPreAppeal();
        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(existingCount + 1);
        var args = ngDialog.open.calls.argsFor(existingCount);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('CommonDialogController');
      });

      //TODO - fix test case
      it('it should call importNewCase success', function () {

        scope.importData = {};
        successResponse = {
          "data": {
            "allowedResourceObjectList": [
              "panel_Update"
            ],
            "ptabReadOnlyUser": false,
            "columnDetails": [{
                "cellTemplate": null,
                "pinToRight": false,
                "typeDefinition": "String",
                "pinToLeft": true,
                "name": "serialNumber",
                "label": "Application #",
                "selected": true
              },
              {
                "cellTemplate": null,
                "pinToRight": false,
                "typeDefinition": "String",
                "pinToLeft": false,
                "name": "promote",
                "label": "Promote?",
                "selected": true
              }
            ],
            "caseDetailsData": [{
                "preAppealInfo": {
                  "appealForwardingFeePaid": false,
                  "preAppealAvailableIndicator": false,
                  "secrecyCode": "1",
                  "examinerAnswerMailExpectedDate": null,
                  "replyBriefTimelyFiledIndicator": false,
                  "petitionsFiledIndicator": false,
                  "appealBriefFeePaid": false,
                  "petitionDecided": false,
                  "promote": "Needs verification",
                  "applicationStatus": "118",
                  "deliveryMode": null,
                  "userIdentifier": "sbartlett",
                  "applicationFilingDate": 1366171200000,
                  "applicationStatusDate": 1559311456000,
                  "receivedDate": 1559313239000,
                  "applicationTypeCategory": "REGULAR",
                  "serialNumber": "13821350",
                  "preAppealSequenceNumber": 0,
                  "groupArtUnitNumber": "3774",
                  "petitionFilingDate": null,
                  "replyBriefRecordedDate": null,
                  "petitionDecisionMessage": "N/A",
                  "techCenter": "3700",
                  "manualImportIndicator": false,
                  "assigneeFullName": "PTAB Appeals Import",
                  "replyBriefDueDateExpIndicator": false,
                  "respondentBriefFeePaid": false,
                  "availablePetitions": null,
                  "examinerAnswerMailDate": null
                },
                "preAppeal": {
                  "activeIndicator": "A",
                  "sequenceNumber": 0,
                  "manualImportIndicator": "N",
                  "preAppealNumber": 0,
                  "audit": {
                    "createUserIdentifier": null,
                    "createdUserName": null,
                    "lockControlNumber": 0,
                    "lastModifiedUserIdentifier": "sbartlett",
                    "lastModifiedUserName": null,
                    "lastModifiedTimestamp": 1559313239000,
                    "createTimestamp": null
                  },
                  "applicationNumberText": "13821350",
                  "receivedDate": 1559313239000,
                  "disciplineCode": "M"
                },
                "appealAssignment": {
                  "assignedDate": 1559313239000,
                  "notes": null,
                  "dueDate": 1559534400000,
                  "description": "Review checklist assignment to POC1 for 0",
                  "palmMailedDate": null,
                  "title": "Review Checklist Assignment To POC1 for 0",
                  "assignmentType": "ATP1",
                  "assignmentTypeIdentifier": "52",
                  "caseType": "PRE-APPEAL",
                  "noOfActiveCases": 0,
                  "globalMetaData": null,
                  "assignmentTypeDescription": "Review checklist assignment to POC1",
                  "audit": {
                    "createUserIdentifier": "sbartlett",
                    "createdUserName": null,
                    "lockControlNumber": 0,
                    "lastModifiedUserIdentifier": "sbartlett",
                    "lastModifiedUserName": null,
                    "lastModifiedTimestamp": 1559313239000,
                    "createTimestamp": 1559313239604
                  },
                  "appealNumber": "0",
                  "standardAssignmentType": null,
                  "actionCode": null,
                  "pendingLocationText": null,
                  "assignmentStatusCode": "A",
                  "hearingIndicator": null,
                  "activeIndicator": "A",
                  "sequenceNumber": 0,
                  "serialNumber": "13821350",
                  "assignor": "3572",
                  "assigneeRoleDescription": "Paralegal/LIE",
                  "assigneeRoleCode": "Paralegal/LIE",
                  "lastModifiedUserName": null,
                  "message": null,
                  "completedUserName": null,
                  "reconsiderSequence": 0,
                  "assignmentIdentifier": 611711,
                  "nextAssignee": null,
                  "assignmentSequence": 0,
                  "priorityIndicator": "N",
                  "clearPanelIndicator": null,
                  "completionCode": null,
                  "completionDate": null,
                  "assignee": "11363",
                  "lifeCycle": null
                }
              },
              {
                "preAppealInfo": {
                  "appealForwardingFeePaid": true,
                  "preAppealAvailableIndicator": false,
                  "secrecyCode": "1",
                  "examinerAnswerMailExpectedDate": null,
                  "replyBriefTimelyFiledIndicator": false,
                  "petitionsFiledIndicator": false,
                  "appealBriefFeePaid": false,
                  "petitionDecided": false,
                  "promote": "Needs verification",
                  "applicationStatus": "118",
                  "deliveryMode": null,
                  "userIdentifier": "sbartlett",
                  "applicationFilingDate": 1332216000000,
                  "applicationStatusDate": 1559311531000,
                  "receivedDate": 1559313239000,
                  "applicationTypeCategory": "REGULAR",
                  "serialNumber": "13425058",
                  "preAppealSequenceNumber": 0,
                  "groupArtUnitNumber": "1644",
                  "petitionFilingDate": null,
                  "replyBriefRecordedDate": null,
                  "petitionDecisionMessage": "N/A",
                  "techCenter": "1600",
                  "manualImportIndicator": false,
                  "assigneeFullName": "PTAB Appeals Import",
                  "replyBriefDueDateExpIndicator": false,
                  "respondentBriefFeePaid": false,
                  "availablePetitions": null,
                  "examinerAnswerMailDate": null
                },
                "preAppeal": {
                  "activeIndicator": "A",
                  "sequenceNumber": 0,
                  "manualImportIndicator": "N",
                  "preAppealNumber": 0,
                  "audit": {
                    "createUserIdentifier": null,
                    "createdUserName": null,
                    "lockControlNumber": 0,
                    "lastModifiedUserIdentifier": "sbartlett",
                    "lastModifiedUserName": null,
                    "lastModifiedTimestamp": 1559313239000,
                    "createTimestamp": null
                  },
                  "applicationNumberText": "13425058",
                  "receivedDate": 1559313239000,
                  "disciplineCode": "B"
                },
                "appealAssignment": {
                  "assignedDate": 1559313239000,
                  "notes": null,
                  "dueDate": 1559534400000,
                  "description": "Review checklist assignment to POC1 for 0",
                  "palmMailedDate": null,
                  "title": "Review Checklist Assignment To POC1 for 0",
                  "assignmentType": "ATP1",
                  "assignmentTypeIdentifier": "52",
                  "caseType": "PRE-APPEAL",
                  "noOfActiveCases": 0,
                  "globalMetaData": null,
                  "assignmentTypeDescription": "Review checklist assignment to POC1",
                  "audit": {
                    "createUserIdentifier": "sbartlett",
                    "createdUserName": null,
                    "lockControlNumber": 0,
                    "lastModifiedUserIdentifier": "sbartlett",
                    "lastModifiedUserName": null,
                    "lastModifiedTimestamp": 1559313239000,
                    "createTimestamp": 1559313239730
                  },
                  "appealNumber": "0",
                  "standardAssignmentType": null,
                  "actionCode": null,
                  "pendingLocationText": null,
                  "assignmentStatusCode": "A",
                  "hearingIndicator": null,
                  "activeIndicator": "A",
                  "sequenceNumber": 0,
                  "serialNumber": "13425058",
                  "assignor": "3572",
                  "assigneeRoleDescription": "Paralegal/LIE",
                  "assigneeRoleCode": "Paralegal/LIE",
                  "lastModifiedUserName": null,
                  "message": null,
                  "completedUserName": null,
                  "reconsiderSequence": 0,
                  "assignmentIdentifier": 611712,
                  "nextAssignee": null,
                  "assignmentSequence": 0,
                  "priorityIndicator": "N",
                  "clearPanelIndicator": null,
                  "completionCode": null,
                  "completionDate": null,
                  "assignee": "11363",
                  "lifeCycle": null
                }
              }
            ],
            "tasks": [{
                "valueText": "PROMOTE",
                "descriptionText": "Promote to appeal"
              },
              {
                "valueText": "REASSIGN",
                "descriptionText": "Reassign"
              },
              {
                "valueText": "REJECT",
                "descriptionText": "Reject"
              },
              {
                "valueText": "VIEW",
                "descriptionText": "View case information"
              }
            ]
          },
          "status": 200,
          "config": {
            "method": "POST",
            "transformRequest": [
              null
            ],
            "transformResponse": [
              null
            ],
            "url": "http://localhost:8081/import-manager/bulk",
            "withCredentials": true,
            "crossDomain": true,
            "data": {
              "userIdentifier": "sbartlett"
            },
            "headers": {
              "Content-Type": "application/json",
              "user-name": "sbartlett",
              "Accept": "application/json, text/plain, */*"
            }
          },
          "statusText": ""
        }
        controller.importedCaseNumber = "90013458";

        controller.loadImportManager(userInfo);
        expect(scope['importNewCase']).toBeDefined();
        scope.importNewCase();


        // HttpFactoryDeferred.resolve(successResponse);
        // $rootScope.$apply();

        expect(ngDialog.open).toHaveBeenCalled();

        // expect(ngDialog.open.calls.count()).toBe(1);
        // var args = ngDialog.open.calls.argsFor(0);
        // expect(args).not.toBe(null);
        // expect(args.length).toBe(1);

        // expect(args[0].controller).toBe('ImportNewCaseController');
        // expect(typeof args[0].resolve).toBe('object');
        // args[0].resolve.userInfo();
      });


      it('it should call importNewCase failure 404', function () {

        scope.reassignData = {};
        var failureResponse = {
          data: {
            message: "Failed"
          },
          status: 404
        };
        controller.loadImportManager(userInfo);
        controller.importedCaseNumber = "90013458";
        expect(scope['importNewCase']).toBeDefined();
        scope.importNewCase();
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();

      });


      it('it should call importNewCase failure', function () {

        scope.reassignData = {};
        var failureResponse = {
          data: {
            message: "Failed"
          }
        };
        controller.loadImportManager(userInfo);
        controller.importedCaseNumber = "90013458";
        expect(scope['importNewCase']).toBeDefined();
        scope.importNewCase();
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();

      });

      //TODO - fix test case
      // it('it should call getCall ', function () {
      //   controller.loadImportManager(userInfo);
      //   expect(scope.getCall).toBeDefined();
      //   spyOn(scope, 'importedPreAppealData');
      //   expect(scope.importedPreAppealData).toBeDefined();
      //   scope.getCall();
      //   expect(scope.importedPreAppealData).toHaveBeenCalled();
      // });

      //TODO - fix test case
      // it('it should call importedPreAppealData ', function () {

      //   successResponse = {
      //     data: {
      //       "columnDetails": [{
      //           "name": "serialNumber",
      //           "label": "Application #",
      //           "typeDefinition": "String",
      //           "pinToLeft": true,
      //           "pinToRight": false,
      //           "selected": true
      //         },
      //         {
      //           "name": "task",
      //           "label": "TASK",
      //           "typeDefinition": "String",
      //           "pinToLeft": true,
      //           "pinToRight": false,
      //           "selected": true
      //         },
      //         {
      //           "name": "promote",
      //           "label": "Promote?",
      //           "typeDefinition": "Date",
      //           "pinToLeft": false,
      //           "pinToRight": false,
      //           "selected": true
      //         },
      //         {
      //           "name": "dav",
      //           "label": "Pre-appeal Seq#",
      //           "typeDefinition": "Number",
      //           "pinToLeft": false,
      //           "pinToRight": true,
      //           "selected": false
      //         },
      //         {
      //           "name": "deliveryMode",
      //           "label": "TrueFalse",
      //           "typeDefinition": "Boolean",
      //           "pinToLeft": false,
      //           "pinToRight": true,
      //           "selected": false
      //         },
      //         {
      //           "name": "appealForwardingFeePaid",
      //           "label": "Appeal Forwarding Fee Paid?",
      //           "typeDefinition": "Boolean",
      //           "pinToLeft": false,
      //           "pinToRight": false,
      //           "selected": true
      //         }
      //       ],
      //       "caseDetailsData": [{
      //           "preAppealInfo": {
      //             "promote": "Manual Import",
      //             "appealForwardingFeePaid": false,
      //             "manualImportIndicator": true,
      //             "deliveryMode": "MAIL",
      //             "userIdentifier": "mmylar",
      //             "receivedDt": 1534363756000
      //           },
      //           "preAppeal": {
      //             "fkAaSerialNo": "90002688",
      //             "sequenceNo": 0,
      //             "audit": {
      //               "lockControlNumber": 0
      //             }
      //           },
      //           "appealAssignment": {
      //             "ptabAssignmentId": 1142417
      //           },
      //           "specialType": {
      //             "fkPaFkAaSerialNo": "90002688",
      //             "fkPaSequenceNo": 0
      //           },
      //           "specialTypes": null
      //         },
      //         {
      //           "preAppealInfo": {
      //             "promote": "Manual Import",
      //             "appealForwardingFeePaid": true,
      //             "manualImportIndicator": true,
      //             "deliveryMode": "EMAIL",
      //             "userIdentifier": "mmylar",
      //             "receivedDt": 1534363756000
      //           },
      //           "preAppeal": {
      //             "fkAaSerialNo": "90002688",
      //             "sequenceNo": 0,
      //             "audit": {
      //               "lockControlNumber": 0
      //             }
      //           },
      //           "appealAssignment": {
      //             "ptabAssignmentId": 1142417
      //           },
      //           "specialType": {
      //             "fkPaFkAaSerialNo": "90002688",
      //             "fkPaSequenceNo": 0
      //           },
      //           "specialTypes": null
      //         }
      //       ]

      //     }

      //   };

      //   var data = {
      //     'userIdentifier': 'pgandhi'
      //   }
      //   expect(scope.importedPreAppealData).toBeDefined();
      //   scope.importedPreAppealData(data);

      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();

      //   // expect(scope.myData).toBe(successResponse.data);

      // });

      // it('get Actions failureResponse ', function () {

      //   var failureResponse = {
      //     data: {
      //       "message": "Application System Error.Please Contact PTAB Support Team"
      //     }

      //   }

      //   var data = {
      //     'userIdentifier': 'pgandhi'
      //   }
      //   expect(scope.importedPreAppealData).toBeDefined();
      //   scope.importedPreAppealData(data);

      //   HttpFactoryDeferred.reject(failureResponse);
      //   $rootScope.$apply();
      //   // scope.$digest();
      // });

      //TODO - fix test case
      it('it should call pressEnter ', function () {
        var event = {};
        event.keyCode = 13;

        controller.loadImportManager(userInfo);
        spyOn(scope, 'importNewCase');
        expect(scope['importNewCase']).toBeDefined();
        expect(scope['pressEnter']).toBeDefined();
        scope.pressEnter(event);
        expect(scope.importNewCase).toHaveBeenCalled();
      });

      // it('it should call addToImport ', function () {
      //   // var decision = true;

      //   expect(scope['addToImport']).toBeDefined();
      //   scope.addToImport();
      // });

      //TODO - fix test case
      it('it should call addToImportManagerData ', function () {

        controller.loadImportManager(userInfo);
        expect(scope['addToImportManagerData']).toBeDefined();
        scope.addToImportManagerData();
      });

      //TODO - fix test case
      // it('it should call warningBeforePromote ', function () {
      //   var existingCount = ngDialog.open.calls.count();
      //   controller.loadImportManager(userInfo);
      //   expect(scope['warningBeforePromote']).toBeDefined();
      //   scope.warningBeforePromote();


      //   expect(ngDialog.open).toHaveBeenCalled();

      //   expect(ngDialog.open.calls.count()).toBe(existingCount + 1);
      //   var args = ngDialog.open.calls.argsFor(existingCount);
      //   expect(args).not.toBe(null);
      //   expect(args.length).toBe(1);

      //   expect(args[0].controller).toBe('WarningBeforePromoteController');
      //   expect(typeof args[0].resolve).toBe('object');
      //   args[0].resolve.promoteToAppealWarning();

      // });

      //TODO - fix test case
      it('it should call openPromoteToAppeal ', function () {
        scope.promoteData = {}
        row = {
          entity: {
            assignmentData: {
              "promote": "Manual Import",
              "appealForwardingFeePaid": true,
              "manualImportIndicator": true,
              "priorityIndicator ": "Y",
              "assigneeRoleCode": "mmylar",
              "dueDate": 1534363756000,
              "audit": {
                "createUserIdentifier": "pgandhi",
                "lastModifiedUserIdentifier": "pgandhi",
                "lockControlNumber": 0,
                "createTimestamp": 1532712182719,
                "lastModifiedTimestamp": new Date().getTime()

              }
            }
          }
        }

        controller.loadImportManager(userInfo);
        expect(scope['openPromoteToAppeal']).toBeDefined();
        scope.openPromoteToAppeal(row);

        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(2);
        var args = ngDialog.open.calls.argsFor(1);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('PromoteToAppealController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.promoteToAppeal();

      });

      it(' should call openCaseViewer', function () {
        var number = {
          serialNumber: '15007114'
        }

        controller.loadImportManager(userInfo);
        expect(scope['openCaseViewer']).toBeDefined();
        scope.openCaseViewer(number);
      });


      //TODO - fix test case
      // it('it should call viewReassign ', function () {

      //   scope.type = {}
      //   number = '06000006';
      //   row = {
      //     entity: {
      //       assignmentData: {
      //         "promote": "Manual Import",
      //         "appealForwardingFeePaid": true,
      //         "manualImportIndicator": true,
      //         "priorityIndicator ": "Y",
      //         "assigneeRoleCode": "mmylar",
      //         "dueDate": 1534363756000,
      //         "audit": {
      //           "createUserIdentifier": "pgandhi",
      //           "lastModifiedUserIdentifier": "pgandhi",
      //           "lockControlNumber": 0,
      //           "createTimestamp": 1532712182719,
      //           "lastModifiedTimestamp": new Date().getTime()

      //         }
      //       }
      //     }
      //   }

      //   controller.loadImportManager(userInfo);
      //   expect(scope['viewReassign']).toBeDefined();
      //   scope.viewReassign(number, row);
      //   // expect(scope.type).toBe(row.entity.assignmentData);

      //   expect(ngDialog.open).toHaveBeenCalled();

      //   expect(ngDialog.open.calls.count()).toBe(7);
      //   var args = ngDialog.open.calls.argsFor(6);
      //   expect(args).not.toBe(null);
      //   expect(args.length).toBe(1);

      //   expect(args[0].controller).toBe('ViewReassignController');
      //   expect(typeof args[0].resolve).toBe('object');
      //   args[0].resolve.reassignData();


      // });

      // it('it should call reject ', function () {

      //   var rejectData = {
      //     "notes": "added",
      //     "audit": {
      //       "createUserIdentifier": "pgandhi",
      //       "lastModifiedUserIdentifier": "pgandhi",
      //       "lockControlNumber": 2
      //     }
      //   };
      //   controller.orgignalText = "added"
      //   expect(scope['reject']).toBeDefined();
      //   expect(ngDialog.open).toBeDefined();
      //   scope.reject(rejectData);


      //   expect(ngDialog.open).toHaveBeenCalled();

      //   expect(ngDialog.open.calls.count()).toBe(7);
      //   var args = ngDialog.open.calls.argsFor(6);
      //   expect(args).not.toBe(null);
      //   expect(args.length).toBe(1);

      //   expect(args[0].controller).toBe('RejectController');
      //   expect(typeof args[0].resolve).toBe('object');
      //   args[0].resolve.rejectData();

      // });

      // it('it should call bulkAssignmnet ', function () {

      //   scope.gridApi = {
      //     selection: {
      //       getSelectedRows: function () {}
      //     }
      //   }

      //   scope.myRole = "PTAB_Administrator"
      //   // expect(scope.gridApi).toBe(gridApi);
      //   // scope.gridApi.core.on.filterChanged();

      //   expect(scope['bulkAssignmnet']).toBeDefined();
      //   scope.bulkAssignmnet();
      //   expect(scope.selectedData.myRole).toBe(scope.myRole);
      //   expect(ngDialog.open).toHaveBeenCalled();


      // });


      //TODO - fix test case
      // it('it should call refreshData ', function () {

      //   expect(scope['refreshData']).toBeDefined();
      //   scope.refreshData();
      // });

      //TODO - fix test cases
      // it('it should call myUserRole ', function () {
      //   var selectedRole = "PTABE2E_Administrator";
      //   var selectedUser = "5778";

      //   expect(scope['myUserRole']).toBeDefined();
      //   successResponse = {
      //     //   data: {
      //     "assignees": [{
      //       "beNo": "5778",
      //       "name": "Baker, Patrick",
      //       "activeCases": "6",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "beNo": "1810",
      //       "name": "Bartlett, Steven",
      //       "activeCases": "0",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "beNo": "26",
      //       "name": "Brock, Alan",
      //       "activeCases": "0",
      //       "assigneeStatus": "InActive",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "beNo": "5779",
      //       "name": "Bui, Jacqueline",
      //       "activeCases": "3",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }]
      //     //   }

      //   };

      //   successResponse.data = {
      //     assignees: [{
      //       "beNo": "5778",
      //       "name": "Baker, Patrick",
      //       "activeCases": "6",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "beNo": "5779",
      //       "name": "Bui, Jacqueline",
      //       "activeCases": "3",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }]
      //   }

      //   scope.myUserRole(selectedRole, selectedUser);
      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();


      // });

      //TODO - fix test case
      // it('it should call myUserRole found assignee false ', function () {
      //   var selectedRole = "PTABE2E_Administrator";
      //   var selectedUser = "5768";

      //   expect(scope['myUserRole']).toBeDefined();
      //   successResponse = {
      //     "assignees": [{
      //       "beNo": "5778",
      //       "name": "Baker, Patrick",
      //       "activeCases": "6",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "beNo": "1810",
      //       "name": "Bartlett, Steven",
      //       "activeCases": "0",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "beNo": "26",
      //       "name": "Brock, Alan",
      //       "activeCases": "0",
      //       "assigneeStatus": "InActive",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "beNo": "5779",
      //       "name": "Bui, Jacqueline",
      //       "activeCases": "3",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }]

      //   };

      //   successResponse.data = {
      //     assignees: [{
      //       "beNo": "5778",
      //       "name": "Baker, Patrick",
      //       "activeCases": "6",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "beNo": "5779",
      //       "name": "Bui, Jacqueline",
      //       "activeCases": "3",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }]
      //   }

      //   scope.myUserRole(selectedRole, selectedUser);
      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();

      // });


      //TODO - fix test case
      // it('get Actions failureResponse get roles', function () {
      //   var selectedRole = "PTABE2E_Administrator";
      //   var selectedUser = "ptabadmin2";
      //   var failureResponse = {
      //     "message": "assignees not found "
      //   }
      //   scope.myUserRole(selectedRole, selectedUser);
      //   HttpFactoryDeferred.reject(failureResponse);
      //   $rootScope.$apply();
      // });

      //TODO - fix test case
      // it('it should call rejectImportManagerData ', function () {

      //   var rejectData = {
      //     "serialNumber": "10668133",
      //     "sequenceNumber": 0,
      //     "notes": "noteToSave",
      //     "assignmentIdentifier": 1724,
      //     "audit": {
      //       "createUserIdentifier": "pgandhi",
      //       "lastModifiedUserIdentifier": "pgandhi",
      //       "lockControlNumber": 2
      //     }
      //   }
      //   var currentAssigneeBeNo = "5768";

      //   expect(scope['rejectImportManagerData']).toBeDefined();
      //   scope.rejectImportManagerData(rejectData);
      // });

      //TODO - fix test case
      // it('it should call deleteAppeal ', function () {

      //   var deleteNumber = "0600005";
      //   expect(scope['deleteAppeal']).toBeDefined();
      //   expect(ngDialog.open).toBeDefined();
      //   scope.deleteAppeal();


      //   expect(ngDialog.open).toHaveBeenCalled();

      //   expect(ngDialog.open.calls.count()).toBe(8);
      //   var args = ngDialog.open.calls.argsFor(7);
      //   expect(args).not.toBe(null);
      //   expect(args.length).toBe(1);

      //   expect(args[0].controller).toBe('DeleteController');
      //   expect(typeof args[0].resolve).toBe('object');
      //   args[0].resolve.deleteData();

      // });

      // it('it should call deleteImportManagerData ', function () {

      //   var number = "0600005";
      //   successResponse = {
      //     data: {}
      //   }

      //   expect(scope['deleteImportManagerData']).toBeDefined();
      //   scope.deleteImportManagerData(number);
      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();
      // });

      // it('it should call deleteImportManagerData ', function () {

      //   var number = "0600005";
      //   var failureResponse = {
      //     data: {}
      //   }

      //   expect(scope['deleteImportManagerData']).toBeDefined();
      //   scope.deleteImportManagerData(number);
      //   HttpFactoryDeferred.reject(failureResponse);
      //   $rootScope.$apply();
      // });

      // it('it should call getAllReassignData ', function () {

      //   var data = {
      //     "assignee": "5780",
      //     "assigneeRoleCode": "PTABE2E_Administrator",
      //     "assignmentDesc": "Assignment To POC4",
      //     "dueDate": 1532712182719
      //   }
      //   var currentAssigneeBeNo = "5768";

      //   successResponse = {
      //     data: {
      //       "ptabAssignmentId": "818484",
      //       "sequenceNo": "0",
      //       "fkAssignmentTypeCd": null,
      //       "activeIn": "\u0000",
      //       "assignedDt": null,
      //       "completionDt": null,
      //       "pendingLocationTx": null,
      //       "lastModifiedTs": 1534455764523,
      //       "lastModifiedUserId": null,
      //       "assignee": null,
      //       "fkAdFkAppealNo": "0",
      //       "serialNumber": null,
      //       "fkAdSequenceNo": "0"
      //     }
      //   }

      //   expect(scope['getAllReassignData']).toBeDefined();
      //   scope.getAllReassignData(data, currentAssigneeBeNo);

      //   // HttpFactoryDeferred.resolve(successResponse);
      //   // $rootScope.$apply();
      // });


      //TODO - fix test case
      // it('it should call getAllReassignBulkData ', function () {

      //   var data = [{
      //     assignmentData: {
      //       "serialNumber": "0",
      //       "fkAssignmentTypeCd": "ATP1",
      //       "audit": {
      //         "createUserIdentifier": "pgandhi",
      //         "lastModifiedUserIdentifier": "pgandhi",
      //         "lockControlNumber": 0,
      //         "createTimestamp": 1532712182719,
      //         "lastModifiedTimestamp": new Date().getTime()

      //       }
      //     },
      //     "assignee": "5780",
      //     "assigneeRoleCode": "PTABE2E_Administrator",
      //     "assignmentDesc": "Assignment To POC4",
      //     "dueDate": 1532712182719
      //   }]
      //   var modifiedItem = {
      //     "assignee": "5780",
      //     "assigneeRoleCode": "PTABE2E_Administrator",
      //     "assignmentDesc": "Assignment To POC4",
      //     "dueDate": 1532712182719
      //   }
      //   var currentAssigneeBeNo = "5768";

      //   expect(scope['getAllReassignBulkData']).toBeDefined();
      //   scope.getAllReassignBulkData(data, currentAssigneeBeNo, modifiedItem);
      // });

      //TODO - fix test case
      // it('it should call copyToClipBoard ', function () {

      //   expect(scope['copyToClipBoard']).toBeDefined();
      //   scope.copyToClipBoard();
      // });

      //TODO - fix test case
      // it('it should call updatePromteData ', function () {

      //   expect(scope['updatePromteData']).toBeDefined();
      //   scope.updatePromteData();
      // });

    });
  });
})();
