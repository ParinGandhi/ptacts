(function () {
  "use strict";

  angular.module('ptabe2e')
    .directive('loadingBar', /* istanbul ignore next */ function ($window) {
      return {
        restrict: 'EA',

        template: '<div class="progress" ng-if="isLoading" >' +
          '<div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%">' +
          '<span class="sr-only">Loading...</span>' +
          '</div>' +
          '</div>'
      };
    })
    .controller('ImportPreAppealManagerController', function ($scope, ngDialog, $log, SearchHelperService, uiGridConstants, HttpFactory, CONSTANTS, AssignmentHelperService, CommonHelperService, $window, $location) {
      var vm = this;
      var loc = $location.url();
      $scope.myData2=[];
      if (loc === '/importManager/') {
        window.document.title = "Pre-Appeal Case Import/Petition Manager";
      }
      vm.newAppealType="A";
      var workerNumber, appUserRole, appUserIdentiifier;
      $scope.hasFilterFlag = 0;

      // workerNumber = $window.sessionStorage.getItem("workerNumber");
      // appUserRole = $window.sessionStorage.getItem("userRole");
      // appUserIdentiifier = $window.sessionStorage.getItem("userIdentiifier");


      $scope.gridOptions = {
        enableGridMenu: true,
        enableSelectAll: false,
        enableFiltering: true,
        rowHeight: 35,
        useExternalFiltering: true,
        exporterCsvFilename: 'Import_manager.csv',
        exporterOlderExcelCompatibility: true,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        paginationPageSizes: [10, 25, 50, 100],
        paginationPageSize: 25,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.WHEN_NEEDED,
        exporterSuppressColumns: ['actionsAvailable'],
        onRegisterApi: function (gridApi) {
          $scope.gridApi = gridApi;
          /* istanbul ignore next */
          $scope.gridApi.core.on.filterChanged($scope, function () {
            var grid = this.grid;
            $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
            if ($scope.numberOfFilters === 0) {
              $scope.gridOptions.data = $scope.preAppealData;

            } else {
              var waivedFilteredData = SearchHelperService.filterGridImportManager(grid, $scope.myData);
              $scope.gridOptions.data = waivedFilteredData;

            }

          });
          /* istanbul ignore next */
          $scope.gridApi.selection.on.rowSelectionChanged($scope, function (row) {
            if ($scope.gridApi.selection.getSelectAllState() && $scope.gridOptions.data.length > 1) {
              $scope.allSelected = true;


            } else {
              $scope.allSelected = false;
            }

            if (row.isSelected) {
              row.entity.disableActions = true;
            } else {
              row.entity.disableActions = false;
            }
            var selectedCount = $scope.gridApi.selection.getSelectedRows().length;
            $scope.selectedData = $scope.gridApi.selection.getSelectedRows();

            if (selectedCount >= 2) {

              $scope.greaterThantwo = true;

            } else {
              $scope.greaterThantwo = false;
            }
          });
          /* istanbul ignore next */
          $scope.gridApi.selection.on.rowSelectionChangedBatch($scope, function (row) {
            $scope.selectedData = $scope.gridApi.selection.getSelectedRows();
            $scope.performAllEnableOrDisableActions(row);


          });
        }
      };

      $scope.gridOptions2 = {
        enableGridMenu: true,
        enableSelectAll: false,
        enableFiltering: false,
        rowHeight: 35,
        
        exporterCsvFilename: 'Import_manager.csv',
        exporterOlderExcelCompatibility: true,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.WHEN_NEEDED,
        exporterSuppressColumns: ['actionsAvailable'],
        onRegisterApi: function (gridApi) {
          $scope.gridApi2 = gridApi;
          /* istanbul ignore next */
          $scope.gridApi2.core.on.filterChanged($scope, function () {
            var grid = this.grid;
            $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
            if ($scope.numberOfFilters === 0) {
              $scope.gridOptions.data = $scope.preAppealData;

            } else {
              var waivedFilteredData = SearchHelperService.filterGridImportManager(grid, $scope.myData);
              $scope.gridOptions.data = waivedFilteredData;

            }

          });
          /* istanbul ignore next */
          $scope.gridApi.selection.on.rowSelectionChanged($scope, function (row) {
            if ($scope.gridApi.selection.getSelectAllState() && $scope.gridOptions.data.length > 1) {
              $scope.allSelected = true;


            } else {
              $scope.allSelected = false;
            }

            if (row.isSelected) {
              row.entity.disableActions = true;
            } else {
              row.entity.disableActions = false;
            }
            var selectedCount = $scope.gridApi.selection.getSelectedRows().length;
            $scope.selectedData = $scope.gridApi.selection.getSelectedRows();

            if (selectedCount >= 2) {

              $scope.greaterThantwo = true;

            } else {
              $scope.greaterThantwo = false;
            }
          });
          /* istanbul ignore next */
          $scope.gridApi.selection.on.rowSelectionChangedBatch($scope, function (row) {
            $scope.selectedData = $scope.gridApi.selection.getSelectedRows();
            $scope.performAllEnableOrDisableActions(row);


          });
        }
      };





      $scope.copyToClipBoard = function (value) {
        $scope.copiedNumber = value;

        var input = document.createElement('input');
        input.setAttribute('value', value);
        document.body.appendChild(input);
        input.select();
        var result = document.execCommand('copy');
        document.body.removeChild(input);
        return result;

      };

      vm.loadImportManager = function (userInfo) {
        /* istanbul ignore if */


        workerNumber = userInfo.appUserInfo[0].loginId;
        appUserRole = userInfo.appUserInfo[0].roleDescription;
        appUserIdentiifier = userInfo.appUserInfo[0].userIdentiifier;
        $window.sessionStorage.setItem("userIdentiifier", appUserIdentiifier);
        vm.user = userInfo.appUserInfo[0];
        vm.userInfo = {
          userId: userInfo.appUserInfo[0].loginId,
          displayName: userInfo.appUserInfo[0].fullName
        };



        // if (workerNumber || appUserRole || appUserIdentiifier) {
        //   if ($window.parent != null) {
        //     workerNumber = $window.opener.userInfo.userId;
        //     appUserRole = $window.opener.userInfo.appUserInfo.roleDescription;
        //     appUserIdentiifier = $window.opener.userInfo.appUserInfo.userIdentiifier;
        //     $window.sessionStorage.setItem("workerNumber", workerNumber);
        //     $window.sessionStorage.setItem("userRole", appUserRole);
        //     $window.sessionStorage.setItem("userIdentiifier", appUserIdentiifier);
        //   } else {
        //     workerNumber = $window.sessionStorage.getItem("workerNumber");
        //     appUserRole = $window.sessionStorage.getItem("userRole");
        //     appUserIdentiifier = $window.sessionStorage.getItem("userIdentiifier");
        //   }
        // }
        vm.workerNumber = workerNumber;

        $scope.preAppealData = [];
        $scope.appealAssignmentData = [];
        $scope.tasksAvailable = [];



        /* istanbul ignore next */
        $scope.performAllEnableOrDisableActions = function (allRows) {

          if ($scope.gridApi.selection.getSelectAllState()) {
            $scope.allSelected = true;
            $scope.greaterThantwo = false;

          } else {
            var selectedCount = $scope.gridApi.selection.getSelectedRows().length;
            $scope.allSelected = false;
            if (selectedCount >= 2) {

              $scope.greaterThantwo = true;

            } else {
              $scope.greaterThantwo = false;
            }
          }

          angular.forEach(allRows, function (row) {

            row.entity.disableActions = $scope.allSelected;

          });


        };
        $scope.isLoading = true;
        $scope.showFilters = false;

        $scope.getCall = function () {
          var data = {
            'userIdentifier': vm.workerNumber
          };

          $scope.importedPreAppealData(data);
        };



        $scope.importedPreAppealData = function (data, number) {
          $scope.loaded = true;
          $scope.enableloading = true;
          $scope.refreashFaild = false;

          return HttpFactory.postActions(CONSTANTS.URL.IMPORTMANAGER, data)
            .then(function (successResponse) {
                $scope.enableloading = false;
                $scope.refreashFaild = false;
                $scope.dateValid = false;
                $scope.refreshDate = new Date();
                loadImporedGridData(successResponse);

                $scope.isLoading = false;
                angular.element(document.getElementsByClassName('grid')).scope().isLoading = false;
              },
              /* istanbul ignore next */
              function (failureResponse) {
                $scope.isLoading = false;
                $log.info(failureResponse);
                if (failureResponse.status === 404) {
                  $scope.enableloading = false;
                  $scope.refreashFaild = false;
                  $scope.dateValid = false;
                  $scope.refreshDate = new Date();
                  CommonHelperService.setToastr("", "clear");
                  CommonHelperService.setToastr(CONSTANTS.TOASTER.noCasesQualified, "info", 30000, 30000);
                } else {
                  $scope.refreashFaild = true;
                  $scope.refreashFailDate = new Date();
                  $scope.enableloading = false;
                  if (angular.isUndefined($scope.refreshDate) || $scope.refreshDate === null) {
                    $scope.dateValid = true;
                  }
                  CommonHelperService.setToastr("", "clear");
                  CommonHelperService.setToastr(CONSTANTS.TOASTER.failedLoad, "error", 30000, 30000);
                }
              });

        };

        function loadImporedGridData(successResponse) {
          $scope.gridOptions.data = {};
          $scope.gridOptions.columnDefs = [];
          $scope.myData = successResponse.data;
          processResponse();
        }

        function processResponse() {
          $scope.tasksAvailable = $scope.myData.tasks;
          $scope.preAppealData = [];
          $scope.appealAssignmentData = [];
          for (var j = 0; j < $scope.myData.caseDetailsData.length; j++) {
            $scope.myData.caseDetailsData[j].preAppealInfo.assignmentData = $scope.myData.caseDetailsData[j].appealAssignment;
            $scope.myData.caseDetailsData[j].preAppealInfo.assignmentData.preAppealLockControlNo = $scope.myData.caseDetailsData[j].preAppeal.audit.lockControlNumber;
            $scope.preAppealData.push($scope.myData.caseDetailsData[j].preAppealInfo);
            $scope.appealAssignmentData.push($scope.myData.caseDetailsData[j].appealAssignment);
          }
          var preAppealColDefs = [];
          // var hasFilterFlag = 0;
          processColumnDetails(preAppealColDefs);
          /* istanbul ignore if */
          // var tempData = {};
          if ($scope.hasFilterFlag > 0) {

            $scope.numberOfFilters = $scope.hasFilterFlag;
            // var filteredData = SearchHelperService.filterTableForImportManager($scope.myData, preAppealColDefs);
            // $scope.gridOptions.data = filteredData;
            $scope.gridOptions.data = SearchHelperService.filterTableForImportManager($scope.myData, preAppealColDefs);
          } else {
            $scope.numberOfFilters = 0;
            // $scope.gridOptions.data = $scope.preAppealData;
            $scope.gridOptions.data = $scope.preAppealData;
          }

          $scope.gridOptions.columnDefs = preAppealColDefs;
          // $scope.gridOptions.data = dataProcessPreAppeal($scope.preAppealData, $scope.myData.columnDetails);
          // $scope.gridOptions.data = dataProcessPreAppeal(tempData, $scope.myData.columnDetails);

          $scope.appealAssignment = $scope.appealAssignmentData;
        }

        function processResponse2(data) {
      //    $scope.tasksAvailable = $scope.myData.tasks;
          $scope.preAppealData2 = [];
          $scope.appealAssignmentData2 = [];
           for (var j = 0; j < $scope.myData2.caseDetailsData.length; j++) {
            $scope.myData2.caseDetailsData[j].preAppealInfo.assignmentData = $scope.myData2.caseDetailsData[j].appealAssignment;
         //   $scope.myData2.caseDetailsData[j].preAppealInfo.assignmentData.preAppealLockControlNo = $scope.myData2.caseDetailsData[j].preAppeal.audit.lockControlNumber;
            $scope.preAppealData2.push($scope.myData2.caseDetailsData[j].preAppealInfo);
            $scope.appealAssignmentData2.push($scope.myData2.caseDetailsData[j].appealAssignment);
            checkForMergeCase();
          }
          $scope.gridOptions2.data = $scope.preAppealData2;
          var preAppealColDefs = [];

          processColumnDetails2(preAppealColDefs)
          $scope.gridOptions2.columnDefs=preAppealColDefs;
          angular.forEach($scope.gridOptions2.columnDefs, function(column) {
            if (column.field==='appealNumber') {
              column.visible=true;
              column.cellTemplate="<div ng-if=\"row.entity.appealNumber!=='0'\" style=\"margin-left:5px;\" class=\"ui-grid-cell-contents\" ng-bind-html=\"row.entity.appealNumber\"></div>" + 
              "<div ng-if=\"row.entity.appealNumber==='0'\" style=\margin-left:5px;\" class=\"ui-grid-cell-contents\">&mdash;</div>";
            }
          });
        }

        function checkForMergeCase() {
          var rowNumber=0;
          var appealNumbers = $scope.appealAssignmentData2[0].appealNumbersForMergedCase;
          appealNumbers = removeAppealNumber(appealNumbers, "99");
          if (appealNumbers.length==0) {
            $scope.preAppealData2[0].appealNumber="0";
            return;
          }
          if (appealNumbers.length>0) {
            removeAppealNumber(appealNumbers, "0");
          } else {
            $scope.preAppealData2[0].appealNumber="0";
            return;
          }
          angular.forEach(appealNumbers, function(appealNumber) {
            if (appealNumber=="0" && appealNumbers.length===1) {
              $scope.preAppealData2[0].appealNumber="0";
            } else if (rowNumber===0) { 
              $scope.preAppealData2[0].appealNumber=appealNumber;
            } else {
              var newRow = angular.copy($scope.preAppealData2[0]);
              newRow.appealNumber = appealNumber;
              $scope.preAppealData2.push(newRow);
            }
            rowNumber++;
          });
        }

        function removeAppealNumber(appealNums, numberToRemove) {
          var returnNumbers=[];
          angular.forEach(appealNums, function(appNum) {
            if (appNum.indexOf(numberToRemove)===0) {
            } else {
                returnNumbers.push(appNum);
            } 
          });
          return returnNumbers;
        }

        function processColumnDetails(preAppealColDefs) {
          for (var i = 0; i < $scope.myData.columnDetails.length; i++) {
            var preAppealCol = {};
            if ($scope.myData.columnDetails[i].typeDefinition === "Date") {
              preAppealCol.type = 'date';
              preAppealCol.cellFilter = 'date:"MM/dd/yyyy"';

            } else {
              preAppealCol.type = 'string';
            }
            preAppealCol.displayName = $scope.myData.columnDetails[i].label;
            preAppealCol.headerTooltip = $scope.myData.columnDetails[i].label;
            preAppealCol.field = $scope.myData.columnDetails[i].name;
            preAppealCol.showItems = $scope.myData.columnDetails[i].selected;
            preAppealCol.leftPin = $scope.myData.columnDetails[i].pinToLeft;
            preAppealCol.rightPin = $scope.myData.columnDetails[i].pinToRight;
            if ($scope.myData.columnDetails[i].cellTemplate != null && $scope.myData.columnDetails[i].cellTemplate !== undefined) {
              preAppealCol.cellTemplate = $scope.myData.columnDetails[i].cellTemplate;
            }
            if ($scope.myData.columnDetails[i].sort) {

              preAppealCol.sort = {
                direction: $scope.myData.columnDetails[i].sort
              };
            }
            if ($scope.myData.columnDetails[i].filter) {
              preAppealCol.filters = [{
                term: $scope.myData.columnDetails[i].filter
              }];
              $scope.hasFilterFlag++;
            } else {
              preAppealCol.filters = [{}];
            }
            preAppealCol.width = 140;

            processPreAppealColumns(preAppealCol);
            processManualImportColumn(preAppealCol);

            preAppealColDefs.push(preAppealCol);
          }
        }

        function processManualImportColumn(preAppealCol) {
          if (preAppealCol.field === "promote") {
            preAppealCol.cellClass = manualColorApply;
          }
        }
        /* istanbul ignore next */
        function manualColorApply(grid, row, col, rowIndex, colIndex) {
          var color = '';
          var val = grid.getCellValue(row, col);
          if (val === 'Manual Import') {
            color = 'blue';
          }
          return color;
        }

        function processPreAppealColumns(preAppealCol) {
          if (preAppealCol.showItems === true) {
            preAppealCol.visible = true;
          } else {
            preAppealCol.visible = false;
          }

          if (preAppealCol.leftPin === true) {
            preAppealCol.pinnedLeft = true;
          }

          if (preAppealCol.rightPin === true) {
            preAppealCol.pinnedRight = true;
          }

          if (preAppealCol.field === "serialNumber") {
            preAppealCol.enableHiding = false;
            preAppealCol.width = 140;
            preAppealCol.cellTemplate = 'app/importManager/dropDown.html';

          }
          if (preAppealCol.field === "dav") {

            preAppealCol.cellTemplate =

              '<div style="cursor: pointer; padding-top:5px">' +
              '<a href="https://www.uspto.gov/" target="_blank" class="davName" id="{{COL_FIELD}}" >' +
              "<u>{{COL_FIELD}}</u>" + '</a>' +
              '</div>';
          }

          if (preAppealCol.field === "task") {
            preAppealCol.enableFiltering = false;
            preAppealCol.enableColumnMenu = false;
            preAppealCol.enableHiding = false;
            preAppealCol.width = 105;
            preAppealCol.cellClass = 'action-drop-down-grid';
            preAppealCol.cellTemplate = 'app/importManager/preAppealActionDropDown.html';
          }
        }

        vm.setAppealType = function (appType) {
    //      toggleFiltering();
      //    $scope.gridApi.grid.clearAllFilters();
     
        };

         function importPetition () {
          var initiateInfo = {};
          initiateInfo.applicationNumber = vm.importedCaseNumber;
          initiateInfo.user=vm.user;
          ngDialog.open({
            template: 'app/caseViewer/initiatePetitionRequest.modal.html',
            controller: 'InitiatePetitionRequestController',
            controllerAs: 'vm',
            showClose: false,
            width:"80%",
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              caseInfo: function () {
                return initiateInfo;
              }
            }
          }).closePromise.then(function (results) {
            if (results.value) {
              vm.interruptInProcess = true;
            }
          });
        }
  

        function toggleFiltering(){
          $scope.gridOptions.enableFiltering = !$scope.gridOptions.enableFiltering;
          $scope.gridApi.core.notifyDataChange( uiGridConstants.dataChange.COLUMN );
        }

        function dataProcessPreAppeal(preAppealData, preAppealColumns) {
          var index = 0;
          var importOnlyPreAppealData = [];
          preAppealData.forEach(function (row) {
            // if (row.assigneeFullName) {
            // if (row.assigneeFullName.includes("Import")) {
            if (row.manualImportIndicator) {
              vm.selectedRow = index;
            }
            index++;
            preAppealColumns.forEach(function (preAppealColumn) {
              dataProcessBooleanValues(row, preAppealColumn);
              dataProcessDeliveryMode(row, preAppealColumn);
            });
            importOnlyPreAppealData.push(row);
            // }
            // }
          });

          return importOnlyPreAppealData;
          // return preAppealData;
        }

        function dataProcessBooleanValues(row, preAppealColumn) {
          if (preAppealColumn.typeDefinition === 'Boolean') {

            if (row[preAppealColumn.name] === true) {
              row[preAppealColumn.name] = row[preAppealColumn.name] ? 'Yes' : null;
            }
            if (row[preAppealColumn.name] === false) {
              row[preAppealColumn.name] = row[preAppealColumn.name] ? null : 'No';
            }
          }

        }

        function dataProcessDeliveryMode(row, preAppealColumn) {
          if (preAppealColumn.name === 'deliveryMode') {

            if (row[preAppealColumn.name] === "MAIL") {
              row[preAppealColumn.name] = row[preAppealColumn.name] ? 'PAPER' : null;
            }
            if (row[preAppealColumn.name] === "EMAIL") {
              row[preAppealColumn.name] = row[preAppealColumn.name] ? 'ELECTRONIC' : null;
            }
          }
        }


        $scope.toggleFilteringImport = function () {
          $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
          $scope.gridApi.grid.clearAllFilters();
          $scope.gridOptions.data = $scope.preAppealData;
          $scope.numberOfFilters = 0;
        };

        $scope.showFilteringPreAppeal = function () {
          ngDialog.open({
            template: 'app/components/helperComponents/filterHelp/filteringHelp.html',
            controller: 'CommonDialogController',
            controllerAs: 'vm',
            showClose: false
          }).then(function () {
            // Model for display only.  Ok button clicked.
          }, function () {
            // X button clicked on modal
          });
        };



        function processColumnDetails2(preAppealColDefs) {
          for (var i = 0; i < $scope.myData2.columnDetails.length; i++) {
            var preAppealCol = {};
            if ($scope.myData2.columnDetails[i].typeDefinition === "Date") {
              preAppealCol.type = 'date';
              preAppealCol.cellFilter = 'date:"MM/dd/yyyy"';

            } else {
              preAppealCol.type = 'string';
            }
            preAppealCol.displayName = $scope.myData2.columnDetails[i].label;
            preAppealCol.headerTooltip = $scope.myData2.columnDetails[i].label;
            preAppealCol.field = $scope.myData2.columnDetails[i].name;
            preAppealCol.showItems = $scope.myData2.columnDetails[i].selected;
            preAppealCol.leftPin = $scope.myData2.columnDetails[i].pinToLeft;
            preAppealCol.rightPin = $scope.myData2.columnDetails[i].pinToRight;
            if ($scope.myData2.columnDetails[i].cellTemplate != null && $scope.myData2.columnDetails[i].cellTemplate !== undefined) {
              preAppealCol.cellTemplate = $scope.myData2.columnDetails[i].cellTemplate;
            }
            
            preAppealCol.width = 140;

            processPreAppealColumns(preAppealCol);
            processManualImportColumn(preAppealCol);

            preAppealColDefs.push(preAppealCol);
          }
        }

        /* istanbul ignore next */
        $scope.importNewCase = function () {
          if (vm.newAppealType==='P') {
            importPetition();
            return;
          }
          HttpFactory.getActions(CONSTANTS.URL.IMPORT_VALIDATE_NNUMBER + vm.importedCaseNumber)
            .then(function (successResponse) {
              $scope.statusNumber = successResponse.data.statusNumber;
              $scope.importData = {
                "statusNumber": $scope.statusNumber,
                "caseNumber": vm.importedCaseNumber
              };
              if (angular.isDefined(vm.importedCaseNumber) && !isNaN(vm.importedCaseNumber)) {

                ngDialog.open({
                  template: 'app/importManager/importNewCase.html',
                  controller: 'ImportNewCaseController',
                  controllerAs: 'vm',
                  width: '31%',
                  showClose: false,
                  closeByEscape: false,
                  closeByDocument: false,
                  resolve: {
                    userInfo: function () {
                      return $scope.importData;
                    }
                  }
                }).closePromise.then(function (applicationId) {
                  if (angular.isDefined(applicationId.value.caseNumber)) {
                    $scope.addToImportManagerData(applicationId.value.caseNumber);
                  }
                }, function () {
                  // Cancel button clicked
                });
              }
            }, function (failureResponse) {
              $scope.isLoading = false;
              CommonHelperService.setToastr(failureResponse.data.message, "error");
            });

        };

        $scope.pressEnter = function (event) {
          if (event.keyCode === 13) {
            $scope.importNewCase();
          }
        };

        $scope.addToImportManagerData = function (number) {
          $scope.isLoading = true;
          var data = {
            'applicationNumber': number,
            'userIdentifier': vm.workerNumber
          };
          vm.importedCaseNumber = "";
          /* istanbul ignore next */
          $scope.importedPreAppealData(data, number).then(function () {
            CommonHelperService.setToastr("The case " + number + " was imported.", "success");
          });
        };

        $scope.warningBeforePromote = function (row) {
          ngDialog.open({
            template: 'app/importManager/warningBeforePromote.html',
            controller: 'WarningBeforePromoteController',
            width: '40%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              promoteToAppealWarning: function () {
                return row;
              }
            }
          }).closePromise.then(function (promoteToAppealWarning) {
            $scope.showPromoteTypes(promoteToAppealWarning.value);
          }, function () {
            // Cancel button clicked
          });
        };

        /* istanbul ignore next */
        $scope.showPromoteTypes = function (row) {
          ngDialog.open({
            template: 'app/importManager/promoteTypesSelect.html',
            controller: 'PromoteTypesSelectController',
            width: '48%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              showPromoteTypesValues: function () {
                return row;
              }
            }
          }).closePromise.then(function (showPromoteTypesValues) {
            $scope.openPromoteToAppeal(showPromoteTypesValues.value);
          }, function () {
            // Cancel button clicked.  No action needed.
          });
        };

        $scope.openPromoteToAppeal = function (row) {
          $scope.getRole();
          $scope.promoteData = row;
          $scope.promoteData.workerNumber = vm.workerNumber;
          ngDialog.close();
          ngDialog.open({
            template: 'app/importManager/promoteToAppeal.html',
            controller: 'PromoteToAppealController',
            width: '60%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            scope: $scope,
            resolve: {
              promoteToAppeal: function () {
                return $scope.promoteData;
              },
              appUserInfo: function () {
                return appUserRole;
              },
              appUserIdentiifier: function () {
                return appUserIdentiifier;
              }
            }
          });
        };

        $scope.openCaseViewer = function (number) {
          $window.userInfo = {
            userId: $window.sessionStorage.getItem("workerNumber")
          };
          $window.open("#/caseViewer/" + number + "/0");
        };



        /* istanbul ignore next */
        $scope.reject = function (rejectData) {
          vm.orgignalText = rejectData.notes;
          ngDialog.open({
            template: 'app/importManager/reject.html',
            controller: 'RejectController',
            controllerAs: 'vm',
            width: '42%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              rejectData: function () {
                return rejectData;
              }
            }

          }).closePromise.then(function (rejectData) {
            vm.noteToSave = rejectData.value.notes;
            angular.element(document.getElementById('rejectNotes')).scope().vm.rejectData.notes = vm.orgignalText;
            if (angular.isDefined(rejectData.value.serialNumber)) {
              $scope.rejectImportManagerData(rejectData.value);
            }
          }, function () {
            // Cancel button clicked
          });
        };

        $scope.rejectImportManagerData = function (rejectData) {
          $scope.isLoading = true;
          var rejectObject = {
            "serialNumber": rejectData.serialNumber,
            "sequenceNumber": rejectData.sequenceNumber,
            "notes": vm.noteToSave,
            "assignmentIdentifier": rejectData.assignmentIdentifier,
            "audit": {
              "createUserIdentifier": rejectData.audit.createUserIdentifier,
              "lastModifiedUserIdentifier": vm.workerNumber,
              "lockControlNumber": rejectData.preAppealLockControlNo
            }
          };
          /* istanbul ignore next */
          HttpFactory.putActions(CONSTANTS.URL.IMPORT_REJECT, rejectObject)
            .then(function (successResponse) {
              var dataAfterReject = {
                'userIdentifier': vm.workerNumber
              };

              $scope.importedPreAppealData(dataAfterReject).then(function () {
                CommonHelperService.setToastr("The case " + rejectObject.serialNumber + " was successfully rejected.", "success");
              });

            }, function (failureResponse) {
              $log.info(failureResponse);
              $scope.isLoading = false;
              CommonHelperService.setToastr(failureResponse.data.message, "error");

            });
        };

        $scope.deleteAppeal = function (deleteNumber) {
          ngDialog.open({
            template: 'app/importManager/delete.html',
            controller: 'DeleteController',
            controllerAs: 'vm',
            width: '42%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              deleteData: function () {
                return deleteNumber;
              }
            }
          }).closePromise.then(function (applicationId) {
            if (angular.isDefined(applicationId.value)) {
              $scope.deleteImportManagerData(applicationId.value);
            }
          }, function () {
            // Cancel button clicked
          });
        };

        $scope.deleteImportManagerData = function (number) {
          $scope.isLoading = true;
          $scope.number = number;
          $scope.workerNumber = vm.workerNumber;
          /* istanbul ignore next */
          HttpFactory.deleteActions(CONSTANTS.URL.IMPORT_DELETE + 'applicationNumberText=' + $scope.number + '&userIdentifier=' + $scope.workerNumber)
            .then(function (successResponse) {
              var dataAfterDelete = {
                'userIdentifier': vm.workerNumber
              };

              $scope.importedPreAppealData(dataAfterDelete).then(function () {
                CommonHelperService.setToastr("The case " + $scope.number + " was successfully deleted.", "success");
              });

            }, function (failureResponse) {
              $log.info(failureResponse);
              $scope.isLoading = false;
              CommonHelperService.setToastr(failureResponse.data.message, "error");

            });
        };

        /* istanbul ignore next */
        $scope.bulkAssignmnet = function (number, row) {
          $scope.type = [];
          $scope.getRole();
          if (row) {
            $scope.type.push(row.entity);
          }
          if ($scope.type.length != 0) {
            $scope.selectedData = $scope.type;
          } else {
            $scope.selectedData = $scope.gridApi.selection.getSelectedRows();
          }
          $scope.selectedData.myRole = $scope.myRole;
          //$scope.selectedData[0].assignmentData.priorityIndicator = $scope.selectedData[0].assignmentData.priorityIndicator === 'Y' ? true : false;
          if ($scope.selectedData.length >= 1 || number) {
            ngDialog.open({
              template: 'app/importManager/importReassignModal.html',
              controller: 'BulkAssignController',
              controllerAs: 'vm',
              width: '60%',
              showClose: false,
              closeByEscape: false,
              closeByDocument: false,
              scope: $scope,
              resolve: {
                preAppeal: function () {
                  return $scope.selectedData;
                },
                userId: function () {
                  return $window.sessionStorage.getItem("workerNumber");
                }
              }
            }).closePromise.then(function (responseData) {
              var successResponse = responseData.value;
              $scope.assignmentsData = successResponse.data;
              var verb = " assignments have ";
              if ($scope.selectedData.length - $scope.assignmentsData.length === 1) {
                verb = " assignment has ";
              }

              if ($scope.assignmentsData.length === 0) {
                CommonHelperService.setToastr($scope.selectedData.length + verb + " been successfully reassigned.", "success");
              } else if ($scope.selectedData.length === $scope.assignmentsData.length) {
                CommonHelperService.setToastr(CONSTANTS.TOASTER.reassignFail, "error");
                return;
              } else {
                CommonHelperService.setToastr($scope.selectedData.length - $scope.assignmentsData.length + verb +
                  "been successfully reassigned.  " + $scope.assignmentsData.length + " assignment(s) failed to be reassigned.", "warning");
              }

              vm.failedReassignments = angular.copy($scope.assignmentsData);
              $scope.refreshData();
              $scope.$$childTail.$$prevSibling.searchText = undefined;
            }, function () {
              // Cancel clicked
            });
          } else {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.selectRow, "error");
          }
        };

        $scope.refreshData = function () {


          $scope.isLoading = true;
          var data = {
            'userIdentifier': vm.workerNumber
          };
          return $scope.importedPreAppealData(data);

        };

        $scope.currentAssignee = {
          name: 'Not assigned',
          activeCases: '',
          assigneeStatus: ''
        };

        $scope.change = function (content) {
          $scope.currentAssignee.name = content.name;
          $scope.currentAssignee.activeCases = content.activeCases;
          $scope.currentAssignee.assigneeStatus = content.assigneeStatus;
          $scope.currentAssignee.beNo = content.beNo;
        };

        $scope.myUserRole = function (selectedRole, selectedUser) {
          $scope.myRoleForImport = selectedRole;
          $scope.getAssignedToForImport = function () {
            HttpFactory.getActions(CONSTANTS.URL.ASSIGNEDTO + "roleCode=" + $scope.myRoleForImport)
              .then(function (successResponse) {
                  $scope.myAssigne = successResponse.data;
                  $scope.currentSelectedRole = selectedRole;
                  $scope.foundAssigne = false;
                  angular.forEach($scope.myAssigne.assignees, function (item) {
                    if (item.beNo === selectedUser) {
                      $scope.foundAssigne = true;
                      $scope.currentAssignee = {
                        name: item.name,
                        activeCases: item.activeCases,
                        assigneeStatus: item.assigneeStatus,
                        beNo: selectedUser
                      };
                    }



                  });
                  $scope.scrollDisable = false;
                  if (!$scope.foundAssigne) {
                    $scope.currentAssignee = {
                      name: 'Not assigned',
                      activeCases: '',
                      assigneeStatus: '',
                      beNo: ""
                    };
                  }
                  $scope.change($scope.currentAssignee);
                },
                function (failureResponse) {
                  $scope.currentAssignee = {
                    name: 'Not assigned',
                    activeCases: '',
                    assigneeStatus: '',
                    beNo: ""
                  };
                  $scope.myAssigne = {};
                  $scope.scrollDisable = true;
                  $log.info(failureResponse);
                });
          };

          $scope.getAssignedToForImport();
        };

        $scope.getRole = function () {
          HttpFactory.getActions(CONSTANTS.URL.ROLETYPE)
            .then(function (successResponse) {
                $scope.myRole = successResponse.data;
              },
              function (failureResponse) {
                $log.info(failureResponse);
              });
        };

        $scope.getRole();

        $scope.getAllReassignBulkData = function (data, currentAssigneeBeNo, modifiedItem) {

          var reAssignDataArray = [];

          data.forEach(function (item) {
            item.dueDate = (new Date(modifiedItem.dueDate).getTime() / 1000) * 1000;
            var reAssignObject = {

              "assignmentType": item.assignmentData.assignmentType,
              "assignee": currentAssigneeBeNo,
              "serialNumber": item.assignmentData.serialNumber,
              "title": item.assignmentData.title,
              "description": item.assignmentData.description,
              "dueDate": item.dueDate,
              "completionDate": item.assignmentData.completionDate,
              "caseType": item.assignmentData.caseType,
              "appealNumber": item.assignmentData.appealNumber,
              "sequenceNumber": item.assignmentData.sequenceNumber,
              "notes": modifiedItem.notes,
              "assigneeRoleCode": item.assignmentData.assigneeRoleCode,
              "priorityIndicator": (modifiedItem.priorityIndicator) ? 'Y' : 'N',
              "assignmentIdentifier": item.assignmentData.assignmentIdentifier,
              "assignor": item.assignmentData.assignor,
              "activeIndicator": item.assignmentData.activeIndicator,
              "audit": {
                "createUserIdentifier": item.assignmentData.audit.createUserIdentifier,
                "lastModifiedUserIdentifier": vm.workerNumber,
                "lockControlNumber": item.assignmentData.audit.lockControlNumber,
                "createTimestamp": item.assignmentData.audit.createTimestamp,
                "lastModifiedTimestamp": new Date().getTime()

              }

            };
            reAssignDataArray.push(reAssignObject);
          });

          angular.element(document.getElementsByClassName('grid')).scope().isLoading = true;
          /* istanbul ignore next */
          HttpFactory.putActions(CONSTANTS.URL.IMPORT_BULK_REASSIGN, reAssignDataArray)
            .then(function (successResponse) {
              $scope.refreshData().then(function () {
                CommonHelperService.setToastr(CONSTANTS.TOASTER.casesReassign, "success");
              });

            }, function (failureResponse) {
              $log.info(failureResponse);
              angular.element(document.getElementsByClassName('grid')).scope().isLoading = false;

              if (failureResponse.status === 404 || failureResponse.status === 500) {
                CommonHelperService.setToastr(CONSTANTS.TOASTER.casesReassignFail, "error");
              }

            });
        };


        // $scope.copyToClipBoard = function (value) {
        //   $scope.copiedNumber = value;

        //   var input = document.createElement('input');
        //   input.setAttribute('value', value);
        //   document.body.appendChild(input);
        //   input.select();
        //   var result = document.execCommand('copy');
        //   document.body.removeChild(input)
        //   return result;

        // }

        $scope.updatePromteData = function () {

          var data = {
            'userIdentifier': vm.workerNumber
          };

          return $scope.importedPreAppealData(data);
        };

        $scope.getExternalUrls = function () {
          HttpFactory.getActions(CONSTANTS.URL.EXTERNALURLS)
            .then(function (successResponse) {
              $scope.externalUrls = [];
              for (var key in successResponse.data) {
                if (key !== "Open in PTOZone" && key !== "ptabReadOnlyUser" && key !== "allowedResourceObjectList" && key !== "ptabDueDateNonEditableUser" && key !== "ptabDefaultRefreshTime") {
                  var url = {
                    description: key,
                    url: successResponse.data[key]
                  };
                  $scope.externalUrls.push(url);
                }
              }

            }, function () {
              // Empty response is ok
            });
        };
        $scope.getExternalUrls();

        $scope.getCall();

        window.onbeforeunload = closingCode;
        /* istanbul ignore next */
        function closingCode() {
          vm.workerNumber = $window.sessionStorage.removeItem("workerNumber");
        }
      };

    });

})();
