(function () {
  "use strict";

  angular
    .module('ptabe2e')
    .controller('PromoteTypesSelectController', function ($scope, ngDialog, showPromoteTypesValues, HttpFactory, CONSTANTS) {
      $scope.serialNumber = showPromoteTypesValues.serialNumber;
      showPromoteTypesValues.appealNumber = "0";

      $scope.fromWorkQueue = showPromoteTypesValues.fromWorkQueue;

      function closeDialog(popupsToClose, data) {

        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose], data);
        } else {
          ngDialog.close(data);
        }
      }

      /* istanbul ignore next */
      $scope.confirmPromoteOptions = function (firstAppeal, promoteValue) {
        if (promoteValue === 'System generated appeal number with this application') {
          clearRadioButton();
          showPromoteTypesValues.appealNumber = "0";
          if ($scope.fromWorkQueue) {
            closeDialog(1, showPromoteTypesValues);
          } else {
            ngDialog.closeAll(showPromoteTypesValues);
          }
        }

        if (!$scope.showAppealNumber && promoteValue === 'Enter other appeal number' && showPromoteTypesValues.appealNumber !== "0") {
          clearRadioButton();
          if ($scope.fromWorkQueue) {
            closeDialog(1, showPromoteTypesValues);
          } else {
            ngDialog.closeAll(showPromoteTypesValues);
          }

        } else {
          $scope.errorMessage = "Not a valid appeal #";
        }
      };

      $scope.cancelPromoteOptions = function () {
        clearRadioButton();
        closeDialog(1);
        // ngDialog.closeAll();
      };

      $scope.existingAppealNumbers = false;

      $scope.enterAppeal = false;
      $scope.getValue = function () {
        $scope.enterAppeal = true;
        $scope.existingAppealNumbers = false;
      };

      $scope.getSystemValue = function () {
        $scope.enterAppeal = false;
        $scope.existingAppealNumbers = false;
        $scope.errorMessage = "";
      };

      $scope.pressEnterToCheckAppeal = function (event, appeal) {
        if (event.keyCode === 13) {
          $scope.enterAppealNumber(appeal);
        }
      };

      $scope.enterAppealNumber = function (appeal) {

        HttpFactory.getActions(CONSTANTS.URL.IMPORT_ENTER_APPEAL + appeal)
          .then(function (successResponse) {
            showPromoteTypesValues.appealNumber = appeal;
            $scope.showAppealNumber = false;

          }, function (failureResponse) {
            $scope.showAppealNumber = true;
            $scope.errorMessage = "Not a valid appeal #";

          });
      };


      function clearRadioButton() {
        document.getElementById('promoteRadioButton').checked = false;
      }
    });
})();
