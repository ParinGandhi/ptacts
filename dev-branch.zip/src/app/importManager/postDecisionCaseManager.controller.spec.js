(function () {
  'use strict';

  describe('PostDecisionCaseManagerController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open']);
    var controller, scope, $rootScope;
    var timeout, userInfo;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;

    var refreshGrid = {
      value: "data"
    }


    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);

      // ngDialog.open.and.returnValue({
      //   then: function (callback3, callback4) {
      //     callback3();
      //     callback4();
      //   }
      // });


      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback1) {
            callback1(refreshGrid);
            // callback2();
          }
        },
        then: function (callback3, callback4) {
          callback3();
          callback4();
        }
      });

      userInfo = {
        "userId": "sbartlett",
        "displayName": "Bartlett, Steven J",
        "appUserInfo": [{
          "userIdentiifier": 5850,
          "activeIn": "Active",
          "lastName": "Bartlett",
          "privileges": ["ImportManager_PostDecisionCaseManager Privileges", "panel_Update", "Paneling"],
          "loginId": "sbartlett",
          "fullName": "Bartlett, Steven J",
          "disiplanceCd": "Admin",
          "jobClassificationCode": "ADM",
          "firstName": "Steven",
          "emailAddress": "Jacqueline.Bui@USPTO.GOV",
          "userWorkerNumber": "83707",
          "roleDescription": "Business Administrator",
          "apjSeniorityRank": 0
        }]
      }

      controller = $controller('PostDecisionCaseManagerController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory,
        userInfo: userInfo

      });
    }));

    describe('PostDecisionCaseManagerController ', function () {


      it('it should call gridOPtions', function () {

        var gridApi = {
          core: {
            on: {
              filterChanged: function ($scope, callback) {}
            }
          }
        };
        expect(scope.gridOptions).toBeDefined();
        expect(scope.gridOptions.onRegisterApi).toBeDefined();
        scope.gridOptions.onRegisterApi(gridApi);
        expect(scope.gridApi).toBe(gridApi);
        scope.gridApi.core.on.filterChanged();

      });


      it('should call loadPostDecisionManager', function () {

        // var userInfo = {
        //   "userId": "sbartlett",
        //   "displayName": "Bartlett, Steven J",
        //   "appUserInfo": [{
        //     "userIdentiifier": 5850,
        //     "activeIn": "Active",
        //     "lastName": "Bartlett",
        //     "privileges": ["ImportManager_PostDecisionCaseManager Privileges", "panel_Update", "Paneling"],
        //     "loginId": "sbartlett",
        //     "fullName": "Bartlett, Steven J",
        //     "disiplanceCd": "Admin",
        //     "jobClassificationCode": "ADM",
        //     "firstName": "Steven",
        //     "emailAddress": "Jacqueline.Bui@USPTO.GOV",
        //     "userWorkerNumber": "83707",
        //     "roleDescription": "Business Administrator",
        //     "apjSeniorityRank": 0
        //   }]
        // }

        expect(controller.loadPostDecisionManager).toBeDefined();
        controller.loadPostDecisionManager(userInfo);

      });

      it('should call optionCase', function () {
        expect(controller.optionCase).toBeDefined();
        controller.optionCase();
      });

      it('should call optionApplication ', function () {
        expect(controller.optionApplication ).toBeDefined();
        controller.optionApplication ();
      });

      it('should call clearDocument', function () {
        expect(scope.clearDocument).toBeDefined();
        scope.clearDocument();
      });

      it('should call checkSearchInfo', function () {
        var searchThis = "";
        controller.searchThis = "";
        expect(scope.checkSearchInfo).toBeDefined();
        scope.checkSearchInfo();
      });

      it('should call checkSearchInfo', function () {
        var searchThis = "134";
        expect(scope.checkSearchInfo).toBeDefined();
        scope.checkSearchInfo();
      });

      it('should call getPostDecisionData', function () {
        // expect(scope.getPostDecisionData).toBeDefined();
       // scope.getPostDecisionData();
      });
      
      it('should call getPostDecisionDataForSpecificCase', function () {
        // expect(scope.getPostDecisionData).toBeDefined();
       // scope.getPostDecisionData();
      });

      //  it('Should call optionAll', function () {
      //   spyOn(scope, 'getPostDecisionData');
      //   // expect(scope['getPostDecisionData']).toBeDefined();
      //   expect(controller['optionAll']).toBeDefined();
      //   controller.optionAll();
      //   expect(scope.getPostDecisionData).toHaveBeenCalled();
      // });

      // it('should call getPostDecisionData', function () {
      //   var userInfo = {
      //     "userId": "sbartlett",
      //     "displayName": "Bartlett, Steven J",
      //     "appUserInfo": [{
      //       "userIdentiifier": 5850,
      //       "activeIn": "Active",
      //       "lastName": "Bartlett",
      //       "privileges": ["ImportManager_PostDecisionCaseManager Privileges", "panel_Update", "Paneling"],
      //       "loginId": "sbartlett",
      //       "fullName": "Bartlett, Steven J",
      //       "disiplanceCd": "Admin",
      //       "jobClassificationCode": "ADM",
      //       "firstName": "Steven",
      //       "emailAddress": "Jacqueline.Bui@USPTO.GOV",
      //       "userWorkerNumber": "83707",
      //       "roleDescription": "Business Administrator",
      //       "apjSeniorityRank": 0
      //     }]
      //   }

      //   successResponse = {
      //     "allowedResourceObjectList": ["panel_Update"],
      //     "ptabReadOnlyUser": false,
      //     "caseDetailsData": [{
      //       "serialNumber": "90004524",
      //       "courtDecision": null,
      //       "originalDecision": null,
      //       "patentNumber": null,
      //       "appealDate": 956894400000,
      //       "appellant": null,
      //       "judgeNameThree": null,
      //       "originalDecisionDate": null,
      //       "rehearingDecision": null,
      //       "judgeNameTwo": null,
      //       "appealNumber": 2000001022,
      //       "judgeNameOne": null,
      //       "rehearingDate": null,
      //       "patentAttorney": null,
      //       "applicationTypeCategory": null,
      //       "statusCode": null,
      //       "courtDecisionDate": null
      //     }, {
      //       "serialNumber": "09661773",
      //       "courtDecision": null,
      //       "originalDecision": null,
      //       "patentNumber": null,
      //       "appealDate": 1081742400000,
      //       "appellant": null,
      //       "judgeNameThree": null,
      //       "originalDecisionDate": null,
      //       "rehearingDecision": null,
      //       "judgeNameTwo": null,
      //       "appealNumber": 2004001405,
      //       "judgeNameOne": null,
      //       "rehearingDate": null,
      //       "patentAttorney": null,
      //       "applicationTypeCategory": null,
      //       "statusCode": null,
      //       "courtDecisionDate": null
      //     }],
      //     "actions": [{
      //       "valueText": "CRR",
      //       "descriptionText": "Create/update rehearing request"
      //     }, {
      //       "valueText": "CSD",
      //       "descriptionText": "Create subsequent decision"
      //     }]
      //   }

      //   // expect(controller.loadPostDecisionManager).toBeDefined();
      //   controller.loadPostDecisionManager(userInfo);

      //   expect(scope.getPostDecisionData).toBeDefined();
      //   // scope.getPostDecisionData(true);
      //   HttpFactoryDeferred.resolve(successResponse);
      //   scope.$digest;

      // });

      it('it should call getPostDecisionData and return successResponse', function () {

        successResponse = {
          data: {
            "allowedResourceObjectList": ["panel_Update"],
            "ptabReadOnlyUser": false,
            "columnDetails": [],
            "caseDetailsData": [{
              "serialNumber": "90004524",
              "courtDecision": null,
              "originalDecision": null,
              "patentNumber": null,
              "appealDate": 956894400000,
              "appellant": null,
              "judgeNameThree": null,
              "originalDecisionDate": null,
              "rehearingDecision": null,
              "judgeNameTwo": null,
              "appealNumber": 2000001022,
              "judgeNameOne": null,
              "rehearingDate": null,
              "patentAttorney": null,
              "applicationTypeCategory": null,
              "statusCode": null,
              "courtDecisionDate": null
            }, {
              "serialNumber": "09661773",
              "courtDecision": null,
              "originalDecision": null,
              "patentNumber": null,
              "appealDate": 1081742400000,
              "appellant": null,
              "judgeNameThree": null,
              "originalDecisionDate": null,
              "rehearingDecision": null,
              "judgeNameTwo": null,
              "appealNumber": 2004001405,
              "judgeNameOne": null,
              "rehearingDate": null,
              "patentAttorney": null,
              "applicationTypeCategory": null,
              "statusCode": null,
              "courtDecisionDate": null
            }],
            "actions": [{
              "valueText": "CRR",
              "descriptionText": "Create/update rehearing request"
            }, {
              "valueText": "CSD",
              "descriptionText": "Create subsequent decision"
            }]
          }
        }



        expect(controller.loadPostDecisionManager).toBeDefined();
        controller.loadPostDecisionManager(userInfo);

        expect(scope['getPostDecisionData']).toBeDefined();
        scope.getPostDecisionData(false);
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();

      });


      it('it should call getPostDecisionData and return failureResponse', function () {

        failureResponse = {
          data: {
            message: "Failure"
          }
        }

        // var userInfo = {
        //   "userId": "sbartlett",
        //   "displayName": "Bartlett, Steven J",
        //   "appUserInfo": [{
        //     "userIdentiifier": 5850,
        //     "activeIn": "Active",
        //     "lastName": "Bartlett",
        //     "privileges": ["ImportManager_PostDecisionCaseManager Privileges", "panel_Update", "Paneling"],
        //     "loginId": "sbartlett",
        //     "fullName": "Bartlett, Steven J",
        //     "disiplanceCd": "Admin",
        //     "jobClassificationCode": "ADM",
        //     "firstName": "Steven",
        //     "emailAddress": "Jacqueline.Bui@USPTO.GOV",
        //     "userWorkerNumber": "83707",
        //     "roleDescription": "Business Administrator",
        //     "apjSeniorityRank": 0
        //   }]
        // }

        expect(controller.loadPostDecisionManager).toBeDefined();
        controller.loadPostDecisionManager(userInfo);

        expect(scope['getPostDecisionData']).toBeDefined();
        scope.getPostDecisionData(false);
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();

      });

      it('it should open showFilteringHelp ', function () {

        var existingCount = ngDialog.open.calls.count();
        controller.loadPostDecisionManager(userInfo);
        expect(scope.showFilteringHelp).toBeDefined();
        scope.showFilteringHelp();
        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(existingCount + 1);
        var args = ngDialog.open.calls.argsFor(existingCount);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('CommonDialogController');
      });

      //TODO - fix test case
      it('it should call checkAction with actionValueCode as CRS', function () {

        controller.loadPostDecisionManager(userInfo);
        var row = "CRS";
        var actionValueCode = "CRS";
        expect(scope['checkAction']).toBeDefined();
        scope.checkAction(row, actionValueCode);

        // actionValueCode="CRR";
        // scope.gridApi = {
        //   selection: {
        //     getSelectedRows: function () {

        //     }
        //   }
        // }
        // scope.checkAction(row, actionValueCode);

        // var row, actionValueCode="CSD";
        // scope.checkAction(row, actionValueCode);

        // var row, actionValueCode = "ERR";
        // scope.checkAction(row, actionValueCode);

        // var row, actionValueCode = "PDO";
        // scope.checkAction(row, actionValueCode);

        // var row, actionValueCode = "TEST";
        // scope.checkAction(row, actionValueCode);
      });

      // it('it should call checkAction with actionValueCode as CRR', function () {

      //   controller.loadPostDecisionManager(userInfo);
      //   var row = "CRR";
      //   var actionValueCode = "CRR";
      //   expect(scope['checkAction']).toBeDefined();
      //   scope.checkAction(row, actionValueCode);

      // });

      // it('it should call checkAction with actionValueCode as CSD', function () {

      //   controller.loadPostDecisionManager(userInfo);
      //   var row, actionValueCode = "CSD";
      //   expect(scope['checkAction']).toBeDefined();
      //   scope.checkAction(row, actionValueCode);

      // });

      it('it should call checkAction with actionValueCode as ERR', function () {

        controller.loadPostDecisionManager(userInfo);
        var row, actionValueCode = "ERR";
        expect(scope['checkAction']).toBeDefined();
        scope.checkAction(row, actionValueCode);

      });

      it('it should call checkAction with actionValueCode as PDO', function () {

        controller.loadPostDecisionManager(userInfo);
        var row, actionValueCode = "PDO";
        expect(scope['checkAction']).toBeDefined();
        scope.checkAction(row, actionValueCode);

      });

      it('it should call checkAction with actionValueCode as empty', function () {

        controller.loadPostDecisionManager(userInfo);
        var row, actionValueCode = "";
        expect(scope['checkAction']).toBeDefined();
        scope.checkAction(row, actionValueCode);

      });


      it('it should call createRehearingAssignment and return success', function () {
        scope.mySelectedRows = [{
          serialNumber: "2019001020",
          appealNumber: "09002010"
        }]

        var decsisionsSuccessResponse = {
          data: {
            decisions: []
          }
        }

        controller.loadPostDecisionManager(userInfo);
        expect(scope['createRehearingAssignment']).toBeDefined();
        scope.createRehearingAssignment();
        HttpFactoryDeferred.resolve(decsisionsSuccessResponse);
        scope.$digest();
        expect(ngDialog.open).toHaveBeenCalled();

      });




      it('it should call createSubsequentDecision ', function () {
        var row = {
          entity: {
            assignmentIdentifier: 5768,
            appealNumber: 2019002010
          }
        }
        scope.userInfo = {
          userId: "sbartlett"
        }
        controller.loadPostDecisionManager(userInfo);
        expect(scope['createSubsequentDecision']).toBeDefined();
        scope.createSubsequentDecision(row);
      });


      it('it should call openCaseViewer ', function () {
        var row = {
          entity: {
            assignmentIdentifier: 5768,
            appealNumber: 2019002010
          }
        }

        controller.loadPostDecisionManager(userInfo);
        expect(scope['openCaseViewer']).toBeDefined();
        scope.openCaseViewer(row);
      });




      it('it should call getAssignmentById and return failure', function () {

        var ptabID = '64';
        var assignmentByIdFailureResponse = {
          data: {
            message: "Failed"
          }

        };

        controller.loadPostDecisionManager(userInfo);
        expect(scope.getAssignmentById).toBeDefined();
        scope.getAssignmentById(ptabID);
        HttpFactoryDeferred.reject(assignmentByIdFailureResponse);
        $rootScope.$apply();

      });


      it('it should call getAssignmentById and return success', function () {

        var ptabID = '64';

        var assignmentByIdSuccessResponse = {
          data: {
            caseDetailsData: [{

            }]
          }

        };

        controller.loadPostDecisionManager(userInfo);
        expect(scope.getAssignmentById).toBeDefined();
        scope.isUpdateRehearing = true;
        scope.getAssignmentById(ptabID);
        HttpFactoryDeferred.resolve(assignmentByIdSuccessResponse);
        $rootScope.$apply();

      });

      //TODO - fix test case
      // it('it should call createRehearingAssignment ', function () {
      //   successResponse = {
      //     data: {}

      //   };

      //   // expect(scope.createRehearingAssignment).toBeDefined();
      //   // scope.createRehearingAssignment();
      //   // HttpFactoryDeferred.resolve(successResponse);
      //   // $rootScope.$apply();

      // });

    });
  });
})();
