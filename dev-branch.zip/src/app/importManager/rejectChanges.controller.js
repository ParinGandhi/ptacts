(function () {
  "use strict";

  angular
    .module('ptabe2e')
    .controller('RejectChangesController', function (ngDialog, rejectData, originalRejectData) {
      var vm = this;

      vm.rejectchanges = function () {
        rejectData.notes = originalRejectData.notes;
        ngDialog.closeAll();

      };

      function closeRejectDialog(popupsToClose) {


        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose]);
        } else {
          ngDialog.close();
        }
      }


      vm.closeCurrentDialog = function () {
        closeRejectDialog(1);
      };
    });
})();
