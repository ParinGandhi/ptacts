(function () {
  'use strict';

  describe('ImportNewCaseController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll']);
    var userInfo;
    var controller;

    // importData = {
    //   'caseNumber': 06000006,
    //   'statusNumber': 150,
    // }
    // controller.caseNumber = 06000006;
    // controller.statusNumber = 150;
    beforeEach(inject(function (_$controller_) {
      $controller = _$controller_;


      controller = $controller('ImportNewCaseController', {
        ngDialog: ngDialog,
        userInfo: userInfo
      });
    }));

    describe('ImportNewCaseController ', function () {


      it('it should call cancelImportNumber ', function () {

        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['cancelImportNumber']).toBeDefined();
        controller.cancelImportNumber();
        expect(ngDialog.closeAll).toHaveBeenCalledWith();

      });

      it('it should call importNumber ', function () {

        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['importNumber']).toBeDefined();
        controller.importNumber();
        expect(ngDialog.closeAll).toHaveBeenCalledWith(userInfo);

      });


    });
  });
})();
