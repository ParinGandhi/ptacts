(function () {
  'use strict';

  describe('BulkAssignController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close', 'open']);
    var preAppeal;
    var controller, scope, $rootScope, userId;
    var successResponse;
    var HttpFactoryDeferred;

    preAppeal = [{
      "assignmentIdentifier": 1589,
      "assignmentType": "DNMA",
      "assignmentTypeDescription": "0",
      "activeIndicator": "A",
      "assignedDate": "1532530402",
      "completionDate": "1532530402",
      "pendingLocationText": "Pending",
      "assignee": "5768",
      "serialNumber": "14368609",
      "sequenceNumber": "0",
      "reconsiderSequenceNo": "0",
      "palmMailedDate": "1532530402",
      "assignmentNo": "0",
      "title": "Import manager default title",
      "description": "Import manager default description",
      "assignor": "fhan",
      "dueDate": "1532530402",
      "assignmentStatusCode": "C",
      "caseType": "APPEAL",
      "creatorUserId": null,
      "createTs": "1532530402",
      "completerNumber": null,
      "proceedingCoreIdentifier": null,
      "proceedingSupIdentifier": null,
      "notes": "Test Appeal create Note",
      "preExistentIdentifier": null,
      "priorityIndicator": "N",
      "assignmentData": {
        "dueDate": 15000002568,
        "assigneeRoleCode": "5768"
      }
    }]

    beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_, _$q_, HttpFactory, userId) {
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);

      controller = $controller('BulkAssignController', {
        $scope: scope,
        ngDialog: ngDialog,
        userId:userId,
        $rootScope: _$rootScope_,
        preAppeal: preAppeal,
        HttpFactory: HttpFactory

      });
    }));

    describe('BulkAssignController ', function () {

      // it('it should call myUserRoleForBulk ', function () {
      //   var selectedRole = "PTABE2E_Administrator";
      //   var selectedUser = "5778";

      //   expect(controller['myUserRoleForBulk']).toBeDefined();
      //   successResponse = [{
      //     "assigneeNumberText ": "5778",
      //     "assigneeFullNameText": "Baker, Patrick",
      //     "activeCaseCount": "6",
      //     "assigneeStatus": "Active",
      //     "role": null,
      //     "description": null
      //   }, {
      //     "assigneeNumberText ": "1810",
      //     "assigneeFullNameText": "Bartlett, Steven",
      //     "activeCaseCount": "0",
      //     "assigneeStatus": "Active",
      //     "role": null,
      //     "description": null
      //   }, {
      //     "assigneeNumberText ": "26",
      //     "assigneeFullNameText": "Brock, Alan",
      //     "activeCaseCount": "0",
      //     "assigneeStatus": "InActive",
      //     "role": null,
      //     "description": null
      //   }, {
      //     "assigneeNumberText ": "5779",
      //     "assigneeFullNameText": "Bui, Jacqueline",
      //     "activeCaseCount": "3",
      //     "assigneeStatus": "Active",
      //     "role": null,
      //     "description": null
      //   }]


      //   successResponse = {
      //     data: [{
      //       "assigneeNumberText ": "5778",
      //       "assigneeFullNameText": "Baker, Patrick",
      //       "activeCaseCount": "6",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "assigneeNumberText ": "5778",
      //       "assigneeFullNameText": "Bui, Jacqueline",
      //       "activeCaseCount": "3",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }]
      //   }

      //   controller.myUserRoleForBulk(selectedRole, selectedUser);
      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();

      // });

      // it('it should call myUserRoleForBulk found assignee false ', function () {
      //   var selectedRole = "PTABE2E_Administrator";
      //   var selectedUser = "5768";

      //   expect(controller['myUserRoleForBulk']).toBeDefined();
      //   successResponse = [{
      //     "assigneeNumberText ": "5778",
      //     "assigneeFullNameText": "Baker, Patrick",
      //     "activeCaseCount": "6",
      //     "assigneeStatus": "Active",
      //     "role": null,
      //     "description": null
      //   }, {
      //     "assigneeNumberText ": "1810",
      //     "assigneeFullNameText": "Bartlett, Steven",
      //     "activeCaseCount": "0",
      //     "assigneeStatus": "Active",
      //     "role": null,
      //     "description": null
      //   }, {
      //     "assigneeNumberText ": "26",
      //     "assigneeFullNameText": "Brock, Alan",
      //     "activeCaseCount": "0",
      //     "assigneeStatus": "InActive",
      //     "role": null,
      //     "description": null
      //   }, {
      //     "assigneeNumberText ": "5779",
      //     "assigneeFullNameText": "Bui, Jacqueline",
      //     "activeCaseCount": "3",
      //     "assigneeStatus": "Active",
      //     "role": null,
      //     "description": null
      //   }]


      //   successResponse = {
      //     data: [{
      //       "assigneeNumberText ": "5768",
      //       "assigneeFullNameText": "Baker, Patrick",
      //       "activeCaseCount": "6",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }, {
      //       "assigneeNumberText ": "5768",
      //       "assigneeFullNameText": "Bui, Jacqueline",
      //       "activeCaseCount": "3",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }]
      //   }

      //   controller.myUserRoleForBulk(selectedRole, selectedUser);
      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();

      // });

      // it('get Actions failureResponse ', function () {
      //   var selectedRole = "PTABE2E_Administrator";
      //   var selectedUser = "5768";
      //   var failureResponse = {
      //     "message": "assignees not found "
      //   }
      //   controller.myUserRoleForBulk(selectedRole, selectedUser);
      //   HttpFactoryDeferred.reject(failureResponse);
      //   $rootScope.$apply();
      // });

      // it('it should call saveBulkReassign  ', function () {

      //   scope.readyToSaveDate = false;
      //   spyOn(scope, 'checkDueDateBulkResassign');
      //   expect(scope['checkDueDateBulkResassign']).toBeDefined();
      //   expect(controller['saveBulkReassign']).toBeDefined();
      //   controller.saveBulkReassign();
      //   expect(scope.checkDueDateBulkResassign).toHaveBeenCalled();
      // });

      // it('it should call saveBulkReassign  ', function () {
      //   // controller.selectedBulkData = {
      //   //   currentAssigneeBeNo: "5768"
      //   // }
      //   controller.currentAssignee = {
      //     beNo : "5768"
      //   }
      //   scope.readyToSaveDate = true;
      //   expect(controller['saveBulkReassign']).toBeDefined();
      //   controller.saveBulkReassign();
      // });

      // it('it should call bulkReassign   ', function () {

      //   scope.readyToSaveDate === false
      //   spyOn(scope, 'checkDueDateBulkResassign');
      //   expect(scope['checkDueDateBulkResassign']).toBeDefined();
      //   expect(controller['bulkReassign']).toBeDefined();
      //   controller.bulkReassign();
      //   expect(scope.checkDueDateBulkResassign).toHaveBeenCalled();
      // });

      // it('it should call bulkReassign  ', function () {

      //   controller.currentAssignee = {
      //     beNo: "5768"
      //   }
      //   scope.readyToSaveDate = true;
      //   expect(ngDialog.closeAll).toBeDefined();
      //   expect(controller['bulkReassign']).toBeDefined();
      //   controller.bulkReassign();
      //   expect(ngDialog.closeAll).toHaveBeenCalledWith(preAppeal);
      // });

      // it('it should call cancelBulkAssign if block', function () {

      //   controller.isSaved = false;
      //   controller.BulkData = {};
      //   controller.currentAssignee = "pgandhi";
      //   controller.originalBulkcurrentAssignee = "mmylar";
      //   expect(controller['cancelBulkAssign']).toBeDefined();
      //   // expect(ngDialog.open).toBeDefined();
      //   controller.cancelBulkAssign();
      //   // expect(ngDialog.open).toHaveBeenCalledWith();

      //   expect(ngDialog.open).toHaveBeenCalled();

      //   expect(ngDialog.open.calls.count()).toBe(1);
      //   var args = ngDialog.open.calls.argsFor(0);
      //   expect(args).not.toBe(null);
      //   expect(args.length).toBe(1);

      //   expect(args[0].controller).toBe('BulkUnSavedChangesController');
      //   expect(typeof args[0].resolve).toBe('object');
      //   args[0].resolve.BulkData();
      //   args[0].resolve.originalBulkReassignData();
      //   args[0].resolve.currentAssignee();
      //   args[0].resolve.originalBulkcurrentAssignee();
      // });

      // it('it should call cancelBulkAssign else block', function () {

      //   expect(controller['cancelBulkAssign']).toBeDefined();
      //   expect(ngDialog.closeAll).toBeDefined();
      //   controller.cancelBulkAssign();
      //   expect(ngDialog.closeAll).toHaveBeenCalledWith();
      // });

      // it('it should call checkDueDateBulkResassign  ', function () {

      //   controller.selectedBulkData = [{
      //     "assignmentData": {
      //       "dueDate": undefined,
      //       "assigneeRoleCode": "5768"
      //     }

      //   }]

      //   expect(scope['checkDueDateBulkResassign']).toBeDefined();
      //   scope.checkDueDateBulkResassign();
      // });

      // it('it should call checkDueDateBulkResassign  ', function () {

      //   controller.selectedBulkData = [{
      //     "assignmentData": {
      //       "dueDate": 15000002568,
      //       "assigneeRoleCode": "5768"
      //     }

      //   }]

      //   expect(scope['checkDueDateBulkResassign']).toBeDefined();
      //   scope.checkDueDateBulkResassign();
      // });

    });
  });
})();
