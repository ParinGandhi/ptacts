(function () {
  'use strict';

  describe('RejectController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open']);
    var rejectData, originalRejectData;
    var controller, scope, $rootScope;
    var timeout;

    rejectData = {
      "serialNumber": "150"
    }
    beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_) {
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      timeout = _$timeout_;


      controller = $controller('RejectController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        rejectData: rejectData,
      });
    }));

    describe('RejectController ', function () {


      it('it should call cancelReject else block ', function () {

        controller.rejectData = "0600006";
        controller.originalRejectData = "mmylar";

        expect(controller['cancelReject']).toBeDefined();
        controller.cancelReject();

        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(1);
        var args = ngDialog.open.calls.argsFor(0);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('RejectChangesController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.rejectData();
        args[0].resolve.originalRejectData();

      });


      // it('it should call cancelReject ', function () {

      //   expect(ngDialog.closeAll).toBeDefined();
      //   expect(controller['cancelReject']).toBeDefined();
      //   controller.cancelReject();
      //   expect(ngDialog.closeAll).toHaveBeenCalledWith();

      // });

      it('it should call rejectNumber ', function () {

        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['rejectNumber']).toBeDefined();
        controller.rejectNumber();
        expect(ngDialog.closeAll).toHaveBeenCalledWith(rejectData);

      });


    });
  });
})();
