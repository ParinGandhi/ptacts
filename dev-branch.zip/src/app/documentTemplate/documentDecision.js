(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .directive('fileModel', ['$parse', function ($parse) {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var model = $parse(attrs.fileModel);
          var modelSetter = model.assign;

          element.bind('change', function () {
            scope.$apply(function () {
              modelSetter(scope, element[0].files[0]);
            });
          });
        }
      };
    }])

    .controller('documentDecisionController', function (ngDialog, $timeout, $scope, $window, CommonHelperService, HttpFactory, $log, CONSTANTS, $http, toastr, $sce, $rootScope, $filter) {
      var vm = this;
      $window.document.title = "P-TACTS - Decision capture";
      $scope.fileExtractContent = [];
      $scope.listOfFileNames = [];
      $scope.fileContent = [];
      $scope.oldDataExtracted =false;
     vm.revalidate =false;
     $scope.statusJ = {};
     $scope.statusJ.open=true;
     $scope.statusY = {};
     $scope.statusY.open=false;
     $scope.upload = 'uploadNew';
      $scope.footerEditValue =false;
      vm.startOver=false;
  try {
  
      $scope.caseNum = $rootScope.sharedItems[0].serialNumber;
      $scope.appealNumber = $rootScope.sharedItems[0].appealNumber;
      $scope.assignmentTypeForRtf = $rootScope.sharedItems[0].assignmentType;
      } catch(error) {
      }
      $scope.rtfBaseLink = CONSTANTS.URL.BASE;
      $scope.showVerifyDecision = true;
      var clFile;
      var reader = new FileReader();
      var fileByteArray = [];

    /* istanbul ignore next*/
    vm.loadDocumentTemplateData = function () {
      vm.userId = $window.sessionStorage.getItem("workerNumber");
      vm.getLoggedInUserName ();
    };

   /** Function to get the logged in user name */
   vm.getLoggedInUserName =function() {
    HttpFactory.getActions(CONSTANTS.URL.USERMANAGEMENT + "?loginId=" + vm.userId)
      .then(function (userNameSuccess) {
        vm.loggedInUser = userNameSuccess.data.caseDetailsData[0].fullName.trim();
      }, function (userNameFailure) {
        console.info("Failed to retrieve user name", userNameFailure);
        return null;
      });
  }

      /* istanbul ignore next */
    $scope.getFileInfo = function () {
      clFile = document.getElementById("fileVerifyDecisionNew");
      $scope.fileInfo = {};
      $scope.fileInfo.name = clFile.files[0].name;
      $scope.fileExtractContent.push(clFile.files[0]);
      $scope.verifiedDocument = {};
      $scope.verifiedDocument.fileName  = $scope.fileInfo.name;
      $scope.docLink =  $scope.verifiedDocument.fileName;
      $scope.fileInfo.path = clFile.value;
      reader.readAsArrayBuffer(clFile.files[0]);
      reader.onloadend = function (evt) {
        if (evt.target.readyState === FileReader.DONE) {
          var arrayBuffer = evt.target.result,
            array = new Uint8Array(arrayBuffer);
          for (var i = 0; i < array.length; i++) {
            fileByteArray.push(array[i]);
          }
        }
      };
    };

    vm.buildEmptyRejection = function() {
      var arejection = $scope.rejections[0];
      vm.rejectionAdd = angular.copy(arejection);
      console.log("ok");
    }
 
    $scope.clearDocument = function() {
      vm.rejectionAdd = {};
      vm.addClaim=false;
     vm.capturedDate = null;
      $scope.cancelEditCaseNumber();
      vm.startOver=true;
      $scope.closeWindowClicked = false;
      if(vm.editedInformation) {
      $scope.openUnsavedChanges();}
      else{
      $scope.footerEdit = null;
      vm.revalidate =false;
      $scope.rejectionEdit=null;
      $scope.verifiedDocument = null;
      $scope.extracted=false;
      $scope.fileExtractContent = [];
      vm.editedInformation = false;
        $scope.rejections = [];
        $scope.exceptionsLength = 0;
        $scope.outcome = null;
        $scope.caseNumberFromDoc = null;
        $scope.referenceNotes =[];
        $scope.displayedException = [];
        $scope.statusJ.open=true;
      }
    };

    $scope.cancelRejectionClaim = function(rejection) {
      rejection.editMode=false;
      $scope.rejectionEdit=null;
      if( vm.editedInformation)
 {      $scope.saveEnabled = false;
 } else if(!vm.editedInformation && $scope.oldDataExtracted){
  $scope.saveEnabled = false;
 } else {
  $scope.saveEnabled = true;
 }
    };

    vm.hideAlert= function(){
      $scope.showMessage = false;
      $scope.infoForCaseNumber = null;
    }

    vm.hideRetrieveMsg= function(){
      vm.messageForRetrival=null;
      vm.searchThis = null;
    }
    vm.saveInformationCall = function(responseObject){
      $scope.otherException=[];
     HttpFactory.postActions(CONSTANTS.URL.SAVE_DECISION_SUMMARY, responseObject
    )
    .then(function (successResponse) {
      vm.editedInformation = false;
      $scope.response = successResponse.data;
      $scope.clearDocument();
      $scope.showMessage = true;
      vm.editedInformation = false;
      $timeout(vm.hideAlert, 8000);
    }, function (failureResponse) {
      $scope.saveEnabled = true;
      vm.editedInformation = false;
      toastr.error(failureResponse.data.message, {
        iconClass: 'toast-danger'
      });
    });
    }

    vm.saveInfo = function() {    
      $scope.showVerifyDecision = false;
      var rejectionss = [];
      for (var i = 0; i <  $scope.rejections.length; i++) {
        rejectionss.push($scope.rejections[i]);
      }
      console.log(  rejectionss);
      if($scope.outcome != null) {
      rejectionss.push($scope.outcome); }
      $scope.infoForCaseNumber = angular.copy($scope.caseNumberFromDoc);
      $scope.decisionBelongsTo.supplementalIdentifier =  angular.copy($scope.caseNumberFromDoc);
      var responseObject =  {
        "proceedingCoreId": $scope.applicationNum,
        "proceedingSupplementaryId":$scope.caseNumberFromDoc,
        "proceedingType": $scope.typeOfCase,
        "descriptionTx": null,
        "totalGrounds":$scope.totalGround ,
        "extractedContent": {
        "decisionBelongsTo": $scope.decisionBelongsTo ,
         "referenceNotes": $scope.referenceNotes,
         "decisionSummary": $scope.decisionSummary,
         "groundsTable": rejectionss,
         "validationrules": $scope.validationRules,
         "panel":$scope.originalPanel
        },
        "audit": { 
          "createUserIdentifier": vm.userId,
          "lastModifiedUserIdentifier": vm.userId,
          "lastModifiedTimestamp": new Date().getTime(),
          "lastModifiedUserName":vm.loggedInUser,
          "lockControlNumber": null
        }
      };

      if (vm.capturedDate) {
        responseObject.audit.createTimestamp = vm.capturedDate;
        responseObject.audit.createUserIdentifier = vm.originalUser;
      } else {
        responseObject.audit.createTimestamp = new Date().getTime();
      }
      

      if (vm.exception || ($scope.otherException && $scope.otherException.length>0)) {
        ngDialog.openConfirm({ 
          template: "app/components/widgets/assignments/src/exceptionErrorModal.html",
          scope: $scope,
          width: '30%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false
            })
          .then(function () {
            // console.log("Yes");
            vm.saveInformationCall(responseObject);
            $scope.rejectionEdit = false; 
            vm.revalidate =false;
            // vm.editedInformation = false;

          }, function () {
            $scope.rejectionEdit = false; 
           vm.revalidate =true;
           $scope.saveEnabled =true;
           vm.editedInformation = true;
          });
      }
         else{
          vm.saveInformationCall(responseObject);
          $scope.rejectionEdit = false; 
         vm.revalidate =false;
        //  vm.editedInformation = false;
         $scope.saveEnabled =false;
         }
    };

    vm.closeTab = function(){
      $window.close();
     }



     function checkFootnotes() {
       $scope.otherException = [];
       angular.forEach($scope.rejections, function(item) {
        var  footnoteValue = getFootnoteScreenValue(item.statuteValue);
        checkAndAddException(footnoteValue);
        footnoteValue = getFootnoteScreenValue(item.referencesBasisValue);
        checkAndAddException(footnoteValue);
       });
     }

     function infootnoteCollection(footnoteValue) {
       if (!$scope.referenceNotes || $scope.referenceNotes.length===0) {
         return false;
       }
       var found=false;
       angular.forEach($scope.referenceNotes, function(footnote) {
        if (footnote.identifier===footnoteValue) {
          found=true;
        }
       });
       return found;
     }
     function checkAndAddException(footnoteValue) {
      if (footnoteValue && !infootnoteCollection(footnoteValue)) {
        var exceptionText = "Footnote:" + footnoteValue + " is not in the Footnote list section.  Please click Add footnote."
        var footnoteException = {
          description:exceptionText
        };
        $scope.otherException.push(footnoteException);
        
      }
     }
      vm.revalidateTable = function () {
        var ruleList = [];
        var rejectionss = [];
        for (var i = 0; i < $scope.rejections.length; i++) {
          rejectionss.push($scope.rejections[i]);
        }

        if ($scope.outcome != null) {
          rejectionss.push($scope.outcome);
        }
        var responseObject = {
          "decisionBelongsTo": $scope.decisionBelongsTo,
          "decisionSummary": $scope.decisionSummary,
          "groundsTable": rejectionss,
          "referenceNotes": $scope.referenceNotes,
          "totalGrounds": $scope.totalGround,
          "validationrules": $scope.validationRules
        };
        HttpFactory.putActions(CONSTANTS.URL.DECISION_SUMMARY_REVALIDATE, responseObject)
          .then(function (successResponse) {
            checkFootnotes();
            $scope.saveEnabled = true;
            $scope.PostDataResponse = successResponse.data;
            $scope.rejections = [];
            var rejection = successResponse.data;
            $scope.decisionBelongsTo = rejection.decisionBelongsTo;
            $scope.referenceNotes = rejection.referenceNotes;
            $scope.decisionSummary = rejection.decisionSummary;
            $scope.totalGround = rejection.totalGrounds;
            $scope.caseNumberFromDoc = rejection.decisionBelongsTo.supplementalIdentifier;
            $scope.applicationNum = rejection.decisionBelongsTo.coreIdentifier;
            $scope.typeOfCase = rejection.decisionBelongsTo.supplementalIdentifierType;
            //       getPanelString(rejection.panelNames);
            //       $scope.originalPanel=rejection.panelNames;

            for (var i = 0; i < rejection.groundsTable.length; i++) {

              try {

                var errors = getError(rejection.groundsTable[i].appliedRules);
                if (errors.length > 0) {
                  var columnNumber = parseInt(errors[0]);
                  if (columnNumber > 0) {
                    columnNumber++;
                  }
                  setClaimsError($scope.typeOfCase, rejection.groundsTable[i].claimInformation, errors[1], columnNumber);
                  //   rejection.groundsTable[i].claimInformation[coumnNum-1].error=errors[1];
                }
   //   rejection.groundsTable[i].claimInformation[0].error=getError( rejection.groundsTable[i].appliedRules, 2);
   //   rejection.groundsTable[i].claimInformation[1].error=getError( rejection.groundsTable[i].appliedRules, 3);
   //   rejection.groundsTable[i].claimInformation[2].error=getError( rejection.groundsTable[i].appliedRules, 4);
   //   if ( rejection.groundsTable[i].claimInformation[0].error.length>0 ||  rejection.groundsTable[i].claimInformation[1].error.length>0 ||  rejection.groundsTable[i].claimInformation[2].error.length>0) {
    //    rejection.groundsTable[i].rowError=true;
  //    }
/*            if (rejection.groundsTable[i].appliedRules.length>0  && (rejection.groundsTable[i].claimInformation[0].error.length===0 && 
      rejection.groundsTable[i].claimInformation[1].error.length===0 && rejection.groundsTable[i].claimInformation[1].error.length===0)) {
        rejection.groundsTable[i].rowError=true;
      }
*/          } catch (error) {
                // Intentionally left blank
              }




              rejection.groundsTable[i].statuteValue = getStatuteSaved(rejection.groundsTable[i]);
              rejection.groundsTable[i].referencesBasisValue = getReferenceBasis(rejection.groundsTable[i]);
              $scope.rejections.push(rejection.groundsTable[i]);
              if (rejection.groundsTable[i].appliedRules != null && rejection.groundsTable[i].appliedRules.length > 0) { //&& (i < rejection.groundsTable.length-1  || rejection.groundsTable.length == 1)
                var exceptionRuleApplied = rejection.groundsTable[i].appliedRules;
                ruleList.push(exceptionRuleApplied);
              }
            };
            $scope.validationRules = successResponse.data.validationrules;
            angular.forEach($scope.validationRules, function (rule) {
              if (rule.identifier == 'cciv:2') {
                $scope.cciv2ErrorDescription = rule.description;
              }
              // console.log( $scope.cciv2ErrorDescription);
            })
            $scope.exceptionsLength = ruleList.length;
            if ($scope.exceptionsLength > 0) {
              $scope.displayedException = [];
              $scope.columnErrorsdisplayedException = [];
              angular.forEach(ruleList, function (rule) {
                angular.forEach(rule, function (arule) {
                  var identifiers = arule.refIdentifier.split(",");
                  for (var i = 0; i < identifiers.length; i++) {
                    var uniqueException = CommonHelperService.checkUnique($scope.displayedException, identifiers[i]);
                    // var uniqueException = checkUnique(identifiers[i]);
                    if (!uniqueException) {
                      $scope.displayedException.push(CommonHelperService.getValidationRule($scope.validationRules, identifiers[i]));
                      // $scope.displayedException.push(getValidationRule(identifiers[i]));
                    }
                  }
                  if (arule.columnErrors != null) {
                    for (var i = 0; i < arule.columnErrors.length; i++) {
                      var columnErrors = arule.columnErrors[i];
                      var columnErrorsuniqueException = CommonHelperService.checkUniqueError($scope.columnErrorsdisplayedException, columnErrors);
                      if (!columnErrorsuniqueException) {
                        $scope.columnErrorsdisplayedException.push(columnErrors);
                      }
                    }
                  }
                });
              });
              vm.exception = true;
            } else if ($scope.otherException && $scope.otherException.length > 0) {
              vm.exception = true;
            } else {
              vm.exception = false;
            }
            $scope.allFields = angular.copy($scope.rejections);
            var lastOne = $scope.rejections.length;
            var size = lastOne - 1;
            if (size > 0) {
              $scope.outcome = $scope.allFields.pop();

              $scope.outcome.editode = false;
              $scope.rejections = $scope.allFields;
            } else {
              $scope.outcome = null;
            }
          }, function () {
            // intentional
          });
        $scope.saveEnabled = true;
        if ($scope.exceptionsLength > 0) {
          vm.exception = true;
        } else if ($scope.otherException && $scope.otherException.length > 0) {
          vm.exception = true;
        } else {
          vm.exception = false;
        }
        vm.editedInformation = true;
        vm.disableRevalidate = true;
      }

   vm.ValidateData = function() {
    vm.outcomeSummaryList = [];    
    angular.forEach($scope.rejections, function(rej) { 
      var obj = {
        "claims": null,
        "usc": null,
        "reference": null,
        "affirmed": null,
        "reversed": null,
        "newGround": null,
      }      
      obj.usc = rej.statuteAsCaptured;
      obj.reference = rej.referencesBasisValue;
      obj.newGround = rej.groundAsCaptured;
      angular.forEach(rej.claimInformation, function(ele) {
        if(ele.referenceType == "REJECTED" && ele.asCaptured) {
          obj.claims = ele.asCaptured.trim() == "" ? null : ele.asCaptured.trim();
        }
        if(ele.referenceType == "AFFIRMED" && ele.asCaptured) {
          obj.affirmed = ele.asCaptured.trim() == "" ? null : ele.asCaptured.trim();
        }
        if(ele.referenceType == "REVERSED" && ele.asCaptured) {
          obj.reversed = ele.asCaptured.trim() == "" ? null : ele.asCaptured.trim();
        }
      })
      vm.outcomeSummaryList.push(obj);
    })
    var data = {
      "audit": {
        "lastModifiedUserIdentifier": vm.userId,
        "lastModifiedTimestamp": new Date().getTime(),
        "createUserIdentifier": null,
        "createdUserName": null,
        "lastModifiedUserName": null,
        "createTimestamp": null,
        "lockControlNumber": null
      },
      "outcomeSummaryList": vm.outcomeSummaryList,
    }
    HttpFactory.postActions(CONSTANTS.URL.OverAllOutcome, data)
          .then(function (successResponse) {
            console.log(successResponse);
            angular.forEach($scope.outcome.claimInformation, function(column) {
              if (column.referenceType == 'AFFIRMED') {
                column.asCaptured = successResponse.data.affirmedOutcome;
              }
              if (column.referenceType == 'REVERSED') {
                column.asCaptured = successResponse.data.reversedOutcome;
              }
            });
            $scope.outcome.groundAsCaptured = successResponse.data.newGroundOutcome;
            vm.revalidateTable();
          })
   }   

   vm.closeWind = function(){
    vm.startOver=false;
     if (vm.editedInformation){
      $scope.openUnsavedChanges();
      $scope.closeWindowClicked = true;
     }
     else {
      vm.editedInformation = false;
      vm.closeTab();
      // vm.mustRevalidateTable = false;
     }
    }


    function getPanelString(panel) {
      $scope.panelString="";
      var apj1, pa;
      angular.forEach(panel, function(judge) {
        if (!judge.employeeName) {
          if (!$scope.panelString) {
            $scope.panelString = judge;
          } else {
            $scope.panelString += " | " + judge;
          }
         } else if (judge.rank===0) {
          pa= judge.employeeName;
        } else if (judge.rank ===1) {
          apj1= judge.employeeName;
        } else {
          $scope.panelString += " | " + judge.employeeName; 
        }
      });
      if (pa) {
        $scope.panelString = apj1 + " (" + pa + ")" + $scope.panelString;
      } else if (apj1) {
        $scope.panelString = apj1 + $scope.panelString;
      }
      
    }
    $scope.addFootnote = function() {
      $scope.addFootnoteMode = true;
      //$scope.editFootnote=true;
    };

    $scope.deleteFootnote = function(refNotes) {
      var indexToRemove=-1;
      var index=0;
      angular.forEach($scope.referenceNotes, function(item) {
        if (item.identifier===refNotes.identifier) {
          indexToRemove = index;
        }
        index++;
      });
      $scope.referenceNotes.splice(indexToRemove, 1);
      $scope.saveEnabled=true;
      checkFootnotes();
    };

    $scope.cancelAddFootnote = function() {
      $scope.addFootnoteMode = false;
      //$scope.editFootnote=false;
    };

    $scope.saveNewFootnote = function() {
      var refNote = {
        identifier:vm.addFootnoteIdentifier,
        referenceText:vm.addFootnoteReferenceText
      };
      if (!$scope.referenceNotes) {
        $scope.referenceNotes = [];
      }

      vm.addFootnoteIdentifier="";
      vm.addFootnoteReferenceText="";
      $scope.addFootnoteMode = false;
      $scope.editFootnote=false;
      $scope.referenceNotes.push(refNote);
      $scope.saveEnabled=true;
      orderFootnotes();
      checkFootnotes();
      if ($scope.exceptionsLength===0 && $scope.otherException.length===0) {
        vm.exception=false;
      }
    };

      /* istanbul ignore next */
      vm.deleteClaimRow = function (rejectionIndex) {
      ngDialog.openConfirm({ 
        template: "app/documentTemplate/confirmationRemoveRowModal.html",
        scope: $scope,
        width: '20%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false
          })
        .then(function () {
          $scope.rejections.splice(rejectionIndex, 1);
          vm.disableRevalidate = false;
          vm.editedInformation = true;
        }, function () {
          //may implement later
        });
    };

    vm.addRejectionClaim = function() {
      var newObject = angular.copy($scope.rejections[0]);
      newObject.appliedRules=[];
      newObject.coreIdentifier= $scope.typeOfCase;

      newObject.statuteAsCaptured = updateStatute(vm.rejectionAdd.statuteEditValue, vm.rejectionAdd.statuteFootnote);
      newObject.statute = newObject.statuteAsCaptured ;
      newObject.statuteValue = updateStatuteValue(vm.rejectionAdd.statuteEditValue, vm.rejectionAdd.statuteFootnote);
      newObject.referencesBasisValue = updateBasisValue(vm.rejectionAdd.referencesBasisEditValue, vm.rejectionAdd.referenceBasisFootnote);
      newObject.referencesBasis = updateBasis(vm.rejectionAdd.referencesBasisEditValue, vm.rejectionAdd.referenceBasisFootnote);
      newObject.groundAsCaptured = vm.rejectionAdd.ground;



  /*     newObject.referencesBasis=vm.rejectionAdd.referencesBasisEditValue;
      newObject.referencesBasisValue = vm.rejectionAdd.referencesBasisEditValue;
      newObject.statute = vm.rejectionAdd.statuteEditValue;
      newObject.statuteAsCaptured = vm.rejectionAdd.statuteEditValue;
      newObject.statuteValue = vm.rejectionAdd.statuteEditValue;
 */     
      newObject.claimInformation[0].asCaptured = vm.rejectionAdd.rejected;
//      newObject.claimInformation[0].referenceType="PETITIONED";

      var claim2 = {};
      newObject.claimInformation[1].asCaptured = vm.rejectionAdd.affirmed;
//      newObject.claimInformation[1].referenceType="'SHOWN_UNPATENTABLE";

      var claim3 = {};
      newObject.claimInformation[2].asCaptured = vm.rejectionAdd.reversed;
//      newObject.claimInformation[2].referenceType="'NOT_SHOWN_UNPATENTABLE";
      $scope.rejections.push(newObject);
      vm.addClaim=false;
      vm.disableRevalidate = false;
      vm.editedInformation = true;
    };

 

     /* istanbul ignore next */
    $scope.openUnsavedChanges = function () {
       ngDialog.openConfirm({ 
        template: "app/documentTemplate/confirmationModal.html",
        scope: $scope,
        width: '30%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false
          })
        .then(function () {
          console.log("Yes");
          if($scope.closeWindowClicked){
            vm.closeTab();
            $scope.footerEdit = null;
            vm.revalidate =false;
            $scope.rejectionEdit=null;
          } else {
            $scope.verifiedDocument = null;
      $scope.extracted=false;
      $scope.fileExtractContent = [];
            $scope.closeWindowClicked = false;
            vm.editedInformation = false;
            $scope.rejections = [];
            $scope.statusJ.open=true;
          }
        }, function () {
          //may implement later
        });
    };

    vm.retriveOldData = function(){
      $scope.saveEnabled = false;
      $scope.oldDataExtracted =true;
      var ruleList = [];
      vm.checkChangedSearch = angular.copy(vm.searchThis);
      vm.messageForRetrival= null;
    HttpFactory.getActions(CONSTANTS.URL.RETRIEVE_DECISION_CAPTUREED + vm.searchThis)
    .then(function (successResponse) {
      vm.capturedDate =  successResponse.data.audit.createTimestamp;
      vm.modifiedDate = successResponse.data.audit.lastModifiedTimestamp;
      vm.mailedDate = successResponse.data.palmMailedDate;
      vm.originalUser = successResponse.data.audit.createUserIdentifier;

      $scope.statusJ.open=false;
      $scope.statusY.open=true;
        $scope.saveEnabled = true;
        $scope.extracted =true;
        $scope.error =false;
        $scope.PostDataResponse = successResponse.data;  
        $scope.rejections = [];
         var rejection = $scope.PostDataResponse.extractedContent;
         angular.forEach(rejection.groundsTable, function(ele) {
          if (ele.statuteAsCaptured) {
           ele.statuteValue = ele.statute;
          } 
          if (ele.referencesBasis) {
            ele.referencesBasisValue = ele.referencesBasis;
           } 
      });
        $scope.decisionBelongsTo = rejection.decisionBelongsTo;
        $scope.referenceNotes = rejection.referenceNotes;
        orderFootnotes();
        $scope.decisionSummary = rejection.decisionSummary;
        $scope.totalGround = rejection.totalGrounds;
        $scope.caseNumberFromDoc =rejection.decisionBelongsTo.supplementalIdentifier;
        $scope.applicationNum= rejection.decisionBelongsTo.coreIdentifier;
        $scope.typeOfCase =rejection.decisionBelongsTo.supplementalIdentifierType;
        if($scope.PostDataResponse.panelList){
          getPanelString($scope.PostDataResponse.panelList);
        }
        else if(rejection.panelNames && rejection.panelNames.length > 0){
          angular.forEach(rejection.panelNames, function(judgeName) {
              if (!$scope.panelString) {
                $scope.panelString = judgeName;
              } else {
                $scope.panelString += " | " + judgeName;
            }
          });
        }
        
        $scope.originalPanel=rejection.panel;
$scope.saveEnabled = false;
  for (var i = 0; i < rejection.groundsTable.length; i++) {
    
    $scope.rejections.push(rejection.groundsTable[i]);

      if(rejection.groundsTable[i].appliedRules != null && rejection.groundsTable[i].appliedRules.length >0){
          var exceptionRuleApplied = rejection.groundsTable[i].appliedRules;
          ruleList.push(exceptionRuleApplied);

          var errors = getError(rejection.groundsTable[i].appliedRules);
          if (errors.length>0) {
            var columnNumber = parseInt(errors[0]);
            setClaimsError($scope.typeOfCase,  rejection.groundsTable[i].claimInformation, errors[1], columnNumber);
         //   rejection.groundsTable[i].claimInformation[coumnNum-1].error=errors[1];
          }
    

  }
  };
  $scope.validationRules = rejection.validationrules;
 angular.forEach($scope.validationRules, function(rule){
if(rule.identifier == 'cciv:2'){
  $scope.cciv2ErrorDescription = rule.description;
}
 })
  $scope.exceptionsLength = ruleList.length;
  if($scope.exceptionsLength >0) {
    $scope.displayedException = [];
    $scope.columnErrorsdisplayedException = [];
    angular.forEach(ruleList,function(rule){
      angular.forEach(rule,function(arule){
        var identifiers = arule.refIdentifier.split(",");
        for (var i=0;i<identifiers.length;i++) {
          var uniqueException = CommonHelperService.checkUnique($scope.displayedException,identifiers[i]);
          if (!uniqueException){
            $scope.displayedException.push(CommonHelperService.getValidationRule($scope.validationRules,identifiers[i]));
          }
        }
if (arule.columnErrors != null) {
  for (var i=0;i<arule.columnErrors.length;i++) {
        var columnErrors = arule.columnErrors[i];
          var columnErrorsuniqueException = CommonHelperService.checkUniqueError($scope.columnErrorsdisplayedException,columnErrors);
          if (!columnErrorsuniqueException){
            $scope.columnErrorsdisplayedException.push(columnErrors);
          }
      }}
   
        });
      });
    vm.exception = true;
     } else {
       vm.exception =false;
     }
  $scope.allFields = angular.copy($scope.rejections);
  var lastOne =   $scope.rejections.length;
  var size = lastOne-1 ;
  if (size >0) {
  $scope.outcome =  $scope.allFields.pop();
  $scope.outcome.editode = false;
  $scope.rejections =   $scope.allFields;
  } else{
    $scope.outcome = null;
  }
    }, function (failure) {
      vm.messageForRetrival=  failure.data.message;
      $scope.error =true;
    });
    }

vm.changeInfo= function(){
  if(vm.checkChangedSearch  == vm.searchThis){

  }else{
    vm.messageForRetrival = null;
  }
}
      vm.uploadDoc = function (value) {
        vm.messageForRetrival = null;
        if (value == 'uploadNew') {
          $scope.upload = 'uploadNew';
          vm.searchThis = null;
          vm.reportFromDate = '';
          vm.reportToDate = '';
        } else if (value == 'retrieve') {
          $scope.upload = 'retrieve';
          vm.reportFromDate = '';
          vm.reportToDate = '';
        } else if (value == 'download') {
          $scope.upload = 'download';
        }
      }

      vm.changeCaseType = function (value) {
        if (value == "appeals") {
          vm.reportType = "AppealDataReport";
          vm.showErrorMessage = false;
        }
        else if (value == "trials") {
          vm.reportType = "TrialDataReport";
          vm.showErrorMessage = false;
        }
      }

      $scope.exportToExcel = function () {
        if  (vm.reportFromDate && vm.reportToDate) {
          $scope.dateFutrueErrowMessage = false;
           vm.z = vm.reportFromDate <=  vm.reportToDate;
          if (vm.z == false){
            $scope.dateErrowMessage=true;
          }else{
            $scope.dateErrowMessage=false;
          }
        }
        else{
          $scope.dateFutrueErrowMessage = true;
        }
        if (vm.reportType && vm.z) {
          vm.showErrorMessage = false;
          vm.isLoading = true;
          var month = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
          var fromDate = new Date(vm.reportFromDate);
          var toDate = new Date(vm.reportToDate);
          // var startDate = fromDate.getDate() + '-' + month[fromDate.getMonth()] + '-' + fromDate.getFullYear();
          // var endDate = toDate.getDate() + '-' + month[toDate.getMonth()] + '-' + toDate.getFullYear();
          var sDate = new Date(vm.reportFromDate); 
          var startDate =  (sDate.getTime()-sDate.getMilliseconds())/1000;

          var eDate = new Date(vm.reportToDate); 
          var endDate =  (eDate.getTime()-eDate.getMilliseconds())/1000;

          HttpFactory.getActions(CONSTANTS.URL.AIA_TRIALS_URLS)
            .then(function (successResponse) {
              successResponse.data.forEach(function (element) {
                if (element.valueText == "PTACTS_TRIAL_SERVICE") {
                  vm.baseTrialUrl = element.descriptionText;
                  $http.get(vm.baseTrialUrl + '/adhoc-reports/export-excel?reportType=' + vm.reportType + '&startDate=' + startDate + '&endDate=' + endDate,
                    {
                      headers: {
                        'Content-Type': 'application/json',
                        'user-name': vm.userId,
                      },
                      withCredentials: true,
                      crossDomain: true,
                      responseType: "arraybuffer",
                    }).then(function (result) {
                      var blob = new Blob([result.data], {
                        type: 'application/pdf',
                      });
                      var a = document.createElement('a');
                      a.href = URL.createObjectURL(blob);
                      a.download = vm.reportType + '.xlsx';
                      a.click();
                      vm.isLoading = false;
                    }, function (failureResponse) {
                      toastr.error('Failed to export the report', {
                        iconClass: 'toast-danger',
                        timeOut: 5000
                      });
                      vm.isLoading = false;
                    });
                }
              });
            }, function (failureResponse) {
              vm.isLoading = false;
            });
        }
        else if(!vm.reportType) {
          vm.showErrorMessage = true;
        }
      }

    /* istanbul ignore next */
    $scope.extractSelectedDocument = function() {
      $scope.showMessage = false;
      var ruleList = [];
      $scope.oldDataExtracted =false;
      $scope.extracted=true;
      $scope.statusY.open=true;
      var pdfDataFile = new FormData();
      angular.forEach($scope.fileExtractContent, function (value) {
        pdfDataFile.append('uploadMultipartFileContents', value);
      });
      HttpFactory.postPdf( CONSTANTS.URL.MAIL_DOC, pdfDataFile)
      .then(function (successResponse) {

    
        $scope.error =false;
        $scope.statusJ.open=false;
        $scope.saveEnabled = true;
        $scope.PostDataResponse = successResponse.data;  
        $scope.rejections = [];
         var rejection = $scope.PostDataResponse;
        $scope.decisionBelongsTo = rejection.decisionBelongsTo;
        $scope.referenceNotes = rejection.referenceNotes;
        orderFootnotes();
        $scope.decisionSummary = rejection.decisionSummary;
        $scope.totalGround = rejection.totalGrounds;
        $scope.caseNumberFromDoc =rejection.decisionBelongsTo.supplementalIdentifier;
        $scope.applicationNum= rejection.decisionBelongsTo.coreIdentifier;
        $scope.typeOfCase =rejection.decisionBelongsTo.supplementalIdentifierType;
        getPanelString(rejection.panelNames);
        $scope.originalPanel=rejection.panelNames;
        for (var i = 0; i < rejection.groundsTable.length; i++) {
          var ground = rejection.groundsTable[i];
          try {

            var errors = getError(rejection.groundsTable[i].appliedRules);
            if (errors.length>0) {
              var columnNumber = parseInt(errors[0]);
              setClaimsError($scope.typeOfCase,  rejection.groundsTable[i].claimInformation, errors[1], columnNumber);
           //   rejection.groundsTable[i].claimInformation[coumnNum-1].error=errors[1];
            }
         //   rejection.groundsTable[i].claimInformation[0].error=getError( rejection.groundsTable[i].appliedRules, 2);
         //   rejection.groundsTable[i].claimInformation[1].error=getError( rejection.groundsTable[i].appliedRules, 3);
         //   rejection.groundsTable[i].claimInformation[2].error=getError( rejection.groundsTable[i].appliedRules, 4);
         //   if ( rejection.groundsTable[i].claimInformation[0].error.length>0 ||  rejection.groundsTable[i].claimInformation[1].error.length>0 ||  rejection.groundsTable[i].claimInformation[2].error.length>0) {
          //    rejection.groundsTable[i].rowError=true;
        //    }
 /*            if (rejection.groundsTable[i].appliedRules.length>0  && (rejection.groundsTable[i].claimInformation[0].error.length===0 && 
            rejection.groundsTable[i].claimInformation[1].error.length===0 && rejection.groundsTable[i].claimInformation[1].error.length===0)) {
              rejection.groundsTable[i].rowError=true;
            }
 */          } catch(error) {
            // Intentionally left blank
          }
           rejection.groundsTable[i].statuteValue = getStatute(rejection.groundsTable[i]);
          rejection.groundsTable[i].referencesBasisValue = getReferenceBasis(rejection.groundsTable[i]);
          $scope.rejections.push(rejection.groundsTable[i]);
          if(rejection.groundsTable[i].appliedRules != null && rejection.groundsTable[i].appliedRules.length >0){
            var exceptionRuleApplied = rejection.groundsTable[i].appliedRules;
            ruleList.push(exceptionRuleApplied);
          }
        };
  $scope.validationRules = successResponse.data.validationrules; //$scope.PostDataResponse.validationrules;
 angular.forEach($scope.validationRules, function(rule){
if(rule.identifier == 'cciv:2'){
  $scope.cciv2ErrorDescription = rule.description;
}
})
  $scope.exceptionsLength = ruleList.length;
  if($scope.exceptionsLength >0) {
    $scope.displayedException = [];
    $scope.columnErrorsdisplayedException = [];
    angular.forEach(ruleList,function(rule){
      angular.forEach(rule,function(arule){
        var identifiers = arule.refIdentifier.split(",");
        for (var i=0;i<identifiers.length;i++) {
          var uniqueException = CommonHelperService.checkUnique($scope.displayedException,identifiers[i]);
          if (!uniqueException){
            $scope.displayedException.push(CommonHelperService.getValidationRule($scope.validationRules,identifiers[i]));
          }
        }
if (arule.columnErrors != null) {
  for (var i=0;i<arule.columnErrors.length;i++) {
        var columnErrors = arule.columnErrors[i];
          var columnErrorsuniqueException = CommonHelperService.checkUniqueError($scope.columnErrorsdisplayedException,columnErrors);
          if (!columnErrorsuniqueException){
            $scope.columnErrorsdisplayedException.push(columnErrors);
          }
      }}
   
        });
      });
    vm.exception = true;
     } else {
       vm.exception =false;
     }
  $scope.allFields = angular.copy($scope.rejections);
  var lastOne =   $scope.rejections.length;
  var size = lastOne-1 ;
  if (size >0) {
  $scope.outcome =  $scope.allFields.pop();
 /*  angular.forEach($scope.outcome.claimInformation, function(column) {
    if (column.expanded) {
      column.error = getError($scope.outcome.appliedRules, 'Outcome');
    }
  });
 */  $scope.outcome.editode = false;
  $scope.rejections =   $scope.allFields;
  } else{
    $scope.outcome = null;
  }
      }, function (failureResponse) {
        $scope.typeOfCase = null;
        $scope.error =true;
       console.log(failureResponse.data.message);
       toastr.error(failureResponse.data.message, {
        iconClass: 'toast-danger',
        timeOut: 5000
      });
      });
    }

    function setClaimsError(typeOfCase, claims, error, columnNum) {
      var claimType;
      if (typeOfCase === 'AIA') {
        switch(columnNum) {
          case 0:
            claimType= "PETITIONED";
            break;
          case 3:
            claimType="SHOWN_UNPATENTABLE";
            break;
          case 4:
            claimType="NOT_SHOWN_UNPATENTABLE";
            break;
          default:
            break;
        }
       } else {
        switch(columnNum) {
          case 0:
            claimType= "PETITIONED|REJECTED";
            break;
          case 3:
            claimType="AFFIRMED";
            break;
          case 4:
            claimType="REVERSED";
            break;
          default:
            break;
        }
      }
      try {
        angular.forEach(claims, function(claim) {
          if (claimType.indexOf(claim.referenceType) >=0) {
            claim.error=error;
          }
        });  
      } catch(error) {
        console.info("Error=" + error);
      }
       

    }

    function getError(appliedRules, i) {
      var columnApplied = appliedRules;
      var errorObject=[];
      if (appliedRules.length==0) {
        return errorObject;
      }

      if(appliedRules.length > 1 && appliedRules[1].columnApplied){
      var columnIndex = appliedRules[1].columnApplied.indexOf("[");

      var columnApplied = appliedRules[1].columnApplied.substring(columnIndex+1, columnIndex+2);
      errorObject.push(columnApplied);
      errorObject.push(appliedRules[1].columnErrors[0]);
      }
    
   /*    angular.forEach(appliedRules, function(rule) {
        if (rule.columnApplied) {
          if (rule.columnApplied.indexOf(i)>=0) {
            if (errorObject.length===0) {
              errorObject.push(true);
            } 
            if (rule.columnErrors) {
              errorObject.push(rule.columnErrors[0]);
            }
           
          }
        } 
      });*/
      return errorObject;
    }

    function getFootnoteValue(footnoteRef) {
      var first = footnoteRef.indexOf(":");
      if (first>5) {
        return footnoteRef.substring(first+1, footnoteRef.length-1);
      }
      return "";
    }

    function getFootnoteScreenValue(footnoteRef) {
      if (!footnoteRef) {
        return "";
      }
      var first = footnoteRef.indexOf("[");
      if (first>1) {
        return footnoteRef.substring(first+1, footnoteRef.length-1);
      }
      return "";
    }
    function getStatute(rejection) {
      if (rejection.statuteAsCaptured && rejection.statuteAsCaptured.indexOf("footnoteRef:")>=0) {
        var endIndex = rejection.statuteAsCaptured.indexOf("footnoteRef:");
        return rejection.statuteAsCaptured.substring(0, endIndex-1) +   " [" + getFootnoteValue(rejection.statuteAsCaptured) + "]";
      } else {
        return rejection.statuteAsCaptured;
      }
    }

    function getStatuteSaved(rejection) {
      if (rejection.statuteAsCaptured && rejection.statuteAsCaptured.indexOf("footnoteRef:")>=0) {
        var endIndex = rejection.statuteAsCaptured.indexOf("footnoteRef:");
        return rejection.statuteAsCaptured.substring(0, endIndex-2) +   " [" + getFootnoteValue(rejection.statuteAsCaptured) + "]";
      } else {
        return rejection.statuteAsCaptured;
      }
    }
   
    function orderFootnotes() {
      angular.forEach($scope.referenceNotes, function(footNote) {
        try {
          footeNote.identifierValue = parseInt(footNote.identifier);
        } catch(error) {
          // intentionally left blank
        }
        
      });
    }
    function getStatuteNoFootnote(rejection) {
      if (rejection.statuteAsCaptured && rejection.statuteValue.indexOf("[")>=0) {
        var endIndex = rejection.statuteAsCaptured.indexOf("[");
        return rejection.statuteValue.substring(0, endIndex);
      } else {
        return rejection.statuteValue;
      }
    }
    function getReferenceBasis(rejection) {
      if (rejection.referencesBasis && rejection.referencesBasis.indexOf("footnoteRef:")>=0) {
        var footnote =  " [" + getFootnoteValue(rejection.referencesBasis) + "]";
        var end = rejection.referencesBasis.indexOf("[footnoteRef:");
        var referenceBasisValue = rejection.referencesBasis.substring(0, end);
        return referenceBasisValue + footnote;
      } else {
        return rejection.referencesBasis;
      }
    }

    $scope.getReferenceBasisNoFootnote = function(rejection) {
      if (rejection.referencesBasis && rejection.referencesBasisValue.indexOf("[")>=0) {
         var end = rejection.referencesBasis.indexOf("[");
        return rejection.referencesBasis.substring(0, end);
      } else {
        return rejection.referencesBasisValue;
      }
    };

    $scope.getReferenceBasisFootnote = function(rejection) {
      if (rejection.referencesBasis && rejection.referencesBasis.indexOf("footnoteRef:")>=0) {
        return getFootnoteValue(rejection.referencesBasis);
      } else {
        return "";
      }
    };


    $scope.editTheFootnote = function(refNotes) {
      vm.editedFootnote = angular.copy(refNotes);
      refNotes.editMode=true;
      $scope.footNoteEditMode=true; 
    };

    $scope.cancelFootnote = function(refNotes) {
      refNotes.editMode=false;
      $scope.footNoteEditMode=false;
    };

    $scope.saveFootnote = function(refNotes) {
      refNotes.identifier = vm.editedFootnote.identifier;
      refNotes.referenceText = vm.editedFootnote.referenceText;
      refNotes.editMode=false;
      $scope.footNoteEditMode=false;
      $scope.saveEnabled=true;
      orderFootnotes();
      checkFootnotes();
    }

    $scope.cancelFooter = function(footer) {
      footer.editMode = false;
      $scope.footerEdit = null;
      vm.revalidate =false;
      if(vm.editedInformation)
      {      $scope.saveEnabled = false;
      } else if(!vm.editedInformation && $scope.oldDataExtracted){
        $scope.saveEnabled = false;
       }else {
       $scope.saveEnabled = true;
      }
    };

    $scope.editFooter = function(footer) {
         if ($scope.footerEdit) {
           return;
         }
         footer.editMode = true;
        $scope.outcome.editode = true;
        vm.revalidate =false;
         $scope.footerEdit = angular.copy(footer);
         if ($scope.typeOfCase === "Appeal" && footer.claimInformation.length > 0 ){
          angular.forEach(footer.claimInformation, function(row) {
            if (row.referenceType ==='AFFIRMED') {
            $scope.footerEdit.affirmed = row.asCaptured; }
             else if(row.referenceType ==='REVERSED'){
              $scope.footerEdit.reversed = row.asCaptured;
             }  else if(row.referenceType ==='REJECTED' ||row.referenceType ==='PETITIONED'  ){
              $scope.footerEdit.rejected = row.asCaptured;
             } 
            // else if(row.referenceType ==='SHOWN_UNPATENTABLE'){
            // } 
          }
          ); 
        }
     else if ($scope.typeOfCase === "AIA" && footer.claimInformation.length > 0 ){
      angular.forEach(footer.claimInformation, function(row) {
         if(row.referenceType ==='SHOWN_UNPATENTABLE'){
          $scope.footerEdit.affirmed = row.asCaptured;
         }
         else if(row.referenceType ==='NOT_SHOWN_UNPATENTABLE'){
          $scope.footerEdit.reversed = row.asCaptured;
         }
        }
      ); 
  } 

  $scope.saveEnabled = false;
 };



 $scope.editRejectionClaim = function(rejection) {
      console.log($scope.rejectionEdit);
       if ($scope.rejectionEdit) {
         return;
       }
       rejection.editMode = true;
       vm.revalidate =false;
       $scope.rejectionEdit = angular.copy(rejection);
       $scope.rejectionEdit.statuteFootnote = getFootnoteScreenValue(rejection.statuteValue);
       $scope.rejectionEdit.statuteEditValue = getStatuteNoFootnote(rejection);
       $scope.rejectionEdit.referenceBasisFootnote = getFootnoteScreenValue(rejection.referencesBasisValue);
       $scope.rejectionEdit.referencesBasisEditValue = $scope.getReferenceBasisNoFootnote(rejection);
       angular.forEach(rejection.claimInformation, function(row) {
        if (row.referenceType ==='AFFIRMED') {
        $scope.rejectionEdit.affirmed = row.asCaptured; }
         else if(row.referenceType ==='REVERSED'){
          $scope.rejectionEdit.reversed = row.asCaptured;
         }  else if(row.referenceType ==='REJECTED'){
          $scope.rejectionEdit.rejected = row.asCaptured;
         } else if(row.referenceType ==='SHOWN_UNPATENTABLE'){
          $scope.rejectionEdit.affirmed = row.asCaptured;
         }
         else if(row.referenceType ==='NOT_SHOWN_UNPATENTABLE'){
          $scope.rejectionEdit.reversed = row.asCaptured;
         }
         else if(row.referenceType ==='PETITIONED'){
          $scope.rejectionEdit.rejected = row.asCaptured;
         }
        }
      );  
      $scope.saveEnabled = false;
    };

    function buildStatueAsCaptured(statute, statuteFootnote) {
      if (statuteFootnote) {
        return 
      }
    }

    function updateStatute(statuteEditValue, footnote) {
      var newStatute = statuteEditValue;
      if (footnote) {
        newStatute += " [footnoteRef:" + footnote + "]";
        return newStatute;
      }
      return newStatute
    }

    function updateStatuteValue(statuteEditValue, footnote) {
      var newStatute =statuteEditValue;
      if (footnote) {
        newStatute += " [" + footnote + "]";
        return newStatute;
      }
      return newStatute
    }
  
    function updateBasis(referencesBasisEditValue, footnote) {
      var newBasis =referencesBasisEditValue;
      if (footnote) {
        newBasis += " [footnoteRef:" + footnote + "]";
        return newBasis;
      }
      return newBasis
    }

    function updateBasisValue(referencesBasisEditValue, footnote) {
      var newBasis = referencesBasisEditValue;
      if (footnote) {
        newBasis += " [" + footnote + "]";
        return newBasis;
      }
      return newBasis
    }


    $scope.saveRejectionClaim = function(rejection) {
      vm.editedInformation = true;
       rejection.editMode = false;
       vm.revalidate =true;
       vm.disableRevalidate = false;
       if($scope.typeOfCase === "Appeal"){ 

        //rejection.statute = $scope.rejectionEdit.statute;
        rejection.statuteAsCaptured = updateStatute($scope.rejectionEdit.statuteEditValue, $scope.rejectionEdit.statuteFootnote);
        rejection.statute = rejection.statuteAsCaptured ? rejection.statuteAsCaptured.trim():rejection.statuteAsCaptured;
        rejection.statuteValue = updateStatuteValue($scope.rejectionEdit.statuteEditValue, $scope.rejectionEdit.statuteFootnote);
        rejection.referencesBasisValue = updateBasisValue($scope.rejectionEdit.referencesBasisEditValue, $scope.rejectionEdit.referenceBasisFootnote);
        rejection.referencesBasis = updateBasis($scope.rejectionEdit.referencesBasisEditValue, $scope.rejectionEdit.referenceBasisFootnote);
        //rejection.statuteAsCaptured = buildStatueAsCaptured(rejection.statuteAs$scope.rejectionEdit.statute, $scope.rejectionEdit.statuteFootnote);
        //rejection.referencesBasis = $scope.rejectionEdit.referencesBasis;
        rejection.groundAsCaptured = $scope.rejectionEdit.groundAsCaptured ? $scope.rejectionEdit.groundAsCaptured.trim():$scope.rejectionEdit.groundAsCaptured;
       angular.forEach(rejection.claimInformation, function(row) {
        if (row.referenceType ==='AFFIRMED') {
          angular.forEach($scope.rejectionEdit.claimInformation, function(row1) {
            if (row1.referenceType ==='AFFIRMED') {
          row.asCaptured =   $scope.rejectionEdit.affirmed ? $scope.rejectionEdit.affirmed.trim():$scope.rejectionEdit.affirmed; }
            }
          );  
        }
         });
        angular.forEach(rejection.claimInformation, function(row) {
          if (row.referenceType ==='REJECTED' ||row.referenceType ==='PETITIONED') {
            angular.forEach($scope.rejectionEdit.claimInformation, function(row1) {
              if (row1.referenceType ==='REJECTED'||row.referenceType ==='PETITIONED') {
                row.asCaptured=  $scope.rejectionEdit.rejected; }
              }
            ); 
           }
          });
          angular.forEach(rejection.claimInformation, function(row) {
            if (row.referenceType ==='REVERSED') {
              angular.forEach($scope.rejectionEdit.claimInformation, function(row1) {
                if (row1.referenceType ==='REVERSED') {
                  row.asCaptured=  $scope.rejectionEdit.reversed; }
                }
              ); 
             }
            });
        } else {
          rejection.statuteValue = updateStatuteValue($scope.rejectionEdit.statuteEditValue, $scope.rejectionEdit.statuteFootnote);
          rejection.statuteAsCaptured = rejection.statuteValue.trim();
          rejection.referencesBasisValue = updateBasisValue($scope.rejectionEdit.referencesBasisEditValue, $scope.rejectionEdit.referenceBasisFootnote);
          rejection.referencesBasis = updateBasis($scope.rejectionEdit.referencesBasisEditValue, $scope.rejectionEdit.referenceBasisFootnote);
  
              angular.forEach(rejection.claimInformation, function(row) {
                if (row.referenceType ==='SHOWN_UNPATENTABLE') {
                   row.asCaptured= $scope.rejectionEdit.affirmed ? $scope.rejectionEdit.affirmed.trim():$scope.rejectionEdit.affirmed;
                 }
                });
                angular.forEach(rejection.claimInformation, function(row) {
                  if (row.referenceType ==='NOT_SHOWN_UNPATENTABLE') {
                     row.asCaptured= $scope.rejectionEdit.reversed ? $scope.rejectionEdit.reversed.trim():$scope.rejectionEdit.reversed;
                   }
                  });
                  angular.forEach(rejection.claimInformation, function(row) {
                    if (row.referenceType ==='PETITIONED') {
                       row.asCaptured= $scope.rejectionEdit.rejected ? $scope.rejectionEdit.rejected.trim():$scope.rejectionEdit.rejected;
                     }
                    });
            }
       $scope.rejectionEdit=null;
       $scope.saveEnabled = false;
    }

    $scope.updateCaseNumber = function() {
      $scope.caseNumberError=false;
      var searchNum =  $scope.editedCaseNumberObject.caseNumber;
        vm.isTrials = searchNum.match(/[a-z]/i) ? true : false;
        if (!vm.isTrials) {
          searchNum = searchNum.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, '');
        }
 
        HttpFactory.getActions(CONSTANTS.URL.CASE_SEARCH + searchNum)
          .then(function (successResponse) {

          
            if (successResponse.data.appealNumber === null || successResponse.data.serialNumber === null) {
              $scope.caseNumberError=true;
            } else {
              $scope.caseNumberFromDoc = $scope.editedCaseNumberObject.caseNumber;
              $scope.editCaseNumberMode = false;
              $scope.saveEnabled = true;
            }
          }, function () {
            $scope.caseNumberError=true;
          });
      
    }
    $scope.editCaseNumber = function() {
      $scope.editCaseNumberMode=true;

      $scope.editedCaseNumberObject = {
        caseNumber : $scope.caseNumberFromDoc
      };
    }

    $scope.cancelEditCaseNumber = function() {
      $scope.editCaseNumberMode = false;
      $scope.caseNumberError=false;
    }
    $scope.saveFooter = function(footer) {
      vm.disableRevalidate = false;
      vm.revalidate = true;
      vm.editedInformation = true;
      footer.editMode = false;
      if($scope.typeOfCase === "Appeal"){ 
        footer.groundAsCaptured = $scope.footerEdit.groundAsCaptured;
        if( footer.groundAsCaptured === "") {
          footer.groundAsCaptured = "  ";
        }
        footer.statuteAsCaptured = $scope.footerEdit.statuteAsCaptured ? $scope.footerEdit.statuteAsCaptured.trim() : $scope.footerEdit.statuteAsCaptured;
      angular.forEach(footer.claimInformation, function(row) {
       if (row.referenceType ==='AFFIRMED') {
         angular.forEach($scope.footerEdit.claimInformation, function(row1) {
           if (row1.referenceType ==='AFFIRMED') {
         row.asCaptured =   $scope.footerEdit.affirmed ; }
           }
         );  
       }
        });
       angular.forEach(footer.claimInformation, function(row) {
         if (row.referenceType ==='REJECTED') {
           angular.forEach($scope.footerEdit.claimInformation, function(row1) {
             if (row1.referenceType ==='REJECTED') {
               row.asCaptured=  $scope.footerEdit.rejected ? $scope.footerEdit.rejected.trim() : $scope.footerEdit.rejected; }
             }
           ); 
          }
         });
         angular.forEach(footer.claimInformation, function(row) {
           if (row.referenceType ==='REVERSED') {
             angular.forEach($scope.footerEdit.claimInformation, function(row1) {
               if (row1.referenceType ==='REVERSED') {
                 row.asCaptured=  $scope.footerEdit.reversed ? $scope.footerEdit.reversed.trim() : $scope.footerEdit.reversed; }
               }
             ); 
            }
           });
           } else {
            footer.statuteAsCaptured = $scope.footerEdit.statuteAsCaptured;
             angular.forEach(footer.claimInformation, function(row) {
               if (row.referenceType ==='SHOWN_UNPATENTABLE') {
                  row.asCaptured= $scope.footerEdit.affirmed ? $scope.footerEdit.affirmed.trim() : $scope.footerEdit.affirmed;
                }
               });
               angular.forEach(footer.claimInformation, function(row) {
                 if (row.referenceType ==='NOT_SHOWN_UNPATENTABLE') {
                    row.asCaptured= $scope.footerEdit.reversed ? $scope.footerEdit.reversed.trim() : $scope.footerEdit.reversed;
                  }
                 });
                 angular.forEach(footer.claimInformation, function(row) {
                   if (row.referenceType ==='PETITIONED') {
                      row.asCaptured= $scope.footerEdit.rejected ? $scope.footerEdit.rejected.trim() : $scope.footerEdit.rejected;
                    }
                   });
           }
      $scope.footerEdit=null;
   }
    });
})();
