(function () {
    'use strict';
  
    describe('documentDecisionController', function () {
  
      beforeEach(module('ptabe2e'));
      var $controller;
      var vm = this;
      var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close', 'open']);
      var controller, scope, $rootScope, _$rootScope_;
      var timeout;
      var successResponse, workerNumber, sharedItems, shareAssign;
      var $httpBackend, spy, $q, HttpFactoryDeferred;
  
      var fakeElement = function (params) {
        return {
          scope: function () {
            return {
              vm: {
                userInfo: {
                  appUserInfo: [{
                    userIdentiifier: "sbartlett"
                  }]
                }
              }
            }
          }
        }
      };
      var shareAssign = [{
        "ptabAssignmentId": "1547",
        "fkAdFkAaSerialNo": "2018005604",
        "fkAdFkAppealNo": "10651537",
        "standardAssignmentType": "Docketing notice",
        "globalMetaData": {
          "briefHearingType": "H"
        }
      }];
  
      var pdfData = {
        value: {
          deliveryMode: 'Electronic'
        }
      }
  
      beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_, _$q_, HttpFactory) {
        $q = _$q_;
        $controller = _$controller_;
        scope = _$rootScope_.$new();
        $rootScope = _$rootScope_;
        timeout = _$timeout_;
        HttpFactoryDeferred = _$q_.defer();
  
        ngDialog.open.and.returnValue({
          closePromise: {
            then: function (callback1) {
              callback1(pdfData);
            }
          },
          then: function (callback3, callback4) {
            callback3();
            callback4();
          }
        });
  
        $rootScope.sharedItems = [{
          "ptabAssignmentId": "1547",
          "fkAdFkAaSerialNo": "2018005604",
          "fkAdFkAppealNo": "10651537",
          "globalMetaData": {
            "briefHearingType": "H"
          }
        }];
        spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
        spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
        spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);
        spy = spyOn(angular, 'element').and.callFake(fakeElement);
  
        controller = $controller('documentDecisionController', {
          $scope: scope,
          ngDialog: ngDialog,
          $rootScope: _$rootScope_,
          HttpFactory: HttpFactory
        });
      }));
  
      describe('documentDecisionController ', function () {

    //  it(' should call fileSelect', function () {
    //     var p = {
    //       keycode: '1',
    //     }
    //     expect(scope.fileSelect).toBeDefined();
    //     scope.fileSelect(p);
    //   });
 
    //   it(' should call fileSelect', function () {
    //     var p = {
    //       keycode: '13'
    //     }
    //     expect(scope['fileSelect']).toBeDefined();
    //     scope.fileSelect(p);
    //   });
  
        it('should call clearDocument  ', function () {
          scope.verifiedDocument = null;
          scope.extracted= false;
          scope.fileExtractContent=[];
          expect(scope.clearDocument).toBeDefined();
          scope.clearDocument();
        });

        it('should call closeWind', function () {
          var editedInformation = false;
          expect(controller.closeWind).toBeDefined();
          controller.closeWind();
        });

        it('should call closeWind', function () {
          var editedInformation = true;
          scope.closeWindowClicked = true;
          expect(controller.closeWind).toBeDefined();
          controller.closeWind();
        });
        it('should call clearDocument if', function () {
          var editedInformation = true;
          scope.verifiedDocument = null;
          scope.extracted= false;
          scope.fileExtractContent=[];
          expect(scope.clearDocument).toBeDefined();
        //  expect(scope.openUnsavedChanges).toBeDefined();
         // scope.openUnsavedChanges();
          // openUnsavedChanges
          // openUnsavedChanges
          scope.clearDocument();
        });

        // it('should call saveInfo ', function () {
        //   var rejections= [];
        //   expect(controller.saveInfo).toBeDefined();
        //   controller.saveInfo();
        // });
        
        it('should call hideAlert', function () {
          expect(controller.hideAlert).toBeDefined();
          controller.hideAlert();
        });
        
        it('should call closeTab', function () {
          expect(controller.closeTab).toBeDefined();
          controller.closeTab();
        });
        it('should call editRejectionClaim AIA', function () {
            var rejectionEdit = undefined;
             scope.typeOfCase = "AIA";
             scope.rejectionEdit = undefined;
             var rejection = {
                 "decisionBelongsTo": {
                   "coreIdentifier": "Appeal 2020-001678",
                   "supplementalIdentifier": "Application 15/540,978"
                 },
                 "referenceNotes": [
                   {
                     "identifier": "2",
                     "referenceText": " As discussed above, we do not reach this rejection.",
                     "referencedIdentifier": null
                   }
                 ],
                 "decisionSummary": {
                   "summaryDetails": null
                 },
                 "outComeDetails": [
                   {
                     "referenceRegulation": "103",
                     "claimInformation": [
                       {
                         "referenceType": "UNKNOWN",
                         "totalClaims": 20,
                         "asCaptured": "1–20",
                         "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                       },
                       {
                         "referenceType": "AFFIRMED",
                         "totalClaims": 20,
                         "asCaptured": "1–20",
                         "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                       },
                       {
                         "referenceType": "REVERSED",
                         "totalClaims": 0,
                         "asCaptured": "",
                         "expanded": ""
                       }
                     ],
                     "grounds": null,
                     "references": "Freeman, Kippola"
                   },
                   {
                     "referenceRegulation": "7-8",
                     "claimInformation": [
                       {
                         "referenceType": "UNKNOWN",
                         "totalClaims": 20,
                         "asCaptured": "1–20",
                         "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                       },
                       {
                         "referenceType": "AFFIRMED",
                         "totalClaims": 0,
                         "asCaptured": "",
                         "expanded": ""
                       },
                       {
                         "referenceType": "REVERSED",
                         "totalClaims": 0,
                         "asCaptured": "",
                         "expanded": ""
                       }
                     ],
                     "grounds": null,
                     "references": "Provisional Non-statutory Double Patenting[footnoteRef:2]"
                   }
                 ]
               }
             expect(scope.editRejectionClaim).toBeDefined();
             scope.editRejectionClaim(rejection);
           });

           it('should call editRejectionClaim AIA', function () {
            var rejectionEdit = undefined;
             scope.typeOfCase = "AIA";
             scope.rejectionEdit = undefined;
             var rejection = {
                 "decisionBelongsTo": {
                   "coreIdentifier": "Appeal 2020-001678",
                   "supplementalIdentifier": "Application 15/540,978"
                 },
                 "referenceNotes": [
                   {
                     "identifier": "2",
                     "referenceText": " As discussed above, we do not reach this rejection.",
                     "referencedIdentifier": null
                   }
                 ],
                 "decisionSummary": {
                   "summaryDetails": null
                 },
                 "outComeDetails": [
                   {
                     "referenceRegulation": "103",
                     "claimInformation": [
                       {
                         "referenceType": "UNKNOWN",
                         "totalClaims": 20,
                         "asCaptured": "1–20",
                         "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                       },
                       {
                         "referenceType": "AFFIRMED",
                         "totalClaims": 20,
                         "asCaptured": "1–20",
                         "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                       },
                       {
                         "referenceType": "REVERSED",
                         "totalClaims": 0,
                         "asCaptured": "",
                         "expanded": ""
                       }
                     ],
                     "grounds": null,
                     "references": "Freeman, Kippola"
                   },
                   {
                     "referenceRegulation": "7-8",
                     "claimInformation": [
                       {
                         "referenceType": "UNKNOWN",
                         "totalClaims": 20,
                         "asCaptured": "1–20",
                         "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                       },
                       {
                         "referenceType": "AFFIRMED",
                         "totalClaims": 0,
                         "asCaptured": "",
                         "expanded": ""
                       },
                       {
                         "referenceType": "REVERSED",
                         "totalClaims": 0,
                         "asCaptured": "",
                         "expanded": ""
                       }
                     ],
                     "grounds": null,
                     "references": "Provisional Non-statutory Double Patenting[footnoteRef:2]"
                   }
                 ]
               }
             expect(scope.editRejectionClaim).toBeDefined();
             scope.editRejectionClaim(rejection);
           });

           it('should call editFooter  else', function () {
            scope.footerEdit = "null";
            var footer = {
              "claimInformation": [],
              "editMode": true,
              "editode": true,
              "groundNo": null,
              "referencesBasis": "",
              "statute": "120",
              "statuteAsCaptured": "1–20"
            }
            // var rejectionEdit = undefined;
            // var row = {
            //     "asCaptured": "1–20",
            //     "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20",
            //     "referenceType": "AFFIRMED",
            //     "totalClaims": 20
            //       }
                
            //  scope.typeOfCase = "APPEAL";
            //  scope.rejectionEdit = undefined;
            //  var rejection = {
            //      "decisionBelongsTo": {
            //        "coreIdentifier": "Appeal 2020-001678",
            //        "supplementalIdentifier": "Application 15/540,978"
            //      },
            //      "referenceNotes": [
            //        {
            //          "identifier": "2",
            //          "referenceText": " As discussed above, we do not reach this rejection.",
            //          "referencedIdentifier": null
            //        }
            //      ],
            //      "decisionSummary": {
            //        "summaryDetails": null
            //      },
            //      "outComeDetails": [
            //        {
            //          "referenceRegulation": "103",
            //          "claimInformation": [
            //            {
            //              "referenceType": "AFFIRMED",
            //              "totalClaims": 20,
            //              "asCaptured": "1–20",
            //              "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
            //            }
            //          ],
            //          "grounds": null,
            //          "references": "Freeman, Kippola"
            //        },
            //        {
            //          "referenceRegulation": "7-8",
            //          "claimInformation": [
            //            {
            //              "referenceType": "UNKNOWN",
            //              "totalClaims": 20,
            //              "asCaptured": "1–20",
            //              "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
            //            },
            //            {
            //              "referenceType": "AFFIRMED",
            //              "totalClaims": 0,
            //              "asCaptured": "",
            //              "expanded": ""
            //            },
            //            {
            //              "referenceType": "REVERSED",
            //              "totalClaims": 0,
            //              "asCaptured": "",
            //              "expanded": ""
            //            }
            //          ],
            //          "grounds": null,
            //          "references": "Provisional Non-statutory Double Patenting[footnoteRef:2]"
            //        }
            //      ]
            //    }
             expect(scope.editFooter).toBeDefined();
             scope.editFooter(footer);
           });
 
           it('should call editFooter  else', function () {
            scope.footerEdit = undefined;
            var footer = {
              "claimInformation": [],
              "editMode": true,
              "editode": true,
              "groundNo": null,
              "referencesBasis": "",
              "statute": "120",
              "statuteAsCaptured": "1–20"
            }

            scope.footerEdit = {
              "claimInformation": [],
              "editMode": true,
              "editode": true,
              "groundNo": null,
              "referencesBasis": "",
              "statute": "120",
              "statuteAsCaptured": "1–20"
            }

            scope.outcome = {
              "claimInformation": [{
                "asCaptured": "1, 2, 4, 68, 10, 1214, 16, 18",
"expanded": "1,2,4,68,10,1214,16,18",
"referenceType": "SHOWN_UNPATENTABLE",
"totalClaims": 8
              }, {"asCaptured": "",
              "expanded": "",
              "referenceType": "NOT_SHOWN_PATENTABLE",
              "totalClaims": 0}],
"editMode": true,
"groundNo": null,
"referencesBasis": "",
"statute": "",
"statuteAsCaptured": ""
            }
             expect(scope.editFooter).toBeDefined();
             scope.editFooter(footer);
           });
 
        it('should call saveRejectionClaim AIA', function () {
            var rejectionEdit = {
                 
                 "affirmed": "1–20",
                 "claimInformation":
             
                     [{
                         "referenceType": "AFFIRMED",
                         "totalClaims": 20,
                         "asCaptured": "1–20",
                         "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                     }],
             
                 "length": 3,
             
                 "editMode": true,
                 "groundNo": null,
                 "referencesBasis": "Freeman, Kippola",
                 "reversed": "",
                 "statute": "103",
                 "statuteAsCaptured": "103"
             
         };
             scope.typeOfCase = "AIA";
             scope.rejectionEdit = {
                 
                     "affirmed": "1–20",
                     "claimInformation":
                 
                         [{
                             "referenceType": "AFFIRMED",
                             "totalClaims": 20,
                             "asCaptured": "1–20",
                             "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                         }],
                 
                     "length": 3,
                 
                     "editMode": true,
                     "groundNo": null,
                     "referencesBasis": "Freeman, Kippola",
                     "reversed": "",
                     "statute": "103",
                     "statuteAsCaptured": "103"
                 
             };
             var rejection = {
                 "decisionBelongsTo": {
                   "coreIdentifier": "Appeal 2020-001678",
                   "supplementalIdentifier": "Application 15/540,978"
                 },
                 "referenceNotes": [
                   {
                     "identifier": "2",
                     "referenceText": " As discussed above, we do not reach this rejection.",
                     "referencedIdentifier": null
                   }
                 ],
                 "decisionSummary": {
                   "summaryDetails": null
                 },
                 "outComeDetails": [
                   {
                     "referenceRegulation": "103",
                     "claimInformation": [
                       {
                         "referenceType": "UNKNOWN",
                         "totalClaims": 20,
                         "asCaptured": "1–20",
                         "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                       },
                       {
                         "referenceType": "AFFIRMED",
                         "totalClaims": 20,
                         "asCaptured": "1–20",
                         "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                       },
                       {
                         "referenceType": "REVERSED",
                         "totalClaims": 0,
                         "asCaptured": "",
                         "expanded": ""
                       }
                     ],
                     "grounds": null,
                     "references": "Freeman, Kippola"
                   },
                   {
                     "referenceRegulation": "7-8",
                     "claimInformation": [
                       {
                         "referenceType": "UNKNOWN",
                         "totalClaims": 20,
                         "asCaptured": "1–20",
                         "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                       },
                       {
                         "referenceType": "AFFIRMED",
                         "totalClaims": 0,
                         "asCaptured": "",
                         "expanded": ""
                       },
                       {
                         "referenceType": "REVERSED",
                         "totalClaims": 0,
                         "asCaptured": "",
                         "expanded": ""
                       }
                     ],
                     "grounds": null,
                     "references": "Provisional Non-statutory Double Patenting[footnoteRef:2]"
                   }
                 ]
               }
             expect(scope.saveRejectionClaim).toBeDefined();
             scope.saveRejectionClaim(rejection);
           });
 

           it('should call saveFooter  Appeal', function () {
            var footer = {
              "claimInformation": [],
              "editMode": true,
              "editode": true,
              "groundNo": null,
              "referencesBasis": "",
              "statute": "120",
              "statuteAsCaptured": "1–20"
            }

           scope.footerEdit = {
              "claimInformation": [],
              "editMode": true,
              "editode": true,
              "groundNo": null,
              "referencesBasis": "",
              "statute": "120",
              "statuteAsCaptured": "1–20"
            }
             scope.typeOfCase = "Appeal";
             scope.rejectionEdit = {
                 
                     "affirmed": "1–20",
                     "claimInformation":
                 
                         [{
                             "referenceType": "AFFIRMED",
                             "totalClaims": 20,
                             "asCaptured": "1–20",
                             "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                         }],
                 
                     "length": 3,
                 
                     "editMode": true,
                     "groundNo": null,
                     "referencesBasis": "Freeman, Kippola",
                     "reversed": "",
                     "statute": "103",
                     "statuteAsCaptured": "103"
                 
             };
             var rejection = {
                 "decisionBelongsTo": {
                   "coreIdentifier": "Appeal 2020-001678",
                   "supplementalIdentifier": "Application 15/540,978"
                 },
                 "referenceNotes": [
                   {
                     "identifier": "2",
                     "referenceText": " As discussed above, we do not reach this rejection.",
                     "referencedIdentifier": null
                   }
                 ],
                 "decisionSummary": {
                   "summaryDetails": null
                 },
                 "outComeDetails": [
                   {
                     "referenceRegulation": "103",
                     "claimInformation": [
                       {
                         "referenceType": "UNKNOWN",
                         "totalClaims": 20,
                         "asCaptured": "1–20",
                         "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                       },
                       {
                         "referenceType": "AFFIRMED",
                         "totalClaims": 20,
                         "asCaptured": "1–20",
                         "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                       },
                       {
                         "referenceType": "REVERSED",
                         "totalClaims": 0,
                         "asCaptured": "",
                         "expanded": ""
                       }
                     ],
                     "grounds": null,
                     "references": "Freeman, Kippola"
                   },
                   {
                     "referenceRegulation": "7-8",
                     "claimInformation": [
                       {
                         "referenceType": "UNKNOWN",
                         "totalClaims": 20,
                         "asCaptured": "1–20",
                         "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                       },
                       {
                         "referenceType": "AFFIRMED",
                         "totalClaims": 0,
                         "asCaptured": "",
                         "expanded": ""
                       },
                       {
                         "referenceType": "REVERSED",
                         "totalClaims": 0,
                         "asCaptured": "",
                         "expanded": ""
                       }
                     ],
                     "grounds": null,
                     "references": "Provisional Non-statutory Double Patenting[footnoteRef:2]"
                   }
                 ]
               }
             expect(scope.saveFooter ).toBeDefined();
             scope.saveFooter (footer);
           });
           it('should call saveFooter  AIA', function () {
            var footer = {
              "claimInformation": [],
              "editMode": true,
              "editode": true,
              "groundNo": null,
              "referencesBasis": "",
              "statute": "120",
              "statuteAsCaptured": "1–20"
            }

           scope.footerEdit = {
              "claimInformation": [],
              "editMode": true,
              "editode": true,
              "groundNo": null,
              "referencesBasis": "",
              "statute": "120",
              "statuteAsCaptured": "1–20"
            }
             scope.typeOfCase = "AIA";
             scope.rejectionEdit = {
                 
                     "affirmed": "1–20",
                     "claimInformation":
                 
                         [{
                             "referenceType": "AFFIRMED",
                             "totalClaims": 20,
                             "asCaptured": "1–20",
                             "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                         }],
                 
                     "length": 3,
                 
                     "editMode": true,
                     "groundNo": null,
                     "referencesBasis": "Freeman, Kippola",
                     "reversed": "",
                     "statute": "103",
                     "statuteAsCaptured": "103"
                 
             };
             var rejection = {
                 "decisionBelongsTo": {
                   "coreIdentifier": "Appeal 2020-001678",
                   "supplementalIdentifier": "Application 15/540,978"
                 },
                 "referenceNotes": [
                   {
                     "identifier": "2",
                     "referenceText": " As discussed above, we do not reach this rejection.",
                     "referencedIdentifier": null
                   }
                 ],
                 "decisionSummary": {
                   "summaryDetails": null
                 },
                 "outComeDetails": [
                   {
                     "referenceRegulation": "103",
                     "claimInformation": [
                       {
                         "referenceType": "UNKNOWN",
                         "totalClaims": 20,
                         "asCaptured": "1–20",
                         "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                       },
                       {
                         "referenceType": "AFFIRMED",
                         "totalClaims": 20,
                         "asCaptured": "1–20",
                         "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                       },
                       {
                         "referenceType": "REVERSED",
                         "totalClaims": 0,
                         "asCaptured": "",
                         "expanded": ""
                       }
                     ],
                     "grounds": null,
                     "references": "Freeman, Kippola"
                   },
                   {
                     "referenceRegulation": "7-8",
                     "claimInformation": [
                       {
                         "referenceType": "UNKNOWN",
                         "totalClaims": 20,
                         "asCaptured": "1–20",
                         "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                       },
                       {
                         "referenceType": "AFFIRMED",
                         "totalClaims": 0,
                         "asCaptured": "",
                         "expanded": ""
                       },
                       {
                         "referenceType": "REVERSED",
                         "totalClaims": 0,
                         "asCaptured": "",
                         "expanded": ""
                       }
                     ],
                     "grounds": null,
                     "references": "Provisional Non-statutory Double Patenting[footnoteRef:2]"
                   }
                 ]
               }
             expect(scope.saveFooter ).toBeDefined();
             scope.saveFooter (footer);
           });

        it('should call saveRejectionClaim', function () {
           var rejectionEdit = {
                
                "affirmed": "1–20",
                "claimInformation":
            
                    [{
                        "referenceType": "AFFIRMED",
                        "totalClaims": 20,
                        "asCaptured": "1–20",
                        "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                    }],
            
                "length": 3,
            
                "editMode": true,
                "groundNo": null,
                "referencesBasis": "Freeman, Kippola",
                "reversed": "",
                "statute": "103",
                "statuteAsCaptured": "103"
            
        };
            scope.typeOfCase = "APPEAL";
            scope.rejectionEdit = {
                
                    "affirmed": "1–20",
                    "claimInformation":
                
                        [{
                            "referenceType": "AFFIRMED",
                            "totalClaims": 20,
                            "asCaptured": "1–20",
                            "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                        }],
                
                    "length": 3,
                
                    "editMode": true,
                    "groundNo": null,
                    "referencesBasis": "Freeman, Kippola",
                    "reversed": "",
                    "statute": "103",
                    "statuteAsCaptured": "103"
                
            };
            var rejection = {
                "decisionBelongsTo": {
                  "coreIdentifier": "Appeal 2020-001678",
                  "supplementalIdentifier": "Application 15/540,978"
                },
                "referenceNotes": [
                  {
                    "identifier": "2",
                    "referenceText": " As discussed above, we do not reach this rejection.",
                    "referencedIdentifier": null
                  }
                ],
                "decisionSummary": {
                  "summaryDetails": null
                },
                "outComeDetails": [
                  {
                    "referenceRegulation": "103",
                    "claimInformation": [
                      {
                        "referenceType": "UNKNOWN",
                        "totalClaims": 20,
                        "asCaptured": "1–20",
                        "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                      },
                      {
                        "referenceType": "AFFIRMED",
                        "totalClaims": 20,
                        "asCaptured": "1–20",
                        "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                      },
                      {
                        "referenceType": "REVERSED",
                        "totalClaims": 0,
                        "asCaptured": "",
                        "expanded": ""
                      }
                    ],
                    "grounds": null,
                    "references": "Freeman, Kippola"
                  },
                  {
                    "referenceRegulation": "7-8",
                    "claimInformation": [
                      {
                        "referenceType": "UNKNOWN",
                        "totalClaims": 20,
                        "asCaptured": "1–20",
                        "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                      },
                      {
                        "referenceType": "AFFIRMED",
                        "totalClaims": 0,
                        "asCaptured": "",
                        "expanded": ""
                      },
                      {
                        "referenceType": "REVERSED",
                        "totalClaims": 0,
                        "asCaptured": "",
                        "expanded": ""
                      }
                    ],
                    "grounds": null,
                    "references": "Provisional Non-statutory Double Patenting[footnoteRef:2]"
                  }
                ]
              }
            expect(scope.saveRejectionClaim).toBeDefined();
            scope.saveRejectionClaim(rejection);
          });

        it('should call cancelRejectionClaim  ', function () {
            var rejection = {
                "decisionBelongsTo": {
                  "coreIdentifier": "Appeal 2020-001678",
                  "supplementalIdentifier": "Application 15/540,978"
                },
                "referenceNotes": [
                  {
                    "identifier": "2",
                    "referenceText": " As discussed above, we do not reach this rejection.",
                    "referencedIdentifier": null
                  }
                ],
                "decisionSummary": {
                  "summaryDetails": null
                },
                "outComeDetails": [
                  {
                    "referenceRegulation": "103",
                    "claimInformation": [
                      {
                        "referenceType": "UNKNOWN",
                        "totalClaims": 20,
                        "asCaptured": "1–20",
                        "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                      },
                      {
                        "referenceType": "AFFIRMED",
                        "totalClaims": 20,
                        "asCaptured": "1–20",
                        "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                      },
                      {
                        "referenceType": "REVERSED",
                        "totalClaims": 0,
                        "asCaptured": "",
                        "expanded": ""
                      }
                    ],
                    "grounds": null,
                    "references": "Freeman, Kippola"
                  },
                  {
                    "referenceRegulation": "7-8",
                    "claimInformation": [
                      {
                        "referenceType": "UNKNOWN",
                        "totalClaims": 20,
                        "asCaptured": "1–20",
                        "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                      },
                      {
                        "referenceType": "AFFIRMED",
                        "totalClaims": 0,
                        "asCaptured": "",
                        "expanded": ""
                      },
                      {
                        "referenceType": "REVERSED",
                        "totalClaims": 0,
                        "asCaptured": "",
                        "expanded": ""
                      }
                    ],
                    "grounds": null,
                    "references": "Provisional Non-statutory Double Patenting[footnoteRef:2]"
                  }
                ]
              }
            expect(scope.cancelRejectionClaim).toBeDefined();
            scope.cancelRejectionClaim(rejection);
          });

          it('should call cancelFooter  ', function () {
var footer = {
  "claimInformation": [],
  "editMode": true,
  "editode": true,
  "groundNo": null,
  "referencesBasis": "",
  "statute": "120",
  "statuteAsCaptured": "1–20"
}
            // var footer = {
            //     "decisionBelongsTo": {
            //       "coreIdentifier": "Appeal 2020-001678",
            //       "supplementalIdentifier": "Application 15/540,978"
            //     },
            //     "referenceNotes": [
            //       {
            //         "identifier": "2",
            //         "referenceText": " As discussed above, we do not reach this rejection.",
            //         "referencedIdentifier": null
            //       }
            //     ],
            //     "decisionSummary": {
            //       "summaryDetails": null
            //     },
            //     "outComeDetails": [
            //       {
            //         "referenceRegulation": "103",
            //         "claimInformation": [
            //           {
            //             "referenceType": "UNKNOWN",
            //             "totalClaims": 20,
            //             "asCaptured": "1–20",
            //             "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
            //           },
            //           {
            //             "referenceType": "AFFIRMED",
            //             "totalClaims": 20,
            //             "asCaptured": "1–20",
            //             "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
            //           },
            //           {
            //             "referenceType": "REVERSED",
            //             "totalClaims": 0,
            //             "asCaptured": "",
            //             "expanded": ""
            //           }
            //         ],
            //         "grounds": null,
            //         "references": "Freeman, Kippola"
            //       },
            //       {
            //         "referenceRegulation": "7-8",
            //         "claimInformation": [
            //           {
            //             "referenceType": "UNKNOWN",
            //             "totalClaims": 20,
            //             "asCaptured": "1–20",
            //             "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
            //           },
            //           {
            //             "referenceType": "AFFIRMED",
            //             "totalClaims": 0,
            //             "asCaptured": "",
            //             "expanded": ""
            //           },
            //           {
            //             "referenceType": "REVERSED",
            //             "totalClaims": 0,
            //             "asCaptured": "",
            //             "expanded": ""
            //           }
            //         ],
            //         "grounds": null,
            //         "references": "Provisional Non-statutory Double Patenting[footnoteRef:2]"
            //       }
            //     ]
            //   }
            expect(scope.cancelFooter).toBeDefined();
            scope.cancelFooter(footer);
          });
          it('getLoggedInUserName failureResponse ', function () {
            var failureResponse = {
              data: {}
            };
            expect(controller.getLoggedInUserName).toBeDefined();
            controller.getLoggedInUserName();    
            HttpFactoryDeferred.reject(failureResponse);
            $rootScope.$apply();
          });

          it(' should call editRejectionClaim ', function () {
            var rejection = {
              "decisionBelongsTo": {
                "coreIdentifier": "Appeal 2020-001678",
                "supplementalIdentifier": "Application 15/540,978"
              },
              "referenceNotes": [
                {
                  "identifier": "2",
                  "referenceText": " As discussed above, we do not reach this rejection.",
                  "referencedIdentifier": null
                }
              ],
              "decisionSummary": {
                "summaryDetails": null
              },
              "outComeDetails": [
                {
                  "referenceRegulation": "103",
                  "claimInformation": [
                    {
                      "referenceType": "UNKNOWN",
                      "totalClaims": 20,
                      "asCaptured": "1–20",
                      "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                    },
                    {
                      "referenceType": "AFFIRMED",
                      "totalClaims": 20,
                      "asCaptured": "1–20",
                      "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                    },
                    {
                      "referenceType": "REVERSED",
                      "totalClaims": 0,
                      "asCaptured": "",
                      "expanded": ""
                    }
                  ],
                  "grounds": null,
                  "references": "Freeman, Kippola"
                },
                {
                  "referenceRegulation": "7-8",
                  "claimInformation": [
                    {
                      "referenceType": "UNKNOWN",
                      "totalClaims": 20,
                      "asCaptured": "1–20",
                      "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                    },
                    {
                      "referenceType": "AFFIRMED",
                      "totalClaims": 0,
                      "asCaptured": "",
                      "expanded": ""
                    },
                    {
                      "referenceType": "REVERSED",
                      "totalClaims": 0,
                      "asCaptured": "",
                      "expanded": ""
                    }
                  ],
                  "grounds": null,
                  "references": "Provisional Non-statutory Double Patenting[footnoteRef:2]"
                }
              ]
            }
            expect(scope.editRejectionClaim).toBeDefined();
            scope.editRejectionClaim(rejection);
          });


          it(' should call editRejectionClaim', function () {
            scope.rejectionEdit = false;
            var rejection = {
              "decisionBelongsTo": {
                "coreIdentifier": "Appeal 2020-001678",
                "supplementalIdentifier": "Application 15/540,978"
              },
              "referenceNotes": [
                {
                  "identifier": "2",
                  "referenceText": " As discussed above, we do not reach this rejection.",
                  "referencedIdentifier": null
                }
              ],
              "decisionSummary": {
                "summaryDetails": null
              },
              "outComeDetails": [
                {
                  "referenceRegulation": "103",
                  "claimInformation": [
                    {
                      "referenceType": "UNKNOWN",
                      "totalClaims": 20,
                      "asCaptured": "1–20",
                      "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                    },
                    {
                      "referenceType": "AFFIRMED",
                      "totalClaims": 20,
                      "asCaptured": "1–20",
                      "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                    },
                    {
                      "referenceType": "REVERSED",
                      "totalClaims": 0,
                      "asCaptured": "",
                      "expanded": ""
                    }
                  ],
                  "grounds": null,
                  "references": "Freeman, Kippola"
                },
                {
                  "referenceRegulation": "7-8",
                  "claimInformation": [
                    {
                      "referenceType": "UNKNOWN",
                      "totalClaims": 20,
                      "asCaptured": "1–20",
                      "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                    },
                    {
                      "referenceType": "AFFIRMED",
                      "totalClaims": 0,
                      "asCaptured": "",
                      "expanded": ""
                    },
                    {
                      "referenceType": "REVERSED",
                      "totalClaims": 0,
                      "asCaptured": "",
                      "expanded": ""
                    }
                  ],
                  "grounds": null,
                  "references": "Provisional Non-statutory Double Patenting[footnoteRef:2]"
                }
              ]
            }
            expect(scope.editRejectionClaim).toBeDefined();
            scope.editRejectionClaim(rejection);
          });

          it(' should call editRejectionClaim', function () {
            scope.rejectionEdit = false;
            var rejection = {
              "decisionBelongsTo": {
                "coreIdentifier": "Appeal 2020-001678",
                "supplementalIdentifier": "Application 15/540,978"
              },
              "referenceNotes": [
                {
                  "identifier": "2",
                  "referenceText": " As discussed above, we do not reach this rejection.",
                  "referencedIdentifier": null
                }
              ],
              "decisionSummary": {
                "summaryDetails": null
              },
              "outComeDetails": [
                {
                  "referenceRegulation": "103",
                  "claimInformation": [
                    {
                      "referenceType": "UNKNOWN",
                      "totalClaims": 20,
                      "asCaptured": "1–20",
                      "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                    },
                    {
                      "referenceType": "AFFIRMED",
                      "totalClaims": 20,
                      "asCaptured": "1–20",
                      "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                    },
                    {
                      "referenceType": "REVERSED",
                      "totalClaims": 0,
                      "asCaptured": "",
                      "expanded": ""
                    }
                  ],
                  "grounds": null,
                  "references": "Freeman, Kippola"
                },
                {
                  "referenceRegulation": "7-8",
                  "claimInformation": [
                    {
                      "referenceType": "UNKNOWN",
                      "totalClaims": 20,
                      "asCaptured": "1–20",
                      "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
                    },
                    {
                      "referenceType": "AFFIRMED",
                      "totalClaims": 0,
                      "asCaptured": "",
                      "expanded": ""
                    },
                    {
                      "referenceType": "REVERSED",
                      "totalClaims": 0,
                      "asCaptured": "",
                      "expanded": ""
                    }
                  ],
                  "grounds": null,
                  "references": "Provisional Non-statutory Double Patenting[footnoteRef:2]"
                }
              ]
            }
            expect(scope.editRejectionClaim).toBeDefined();
            scope.editRejectionClaim(rejection);
          });

        //   it(' should call saveRejectionClaim', function () {
        //     var rejection = {
        //       "decisionBelongsTo": {
        //         "coreIdentifier": "Appeal 2020-001678",
        //         "supplementalIdentifier": "Application 15/540,978"
        //       },
        //       "referenceNotes": [
        //         {
        //           "identifier": "2",
        //           "referenceText": " As discussed above, we do not reach this rejection.",
        //           "referencedIdentifier": null
        //         }
        //       ],
        //       "decisionSummary": {
        //         "summaryDetails": null
        //       },
        //       "outComeDetails": [
        //         {
        //           "referenceRegulation": "103",
        //           "claimInformation": [
        //             {
        //               "referenceType": "UNKNOWN",
        //               "totalClaims": 20,
        //               "asCaptured": "1–20",
        //               "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
        //             },
        //             {
        //               "referenceType": "AFFIRMED",
        //               "totalClaims": 20,
        //               "asCaptured": "1–20",
        //               "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
        //             },
        //             {
        //               "referenceType": "REVERSED",
        //               "totalClaims": 0,
        //               "asCaptured": "",
        //               "expanded": ""
        //             }
        //           ],
        //           "grounds": null,
        //           "references": "Freeman, Kippola"
        //         },
        //         {
        //           "referenceRegulation": "7-8",
        //           "claimInformation": [
        //             {
        //               "referenceType": "UNKNOWN",
        //               "totalClaims": 20,
        //               "asCaptured": "1–20",
        //               "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
        //             },
        //             {
        //               "referenceType": "AFFIRMED",
        //               "totalClaims": 0,
        //               "asCaptured": "",
        //               "expanded": ""
        //             },
        //             {
        //               "referenceType": "REVERSED",
        //               "totalClaims": 0,
        //               "asCaptured": "",
        //               "expanded": ""
        //             }
        //           ],
        //           "grounds": null,
        //           "references": "Provisional Non-statutory Double Patenting[footnoteRef:2]"
        //         }
        //       ]
        //     }
        //     expect(scope.saveRejectionClaim).toBeDefined();
        //     scope.saveRejectionClaim(rejection);
        //   });
        
        // it('should call useanotherpdf', function () {
        //   expect(scope.useanotherpdf ).toBeDefined();
        //   scope.useanotherpdf();
        // });
        // it('should call dispFile ', function () {
        //   var file = {
        //     currentTarget: {
        //       files: [{
        //         name: "file"
        //       }]
        //     }
        //   }
        //   var event;
        //   expect(scope.dispFile).toBeDefined();
        //   scope.dispFile(file, event);
  
        // });
  
        // it('should call dispFile ', function () {
        //   var file = {
        //     currentTarget: {
        //       files: [{
        //         name: undefined
        //       }]
        //     }
        //   }
        //   var event;
        //   scope.errorMessage = false;
        //   expect(scope.dispFile).toBeDefined();
        //   scope.dispFile(file, event);
  
        // });
  
  
        // it('should call openCommentsNotesModal ', function () {
        //   expect(scope.openCommentsNotesModal).toBeDefined();
        //   scope.openCommentsNotesModal();
        // });
  
        // // it('should call selectHearingStatus ', function () {
        // //   controller.hearingStatusIndicator = true;
        // //   expect(scope.selectHearingStatus).toBeDefined();
        // //   scope.selectHearingStatus();
        // // });
  
        // it('should call checkForHearingStatusIndicator ', function () {
        //   expect(scope.checkForHearingStatusIndicator).toBeDefined();
        //   scope.checkForHearingStatusIndicator();
        // });
  
        // it('should call enableUploadButton ', function () {
        //   expect(scope.enableUploadButton).toBeDefined();
        //   scope.enableUploadButton();
        // });
  
      });
    });
  })();
  