

'use strict';
/**
 * Grid utilities directive.  Displays save grid pref and number of filters.  Can be expanded.
 */
angular.module('ptabe2e').directive('gridUtilities', function () {

  return {
    restrict: 'E',
    templateUrl: 'app/judgePortal/gridUtilities.html',
    scope: {
        saveGridPreferences: '=?',
        numberOfFilters: '=?',
        preferencesChanged: '=?'
    },
    controller: 'gridUtilitiesDirectiveController',
    controllerAs: 'vm',
    bindToController: true
  };

});
