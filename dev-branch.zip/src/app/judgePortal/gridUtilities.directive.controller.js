'use strict';
/**
 * Grid utilities controller.  This is an angular element directive
 */
angular.module('ptabe2e').controller(
  'gridUtilitiesDirectiveController',
  function () {
    var vm = this;
    vm.saveGrid = function () {
      if (vm.saveGridPreferences) {
        vm.saveGridPreferences();
      }
    };
 });
