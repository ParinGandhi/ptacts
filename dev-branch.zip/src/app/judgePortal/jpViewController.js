"use strict";
angular
  .module('ptabe2e')
  .controller('JpviewController',
    function (HttpFactory, $log, $scope, $timeout, $route, $window, CONSTANTS, $filter, CommonHelperService,$interval) {
      var vm = this;
      var loggedInUser = null;
      var activeWorkspace = null;
      var timeout = null;

      $scope.originalJudgePortalData = {};
      $scope.openCases = {};
      $scope.closedCases = {};
      $scope.apj1Cases = {};
      $scope.apj2PlusCases = {};
      $scope.filterredData = null;
      $scope.originalFilterredData = null;
      $scope.filterObj = {};
      $scope.orderByField = [];
      $scope.filterLength = 0;
      var typesArray = ['caseDetailsData','institutionDecision','finalDecision','notInstituted','rehearingDecision',
      'terminationdismissed','courtdecision','termination','trialCertificateIssued'];
      vm.showNoClosedCasesMsg = false;
      vm.workspaces = [];
      vm.Closedcase;
      vm.apj1Case = true;
      vm.activeTabIndex=0;
      vm.apj2Cases;
      $scope.limitNumber=500;
      var promise;
      $scope.finishedLoading =false;



      /** Function called when page is loaded. Used to set global values */
      vm.loadJudgePortal = function (userInfo) {
        vm.currentLoggedInRoleIsAdmin = userInfo.appUserInfo[0].roleDescription === CONSTANTS.ROLES.ADMIN;
        vm.caseNumber = $route.current.params.caseNumber;
        vm.applicationNumber = $route.current.params.applicationNumber;
        vm.userId = $window.sessionStorage.getItem("workerNumber");
        $window.document.title = "JP View - P-TACTS";
        getLoggedInUserName();
      };

      /** Function to get the logged in user name */
      function getLoggedInUserName() {
        HttpFactory.getActions(CONSTANTS.URL.USERMANAGEMENT + "?loginId=" + vm.userId)
          .then(function (userNameSuccess) {
            loggedInUser = userNameSuccess.data.caseDetailsData[0].fullName.trim();
            $scope.getJudgePortalData();
          }, function (userNameFailure) {
            console.info("Failed to retrieve user name", userNameFailure);
            return null;
          });
      }


      $scope.getJudgePortalData = function () {
        HttpFactory.getActions('/mixed-case-dockets/docket_details/open/' + vm.userId)
          .then(function (successResponse) {
              if (angular.isDefined(successResponse.data)) {
                $scope.originalJudgePortalData = successResponse.data;
                filterDate($scope.originalJudgePortalData);
                $scope.openCases = angular.copy($scope.originalJudgePortalData);
                buildJPView();
                setUpTabs();
                //getClosedCases();
              }
            },
            function (failureResponse) {
              $log.debug(failureResponse);
              /* istanbul ignore if: toaster error  */
              if (failureResponse.status === 404) {
                CommonHelperService.setToastr(failureResponse.data.message, "info");
              }
            });
      };

      function setUpTabs() {
        $scope.apj1Cases = getAPJ1Cases($scope.originalJudgePortalData);
        $scope.apj2PlusCases = getAPJ2PlusCases($scope.originalJudgePortalData);
        $scope.limitNumber =800;
        $timeout(function() {
          $scope.updateOrderByField('PROCEEDING_NO');
        }, 1500);

        $scope.filterredData = vm.currentLoggedInRoleIsAdmin ? angular.copy($scope.openCases) : angular.copy($scope.apj1Cases);
        setLimit();
        $scope.originalFilterredData = angular.copy($scope.filterredData)
        setTabCount();
      }

      function getClosedCases(selectedTab) {
        HttpFactory.getActions('/mixed-case-dockets/docket_details/closed/' + vm.userId)
          .then(function (successResponse) {
              if (angular.isDefined(successResponse.data)) {
                $scope.closedClasesLoaded=true;
                try {
                  vm.showNoClosedCasesMsg = successResponse.data.columnDetails.length === 0;
                } catch (error) {
                  $log.debug(error);
                }
                filterDate(successResponse.data)
                $scope.closedCases = successResponse.data;
                $scope.closedCases.columnDetails[8].columnLabel = "Disposition dates";
                
              }

              vm.selectTab(selectedTab);
              $scope.filterredData = angular.copy($scope.closedCases);

              $scope.originalFilterredData = angular.copy($scope.filterredData)
              setTabCount();
            },
            function (failureResponse) {
              $log.debug(failureResponse);
              /* istanbul ignore if: toaster error  */
              if (failureResponse.status === 404) {
                CommonHelperService.setToastr(failureResponse.data.message, "info");
              }
            }).finally(function () {
   /*          $scope.apj1Cases = getAPJ1Cases($scope.originalJudgePortalData);
            $scope.apj2PlusCases = getAPJ2PlusCases($scope.originalJudgePortalData);
            $scope.limitNumber =800;
            $timeout(function() {
              $scope.updateOrderByField('PROCEEDING_NO');
              
            }, 1500);
             
      
            $scope.filterredData = vm.currentLoggedInRoleIsAdmin ? angular.copy($scope.openCases) : angular.copy($scope.apj1Cases);
            setLimit();
            $scope.originalFilterredData = angular.copy($scope.filterredData)
            setTabCount(); */
         
          });
      }



      function setTabCount() {
        vm.workspaces[0].count = vm.currentLoggedInRoleIsAdmin ? $scope.openCases.caseDetailsData.length : $scope.apj1Cases.caseDetailsData.length;
        vm.workspaces[1].count = vm.currentLoggedInRoleIsAdmin ? $scope.closedCases.caseDetailsData.length : $scope.apj2PlusCases.caseDetailsData.length;
        vm.allCasesCount = $scope.apj1Cases.caseDetailsData.length;
        vm.finalCount = $scope.apj1Cases.finalDecision.length;
        vm.InstitutionCount =  $scope.apj1Cases.institutionDecision.length;
        // vm.allCasesCount = vm.currentLoggedInRoleIsAdmin ? $scope.closedCases.caseDetailsData.length : $scope.apj2PlusCases.caseDetailsData.length;
        // vm.allCasesCount = $scope.closedCases.caseDetailsData.length;
      }


      /** Function to get all APJ1 cases for Judge role */
      function getAPJ1Cases(data) {
        
        var apj1TempCases = angular.copy(data);
      
        typesArray.forEach(function(each){
          apj1TempCases[each]=[];
          if(data && data[each]){
            
          for (var i = 0; i < data[each].length; i++) {
            if (data[each][i].APJ1_WORKER_ID && data[each][i].APJ1_WORKER_ID.trim() === loggedInUser) {
              apj1TempCases[each].push(data[each][i]);
            }
          }
        }})
      
        // for (var i = 0; i < $scope.originalJudgePortalData.caseDetailsData.length; i++) {
        //   if ($scope.originalJudgePortalData.caseDetailsData[i].APJ1_WORKER_ID && $scope.originalJudgePortalData.caseDetailsData[i].APJ1_WORKER_ID.trim() === loggedInUser) {
        //     apj1TempCases.caseDetailsData.push($scope.originalJudgePortalData.caseDetailsData[i]);
        //   }
        // }
        // for (var i = 0; i < $scope.originalJudgePortalData.institutionDecision.length; i++) {
        //   if ($scope.originalJudgePortalData.institutionDecision[i].APJ1_WORKER_ID && $scope.originalJudgePortalData.institutionDecision[i].APJ1_WORKER_ID.trim() === loggedInUser) {
        //     apj1TempCases.institutionDecision.push($scope.originalJudgePortalData.caseDetailsData[i]);
        //   }
        // }
        // for (var i = 0; i < $scope.originalJudgePortalData.finalDecision.length; i++) {
        //   if ($scope.originalJudgePortalData.finalDecision[i].APJ1_WORKER_ID && $scope.originalJudgePortalData.finalDecision[i].APJ1_WORKER_ID.trim() === loggedInUser) {
        //     apj1TempCases.finalDecision.push($scope.originalJudgePortalData.caseDetailsData[i]);
        //   }
        // }
        return apj1TempCases;
      }


      /** Function to get all APJ2+ cases for judge role */
      function getAPJ2PlusCases(data) {
        var apj2PlusTempCases = angular.copy(data);
        typesArray.forEach(function(each){
          apj2PlusTempCases[each]=[];
          if(data && data[each]){
            for (var i = 0; i < data[each].length; i++) {
              apj2PlusTempCases[each] = matchApjWithUser(data[each][i].APJ2_WORKER_ID, apj2PlusTempCases[each], data.caseDetailsData[i]);
              apj2PlusTempCases[each] = matchApjWithUser(data[each][i].APJ3_WORKER_ID, apj2PlusTempCases[each], data.caseDetailsData[i]);
              apj2PlusTempCases[each] = matchApjWithUser(data[each][i].APJ4_WORKER_ID, apj2PlusTempCases[each], data.caseDetailsData[i]);
               apj2PlusTempCases[each] = matchApjWithUser(data[each][i].APJ5_WORKER_ID, apj2PlusTempCases[each], data.caseDetailsData[i]);
               apj2PlusTempCases[each] = matchApjWithUser(data[each][i].APJ6_WORKER_ID, apj2PlusTempCases[each], data.caseDetailsData[i]);
               apj2PlusTempCases[each] = matchApjWithUser(data[each][i].APJ7_WORKER_ID, apj2PlusTempCases[each], data.caseDetailsData[i]);
               apj2PlusTempCases[each] = matchApjWithUser(data[each][i].APJ8_WORKER_ID, apj2PlusTempCases[each], data.caseDetailsData[i]);
               apj2PlusTempCases[each] = matchApjWithUser(data[each][i].APJ9_WORKER_ID, apj2PlusTempCases[each], data.caseDetailsData[i]);
            }
          }})
  
        // if ($scope.originalJudgePortalData) {
        //   for (var i = 0; i < $scope.originalJudgePortalData.caseDetailsData.length; i++) {
        //     apj2PlusTempCases.caseDetailsData = matchApjWithUser($scope.originalJudgePortalData.caseDetailsData[i].APJ2_WORKER_ID, apj2PlusTempCases.caseDetailsData, $scope.originalJudgePortalData.caseDetailsData[i]);
        //     apj2PlusTempCases.caseDetailsData = matchApjWithUser($scope.originalJudgePortalData.caseDetailsData[i].APJ3_WORKER_ID, apj2PlusTempCases.caseDetailsData, $scope.originalJudgePortalData.caseDetailsData[i]);
        //     apj2PlusTempCases.caseDetailsData = matchApjWithUser($scope.originalJudgePortalData.caseDetailsData[i].APJ4_WORKER_ID, apj2PlusTempCases.caseDetailsData, $scope.originalJudgePortalData.caseDetailsData[i]);
        //     apj2PlusTempCases.caseDetailsData = matchApjWithUser($scope.originalJudgePortalData.caseDetailsData[i].APJ5_WORKER_ID, apj2PlusTempCases.caseDetailsData, $scope.originalJudgePortalData.caseDetailsData[i]);
        //     apj2PlusTempCases.caseDetailsData = matchApjWithUser($scope.originalJudgePortalData.caseDetailsData[i].APJ6_WORKER_ID, apj2PlusTempCases.caseDetailsData, $scope.originalJudgePortalData.caseDetailsData[i]);
        //     apj2PlusTempCases.caseDetailsData = matchApjWithUser($scope.originalJudgePortalData.caseDetailsData[i].APJ7_WORKER_ID, apj2PlusTempCases.caseDetailsData, $scope.originalJudgePortalData.caseDetailsData[i]);
        //     apj2PlusTempCases.caseDetailsData = matchApjWithUser($scope.originalJudgePortalData.caseDetailsData[i].APJ8_WORKER_ID, apj2PlusTempCases.caseDetailsData, $scope.originalJudgePortalData.caseDetailsData[i]);
        //     apj2PlusTempCases.caseDetailsData = matchApjWithUser($scope.originalJudgePortalData.caseDetailsData[i].APJ9_WORKER_ID, apj2PlusTempCases.caseDetailsData, $scope.originalJudgePortalData.caseDetailsData[i]);
        //   }
        //   for (var i = 0; i < $scope.originalJudgePortalData.institutionDecision.length; i++) {
        //     apj2PlusTempCases.institutionDecision = matchApjWithUser($scope.originalJudgePortalData.institutionDecision[i].APJ2_WORKER_ID, apj2PlusTempCases.institutionDecision, $scope.originalJudgePortalData.institutionDecision[i]);
        //     apj2PlusTempCases.institutionDecision = matchApjWithUser($scope.originalJudgePortalData.institutionDecision[i].APJ3_WORKER_ID, apj2PlusTempCases.institutionDecision, $scope.originalJudgePortalData.institutionDecision[i]);
        //     apj2PlusTempCases.institutionDecision = matchApjWithUser($scope.originalJudgePortalData.institutionDecision[i].APJ4_WORKER_ID, apj2PlusTempCases.institutionDecision, $scope.originalJudgePortalData.institutionDecision[i]);
        //     apj2PlusTempCases.institutionDecision = matchApjWithUser($scope.originalJudgePortalData.institutionDecision[i].APJ5_WORKER_ID, apj2PlusTempCases.institutionDecision, $scope.originalJudgePortalData.institutionDecision[i]);
        //     apj2PlusTempCases.institutionDecision = matchApjWithUser($scope.originalJudgePortalData.institutionDecision[i].APJ6_WORKER_ID, apj2PlusTempCases.institutionDecision, $scope.originalJudgePortalData.institutionDecision[i]);
        //     apj2PlusTempCases.institutionDecision = matchApjWithUser($scope.originalJudgePortalData.institutionDecision[i].APJ7_WORKER_ID, apj2PlusTempCases.institutionDecision, $scope.originalJudgePortalData.institutionDecision[i]);
        //     apj2PlusTempCases.institutionDecision = matchApjWithUser($scope.originalJudgePortalData.institutionDecision[i].APJ8_WORKER_ID, apj2PlusTempCases.institutionDecision, $scope.originalJudgePortalData.institutionDecision[i]);
        //     apj2PlusTempCases.institutionDecision = matchApjWithUser($scope.originalJudgePortalData.institutionDecision[i].APJ9_WORKER_ID, apj2PlusTempCases.institutionDecision, $scope.originalJudgePortalData.institutionDecision[i]);
        //   }
        //   for (var i = 0; i < $scope.originalJudgePortalData.finalDecision.length; i++) {
        //     apj2PlusTempCases.finalDecision = matchApjWithUser($scope.originalJudgePortalData.finalDecision[i].APJ2_WORKER_ID, apj2PlusTempCases.finalDecision, $scope.originalJudgePortalData.finalDecision[i]);
        //     apj2PlusTempCases.finalDecision = matchApjWithUser($scope.originalJudgePortalData.finalDecision[i].APJ3_WORKER_ID, apj2PlusTempCases.finalDecision, $scope.originalJudgePortalData.finalDecision[i]);
        //     apj2PlusTempCases.finalDecision = matchApjWithUser($scope.originalJudgePortalData.finalDecision[i].APJ4_WORKER_ID, apj2PlusTempCases.finalDecision, $scope.originalJudgePortalData.finalDecision[i]);
        //     apj2PlusTempCases.finalDecision = matchApjWithUser($scope.originalJudgePortalData.finalDecision[i].APJ5_WORKER_ID, apj2PlusTempCases.finalDecision, $scope.originalJudgePortalData.finalDecision[i]);
        //     apj2PlusTempCases.finalDecision = matchApjWithUser($scope.originalJudgePortalData.finalDecision[i].APJ6_WORKER_ID, apj2PlusTempCases.finalDecision, $scope.originalJudgePortalData.finalDecision[i]);
        //     apj2PlusTempCases.finalDecision = matchApjWithUser($scope.originalJudgePortalData.finalDecision[i].APJ7_WORKER_ID, apj2PlusTempCases.finalDecision, $scope.originalJudgePortalData.finalDecision[i]);
        //     apj2PlusTempCases.finalDecision = matchApjWithUser($scope.originalJudgePortalData.finalDecision[i].APJ8_WORKER_ID, apj2PlusTempCases.finalDecision, $scope.originalJudgePortalData.finalDecision[i]);
        //     apj2PlusTempCases.finalDecision = matchApjWithUser($scope.originalJudgePortalData.finalDecision[i].APJ9_WORKER_ID, apj2PlusTempCases.finalDecision, $scope.originalJudgePortalData.finalDecision[i]);
        //   }
        // }
        return apj2PlusTempCases;
      }


      /** Function used to get cases where logged in user is an APJ2 - APJ9 */
      function matchApjWithUser(apj, tempCases, currentCase) {
        if (apj && apj.trim() === loggedInUser) {
          tempCases.push(currentCase);
        }
        return tempCases;
      }
function checkEmpty(value){
  if(value && value !=""){
    return value;
  }
  return "";
}

      /** This function will convert the date from epoch to human readable format */
      function filterDate(data) {
        data.caseDetailsData.forEach(function (each) {
          if (each.PROCEEDING_FILING_DT && each.PROCEEDING_FILING_DT != "") {
            each.PROCEEDING_FILING_DT_STRING = $filter('date')(each.PROCEEDING_FILING_DT, 'MM/dd/yyyy');
          }  else {
            each.PROCEEDING_FILING_DT_STRING = "";
          }

           if (each.INSTITUTION_DECISION_DT && each.INSTITUTION_DECISION_DT != "") {
            each.INSTITUTION_DECISION_DT_STRING = $filter('date')(each.INSTITUTION_DECISION_DT, 'MM/dd/yyyy');
          } else{
            each.INSTITUTION_DECISION_DT_STRING ="";
          }
          if(each.ADDITIONAL_APJ_WORKER_ID_TX && each.ADDITIONAL_APJ_WORKER_ID_TX != ""){
            each.APJ_STRING = checkEmpty(each.APJ1_WORKER_ID)+ " "+ checkEmpty(each.APJ2_WORKER_ID)+" "+ checkEmpty(each.APJ3_WORKER_ID)
          }else{
            each.APJ_STRING ="";
          }


          setDueDate(each)
        })
      }


      /** This function will set the due date string for each case */
      function setDueDate(each) {
        if (each.PROCEEDING_TYPE_CT == 'TRIAL') {
          if (each.DECISION_DUE_DAYS != null && each.INSTITUTION_DECISION_DT != null && each.PROCEEDING_TYPE_CT == 'TRIAL' && each.PROCEEDING_STATUTORY_DT != null &&
            each.DECISION_DUE_DAYS < 90 && each.DECISION_DUE_DAYS >= 30) {
            each.APPEAL_SEQUENCE_NO = each.PROCEEDING_STATUTORY_DT;
          }
          if (each.DECISION_DUE_DAYS != null && each.INSTITUTION_DECISION_DT != null && each.PROCEEDING_TYPE_CT == 'TRIAL' &&
            each.PROCEEDING_STATUTORY_DT != null && each.DECISION_DUE_DAYS < 30 && each.DECISION_DUE_DAYS >= 0) {
            each.APPEAL_SEQUENCE_NO = each.PROCEEDING_STATUTORY_DT;
          }
          if (each.DECISION_DUE_DAYS != null && each.INSTITUTION_DECISION_DT != null && each.PROCEEDING_TYPE_CT == 'TRIAL' &&
            each.PROCEEDING_STATUTORY_DT != null && each.DECISION_DUE_DAYS < 0) {
            each.APPEAL_SEQUENCE_NO = each.PROCEEDING_STATUTORY_DT;
          }
          if (each.DECISION_DUE_DAYS != null && each.INSTITUTION_DECISION_DT == null && each.PROCEEDING_TYPE_CT == 'TRIAL' && each.PROCEEDING_STATUTORY_DT != null &&
            each.DECISION_DUE_DAYS < 60 && each.DECISION_DUE_DAYS >= 30) {
            each.APPEAL_SEQUENCE_NO = each.PROCEEDING_STATUTORY_DT;
          }
          if (each.DECISION_DUE_DAYS != null && each.INSTITUTION_DECISION_DT == null &&
            each.PROCEEDING_TYPE_CT == 'TRIAL' && each.PROCEEDING_STATUTORY_DT != null && each.DECISION_DUE_DAYS < 30 &&
            each.DECISION_DUE_DAYS >= 0) {
            each.APPEAL_SEQUENCE_NO = each.statutoryDateMinusYear;
          }
          if (each.DECISION_DUE_DAYS != null && each.INSTITUTION_DECISION_DT == null &&
            each.PROCEEDING_TYPE_CT == 'TRIAL' && each.PROCEEDING_STATUTORY_DT != null && each.DECISION_DUE_DAYS < 30 &&
            each.DECISION_DUE_DAYS >= 0) {
            each.APPEAL_SEQUENCE_NO = each.statutoryDateMinusYear;
          }
          if (each.DECISION_DUE_DAYS != null && each.INSTITUTION_DECISION_DT == null && each.PROCEEDING_TYPE_CT == 'TRIAL' &&
            each.PROCEEDING_STATUTORY_DT != null && each.DECISION_DUE_DAYS < 0) {
            each.APPEAL_SEQUENCE_NO = each.statutoryDateMinusYear;
          }
        }
      }


      function buildJPView() {
        var workspace1 = {
          currentWorkspaceOrderNumber: 0,
          value: 0,
          defaultIndicator: true,
          structure: "12",
          userWorkspaceName: vm.currentLoggedInRoleIsAdmin ? "Open cases" : "AIA Trials - APJ1 docket",
          userWorkspaceIdentifier: vm.currentLoggedInRoleIsAdmin ? "openCases" : "apj1Cases",
          active: 'active'
        };
        workspace1.tooltip = workspace1.userWorkspaceName.replace(/&nbsp;/g, " ");
        vm.workspaces.push(workspace1);
        var workspace2 = {
          currentWorkspaceOrderNumber: 1,
          value: 1,
          defaultIndicator: false,
          structure: "12",
          userWorkspaceName: vm.currentLoggedInRoleIsAdmin ? "Closed cases" : "AIA Trials - APJ2+ docket",
          userWorkspaceIdentifier: vm.currentLoggedInRoleIsAdmin ? "closedCases" : "apj2PlusCases",
          active: 'non-active'
        };
        workspace2.tooltip = workspace2.userWorkspaceName.replace(/&nbsp;/g, " ");
        vm.workspaces.push(workspace2);
        activeWorkspace = vm.workspaces[0];
        var workspace3 = {
          currentWorkspaceOrderNumber: 2,
          value: 2,
          defaultIndicator: false,
          structure: "12",
          userWorkspaceName:vm.currentLoggedInRoleIsAdmin?"Closed cases": "My closed cases",
          userWorkspaceIdentifier: "closedCases",
          active: 'non-active'
        };
        workspace3.tooltip = workspace3.userWorkspaceName.replace(/&nbsp;/g, " ");
        if(!vm.currentLoggedInRoleIsAdmin ) {
          vm.workspaces.push(workspace3);
        }
        
      }

      function setLimit() {
        promise =  $interval(function callAtInterval() {
          $scope.finishedLoading=false;
     if($scope.limitNumber < $scope.filterredData.caseDetailsData.length && $scope.limitNumber > 7){
       var initCount =$scope.limitNumber + Math.trunc($scope.filterredData.caseDetailsData.length/7);
        $scope.limitNumber = (initCount >$scope.filterredData.caseDetailsData.length)?$scope.filterredData.caseDetailsData.length:initCount;
     }else{
      $scope.limitNumber = $scope.filterredData.caseDetailsData.length;
      $interval.cancel(promise);
      $scope.finishedLoading=true;
     }

        
     },1000)

       
     }
     $scope.increaseLimit=function(){
      $timeout(function() {
        if($scope.limitNumber<$scope.filterredData.caseDetailsData.length){
          $scope.limitNumber = $scope.limitNumber + 800;
        }
        
      }, 500);
     }

     $scope.finished=function(){
$scope.finishedLoading=true;
//$scope.updateOrderByField($scope.filterredData.columnDetails.columnName[0]);

     }

     vm.all = function (currentIdentifier)  {
      $scope.filterredData = $scope[currentIdentifier];
      $scope.filterredData.caseDetailsData = angular.copy($scope.originalFilterredData.caseDetailsData);
     }

      vm.selectTab = function (currentTab) {
        if (currentTab.userWorkspaceIdentifier==="closedCases" && !$scope.closedClasesLoaded) {
          getClosedCases(currentTab);
          return;
        }
        $scope.limitNumber=800;
        $timeout(function() {
          currentTab.userWorkspaceIdentifier == 'closedCases'?$scope.updateOrderByField('PROCEEDING_FILING_DT'):$scope.updateOrderByField('PROCEEDING_NO');
          
        }, 500);
        
        $scope.searchTextt = "";
       // document.getElementById('searchforGlobal').value="";
        $scope.orderByField = [];
        $scope.filterObj={};
        $scope.filterLength = 0;
        
        $scope.filterredData = angular.copy($scope[currentTab.userWorkspaceIdentifier]);
        $scope.originalFilterredData = angular.copy($scope.filterredData)
        if(currentTab.userWorkspaceIdentifier == 'closedCases'){
          $scope.filterredData = vm.currentLoggedInRoleIsAdmin?$scope.originalFilterredData:getAPJ1Cases($scope.originalFilterredData);
          vm.selectedClosedValue={'displayName':vm.currentLoggedInRoleIsAdmin?'All cases':'APJ1 cases','modelName':vm.currentLoggedInRoleIsAdmin?'originalFilterredData':'apj1CasesClosed'};
          vm.selectedClosedValue.length = $scope.filterredData.caseDetailsData.length;
      
          
        }
        for (var i = 0; i < vm.workspaces.length; i++) {
          vm.workspaces[i].active = "non-active";
          vm.workspaces[i].activeInd = null;
        }
        activeWorkspace = currentTab;
        vm.workspaces[activeWorkspace.currentWorkspaceOrderNumber].active = "active";
        vm.workspaces[activeWorkspace.currentWorkspaceOrderNumber].activeInd = true;
        vm.workspaceOrderChanged = true;
        vm.tab = 'activeTab' + activeWorkspace.currentWorkspaceOrderNumber;
        vm.activeTabIndex = activeWorkspace.currentWorkspaceOrderNumber;
        if(currentTab.userWorkspaceIdentifier === "apj2PlusCases" || currentTab.userWorkspaceIdentifier === "apj1Cases") {
           vm.Closedcase = false;
          //  vm.apj1Case = true;
           if(currentTab.userWorkspaceIdentifier === "apj1Cases" ) {
             vm.apj1Case = true;
             vm.apj2Cases = false;
            vm.allApj1Count = $scope.apj1Cases.caseDetailsData.length;
            vm.finalCount = $scope.apj1Cases.finalDecision.length;
            vm.InstitutionCount =  $scope.apj1Cases.institutionDecision.length;
           }else {
             vm.apj2Cases = true;
             vm.apj1Case = false;
            vm.allCasesCount = $scope.apj2PlusCases.caseDetailsData.length;
            vm.finalCount = $scope.apj2PlusCases.finalDecision.length;
            vm.InstitutionCount = $scope.apj2PlusCases.institutionDecision.length;
           }
        } else {
          
          vm.Closedcase = true;
          vm.apj1Case = false;
          vm.apj2Cases = false;
          vm.allClosedCount = $scope.closedCases.caseDetailsData.length;
          vm.notInstiCount = $scope.closedCases.notInstituted.length;
          vm.rehearingCount = $scope.closedCases.rehearingDecision.length;
          vm.terminationCount = $scope.closedCases.termination.length;
          vm.dismissedCount = $scope.closedCases.dismissed.length;
          vm.courtCount = $scope.closedCases.courtDecision.length;
          vm.trialCount = $scope.closedCases.trialCertificateIssued.length;
          
        }
        setLimit();
      };

      $scope.updateFileteredData = function(obj){
        if(obj.modelName == 'apj1CasesClosed'){
          $scope.filterredData = getAPJ1Cases($scope.originalFilterredData);
          
        } else
        if(obj.modelName == 'apj2PlusCasesClosed'){
          $scope.filterredData = getAPJ2PlusCases($scope.originalFilterredData);
        } else{
          $scope.filterredData = angular.copy($scope[obj.modelName]);
        }
        vm.selectedClosedValue.length = $scope.filterredData.caseDetailsData.length;
vm.selectedClosedValue.displayName =obj.displayName;

      }

    $scope.getCases = function(type,subtype) {
       $scope.filterredData.caseDetailsData  = angular.copy($scope[type][subtype]);
       setLimit();
    }

      $scope.updateOrderByField = function (field) {

        !$scope.orderByField.includes(field) ?  $scope.correctOrder(field) :  $scope.correctOrder('-'+field) ;

          $scope.orderByField = !$scope.orderByField.includes(field) ? [field] : ['-' + field];
       
         
      
        
          if(promise){
            $interval.cancel(promise);
          }
        $timeout(function(){
          setLimit();
        },4000) 
       
      
      }

     

      $scope.correctOrder =function(field){
        // var byDate = $scope.filterredData.caseDetailsData.slice(0);
        // byDate.sort(function(a,b) {
        //     return a[field] - b[field];
        // });
        // $scope.filterredData.caseDetailsData =byDate;
        $scope.limitNumber=800;
        $scope.filterredData.caseDetailsData = $filter('orderBy')($scope.filterredData.caseDetailsData, field);
      }
      $scope.reverseorder =function(field){
        var byDate = $scope.filterredData.caseDetailsData.slice(0);
        byDate.sort(function(a,b) {
            return  b[field] -a[field];
        });
        $scope.filterredData.caseDetailsData =byDate;
      }

      vm.getDate = function (allDispositionText) {
        if (allDispositionText.length !== 0) {
          var dateDisplay=  allDispositionText.split("-");
          var addDash = "-";
          var stringNew = dateDisplay[0] + addDash;
          return stringNew;
        }
        return "";
      };

      vm.getDispositionText = function (allDispositionText) {
        if (allDispositionText.length !== 0) {
          var descriptionForDt=  allDispositionText.split("-");
          return descriptionForDt[1];
        }
        return "";
      };
      
      function rowContainsValue(thisRow, key) {
        var validKey = thisRow.hasOwnProperty(key) && thisRow[key];
        return validKey && (isNaN(parseInt(thisRow[key], CONSTANTS.GLOBAL.RADIX)) || thisRow[key].toString().length !== 13);
      }

      function displayNoResults(simpleSearchResults) {
        // if (simpleSearchResults.length === 0) {
        //   toastr.error(CONSTANTS.TOASTER.noRecords, {
        //     iconClass: 'toast-danger'
        //   });
        // }
      }

      function getDateRow(thisDate) {
        var month = thisDate.getMonth() + 1;
        if (month < 10) {
          month = '0' + month.toString();
        }
        var date = thisDate.getDate();
        if (date < 10) {
          date = '0' + date.toString();
        }
        return month + '/' + date + '/' + thisDate.getFullYear();
      }
      $scope.clearSearch = function () {
        $scope.searchTextt = "";
        $scope.filterredData = angular.copy($scope.originalFilterredData);
      }
      $scope.globalSearch = function (textToSearch) {

        // $scope.filterObj={
        //   PROCEEDING_FILING_DT_STRING:value,
        //   INSTITUTION_DECISION_DT_STRING:value,
        //   PROCEEDING_NO:value,
        //   PATENT_NO:value,
        //   INTERESTED_PARTY_NAME_TX:value,
        //   APJ1_WORKER_ID:value,
        //   PROCEEDING_STATUS_NM:value,
        //   ALL_DISPOSITION_TX:value
        // }
        if (textToSearch == "") {
          $scope.filterredData = angular.copy($scope.originalFilterredData);
          return;
        }
        if (textToSearch !== $scope.previousTextToSearch) {
          $scope.previousTextToSearch = angular.copy(textToSearch);
          // $scope.clearSearch(false);
          $scope.filterredData = angular.copy($scope.originalFilterredData);
        }
        var simpleSearchResults = [];
        angular.forEach($scope.filterredData.caseDetailsData, function (thisRow) {
          for (var key in thisRow) {
            if (rowContainsValue(thisRow, key)) {
              if (thisRow[key].toString().toLowerCase().includes(textToSearch.trim().toLowerCase())) {
                simpleSearchResults.push(thisRow);
                break;
              }
            } else {
              var thisDate = new Date(thisRow[key]);
              var dateToCompare = getDateRow(thisDate);
              if (dateToCompare.includes(textToSearch.trim())) {
                simpleSearchResults.push(thisRow);
                break;
              }
            }
          }
        });
        displayNoResults(simpleSearchResults);
        $scope.filterredData.caseDetailsData = simpleSearchResults;

      }

      $scope.updateFilters = function (e, item) {
        $scope.limitNumber=800;
        $timeout.cancel(timeout);
        timeout = $timeout(function () {
          if (item.columnName[0] == 'PROCEEDING_FILING_DT') {
            $scope.filterObj.PROCEEDING_FILING_DT_STRING = e.target.value;
          } else if (item.columnName[0] == 'INSTITUTION_DECISION_DT') {
            $scope.filterObj.INSTITUTION_DECISION_DT_STRING = e.target.value;
          } else if (item.columnName[0] === "ADDITIONAL_APJ_WORKER_ID_TX") {
            $scope.filterObj.APJ_STRING =  e.target.value;
            // $scope.filterObj.
            // var tempFilteredList = [];
            // if (e.target.value.trim() === "") {
            //   $scope.filterredData.caseDetailsData = [];
            //   $scope.filterredData.caseDetailsData = $scope.originalFilterredData.caseDetailsData;
            // } else {
            //   angular.forEach($scope.originalFilterredData.caseDetailsData, function (eachCase) {
            //     var addCase = false;
            //     if (eachCase.APJ1_WORKER_ID && eachCase.APJ1_WORKER_ID.toLowerCase().includes(e.target.value)) {
            //       addCase = true;
            //     }
            //     if (eachCase.APJ2_WORKER_ID && eachCase.APJ2_WORKER_ID.toLowerCase().includes(e.target.value)) {
            //       addCase = true;
            //     }
            //     if (eachCase.APJ3_WORKER_ID && eachCase.APJ3_WORKER_ID.toLowerCase().includes(e.target.value)) {
            //       addCase = true;
            //     }
            //     if (addCase) {
            //       tempFilteredList.push(eachCase);
            //     }
            //   })
            //   $scope.filterredData.caseDetailsData = [];
            //   $scope.filterredData.caseDetailsData = tempFilteredList;
            // }
            // activeWorkspace.count = $scope.filterredData.caseDetailsData.length;
          } else {
            $scope.filterObj[item.columnName[0]] = e.target.value;
          }
          $scope.filterLength=0;
          var keys = Object.keys($scope.filterObj)

          angular.forEach(keys,function(key){
            if ($scope.filterObj[key] && $scope.filterObj[key] != ''){
              $scope.filterLength = $scope.filterLength + 1;
            }
          })
          setLimit();
         
        }, 700);
      }



      $scope.sortyArray = function (param) {
        var temp = param.charAt(0);
        if (temp == '-') {
          if ($scope.orderByField.indexOf(param.substring(1)) != -1) {
            $scope.orderByField.splice($scope.orderByField.indexOf(param.substring(1)), 1)
          }
        } else {
          if ($scope.orderByField.indexOf('-' + param) != -1) {
            $scope.orderByField.splice($scope.orderByField.indexOf('-' + param), 1)
          }
        }
        if ($scope.orderByField.indexOf(param) == -1) {
          $scope.orderByField.push(param);
        }
      }

      $scope.clearFilterObj = function () {
        $scope.filterObj = {};
        $scope.filterLength = 0;
        $scope.searchTextt = "";
       // document.getElementById('searchforGlobal').value="";
        $scope.filterredData = angular.copy($scope.originalFilterredData);
        $scope.limitNumber=800;
        setLimit();
      }
      $scope.openCaseViewerwithAppeal = function (row) {
        var entity = {
          entity: row
        }
        CommonHelperService.openCaseViewerwithAppeal(entity);
      };



      $scope.openCaseViewerwithTrials = function (row) {
        var entity = {
          entity: row
        }
        CommonHelperService.openCaseViewerwithTrials(entity);
      };

      vm.enterOnActions = function($event,reportType) {
        if ($event.keyCode === 13) {
          vm.getReport(reportType);
        }
      };

      vm.getReport = function(reportType) {
        var fileNamePrepend;
        var updatedColumnList;
        var updatedCaseDetails;
        if (reportType==='all') {
          fileNamePrepend = "All assigned cases";
        } else {
          fileNamePrepend = reportType==='apjOne' ? vm.workspaces[0].userWorkspaceName : vm.workspaces[1].userWorkspaceName;
        }
        HttpFactory.downloadzip("/mixed-case-dockets/apj_report/open/" + vm.userId + "/" + reportType)
          .then(function (successResponse) {
            var blob = new Blob([successResponse.data], {
              type: 'text/csv'
            });
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = 'JPView_' + fileNamePrepend + "_" + CommonHelperService.getCurrentTime() + '.xlsx';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
          }, function (failureResponse) {
            toastr.error(failureResponse);
        });
     };

      vm.exportData = function () {
        var updatedColumnList = angular.copy($scope.filterredData.columnDetails);
        var updatedCaseDetails = angular.copy($scope.filterredData.caseDetailsData);
        
        buildExcel(updatedColumnList, updatedCaseDetails);
      };

      function buildExcel(updatedColumnList, updatedCaseDetails, name) {
        var headers = [];
        angular.forEach(updatedColumnList, function (coldata) {
          headers.push(coldata.columnLabel);
        });
        var fields = [];
        angular.forEach(updatedColumnList, function (coldata) {

          if (coldata.columnName[0] === 'FK_ASSIGNEE_BE_NO') {
            fields.push([coldata.columnName[1], coldata.columnType]);
          } else {
            fields.push([coldata.columnName[0], coldata.columnType]);
          }
        });
        var replacer = function (key, value) {
          return value === null ? '' : value;
        };
        var csv = updatedCaseDetails.map(function (row) {
          return fields.map(function (fieldName) {
            if (fieldName[0] === "APPEAL_SEQUENCE_NO" && row[fieldName[0]] !== null) {
              if (angular.isString(row[fieldName[0]])) {
                return " " + $filter('date')(new Date(row[fieldName[0]]).getTime(), 'MM/dd/yyyy') + " ";
              } else if (angular.isNumber(row[fieldName[0]])) {
                return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy') + " ";
              }
            }
            if (fieldName[1] === 'date') {
              if (row[fieldName[0]] === null) {
                return "";
              }
              if (fieldName[0] === 'LAST_MODIFIED_TS') {
                return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy hh:mm:ss a') + " ";
              } else {
                return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy') + " ";
              }
            } else if (fieldName[1] === 'string') {
              if (fieldName[0] === 'ALL_DISPOSITION_TX') {
                if (row.hasOwnProperty('ALL_DISPOSITION_TX')) {
                  if (row[fieldName[0]] === "") {
                    return "";
                  } else {

                    return JSON.stringify(convertArrayToString(row[fieldName[0]]), replacer);
                  }
                } else {
                  return "";
                }

              } else if (fieldName[0] === "ADDITIONAL_APJ_WORKER_ID_TX") {
                return JSON.stringify(setPanelColumnForExport(row));
              } else if (fieldName[0] === "DECISION_DUE_DAYS") {
                return "";
              } else {
                return JSON.stringify(row[fieldName[0]], replacer);
              }
            } else {
              return JSON.stringify(row[fieldName[0]], replacer);
            }
          }).join(',');
        });
        csv.unshift(headers.join(','));
        csv = csv.join('\r\n');
        var hiddenElement = document.createElement('a');
        hiddenElement.href = URL.createObjectURL(new Blob([csv], {
          type: 'text/csv'
        }));
        hiddenElement.target = '_blank';
        if (name) {
          hiddenElement.download = 'JPView_' + name + "_" + CommonHelperService.getCurrentTime() + '.csv';  
        } else {
          hiddenElement.download = 'JPView_' + activeWorkspace.userWorkspaceName + "_" + CommonHelperService.getCurrentTime() + '.csv';
        }
        
        hiddenElement.click();
      }



      function convertArrayToString(value) {
        var arrayString = "";
        try {
          angular.forEach(value.slice(0, 3), function (eachItem) {
            arrayString += eachItem + " ";
          });
        } catch (error) {
          console.info("Empy value found in export," + value);
        }
        return arrayString;
      }


      function setPanelColumnForExport(row) {
        var judgePanel = "";
        if (row.APJ1_WORKER_ID && row.APJ1_WORKER_ID.trim() !== "") {
          judgePanel += row.APJ1_WORKER_ID.trim();
        }
        if (row.ATTORNEY_WORKER_ID && row.ATTORNEY_WORKER_ID.trim() !== "") {
          judgePanel += ' (' + row.ATTORNEY_WORKER_ID.trim() + ')';
        }
        if (row.APJ2_WORKER_ID && row.APJ2_WORKER_ID.trim() !== "") {
          judgePanel += ' | ' + row.APJ2_WORKER_ID.trim();
        }
        if (row.APJ3_WORKER_ID && row.APJ3_WORKER_ID.trim() !== "") {
          judgePanel += ' | ' + row.APJ3_WORKER_ID.trim();
        }
        judgePanel = getFourAndAbove(row, judgePanel);
        return judgePanel;
      }



      function getFourAndAbove(row, judgePanel) {
        if (row.APJ4_WORKER_ID && row.APJ4_WORKER_ID.trim() !== "") {
          judgePanel += ' | ' + row.APJ4_WORKER_ID.trim();
        }
        if (row.APJ5_WORKER_ID && row.APJ5_WORKER_ID.trim() !== "") {
          judgePanel += ' | ' + row.APJ5_WORKER_ID.trim();
        }
        if (row.APJ6_WORKER_ID && row.APJ6_WORKER_ID.trim() !== "") {
          judgePanel += ' | ' + row.APJ6_WORKER_ID.trim();
        }
        return getSevenAndAbove(row, judgePanel);
      }

      function getSevenAndAbove(row, judgePanel) {
        if (row.APJ7_WORKER_ID && row.APJ7_WORKER_ID.trim() !== "") {
          judgePanel += ' | ' + row.APJ7_WORKER_ID.trim();
        }
        if (row.APJ8_WORKER_ID && row.APJ8_WORKER_ID.trim() !== "") {
          judgePanel += ' | ' + row.APJ8_WORKER_ID.trim();
        }
        if (row.APJ9_WORKER_ID && row.APJ9_WORKER_ID.trim() !== "") {
          judgePanel += ' | ' + row.APJ9_WORKER_ID.trim();
        }
        return judgePanel;
      }


    });
