"use strict";
angular
  .module('ptabe2e')
  .controller('JudgePortalController',
    function (HttpFactory, $log, $scope, $timeout, uiGridConstants, $route, $window, dashboard, CONSTANTS, $filter, CommonHelperService, SearchHelperService, i18nService) {
      var vm = this;
      vm.closedCasesNumberOfFilters = 0;
      vm.showNoClosedCasesMsg = false;
      vm.tab = "activeTab0";
      vm.isLoadingClosed = true;
      vm.initialLoad = true;
      var activeWorkspace;
      vm.inProgress = false;
      $scope.isLoading = false;
      var loggedInUser = null;
      $scope.showNoCasesMsg = false;
      i18nService.get('en').gridMenu.exporterAllAsCsv = 'Export filtered data as csv';

      /* Handles the change of tabs by amin user */
      function handleAdminTabChange(currentTab) {
        if (currentTab.currentWorkspaceOrderNumber === 1 && !$scope.closedCasesLoaded) {
          getClosedCases();
        }
      }

      vm.selectTab = function (currentTab) {
        activeWorkspace = currentTab;
        if (vm.currentLoggedInRoleIsAdmin) {
          handleAdminTabChange(currentTab);
        } else if (currentTab.currentWorkspaceOrderNumber === 0) {
          $scope.getAllApjCases('one');
          doFilter();
        } else if (currentTab.currentWorkspaceOrderNumber === 1) {
          $scope.getAllApjCases('twoPlus');
          doFilter();
        }
        for (var i = 0; i < vm.workspaces.length; i++) {
          vm.workspaces[i].active = "non-active";
          vm.workspaces[i].activeInd = null;
        }
        activeWorkspace = currentTab;
        vm.workspaces[activeWorkspace.currentWorkspaceOrderNumber].active = "active";
        vm.workspaces[activeWorkspace.currentWorkspaceOrderNumber].activeInd = true;
        vm.workspaceOrderChanged = true;
        vm.tab = 'activeTab' + activeWorkspace.currentWorkspaceOrderNumber;
        vm.activeTabIndex = activeWorkspace.currentWorkspaceOrderNumber;
      };

      function doFilter() {
        if ($scope.numberOfFilters > 0) {
          $scope.gridOptions.data = SearchHelperService.filterTable($scope.myData, $scope.gridOptions.columnDefs);
        }
      }

      function buildPortal() {
        vm.workspaces = [];
        var userWorkspaceName = "AIA Trials - APJ1 docket";
        var userWorkspaceName2 = "AIA Trials - APJ2+ docket";
        if (vm.currentLoggedInRoleIsAdmin) {
          userWorkspaceName = "All open cases";
          userWorkspaceName2 = "All closed cases";
        }
        var theWS = {
          currentWorkspaceOrderNumber: 0,
          defaultIndicator: true,
          structure: "12",
          userWorkspaceName: userWorkspaceName
        };
        createWorkspace(theWS, 0, 'active');
        theWS = {
          currentWorkspaceOrderNumber: 1,
          defaultIndicator: false,
          structure: "12",
          userWorkspaceName: userWorkspaceName2
        };
        createWorkspace(theWS, 1, 'non-active');

      }

      /* istanbul ignore next */
      function createWorkspace(currentWorkspace, i, active) {
        var workspace = {};
        workspace.userWorkspaceName = currentWorkspace.userWorkspaceName;
        workspace.tooltip = workspace.userWorkspaceName.replace(/&nbsp;/g, " ");
        workspace.userWorkspaceIdentifier = currentWorkspace.userWorkspaceIdentifier;
        workspace.active = active;
        workspace.currentWorkspaceOrderNumber = currentWorkspace.currentWorkspaceOrderNumber;
        workspace.text = 'Workspace ' + i;
        workspace.value = i;

        //initialize workspace structure
        vm.workspaces.push(workspace);
      }

      $scope.gridOptions = {
        enableGridMenu: true,
        enableSelectAll: true,
        useExternalFiltering: true,
        exporterCsvFilename: 'TrialsCaseDocket_' + CommonHelperService.getCurrentTime() + '.csv',
        exporterOlderExcelCompatibility: true,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        gridMenuShowHideColumns: true,
        enableFiltering: true,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.WHEN_NEEDED,
        enableVerticalScrollbar: uiGridConstants.scrollbars.NEVER,
        paginationPageSizes: [10, 25, 50, 100],
        gridMenuCustomItems: [{
          title: 'Export full docket as csv',
          action: function () {
            vm.exportData();
          },
          order: 210
        }],
        onRegisterApi: function (gridApi) {

          $scope.gridApi = gridApi;
          $scope.gridApi.core.on.filterChanged($scope, function () {
            var grid = this.grid;
            $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
            if ($scope.numberOfFilters === 0) {
              $scope.gridOptions.data = $scope.myData.caseDetailsData;
            } else {
              var filteredData = SearchHelperService.filterGrid(grid, $scope.myData);
              $scope.gridOptions.data = filteredData;
              $log.debug($scope.widgetName + "(" + $scope.widgetIdentifier + ") filtered data: ");
              $log.debug(filteredData);
            }
          });
        }
      };

      vm.exportData = function (type) {
        var updatedColumnList = angular.copy($scope.updatedColumnList);
        $scope.caseDetailsDataViewCaseDoc = angular.copy($scope.myData.caseDetailsData);
        if (type === 'closed') {
          updatedColumnList = angular.copy($scope.closedUpdatedColumnList);
          $scope.caseDetailsDataViewCaseDoc = angular.copy($scope.myClosedData.caseDetailsData);
        }
        var headers = [];
        angular.forEach(updatedColumnList, function (coldata) {
          headers.push(coldata.columnLabel);
        });
        var fields = [];
        angular.forEach(updatedColumnList, function (coldata) {

          if (coldata.columnName[0] === 'FK_ASSIGNEE_BE_NO') {
            fields.push([coldata.columnName[1], coldata.columnType]);
          } else {
            fields.push([coldata.columnName[0], coldata.columnType]);
          }
        });
        var replacer = function (key, value) {
          return value === null ? '' : value;
        };
        //$scope.caseDetailsDataViewCaseDoc = angular.copy($scope.myData.caseDetailsData);
        var csv = $scope.caseDetailsDataViewCaseDoc.map(function (row) {
          return fields.map(function (fieldName) {
            if (fieldName[1] === 'date') {
              if (row[fieldName[0]] === null) {
                return "";
              }
              if (fieldName[0] === 'LAST_MODIFIED_TS') {
                return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy hh:mm:ss a') + " ";
              } else {
                return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy') + " ";
              }
            } else if (fieldName[1] === 'string') {
              if (fieldName[0] === 'ALL_DISPOSITION_TX') {
                if (row.hasOwnProperty('ALL_DISPOSITION_TX')) {
                  if (row[fieldName[0]] === "") {
                    return "";
                  } else {

                    return JSON.stringify(convertArrayToString(row[fieldName[0]]), replacer);
                  }
                } else {
                  return "";
                }

              } else if (fieldName[0] === "ADDITIONAL_APJ_WORKER_ID_TX") {
                return JSON.stringify(setPanelColumnForExport(row));
              } else if (fieldName[0] === "DECISION_DUE_DAYS") {
                return "";
              } else {
                return JSON.stringify(row[fieldName[0]], replacer);
              }
            } else {
              return JSON.stringify(row[fieldName[0]], replacer);
            }
          }).join(',');
        });
        csv.unshift(headers.join(','));
        csv = csv.join('\r\n');
        var hiddenElement = document.createElement('a');
        hiddenElement.href = URL.createObjectURL(new Blob([csv], {
          type: 'text/csv'
        }));
        hiddenElement.target = '_blank';
        hiddenElement.download = 'JudgePortal_FullDocket_' + CommonHelperService.getCurrentTime() + '.csv';
        hiddenElement.click();
      };

      vm.loadJudgePortal = function (userInfo) {
        vm.currentLoggedInRoleIsAdmin = userInfo.appUserInfo[0].roleDescription === 'Business Administrator';
        vm.caseNumber = $route.current.params.caseNumber;
        vm.applicationNumber = $route.current.params.applicationNumber;
        vm.userId = $window.sessionStorage.getItem("workerNumber");
        $window.document.title = "JP View - P-TACTS";
        getLoggedInUserName();
      };

      /* istanbul ignore next*/
      $scope.getJudgePortalData = function () {
        $scope.isLoading = true;
        $scope.gearLoading = true;
        HttpFactory.getActions('/mixed-case-dockets/docket_details/open/' + vm.userId)
          .then(function (successResponse) {
              $scope.enableloading = false;
              $scope.dateValid = false;
              $scope.isInColumnDetails = false;
              if (angular.isDefined(successResponse.data)) {
                $scope.myData = successResponse.data;
                $scope.updatedColumnList = successResponse.data.columnDetails;
                var setColumnsResponse = CommonHelperService.setColumnDefinitions($scope.myData.columnDetails);
                var hasFilterFlag = setColumnsResponse.filterCount;

                updateColumnDefs(setColumnsResponse.colDefs, $scope.gridOptions);
                // $scope.gridOptions.paginationPageSize = $scope.myData.paginationSize;

                $scope.gridOptions.data = CommonHelperService.setGridData(hasFilterFlag, $scope.myData.caseDetailsData, setColumnsResponse.colDefs);
                if (hasFilterFlag > 0) {

                  $scope.numberOfFilters = hasFilterFlag;

                  var filteredData = SearchHelperService.filterTable($scope.myData, setColumnsResponse.colDefs);
                  $scope.gridOptions.data = filteredData;
                } else {
                  $scope.numberOfFilters = 0;
                  $scope.originalGridData = angular.copy($scope.myData.caseDetailsData);
                  if (vm.currentLoggedInRoleIsAdmin) {
                    $scope.getAllApjCases("all");
                  } else {
                    $scope.getAllApjCases("one");
                  }
                }
                $timeout($scope.setPaginationManually, 700);
                $scope.noRecordsFound = true;
              }
              // $scope.gridOptions.paginationPageSize = $scope.gridOptions.data.length;
            },
            function (failureResponse) {
              $log.debug(failureResponse);
              /* istanbul ignore if: toaster error  */
              if (failureResponse.status === 404) {
                $scope.enableloading = false;
                CommonHelperService.setToastr(failureResponse.data.message, "info");
                $scope.noRecordsFound = true;
              } else {
                $scope.enableloading = false;
              }
            }).finally(function () {
            // Add total number of records to pagination dropdown
            if ($scope.gridOptions.data.length > 100) {
              $scope.gridOptions.paginationPageSizes.push($scope.gridOptions.data.length);
            }
            $scope.gridOptions.paginationPageSize = 10;
            $scope.dynamicHeight = getTableHeight($scope.gridOptions.paginationPageSize);
            $scope.isLoading = false;
            $scope.gearLoading = false;
          });
      };

      function updateColumnDefs(columndefs, gridOptions) {
        var selected = [];
        var unselected = [];
        var selectedCount = 0;

        angular.forEach(columndefs, function (col) {
          col.enableHiding = true;
          if (col.visible) {
            selected.push(col);
            selectedCount = selectedCount + 1;
          } else {
            unselected.push(col);
          }
        });

        columndefs = [];
        angular.forEach(selected, function (col) {
          columndefs.push(col);
        });
        unselected.sort(CommonHelperService.alphabetizeAvailableColumns);
        angular.forEach(unselected, function (col) {
          columndefs.push(col);
        });

        gridOptions.rowHeight = 70;

        for (var i = 0; i < columndefs.length; i++) {
          if (columndefs[i].field === "ALL_DISPOSITION_TX" && columndefs[i].visible === true) {
            gridOptions.rowHeight = 70;
            break;
          }
        }
        gridOptions.columnDefs = buildCaseAlerts(columndefs);
      }


      function buildCaseAlerts(columndefs) {
        angular.forEach(columndefs, function (col) {
          if (col.displayName === 'Alerts') {
            col = CommonHelperService.addAlertFilters(col, 'View case dockets');
          }
        });
        return columndefs;
      }


      function getLoggedInUserName() {
        HttpFactory.getActions(CONSTANTS.URL.USERMANAGEMENT + "?loginId=" + vm.userId)
          .then(function (userNameSuccess) {
            loggedInUser = userNameSuccess.data.caseDetailsData[0].fullName.trim();
            buildPortal();
            $timeout(function () {
              $scope.getJudgePortalData();
            }, 2000);
          }, function (userNameFailure) {
            console.info("Failed to retrieve user name", userNameFailure);
          });
      }

      $scope.getAllApjCases = function (apjNumber) {
        var tempCases = [];
        if (apjNumber === 'all') {
          tempCases = angular.copy($scope.originalGridData);
        } else {
          tempCases = getJudgeCases(apjNumber);
        }
        sortCaseGrid(tempCases);
        computeGridHeight(apjNumber);
      };

      function getJudgeCases(apjNumber) {
        if (apjNumber === "one") {
          return getAPJ1Cases();
        }
        return getApj2PlusCases();
      }

      function getAPJ1Cases() {
        var tempCases = [];
        angular.forEach($scope.originalGridData, function (currentCase) {
          if (currentCase.APJ1_WORKER_ID && currentCase.APJ1_WORKER_ID.trim() === loggedInUser) {
            tempCases.push(currentCase);
          }
        });
        return tempCases;
      }

      function getApj2PlusCases() {
        var tempCases = [];
        angular.forEach($scope.originalGridData, function (currentCase) {
          tempCases = matchApjWithUser(currentCase.APJ2_WORKER_ID, tempCases, currentCase);
          tempCases = matchApjWithUser(currentCase.APJ3_WORKER_ID, tempCases, currentCase);
          tempCases = matchApjWithUser(currentCase.APJ4_WORKER_ID, tempCases, currentCase);
          tempCases = matchApjWithUser(currentCase.APJ5_WORKER_ID, tempCases, currentCase);
          tempCases = matchApjWithUser(currentCase.APJ6_WORKER_ID, tempCases, currentCase);
          tempCases = matchApjWithUser(currentCase.APJ7_WORKER_ID, tempCases, currentCase);
          tempCases = matchApjWithUser(currentCase.APJ8_WORKER_ID, tempCases, currentCase);
          tempCases = matchApjWithUser(currentCase.APJ9_WORKER_ID, tempCases, currentCase);
        });
        return tempCases;
      }

      function matchApjWithUser(apj, tempCases, currentCase) {
        if (apj && apj.trim() === loggedInUser) {
          tempCases.push(currentCase);
        }
        return tempCases;
      }

      /* This computes the grid height bases on data rows.*/
      function computeGridHeight(apjNumber) {
        if (apjNumber === "one") {
          $scope.dynamicHeight = getTableHeight($scope.gridOptions.data.length);
          $log.debug("After sort height: ", $scope.dynamicHeight);
        } else {
          $scope.dynamicHeight2 = getTableHeight($scope.gridOptions.data.length);
          $log.debug("After sort height: ", $scope.dynamicHeight2);
        }
        $scope.showNoCasesMsg = $scope.gridOptions.data.length > 0 ? false : true;
      }

      /** Sorts the grid based on preceding number.*/
      function sortCaseGrid(tempCases) {
        $scope.myData.caseDetailsData = angular.copy(tempCases);
        $scope.gridOptions.data = angular.copy(tempCases);
        $scope.gridOptions.data.sort(function compare(a, b) {
          // Use toUpperCase() to ignore character casing
          var caseA = a.PROCEEDING_NO.toUpperCase();
          var caseB = b.PROCEEDING_NO.toUpperCase();

          var comparison = 0;
          if (caseA > caseB) {
            comparison = 1;
          } else if (caseA < caseB) {
            comparison = -1;
          }
          return comparison;
        });
      }

      $scope.openCaseViewer = function (row) {
        CommonHelperService.openCaseViewer(row);
      };

      $scope.openCaseViewerwithAppeal = function (row) {
        CommonHelperService.openCaseViewerwithAppeal(row);
      };

      $scope.openCaseViewerwithTrials = function (row) {
        CommonHelperService.openCaseViewerwithTrials(row);
      };

      /* Gets the table height based on number of rows in data */
      function getTableHeight(data) {
        var rowHeight = 70;
        var headerHeight = 80;
        return {
          // 'height': (data.length * rowHeight + headerHeight) + 'px'
          'height': (data * rowHeight + headerHeight) + 'px'
        };
      }

      function convertArrayToString(value) {
        var arrayString = "";
        try {
          angular.forEach(value.slice(0, 3), function (eachItem) {
            arrayString += eachItem + " ";
          });
        } catch (error) {
          console.info("Empy value found in export," + value);
        }
        return arrayString;
      }

      function setPanelColumnForExport(row) {
        var judgePanel = "";
        if (row.APJ1_WORKER_ID && row.APJ1_WORKER_ID.trim() !== "") {
          judgePanel += row.APJ1_WORKER_ID.trim();
        }
        if (row.ATTORNEY_WORKER_ID && row.ATTORNEY_WORKER_ID.trim() !== "") {
          judgePanel += ' (' + row.ATTORNEY_WORKER_ID.trim() + ')';
        }
        if (row.APJ2_WORKER_ID && row.APJ2_WORKER_ID.trim() !== "") {
          judgePanel += ' | ' + row.APJ2_WORKER_ID.trim();
        }
        if (row.APJ3_WORKER_ID && row.APJ3_WORKER_ID.trim() !== "") {
          judgePanel += ' | ' + row.APJ3_WORKER_ID.trim();
        }
        judgePanel = getFourAndAbove(row, judgePanel);
        return judgePanel;
      }

      function getFourAndAbove(row, judgePanel) {
        if (row.APJ4_WORKER_ID && row.APJ4_WORKER_ID.trim() !== "") {
          judgePanel += ' | ' + row.APJ4_WORKER_ID.trim();
        }
        if (row.APJ5_WORKER_ID && row.APJ5_WORKER_ID.trim() !== "") {
          judgePanel += ' | ' + row.APJ5_WORKER_ID.trim();
        }
        if (row.APJ6_WORKER_ID && row.APJ6_WORKER_ID.trim() !== "") {
          judgePanel += ' | ' + row.APJ6_WORKER_ID.trim();
        }
        return getSevenAndAbove(row, judgePanel);
      }

      function getSevenAndAbove(row, judgePanel) {
        if (row.APJ7_WORKER_ID && row.APJ7_WORKER_ID.trim() !== "") {
          judgePanel += ' | ' + row.APJ7_WORKER_ID.trim();
        }
        if (row.APJ8_WORKER_ID && row.APJ8_WORKER_ID.trim() !== "") {
          judgePanel += ' | ' + row.APJ8_WORKER_ID.trim();
        }
        if (row.APJ9_WORKER_ID && row.APJ9_WORKER_ID.trim() !== "") {
          judgePanel += ' | ' + row.APJ9_WORKER_ID.trim();
        }
        return judgePanel;
      }

      $scope.gridOptions.exporterFieldCallback = function (grid, row, col, value) {
        $scope.gridOptions.exporterCsvFilename = 'JudgePortal_' + CommonHelperService.getCurrentTime() + '.csv';
        if (col.colDef.type === 'string') {
          if (col.colDef.field === 'ALL_DISPOSITION_TX' && value) {
            if (value[0] === "") {
              value = "";
            } else {
              value = convertArrayToString(value);
            }
          }

          if (col.colDef.displayName === 'Judge panel') {
            return setPanelColumnForExport(row.entity);
          }
        }

        value = getDateValue(col, value);
        if (col.colDef.field === "DECISION_DUE_DAYS") {
          value = "";
        }
        return value;
      };

      function getDateValue(col, value) {
        if (col.colDef.type === 'date') {
          if (col.colDef.field === 'LAST_MODIFIED_TS') {
            value = $filter('date')(value, 'MM/dd/yyyy hh:mm:ss a');
          } else {
            value = $filter('date')(value, 'MM/dd/yyyy');
          }
          if (!value) {
            value = "";
          } else {
            value = " " + value;
          }
        }
        return value;
      }

      /* Build the grid for closed cases */
      function buildClosedCasesGrid() {
        $scope.closedGridOptions = CommonHelperService.setCommonGridOptions();
        $scope.closedGridOptions.enableVerticalScrollbar = uiGridConstants.scrollbars.NEVER;
        $scope.closedGridOptions.paginationPageSizes = [10, 25, 50, 100];


        $scope.closedGridOptions.gridMenuCustomItems = [{
          title: 'Export full docket as csv',
          action: function () {
            vm.exportData('closed');
          },
          order: 210
        }];




        $scope.closedGridOptions.onRegisterApi = function (gridApi) {
          $scope.closedGridApi = gridApi;
          $scope.closedGridApi.core.on.filterChanged($scope, function () {
            var grid = this.grid;
            vm.closedCasesNumberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
            if (vm.closedCasesNumberOfFilters === 0) {
              $scope.closedGridOptions.data = $scope.myClosedData.caseDetailsData;
            } else {
              var filteredData = SearchHelperService.filterGrid(grid, $scope.myClosedData);
              $scope.closedGridOptions.data = filteredData;
            }
            // check For Unsaved Changes when save grid preferces is added checkForUnsavedChanges();
          });
          $scope.closedGridApi.core.on.columnVisibilityChanged($scope, function () {
            // check for isColumnVisibilityChanged = true;
            updateColumnDefs($scope.closedGridOptions.columnDefs);
            //   check For Unsaved Changes
          });
        };
      }
      buildClosedCasesGrid();

      $scope.closedGridOptions.exporterFieldCallback = function (grid, row, col, value) {
        $scope.closedGridOptions.exporterCsvFilename = 'JudgePortal_' + CommonHelperService.getCurrentTime() + '.csv';
        if (col.colDef.type === 'string') {
          if (col.colDef.field === 'ALL_DISPOSITION_TX' && value) {
            if (value[0] === "") {
              value = "";
            } else {
              value = convertArrayToString(value);
            }
          }

          if (col.colDef.displayName === 'Judge panel') {
            return setPanelColumnForExport(row.entity);
          }
        }

        value = getDateValue(col, value);
        if (col.colDef.field === "DECISION_DUE_DAYS") {
          value = "";
        }
        return value;
      };

      /* istanbul ignore next*/
      function getClosedCases() {
        HttpFactory.getActions('/mixed-case-dockets/docket_details/closed/' + vm.userId)
          .then(function (successResponse) {
              if (angular.isDefined(successResponse.data)) {
                $scope.myClosedData = successResponse.data;
                try {
                  vm.showNoClosedCasesMsg = successResponse.data.columnDetails.length === 0;
                } catch (error) {
                  $log.debug(error);
                }

                $scope.closedUpdatedColumnList = successResponse.data.columnDetails;
                var setColumnsResponse = CommonHelperService.setColumnDefinitions($scope.myClosedData.columnDetails);

                var hasFilterFlag = setColumnsResponse.filterCount;

                updateColumnDefs(setColumnsResponse.colDefs, $scope.closedGridOptions);
                $scope.closedGridOptions.paginationPageSize = $scope.myClosedData.paginationSize;
                $scope.closedGridOptions.data = CommonHelperService.setGridData(hasFilterFlag, $scope.myClosedData.caseDetailsData, setColumnsResponse.colDefs);
                vm.closedCasesNumberOfFilters = hasFilterFlag;
                if (hasFilterFlag > 0) {
                  var filteredData = SearchHelperService.filterTable($scope.myClosedData, setColumnsResponse.colDefs);
                  $scope.closedGridOptions.data = filteredData;
                } else {
                  $scope.originalClosedGridData = angular.copy($scope.myClosedData.caseDetailsData);
                }
              }
              $scope.closedGridOptions.paginationPageSize = $scope.closedGridOptions.data.length;
              vm.isLoadingClosed = false;
            },
            function (failureResponse) {
              $log.debug(failureResponse);
              /* istanbul ignore if: toaster error  */
              if (failureResponse.status === 404) {
                $scope.enableloading = false;
                CommonHelperService.setToastr(failureResponse.data.message, "info");
              } else {
                $scope.enableloading = false;
                if (angular.isUndefined($scope.refreshDate) || $scope.refreshDate === null) {
                  $scope.dateValid = true;
                }
              }
            }).finally(function () {
            // Add total number of records to pagination dropdown
            if ($scope.closedGridOptions.data.length > 100) {
              $scope.closedGridOptions.paginationPageSizes.push($scope.closedGridOptions.data.length);
            }
            $scope.closedGridOptions.paginationPageSize = 10;
            $scope.closedDynamicHeight = getTableHeight($scope.closedGridOptions.paginationPageSize);
            vm.isLoadingClosed = false;
          });
      }
    });
