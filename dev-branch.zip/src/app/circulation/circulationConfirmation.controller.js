(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('CirculationConfirmationController', function (ngDialog, $filter, flag, rowToDelete) {
      var vm = this;
      vm.mailingInstructions = {
        noteText: "No instructions"
      };


      /* istanbul ignore next */
      vm.tinymceOptions = {
        plugins: 'link image',
        toolbar: "undo redo  bold italic  link media",
        menu: {},
        browser_spellcheck: true,
        contextmenu: false,
        elementpath: false,

        init_instance_callback: function (editor) {
          var textContentTrigger = function () {
            vm.textContent = editor.getBody().textContent;
          };

          editor.on('KeyUp', textContentTrigger);
          editor.on('ExecCommand', textContentTrigger);
          editor.on('SetContent', function (e) {
            if (!e.initial) {
              textContentTrigger();
            }

          });
        }
      };



      vm.instructionsNote = {
        noteModifiedBy: "Bui, Hung H",
        audit: {
          lastModifiedTimestamp: 1577423520000
        },
        noteText: 'Please place postage and return address'
      };


      vm.showAbandon = false;
      vm.showDelete = false;
      vm.showReplace = false;
      vm.fixSequence = false;
      vm.paralegalOnly = false;
      vm.readyForMailingBeforeInitiate = false;
      vm.showBlank = false;
      vm.showOther = false;
      vm.showWriting = false;
      vm.showCirculationInitiated = false;
      var displayDate = rowToDelete ? $filter('date')(rowToDelete.entity.completedDate, 'MM/dd/yyyy') : null;
      var displayName = rowToDelete ? rowToDelete.entity.assigneeName.split(",").reverse().join(" ") : null;

      switch (flag) {
        case 'unsaved':
          vm.title = 'Abandon changes?';
          vm.body = 'You have unsaved changes. Your changes will be lost.';
          vm.showAbandon = true;
          break;
        case 'delete':
          vm.title = 'Remove review request?';
          vm.body = 'Do you want to remove review request that is already open for ' + displayName + ' (' + rowToDelete.entity.role + ')' + ' and due on ' + displayDate + '?';
          vm.showDelete = true;
          break;
        case 'deleteInactive':
          vm.title = 'Remove review request?';
          vm.body = 'Do you want to remove review request for ' + displayName + ' (' + rowToDelete.entity.role + ')' + ' and due on ' + displayDate + '?';
          vm.showDelete = true;
          break;
        case 'replace':
          vm.title = 'Replace current assignment?';
          vm.body = 'Do you wish to replace the current circulation assignment for ' + rowToDelete.entity.role + ' due on ' + displayDate + ' with this new circulation assignment';
          vm.showReplace = true;
          break;
        case 'sequence':
          vm.title = 'Missing tiers error!';
          vm.body = 'There cannot be any gaps in the order. Please fix error before proceeding.';
          vm.fixSequence = true;
          break;
        case 'paralegalOnly':
          vm.title = 'Start PL review only, no APJ2/3?';
          vm.body = 'Do you want to circulate this decision outside of PTAB E2E?';
          vm.paralegalOnly = true;
          vm.readyMailMode = true;
          break;
        case 'other':
          vm.title = 'Confirm';
          vm.body = 'Other indicates you are not ready to sign-off on the review. Add comments in the Circulation Notes tab. Do you wish to continue? ';
          vm.showOther = true;
          break;
        case 'blank':
          vm.title = 'Cannot be blank';
          vm.body = 'Results field cannot be blank.';
          vm.showBlank = true;
          break;
        case 'addWriting':
          vm.title = 'Add additional materials?';
          vm.body = 'Did you wish to add additional materials to the opinion before it is to be mailed out?';
          vm.showWriting = true;
          break;
        case 'readyForMailingBeforeInitiate':
          vm.title = 'Mail decision without circulation?';
          vm.body = 'You are about to send the decision for mailing without initiating the panel circulation in the PTAB E2E system. Do you want to continue?';
          vm.readyForMailingBeforeInitiate = true;
          vm.readyMailMode = true;
          break;
        case 'readyForMailingAfterInitiate':
          vm.title = 'Move ahead without signoffs?';
          vm.body = 'One or more panel member(s) has not entered their sign off in PTAB E2E, are you sure that you want to move ahead w/out their sign offs?';
          vm.paralegalOnly = true;
          vm.readyMailMode = true;
          break;
        case 'initiateParalegal':
          vm.title = 'Close Circulation Manager browser tab?';
          vm.body = 'Paralegal review has been initiated successfully. Do you want to close the "Circulation Manager" browser tab?';
          vm.paralegalOnly = true;
          break;
        case 'initiateCirculation':
          vm.title = 'Circulation has been initiated';
          vm.body = 'Circulation has been initiated. The first assignment has been sent.';
          vm.showCirculationInitiated = true;
          break;
        case 'updateCirculation':
          vm.title = 'Circulation has been updated';
          vm.body = 'Circulation assignments have been updated.';
          vm.showCirculationInitiated = true;
          break;
        case 'noCirculation':
          vm.title = 'Circulation not initiated';
          vm.body = 'Circulation for this case has not been initiated yet.';
          vm.showBlank = true;
          break;
        case 'allReviewsComplete':
          vm.title = 'Review and confirm ready for mail';
          vm.body = 'All reviews have been completed.  Confirm Ready for mail?';
          vm.allReviewsComplete = true;
          vm.readyMailMode = true;
          break;
        default:
          vm.title = 'Abandon changes?';
          vm.body = 'You have unsaved changes. Your changes will be lost.';
          vm.showAbandon = true;
          break;
      }

      vm.closeCurrentDialog = function () {
        ngDialog.closeAll(false);
      };

      vm.revertchanges = function () {
        ngDialog.closeAll(true);
      };

      vm.closeReplaceDialog = function () {
        ngDialog.close(lastDialog(), false);
      };

      vm.replaceAssignment = function () {
        ngDialog.close(lastDialog(), rowToDelete);
      };

      function lastDialog() {
        var openDialogs = ngDialog.getOpenDialogs();
        return openDialogs[openDialogs.length - 1];
      }

      vm.stayOnPage = function () {
        ngDialog.closeAll(false);
      };

      vm.closeCirculationManager = function () {
        ngDialog.closeAll(true);
      };

    });
})();
