(function () {
    'use strict';
  
    describe('ConfirmRemoveNoteController', function () {
  
      beforeEach(module('ptabe2e'));
      var $controller;
      var vm = this;
      var controller, scope, $rootScope, $CommonHelperService;
      var successResponse, failureResponse;
      var $httpBackend, spy, $q, HttpFactoryDeferred;
      var ngDialogData = {
          notes: {
            circulationNoteIdentifier: '1'
          }
      }
      var notesInfo = ngDialogData;
      var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'closeAll']);
  
      var fakeElement = function (params) {
        return {
          scope: function () {
            return {
              vm: {
                getWidgetZone: function () {
  
                },
                setWidgetContentHeight: function () {
  
                }
              }
            }
          }
        }
      };
  
      beforeEach(inject(function (_$controller_, _$rootScope_, _$httpBackend_, _$q_, HttpFactory, _CommonHelperService_) {
        $q = _$q_;
        scope = _$rootScope_.$new();
        $controller = _$controller_;
        $rootScope = _$rootScope_;
        $httpBackend = _$httpBackend_;
        $CommonHelperService = _CommonHelperService_;
        scope.ngDialogData = {
            notes: {
                circulationNoteIdentifier: '1'
            }
        }
        // $ngDialog.open.and.returnValue({
        //   then: function (callback1, callback2) {
        //     callback1();
        //     callback2();
        //   }
        // });
        HttpFactoryDeferred = _$q_.defer();
        spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
        spyOn(HttpFactory, 'deleteActions').and.returnValue(HttpFactoryDeferred.promise);
        spyOn($CommonHelperService, 'setToastr').and.callFake(function () {
          return "toastr";
        });
        spy = spyOn(angular, 'element').and.callFake(fakeElement);
  
        controller = $controller('ConfirmRemoveNoteController', {
          $scope: scope,
          ngDialog: ngDialog,
          $rootScope: _$rootScope_,
          HttpFactory: HttpFactory,
          notesInfo: notesInfo
        });
      }));
  
      describe('ConfirmRemoveNoteController ', function () {
  
        
        it('should call deleteNote and get successResponse', function () {
          expect(controller.deleteNote).toBeDefined();
          controller.deleteNote();
          HttpFactoryDeferred.resolve(successResponse);
          $rootScope.$apply();
        });
  
        it('should call deleteNote and get failureResponse', function () {
          failureResponse = {
            data: {
              "message": "Note not saved"
            }
          };
          expect(controller.deleteNote).toBeDefined();
          controller.deleteNote();
          HttpFactoryDeferred.reject(failureResponse);
          $rootScope.$apply();
        });
  
      });
    });
  })();
  