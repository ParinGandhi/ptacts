(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .directive('clFileModel', ['$parse', /* istanbul ignore next */ function () {
      return {
        restrict: 'A',
        link: function (scope, element) {
          element.bind('change', function () {
            scope.$apply(function () { //intentional
            });
          });
        }
      };
    }])

    .directive('clOnChange', /* istanbul ignore next */ function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var onChangeFunc = scope.$eval(attrs.clOnChange);
          element.bind('change', onChangeFunc);
        }
      };
    })

    .controller('AddEditDocumentController', function ($scope, CONSTANTS, circulationIdentifier, prosecutionArtifacts, ngDialog, CommonHelperService, HttpFactory) {
      var vm = this;
      vm.disableSave = false;
      vm.prosecutionArtifacts = prosecutionArtifacts;
      vm.dialogModel = $scope.ngDialogData;
      vm.circulationIdentifier = circulationIdentifier;
      /* instanbul ignore next */
      if (vm.dialogModel.data) {
        vm.dialogModel.data.fileName = vm.dialogModel.data.artifactUrlText.replace(/\"/g, ""); //.substring(lastIndex + 1);
        vm.fileName = angular.copy(vm.dialogModel.data.fileName);
        vm.dialogModel.data.description = vm.dialogModel.data.artifactTitleName;
        vm.fileDescription = angular.copy(vm.dialogModel.data.description);
        vm.circulationArtifactIdentifier = vm.dialogModel.data.circulationArtifactIdentifier;
      } else {
        vm.dialogModel.data = {};
      }
      var clFile;
      var reader = new FileReader();
      var fileByteArray = [];

      /* istanbul ignore next */
      vm.getFileInfo = function () {
        clFile = document.getElementById("file1");
        $scope.fileInfo = {};
        $scope.fileInfo.name = clFile.files[0].name;
        vm.dialogModel.data.fileName = $scope.fileInfo.name;
        $scope.fileInfo.path = clFile.value;
        reader.readAsArrayBuffer(clFile.files[0]);
        reader.onloadend = function (evt) {
          if (evt.target.readyState === FileReader.DONE) {
            var arrayBuffer = evt.target.result,
              array = new Uint8Array(arrayBuffer);
            for (var i = 0; i < array.length; i++) {
              fileByteArray.push(array[i]);
            }
          }
        };
      };

      function getOtherArtifact() {
        var artifactToReturn=null;
        angular.forEach(vm.prosecutionArtifacts.prosecutionArtifacts, function(artifact) {
          if (artifact.artifactName!==vm.dialogModel.data.artifactName) {
            artifactToReturn = angular.copy(artifact);
          }
        });
        return artifactToReturn;
      }

      /*istanbul ignore next: toaster error */
      vm.confirm = function () {
        vm.createUrl = vm.dialogModel.data.fileName.replace(/\"/g, "");
        var data = {};

        if (vm.dialogModel.data.artifactType === "c") {
          var circulationArtifacts = [{
            "audit": {
              "lastModifiedTimestamp": new Date().getTime(),
              "lastModifiedUserIdentifier": vm.dialogModel.loggedInUser,
              "createUserIdentifier": vm.dialogModel.loggedInUser
            },
            "circulationArtifactIdentifier": vm.dialogModel.data.circulationArtifactIdentifier ? vm.dialogModel.data.circulationArtifactIdentifier : null,
            "artifactUrlText": vm.createUrl,
            "artifactTitleName": vm.dialogModel.data.description,
            "appealNumber":vm.dialogModel.data.appealNumber,
             "serialNumber":vm.dialogModel.data.serialNumber
          }];
          data.circulationArtifacts = circulationArtifacts;
        }
        if (vm.dialogModel.data.artifactType === "p") {
          var prosecutionArtifacts = [{
            "audit": {
              "lastModifiedTimestamp": new Date().getTime(),
              "lastModifiedUserIdentifier": vm.dialogModel.loggedInUser,
              "createUserIdentifier": vm.dialogModel.loggedInUser
            },
            "prosecutionArtifactId": vm.dialogModel.data.prosecutionArtifactId ? vm.dialogModel.data.prosecutionArtifactId : null,
            "artifactUrlText": vm.createUrl,
            "artifactTitleName": vm.dialogModel.data.description,
            "appealNumber":vm.dialogModel.data.appealNumber,
             "serialNumber":vm.dialogModel.data.serialNumber
          }];
          if (!vm.dialogModel.data.prosecutionArtifactId) {
            var otherArtifact = getOtherArtifact();
            if (otherArtifact) {

              var secondArtifact = {
                "audit": {
                  "lastModifiedTimestamp": new Date().getTime(),
                  "lastModifiedUserIdentifier": vm.dialogModel.loggedInUser,
                  "createUserIdentifier": vm.dialogModel.loggedInUser
                },
                "prosecutionArtifactId": null,
                "fkDocumentTypeId":otherArtifact.fkDocumentTypeId,
                "artifactUrlText": otherArtifact.artifactUrlText,
                "artifactTitleName": otherArtifact.artifactTitleName,
                "appealNumber":vm.dialogModel.data.appealNumber,
                 "serialNumber":vm.dialogModel.data.serialNumber
              }
              prosecutionArtifacts.push(secondArtifact);
            }
          }
          data.prosecutionArtifacts = prosecutionArtifacts;
        }

        data.circulationIdentifier = vm.dialogModel.circulationIdentifier;
        if (vm.dialogModel.documentCall) {
          // var docsList = [];

          // docsList.push(data);
          HttpFactory.putActions("/circulation-artifact/update-artifacts", data)
            .then(function () {
              CommonHelperService.setToastr("", "clear");
              CommonHelperService.setToastr(CONSTANTS.TOASTER.docSuccess, "success");
              $scope.confirm();
            }, function () {
              vm.disableSubmit = false;
              CommonHelperService.setToastr("", "clear");
              CommonHelperService.setToastr(CONSTANTS.TOASTER.docFail, "error");
            });
        } else
        if (vm.dialogModel.showInitiate === 'I') {
          var data = {
            "audit": {
              "lastModifiedTimestamp": new Date().getTime(),
              "lastModifiedUserIdentifier": vm.dialogModel.loggedInUser,
              "createUserIdentifier": vm.dialogModel.loggedInUser,
            },
            "circulationIdentifier": vm.dialogModel.circulationIdentifier,
            "artifactUrlText": vm.createUrl,
            "artifactTitleName": vm.dialogModel.data.description,
          };
          HttpFactory.postActions("/circulation-artifact", data)
            .then(function () {
              CommonHelperService.setToastr("", "clear");
              CommonHelperService.setToastr(CONSTANTS.TOASTER.docAdd, "success");
              $scope.confirm();

            }, function () {
              vm.disableSubmit = false;
              CommonHelperService.setToastr("", "clear");
              CommonHelperService.setToastr(CONSTANTS.TOASTER.docAddFail, "error");
            });
        } else
        if (vm.dialogModel.showInitiate === 'NI') {
          var data = {
            "audit": {
              "lastModifiedTimestamp": new Date().getTime(),
              "lastModifiedUserIdentifier": vm.dialogModel.loggedInUser,
              "createUserIdentifier": vm.dialogModel.loggedInUser,
            },
            "circulationIdentifier": vm.dialogModel.circulationIdentifier,
            "artifactUrlText": vm.createUrl,
            "artifactTitleName": vm.dialogModel.data.description,
          };
          $scope.confirm(data);

        } else {
          $scope.confirm(data);
        }
      };


      /*istanbul ignore next: toaster error */
      vm.edit = function () {
        var data = {
          "audit": {
            "lastModifiedTimestamp": new Date().getTime(),
            "lastModifiedUserIdentifier": vm.dialogModel.loggedInUser,
          },
          "circulationIdentifier": vm.circulationIdentifier,
          "artifactUrlText": "C://Source Code//UI Trunk's",
          "artifactTitleName": vm.dialogModel.data.description
        };

        HttpFactory.putActions("/circulation-artifact", data)
          .then(function () {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.editDoc, "success");
          }, function () {
            vm.disableSubmit = false;
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.editDocFail, "error");
          });
      };

      vm.closeAddCirculationModal = function () {
        ngDialog.closeAll();
      };
    });
})();
