'use strict';
angular.module('ptabe2e').factory('CirculationHelperService', function (HttpFactory) {

  var counselHelperService = {
    getEndDate: getEndDate,
    getPreviousEndDate: getPreviousEndDate,
    isBusinessDay: isBusinessDay,
    getResultsClass: getResultsClass,
    inActiveTier: inActiveTier,
    lowestTier: lowestTier,
    cancelAssignment: cancelAssignment
  };


  function cancelAssignment(requestBody, url) {
    return HttpFactory.putActions('/circulation/' + url, requestBody)
    .then(function (successResponse) {
     return null;
    }, function (failureResponse) {
      console.log(failureResponse);
     return failureResponse;
  });
  }

  function lowestTier(data) {
    var lowTier = 99;
    angular.forEach(data, function (row) {
      lowTier = Math.min(lowTier, row.order);
    });
    return lowTier;
  }

  function getResultsClass(row, data) {
    if (row.entity.dispositionTimestamp) {
      return 'reviewComplete';
    }


    if (inActiveTier(row.entity.order, data)) {

      if (row.entity.assigneeUserId.toLowerCase().includes('queue')) {
        return 'activeGreenPending';
      }


      if (isOverdue(row.entity.completedDate)) {
        return 'activeDanger';
      }

      if (isWithOneDay(row.entity.completedDate)) {
        return 'activeWarning';
      }


      return 'activeGreen';
    }


    return 'upcoming';
  }

  function isOverdue(completedDate) {
    var yesterday = new Date();
    yesterday.setHours(23);
    yesterday.setMinutes(59);
    yesterday.setDate(yesterday.getDate() - 1);
    return yesterday.getTime() > completedDate.getTime();
  }


  function isWithOneDay(completedDate) {
    var tomorrow = new Date();
    tomorrow.setHours(23);
    tomorrow.setMinutes(59);
    tomorrow.setDate(tomorrow.getDate() + 1);
    var today = new Date().setHours(0, 0, 0, 0);
    return completedDate.getTime() >= today && completedDate.getTime() < tomorrow.getTime();
  }


  function inActiveTier(order, data) {
    var isInTier = false;
    angular.forEach(data, function (row) {
      if (row.order === order && row.activeAssignment) {
        isInTier = true;
      }
    });

    return isInTier;
  }


  function getPreviousEndDate(order, data) {
    var orderToFind = order - 1;
    var latestCompletionDate;
    orderToFind = findPreviousRow(orderToFind, data);
    if (!orderToFind) {
      return null;
    }

    angular.forEach(data, function (row) {
      if (row.order === orderToFind) {
        if (!latestCompletionDate || latestCompletionDate < row.completedDate) {
          latestCompletionDate = angular.copy(row.completedDate);
        }
      }
    });

    return latestCompletionDate;
  }

  function findPreviousRow(orderToFind, data) {
    var rowFound = null;
    angular.forEach(data, function (row) {
      if (row.order === orderToFind) {
        rowFound = row;
      }
    });

    if (rowFound && rowFound.reviewDispositionCode !== 'T') {
      return rowFound.order;
    } else {
      return findPreviousRow(orderToFind - 1, data);
    }
  }



  function getEndDate(startDate, duration) {

    var endDate = new Date(startDate);
    endDate.setDate(endDate.getDate() + duration);



    var days = businessDaysFromDate(startDate, duration);
    return days;

  }






  function businessDaysFromDate(date, businessDays) {
    var counter = 0,
      tmp = new Date(date);
    while (businessDays >= 0) {
      if (angular.isDate(date)) {
        tmp.setTime(date.getTime() + counter * 86400000);
      } else {
        tmp.setTime(date + counter * 86400000);
      }
      if (isBusinessDay(tmp)) {
        --businessDays;
      }
      ++counter;
    }
    return tmp;
  }

  function isBusinessDay(date) {
    var dayOfWeek = date.getDay();
    if (dayOfWeek === 0 || dayOfWeek === 6) {
      // Weekend
      return false;
    }

    var holidays = [
      '12/31+5', // New Year's Day on a saturday celebrated on previous friday
      '1/1', // New Year's Day
      '1/2+1', // New Year's Day on a sunday celebrated on next monday
      '1-3/1', // Birthday of Martin Luther King, third Monday in January
      '2-3/1', // Washington's Birthday, third Monday in February
      '5~1/1', // Memorial Day, last Monday in May
      '7/3+5', // Independence Day
      '7/4', // Independence Day
      '7/5+1', // Independence Day
      '9-1/1', // Labor Day, first Monday in September
      '10-2/1', // Columbus Day, second Monday in October
      '11/10+5', // Veterans Day
      '11/11', // Veterans Day
      '11/12+1', // Veterans Day
      '11-4/4', // Thanksgiving Day, fourth Thursday in November
      '12/24+5', // Christmas Day
      '12/25', // Christmas Day
      '12/26+1' // Christmas Day
    ];

    var dayOfMonth = date.getDate(),
      month = date.getMonth() + 1,
      monthDay = month + '/' + dayOfMonth;

    if (holidays.indexOf(monthDay) > -1) {
      return false;
    }

    var monthDayDay = monthDay + '+' + dayOfWeek;
    if (holidays.indexOf(monthDayDay) > -1) {
      return false;
    }

    var weekOfMonth = Math.floor((dayOfMonth - 1) / 7) + 1,
      monthWeekDay = month + '-' + weekOfMonth + '/' + dayOfWeek;
    if (holidays.indexOf(monthWeekDay) > -1) {
      return false;
    }

    var lastDayOfMonth = new Date(date);
    lastDayOfMonth.setMonth(lastDayOfMonth.getMonth() + 1);
    lastDayOfMonth.setDate(0);
    var negWeekOfMonth = Math.floor((lastDayOfMonth.getDate() - dayOfMonth - 1) / 7) + 1,
      monthNegWeekDay = month + '~' + negWeekOfMonth + '/' + dayOfWeek;
    if (holidays.indexOf(monthNegWeekDay) > -1) {
      return false;
    }

    return true;
  }



  return counselHelperService;
});
