(function () {
  'use strict';

  angular
    .module('ptabe2e').run(['$anchorScroll', function ($anchorScroll) {
      $anchorScroll.yOffset = 50; // always scroll by 50 extra pixels
    }])
    .controller('CompleteReviewModalController', function ($anchorScroll, $location, $scope, data, ngDialog, $sce) {
      $scope.gotoAnchor = function (x) {
        if (x !== 'O' && x !== 'RM') {
          x = 'Decisions';
        }
        var newHash = 'anchor' + x;
        if ($location.hash() !== newHash) {
          // set the $location.hash to `newHash` and
          // $anchorScroll will automatically scroll to it
          $location.hash('anchor' + x);
        } else {
          // call $anchorScroll() explicitly,
          // since $location.hash hasn't changed
          $anchorScroll();
        }
      };


      var vm = this;
      vm.selectedOption;
      vm.circulationInfo = data;
      vm.lastAssignment = data.lastAssignment;
      vm.resultItems = vm.circulationInfo.data.entity.reviewDispositionDetails;
      vm.type = vm.circulationInfo.data.entity.role === 'PA' ? "Complete update" : "Complete review";
      vm.typeBtn = vm.type;
      vm.message = vm.circulationInfo.data.entity.role === 'PA' ? 'If you have completed your update, click "Complete update" to and close the assignment.' : 'If you have completed your review, click "Complete review" button to close the assignment.';
      vm.theHeight = "278px;";
      vm.theHelpHeight = "371px;";
      vm.theButtonHelpHeight = "400px;";


      if (vm.circulationInfo.data.entity.assignmentTypeCode === 'CIRWR' || vm.circulationInfo.data.entity.assignmentTypeCode === 'CIRWRANDPR') {
        vm.type = "Complete additional decision materials";
        vm.typeBtn = "Complete content";
        vm.message = "If you completed additional decision materials, click Complete content to submit result and close assignment.";
      }

      if (vm.resultItems && vm.resultItems.length === 1) {
        vm.result = vm.resultItems[0].id;
        vm.theHeight = "80px;";
        if (vm.lastAssignment) {
          vm.theHeight = "136px;";
        }
      }

      var helpText = '<br><span id="anchorRM">Select \"Authorized for Mailing\" and click on \"Complete review" to sign off on the decision and complete the current draft review assignment</span><br><br>';
      helpText += '<span id="anchorDecisions">Select \"Concur\", \"Concur in Part", or \"Dissent\" to add a separate opinion. Check the box under the appropriate opinion type to create a new additional writing assignment for you.<br><br> When you complete the additional writing assignment, the paralegal team will be notified that your opinion draft is ready for review. Leave blank if your opinion draft has already been reviewed by the paralegal. <br><br>If you have not already done so, please add the link to your opinion draft to the document links table. After making the appropriate selections, click on \"Complete review\" to complete the current draft review assignment.</span><br><br>';
      helpText += '<span id="anchorO">Select \"Other\" and click on \"Complete review\" to complete the current draft review assignment without signing off on the decision. <br><br>If \"Other\" is selected, please add comments to the Pre-decision circulation notes tab.</span>';
      $scope.moreTrustedHtml = $sce.trustAsHtml(helpText);


      vm.setMessage = function (item) {
        if(item.reviewDispositionCode =='O' && (vm.selectedValueForApj == false ||vm.selectedValueForApj == undefined)){
vm.disableButton = true;
        } else {
          vm.disableButton = false;   
        }
        switch (item.reviewDispositionCode) {
          case 'C':
            vm.selectedOption = "concurring";
            break;
          case 'CIP':
            vm.selectedOption = "concurring-in-part";
            break;
          case 'D':
            vm.selectedOption = "dissenting";
            break;
          default:
            break;
        }
      };

      vm.closeCompleteReviewDialog = function () {
        ngDialog.closeAll(false);
      };

      vm.setApj = function(){
        vm.disableButton = false;
        if(vm.selectedValueForApj == false){
          vm.disableButton = true;
        }else{
          vm.disableButton = false;
        }
      }

      vm.completeReview = function () {
        if (vm.selectedValueForApj == '1'){
vm.selectedValueForApj = true;
        } else if(vm.selectedValueForApj == '2'|| vm.selectedValueForApj == undefined){
vm.selectedValueForApj = false;
        }
        var response = {
          "selectedReview": vm.result,
          "additionlWriting": vm.additionalWriting,
          "paralegalWritingAssignmentReview": vm.addParalegalReview,
          "createAPJ1ReviewAssignmentbyOtherAPJsWithOtherOption": vm.selectedValueForApj
        };
        ngDialog.closeAll(response);
      };

      vm.completeReviewOnly = function () {
        var response = {
          "selectedReview": vm.circulationInfo.data.entity.role === 'PA' ? 'UC' : 'RC',
          "additionlWriting": null
        };
        ngDialog.closeAll(response);
      };

    });
})();
