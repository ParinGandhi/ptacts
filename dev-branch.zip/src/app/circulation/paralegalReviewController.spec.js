(function () {
  'use strict';

  describe('ParalegalReviewController', function () {

    beforeEach(module('ptabe2e'))

    var vm = this;
    var scope;
    var controller, $controller;
    var $http, $interval, $rootScope;
    var $q, HttpFactoryDeferred;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close', 'open']);

    beforeEach(inject(function (_$controller_, _$http_, _$rootScope_, _$interval_, _$q_, HttpFactory) {
      $q = _$q_;
      $http = _$http_;
      scope = _$rootScope_.$new();
      $interval = _$interval_;
      $rootScope = _$rootScope_;
      scope.ngDialogData = [{
        estimatedLoeDaysQt: 3
      }]

      // setup the promise
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);

      $controller = _$controller_;

      controller = $controller('ParalegalReviewController', {
        $http: $http,
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        $interval: $interval,
        HttpFactory: HttpFactory,
      });
    }));


    describe('check functions', function () {

      it(' should call udpateEndDate', function () {
        expect(controller.udpateEndDate).toBeDefined();
        controller.udpateEndDate();
      });

    });
  });
})();
