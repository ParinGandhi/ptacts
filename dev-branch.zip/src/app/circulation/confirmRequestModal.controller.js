(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('ConfirmRequestModalController', function ($scope, HttpFactory, ngDialog) {
      var vm=this;
      
      vm.data = $scope.ngDialogData;

    });
})();
