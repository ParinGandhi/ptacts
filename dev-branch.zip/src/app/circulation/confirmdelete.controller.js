(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .controller('confirmdeleteController', function ($scope, ngDialog, id, loggedInUser, HttpFactory, CommonHelperService, CONSTANTS) {
      var vm = this;
      vm.id = id;
      vm.closeModal = function () {
        ngDialog.closeAll();
      };


      vm.deleteDocument1 = function () {
        HttpFactory.deleteActions("/circulation-artifact/" + vm.id + "/" + loggedInUser)
          .then(function () {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.deleteDoc, "success");
            $scope.confirm();
          }, function () {
            vm.disableSubmit = false;
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.deleteDocFail, "error");

          });
      };

    });
})();
