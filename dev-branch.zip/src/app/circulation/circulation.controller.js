"use strict";
angular
  .module('ptabe2e')
  .controller('CirculationManagerController',
    function (ngDialog, HttpFactory, toastr, $scope, $timeout, uiGridConstants, $route, $window, CONSTANTS,
      $filter, CommonHelperService, SearchHelperService, CirculationHelperService) {

      var vm = this;
      vm.startDate = new Date();
      vm.assignmentId = $route.current.params.assignmentId;
      vm.updatedDate = new Date();
      vm.currentTab = 'circulation';
      vm.circulationStartDate = new Date();
      vm.userIsAPJ1 = false;
      vm.userIsParalegal = true;
      vm.message;
      vm.currentLoggedInRole;
      vm.followOnActions = {
        "message": null,
        "closeWindow": false
      };
      vm.changesMade = false;
      var removedCirculationAssignmentBag = [];
      var addedCirculationAssignmentBag = [];
      var originalPanel;
      var fromInitiateParalegalOnly = false;
      var fromInitiateCirculation = false;
      var fromUpdateCirculation = false;
      var activeOrderNo;
      var deletedActiveAssignment;
      vm.completeReviewData;
      vm.caseMailed = false;
      vm.paralegalLoggedIn = false;
      vm.isParalegalReviewOnly = false;
      vm.inProgress = false;
      vm.applicationNumber;
      vm.caseNumber;
      vm.readOnlyMode;
      vm.circulationNotes = {};
      var previousTab = "circulation";
      $scope.isLoading = false;
      var saveNotesBeforeInitiation = false;
      var notesBeforeInitiation = {};
      var mailingInstructions;
      vm.addMailingInstructions = false;
      var updateStatusCodeList = ['UPDATE_CIRC', 'MAILED'];
      vm.notesIndicator = 0;
      vm.showButtons = false;
      var shareAssign;
      var role;
      var foreignpatList = [];
      var nonpatList = [];




      function getprefix() {
        var prefix = "fromJudgePortal";
        var id = "";
        role = window.name.substring(window.name.indexOf("roleDescription") + 20, window.name.indexOf("roleDescription") + 25);
        if (window.name && window.name.substring(0, prefix.length) === prefix && role != "Judge") {
          console.log(window.name.indexOf("ptabAssignmentId"));
          console.log(window.name);
          id = window.name.substring(window.name.indexOf("ptabAssignmentId") + 18, window.name.indexOf("}"));
          //vm.showButtons = true;
          getDetails(id);
        }
        else {
          vm.showButtons = false;
        }
      }

      function resetButtonActions() {
        vm.buttonActions = {
          "showSave": false,
          "showInitiate": false,
          "showCircUpdate": false,
          "showReadyForMail": false
        };
      }
      resetButtonActions();

      vm.loadCirculationManager = function () {
        vm.caseNumber = $route.current.params.caseNumber;
        vm.applicationNumber = $route.current.params.applicationNumber;
        vm.loggedInUser = $window.sessionStorage.getItem("workerNumber");
        $timeout(function () {
          getPanelists();
        }, 2000);
        console.info("CirculationManager");
        getApjName();
      };

      vm.circulationGridOptions = {
        enableFiltering: true,
        enableSorting: true,
        enableRowSelection: false,
        enableSelectAll: false,
        enableGridMenu: true,
        exporterMenuCsv: false,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        treeRowHeaderAlwaysVisible: false,
        enableCellEditOnFocus: true,
        useExternalFiltering: true,
        cellEditableCondition: function ($scope) {
          var editable = false;
          if ($scope.row.entity.activeAssignment) {
            if (vm.loggedInUser === $scope.row.entity.assigneeUserId) {
              editable = true;
            }
          } else {
            editable = false;
          }
          return editable;
        },
        columnDefs: [{
          displayName: 'Order',
          name: 'order',
          field: 'order',
          type: 'number',
          cellTemplate: "<div ng-disabled=\"!grid.appScope.vm.userIsAPJ1\" style=\"text-align:center; padding-top:5px;\" class=\"truncateTitle\" ng-model=\"row.entity.order\" ng-change=\"grid.appScope.checkForChanges()\">{{row.entity.order}}</div>",
          cellEditableCondition: function ($scope) {
            if (vm.userIsAPJ1 && !$scope.row.entity.dispositionTimestamp && !$scope.row.entity.activeAssignment) {
              return true;
            } else {
              return false;
            }
          },
          cellClass: function (grid, row) {
            if (vm.userIsAPJ1 && !row.entity.dispositionTimestamp && !row.entity.activeAssignment) {
              return 'editableDecision';
            } else {
              return '';
            }
          },
          headerTooltip: 'Order',
          cellTooltip: true,
          width: '6%',
          minWidth: 50,
          rowHeight: 38
        },
        {
          displayName: 'Role',
          name: 'role',
          field: 'role',
          headerTooltip: 'Reviewer role',
          cellTooltip: true,
          cellClass: 'green',
          width: '9%',
          minWidth: 100,
          cellEditableCondition: false,
          cellTemplate: '<div ng-if="!row.entity.supervisorName" style="margin-top: 5px; margin-left:5px;">{{row.entity.role}}</div>' +
            '<div ng-if="row.entity.supervisorName" title="Supervisor - {{row.entity.supervisorName}}" style="margin-top: 5px; margin-left:5px; cursor: pointer;">' +
            '<a>{{row.entity.role}} </a>' +
            '<i class="fas fa-info-circle" title="Supervisor - {{row.entity.supervisorName}}" style="cursor: pointer;"></i>' +
            '<a href="" ng-if="row.entity.descriptionTx || row.entity.dispositionTimestamp" title="{{row.entity.descriptionTx}}">' +
            '<i style="color:#444;margin-left:.3em;" class="fas fa-book"></i><span class="sr-only">{{row.entity.descriptionTx}}</span></a></div > '
        },
        {
          displayName: 'Name',
          name: 'assigneeName',
          field: 'assigneeName',
          headerTooltip: 'Name',
          cellTooltip: true,
          width: '12%',
          minWidth: 152,
          cellEditableCondition: false
        },
        {
          displayName: 'Assignment type',
          name: 'assignmentType',
          field: 'assignmentType',
          cellEditableCondition: false,
          headerTooltip: 'Assignment type',
          cellTemplate: "<div style=\"padding-top:5px;\" class=\"truncateTitle\"><span style=\"margin-left:8px;padding-top:5px;\">{{row.entity.assignmentType}}</span></div>",
          cellTooltip: true,
          minWidth: 285
        },
        {
          displayName: 'Duration',
          name: 'estimatedLoeDaysQt',
          field: 'estimatedLoeDaysQt',
          headerTooltip: 'Estimated days to commplete assignment',
          cellTemplate: "<div ng-disabled=\"!grid.appScope.vm.userIsAPJ1\" style=\" text-align:center; padding-top:5px;\" class=\"truncateTitle\">{{row.entity.estimatedLoeDaysQt}}</div>",
          cellEditableCondition: function ($scope) {
            if (vm.userIsAPJ1 && !$scope.row.entity.dispositionTimestamp) {
              return true;
            } else {
              return false;
            }
          },
          cellClass: function (grid, row) {
            if (vm.userIsAPJ1 && !row.entity.dispositionTimestamp) {
              return 'editableDecision';
            } else {
              return '';
            }
          },
          cellTooltip: true,
          width: '6%',
          minWidth: 50,
          type: 'number'
        },
        {
          displayName: 'Start date',
          name: 'startDate',
          field: 'startDate',
          headerTooltip: 'Start date of assignment',
          cellTooltip: true,
          cellEditableCondition: false,
          cellTemplate: '<div ng-if="row.entity.activeAssignment || row.entity.dispositionTimestamp" style="margin-left: 8px; padding-top:5px;">{{row.entity.startDate | date:"MM/dd/yyyy hh:mm:ss a"}}</div>' +
            '<div ng-if="!row.entity.activeAssignment" style="margin-left: 8px; padding-top:5px;">{{row.entity.startDate | date:"MM/dd/yyyy"}} (est)</div>',
          type: 'date',
          cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'",
          width: '12%',
          minWidth: 152
        },
        {
          displayName: 'End date',
          name: 'completedDate',
          field: 'completedDate',
          headerTooltip: 'End date of assignment',
          cellTooltip: true,
          cellTemplate: '<div ng-if="!row.entity.dispositionTimestamp" style=\" margin-left: 8px; padding-top:5px;\">{{row.entity.completedDate | date:"MM/dd/yyyy"}} (est)</div>' +
            '<div ng-if="row.entity.dispositionTimestamp" style=\" margin-left: 8px; padding-top:5px;\">{{row.entity.completedDate | date:"MM/dd/yyyy hh:mm:ss a"}}</div>',
          type: 'date',
          cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'",
          width: '12%',
          minWidth: 152,
          cellEditableCondition: false
        },
        {
          name: 'result',
          displayName: 'Results',
          field: 'reviewDispositionCodeDescription',
          type: 'string',
          width: '12%',
          minWidth: 142,
          cellEditableCondition: false,
          headerTooltip: 'Assignment results',
          cellClass: function (grid, row) {
            if (!vm.buttonActions.showInitiate) {
              recalculateGrid();
              return CirculationHelperService.getResultsClass(row, vm.circulationGridOptions.data);
            }
          }
        },
        {
          name: 'Actions',
          width: '9%',
          minWidth: 92,
          enableFiltering: false,
          enableSorting: false,
          enableHiding: false,
          headerTooltip: 'Actions',
          cellTooltip: true,
          cellTemplate: '<div ng-if="row.entity.dispositionTimestamp">' +
            '<button class="btn btn-default btn-hover btn-icon-only" title="Review completed">' +
            '<i class="fas fa-check-circle" style="color: #007A33"></i>' +
            '<span class="sr-only">Review complete</span></button> ' +
            '</div>' +
            '<div ng-if="!row.entity.dispositionTimestamp">' +
            '<div ng-if="row.entity.activeAssignment && row.entity.assigneeUserId === grid.appScope.vm.loggedInUser">' +
            '<button class="btn btn-primary btn-xs" ng-click="grid.appScope.vm.completeReview(row, \'COMPLETE_REVIEW\')" ng-if="grid.appScope.vm.buttonActions.showCircUpdate" style="margin-top: .3em; margin-left: .3em;">' +
            '<span ng-if="row.entity.role === \'PA\'" title="Complete update">Complete update</span>' +
            '<span ng-if="row.entity.role !== \'PA\'" title="Complete review">Complete review</span></button>' +
            '<button ng-if="grid.appScope.vm.userIsAPJ1" class="btn btn-default btn-hover btn-icon-only" title="Remove from circulation" ng-click="grid.appScope.deleteRow($event, row)">' +
            '<i class="fas fa-times-circle" style="color: #A6192E"></i><span class="sr-only">Remove from circulation</span></button> ' +
            '</div>' +
            '</div>' +
            '<div ng-if="grid.appScope.vm.userIsAPJ1">' +
            '<button class="btn btn-default btn-hover btn-icon-only" title="Remove from circulation" ng-click="grid.appScope.deleteRow($event, row)"><i class="fas fa-times-circle" style="color: #A6192E"></i><span class="sr-only">Remove from circulation</span></button>' +
            '<button ng-if="!row.entity.dispositionTimestamp" ng-disabled="grid.appScope.vm.disableUndo(row)" class="btn btn-default btn-hover btn-icon-only" title="Cancel review assignment" ng-click="grid.appScope.vm.cancelAssignment(row)"><i class="fas fa-undo"></i><span class="sr-only">Remove from circulation</span></button>' +
            '</div>',
          cellEditableCondition: false
        }
        ]
      };

      vm.circulationGridOptions.onRegisterApi = function (gridApi) {
        vm.gridApi = gridApi;
        vm.gridApi.edit.on.afterCellEdit($scope, function (rowEntity, colDef, newValue, oldValue) {
          if (rowEntity.order >= activeOrderNo && newValue !== oldValue && colDef.field === 'order') {
            var foundDuplicate = false;
            angular.forEach(vm.originalCirculationGridOptionsData, function (item) {
              if (!foundDuplicate) {
                if (rowEntity.role === item.role && rowEntity.order === item.order) {
                  foundDuplicate = true;
                  var rowToReplace = {};
                  rowToReplace.entity = item;
                  ngDialog.open({
                    template: 'app/circulation/circulationConfirmation.modal.html',
                    controller: 'CirculationConfirmationController',
                    controllerAs: 'vm',
                    width: '25%',
                    showClose: false,
                    closeByEscape: false,
                    closeByDocument: false,
                    resolve: {
                      flag: function () {
                        return 'replace';
                      },
                      rowToDelete: function () {
                        return rowToReplace;
                      }
                    }
                  }).closePromise.then(function (response) {
                    if (response.value) {
                      item.estimatedLoeDaysQt = rowEntity.estimatedLoeDaysQt;
                      var index = vm.originalCirculationGridOptionsData.indexOf(rowEntity);
                      console.log(index);
                      var modifiedAssignment = vm.originalCirculationGridOptionsData.splice(vm.originalCirculationGridOptionsData.indexOf(rowEntity), 1);
                      modifiedAssignment[0].startDate = angular.isDate(modifiedAssignment[0].startDate) ? modifiedAssignment[0].startDate.setHours(0, 0, 0, 0) : modifiedAssignment[0].startDate;
                      modifiedAssignment[0].completedDate = angular.isDate(modifiedAssignment[0].completedDate) ? modifiedAssignment[0].completedDate.setHours(0, 0, 0, 0) : modifiedAssignment[0].completedDate;
                      removedCirculationAssignmentBag.push(modifiedAssignment[0]);
                      vm.circulationGridOptions.data = angular.copy(vm.originalCirculationGridOptionsData);
                      recalculateGrid();
                    } else {
                      rowEntity.order = oldValue;
                    }
                  });
                }
              }
            });
          }
          if (newValue !== oldValue) {
            rowEntity.State = "changed";
            rowEntity.movedToDifferentTier = true;
            rowEntity.previousTierNumber = oldValue;
            $scope.checkForChanges();
          }
          if (!foundDuplicate) {
            if (!newValue) {
              switch (colDef.field) {
                case 'order':
                  rowEntity.order = oldValue;
                  CommonHelperService.setToastr(colDef.displayName + ' is required.', "error");
                  break;
                case 'duration':
                  rowEntity.duration = oldValue;
                  CommonHelperService.setToastr(colDef.displayName + ' is required.', "error");
                  break;
                default:
              }
            } else if (rowEntity.order < activeOrderNo) {
              rowEntity.order = oldValue;
              CommonHelperService.setToastr('Order number must be ' + activeOrderNo + ' or more.', "error");
            } else {
              recalculateGrid();
            }
          } else {
            recalculateGrid();
          }
        });
        $scope.gridApi = gridApi;
        $scope.gridApi.core.on.filterChanged($scope, function () {
          var grid = this.grid;
          $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
          if ($scope.numberOfFilters === 0) {
            vm.circulationGridOptions.data = $scope.originalCirculationGrid;
          } else {
            var filteredData = SearchHelperService.filterGrid(grid, $scope.originalCirculationGrid);
            vm.circulationGridOptions.data = filteredData;
          }
        });
      };

      vm.documentsGridOptions = {
        enableFiltering: true,
        enableGridMenu: true,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.WHEN_NEEDED,
        exporterMenuCsv: false,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        treeRowHeaderAlwaysVisible: false,
        useExternalFiltering: true,
        rowHeight: 45,
        columnDefs: [{
          displayName: 'Description',
          name: 'artifactTitleName',
          field: 'artifactTitleName',
          headerTooltip: 'Description',
          cellTooltip: true
        },
        {
          displayName: 'Path/File',
          name: 'artifactUrlText',
          field: 'artifactUrlText',
          headerTooltip: 'Link to file on S:drive',
          cellTemplate: "<div style=\" margin-left: 8px; padding-top:5px;\"><a ng-click='grid.appScope.openDoc(row.entity)' target='_blank'>{{row.entity.artifactUrlText}}</a></div>",
          cellTooltip: false
        },
        {
          displayName: 'Modified date',
          name: 'lastModifiedTimestamp',
          field: 'lastModifiedTimestamp',
          headerTooltip: 'Modified date',
          cellTooltip: true,
          visible: false,
          cellTemplate: "<div title= \"{{row.entity.audit.lastModifiedTimestamp | date:'MM/dd/yyyy hh:mm:ss a'}}\" style=\" margin-left: 8px; padding-top:5px;\">{{row.entity.audit.lastModifiedTimestamp | date:'MM/dd/yyyy hh:mm:ss a'}} </div>",
          type: 'date',
          cellFilter: "date:'MM/dd/yyyy'",
          width: 200
        },
        {
          displayName: 'Modified by',
          name: 'modifiedUserName',
          field: 'modifiedUserName',
          visible: false,
          cellTemplate: "<div title= \"{{row.entity.modifiedUserName}}\" style=\" margin-left: 8px; padding-top:5px;\">{{row.entity.modifiedUserName}} </div>",
          headerTooltip: 'Modified by',
          cellTooltip: true,
          width: 150
        },
        {
          name: 'Actions',
          width: 130,
          enableFiltering: false,
          enableSorting: false,
          enableHiding: false,
          headerTooltip: 'Actions', // ng-click=\"grid.appScope.copyDocument(row.entity)\"
          cellTooltip: true,
          cellTemplate: '<div class="btn-group" style="margin-left:.2em; padding-top:2px;">' +
            '<button class="btn btn-xs btn-default btn-icon-only btn-hover" title="Edit link" ng-disabled="grid.appScope.vm.readOnlyMode" ng-click="grid.appScope.editDocument(row.entity)">' +
            ' <i class="far fa-edit"></i><span class="sr-only">Edit link</span></button>' +
            '<button class="btn btn-xs btn-default btn-icon-only btn-hover" title="Copy path to clipboard" ng-disabled="grid.appScope.vm.readOnlyMode" ng-click="grid.appScope.copyDocument(row.entity)">' +
            ' <i class="far fa-copy"></i><span class="sr-only">Copy link</span></button>' +
            '<button class="btn btn-xs btn-default btn-icon-only btn-hover" title="Copy path to new row" ng-disabled="grid.appScope.vm.readOnlyMode" ng-click="grid.appScope.copyToNewRow(row.entity)">' +
            ' <i class="fas fa-stream"></i><span class="sr-only">Copy link</span></button>' +
            '<button style="margin-left:-.5em;"  class="btn btn-xs btn-default btn-icon-only btn-hover" title="Remove link" ng-disabled="grid.appScope.vm.readOnlyMode || row.entity.artifactType === \'p\'" ng-click="grid.appScope.deleteDocument(row.entity.circulationArtifactIdentifier)">' +
            ' <i class="far fa-times-circle"></i><span class="sr-only">Remove link</span></button></div>'
        }
        ]
      };

      vm.disableUndo = function (row) {
        var theClass = CirculationHelperService.getResultsClass(row, vm.circulationGridOptions.data);
        var isUpcoming = theClass === 'upcoming';
        return isUpcoming;
      };

      vm.documentsGridOptions.onRegisterApi = function (gridApi) {
        vm.documentsGridApi = gridApi;
        $scope.gridApi = gridApi;
        $scope.gridApi.core.on.filterChanged($scope, function () {
          var grid = this.grid;
          $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
          if ($scope.numberOfFilters === 0) {
            vm.documentsGridOptions.data = $scope.myData1;
          } else {
            var filteredData = SearchHelperService.filterGrid(grid, $scope.myData1);
            vm.documentsGridOptions.data = filteredData;
          }
        });
      };

      function getExternalUrls() {
        HttpFactory.getActions(CONSTANTS.URL.EXTERNALURLS)
          .then(function (successResponse) {
            $scope.externalUrls = [];
            for (var key in successResponse.data) {
              if (key !== "Open in PTOZone" && key !== "ptabReadOnlyUser" && key !== "allowedResourceObjectList" &&
                key !== "ptabDueDateNonEditableUser" && key !== 'ptabDefaultRefreshTime') {
                var url = {
                  description: key,
                  url: successResponse.data[key]
                };
                $scope.externalUrls.push(url);
              }
            }
          });
      }
      getExternalUrls();

      $timeout(function () {
        setAriaAttribute('mceu_0', 'Undo');
        setAriaAttribute('mceu_1', 'Redo');
        setAriaAttribute('mceu_2', 'Bold');
        setAriaAttribute('mceu_3', "Italic");
        setAriaAttribute('mceu_4', "insert link");
        setAriaAttribute('mceu_14', 'Undo');
        setAriaAttribute('mceu_13', 'Undo');
        setAriaAttribute('mceu_15', 'Redo');
        setAriaAttribute('mceu_16', 'Bold');
        setAriaAttribute('mceu_17', "Italic");
        setAriaAttribute('mceu_18', "insert link");
      }, 2000);

      function setAriaAttribute(timeMcButtonId, text) {
        try {
          var tinyMcButton = document.getElementById(timeMcButtonId);
          var tinyMcButtonHTML = tinyMcButton.childNodes[0];
          tinyMcButtonHTML.setAttribute("aria-label", text);
        } catch (error) {
          console.info("Error finding TinyMCE button");
        }
      }

      $scope.deleteDocument = function (id) {
        vm.id = id;
        ngDialog.openConfirm({
          template: 'app/circulation/confirmdelete.html',
          controller: 'confirmdeleteController',
          controllerAs: 'vm',
          width: '30%',
          resolve: {
            id: function () {
              return vm.id;
            },
            loggedInUser: function () {
              return vm.loggedInUser;
            }
          }
        }).then(function () {
          getDocumentsLink();
        }, function () {
          console.info("message");
          getDocumentsLink();
        });

      };

      function buildCirculationAndDocumentData() {
        vm.circulationGridOptions.data = $filter('orderBy')(vm.panel, 'order');
        console.log("Circulation after GET: %o", vm.circulationGridOptions.data);
        for (var i = 0; i < vm.circulationGridOptions.data.length; i++) {
          vm.circulationGridOptions.data[i].result = vm.circulationGridOptions.data[i].reviewDispositionCode ? vm.circulationGridOptions.data[i].reviewDispositionCode : null;
        }
        vm.documentsGridOptions.data = [];
        vm.noMoreAssignments = allReviewsAreComplete() && vm.circulationGridOptions.data.length > 0;

      }

      $scope.checkForChanges = function () {
        var currentData = buildComparisonLists(vm.circulationGridOptions.data);
        var originalData = buildComparisonLists(vm.originalCirculationGridOptionsData);
        if (!angular.equals(currentData, originalData)) {
          vm.changesMade = true;
        }
      };

      vm.showResults = function () {
        console.log(vm.circulationGridOptions.data);
      };

      vm.checkForTabChanges = function (tab) {
        if (vm.notesIndicator > 0 && tab === 'notes') {
          markNotesAsRead();
        }
        var currentData = buildComparisonLists(vm.circulationGridOptions.data);
        var originalData = buildComparisonLists(vm.originalCirculationGridOptionsData);
        console.log(angular.equals(currentData, originalData) && !vm.circulationNotes.noteText);
        if (angular.equals(currentData, originalData) && !vm.circulationNotes.noteText && angular.equals(vm.mailingNotes, vm.originalMailingNotes)) {
          vm.currentTab = tab;
          previousTab = tab;
        } else {
          var flag = 'unsaved';
          ngDialog.open({
            template: 'app/circulation/circulationConfirmation.modal.html',
            controller: 'CirculationConfirmationController',
            controllerAs: 'vm',
            width: '25%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              rowToDelete: function () {
                return null;
              },
              flag: function () {
                return flag;
              }
            }
          }).closePromise.then(function (response) {
            if (response.value) {
              vm.circulationGridOptions.data = angular.copy(vm.originalCirculationGridOptionsData);
              vm.circulationNotes.noteText = "";
              vm.currentTab = tab;
              vm.changesMade = false;
              vm.newDecisionDueDate = angular.copy(vm.decisionDueDate);
              vm.mailingNotes = angular.copy(vm.originalMailingNotes);
              previousTab = tab;
            } else {
              setPreviousTabAsActive();
            }
          });
        }
      };

      function markNotesAsRead() {
        HttpFactory.putActions('/circulation-notes/user-read-circulation-note?userId=' + vm.loggedInUser + '&circulationId=' + vm.circulationInfo.circulationIdentifier)
          .then(function (markedNotesAsReadSuccess) {
            console.log('markedNotesAsReadSuccess: ', markedNotesAsReadSuccess);
            vm.notesIndicator = 0;
          }, function (markedNotesAsReadFailure) {
            console.log('markedNotesAsReadFailure: ', markedNotesAsReadFailure);
          });
      }

      function setPreviousTabAsActive() {
        var circulationTab = document.getElementById("circulation");
        var notesTab = document.getElementById("notes");
        var historyTab = document.getElementById("history");
        circulationTab.classList.remove('active');
        notesTab.classList.remove('active');
        historyTab.classList.remove('active');
        switch (previousTab) {
          case 'circulation':
            circulationTab.classList.add('active');
            break;
          case 'notes':
            notesTab.classList.add('active');
            break;
          case 'history':
            historyTab.classList.add('active');
            break;
          default:
            break;
        }
      }

      function buildComparisonLists(dataList) {
        var tempList = [];
        angular.forEach(dataList, function (item) {
          var startDate;
          if (angular.isDate(item.startDate)) {
            startDate = item.startDate.getTime();
          } else {
            startDate = item.startDate;
          }
          var tempItem = {
            "order": item.order,
            "estimatedLoeDaysQt": item.estimatedLoeDaysQt,
            "startDate": startDate,
            "result": item.result
          };
          tempList.push(tempItem);
        });
        return tempList;
      }

      $scope.copyLink = function () {
        console.info("IMhere");
        var copyText = document.getElementById("myInput");
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        document.execCommand("copy");
      };

      vm.addToCirculation = function () {
        ngDialog.open({
          template: 'app/circulation/addCirculationModal.html',
          controller: 'AddCirculationController',
          controllerAs: 'vm',
          width: '25%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            originalPanel: function () {
              return originalPanel;
            },
            gridData: function () {
              return vm.circulationGridOptions.data;
            }
          }
        }).closePromise.then(function (response) {
          if (response.value) {
            if (response.value.insertOrder) {
              insertCirculationRow(response.value);
            } else {
              addCirculationRow(response.value);
            }
            vm.recalculate();
            $scope.checkForChanges();
          }
        });
      };

      function addCirculationRow(circulation) {
        var replacedExisting = false;
        for (var i = 0; i < vm.circulationGridOptions.data.length; i++) {
          if (vm.circulationGridOptions.data[i].order === circulation.order && vm.circulationGridOptions.data[i].role === circulation.role) {
            vm.circulationGridOptions.data[i].estimatedLoeDaysQt = circulation.estimatedLoeDaysQt;
            vm.circulationGridOptions.data[i].currentlyActive = vm.circulationGridOptions.data[i].activeAssignment;
            replacedExisting = true;
          }
        }
        vm.recalculate();
        if (!replacedExisting) {
          addNewReviewer(circulation);
        }
      }

      function insertCirculationRow(circulation) {
        for (var i = 0; i < vm.circulationGridOptions.data.length; i++) {
          if (vm.circulationGridOptions.data[i].order >= circulation.order) {
            vm.circulationGridOptions.data[i].order++;
          }
        }
        vm.recalculate();
        addNewReviewer(circulation);
      }

      function addNewReviewer(circulation) {
        var index;
        for (var i = 0; i < originalPanel.length; i++) {
          if (originalPanel[i].role === circulation.role && circulation.assignmentType.includes(originalPanel[i].assignmentType)) {
            // if (originalPanel[i].role === circulation.role) {
            index = i;
          }
        }
        var newReviewer = angular.copy(originalPanel[index]);
        newReviewer.estimatedLoeDaysQt = circulation.estimatedLoeDaysQt;
        newReviewer.order = circulation.order;
        if (newReviewer.order === activeOrderNo) {
          newReviewer.currentlyActive = true;
        }
        newReviewer.circulationLevelIdentifier = circulation.circulationLevelIdentifier;
        newReviewer.ptabAssignmentIdentifier = null;
        newReviewer.assignmentTypeCode = setAssignmentTypeCode(circulation.role, circulation.assignmentType);
        vm.circulationGridOptions.data.push(newReviewer);
        addedCirculationAssignmentBag.push(newReviewer);
        vm.recalculate();
        for (var j = 0; j < vm.circulationGridOptions.data.length; j++) {
          if (vm.circulationGridOptions.data[j].role === circulation.role &&
            vm.circulationGridOptions.data[j].estimatedLoeDaysQt === circulation.estimatedLoeDaysQt &&
            vm.circulationGridOptions.data[j].order === circulation.order) {
            index = j;
          }
        }
        var latest = addedCirculationAssignmentBag.length - 1;
        var currentTime = new Date().getTime();
        addedCirculationAssignmentBag[latest].startDate = addedCirculationAssignmentBag[latest].order === activeOrderNo ? currentTime : vm.circulationGridOptions.data[index].startDate;
        addedCirculationAssignmentBag[latest].completedDate = addedCirculationAssignmentBag[latest].order === activeOrderNo ? currentTime : vm.circulationGridOptions.data[index].completedDate;
      }

      function setAssignmentTypeCode(code, assignmentType) {
        switch (code) {
          case 'Initiate':
            return 'CIRC';
          case 'Paralegal':
            return 'CIRPR';
          case 'PA':
            return 'CIRPA';
          case 'APJ9':
            return 'CIRAPJ9';
          case 'APJ8':
            return 'CIRAPJ8';
          case 'APJ7':
            return 'CIRAPJ7';
          case 'APJ6':
            return 'CIRAPJ6';
          case 'APJ5':
            return 'CIRAPJ5';
          case 'APJ4':
            return 'CIRAPJ4';
          case 'APJ3':
            return 'CIRAPJ3';
          case 'APJ2':
            return 'CIRAPJ2';
          case 'APJ1':
            if (null != assignmentType && assignmentType.includes('APJ1 review paralegal comments')) {
              return 'CIRAPJC';
            } else if (null != assignmentType && assignmentType.includes('APJ1 review panel comments')) {
              return 'CIRAPJ1';
            } else {
              return 'CIRAPJ1RDD';
            }
            break;
          default:
            break;
        }
      }

      vm.recalculate = function () {
        recalculateGrid();
        vm.circulationGridOptions.data = $filter('orderBy')(vm.circulationGridOptions.data, 'order');
      };

      /* Recalculates the start and stop times of active and future tiers */
      function recalculateGrid() {
        vm.circulationGridOptions.data = $filter('orderBy')(vm.circulationGridOptions.data, 'order');
        angular.forEach(vm.circulationGridOptions.data, function (row) {
          if (!row.dispositionTimestamp) {
            if (row.activeAssignment) {
              row.startDate = new Date(row.startDate);
              row.completedDate = CirculationHelperService.getEndDate(row.startDate, row.estimatedLoeDaysQt);
              row.completedDate.setDate(row.completedDate.getDate());
            } else {
              row.startDate = getStartDate(row);
              row.completedDate = CirculationHelperService.getEndDate(row.startDate, row.estimatedLoeDaysQt);
              row.completedDate.setDate(row.completedDate.getDate());
            }
          }
        });
        // Estimated mail date as seen above circulation manager grid
        try {
          if (!vm.buttonActions.showInitiate) {
            vm.newDecisionDueDate = vm.circulationGridOptions.data[vm.circulationGridOptions.data.length - 1].completedDate;
          }
        } catch (error) {
          console.error(error);
        }
      }

      function getStartDate(row) {
        if (row.order === CirculationHelperService.lowestTier(vm.circulationGridOptions.data)) {
          return angular.copy(vm.circulationStartDate);
        } else {
          var previousEndDate = CirculationHelperService.getPreviousEndDate(row.order, vm.circulationGridOptions.data);
          if (CirculationHelperService.inActiveTier(row.order, vm.circulationGridOptions.data)) {
            return new Date();
          }
          previousEndDate = CirculationHelperService.getEndDate(previousEndDate, 1);
          return previousEndDate;
        }
      }

      $scope.deleteRow = function ($event, row) {
        console.info("delete row");
        var flag = row.entity.activeAssignment ? 'delete' : 'deleteInactive';
        ngDialog.open({
          template: 'app/circulation/circulationConfirmation.modal.html',
          controller: 'CirculationConfirmationController',
          controllerAs: 'vm',
          width: '25%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            rowToDelete: function () {
              return row;
            },
            flag: function () {
              return flag;
            }
          }
        }).closePromise.then(function (response) {
          if (response.value) {
            vm.changesMade = true;
            var deletedAssignment = vm.circulationGridOptions.data.splice(vm.circulationGridOptions.data.indexOf(row.entity), 1);
            deletedAssignment[0].startDate = angular.isDate(deletedAssignment[0].startDate) ? deletedAssignment[0].startDate.setHours(0, 0, 0, 0) : deletedAssignment[0].startDate;
            deletedAssignment[0].completedDate = angular.isDate(deletedAssignment[0].completedDate) ? deletedAssignment[0].completedDate.setHours(0, 0, 0, 0) : deletedAssignment[0].completedDate;
            deletedAssignment[0].currentlyActive = deletedAssignment[0].activeAssignment;
            deletedActiveAssignment = deletedAssignment[0].order === activeOrderNo ? true : false;
            if (vm.circulationInfo.circulationRecordsExists) {
              /** Check if  deleting a recently added */
              if (!recentlyAdded(deletedAssignment[0])) {
                removedCirculationAssignmentBag.push(deletedAssignment[0]);
              }
            }
            vm.recalculate();
            console.log("Just got deleted: %o", removedCirculationAssignmentBag);
          }
        });
      };

      /** If deleteing a recently added assignment (before updating the circulation), then remove the assignment from the add bag and delete bag */
      function recentlyAdded(itemToDelete) {
        var indexToRemove;
        var removeFromAddBag = false;
        for (var i = 0; i < addedCirculationAssignmentBag.length; i++) {
          if (angular.equals(itemToDelete, addedCirculationAssignmentBag[i])) {
            indexToRemove = i;
            removeFromAddBag = true;
          }
        }
        if (removeFromAddBag) {
          addedCirculationAssignmentBag.splice(indexToRemove, 1);
        }
        return removeFromAddBag;
      }

      function clearLists() {
        removedCirculationAssignmentBag = [];
        addedCirculationAssignmentBag = [];
        vm.changesMade = false;
      }

      function getDocumentsLink() {
        HttpFactory.getActions("/circulation-artifact?appealNumber=" + vm.caseNumber + "&serialNumber=" + vm.applicationNumber)
          .then(function (successResponse) {
            // vm.documentsGridOptions.data = successResponse.data;
            vm.documentsGridOptions.data = [];
            angular.forEach(successResponse.data.circulationArtifacts, function (artifact) {
              artifact.artifactType = "c"
              vm.documentsGridOptions.data.push(artifact);
            });
            vm.returnObject = {
              prosecutionArtifacts: []
            };
            angular.forEach(successResponse.data.prosecutionArtifacts, function (artifact) {
              artifact.appealNumber = vm.caseNumber;
              artifact.serialNumber = vm.applicationNumber;
              artifact.audit = {};
              artifact.audit.lastModifiedTimestamp = new Date().getTime();
              artifact.audit.lastModifiedUserIdentifier = vm.loggedInUser;
              artifact.audit.createUserIdentifier = vm.loggedInUser;

              artifact.artifactType = "p";
              vm.returnObject.prosecutionArtifacts.push(artifact);
              vm.documentsGridOptions.data.push(artifact);
            })
            angular.forEach(vm.documentsGridOptions.data, function (row) {
              row.lastModifiedTimestamp = row.audit.lastModifiedTimestamp;
              row.modifiedUserName = row.modifiedUserName;
            });
            $scope.myData1 = angular.copy(vm.documentsGridOptions.data);

          });
      }

      vm.getCirculationData = function () {
        getPanelists();
      };

      function saveProsecuationDocs() {
        HttpFactory.getActions(CONSTANTS.URL.GET_CIRCULATION_DETAILS + vm.caseNumber + '&serialNumber=' + vm.applicationNumber + '&userId=' + vm.loggedInUser)
          .then(function (successResponse) {
            try {
              vm.circulationInfo = successResponse.data;
              vm.circulationIdentifier = vm.circulationInfo.circulationIdentifier;
              vm.returnObject.circulationIdentifier = vm.circulationIdentifier;
              HttpFactory.putActions("/circulation-artifact/update-artifacts", vm.returnObject)
                .then(function (successResponse) {
                  console.info("Saved artifacts");
                  vm.returnObject = null;
                });
            } catch (error) {
              console.error(error);
            }
          });
      }

      function getPanelists() {
        $scope.isLoading = true;
        HttpFactory.getActions(CONSTANTS.URL.GET_CIRCULATION_DETAILS + vm.caseNumber + '&serialNumber=' + vm.applicationNumber + '&userId=' + vm.loggedInUser)
          .then(function (successResponse) {
            vm.circulationInfo = successResponse.data;
            getprefix();
            if (window.name == "") {
              getIdentifierAndGetDetails(successResponse.data);
            }
            checkAssignmentTypeId();
            vm.circulationIdentifier = vm.circulationInfo.circulationIdentifier;
            originalPanel = successResponse.data.activePanelDetails;
            vm.originalCirculationInfo = angular.copy(successResponse.data);
            vm.panel = successResponse.data.circulationAssignmentBag;
            vm.new = angular.copy(!vm.circulationInfo.circulationRecordsExists);
            vm.marginLeft = vm.new ? '37em' : '52em';
            vm.userIsAPJ1 = vm.circulationInfo.apjOneloggedIn;
            clearLists();
            setActions(vm.circulationInfo.actions);
            vm.decisionDueDate = successResponse.data.assignmentDueDate;
            vm.assignmentIdToChangeDueDate = successResponse.data.assignmentIdToChangeDueDate;
            if (!vm.decisionDueDate) {
              vm.decisionDueDate = (new Date()).getTime();
            }
            vm.newDecisionDueDate = angular.copy(vm.decisionDueDate);
            vm.dueDateValid = true;
            if (vm.panel) {
              buildCirculationAndDocumentData();
            }
            checkForActiveAssignment();
            vm.recalculate();
            vm.originalCirculationGridOptionsData = angular.copy(vm.circulationGridOptions.data);
            $scope.originalCirculationGrid = angular.copy(vm.circulationGridOptions.data);
            vm.getAssignHistory();
            vm.getCirculationNotes();
            getDocumentsLink();
            getCaseData(vm.circulationInfo.ptabAssignmentIdForGloabalDetails);
            getRuling();
            getNotesCount();
            vm.readOnlyMode = false;
            if (!vm.circulationInfo.apjOneloggedIn) {
              vm.readOnlyMode = checkForReadOnly(vm.circulationInfo);
            }
            vm.updated = new Date();
            $scope.isLoading = false;
            console.log(vm.circulationInfo);
            console.log(vm.circulationGridOptions.data);
          }, function () {
            $scope.isLoading = false;
          });
      }

      function checkAssignmentTypeId() {
        if (vm.circulationInfo.circulationAssignmentBag[0].initialAPJ1ReviewButton && role != "Judge") {
          vm.showButtons = true;
        }
        else {
          vm.showButtons = false;
        }
      }

      function getNotesCount() {
        if (vm.loggedInUser && vm.circulationInfo.circulationIdentifier) {
          HttpFactory.getActions('/circulation-notes/counter?userId=' + vm.loggedInUser + '&circulationId=' + vm.circulationInfo.circulationIdentifier)
            .then(function (notesCountSuccess) {
              console.log('notesCountSuccess: ', notesCountSuccess);
              vm.notesIndicator = notesCountSuccess.data;
            }, function (notesCountFailure) {
              console.log('notesCountFailure: ', notesCountFailure);
            });
        }
      }

      function checkForReadOnly(circulationPanel) {
        var readOnly = true;
        angular.forEach(circulationPanel.activePanelDetails, function (panel) {
          if (panel.assigneeUserId === vm.loggedInUser) {
            readOnly = false;
          }
        });
        if (readOnly) {
          angular.forEach(circulationPanel.circulationAssignmentBag, function (panel) {
            if (panel.assigneeUserId === vm.loggedInUser) {
              readOnly = false;
            }
          });
        }
        return readOnly;
      }

      function checkForActiveAssignment() {
        if (vm.buttonActions.showCircUpdate) {
          var updateTier = true;
          var activeTier;
          var rightNow;
          var localActiveOrder;
          vm.circulationGridOptions.data.forEach(function (assignment) {
            if (updateTier) {
              activeTier = assignment.order;
            }
            if (assignment.assigneeUserId === vm.loggedInUser) {
              $scope.isParalegalOrSPL = true;
            }
            var startDate = angular.isDate(assignment.startDate) ? assignment.startDate.getTime() : assignment.startDate;
            rightNow = new Date().getTime();
            if (startDate <= rightNow && !assignment.dispositionTimestamp && activeTier === assignment.order) {
              startDate = new Date(startDate);
              if (updateTier || assignment.order === localActiveOrder) {
                assignment.activeAssignment = true;
                updateTier = false;
                localActiveOrder = assignment.order;
                activeOrderNo = assignment.order;
                vm.circulationGridOptions.columnDefs[7].editDropdownOptionsArray = setResultsDropdown(assignment.reviewDispositionDetails);
                if (assignment.assigneeUserId !== vm.loggedInUser && assignment.assignmentTypeCode === 'CIRPR') {
                  vm.paralegalLoggedIn = true;
                }
              }
            } else {
              assignment.activeAssignment = false;
            }
          });
        }
      }

      function setResultsDropdown(resultsList) {
        var newList = [];
        resultsList.forEach(function (result) {
          var resultObj = {
            "id": result.reviewDispositionCode,
            "result": result.descriptionText
          };
          newList.push(resultObj);
        });
        return newList;
      }

      function setActions(actions) {
        resetButtonActions();
        vm.dueDateLabel = "Estimated mail date";
        angular.forEach(actions, function (action) {
          switch (action) {
            case 'UPDATE_DRAFT':
              vm.buttonActions.showSave = true;
              break;
            case 'INITIATE':
              vm.buttonActions.showInitiate = true;
              vm.dueDateLabel = "Draft due date";
              break;
            case 'UPDATE_CIRC':
              vm.buttonActions.showCircUpdate = true;
              break;
            case 'READY FOR MAILING':
              vm.buttonActions.showReadyForMail = true;
              break;
            default:
              break;
          }
        });
      }

      function getCaseData(assignmentId) {
        HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTBYID + assignmentId)
          .then(function (successResponse) {
            vm.caseData = successResponse.data.globalMetaData;
            vm.caseData.caseTypes = [];
            vm.caseData.caseTypes.push(successResponse.data.globalMetaData.caseType);
            $window.document.title = vm.caseData.caseNumber + " - Circulation Manager";
          }, function (failureResponse) {
            console.log('failureResponse: ', failureResponse);
            $scope.caseTypeDisable = true;
            toastr.clear();
            toastr.error($scope.myusrNo + " does not exist in PTAB-E2E, you may want to import a new case into" +
              " PTAB-E2E for this XXX application number prior to creating an assignment.", {
              iconClass: 'toast-danger'
            });
          });
      }

      /* istanbul ignore next */
      vm.tinymceOptions = {
        plugins: 'link image',
        toolbar: "undo redo  bold italic  link media",
        menubar: false,
        browser_spellcheck: true,
        contextmenu: false,
        elementpath: false,
        init_instance_callback: function (editor) {
          var textContentTrigger = function () {
            vm.textContent = editor.getBody().textContent;
          };
          editor.on('KeyUp', textContentTrigger);
          editor.on('ExecCommand', textContentTrigger);
          editor.on('SetContent', function (e) {
            if (!e.initial) {
              textContentTrigger();
            }
          });
        }
      };

      vm.gridCirculationHistory = {
        enableColumnResizing: true,
        enableHorizontalScrollbar: 1,
        enableGridMenu: true,
        rowHeight: 35,
        exporterCsvFilename: 'CirculationHistory.csv',
        exporterOlderExcelCompatibility: true,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        enableFiltering: true,
        useExternalFiltering: true,
        columnDefs: [{
          name: 'assignmentStatusCode',
          displayName: 'Assignment status',
          headerTooltip: 'Assignment status',
          cellTooltip: true,
          field: 'assignmentStatusCode',
          width: '90'
        },
        {
          name: 'completionDate',
          displayName: 'Completion/canceled date',
          headerTooltip: 'Completion/canceled date',
          cellTooltip: true,
          field: 'completionDate',
          type: 'date',
          cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'",
          sort: {
            direction: uiGridConstants.DESC,
            priority: 0
          },
          width: '170'
        },
        {
          name: 'title',
          displayName: 'Assignment title',
          headerTooltip: 'Assignment title',
          cellTooltip: true,
          field: 'title',
          width: '300'
        },
        {
          name: 'assignedDate',
          displayName: 'Assigned date',
          headerTooltip: 'Assigned date',
          cellTooltip: true,
          field: 'assignedDate',
          type: 'date',
          cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'",
          sort: {
            direction: 'desc',
            priority: 0
          },
          width: '170'
        },
        {
          name: 'dueDate',
          displayName: 'Assignment due date',
          headerTooltip: 'Assignment due date',
          cellTooltip: true,
          field: 'dueDate',
          type: 'date',
          cellFilter: "date:'MM/dd/yyyy'",
          width: '150'
        },
        {
          name: 'assignee',
          displayName: 'Assignee',
          headerTooltip: 'Assignee',
          cellTooltip: true,
          field: 'assignee',
          width: '160'
        },
        {
          name: 'assignor',
          displayName: 'Assignor',
          headerTooltip: 'Assignor',
          cellTooltip: true,
          field: 'assignor',
          width: '160'
        },
        {
          name: 'notes',
          displayName: 'Updates/notes',
          headerTooltip: 'Updates/notes',
          field: 'notes',
          cellTemplate: "<div  title='{{row.entity.notes}}' style=\"margin-top: 5px; margin-left: 5px;\" class=\"ui-grid-cell-contents\" ng-bind-html=\"row.entity.notes\"></div>",
          type: 'string',
          width: '120'
        },
        {
          name: 'audit.lastModifiedTimestamp',
          displayName: 'Update date(s)',
          headerTooltip: 'Update date(s)',
          field: 'lastModifiedTimestamp',
          type: 'date',
          cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'",
          cellTooltip: true,
          width: '170'
        },
        {
          name: 'audit.createTimestamp',
          displayName: 'Creation date',
          headerTooltip: 'Creation date',
          cellTooltip: true,
          field: 'createTimestamp',
          type: 'date',
          cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'",
          width: '170'
        },
        {
          name: 'assignmentTypeDescription',
          displayName: 'Assignment type',
          headerTooltip: 'Assignment type',
          cellTooltip: true,
          field: 'assignmentTypeDescription',
          width: '210'
        },
        {
          name: 'description',
          displayName: 'Description',
          headerTooltip: 'Description',
          cellTooltip: true,
          field: 'description',
          width: '200'
        },
        {
          name: 'serialNumber',
          displayName: 'Application #',
          headerTooltip: 'Application #',
          cellTooltip: true,
          field: 'serialNumber',
          width: '150'
        },
        {
          name: 'audit',
          displayName: 'Audit log',
          headerTooltip: 'Audit log',
          cellTooltip: true,
          enableFiltering: false,
          width: '150',
          field: 'audit',
          cellTemplate: '<div data-toggle="tooltip" title="Audit log" class="truncateTitle" style="cursor: pointer; margin-left: 8px; padding-top:5px; text-decoration: underline;">' +
            '<a ng-click="grid.appScope.openAssignHistory(row)" target="_blank" id="{{row.entity.assignmentIdentifier}}">' +
            'Audit log <i class="fas fa-external-link-alt"></i></a></div>'
        }
        ]
      };

      vm.gridCirculationHistory.onRegisterApi = function (gridApi) {
        $scope.gridApi = gridApi;
        $scope.gridApi.core.on.filterChanged($scope, function () {
          var grid = this.grid;
          $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
          if ($scope.numberOfFilters === 0) {
            vm.gridCirculationHistory.data = $scope.myData;
          } else {
            var filteredData = SearchHelperService.filterGrid(grid, $scope.myData);
            vm.gridCirculationHistory.data = filteredData;
          }
        });
      };

      /* istanbul ignore next: toaster error*/
      vm.getAssignHistory = function () {
        HttpFactory.getActions("/circulation/assignment-history?serialNumber=" + vm.applicationNumber + "&appealNumber=" + vm.caseNumber)
          .then(function (successResponse) {
            vm.gridCirculationHistory.data = successResponse.data.caseDetailsData;
            angular.forEach(vm.gridCirculationHistory.data, function (row) {
              row.lastModifiedTimestamp = row.audit.lastModifiedTimestamp;
              row.createTimestamp = row.audit.createTimestamp;
            });
            $scope.myData = angular.copy(vm.gridCirculationHistory.data);
          }, function (failureResponse) {
            toastr.error(failureResponse);
          });
      };

      /* istanbul ignore next: resolve error*/
      $scope.openAssignHistory = function (row) {
        $scope.assignData = row.entity;
        ngDialog.open({
          template: 'app/components/widgets/assignments/src/assignmnetHistory.html',
          controller: 'AssignmentHistoryController',
          controllerAs: 'vm',
          width: '80%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            assignmentData: function () {
              return $scope.assignData;
            }
          }
        });
      };

      function getOtherValue(row) {
        return row.role !== "APJ1";
      }

      function isLastAssignment() {
        var noDispositionTimestamp = 0;
        for (var i = 0; i < vm.circulationGridOptions.data.length; i++) {
          if (!vm.circulationGridOptions.data[i].dispositionTimestamp) {
            noDispositionTimestamp++;
          }
        }
        return noDispositionTimestamp === 1 && vm.userIsAPJ1;
      }

      vm.completeReview = function (row, code) {
        var data = {
          code: code,
          data: row,
          userRole: vm.currentLoggedInRole,
          lastAssignment: isLastAssignment()
        };
        vm.completeReviewData = data;
        ngDialog.open({
          template: 'app/circulation/completeReviewModal.html',
          controller: 'CompleteReviewModalController',
          controllerAs: 'vm',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            data: function () {
              return data;
            }
          }
        }).closePromise.then(function (response) {
          if (response.value) {

            for (var i = 0; i < vm.circulationGridOptions.data.length; i++) {

              if (vm.circulationGridOptions.data[i].ptabAssignmentIdentifier === row.entity.ptabAssignmentIdentifier) {
                vm.circulationGridOptions.data[i].assignmentActionCode = vm.completeReviewData.code;
                vm.circulationGridOptions.data[i].addAdditionalWritingAssignment = response.value.additionlWriting;
                vm.circulationGridOptions.data[i].reviewDispositionCode = response.value.selectedReview;
                vm.circulationGridOptions.data[i].paralegalWritingAssignmentReview = response.value.paralegalWritingAssignmentReview;
                if (response.value.createAPJ1ReviewAssignmentbyOtherAPJsWithOtherOption && vm.circulationGridOptions.data[i + 1]) {
                  if (vm.circulationGridOptions.data[i + 1].order == vm.circulationGridOptions.data[i].order) {
                    vm.checkNext = vm.circulationGridOptions.data[i + 2];
                  } else {
                    vm.checkNext = vm.circulationGridOptions.data[i + 1];
                  }
                  vm.circulationGridOptions.data[i].createAPJ1ReviewAssignmentbyOtherAPJsWithOtherOption = getOtherValue(vm.checkNext);
                } else {
                  vm.circulationGridOptions.data[i].createAPJ1ReviewAssignmentbyOtherAPJsWithOtherOption = response.value.createAPJ1ReviewAssignmentbyOtherAPJsWithOtherOption;
                }
              }
            }
            vm.processCirculation(vm.completeReviewData.code);
          }
        });
      };

      function allReviewsAreComplete() {
        var allReviewsComplete = true;
        vm.circulationGridOptions.data.forEach(function (assignment) {
          if (!assignment.dispositionTimestamp && assignment.role !== 'Paralegal') {
            allReviewsComplete = false;
          }
        });
        return allReviewsComplete;
      }

      vm.readyForMailing = function (circulationstatusCode) {
        var allReviewsComplete = true;
        var modalData = {
          "ruling": vm.rulingCheck,
          "originalRuling": vm.originalCheck,
          "mailingNotes": vm.circulationInfo.mailingNotes,
          "flag": "allReviewsComplete"
        };
        allReviewsComplete = allReviewsAreComplete();
        if (!allReviewsComplete) {
          if (vm.buttonActions.showInitiate) {
            modalData.flag = 'readyForMailingBeforeInitiate';
          } else {
            modalData.flag = 'readyForMailingAfterInitiate';
          }
        }
        ngDialog.open({
          template: 'app/circulation/readyForMailingModal.html',
          controller: 'ReadyForMailingController',
          controllerAs: 'vm',
          width: '70%',
          appendClassName: 'ngdialog-content-cust',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            modalData: function () {
              return modalData;
            }
          }
        }).closePromise.then(function (response) {
          vm.circulationCode = circulationstatusCode;
          vm.splInstructions = response.value.specialInstructionTx;
          if (vm.splInstructions.foreignpatent.length > 0 || vm.splInstructions.nonPatentDoc.length > 0) {
            vm.resultsList = [];
            setForPatObj(vm.splInstructions);
            setNonPatObj(vm.splInstructions);
          }
          else {
            if (response.value || response.value.mailingNotes === "") {
              vm.rulingCheck = response.value.ruling;
              mailingInstructions = !response.value.mailingNotes ? "No instructions" : response.value.mailingNotes;
              vm.addMailingInstructions = true;
              vm.processCirculation(circulationstatusCode);
            }
          }
        });
      };

      function cancelMailing(flag) {
        vm.inProgress = true;
        var requestBody = {
          "circulationIdentifier": vm.circulationIdentifier,
          "serialNumber": vm.applicationNumber,
          "appealNumber": vm.caseNumber,
          "circulationTypeCode": vm.circulationInfo.circulationTypeCode,
          "audit": {
            "createUserIdentifier": vm.loggedInUser,
            "lastModifiedUserIdentifier": vm.loggedInUser
          }
        }


        var url;
        if (!flag) {
          url = 'cancelReadyForMailing';
        } else {
          if (flag.entity.order > 1) {
            url = 'cancelCurrentAssignmentAndActivatePreviousAssignment';
          } else {
            url = 'cancelCirculationInitiation';
          }
        }

        var returnValue = CirculationHelperService.cancelAssignment(requestBody, url);
        if (returnValue) {

          var successMessage;
          if (!flag) {
            successMessage = "Mailing has been canceled";
          } else {
            if (flag.entity.order > 1) {
              successMessage = 'Circulation assignment has been canceled and previous assignment has been activated';
            } else {
              successMessage = "Circulation has been canceled";
            }
          }

          toastr.success(successMessage);
          vm.inProgress = false;
          vm.caseMailed = false;
          $scope.isLoading = false;
          // vm.refreshCirculationManager();
          console.info("{Calling refresh circ");
          $timeout(function () {
            vm.refreshCirculationManager();
          }, 1000);

        } else {
          toastr.error(returnValue.data.message, {
            iconClass: 'toast-danger'
          });
          vm.inProgress = false;
          vm.caseMailed = false;
          $scope.isLoading = false;
        }
      }

      vm.processCirculation = function (circulationstatusCode) {
        $scope.isLoading = true;
        var circulationObject;
        fromInitiateCirculation = circulationstatusCode === 'INITIATED' ? true : false;
        fromUpdateCirculation = updateStatusCodeList.includes(circulationstatusCode);
        var tempCirculationObj = createCirculationObject(circulationstatusCode);
        if (vm.circulationInfo.circulationRecordsExists && vm.buttonActions.showCircUpdate) {
          circulationObject = checkCurrentlyActive(tempCirculationObj);
          if (addedCirculationAssignmentBag.length > 0) {
            angular.forEach(circulationObject.addedCirculationAssignmentBag, function (newAssignment) {
              angular.forEach(circulationObject.circulationAssignmentBag, function (currentAssignment) {
                if (newAssignment.order === currentAssignment.order && newAssignment.role === currentAssignment.role) {
                  newAssignment.currentlyActive = currentAssignment.currentlyActive;
                  if (newAssignment.currentlyActive) {
                    newAssignment.startDate = new Date().getTime();
                    currentAssignment.startDate = new Date().getTime();
                  }
                }
              });
            });
          }
        } else {
          circulationObject = tempCirculationObj;
        }
        // Remove all items from circulation assignment bag if deleting an active assignment
        if (deletedActiveAssignment) {
          circulationObject.circulationAssignmentBag = [];
          deletedActiveAssignment = false;
        }
        console.log("Final object: %o", circulationObject);
        if (vm.circulationInfo.circulationRecordsExists) {
          updateCirculation(circulationObject);
          console.log("Update circulation");
        } else {
          if (saveNotesBeforeInitiation) {
            saveNotesBeforeInitiation = false;
            circulationObject.circulationNoteBag = [];
            circulationObject.circulationNoteBag.push(notesBeforeInitiation);
          }
          createCirculation(circulationObject);
          console.log("Create circulation");
        }
      };


      function checkCurrentlyActive(circulation) {
        var mainCirculation = angular.copy(circulation);
        var circulationToCheck = $filter('orderBy')(circulation.circulationAssignmentBag, 'order');
        var updateTier = true;
        var activeTier;
        for (var i = 0; i < circulationToCheck.length; i++) {
          console.log(activeOrderNo);
          if (updateTier) {
            activeTier = circulationToCheck[i].order;
          }
          if (!circulationToCheck[i].dispositionTimestamp && activeTier === circulationToCheck[i].order) {
            circulationToCheck[i].currentlyActive = true;
            updateTier = false;
          }
        }
        mainCirculation.circulationAssignmentBag = circulationToCheck;
        return mainCirculation;
      }


      function createCirculationObject(statusCode) {
        var currentGridData = convertDates(vm.circulationGridOptions.data);
        var circulationObject = angular.copy(vm.originalCirculationInfo);
        circulationObject.circulationAssignmentBag = currentGridData;
        if (removedCirculationAssignmentBag.length > 0) {
          circulationObject.removedCirculationAssignmentBag = removedCirculationAssignmentBag;
        }
        if (addedCirculationAssignmentBag.length > 0) {
          circulationObject.addedCirculationAssignmentBag = addedCirculationAssignmentBag;
        }
        if (statusCode === 'COMPLETE_REVIEW') {
          circulationObject.circulationStatusCode = 'UPDATE_CIRC';
          circulationObject.assignmentActionCode = 'COMPLETE_REVIEW';
        } else {
          circulationObject.circulationStatusCode = statusCode;
        }
        circulationObject.audit.lastModifiedUserIdentifier = $window.sessionStorage.getItem("workerNumber");
        circulationObject.audit.lastModifiedTimestamp = new Date().getTime();
        circulationObject.audit.createUserIdentifier = circulationObject.audit.createUserIdentifier ? circulationObject.audit.createUserIdentifier : $window.sessionStorage.getItem("workerNumber");
        circulationObject.audit.createTimestamp = circulationObject.audit.createTimestamp ? circulationObject.audit.createTimestamp : new Date().getTime();
        circulationObject.mailingNotes = vm.addMailingInstructions ? mailingInstructions : circulationObject.mailingNotes;
        circulationObject.specialInstructionTx = vm.splInstructions;
        vm.addMailingInstructions = false;
        console.log(currentGridData);
        if (fromInitiateParalegalOnly) {
          circulationObject.circulationTypeCode = "PARALEGAL";
        }
        return circulationObject;
      }

      function convertDates(gridData) {
        for (var i = 0; i < gridData.length; i++) {
          var startDate = angular.isDate(gridData[i].startDate) ? gridData[i].startDate.getTime() : gridData[i].startDate;
          var completedDate = angular.isDate(gridData[i].completedDate) ? gridData[i].completedDate.getTime() : gridData[i].completedDate;
          gridData[i].startDate = startDate;
          gridData[i].completedDate = completedDate;
          delete gridData[i].$$hashKey;
          delete gridData[i].activeAssignment;
          gridData[i].circulationLevelIdentifier = gridData[i].order.toString();
          gridData[i].reviewDispositionCode = gridData[i].reviewDispositionCode ? gridData[i].reviewDispositionCode : null;
        }
        return gridData;
      }


      function createCirculation(circulationObject) {
        vm.inProgress = true;
        vm.followOnActions.message = setMessage(circulationObject.circulationStatusCode);
        HttpFactory.postActions('/circulation', circulationObject)
          .then(function (successResponse) {
            putUpdateRuling();
            vm.circulationNotes.noteText = "";
            var flag;
            if (fromInitiateCirculation) {
              flag = 'initiateCirculation';
              //  saveProsecuationDocs();
            }
            if (fromInitiateParalegalOnly) {
              flag = 'initiateParalegal';
              //  saveProsecuationDocs();
            }
            if (flag) {
              ngDialog.open({
                template: 'app/circulation/circulationConfirmation.modal.html',
                controller: 'CirculationConfirmationController',
                controllerAs: 'vm',
                width: '25%',
                showClose: false,
                closeByEscape: false,
                closeByDocument: false,
                resolve: {
                  rowToDelete: function () {
                    return null;
                  },
                  flag: function () {
                    return flag;
                  }
                }
              }).closePromise.then(function (response) {
                if (response.value) {
                  window.close();
                } else {
                  getPanelists();
                  toastr.success(vm.followOnActions.message, {
                    iconClass: 'toast-success'
                  });
                  console.log(successResponse);
                }
              });
            } else {
              getPanelists();
              toastr.success(vm.followOnActions.message, {
                iconClass: 'toast-success'
              });
              vm.inProgress = false;
            }
            vm.inProgress = false;
            $scope.isLoading = false;
          }, function (failureResponse) {
            console.log(failureResponse);
            toastr.error(failureResponse.data.message, {
              iconClass: 'toast-danger'
            });
            vm.inProgress = false;
            vm.caseMailed = false;
            $scope.isLoading = false;
          });
      }

      function updateCirculation(circulationObject) {
        vm.inProgress = true;
        vm.followOnActions.message = setMessage(circulationObject.circulationStatusCode);
        HttpFactory.putActions('/circulation', circulationObject)
          .then(function (successResponse) {
            putUpdateRuling();

            var flag;
            if (fromUpdateCirculation) {
              flag = 'updateCirculation';
            }
            if (fromInitiateCirculation) {
              flag = 'initiateCirculation';
            }
            if (flag) {
              ngDialog.open({
                template: 'app/circulation/circulationConfirmation.modal.html',
                controller: 'CirculationConfirmationController',
                controllerAs: 'vm',
                width: '25%',
                showClose: false,
                closeByEscape: false,
                closeByDocument: false,
                resolve: {
                  rowToDelete: function () {
                    return null;
                  },
                  flag: function () {
                    return flag;
                  }
                }
              }).closePromise.then(function (response) {
                if (response.value) {
                  window.close();
                } else {
                  getPanelists();
                  console.log(successResponse);
                  vm.inProgress = false;
                }
              }, function () {
                vm.inProgress = false;
              });
            } else {
              getPanelists();
              if (vm.followOnActions.closeWindow && circulationObject.assignmentActionCode !== 'COMPLETE_REVIEW') {
                window.close();
              }
              toastr.success(vm.followOnActions.message, {
                iconClass: 'toast-success'
              });
              console.log(successResponse);
              vm.inProgress = false;
            }
            $scope.isLoading = false;
          }, function (failureResponse) {
            console.log(failureResponse);
            toastr.error(failureResponse.data.message, {
              iconClass: 'toast-danger'
            });
            vm.inProgress = false;
            vm.caseMailed = false;
            $scope.isLoading = false;
          });
      }

      function setMessage(action) {
        var message;
        switch (action) {
          case 'DRAFT':
            message = vm.circulationInfo.circulationRecordsExists ? "Circulation has been updated" : "Circulation has been saved";
            break;
          case 'INITIATED':
            vm.followOnActions.closeWindow = true;
            message = "Circulation has been initiated";
            break;
          case 'UPDATE_CIRC':
            vm.followOnActions.closeWindow = true;
            message = "Circulation has been updated";
            break;
          case 'COMPLETE_REVIEW':
            vm.followOnActions.closeWindow = true;
            message = "Review has been completed";
            break;
          case 'MAILED':
            vm.followOnActions.closeWindow = true;
            message = "Case sent for mailing";
            vm.caseMailed = true;
            break;
          default:
            break;
        }
        return message;
      }


      vm.initiateParalegReview = function () {
        ngDialog.openConfirm({
          template: 'app/circulation/paralegalReview.html',
          controller: 'ParalegalReviewController',
          data: vm.panel,
          controllerAs: 'vm'
        }).then(function (response) {
          console.log(response);
          var paraOnly = angular.copy(vm.circulationGridOptions.data[0]);
          paraOnly.estimatedLoeDaysQt = response.duration;
          paraOnly.startDate = response.startDate;
          paraOnly.completedDate = response.endDate;
          vm.circulationGridOptions.data = [];
          vm.circulationGridOptions.data.push(paraOnly);
          vm.new = false;
          vm.marginLeft = "52em";
          fromInitiateParalegalOnly = true;
          vm.processCirculation('INITIATED');
        });
      };

      vm.requestCancelMailingConfirmation = function () {
        var data = {};
        data.title = "Confirmation";
        data.message = "Are you sure you want to cancel mailing decision document?";
        ngDialog.openConfirm({
          template: 'app/circulation/confirmRequestModal.html',
          controller: 'ConfirmRequestModalController',
          data: data,
          width: '30%',
          controllerAs: 'vm'
        }).then(function () {
          console.info("Confirmed");
          cancelMailing(null);
        });
      }

      vm.cancelAssignment = function (row) {
        var data = {
        };
        //      cancel the paralegal review assignment

        //and put the case back on Judge's (APJ1) docket with create decision draft assignment
        data.title = "Confirmation";
        if (row.entity.order > 1) {
          data.message = "Are you sure you want to cancel this assignment and activate the previous assignment?";
        } else {
          data.message = "Are you sure you want to cancel this paralegal review assignment and return create decision draft assignment back to you?";
        }

        ngDialog.openConfirm({
          template: 'app/circulation/confirmRequestModal.html',
          controller: 'ConfirmRequestModalController',
          data: data,
          width: '30%',
          controllerAs: 'vm'
        }).then(function () {
          console.info("Confirmed");
          cancelMailing(row);
        });
      };

      vm.updateDueDate = function () {
        var obj = {
          "ptabAssignmentId": vm.assignmentIdToChangeDueDate, // assignmentIdToChangeDueDate
          "dueDate": vm.newDecisionDueDate.getTime(), // New due date
          "audit": {
            "lastModifiedUserIdentifier": vm.loggedInUser,
            "createUserIdentifier": "vm.loggedInUser",
            "lastModifiedTimestamp": (new Date()).getTime()
          }
        };
        HttpFactory.putActions(CONSTANTS.URL.UPDATE_DUE_DATE, obj)
          .then(function () {
            vm.decisionDueDate = angular.copy(vm.newDecisionDueDate);
            CommonHelperService.setToastr(CONSTANTS.TOASTER.draftDue, "success");
          }, function (error) {
            CommonHelperService.setToastr(error.data.message, "error");
          });
      };


      vm.circulationNotesAdd = function () {
        var data = {
          "audit": {
            "lastModifiedTimestamp": new Date().getTime(),
            "lastModifiedUserIdentifier": vm.loggedInUser,
            "createUserIdentifier": vm.loggedInUser,
            "createdUserName": null,
            "lastModifiedUserName": null,
            "createTimestamp": new Date().getTime(),
            "lockControlNumber": 0
          },
          "circulationIdentifier": vm.circulationIdentifier,
          "noteText": vm.circulationNotes.noteText,
          "noteCreationTimestamp": new Date().getTime()
        };
        if (!vm.circulationInfo.circulationRecordsExists) {
          saveNotesBeforeInitiation = true;
          notesBeforeInitiation = angular.copy(data);
          vm.processCirculation('DRAFT');
        } else {
          HttpFactory.postActions("/circulation-notes", data)
            .then(function () {
              CommonHelperService.setToastr("", "clear");
              CommonHelperService.setToastr(CONSTANTS.TOASTER.addNote, "success");
              vm.circulationNotes.noteText = "";
              vm.getCirculationNotes();
            }, function () {
              CommonHelperService.setToastr("", "clear");
              CommonHelperService.setToastr(CONSTANTS.TOASTER.addNoteFail, "error");
            });
        }
      };

      vm.mailingInstructionsSave = function () {
        var mailingInstructionsList = [];
        var mailingInstructionsObj = {
          "audit": {
            "lastModifiedTimestamp": new Date().getTime(),
            "lastModifiedUserIdentifier": vm.loggedInUser,
            "createUserIdentifier": vm.loggedInUser,
            "createdUserName": null,
            "lastModifiedUserName": null,
            "createTimestamp": new Date().getTime(),
            "lockControlNumber": 0
          },
          "circulationIdentifier": vm.circulationIdentifier,
          "noteText": vm.mailingNotes // this would empty for removing instructions
        };
        mailingInstructionsList.push(mailingInstructionsObj);
        if (!vm.circulationInfo.circulationRecordsExists) {
          mailingInstructions = vm.mailingNotes;
          vm.addMailingInstructions = true;
          vm.processCirculation('DRAFT');
        } else {
          HttpFactory.putActions('/circulation/mailingNotes', mailingInstructionsList)
            .then(function (mailingInstructionsSuccess) {
              console.log('mailingInstructionsSuccess: ', mailingInstructionsSuccess);
              CommonHelperService.setToastr(CONSTANTS.TOASTER.mailSave, "success");
              getPanelists();
            }, function (mailingInstructionsFailure) {
              console.log('mailingInstructionsFailure: ', mailingInstructionsFailure);
              CommonHelperService.setToastr(CONSTANTS.TOASTER.mailFail, "error");
            });
        }
      };

      vm.getCirculationNotes = function () {
        HttpFactory.getActions("/circulation-notes?appealNumber=" + vm.caseNumber + "&serialNumber=" + vm.applicationNumber)
          .then(function (successResponse) {
            vm.circulationLevelNotes = successResponse.data.circulationLevelNotes;
            vm.mailingNotes = successResponse.data.mailingNotes.length > 0 ? successResponse.data.mailingNotes[0].noteText : [];
            vm.originalMailingNotes = angular.copy(vm.mailingNotes);
          }, function (circulationNotesFailure) {
            console.log('circulationNotesFailure: ', circulationNotesFailure);
          });
      };



      vm.editNote = function (notes) {
        var editNotesOptions = {
          notes: notes,
          loggedInUser: vm.loggedInUser,
          circulationIdentifier: vm.circulationIdentifier
        };
        ngDialog.open({
          template: 'app/circulation/editCirculationNote.html',
          controller: 'EditCirculationNoteController',
          data: editNotesOptions,
          controllerAs: 'vm',
          width: '65%'
        }).closePromise.then(function () {
          vm.getCirculationNotes();
        });
      };


      vm.removeNote = function (notes) {
        var deleteNotesOptions = {
          notes: notes,
          loggedInUser: vm.loggedInUser,
          circulationIdentifier: vm.circulationIdentifier
        };
        ngDialog.open({
          template: 'app/circulation/confirmRemoveNote.html',
          controller: 'ConfirmRemoveNoteController',
          data: deleteNotesOptions,
          controllerAs: 'vm'
        }).closePromise.then(function (response) {
          if (response) {
            vm.getCirculationNotes();
          }
        });
      };



      $scope.copyDocument = function (value) {

        $scope.copiedNumber = value.artifactUrlText;
        var input = document.createElement('input');
        input.setAttribute('value', value.artifactUrlText);
        document.body.appendChild(input);
        input.select();
        var result = document.execCommand('copy');
        document.body.removeChild(input);
        CommonHelperService.setToastr(CONSTANTS.TOASTER.docLink, "success");
        return result;
      };


      $scope.copyToNewRow = function (value) {
        var url = null;
        var copiedDocumentLink = null;
        if (value.artifactType === "c") {
          url = "/circulation-artifact";
          copiedDocumentLink = {
            "audit": {
              "lastModifiedTimestamp": new Date().getTime(),
              "lastModifiedUserIdentifier": vm.loggedInUser,
              "createUserIdentifier": vm.loggedInUser
            },
            "circulationArtifactIdentifier": null,
            "artifactUrlText": value.artifactUrlText,
            "artifactTitleName": value.artifactTitleName + "_[Copy]"
          };
        }
        if (value.artifactType === "p") {
          url = "/prosecution-artifact";
          copiedDocumentLink = angular.copy(value);
          delete copiedDocumentLink.$$hashKey;
          delete copiedDocumentLink.artifactType;
          copiedDocumentLink.artifactName = copiedDocumentLink.artifactName + "_[Copy]";
          copiedDocumentLink.audit.lastModifiedTimestamp = new Date().getTime();
          copiedDocumentLink.audit.lastModifiedUserIdentifier = vm.loggedInUser;
          copiedDocumentLink.audit.createUserIdentifier = vm.loggedInUser;
        }
        copiedDocumentLink.circulationIdentifier = vm.circulationInfo.circulationIdentifier;
        console.log(copiedDocumentLink);
        HttpFactory.postActions(url, copiedDocumentLink)
          .then(function () {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.docCopy, "success");
            getDocumentsLink();
          }, function () {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.docCopyFail, "error");
          });
      };


      vm.addDocument = function () {
        if (vm.buttonActions.showInitiate === true) {
          vm.showInitiate = "NI";
        } else {
          vm.showInitiate = "I";
        }
        var addEditDocOptions = {
          title: 'Add document link',
          buttonText: 'Add link',
          loggedInUser: vm.loggedInUser,
          circulationIdentifier: vm.circulationIdentifier,
          showInitiate: vm.showInitiate
        };
        ngDialog.openConfirm({
          template: 'app/circulation/addEditDocument.html',
          controller: 'AddEditDocumentController',
          data: addEditDocOptions,
          width: '31%',
          controllerAs: 'vm',
          resolve: {
            loggedInUser: function () {
              return vm.loggedInUser;
            },
            circulationIdentifier: function () {
              return vm.circulationIdentifier;
            },
            prosecutionArtifacts: function () {
              return vm.returnObject;
            }
          }
        }).then(function (data) {
          if (data) {
            vm.originalCirculationInfo.circulationArtifactBag = [];
            vm.originalCirculationInfo.circulationArtifactBag.push(data);
            if (vm.showInitiate === "NI") {
              vm.processCirculation('DRAFT');
            }

          }
          getDocumentsLink();
          vm.refreshCirculationManager();
        }, function () {
          getDocumentsLink();
        });
      };



      $scope.editDocument = function (row) {
        var addEditDocOptions = {
          title: 'Update document link',
          buttonText: 'Update link',
          documentCall: 'PUT',
          width: '31%',
          data: row,
          loggedInUser: vm.loggedInUser,
          circulationIdentifier: vm.circulationIdentifier
        };
        ngDialog.openConfirm({
          template: 'app/circulation/addEditDocument.html',
          controller: 'AddEditDocumentController',
          data: addEditDocOptions,
          controllerAs: 'vm',
          resolve: {
            circulationIdentifier: function () {
              return vm.circulationIdentifier;
            },
            prosecutionArtifacts: function () {
              return vm.returnObject;
            }
          }
        }).then(function () {
          $timeout(function () {
            getDocumentsLink();
          }, 2000);

        }, function () {
          console.info("canceled");
        });
      };


      vm.refreshCirculationManager = function () {
        getPanelists();
      };


      $scope.editDescription = function (row) {
        ngDialog.open({
          template: 'app/circulation/editDescription.html',
          controller: 'EditCirculationDescriptionController',
          controllerAs: 'vm',
          resolve: {
            assignment: function () {
              return row;
            }
          }
        }).closePromise.then(function (response) {
          if (response.value) {
            vm.refreshCirculationManager();
          }
        });
      };


      /* 101 ruling*/
      function getRuling() {
        HttpFactory.getActions("/appeals/special_type/" + vm.applicationNumber + "/" + vm.caseNumber)
          .then(function (successResponse) {
            vm.ruling = successResponse.data;
            if (vm.ruling.exsistingTypes.length > 0) {
              angular.forEach(vm.ruling.exsistingTypes, function (exsistingType) {
                if (exsistingType.typeNameText === 'UT' && exsistingType.checked === true) {
                  vm.rulingCheck = exsistingType.checked;
                  vm.originalCheck = exsistingType.checked;
                }
              });
            }
          }, function (failureResponse) {
            return failureResponse;
          });
      }


      /*update 101 ruling*/
      function putUpdateRuling() {
        if (vm.rulingCheck !== vm.originalCheck) {
          var rulingTypes = [];
          if (vm.rulingCheck) {
            var rulingType = {
              "fkSpecialTypId": null,
              "isChecked": vm.rulingCheck
            };
            angular.forEach(vm.ruling.allTypes, function (allTypes) {
              if (allTypes.typeNameText === 'UT') {
                rulingType.fkSpecialTypId = allTypes.specialTypeIdentifier;
              }
            });
            rulingTypes.push(rulingType);
          }
          if (vm.ruling.exsistingTypes.length > 0) {
            angular.forEach(vm.ruling.exsistingTypes, function (column) {
              if (column.typeNameText !== 'UT') {
                var specialType = {
                  "fkSpecialTypId": column.specialTypeIdentifier,
                  "isChecked": true
                };
                rulingTypes.push(specialType);
              }
            });
          }
          var updateRuling = {
            "specialTypes": rulingTypes,
            "serialNumber": vm.applicationNumber,
            "appealNumber": vm.caseNumber,
            "lifeCycle": null,
            "audit": {
              "lastModifiedUserIdentifier": $window.sessionStorage.getItem("workerNumber"),
              "lastModifiedTimestamp": new Date().getTime(),
              "createUserIdentifier": $window.sessionStorage.getItem("workerNumber")
            }
          };
          HttpFactory.putActions("/appeals/special_type", updateRuling)
            .then(function (successResponse) {
              console.log(successResponse);
            },
              function (failureResponse) {
                console.log(failureResponse);
              });
        }
      }

      // $timeout(function () {
      //   setAriaAttribute('mceu_0', 'Undo');
      //   setAriaAttribute('mceu_1', 'Redo');
      //   setAriaAttribute('mceu_2', 'Bold');
      //   setAriaAttribute('mceu_3', "Italic");
      //   setAriaAttribute('mceu_4', "insert link");
      // }, 2000);

      // function setAriaAttribute(timeMcButtonId, text) {
      //   try {
      //     var tinyMcButton = document.getElementById(timeMcButtonId);
      //     var tinyMcButtonHTML = tinyMcButton.childNodes[0];
      //     tinyMcButtonHTML.setAttribute("aria-label", text);
      //   } catch (error) {
      //     console.info("Error finding TinyMCE button");
      //   }
      // }


      vm.reorderPanel = function () {
        ngDialog.open({
          template: 'app/circulation/reorderPanel/reorderPanel.modal.html',
          controller: 'ReorderPanelController',
          controllerAs: 'vm',
          width: '60%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            activePanel: function () {
              return vm.circulationInfo;
            }
          }
        }).closePromise.then(function (response) {
          if (response.value) {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.reorderPanel, "success");
            getPanelists();
          }
        });
      };

      $scope.confirmDecision = function () {
        $scope.disableYes = true;
        $scope.disableConfirm = true;
        $scope.currentAssignment = shareAssign;
        var data = {
          "assignmentType": shareAssign.assignmentType,
          "assignee": shareAssign.assignee,
          "serialNumber": shareAssign.serialNumber,
          "title": shareAssign.title,
          "description": shareAssign.description,
          "dueDate": shareAssign.dueDate,
          "completionDate": new Date().getTime(),
          "completionCode": "APJ_DECISION",
          "caseType": shareAssign.caseType,
          "appealNumber": shareAssign.appealNumber,
          "sequenceNumber": shareAssign.sequenceNumber,
          "priorityIndicator": shareAssign.priorityIndicator,
          "assignmentIdentifier": shareAssign.assignmentIdentifier,
          "assignor": shareAssign.assignor,
          "activeIndicator": shareAssign.activeIndicator,
          "documentReviewerName": vm.loggedInUser,
          "documentReviewDate": new Date().getTime(),
          "notes": "",
          "audit": {
            "createUserIdentifier": vm.loggedInUser,
            "lastModifiedUserIdentifier": vm.loggedInUser,
            "lockControlNumber": shareAssign.audit.lockControlNumber,
            "createTimestamp": shareAssign.audit.createTimestamp,
            "lastModifiedTimestamp": new Date().getTime()
          },
          "nextAssignee": $scope.apj1Identifer
        };

        HttpFactory.putActions(CONSTANTS.URL.UPDATE_ASSIGNMENT, data)
          .then(function (successResponse) {
            //$log.info(successResponse);
            toastr.success(CONSTANTS.TOASTER.draftReview, {
              iconClass: 'toast-success'
            });
            vm.showButtons = false;
            //ngDialog.closeAll('true');
          }, function (failureResponse) {
            $scope.disableYes = false;
            toastr.clear();
            toastr.error(failureResponse.data.message, {
              iconClass: 'toast-danger'
            });
          });

      };

      function getDetails(assignmentIdentifier) {
        HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTBYID + assignmentIdentifier)
          .then(function (successResponse) {
            shareAssign = successResponse.data;
          }, function (failureResponse) {
            console.log('failureResponse: ', failureResponse);
          });
      }

      function getIdentifierAndGetDetails(resp) {
        if (resp.circulationAssignmentBag.length > 0) {
          angular.forEach(resp.circulationAssignmentBag, function (ele) {
            if (ele.order == 1) {
              getDetails(ele.ptabAssignmentIdentifier);
            }
          })
        }
      }

      /* get apj1 name */
      /* istanbul ignore next */
      function getApjName() {
        HttpFactory.getActions("/appeal-judge-panels?appealNumber=" + vm.caseNumber + "&applicationNumber=" + vm.applicationNumber)
          .then(function (successResponse) {
            angular.forEach(successResponse.data.judgePanel[0].panelToBeCreated, function (panel) {
              if (panel.activeIndicator === "Y" && panel.panelRank === 1) {
                $scope.apj1 = panel.panelName;
                $scope.apj1Identifer = panel.identifier;
              }
            });
          }, function (failureResponse) {
            return failureResponse;
          });
      };

      vm.uploadDocuments = function (uploadDocsObject, fullObject) {
        $scope.isLoading = true;
        HttpFactory.postActions('/artifacts/upload', uploadDocsObject)
          .then(function (successResponse) {
            fullObject.cmsId = successResponse.data.cmsObjectId;
            delete fullObject.file;
            vm.resultsList.push(fullObject.cmsId);
            checkCount();
          }, function (failureResponse) {
            toastr.error(failureResponse.data.message, {
              iconClass: 'toast-danger'
            });
            $scope.isLoading = false;
          });
      }

      function checkCount() {
        if (vm.resultsList.length == (vm.splInstructions.foreignpatent.length + vm.splInstructions.nonPatentDoc.length)) {
          vm.processCirculation(vm.circulationCode);
          $scope.isLoading = false;
        }
      }

      function setForPatObj(docObject) {
        foreignpatList = [];
        angular.forEach(docObject.foreignpatent, function (patent) {
          $scope.showPreviewPdf(patent);
        });
      }

      function setNonPatObj(docObject) {
        nonpatList = [];
        angular.forEach(docObject.nonPatentDoc, function (nonpatent) {
          $scope.showPreviewPdf(nonpatent);
        });
      }

      $scope.showPreviewPdf = function (patent) {
        $scope.isLoading = true;
        var pdfDataFile = new FormData();
        angular.forEach(patent.file, function (value) {
          pdfDataFile.append('uploadMultipartFileContents', value);
        });
        HttpFactory.postPdf(CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.USERGEN + 'appealNumber=' + vm.caseNumber +
          '&ptabAssignmentId=' + vm.originalCirculationInfo.ptabAssigmentId, pdfDataFile)
          .then(function (successResponse) {
            $scope.PostDataResponse = successResponse.data.fileContent;
            $scope.genPdfFileName = successResponse.data.fileName;
            $scope.contentsPreview = 'data:application/pdf;base64,' + $scope.PostDataResponse;
            var obj = {
              "proceedingNum": vm.caseNumber,
              "fileName": successResponse.data.fileName
            }
            vm.uploadDocuments(obj, patent);
          }, function () {
            // intentional
            $scope.isLoading = false;
            console.log("error");
          });
      };

      function getPTABSERVICES() {
        HttpFactory.getActions(CONSTANTS.URL.PTABSERVICES_URL)
        .then(function (successResponse) {
          console.log(successResponse);
          $scope.serviceBaseUrl = successResponse.data[0].descriptionText;
        }, function (failureResponse) {

        });
      }
      getPTABSERVICES();

      $scope.openDoc = function (row) {
        if(row.artifactUrlText.startsWith('PTAB/')) {
          $window.open($scope.serviceBaseUrl+"/artifacts/retrieve-cms-document?cmsObjectId=" + row.artifactUrlText);
        }
        else {
          $window.open(row.artifactUrlText);
        }
      };

    });
