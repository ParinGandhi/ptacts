(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('AddCirculationController', function ($scope, ngDialog, originalPanel, gridData, CONSTANTS) {
      var vm = this;
      vm.disableSave = false;
      vm.selectedOrder;
      vm.originalPanel = originalPanel;
      for (var i = 0; i < vm.originalPanel.length; i++) {
        vm.originalPanel[i].rank = i;
        if (vm.originalPanel[i].role === 'APJ1' && vm.originalPanel[i].assignmentType.includes('panel')) {
          vm.originalPanel[i].assignmentTypeDesc = ' - Panel review';
        }
        else if (vm.originalPanel[i].role === 'APJ1' && vm.originalPanel[i].assignmentType.includes('paralegal')) {
          vm.originalPanel[i].assignmentTypeDesc = ' - Paralegal review';
        } else if (vm.originalPanel[i].role === 'APJ1' && vm.originalPanel[i].assignmentType.includes('decision')){
          vm.originalPanel[i].assignmentTypeDesc = ' - Review decision draft';
        }
      }
      var selectedPanelMember;

      function constructOrderList() {
        vm.orderDropDown = [];
        var tempDropDownList = [];
        var minOrder;
        var maxOrder = gridData[gridData.length - 1].order + 2;
        for (var i = 0; i < gridData.length; i++) {
          if (!gridData[i].dispositionTimestamp) {
            minOrder = gridData[i].order;
            break;
          }
        }
        if (minOrder) {
          for (var k = minOrder; k < maxOrder; k++) {
            tempDropDownList.push(k);
          }
        } else {
          tempDropDownList.push(maxOrder);
        }

        // Add insert items
        for (var j = 0; j < tempDropDownList.length - 2; j++) {
          if (containsOrder(tempDropDownList[j])) {
            vm.orderDropDown.push(tempDropDownList[j]);
          } else {
            vm.orderDropDown.push(tempDropDownList[j] + " (new order)");
          }

          if (containsOrder(tempDropDownList[j]) && containsOrder(tempDropDownList[j + 1])) {
            vm.orderDropDown.push("Insert between " + tempDropDownList[j] + " and " + tempDropDownList[j + 1]);
          }
        }
        vm.orderDropDown.push(tempDropDownList[tempDropDownList.length - 2]);
        vm.orderDropDown.push(tempDropDownList[tempDropDownList.length - 1] + " (new order)");
      }


      constructOrderList();


      function containsOrder(order) {
        var orderMatch = false;
        angular.forEach(gridData, function (row) {
          if (row.order === order) {
            orderMatch = true;
          }
        });
        return orderMatch;
      }

      vm.filterPanel = function (order) {
        var orderIndex = parseInt(order, CONSTANTS.GLOBAL.RADIX) - 1;
        vm.panel = [];
        for (var i = 0; i < vm.originalPanel.length; i++) {
          if (i !== orderIndex) {
            vm.panel.push(vm.originalPanel[i]);
          }
        }
      };

      vm.dialogModel = {};

      vm.confirm = function () {
        console.info(vm.dialogModel);
        vm.dialogModel.role = vm.selectedRole.role;
        vm.dialogModel.assignmentType = vm.selectedRole.assignmentType;
        if (vm.dialogModel.order.indexOf('Insert') >= 0) {
          insertReviewer();
          return;
        }
        var alreadyExists = false;
        var existingPanel = {
          "entity": {}
        };
        // check if duplicate exists
        angular.forEach(gridData, function (item) {

          if (vm.dialogModel.role === item.role && item.assignmentType.includes(vm.dialogModel.assignmentType)) {
          // if (vm.dialogModel.role === item.role) {
            selectedPanelMember = angular.copy(item);
            selectedPanelMember.order = parseInt(vm.dialogModel.order, CONSTANTS.GLOBAL.RADIX);
            selectedPanelMember.estimatedLoeDaysQt = vm.dialogModel.duration;
            if (parseInt(vm.dialogModel.order, CONSTANTS.GLOBAL.RADIX) === item.order) {
              alreadyExists = true;
              existingPanel.entity = selectedPanelMember;
            }
          }

        });

        // if not in grid, find from original
        if (!selectedPanelMember) {
          angular.forEach(vm.originalPanel, function (currentPanel) {
            if (vm.dialogModel.role === currentPanel.role && vm.dialogModel.assignmentType === currentPanel.assignmentType) {
              selectedPanelMember = angular.copy(currentPanel);
              selectedPanelMember.order = parseInt(vm.dialogModel.order, CONSTANTS.GLOBAL.RADIX);
              selectedPanelMember.estimatedLoeDaysQt = vm.dialogModel.duration;
            }
          });
        }
        if (alreadyExists) {
          var flag = 'replace';
          ngDialog.open({
            template: 'app/circulation/circulationConfirmation.modal.html',
            controller: 'CirculationConfirmationController',
            controllerAs: 'vm',
            width: '25%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              flag: function () {
                return flag;
              },
              rowToDelete: function () {
                return existingPanel;
              }
            }
          }).closePromise.then(function (response) {
            if (response.value) {
              sendReplacementPanel(response.value.entity);
            }
          }, function () {
            //intentional
          });
        } else {
          sendReplacementPanel(selectedPanelMember);
        }
      };

      function insertReviewer() {
        var andIndex = vm.dialogModel.order.indexOf('and');
        var lastNumberIndex = andIndex + 4;
        var selectedPanelMember;
        var indexOrder = vm.dialogModel.order.substring(lastNumberIndex);
        angular.forEach(vm.originalPanel, function (currentPanel) {
          if (vm.dialogModel.role === currentPanel.role) {
            selectedPanelMember = angular.copy(currentPanel);
            selectedPanelMember.order = parseInt(indexOrder, CONSTANTS.GLOBAL.RADIX);
            selectedPanelMember.estimatedLoeDaysQt = vm.dialogModel.duration;
            selectedPanelMember.insertOrder = true;
          }
        });

        sendReplacementPanel(selectedPanelMember);
      }

      function sendReplacementPanel(panel) {
        ngDialog.closeAll(panel);
      }

      vm.closeAddCirculationModal = function () {
        ngDialog.closeAll(false);
      };
    });
})();
