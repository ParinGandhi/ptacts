(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('EditCirculationNoteController', function ($scope, ngDialog, CommonHelperService, HttpFactory, CONSTANTS) {
      var vm = this;
      vm.circulationNotes = $scope.ngDialogData.notes;
      var circulationInfo = $scope.ngDialogData;

      /* istanbul ignore next */
      vm.tinymceOptions = {
        plugins: 'link image',
        toolbar: "undo redo  bold italic  link media",
        menu: {},
        browser_spellcheck: true,
        contextmenu: false,
        elementpath: false,

        init_instance_callback: function (editor) {
          var textContentTrigger = function () {
            vm.textContent = editor.getBody().textContent;
          };

          editor.on('KeyUp', textContentTrigger);
          editor.on('ExecCommand', textContentTrigger);
          editor.on('SetContent', function (e) {
            if (!e.initial) {
              textContentTrigger();
            }

          });
        }
      };

      /*istanbul ignore next: toaster error */
      vm.confirm = function () {
        var data = [{
          "audit": {
            "lastModifiedTimestamp": new Date().getTime(),
            "lastModifiedUserIdentifier": circulationInfo.loggedInUser,
            "createUserIdentifier": circulationInfo.loggedInUser,
            "createdUserName": null,
            "lastModifiedUserName": null,
            "createTimestamp": new Date().getTime(),
            "lockControlNumber": 0
          },
          "circulationIdentifier": vm.circulationNotes.circulationIdentifier,
          "noteText": vm.circulationNotes.noteText,
          "noteCreationTimestamp": new Date().getTime(),
          "circulationNoteIdentifier": vm.circulationNotes.circulationNoteIdentifier,
          "authorUserId": vm.circulationNotes.authorUserId,
          "noteModifiedBy": circulationInfo.loggedInUser

        }];

        HttpFactory.putActions("/circulation-notes", data)
          .then(function () {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.noteSuccess, "success");
            vm.circulationNotes = "";
            ngDialog.closeAll();

          }, function () {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.noteFail, "error");
          });
      };


    });
})();
