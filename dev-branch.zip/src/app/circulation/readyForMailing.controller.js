(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('ReadyForMailingController', function (ngDialog, modalData, HttpFactory, CONSTANTS, $window, $scope) {
      var vm = this;
      var loggedInUser = $window.sessionStorage.getItem('workerNumber');
      vm.mailingNotes = modalData.mailingNotes;
      vm.showAbandon = false;
      vm.showDelete = false;
      vm.showReplace = false;
      vm.fixSequence = false;
      vm.paralegalOnly = false;
      vm.readyForMailingBeforeInitiate = false;
      vm.showBlank = false;
      vm.showOther = false;
      vm.showWriting = false;
      vm.showCirculationInitiated = false;
      vm.rulingCheck = modalData.ruling;
      vm.originalCheck = modalData.originalRuling;
      vm.currentTime = new Date().getTime();
      vm.patentEdit = false;
      vm.foreignPatentEdit = false;
      vm.nonPatentEdit = false;
      vm.enableUsPatent = false;
      vm.enableForeignPatent = false;
      vm.status6 = true;
      vm.status5 = true;
      vm.shi1 = false;
      vm.shi2 = false;
      vm.usPatentList = [];
      vm.forPatentList = [];
      vm.nonPatentList = [];
      vm.selectedClassification = "";
      vm.dialogModel = {};
      var reader = new FileReader();
      var fileByteArray = [];

      /* istanbul ignore next */
      vm.tinymceOptions = {
        plugins: 'link image',
        toolbar: "undo redo  bold italic  link media",
        menu: {},
        browser_spellcheck: true,
        contextmenu: false,
        elementpath: false,

        init_instance_callback: function (editor) {
          var textContentTrigger = function () {
            vm.textContent = editor.getBody().textContent;
          };

          editor.on('KeyUp', textContentTrigger);
          editor.on('ExecCommand', textContentTrigger);
          editor.on('SetContent', function (e) {
            if (!e.initial) {
              textContentTrigger();
            }

          });
        }
      };


      function getDefaults() {
        HttpFactory.getActions(CONSTANTS.URL.DEAFULTS + loggedInUser)
          .then(function (successResponse) {
            console.log(successResponse);
            vm.loggedInUserName = successResponse.data.caseDetailsData[0].fullName;

          }, function () {
            // Empty repsonse is ok
          });
      }
      getDefaults();



      switch (modalData.flag) {
        case 'readyForMailingBeforeInitiate':
          vm.title = 'Mail decision without circulation?';
          vm.body = 'You are about to send the decision for mailing without initiating the panel circulation in the P-TACTS system. Do you want to continue?';
          vm.readyForMailingBeforeInitiate = true;
          vm.readyMailMode = true;
          break;
        case 'readyForMailingAfterInitiate':
          vm.title = 'Move ahead without signoffs?';
          vm.body = 'One or more panel member(s) has not entered their sign off in P-TACTS, are you sure that you want to move ahead w/out their sign offs?';
          vm.paralegalOnly = true;
          vm.readyMailMode = true;
          break;
        case 'allReviewsComplete':
          vm.title = 'Review and confirm ready for mail';
          vm.body = 'All reviews have been completed.  Confirm Ready for mail?';
          vm.allReviewsComplete = true;
          vm.readyMailMode = true;
          break;
        default:
          break;
      }

      vm.closeCurrentDialog = function () {
        ngDialog.closeAll(false);
      };

      vm.readyToMail = function () {

        var response = {
          "mailingNotes": null,
          "ruling": vm.rulingCheck,
          "specialInstructionTx": {
            "uspatent": vm.usPatentList,
            "foreignpatent": vm.forPatentList,
            "nonPatentDoc": vm.nonPatentList
          }
        };

        if (angular.isUndefined(vm.textContent) || vm.textContent && vm.textContent.trim()) {
          response.mailingNotes = vm.mailingNotes;
        }
        ngDialog.closeAll(response, true);
      };

      vm.onEditPatent = function (val, index) {
        vm.patentEdit = true;
        vm.patentRowId = index;
        val.edit = true;
      };

      vm.onCancelPatent = function (val, index) {
        vm.patentEdit = false;
        vm.patentRowId = index;
        val.edit = false;
        val.documentNo = "";
        val.date = "";
        val.name = "";
        val.classification1 = "";
        val.classification2 = "";
      };

      vm.patentUndoText = function (row, index) {
        row.documentNo = "";
        row.date = "";
        row.name = "";
        row.classification1 = "";
        row.classification2 = "";
        vm.patentRowId = index;
      }

      vm.patentSave = function (val, i, classification) {
        console.log(val);
        val.id = i;
        val.edit = false;
        console.log(val);
        vm.patentEdit = false;
        vm.patentRowId = i;
      }

      vm.onPatentDelete = function (val, i) {
        vm.usPatentList.splice(i, 1);
      }

      vm.onEditForPatent = function (val, event, index) {
        vm.foreignPatentEdit = true;
        vm.forPatentRowId = index;
        val.edit = true;
      };

      vm.onCancelForPatent = function (val, index) {
        vm.foreignPatentEdit = false;
        vm.forPatentRowId = index;
        val.edit = false;
        val.documentNo = "";
        val.date = "";
        val.country = "";
        val.name = "";
        val.classification1 = "";
        val.classification2 = "";
        val.file = "";
        val.fileName = "";
      };

      vm.forUndoText = function (row, index) {
        row.documentNo = "";
        row.date = "";
        row.name = "";
        row.country = "",
          row.classification1 = "";
        row.classification2 = "";
        row.file = "";
        row.fileName = "";
        vm.forPatentRowId = index;
      }

      vm.forPatentSave = function (val, i) {
        val.id = i;
        val.edit = false;
        console.log(val);
        vm.foreignPatentEdit = false;
        vm.forPatentRowId = i;
      }

      vm.onForPatentDelete = function (val, i) {
        vm.forPatentList.splice(i, 1);
      }

      vm.onEditNonPatent = function (val, index) {
        vm.nonPatentEdit = true;
        vm.nonPatentRowId = index;
        val.edit = true;
      };

      vm.onCancelNonPatent = function (val, index) {
        vm.nonPatentEdit = false;
        vm.nonPatentRowId = index;
        val.edit = false;
        val.name = "";
        val.docInfo = "";
        val.file = "";
        val.fileName = "";
      };

      vm.undoText = function (val, index) {
        vm.nonPatentRowId = index;
        val.name = "";
        val.docInfo = "";
        val.file = "";
        val.fileName = "";
      }

      vm.nonPatentSave = function (val, i) {
        val.id = i;
        val.edit = false;
        console.log(val);
        vm.nonPatentEdit = false;
        vm.nonPatentRowId = i;
      }

      vm.onNonPatentDelete = function (val, i) {
        vm.nonPatentList.splice(i, 1);
      }

      vm.uspatentInst = function (event) {
        vm.enableUsPatent = event;
      }

      vm.foreignPatentInst = function (event) {
        vm.enableForeignPatent = event;
        if (!event) {
          vm.foreignPatentEdit = event;
          vm.nonPatentEdit = event;
        }
      }

      vm.addUsPatent = function () {
        var obj = {
          "id": "",
          "documentNo": "",
          "date": "",
          "name": "",
          "classification1": "",
          "classification2": "",
          "edit": false
        }
        vm.usPatentList.push(obj);
        console.log(vm.usPatentList);
      }

      vm.addForeignPatent = function () {
        var obj = {
          "id": "",
          "documentNo": "",
          "date": "",
          "country": "",
          "name": "",
          "classification1": "",
          "classification2": "",
          "file": "",
          "fileName": "",
          "edit": false
        }
        vm.forPatentList.push(obj);
        console.log(vm.forPatentList);
      }

      vm.addNonPatent = function () {
        var obj = {
          "id": "",
          "name": "",
          "docInfo": "",
          "file":"",
          "fileName": "",
          "edit": false
        }
        vm.nonPatentList.push(obj);
      }

      vm.changeClassification = function (selectedValue) {
        vm.selectedClassification = selectedValue;
        console.log(selectedValue);
      }

      $scope.fileSelect = function (p) {
        if (p.keyCode === '13') {
          document.getElementById('file1').click();
        }
      };

      vm.getFileInfo = function () {
        var clFile = document.getElementById("file" + vm.tempRowId);
        if (clFile) {
          console.log(clFile);
          $scope.fileInfo = {};
          $scope.fileInfo.name = clFile.files[0].name;
          vm.tempRowData.fileName = $scope.fileInfo.name;
          $scope.fileInfo.path = clFile.value;
          reader.readAsArrayBuffer(clFile.files[0]);
          reader.onloadend = function (evt) {
            if (evt.target.readyState === FileReader.DONE) {
              var arrayBuffer = evt.target.result,
                array = new Uint8Array(arrayBuffer);
              for (var i = 0; i < array.length; i++) {
                fileByteArray.push(array[i]);
              }
            }
          };
          $scope.fileContent = [];
          $scope.fileContent.push(clFile.files[0]);
          // var pdfDataFile = new FormData();
          // angular.forEach($scope.fileContent, function (value) {
          //   pdfDataFile.append('uploadMultipartFileContents', value);
          // });
          vm.tempRowData.file = $scope.fileContent;
        }
      };

      vm.openFileModal = function (data, index) {
        vm.tempRowId = index;
        vm.tempRowData = data;
        document.getElementById("file" + index).click();
      }



    });
})();
