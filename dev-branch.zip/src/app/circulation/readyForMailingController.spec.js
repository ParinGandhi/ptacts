(function () {
  'use strict';

  describe('ReadyForMailingController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open', 'getOpenDialogs', 'close']);
    var controller, scope, $rootScope;
    var $q, HttpFactoryDeferred, modalData;
    var successResponse = "";
    //   var successResponse = {
    //     data: [{
    //       "caseDetailsData": {
    //         "fullName": "add"
    //       }
    //     }]
    //   };
    modalData = {
      "mailingNotes": "",
      "flag": ""
    }

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);

      controller = $controller('ReadyForMailingController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        modalData: modalData,
        HttpFactory: HttpFactory,
      });
    }));

    describe('ReadyForMailingController', function () {

      it('Should invoke dismiss on ngDialog', function () {
        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['closeCurrentDialog']).toBeDefined();
        controller.closeCurrentDialog();
        expect(ngDialog.closeAll).toHaveBeenCalledWith(false);
      });

      it('it should call readyToMail', function () {
        var response = {
          "mailingNotes": null,
          "ruling": vm.rulingCheck
        };
        controller.textContent = "ss";
        expect(controller.readyToMail).toBeDefined();
        controller.readyToMail();
      });

      //   it('it should call getDefaults successResponse', function () {
      //     successResponse = {
      //       data: [{
      //         "caseDetailsData": {
      //           "fullName": "add"
      //         }
      //       }]
      //     };
      //     HttpFactoryDeferred.resolve(successResponse);
      //     scope.$digest();
      //   });
    });
  });
})();
