(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('EditCirculationDescriptionController', function ($window, assignment, CommonHelperService, HttpFactory, ngDialog, CONSTANTS) {
      var vm = this;
      vm.assignment = angular.copy(assignment);
      vm.submitting = false;

      /* istanbul ignore next */

      /*istanbul ignore next: toaster error */
      vm.confirm = function () {

        vm.submitting = true;
        vm.assignment.audit.lastModifiedTimestamp = new Date().getTime();
        vm.assignment.audit.lastModifiedUserIdentifier = $window.sessionStorage.getItem("workerNumber");
        vm.assignment.startDate = null;
        vm.assignment.completedDate = null;


        HttpFactory.putActions("/assignments/update-descriptionTx", vm.assignment)
          .then(function () {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.descUpdate, "success");
            vm.circulationNotes = "";
            vm.submitting = false;
            ngDialog.closeAll(true);
          }, function () {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.descFail, "error");
            vm.submitting = false;
          });
      };

    });
})();
