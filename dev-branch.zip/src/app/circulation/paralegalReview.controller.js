(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('ParalegalReviewController', function ($scope, CirculationHelperService) {
      var vm = this;
      vm.disableSave = false;
      vm.panel = $scope.ngDialogData;
      vm.dialogModel = {};
      vm.dialogModel.startDate = new Date();
      vm.dialogModel.duration = vm.panel[0].estimatedLoeDaysQt;
      vm.dialogModel.endDate = new Date();
      vm.udpateEndDate = function () {
        vm.dialogModel.endDate = CirculationHelperService.getEndDate(vm.dialogModel.startDate, vm.dialogModel.duration);
      };
      vm.udpateEndDate();

    });
})();
