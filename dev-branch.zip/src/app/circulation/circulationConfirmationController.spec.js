(function () {
  'use strict';

  describe('CirculationConfirmationController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open', 'getOpenDialogs', 'close']);
    var controller, scope, $rootScope;
    var $q, HttpFactoryDeferred, rowToDelete, flag;

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);

      controller = $controller('CirculationConfirmationController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        flag: flag,
        rowToDelete: rowToDelete,
        HttpFactory: HttpFactory,
      });
    }));

    describe('CirculationConfirmationController', function () {

      it('Should invoke dismiss on ngDialog', function () {
        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['stayOnPage']).toBeDefined();
        controller.stayOnPage();
        expect(ngDialog.closeAll).toHaveBeenCalledWith(false);
      });

      it('Should invoke dismiss on ngDialog', function () {
        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['closeCurrentDialog']).toBeDefined();
        controller.closeCurrentDialog();
        expect(ngDialog.closeAll).toHaveBeenCalledWith(false);
      });

      it('Should invoke dismiss on ngDialog', function () {
        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['revertchanges']).toBeDefined();
        controller.revertchanges();
        expect(ngDialog.closeAll).toHaveBeenCalledWith(true);
      });

      it('Should invoke dismiss on ngDialog', function () {
        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['closeCirculationManager']).toBeDefined();
        controller.closeCirculationManager();
        expect(ngDialog.closeAll).toHaveBeenCalledWith(false);
      });

      it('it should call closeReplaceDialog ', function () {
        expect(controller.closeReplaceDialog).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.closeReplaceDialog();
      });

      it('it should call replaceAssignment', function () {
        expect(controller.replaceAssignment).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.replaceAssignment();
      });

    });
  });
})();
