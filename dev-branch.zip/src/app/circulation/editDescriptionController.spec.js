(function () {
  'use strict';

  describe('EditCirculationDescriptionController', function () {
    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var controller, scope, $rootScope;
    var $q;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'closeAll']);
    var assignment = {
      "circulationArtifactIdentifier": 755,
      "circulationIdentifier": 1228,
      "artifactUrlText": "download (1).docx",
      "artifactTitleName": "test_[Copy]",
      "referenceUserId": 29,
      "modifiedUserName": "Bisk, Jennifer S.",
      "audit": {
        "lastModifiedTimestamp": 1582575648107,
        "lastModifiedUserIdentifier": "jbisk",
        "createUserIdentifier": "jbisk",
        "createdUserName": null,
        "lastModifiedUserName": null,
        "createTimestamp": 1582575648107,
        "lockControlNumber": 0
      },
      "lastModifiedTimestamp": 1582575648107
    }
    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_) {
      $q = _$q_;
      scope = _$rootScope_.$new();
      $controller = _$controller_;
      $rootScope = _$rootScope_;
      scope.ngDialogData = {}

      controller = $controller('EditCirculationDescriptionController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        assignment: assignment
      });
    }));

    describe('EditCirculationDescriptionController ', function () {

      it('should be defined', function () {
        expect(controller.assignment).toBeDefined();
        expect(controller.submitting).toBeDefined();
      });

    });
  });
})();
