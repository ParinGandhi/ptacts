(function () {
  'use strict';

  describe('AddEditDocumentController', function () {

    beforeEach(module('ptabe2e'))
    var $controller;
    var vm = this;
    var controller, scope, $rootScope;
    var circulationIdentifier;
    var HttpFactoryDeferred;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'close', 'closeAll', 'getOpenDialogs']);
    var $q, $http, $interval;
    circulationIdentifier = "11";

    beforeEach(inject(function (_$controller_, _$http_, _$rootScope_, _$interval_, _$q_, HttpFactory, dialogModel) {
      $q = _$q_;
      $http = _$http_;
      scope = _$rootScope_.$new();
      $interval = _$interval_;
      $rootScope = _$rootScope_;

      // setup the promise
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      $controller = _$controller_;

      controller = $controller('AddEditDocumentController', {
        $http: $http,
        $scope: scope,
        $rootScope: _$rootScope_,
        $interval: $interval,
        HttpFactory: HttpFactory,
        ngDialog: ngDialog,
        circulationIdentifier: circulationIdentifier,
      })
    }));


    describe('check functions', function () {
      //   it(' should call closeAddCirculationModal', function () {
      //     expect(ngDialog.closeAll).toBeDefined();
      //     expect(controller.closeAddCirculationModal).toBeDefined();
      //     controller.closeAddCirculationModal();
      //     expect(ngDialog.closeAll).toHaveBeenCalledWith();
      //   });

    });


  });
})();
