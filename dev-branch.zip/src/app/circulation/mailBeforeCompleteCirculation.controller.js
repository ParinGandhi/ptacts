(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('MailBeforeCompleteCirculationController', function () {
      var vm = this;
      vm.title = "Circulation reviews are not completed!";
      vm.title = "Mail desicion without circulation?";
      vm.message = "You are about to send the decision for mailing without initiating the panel circulation in the PTAB E2E system. Do you want to continue?";
    });
})();
