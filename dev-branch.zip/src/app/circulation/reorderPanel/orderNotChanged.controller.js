(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('OrderNotChangedController', function (ngDialog, modalInfo) {

      var vm = this;
      vm.modalInfo = modalInfo;

      vm.back = function () {
        ngDialog.close(lastDialog());
      };

      function lastDialog() {
        var openDialogs = ngDialog.getOpenDialogs();
        return openDialogs[openDialogs.length - 1];
      }


    });
})();
