(function () {
  'use strict';

  describe('confirmdeleteController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var controller, scope, $rootScope, $CommonHelperService;
    var successResponse, failureResponse;
    var $httpBackend, spy, $q, HttpFactoryDeferred;
    var id = "1";
    var loggedInUser = "eswift";
    var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'closeAll']);

    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              getWidgetZone: function () {

              },
              setWidgetContentHeight: function () {

              }
            }
          }
        }
      }
    };

    beforeEach(inject(function (_$controller_, _$rootScope_, _$httpBackend_, _$q_, HttpFactory, _CommonHelperService_) {
      $q = _$q_;
      scope = _$rootScope_.$new();
      $controller = _$controller_;
      $rootScope = _$rootScope_;
      $httpBackend = _$httpBackend_;
      $CommonHelperService = _CommonHelperService_;

      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'deleteActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn($CommonHelperService, 'setToastr').and.callFake(function () {
        return "toastr";
      });
      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      controller = $controller('confirmdeleteController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory,
        id: id,
        loggedInUser: loggedInUser
      });
    }));

    describe('ConfirmRemoveNoteController ', function () {
      it('it should call closeModal ', function () {
        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['closeModal']).toBeDefined();
        controller.closeModal();
        expect(ngDialog.closeAll).toHaveBeenCalledWith();
      });

      // it('should call deleteDocument1', function () {
      //   expect(controller.deleteDocument1).toBeDefined();
      //   controller.deleteDocument1();
      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();
      // });

      it('should call deleteDocument1 and get failureResponse', function () {
        failureResponse = {
          data: {
            "message": "Note not saved"
          }
        };
        expect(controller.deleteDocument1).toBeDefined();
        controller.deleteDocument1();
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });

    });
  });
})();
