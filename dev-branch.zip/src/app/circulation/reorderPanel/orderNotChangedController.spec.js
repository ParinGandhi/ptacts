(function () {
  'use strict';

  describe('OrderNotChangedController', function () {

    beforeEach(module('ptabe2e'))
    var $controller;
    var vm = this;
    var controller, scope, $rootScope;
    var modalInfo;
    var HttpFactoryDeferred;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'close', 'closeAll', 'getOpenDialogs']);
    var $q, $http, $interval;
    modalInfo = "123";


    beforeEach(inject(function (_$controller_, _$http_, _$rootScope_, _$interval_, _$q_, HttpFactory) {
      $q = _$q_;
      $http = _$http_;
      scope = _$rootScope_.$new();
      $interval = _$interval_;
      $rootScope = _$rootScope_;

      // setup the promise
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      $controller = _$controller_;

      controller = $controller('OrderNotChangedController', {
        $http: $http,
        $scope: scope,
        $rootScope: _$rootScope_,
        $interval: $interval,
        HttpFactory: HttpFactory,
        modalInfo: modalInfo,
        ngDialog: ngDialog,
      });
    }));

    describe('check functions', function () {
      it('it should call back ', function () {
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.back();
      });

    });
  });
})();
