(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('ReorderPanelController', function (activePanel, CommonHelperService, ngDialog, $window, HttpFactory, CONSTANTS, toastr) {

      var vm = this;
      vm.activePanel = activePanel;
      vm.patentAttorney = {
        panelRank: null,
        name: null,
        identifier: null
      };
      vm.patentAttorneyExists = false;
      vm.panelToBeDeleted = [];
      vm.selectedDiscipline = "";
      vm.selectedSection = "";
      vm.updating = false;

      /** This function will retrieve the list of disciplines
       * Code is commented out unti4l discipline user story is created
       */
      function getDisciplineList() {
        HttpFactory.getActions(CONSTANTS.URL.GET_DISCIPLINES)
          .then(function (successResponse) {
            vm.disciplineList = successResponse.data;
          }, function () { //intentional
          });
      }

      getDisciplineList();

      /** This function will retrieve the list of sections */
      function getSectionList() {
        HttpFactory.getActions(CONSTANTS.URL.GET_SECTIONS)
          .then(function (successResponse) {
            vm.sectionList = successResponse.data;

          }, function () { //intentional
          });
      }

      getSectionList();

      /** This function will retrieve a list of judges. On initial load, or if 'all' is selected from dropdown,
       * all judges will be displayed. It will also remove the judges that are on the panel from the judge list
       */
      vm.getJudgeList = function (params) {
        var url = setUrl(params);
        HttpFactory.getActions(url)
          .then(function (successResponse) {
            vm.judgeList = successResponse.data;
            for (var i = 0; i < vm.judgeList.length; i++) {
              angular.forEach(vm.judgesToPanel, function (paneledJudge) {
                if (paneledJudge.assigneeNumberText === vm.judgeList[i].assigneeNumberText) {
                  vm.judgeList.splice(i, 1);
                }
              });
            }
            vm.originalJudgeList = angular.copy(successResponse.data);
            console.log();
          }, function () {
            toastr.error(CONSTANTS.TOASTER.judges, {
              iconClass: 'toast-danger'
            });
            vm.judgeList = [];
          });
      };

      vm.getJudgeList('initialLoad');

      function setUrl(params) {
        // Get all judges on initial load or if "Select a discipline/section" is selected or "all" is selected for both
        if (params === "initialLoad" || (vm.selectedDiscipline === "" &&
            vm.selectedSection === "") ||
          (vm.selectedDiscipline === "all" &&
            vm.selectedSection === "all")) {
          return CONSTANTS.URL.GET_ALL_JUDGES;
        }
        // If both discipline and section are selected
        if (angular.isDefined(vm.selectedDiscipline) && vm.selectedDiscipline !== "" && angular.isDefined(vm.selectedSection) && vm.selectedSection !== "") {
          // If selected discipline is set to all, then all judges for the selected section are returned
          if (vm.selectedDiscipline === "all") {
            return CONSTANTS.URL.GET_JUDGES + "sectionText=" + vm.selectedSection;
            // If selected section is set to all, then all judges for the selected discipline are returned
          } else if (vm.selectedSection === "all") {
            return CONSTANTS.URL.GET_JUDGES + "disciplineCode=" + vm.selectedDiscipline;
            // Return the combined judge list
          } else {
            return CONSTANTS.URL.GET_JUDGES + "sectionText=" + vm.selectedSection + "&disciplineCode=" + vm.selectedDiscipline;
          }
          // Return list of judges based on selected discipline
        } else if (angular.isDefined(vm.selectedDiscipline) && vm.selectedDiscipline !== "" && vm.selectedDiscipline !== "all") {
          return CONSTANTS.URL.GET_JUDGES + "disciplineCode=" + vm.selectedDiscipline;
          // Return list of judges based on selected section
        } else if (angular.isDefined(vm.selectedSection) && vm.selectedSection !== "" && vm.selectedSection !== "all") {
          return CONSTANTS.URL.GET_JUDGES + "sectionText=" + vm.selectedSection;
          // Return all judges if either discipline or section is set to all and the other is set to "Select a ...."
        } else if ((vm.selectedDiscipline === "all" && vm.selectedSection === "") || (vm.selectedDiscipline === "" && vm.selectedSection === "all")) {
          return CONSTANTS.URL.GET_ALL_JUDGES;
        }
      }

      vm.criteriaMatch = function (input) {
        var tempList = [];
        if (angular.isDefined(input) && input.trim() !== "") {
          angular.forEach(vm.originalJudgeList, function (currentJudge) {
            if (currentJudge.assigneeFullNameText.toLowerCase().includes(input.toLowerCase())) {
              tempList.push(currentJudge);
            }
          });
          vm.judgeList = angular.copy(tempList);
        } else {
          tempList = angular.copy(vm.originalJudgeList);
          for (var i = 0; i < vm.judgesToPanel.length; i++) {
            for (var j = 0; j < tempList.length; j++) {
              if (tempList[j].assigneeFullNameText === vm.judgesToPanel[i].assigneeFullNameText) {
                tempList.splice(j, 1);
              }
            }
          }
          vm.judgeList = angular.copy(tempList);
        }
      };


      /** This function will move the judges from the judge list to the panel */
      vm.moveJudgeToPanel = function () {
        angular.forEach(vm.selectedJudges, function (column) {
          vm.addJudge = true;
          if (vm.newPanel.length === 0) {
            var judge = {
              name: vm.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIX)].assigneeFullNameText,
              identifier: vm.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIX)].assigneeNumberText
            };
            vm.newPanel.push(judge);
            vm.addJudge = false;
          } else {
            for (var i = 0; i < vm.newPanel.length; i++) {

              if (vm.newPanel[i].identifier === vm.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIX)].assigneeNumberText) {
                toastr.error(vm.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIX)].assigneeFullNameText + " has already been added to the panel", {
                  iconClass: 'toast-danger'
                });
                vm.addJudge = false;
                break;
              }
            }
          }
          if (vm.addJudge) {
            judge = {
              name: vm.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIX)].assigneeFullNameText,
              identifier: vm.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIX)].assigneeNumberText
            };
            vm.newPanel.push(judge);
          }
        });



        vm.selectedJudges.sort(function (a, b) {
          return b - a;
        });

        angular.forEach(vm.selectedJudges, function (column) {
          vm.judgeList.splice(parseInt(column, CONSTANTS.GLOBAL.RADIX), 1);
        });

        vm.clickedColumn = [];
        vm.panelChanged = true;

        vm.disableMove = true;
        //validateSubmit();
      };

      /** This function will disable the submit panel button until at least 3 judges are paneled */
      function validateSubmit() {
        vm.disableSubmitPanel = false;
        //var ewfElement = angular.element(document.getElementById("ewfUpdated")).scope();

        if ((vm.newPanel.length < 3 && vm.newPanel.length >= 0) ||
          (vm.selectedRow.briefHearingTypeCode === CONSTANTS.TYPE_CODES.HEARD && vm.judgesToPanel.length === 0)) {
          vm.disableSubmitPanel = true;
        }

        if (vm.selectedRow.briefHearingTypeCode !== CONSTANTS.TYPE_CODES.HEARD && vm.judgesToPanel.length === 0) {
          vm.disableSubmitPanel = false;
        }
        vm.getAttorneyList();
      }

      /** This function will limit the list of selected judges to 9
       * This is subject to removal once the PO's decide on a maximum number of allowed judges on the panel
       */
      vm.dataSelected = function (judge) {
        vm.disableMove = false;
        vm.selectedJudges = judge;
      };


      /** This function will remove the judge from the panel */
      vm.removeJudgeFromPanel = function (index) {
        var toDelete = {
          "identifier": vm.newPanel[index].identifier,
          "panelRank": index + 1
        };
        vm.panelToBeDeleted.push(toDelete);
        vm.newPanel.splice(index, 1);
        vm.getAttorneyList();
        if (vm.newPanel.length === 0) {
          vm.noAttorney = true;
        }
        if (index === 0) {
          vm.selectedAttorney = 'default';
          vm.patentAttorneyExists = false;
        }
        vm.panelChanged = true;
      };

      /** This function will remove all the judges from the panel */
      vm.removeAllJudgesFromPanel = function () {
        for (var i = 0; i < vm.newPanel.length; i++) {
          var remove = {};
          remove.identifier = vm.newPanel[i].assigneeNumberText;
          remove.panelRank = i + 1;
        }
        vm.selectedAttorney = 'default';
        vm.patentAttorneyExists = false;
        vm.newPanel = [];
        vm.noAttorney = true;
        vm.panelChanged = true;
        validateSubmit();
      };

      function setPanelForDisplay() {
        vm.panelToDisplay = [];
        var apj1Found = false;
        angular.forEach(vm.activePanel.activePanelDetails, function (panel) {
          var panelToAdd = {
            panelRank: null,
            name: null
          };
          if (panel.role.includes('APJ')) {
            if (panel.role === "APJ1") {
              if (!apj1Found) {
                panelToAdd.panelRank = parseInt(panel.role.substr(3), CONSTANTS.GLOBAL.RADIX);
                panelToAdd.name = panel.assigneeName;
                panelToAdd.identifier = panel.assignee;
                vm.panelToDisplay.push(panelToAdd);
                apj1Found = true;
              }
            } else {
              panelToAdd.panelRank = parseInt(panel.role.substr(3), CONSTANTS.GLOBAL.RADIX);
              panelToAdd.name = panel.assigneeName;
              panelToAdd.identifier = panel.assignee;
              vm.panelToDisplay.push(panelToAdd);
            }
          }
          if (panel.role === "PA") {
            vm.patentAttorney.panelRank = panel.role;
            vm.patentAttorney.name = panel.assigneeName;
            vm.patentAttorney.identifier = panel.assignee;
            vm.patentAttorneyExists = true;
          }
        });

        vm.originalSelectedAttorney = vm.patentAttorneyExists ? angular.copy(vm.patentAttorney.identifier) : 'default';

        vm.newPanel = angular.copy(vm.panelToDisplay);

        vm.panelToDisplayString = " ";
        for (var i = 0; i < vm.panelToDisplay.length; i++) {
          vm.panelToDisplayString += vm.panelToDisplay[i].name;
          if (vm.patentAttorneyExists && i == 0) {
            vm.panelToDisplayString += " (" + vm.patentAttorney.name + ")";
          }
          if (i !== vm.panelToDisplay.length - 1) {
            vm.panelToDisplayString += " | ";
          }
        }

      }

      setPanelForDisplay();


      /** This function will retrieve a list of attorneys based on the first selected judge in the panel (APJ1) */
      /* istanbul ignore next */
      vm.getAttorneyList = function () {
        if (vm.newPanel.length > 0) {
          HttpFactory.getActions(CONSTANTS.URL.GET_ATTORNEY_LIST + vm.newPanel[0].identifier)
            .then(function (successResponse) {
              var assignedList = successResponse.data.assignedAttorneyList;
              assignedList.push({
                assigneeNumberText: "divider",
                assigneeFullNameText: "---------------"
              });
              vm.attorneyList = assignedList.concat(successResponse.data.nonAssignedAttorneyList);

              if (vm.patentAttorneyExists) {
                vm.selectedAttorney = vm.patentAttorney.identifier;
              }

              vm.noAttorney = false;
              if (!vm.selectedAttorney) {
                vm.selectedAttorney = 'default';
              }
            }, function (failureResponse) {
              vm.attorneyList = [];
              console.log(failureResponse);
              vm.selectedAttorney = 'default';
              vm.noAttorney = true;
            });

        }

      };

      vm.getAttorneyList();


      vm.patentAttorneyChanged = function (selectedPA) {
        vm.patentAttorneyExists = true;
        vm.patentAttorney.identifier = selectedPA;
      };


      /** This function will move the selected judge in the panel up */
      vm.listUp = function (itemIndex) {
        vm.newPanel = CommonHelperService.moveListItem(vm.newPanel, itemIndex, itemIndex - 1);
        vm.getAttorneyList();
      };

      /** This function will move the selected judge in the panel down */
      vm.listDown = function (itemIndex) {
        vm.newPanel = CommonHelperService.moveListItem(vm.newPanel, itemIndex, itemIndex + 1);
        vm.getAttorneyList();
      };

      vm.submitRequest = function () {
        if (angular.equals(vm.panelToDisplay, vm.newPanel) && vm.selectedAttorney === vm.originalSelectedAttorney) {
          var modalInfo = {
            "title": "Panel order has not changed!",
            "message": "The current panel must be reordered in order to submit a Panel reorder request. Please go back and change the order of the judges on the panel"
          };
          ngDialog.open({
            template: 'app/circulation/reorderPanel/orderNotChanged.model.html',
            controller: 'OrderNotChangedController',
            controllerAs: 'vm',
            width: '30%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              modalInfo: function () {
                return modalInfo;
              }
            }
          }).closePromise.then(function () {
            // Reporder save is done in modal.
          }, function () {
            // Cancel was clicked.
          });
        } else {
          vm.updating = true;
          console.clear();
          console.log(vm.activePanel);
          var newPanelCopy = angular.copy(vm.newPanel);
          console.log("Before: ", vm.newPanel);
          for (var i = 0; i < newPanelCopy.length; i++) {
            newPanelCopy[i].panelRank = i + 1;
            delete newPanelCopy[i].name;
          }
          if (vm.patentAttorneyExists) {
            delete vm.patentAttorney.name;
            vm.patentAttorney.panelRank = 0;
            newPanelCopy.unshift(vm.patentAttorney);
          }
          console.log("After: ", newPanelCopy);
          var panelToUpdate = {
            "assignee": $window.sessionStorage.getItem("workerNumber"),
            "serialNumber": vm.activePanel.serialNumber,
            "caseType": vm.activePanel.proceedingType,
            "appealNumber": vm.activePanel.appealNumber,
            "actionCode": "Reorder",
            "priorityIndicator": "N",
            "audit": {
              "createUserIdentifier": $window.sessionStorage.getItem("workerNumber"),
              "lastModifiedUserIdentifier": $window.sessionStorage.getItem("workerNumber"),
              "lockControlNumber": 0
            },
            "circulationPanelReorder": newPanelCopy
          };
          HttpFactory.postActions("/assignments/panel-assignment", panelToUpdate)
            .then(function (reorderSuccess) {
              console.log('reorderSuccess: ', reorderSuccess);
              ngDialog.closeAll(true);
              vm.updating = false;
            }, function (reorderFailure) {
              console.log('reorderFailure: ', reorderFailure);
              CommonHelperService.setToastr(reorderFailure.data.message, "error");
              vm.updating = false;
            });

        }
      };

      vm.cancelReorder = function () {
        ngDialog.closeAll();
      };

      var arr = [12, 345, 2, 6, 7896];

      function findNumbers(nums) {
        var count = 0;
        angular.forEach(nums, function (num) {
          if (num.toString().split("").length % 2 === 0) {
            count = count + 1;
          }
        });
        return count;
      }

      findNumbers(arr);


    });
})();
