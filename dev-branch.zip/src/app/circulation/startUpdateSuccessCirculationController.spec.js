(function () {
    'use strict';
  
    describe('StartUpdateCirculationSuccessController', function () {
  
      beforeEach(module('ptabe2e'));
      var $controller;
      var vm = this;
      var controller, scope, $rootScope;
      var $q;
      
      var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'closeAll']);
  
      
  
      beforeEach(inject(function (_$controller_, _$rootScope_, _$q_) {
        $q = _$q_;
        scope = _$rootScope_.$new();
        $controller = _$controller_;
        $rootScope = _$rootScope_;
        scope.ngDialogData = {}
      
  
        controller = $controller('StartUpdateCirculationSuccessController', {
          $scope: scope,
          ngDialog: ngDialog,
          $rootScope: _$rootScope_
        });
      }));
  
      describe('StartUpdateCirculationSuccess ', function () {
        
        it('should display title and message', function () {
          expect(controller.title).toBeDefined();
          expect(controller.message).toBeDefined();
        });
         
      });
    });
  })();
  