(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .controller('ConfirmRemoveNoteController', function ($scope, ngDialog, HttpFactory, CommonHelperService, CONSTANTS) {
      var vm = this;
      var notesInfo = $scope.ngDialogData.notes;
      vm.deleteNote = function () {
        HttpFactory.deleteActions("/circulation-notes/" + notesInfo.circulationNoteIdentifier)
          .then(function () {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.delNote, "success");
            ngDialog.closeAll();
          }, function () {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.delNoteFail, "error");

          });
      };

    });
})();
