(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('StartUpdateCirculationSuccessController', function ($scope) {
      var vm = this;
      vm.message = $scope.ngDialogData.message;
      vm.title = $scope.ngDialogData.title;
      if (!vm.message) {
        vm.message = "Circulation has been initiated. This first assignment has been sent.";
      }

      if (!vm.title) {
        vm.title = "Circulation initiated sucessfully!";
      }
    });
})();
