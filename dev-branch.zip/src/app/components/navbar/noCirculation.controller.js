(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('NoCirculationController', function (ngDialog, caseNumber) {
      var vm = this;
      vm.showTrials = false;
      vm.caseNumber = caseNumber;
      if (vm.caseNumber.match(/[a-z]/i)) {
        vm.showTrials = true;
      } else {
        vm.showTrials = false;
      }

      vm.closeCurrentDialog = function () {
        ngDialog.close(lastDialog(), false);
      };

      function lastDialog() {
        var openDialogs = ngDialog.getOpenDialogs();
        return openDialogs[openDialogs.length - 1];
      }

    });
})();
