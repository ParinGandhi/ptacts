(function () {
  'use strict';

  describe('NotificationsModalController', function () {

    beforeEach(module('ptabe2e'))

    var vm = this;
    var scope;
    var controller, $controller, row;
    var $http, $interval, $log, $rootScope, spy, timeout, url, advancedSearchFlag, row, rowRenderIndex, col;
    var $q, userInfo, HttpFactoryDeferred;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close', 'open']);
    userInfo = {
      userId: "peter"
    };

    var failureResponse = '';
    var successResponse = '';
    beforeEach(inject(function (_$controller_, _$http_, _$rootScope_, _$interval_, $compile, _$q_, HttpFactory, CONSTANTS) {
      $q = _$q_;
      $http = _$http_;
      scope = _$rootScope_.$new();
      $interval = _$interval_;
      $rootScope = _$rootScope_;

      // setup the promise
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      // spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);
      // spyOn(HttpFactory, 'deleteActions').and.returnValue(HttpFactoryDeferred.promise);
      $controller = _$controller_;

      controller = $controller('NotificationsModalController', {
        $http: $http,
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        $interval: $interval,
        HttpFactory: HttpFactory,
        userInfo: userInfo
      });
    }));

    // afterEach(function () {
    //   spy.and.callThrough();
    // });

    describe('check functions', function () {

      it(' should call closeNotification', function () {
        var pauseTimer = true;
        expect(scope['closeNotification']).toBeDefined();
        scope.closeNotification();
      });

      it('getNotifications failureResponse ', function () {
        scope.lastRefresh = "2/2/2012";
        scope.isLoading = false;
        failureResponse = {
          data: {}
        };
        expect(scope['getNotifications']).toBeDefined();
        scope.getNotifications();
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });

      it('getNotifications successResponse ', function () {
        scope.lastRefresh = "2/2/2012";
        scope.isLoading = false;
        successResponse = {
          data: {
            "allowedResourceObjectList": ["panel_Update"],
            "ptabDefaultRefreshTime": 300000,
            "ptabReadOnlyUser": false,
            "alertsColumns": [{
              "pinnedRight": false,
              "cellTemplate": "<div style=\"margin-left:8px;padding-top:5px;\" ng-class=\"{'bold-alert':row.entity.read === false}\"><span ng-show=\"row.entity.alertPriorityCategory === 'High'\" title=\"Important\"><i class=\"fas fa-exclamation\" style=\"color:#E4002B;\"><\/i><\/span><a ng-if=\"row.entity.read === false\" title=\"New alert\"><i class=\"fas fa-circle\" style=\"font-size: 9px\"><\/i><\/a><\/div>",
              "visible": true,
              "headerTooltip": "Important",
              "enableFiltering": false,
              "displayName": "!",
              "cellClass": null,
              "type": "string",
              "enableSorting": true,
              "cellFilter": null,
              "field": "alertPriorityCategory",
              "width": "4%",
              "selected": false,
              "pinnedLeft": false
            }, {
              "pinnedRight": false,
              "cellTemplate": "<div style=\"margin-left: 8px; padding-top:5px; text-decoration: underline; color: blue\" class=\"truncateTitle\" ng-class=\"{'bold-alert':row.entity.read === false}\" > <a href  ng-click=\"grid.appScope.openCaseViewer(row)\" title=\"Open {{row.entity.appealNumber}} in case viewer\" target=\"_blank\" >{{row.entity.appealNumber}}<\/a> <\/span><\/div>",
              "visible": true,
              "headerTooltip": "Case #",
              "enableFiltering": true,
              "displayName": "Case #",
              "cellClass": null,
              "type": "string",
              "enableSorting": true,
              "cellFilter": null,
              "field": "appealNumber",
              "width": "9%",
              "selected": false,
              "pinnedLeft": false
            }, {
              "pinnedRight": false,
              "cellTemplate": "<div title=\"{{row.entity.messageText}}\" style=\"margin-left: 8px; padding-top:5px;\" class=\"truncateTitle\" ng-class=\"{'bold-alert':row.entity.read === false}\" >{{row.entity.messageText}}<\/div>",
              "visible": true,
              "headerTooltip": "Message",
              "enableFiltering": true,
              "displayName": "Message",
              "cellClass": null,
              "type": "string",
              "enableSorting": true,
              "cellFilter": null,
              "field": "messageText",
              "width": null,
              "selected": false,
              "pinnedLeft": false
            }, {
              "pinnedRight": false,
              "cellTemplate": "<div title=\" {{row.entity.sentTimestamp | date:'MM/dd/yyyy hh:mm:ss a' }}\" style=\" margin-left: 8px; padding-top:5px;\" ng-class=\"{'bold-alert':row.entity.read === false}\">{{row.entity.sentTimestamp | date:\"MM/dd/yyyy hh:mm:ss a\"}} <\/div>",
              "visible": true,
              "headerTooltip": "Received",
              "enableFiltering": true,
              "displayName": "Received",
              "cellClass": null,
              "type": "date",
              "enableSorting": true,
              "cellFilter": "date:\"MM/dd/yyyy hh:mm:ss a\"",
              "field": "sentTimestamp",
              "width": "16%",
              "selected": false,
              "pinnedLeft": false
            }, {
              "pinnedRight": false,
              "cellTemplate": "<div title=\"{{row.entity.assignmentTitle}}\" style=\" margin-left: 8px; padding-top:5px;\" class=\"truncateTitle\" ng-class=\"{'bold-alert':row.entity.read === false}\" >{{row.entity.assignmentTitle}}<\/div>",
              "visible": false,
              "headerTooltip": "Assignment title",
              "enableFiltering": true,
              "displayName": "Assignment title",
              "cellClass": null,
              "type": "string",
              "enableSorting": true,
              "cellFilter": null,
              "field": "assignmentTitle",
              "width": null,
              "selected": false,
              "pinnedLeft": false
            }, {
              "pinnedRight": false,
              "cellTemplate": "<div title=\"{{row.entity.assignmentType}}\" style=\" margin-left: 8px; padding-top:5px;\" class=\"truncateTitle\" ng-class=\"{'bold-alert':row.entity.read === false}\" >{{row.entity.assignmentType}}<\/div>",
              "visible": false,
              "headerTooltip": "Assignment type",
              "enableFiltering": true,
              "displayName": "Assignment type",
              "cellClass": null,
              "type": "string",
              "enableSorting": true,
              "cellFilter": null,
              "field": "assignmentType",
              "width": null,
              "selected": false,
              "pinnedLeft": false
            }, {
              "pinnedRight": false,
              "cellTemplate": "<div data-toggle=\"tooltip\" title=\"Delete\" class=\"truncateTitle\" style=\"cursor: pointer; margin-left:2em; padding-top:5px;\"> <a ng-click=\"grid.appScope.deleteRows(row)\"> <i class=\"far fa-trash-alt\"><\/i><\/a><\/div>",
              "visible": true,
              "headerTooltip": "Actions",
              "enableFiltering": false,
              "displayName": "Actions",
              "cellClass": null,
              "type": null,
              "enableSorting": false,
              "cellFilter": null,
              "field": "Actions",
              "width": "8%",
              "selected": false,
              "pinnedLeft": false
            }],
            "ptabDueDateNonEditableUser": false,
            "alertsWithCount": {
              "countOfAllAlerts": 52,
              "allAlertsBag": [{
                "messageText": "Assigned: Review reconsideration for additional decisional units (ADU) for 2019005962 has been assigned to you.",
                "read": true,
                "serialNumber": "15200936",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1573833194154,
                "assignmentType": "Review reconsideration for additional decisional units (ADU)",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review reconsideration for additional decisional units (ADU) - 2019005962",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019005962",
                "alertIdentifier": 2086,
                "alertRecipientId": 2830,
                "clearIndicator": false
              }, {
                "messageText": "Please review decision draft for case 2020000232 on the S: drive by 11/18/2019 ",
                "read": true,
                "serialNumber": "95002033",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1573657993663,
                "assignmentType": "Paralegal review decision draft",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Paralegal review decision draft - 2020000232",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2020000232",
                "alertIdentifier": 1928,
                "alertRecipientId": 2616,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Review correct Due date points for 2019005643 has been assigned to you.",
                "read": true,
                "serialNumber": "11592598",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1574713449451,
                "assignmentType": "Correct Due date points",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct Due date points - 2019005643",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019005643",
                "alertIdentifier": 2905,
                "alertRecipientId": 4244,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Correct decisional units (DU) for 2019005643 has been assigned to you.",
                "read": true,
                "serialNumber": "11592598",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1574887486960,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2019005643",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019005643",
                "alertIdentifier": 3210,
                "alertRecipientId": 4811,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Review request additional decisional units (ADU) for 2019005962 has been assigned to you.",
                "read": true,
                "serialNumber": "15200936",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1574888330204,
                "assignmentType": "Review request additional decisional units (ADU)",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review request additional decisional units (ADU) - 2019005962",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019005962",
                "alertIdentifier": 3211,
                "alertRecipientId": 4812,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Review correct Due date points for 2019005870 has been assigned to you.",
                "read": true,
                "serialNumber": "95000104",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1575302223167,
                "assignmentType": "Correct Due date points",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct Due date points - 2019005870",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019005870",
                "alertIdentifier": 3285,
                "alertRecipientId": 4914,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Review reconsideration for additional decisional units (ADU) for 2019005870 has been assigned to you.",
                "read": true,
                "serialNumber": "95000104",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1575305929211,
                "assignmentType": "Review reconsideration for additional decisional units (ADU)",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review reconsideration for additional decisional units (ADU) - 2019005870",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019005870",
                "alertIdentifier": 3314,
                "alertRecipientId": 4929,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Correct decisional units (DU) for 2019004360 has been assigned to you.",
                "read": true,
                "serialNumber": "14652017",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1577377093552,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2019004360",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019004360",
                "alertIdentifier": 4007,
                "alertRecipientId": 5892,
                "clearIndicator": false
              }, {
                "messageText": "Your review assignment for case 2020000084 has been cancelled due to reordering by Erica Swift on 12/27/2019",
                "read": true,
                "serialNumber": "15037833",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1577474046892,
                "assignmentType": "Paralegal review decision draft",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Paralegal review decision draft - 2020000084",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2020000084",
                "alertIdentifier": 4019,
                "alertRecipientId": 5948,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Correct decisional units (DU) for 2017006677 has been assigned to you.",
                "read": true,
                "serialNumber": "13769059",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579029053441,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2017006677",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017006677",
                "alertIdentifier": 4697,
                "alertRecipientId": 6843,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Review request additional decisional units (ADU) for 2017006677 has been assigned to you.",
                "read": true,
                "serialNumber": "13769059",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579189508241,
                "assignmentType": "Review request additional decisional units (ADU)",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review request additional decisional units (ADU) - 2017006677",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017006677",
                "alertIdentifier": 4881,
                "alertRecipientId": 7079,
                "clearIndicator": false
              }, {
                "messageText": "Approved: Request additional decisional units - case# 2019004360 has been approved with modified award of requested additional decisional units",
                "read": true,
                "serialNumber": "14652017",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579195775727,
                "assignmentType": "Review request additional decisional units (ADU)",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review request additional decisional units (ADU) - 2019004360",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019004360",
                "alertIdentifier": 4949,
                "alertRecipientId": 7155,
                "clearIndicator": false
              }, {
                "messageText": "Your review assignment for case 2020000419 has been cancelled due to reordering by Erica Swift on 01/16/2020",
                "read": true,
                "serialNumber": "95001082",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579203521401,
                "assignmentType": "Paralegal review decision draft",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Paralegal review decision draft - 2020000419",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2020000419",
                "alertIdentifier": 4973,
                "alertRecipientId": 7216,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Review request additional decisional units (ADU) for 2017006677 has been assigned to you.",
                "read": true,
                "serialNumber": "13769059",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579097226627,
                "assignmentType": "Review request additional decisional units (ADU)",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review request additional decisional units (ADU) - 2017006677",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017006677",
                "alertIdentifier": 4814,
                "alertRecipientId": 6956,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Correct decisional units (DU) for 2019005962 has been assigned to you.",
                "read": true,
                "serialNumber": "15200936",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1578933027349,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2019005962",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019005962",
                "alertIdentifier": 4627,
                "alertRecipientId": 6684,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Correct decisional units (DU) for 2019005643 has been assigned to you.",
                "read": true,
                "serialNumber": "11592598",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1578938595538,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2019005643",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019005643",
                "alertIdentifier": 4629,
                "alertRecipientId": 6686,
                "clearIndicator": false
              }, {
                "messageText": "Please review decision draft for case review decision draft on the S: drive by 2020000418 ",
                "read": true,
                "serialNumber": "90007155",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579196717043,
                "assignmentType": "Paralegal review decision draft",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Paralegal review decision draft - 2020000418",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2020000418",
                "alertIdentifier": 4951,
                "alertRecipientId": 7157,
                "clearIndicator": false
              }, {
                "messageText": "Rejected: Request additional decisional units - case# 2018008776 has been rejected.",
                "read": true,
                "serialNumber": "15496706",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579200638350,
                "assignmentType": "Review request additional decisional units (ADU)",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review request additional decisional units (ADU) - 2018008776",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2018008776",
                "alertIdentifier": 4958,
                "alertRecipientId": 7164,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Correct decisional units (DU) for 2019005962 has been assigned to you.",
                "read": true,
                "serialNumber": "15200936",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1578931252862,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2019005962",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019005962",
                "alertIdentifier": 4625,
                "alertRecipientId": 6682,
                "clearIndicator": false
              }, {
                "messageText": "Approved: Decisional units - case# 2018008776 has been approved with modified award of decisional units",
                "read": true,
                "serialNumber": "15496706",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579194796883,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2018008776",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2018008776",
                "alertIdentifier": 4917,
                "alertRecipientId": 7143,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Review request additional decisional units (ADU) for 2017006677 has been assigned to you.",
                "read": true,
                "serialNumber": "13769059",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1578945364113,
                "assignmentType": "Review request additional decisional units (ADU)",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review request additional decisional units (ADU) - 2017006677",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017006677",
                "alertIdentifier": 4656,
                "alertRecipientId": 6706,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Correct decisional units (DU) for 2017006677 has been assigned to you.",
                "read": true,
                "serialNumber": "13769059",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579042197849,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2017006677",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017006677",
                "alertIdentifier": 4730,
                "alertRecipientId": 6865,
                "clearIndicator": false
              }, {
                "messageText": "Modified: Request additional decisional units - case# 2020000243 has been approved with modified award of requested additional decisional units",
                "read": true,
                "serialNumber": "13828677",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579035166545,
                "assignmentType": "Review request additional decisional units (ADU)",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review request additional decisional units (ADU) - 2020000243",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2020000243",
                "alertIdentifier": 4723,
                "alertRecipientId": 6838,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Correct decisional units (DU) for 2017006677 has been assigned to you.",
                "read": true,
                "serialNumber": "13769059",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579041828142,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2017006677",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017006677",
                "alertIdentifier": 4727,
                "alertRecipientId": 6862,
                "clearIndicator": false
              }, {
                "messageText": "Your review assignment for case 2017005624 has been cancelled due to reordering by Erica Swift on 01/14/2020",
                "read": true,
                "serialNumber": "12869466",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579042769291,
                "assignmentType": "Paralegal review decision draft",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Paralegal review decision draft - 2017005624",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017005624",
                "alertIdentifier": 4742,
                "alertRecipientId": 6877,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Correct decisional units (DU) for 2019001947 has been assigned to you.",
                "read": true,
                "serialNumber": "14266361",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1578930407954,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2019001947",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019001947",
                "alertIdentifier": 4612,
                "alertRecipientId": 6662,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Correct decisional units (DU) for 2019004360 has been assigned to you.",
                "read": true,
                "serialNumber": "14652017",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1578934677018,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2019004360",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019004360",
                "alertIdentifier": 4643,
                "alertRecipientId": 6673,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Correct decisional units (DU) for 2017006677 has been assigned to you.",
                "read": true,
                "serialNumber": "13769059",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1578938559668,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2017006677",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017006677",
                "alertIdentifier": 4650,
                "alertRecipientId": 6700,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Correct decisional units (DU) for 2019004360 has been assigned to you.",
                "read": true,
                "serialNumber": "14652017",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1578934934570,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2019004360",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019004360",
                "alertIdentifier": 4644,
                "alertRecipientId": 6674,
                "clearIndicator": false
              }, {
                "messageText": "Modified: Request additional decisional units - case# 2018008771 has been approved with modified award of requested additional decisional units",
                "read": true,
                "serialNumber": "13623067",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579033447051,
                "assignmentType": "Review request additional decisional units (ADU)",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review request additional decisional units (ADU) - 2018008771",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2018008771",
                "alertIdentifier": 4720,
                "alertRecipientId": 6835,
                "clearIndicator": false
              }, {
                "messageText": "Your review assignment for case 2019005965 has been cancelled due to reordering by Erica Swift on 01/17/2020",
                "read": true,
                "serialNumber": "14907096",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579279518482,
                "assignmentType": "Paralegal review decision draft",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Paralegal review decision draft - 2019005965",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019005965",
                "alertIdentifier": 5026,
                "alertRecipientId": 7192,
                "clearIndicator": false
              }, {
                "messageText": "Approved: Decisional units - case# 2020000243 has been approved with modified award of decisional units",
                "read": true,
                "serialNumber": "13828677",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1580323549517,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2020000243",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2020000243",
                "alertIdentifier": 5195,
                "alertRecipientId": 7412,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Review request additional decisional units (ADU) for 2017006723 has been assigned to you.",
                "read": true,
                "serialNumber": "10553359",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1580481293952,
                "assignmentType": "Review request additional decisional units (ADU)",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review request additional decisional units (ADU) - 2017006723",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017006723",
                "alertIdentifier": 5242,
                "alertRecipientId": 7511,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Review request additional decisional units (ADU) for 2017006677 has been assigned to you.",
                "read": true,
                "serialNumber": "13769059",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579204751683,
                "assignmentType": "Review request additional decisional units (ADU)",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review request additional decisional units (ADU) - 2017006677",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017006677",
                "alertIdentifier": 4980,
                "alertRecipientId": 7223,
                "clearIndicator": false
              }, {
                "messageText": "Approved: Decisional units - case# 2020000243 has been approved with modified award of decisional units",
                "read": true,
                "serialNumber": "13828677",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1580345424785,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2020000243",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2020000243",
                "alertIdentifier": 5228,
                "alertRecipientId": 7461,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Review request additional decisional units (ADU) for 2017006677 has been assigned to you.",
                "read": true,
                "serialNumber": "13769059",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1580420230378,
                "assignmentType": "Review request additional decisional units (ADU)",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review request additional decisional units (ADU) - 2017006677",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017006677",
                "alertIdentifier": 5233,
                "alertRecipientId": 7502,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Review request additional decisional units (ADU) for 2019005643 has been assigned to you.",
                "read": true,
                "serialNumber": "11592598",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1580420835487,
                "assignmentType": "Review request additional decisional units (ADU)",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review request additional decisional units (ADU) - 2019005643",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019005643",
                "alertIdentifier": 5238,
                "alertRecipientId": 7507,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Review reconsideration for additional decisional units (ADU) for 2017006723 has been assigned to you.",
                "read": true,
                "serialNumber": "10553359",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1580481428761,
                "assignmentType": "Review reconsideration for additional decisional units (ADU)",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review reconsideration for additional decisional units (ADU) - 2017006723",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017006723",
                "alertIdentifier": 5263,
                "alertRecipientId": 7512,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Correct decisional units (DU) for 2017006677 has been assigned to you.",
                "read": true,
                "serialNumber": "13769059",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579126754182,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2017006677",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017006677",
                "alertIdentifier": 4856,
                "alertRecipientId": 7026,
                "clearIndicator": false
              }, {
                "messageText": "Your review assignment for case 2020000420 has been cancelled due to reordering by Erica Swift on 01/17/2020",
                "read": true,
                "serialNumber": "90007981",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579276655152,
                "assignmentType": "Paralegal review decision draft",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Paralegal review decision draft - 2020000420",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2020000420",
                "alertIdentifier": 5023,
                "alertRecipientId": 7189,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Review request additional decisional units (ADU) for 2017006677 has been assigned to you.",
                "read": true,
                "serialNumber": "13769059",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1580420316783,
                "assignmentType": "Review request additional decisional units (ADU)",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review request additional decisional units (ADU) - 2017006677",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017006677",
                "alertIdentifier": 5235,
                "alertRecipientId": 7504,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Correct decisional units (DU) for 2017006677 has been assigned to you.",
                "read": true,
                "serialNumber": "13769059",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1580419673701,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2017006677",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017006677",
                "alertIdentifier": 5232,
                "alertRecipientId": 7501,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Review reconsideration for additional decisional units (ADU) for 2019005643 has been assigned to you.",
                "read": true,
                "serialNumber": "11592598",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1580420993673,
                "assignmentType": "Review reconsideration for additional decisional units (ADU)",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review reconsideration for additional decisional units (ADU) - 2019005643",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019005643",
                "alertIdentifier": 5240,
                "alertRecipientId": 7509,
                "clearIndicator": false
              }, {
                "messageText": "This case is being removed from your docket because it is being send back to the Examiner.",
                "read": true,
                "serialNumber": "90007111",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1580832235231,
                "assignmentType": "Update eWF",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Update eWF - 2020000007",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2020000007",
                "alertIdentifier": 5290,
                "alertRecipientId": 7548,
                "clearIndicator": false
              }, {
                "messageText": "This case is being removed from your docket because it is being send back to the Examiner.",
                "read": true,
                "serialNumber": "95001862",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1580847643665,
                "assignmentType": "Update eWF",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Update eWF - 2019005421",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2019005421",
                "alertIdentifier": 5338,
                "alertRecipientId": 7623,
                "clearIndicator": false
              }, {
                "messageText": "Please review decision draft for case review decision draft on the S: drive by 2017011765 ",
                "read": true,
                "serialNumber": "14209063",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1579128393013,
                "assignmentType": "Paralegal review decision draft",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Paralegal review decision draft - 2017011765",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017011765",
                "alertIdentifier": 4859,
                "alertRecipientId": 7037,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Correct decisional units (DU) for 2017006677 has been assigned to you.",
                "read": true,
                "serialNumber": "13769059",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1580343362796,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2017006677",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017006677",
                "alertIdentifier": 5201,
                "alertRecipientId": 7418,
                "clearIndicator": false
              }, {
                "messageText": "Your review assignment for case 2020000423 has been cancelled due to reordering by Erica Swift on 02/07/2020",
                "read": true,
                "serialNumber": "15032950",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1581101581643,
                "assignmentType": "Paralegal review decision draft",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Paralegal review decision draft - 2020000423",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2020000423",
                "alertIdentifier": 5386,
                "alertRecipientId": 7664,
                "clearIndicator": false
              }, {
                "messageText": "This case is being removed from your docket because it is being send back to the Examiner.",
                "read": true,
                "serialNumber": "10824954",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1581418641959,
                "assignmentType": "Send notice of hearing",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Send Notice of Hearing - 2017004412",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017004412",
                "alertIdentifier": 5449,
                "alertRecipientId": 7779,
                "clearIndicator": false
              }, {
                "messageText": "This case is being removed from your docket because it is being send back to the Examiner.",
                "read": true,
                "serialNumber": "10824954",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1581418643848,
                "assignmentType": "Update eWF",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Update eWF - 2017004412",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017004412",
                "alertIdentifier": 5450,
                "alertRecipientId": 7800,
                "clearIndicator": false
              }, {
                "messageText": "Assigned: Correct decisional units (DU) for 2017006723 has been assigned to you.",
                "read": true,
                "serialNumber": "10553359",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1580933668915,
                "assignmentType": "Correct decisional units",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Review correct decisional units - 2017006723",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2017006723",
                "alertIdentifier": 5351,
                "alertRecipientId": 7609,
                "clearIndicator": false
              }, {
                "messageText": "Please review decision draft for case review decision draft on the S: drive by 2020000570 ",
                "read": true,
                "serialNumber": "95000390",
                "alertPriorityCategory": "Low",
                "sentTimestamp": 1584039343375,
                "assignmentType": "Paralegal review decision draft",
                "proceedingType": "APPEAL",
                "assignmentTitle": "Paralegal review decision draft - 2020000570",
                "recipientBag": ["eswift"],
                "audit": {
                  "createUserIdentifier": null,
                  "createdUserName": null,
                  "lockControlNumber": null,
                  "lastModifiedUserIdentifier": "eswift",
                  "lastModifiedUserName": null,
                  "lastModifiedTimestamp": null,
                  "createTimestamp": null
                },
                "appealNumber": "2020000570",
                "alertIdentifier": 6124,
                "alertRecipientId": 9357,
                "clearIndicator": false
              }],
              "countOfNewAlerts": 0,
              "allNewAlertsBag": []
            }

          }
        };
        expect(scope['getNotifications']).toBeDefined();
        scope.getNotifications();
        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();
      });

      it(' should call openCaseViewer', function () {
        row = {
          entity: {
            fkAdFkAppealNo: '2018005819',
            fkAdFkAaSerialNo: '15007114',
            read: true
          }
        }
        expect(scope['openCaseViewer']).toBeDefined();
        scope.openCaseViewer(row);
      });

      it(' should call oldRow', function () {
        var oldList = [];
        var oldSelected = {
          "alertIdentifier": 123,
          "audit": {
            "lastModifiedUserIdentifier": "esw"
          },
          "read": true,
          "alertRecipientId": 123
        };
        row = {
          entity: {
            fkAdFkAppealNo: '2018005819',
            fkAdFkAaSerialNo: '15007114',
            read: true
          }
        }
        expect(scope['oldRow']).toBeDefined();
        scope.oldRow(row);
        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();
      });

      it(' should call oldRow failure', function () {
        var oldList = [];
        var oldSelected = {
          "alertIdentifier": 123,
          "audit": {
            "lastModifiedUserIdentifier": "esw"
          },
          "read": true,
          "alertRecipientId": 123
        };
        row = {
          entity: {
            fkAdFkAppealNo: '2018005819',
            fkAdFkAaSerialNo: '15007114',
            read: true
          }
        }
        expect(scope['oldRow']).toBeDefined();
        scope.oldRow(row);
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });

      it(' should call deleteRows failureResponse', function () {
        var selected = [];
        var deleteList = [];
        row = {
          entity: {
            fkAdFkAppealNo: '2018005819',
            fkAdFkAaSerialNo: '15007114',
            read: true
          }
        }
        var deleteSelected = {
          "alertIdentifier": 123,
          "audit": {
            "lastModifiedUserIdentifier": "awkj"
          },
          "clearIndicator": true,
          "alertRecipientId": 1
        };
        expect(scope['deleteRows']).toBeDefined();
        scope.deleteRows(row);
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });


      it(' should call deleteRows failureResponse', function () {
        controller.userInfo.userInfo = undefined;
        var selected = [];
        var deleteList = [];
        row = {
          entity: {
            fkAdFkAppealNo: '2018005819',
            fkAdFkAaSerialNo: '15007114',
            read: true
          }
        }
        var deleteSelected = {
          "alertIdentifier": 123,
          "audit": {
            "lastModifiedUserIdentifier": "awkj"
          },
          "clearIndicator": true,
          "alertRecipientId": 1
        };
        expect(scope['deleteRows']).toBeDefined();
        scope.deleteRows(row);
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });


      // it(' should call deleteRows successResponse', function () {
      //   scope.getSelectedRows = {
      //     "messageText": "This case is being removed from your docket because it is being send back to the Examiner.",
      //     "read": true,
      //     "serialNumber": "95001287",
      //     "alertPriorityCategory": "Low",
      //     "sentTimestamp": 1580849120673,
      //     "alertPopUpSeen": true,
      //     "assignmentType": "Create subsequent decision panel",
      //     "proceedingType": "APPEAL",
      //     "assignmentTitle": "Create subsequent decision panel - 2012005573",
      //     "recipientBag": ["sbartlett"],
      //     "audit": {
      //       "createUserIdentifier": null,
      //       "createdUserName": null,
      //       "lockControlNumber": null,
      //       "lastModifiedUserIdentifier": "sbartlett",
      //       "lastModifiedUserName": null,
      //       "lastModifiedTimestamp": null,
      //       "createTimestamp": null
      //     },
      //     "appealNumber": "2017003978",
      //     "alertIdentifier": 2250,
      //     "alertRecipientId": 3194,
      //     "clearIndicator": false
      //   }
      //   successResponse = [{
      //     "alertIdentifier": 5386,
      //     "alertRecipientId": 7664,
      //     "read": false,
      //     "clearIndicator": true,
      //     "audit": {
      //       "lastModifiedTimestamp": null,
      //       "lastModifiedUserIdentifier": "eswift",
      //       "createUserIdentifier": "eswift",
      //       "createdUserName": null,
      //       "lastModifiedUserName": null,
      //       "createTimestamp": null,
      //       "lockControlNumber": null
      //     }
      //   }, {
      //     "alertIdentifier": 5449,
      //     "alertRecipientId": 7779,
      //     "read": false,
      //     "clearIndicator": true,
      //     "audit": {
      //       "lastModifiedTimestamp": null,
      //       "lastModifiedUserIdentifier": "eswift",
      //       "createUserIdentifier": "eswift",
      //       "createdUserName": null,
      //       "lastModifiedUserName": null,
      //       "createTimestamp": null,
      //       "lockControlNumber": null
      //     }
      //   }];
      //   var selected = [];
      //   var deleteList = [];
      //   // row = {
      //   //   entity: {
      //   //     fkAdFkAppealNo: '2018005819',
      //   //     fkAdFkAaSerialNo: '15007114',
      //   //     read: true
      //   //   }
      //   // }
      //   var deleteSelected = {
      //     "alertIdentifier": 123,
      //     "audit": {
      //       "lastModifiedUserIdentifier": "awkj"
      //     },
      //     "clearIndicator": true,
      //     "alertRecipientId": 1
      //   };
      //   expect(scope['deleteRows']).toBeDefined();
      //   scope.deleteRows(row);
      //   HttpFactoryDeferred.resolve(successResponse);
      //   // $rootScope.$apply();
      //   scope.$digest();
      // });
    });
  });
})();
