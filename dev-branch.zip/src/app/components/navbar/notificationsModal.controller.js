(function () {
  "use strict";

  angular
    .module('ptabe2e')
    .controller('NotificationsModalController', function ($scope, toastr, $timeout, userInfo, HttpFactory,
      i18nService, uiGridConstants, $window, SearchHelperService, CommonHelperService, $filter, $log, CONSTANTS) {
      var vm = this;
      i18nService.get('en').gridMenu.exporterVisibleAsCsv = 'Export filtered data as csv';
      var isFilterChanged = false;
      vm.userInfo = userInfo;
      vm.pauseTimer = false;
      $scope.isLoading = true;
      /* istanbul ignore next*/
      $scope.gridOptions = {
        enableFiltering: true,
        enableRowSelection: true,
        enableSelectAll: true,
        enableGridMenu: true,
        enableSorting: true,
        exporterCsvFilename: 'Notifications.csv',
        exporterOlderExcelCompatibility: true,
        exporterFieldCallback: function (grid, row, col, value) {
          if (col.colDef.type === 'date') {
            if (col.field === 'sentTimestamp') {
              value = $filter('date')(value, 'MM/dd/yyyy hh:mm:ss a');
            } else {
              value = $filter('date')(value, 'MM/dd/yyyy');
            }
            if (angular.isUndefined(value) || value === null) {
              value = "";
            } else {
              value = " " + value;
            }
          }
          return value;
        },
        exporterMenuAllData: false,
        exporterMenuCsv: true,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.WHEN_NEEDED,
        gridMenuShowHideColumns: true,
        treeRowHeaderAlwaysVisible: false,
        useExternalFiltering: true,
        gridMenuCustomItems: [{
          title: 'Show hidden filters',
          action: function () {
            showHiddenFilteredColumns();
          },
          order: 190
        }]
      };
      /* istanbul ignore next*/
      $scope.gridOptions.onRegisterApi = function (gridApi) {
        $scope.gridApiNoti = gridApi;
        $scope.gridApiNoti.selection.setMultiSelect(true);
        $scope.gridApiNoti.selection.on.rowSelectionChanged($scope, function (row) {
          $scope.getSelectedRows = $scope.gridApiNoti.selection.getSelectedRows();
        });
        $scope.gridApiNoti.selection.on.rowSelectionChangedBatch($scope, function () {
          $scope.getSelectedRows = $scope.gridApiNoti.selection.getSelectedRows();
        });
        $scope.gridApiNoti.core.on.filterChanged($scope, function () {
          isFilterChanged = true;
          var grid = this.grid;
          $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
          if ($scope.numberOfFilters === 0) {
            $scope.gridOptions.data = $scope.myData;
          } else {
            var filteredData = SearchHelperService.filterGrid(grid, $scope.myData);
            $scope.gridOptions.data = filteredData;
          }
        });

      };


      /* istanbul ignore next*/
      $scope.gridOptions.gridMenuCustomItems = [{
        title: 'Export full list as csv',
        action: function () {
          $scope.download_csv();
        },
        order: 220
      }];

      /* istanbul ignore next*/
      $scope.download_csv = function () {
        var headers = [];
        angular.forEach($scope.gridOptions.columnDefs, function (coldata) {
          headers.push(coldata.displayName);

        });
        var fields = [];
        angular.forEach($scope.gridOptions.columnDefs, function (coldata) {

          if (coldata.name[0] === 'alertPriorityCategory') {
            fields.push([coldata.name, coldata.type]);
          } else {
            fields.push([coldata.name, coldata.type]);
          }
        });
        var replacer = function (key, value) {
          if (value === null || angular.isUndefined(value)) {
            value = '';
          }
          return value;
        };
        var csv = $scope.myData.map(function (row) {
          return fields.map(function (fieldName) {
            if (fieldName[1] === 'date') {
              if (row[fieldName[0]]) {
                return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy hh:mm:ss a') + " ";
              } else {
                return "";
              }
            } else {
              return JSON.stringify(row[fieldName[0]], replacer);
            }
          }).join(',');
        });
        csv.unshift(headers.join(','));
        csv = csv.join('\r\n');
        var hiddenElement = document.createElement('a');
        hiddenElement.href = URL.createObjectURL(new Blob([csv], {
          type: 'text/csv'
        }));
        hiddenElement.target = '_blank';
        hiddenElement.download = 'Notifications' + CommonHelperService.getCurrentTime() + '.csv';
        hiddenElement.click();
      };


      /* istanbul ignore next  */
      function showHiddenFilteredColumns() {
        var hiddenFilteredColumns = SearchHelperService.hasHiddenColumnFilters($scope.gridApiNoti.grid.columns);

        angular.forEach(hiddenFilteredColumns, function (column) {
          column.showColumn();
          $scope.preferencesChanged = true;
        });
        $scope.gridApiNoti.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
      }

      $scope.getNotifications = function () {

        $scope.lastRefresh = new Date();

        HttpFactory.getActions("/alerts?recipientUserId=" + $window.sessionStorage.getItem("workerNumber"))
          .then(function (successResponse) {
              $scope.alertList = [];
              $scope.countOfNewAlerts = 0;
              $scope.countOfAllAlerts = 0;

              if (!$scope.columnsDefined) {
                $scope.gridOptions.columnDefs = successResponse.data.alertsColumns;
                angular.forEach($scope.gridOptions.columnDefs, function (column) {
                  if (column.field === "sentTimestamp") {
                    column.sort = {
                      direction: uiGridConstants.DESC,
                      priority: 0
                    };
                  }

                  column.filters = [{}];
                });
              }

              $scope.countOfNewAlerts = successResponse.data.alertsWithCount.countOfNewAlerts;
              $scope.countOfAllAlerts = successResponse.data.alertsWithCount.countOfAllAlerts;
              getAlertArray(successResponse.data.alertsWithCount.allAlertsBag);

              $scope.myData = successResponse.data.alertsWithCount.allAlertsBag;

              if ($scope.columnsDefined) {
                setGridData($scope.gridOptions.columnDefs);
              } else {
                $scope.gridOptions.data = successResponse.data.alertsWithCount.allAlertsBag;
              }
              $scope.columnsDefined = true;
              //   $scope.gridOptions.data = CommonHelperService.setGridData(1, $scope.gridOptions.data, $scope.gridOptions.columnDefs);
              if (!vm.pauseTimer) {
                $timeout(function () {
                  $scope.getNotifications();
                }, 30000);
              }
              $scope.isLoading = false;
            },
            function (failureResponse) {
              toastr.error(failureResponse.data.message, {
                iconClass: 'toast-danger'
              });
              if (!vm.pauseTimer) {
                $timeout(function () {
                  $scope.getNotifications();
                }, 30000);
              }
              $scope.isLoading = false;
            });
      };
      /* istanbul ignore next */
      function setGridData(colDefs) {
        if ($scope.numberOfFilters > 0) {
          var filteredData = SearchHelperService.filterTable($scope.myData, colDefs);
          $timeout(function () {
            $scope.gridOptions.data = filteredData;
            $scope.savedFilteredData = filteredData;
          }, 200);

        } else {
          $scope.numberOfFilters = 0;
          $timeout(function () {
            $scope.gridOptions.data = $scope.myData;
          }, 200);

        }
      }


      $scope.closeNotification = function () {
        vm.pauseTimer = true;
      };

      function getAlertArray(addedAlerts, makeUnread) {
        angular.forEach(addedAlerts, function (alert) {
          $scope.alertList.push(alert);
        });
      }

      $scope.getNotifications();

      $scope.oldRow = function (row) {
        var oldList = [];
        var oldSelected = {
          "alertIdentifier": row.entity.alertIdentifier,
          "audit": {
            "lastModifiedUserIdentifier": vm.userInfo.userId
          },
          "read": true,
          "alertRecipientId": row.entity.alertRecipientId
        };
        oldList.push(oldSelected);
        HttpFactory.putActions("/alerts", oldList)
          .then(function (successResponse) {
            $log.info(successResponse);
            $scope.getNotifications();
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };


      $scope.openCaseViewer = function (row) {
        row.entity.read = true;
        $window.open("#/caseViewer/" + row.entity.serialNumber + "/" + row.entity.appealNumber);
        $scope.oldRow(row);
      };


      $scope.deleteRows = function (row) {
        var selectedRows = [];
        if (row) {
          selectedRows.push(row.entity);
        } else {
          selectedRows = $scope.getSelectedRows;
        }

        var deleteList = [];
        selectedRows.forEach(function (element) {
          if (vm.userInfo.userId === undefined) {
            vm.userInfo.userId = vm.userInfo.appUserInfo[0].loginId;
          }
          var deleteSelected = {
            "alertIdentifier": element.alertIdentifier,
            "audit": {
              "lastModifiedUserIdentifier": vm.userInfo.userId
            },
            "clearIndicator": true,
            "alertRecipientId": element.alertRecipientId
          };
          deleteList.push(deleteSelected);
        });
        HttpFactory.putActions("/alerts", deleteList)
          .then(function (successResponse) {
            $log.info(successResponse);
            toastr.success(CONSTANTS.TOASTER.notifDeleted, {
              iconClass: 'toast-success',
              timeOut: 2000
            });

            $scope.getNotifications();
            $scope.getSelectedRows.length = "0";
          }, function (failureResponse) {
            $log.info(failureResponse);
            toastr.error(CONSTANTS.TOASTER.notiNotDeleted, {
              iconClass: 'toast-danger',
            });
          });
      };


      $scope.importantRows = function () {
        var importantList = [];
        $scope.getSelectedRows.forEach(function (element) {
          if (vm.userInfo.userId === undefined) {
            vm.userInfo.userId = vm.userInfo.appUserInfo[0].loginId;
          }
          var keepUnread = {
            "alertIdentifier": element.alertIdentifier,
            "audit": {
              "lastModifiedUserIdentifier": vm.userInfo.userId
            },
            "alertPriorityCategory": "High",
            "alertRecipientId": element.alertRecipientId
          };
          importantList.push(keepUnread);
        });

        HttpFactory.putActions("/alerts", importantList)
          .then(function (successResponse) {
            $log.info(successResponse);
            toastr.success(CONSTANTS.TOASTER.notiImportant, {
              iconClass: 'toast-success',
              timeOut: 2000
            });
            $scope.getSelectedRows.length = "0";
            $scope.getNotifications();

          }, function (failureResponse) {
            $log.info(failureResponse);
            toastr.error(CONSTANTS.TOASTER.notiNotMarkedImportant, {
              iconClass: 'toast-danger',
              timeOut: 2000
            });
          });
      };

      $scope.allAlertStatus = function () {
        var allAlertList = [];
        $scope.gridOptions.data.forEach(function (element) {
          if (element.read === false) {
            if (vm.userInfo.userId === undefined) {
              vm.userInfo.userId = vm.userInfo.appUserInfo[0].loginId;
            }
            var allAlert = {
              "alertIdentifier": element.alertIdentifier,
              "audit": {
                "lastModifiedUserIdentifier": vm.userInfo.userId
              },
              "read": true,
              "alertRecipientId": element.alertRecipientId
            };
            allAlertList.push(allAlert);
          }
        });
        HttpFactory.putActions("/alerts", allAlertList)
          .then(function (successResponse) {
            $log.info(successResponse);
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };
    });
})();
