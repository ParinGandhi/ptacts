(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('AdvancedSearchController', function ($scope, $log, CommonHelperService, HttpFactory, $window, ngDialog, CONSTANTS) {
      var vm = this;
      var trialsLink;
      vm.displayNone = true;
      $scope.failureResponse = false;
      $scope.searchOption = "Case #";
      $scope.searchTerm = "CASE_NUMBER";
      $scope.searchThis = "";
      vm.showResults = false;
      vm.noNumberSelected = false;
      getAIAURLs();
      vm.optionCase = function () {
        $scope.searchThis = "";
        $scope.searchTerm = "CASE_NUMBER";
        $scope.searchOption = "Case #";
        vm.showResults = false;
        $scope.failureResponse = false;
      };
      vm.optionTrials = function () {
        $scope.searchThis = "";
        $scope.searchTerm = "TRIAL_NUMBER";
        $scope.searchOption = 'AIA Trials #';
        vm.showResults = false;
        $scope.failureResponse = false;
      };
      vm.optionApplication = function () {
        $scope.searchThis = "";
        $scope.searchTerm = "APPLICATION_NUMBER";
        $scope.searchOption = "Application #";
        vm.showResults = false;
        $scope.failureResponse = false;
      };
      vm.optionPatent = function () {
        $scope.searchThis = "";
        $scope.searchTerm = "PATENT_NUMBER";
        $scope.searchOption = "Patent #";
        vm.showResults = false;
        $scope.failureResponse = false;
      };

      vm.gridOptions = {
        enableColumnResizing: false,
        enableSelectAll: false,
        enableRowSelection: false,
        enableHorizontalScrollbar: 2,
        useExternalFiltering: false,
        enableGridMenu: false,
        exporterOlderExcelCompatibility: false,
        exporterMenuCsv: false,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        enableFiltering: false,
        enableSorting: false,
        columnDefs: [{
            displayName: 'Case #',
            cellTemplate: "<div  class='ui-grid-cell-contents' ><a role=\"button\" href ng-click=\"grid.appScope.openCaseViewer(row)\" target=\"_blank\" title=\"Open case viewer\"><span class=\"acExaminerList\"> &nbsp {{row.entity.appealNumber}}<\/span><\/a><\/div>",
            field: 'appealNumber',
            headerTooltip: 'Case #',
            cellTooltip: true,
            width: '27%',
            type: 'number',
            allowCellFocus: false,
            enableColumnMenu: false
          },
          {
            displayName: 'Application #',
            field: 'serialNumber',
            type: 'number',
            cellTooltip: true,
            width: '27%',
            headerTooltip: 'Application #',
            allowCellFocus: false,
            enableColumnMenu: false
          },
          {
            displayName: 'Patent #',
            field: 'patentNumber',
            headerTooltip: 'Patent #',
            cellTooltip: true,
            width: '27%',
            allowCellFocus: false,
            enableColumnMenu: false
          },
          {
            cellTemplate: "<div data-toggle=\"tooltip\" class=\"truncateTitle\" style=\"cursor: pointer; margin-left:2em; padding-top:5px;\"> <a role=\"button\" href title=\"Open case viewer\" ng-click=\"grid.appScope.openCaseViewer(row)\"> <i class=\"fas fa-binoculars\"><\/i><\/a><a  role=\"button\" href style=\"margin-left:10px;\" title=\"Circulation manager\" ng-click=\"grid.appScope.getCaseInfo(row)\"> <i class=\"fas fa-tasks\"><\/i><\/a><\/div>",

            displayName: 'Actions',
            field: 'actions',
            headerTooltip: 'Actions',
            cellTooltip: true,
            width: '19%',
            allowCellFocus: false,
            enableColumnMenu: false
          },
        ]
      };

      function getAIAURLs(gotoPage, caseInfo) {
        HttpFactory.getActions(CONSTANTS.URL.AIA_URLS)
        .then(function (successResponse) {
          var aiaTrialsLinks = successResponse.data;
          angular.forEach(aiaTrialsLinks, function(valueRow) {
            if (valueRow.valueText==="CASE_VIEWER") {
              trialsLink = valueRow.descriptionText;
            }

          });
        }, function (failureResponse) {

        });
      }

      $scope.openCaseViewer = function (row) {
        var isTrials = row.entity.appealNumber.match(/[a-z]/i) ? true : false;

        if (isTrials) {
          if (row.entity.appealNumber.match(/[D]/i) && trialsLink && trialsLink.indexOf('caseViewer')>0) {
            CommonHelperService.getRedirectUrl();
            return;
          }
          var url = trialsLink + row.entity.serialNumber + "/" +  row.entity.appealNumber + "/documents";
          $window.open(url);
          return;
        }
        $window.open("#/caseViewer/" + row.entity.serialNumber + "/" + row.entity.appealNumber + "/documents");
      };

      $scope.getCaseInfo = function (row) {

        if (row.entity.appealNumber.match(/[a-z]/i)) {
          ngDialog.open({
            template: 'app/components/navbar/noCirculation.modal.html',
            controller: 'NoCirculationController',
            controllerAs: 'vm',
            width: '25%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              rowToDelete: function () {
                return null;
              },
              flag: function () {
                return 'noCirculation';
              },
              caseNumber: function () {
                return row.entity.appealNumber;
              }
            }
          });
        } else {
          HttpFactory.getActions("/case-information/details?serialNumber=" + row.entity.serialNumber + "&appealNumber=" + row.entity.appealNumber)
            .then(function (successResponse) {
              vm.caseInfo = successResponse.data;
              vm.circulationViewable = vm.caseInfo.circulationViewable;
              $scope.openCirculationManager(row);
            }, function (failureResponse) {
              $log.info(failureResponse);
            });
        }
      };

      $scope.openCirculationManager = function (row) {
        if (vm.circulationViewable) {
          $window.open("#/circulation/" + row.entity.serialNumber + "/" + row.entity.appealNumber);
        } else {
          ngDialog.open({
            template: 'app/components/navbar/noCirculation.modal.html',
            controller: 'NoCirculationController',
            controllerAs: 'vm',
            width: '35%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              rowToDelete: function () {
                return null;
              },
              flag: function () {
                return 'noCirculation';
              },
              caseNumber: function () {
                return row.entity.appealNumber;
              }
            }
          });
        }
      };


      vm.advancedSearch = function () {
        $scope.searchTotalLength = 0;
        $scope.failureResponse = false;
        vm.displayNone = true;
        vm.gridOptions.data = [];
        if ($scope.searchThis === "") {
          vm.gridOptions.data = [];
          vm.showResults = false;
          vm.noNumberSelected = true;
        } else {
          HttpFactory.getActions("/case-information/caseNumber-search?searchType=" + $scope.searchTerm + "&caseNumber=" + $scope.searchThis)
            .then(function (successResponse) {
              vm.gridOptions.data = successResponse.data.searchNumbers;
              $scope.searchTotalLength = vm.gridOptions.data.length;
              if (successResponse.data.message) {
                $scope.searchTotalLength = 0;
              }
              if ($scope.searchThis === "") {
                vm.gridOptions.data = [];
                vm.showResults = false;
                vm.noNumberSelected = true;

              } else if ($scope.searchTotalLength > 0) {
                vm.displayNone = false;
                vm.showResults = true;
              }
            }, function (failureResponse) {
              $scope.failureMessage = failureResponse.data.message;
              $scope.failureResponse = true;
              $scope.searchTotalLength = 0;
            });

        }
      };

      vm.numberLook = function () {
        vm.showResults = false;
        vm.noNumberSelected = false;
        $scope.failureResponse = false;
      };

      vm.pressEnter = function (event) {
        if (event.keyCode === 13) {
          vm.advancedSearch();
        }
      };
    });
})();
