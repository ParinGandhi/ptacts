'use strict';
angular
  .module('ptabe2e').directive('globalHeader2', function ($timeout, $window) {
    return {
      restrict: 'E',
      scope: {
        customdata: '=',
        openCaseViewer: '=',
        externalurls: '=',
        callonenter: '=?',
        openApplicationList: '=?',
        status1: '='
      },
      templateUrl: 'app/components/globalHeader/globalHeaderDirective2.html',
      link: function (scope, elm, attrs) {
        // Intentional empty function
      }
    };
  });
