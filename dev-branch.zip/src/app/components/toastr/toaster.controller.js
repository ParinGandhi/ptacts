(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .controller('ToasterController', function ($scope, ngDialog) {
      $scope.openToasterConsole = function () {
        ngDialog.open({
          template: "app/components/toastr/toastmsg.html",
          controller: 'toastCloseController',
          // scope: $scope,
          width: '25%',
          showClose: false,
          resolve: {
            message: function () {
              return $scope.message;
            },
            title: function () {
              return $scope.title;
            },
            toastClass: function () {
              return $scope.toastClass;
            },
            toastType: function () {
              return $scope.toastType;
            }
          }
        });
      };

      $scope.contactUs = function () {
        ngDialog.open({
          template: "app/components/toastr/contactUs.html",
          controller: 'ContactUsController',
          width: '40%',
          showClose: false,
          resolve: {
          }
        })
      };

    });
})();
