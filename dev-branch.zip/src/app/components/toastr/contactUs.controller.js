(function () {
    'use strict';

    angular
        .module('ptabe2e')
        .controller('ContactUsController', function ($scope, ngDialog, HttpFactory) {


            $scope.getHelpHtml = function () {
                HttpFactory.getActions("/reference-data/code-reference-types?typeCode=HTML")
                    .then(function (htmlResponse) {

                        if (htmlResponse && htmlResponse.data && htmlResponse.data.length > 0) {
                            angular.forEach(htmlResponse.data, function (element) {
                                if (element.valueText == 'AppealsContactUs') {
                                    $scope.contactUsHtml = element.descriptionText
                                }
                            });
                            var div = document.getElementById("htmlContent");
                            if ($scope.contactUsHtml) {
                                div.innerHTML = $scope.contactUsHtml;
                            }
                          }
                    }, function (failureResponse) {
                        $scope.failureMessage = failureResponse.data.message;
                    });
            };
            $scope.getHelpHtml();
        });
})();
