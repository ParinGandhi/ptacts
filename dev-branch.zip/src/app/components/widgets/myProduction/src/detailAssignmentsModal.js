(function () {
  "use strict";
  angular
  .module('ptabe2e')

  .controller('DetailAssignmentsController', function ($scope, HttpFactory, uiGridConstants, CONSTANTS) {
    var vm = this;
    vm.dialogData = $scope.ngDialogData;

    vm.assignmentsOptions = {
      enableHorizontalScrollbar: 2,
      showColumnFooter:true,
      paginationPageSizes: [10, 25, 50, 100],
      paginationPageSize: 10,
      columnDefs: [{
          name: 'number',
          displayName: 'No.',
          headerTooltip: 'Number',
          cellTooltip: true,
          cellClass: 'detailCellRightAlign',
          footerCellTemplate:"<div class=\"myProductionGrid-rightAlign-footer\">{{grid.appScope.vm.totalNumOfAssignments}}<\/div>",
          width:62,
          type:'number',
          field: 'rowNumber'
        },
         {
          name: 'appealNumber',
          displayName: 'Case #',
          headerTooltip: 'Case #',
          footerCellTemplate:"<div>&nbsp; &mdash;<\/div>",
          cellTooltip: true,
          field: 'appealNumber',type: "number",
          width: 90
        },
        {
          name: 'serialNumber',
          displayName: 'Application #',
          headerTooltip: 'Application number',
          footerCellTemplate:"<div>&nbsp; &mdash;<\/div>",
          cellTooltip: true,
          field: 'serialNumber',
          width:128
        },
        {
          name: 'assignmentType',
          displayName: 'Assignment type',
          width:230,
          headerTooltip: 'Assignment type',
          footerCellTemplate:"<div>&nbsp; &mdash;<\/div>",
          cellTooltip: true,
          field: 'assignmentType'
        },
        {
          name: 'assignedDate',
          displayName: 'Assigned date',
          headerTooltip: 'Assigned date',
          cellTooltip: true,
          field: 'assignmentAssignedDate',
          footerCellTemplate:"<div>&nbsp; &mdash;<\/div>",
          type: 'date',
          cellFilter: "date:'MM/dd/yyyy'",
          width:130
        },
        {
          name: 'completionDate',
          displayName: 'Completion date',
          headerTooltip: 'Completion date',
          cellTooltip: true,
          field: 'assignmentCompletionDate',
          footerCellTemplate:"<div>&nbsp; &mdash;<\/div>",
          type: 'date',
          cellFilter: "date:'MM/dd/yyyy'",
          width:145
        },
        {
          name: 'PC',
          displayName: 'PC',
          headerTooltip: 'Production credit',
          cellTooltip: true,
          cellFilter: 'number:2',
          cellClass: 'detailCellRightAlign',
      //    aggregationType:uiGridConstants.aggregationTypes.sum,
          footerCellTemplate:"<div class=\"myProductionGrid-rightAlign-footer\">{{grid.appScope.vm.getFooter(grid.appScope.vm.totalProductivityCredits)}}<\/div>",
          field: 'productivityCredits',
          width:60
        },
        {
          name: 'APC',
          displayName: 'APC',
          headerTooltip: 'Additional production credit',
          cellTooltip: true,
          cellFilter: 'number:2',
        //  cellClass: 'detailCellRightAlign',
          aggregationType:uiGridConstants.aggregationTypes.sum,
          cellTemplate: "<div style=\"padding-top:5px;\" class=\"truncateTitle myProductionGrid-rightAlign-footer\"><span style=\"margin-left:8px;padding-top:5px;\"><a ng-show='row.entity.rapcPendingStatus' style='margin-top:-.32em;color:black;' title=\"APC request is awaiting supervisor's review\" class='myProductionHourGlass btn btn-hover btn-icon-only'><i class='fas fa-hourglass-half' ng-class=\"{'myProductionHourGlassIcon2Digits':row.entity.additionalProductivityCredits>=10}\"></i><span class='sr-only'>Pending APC</span></a> <span class'detailCellRightAlign'>{{grid.appScope.vm.getFooter(row.entity.additionalProductivityCredits)}}</span></span></div>",
          footerCellTemplate:"<div class=\"myProductionGrid-rightAlign-footer\">{{grid.appScope.vm.getFooter(grid.appScope.vm.totalAdditionalProductivityCredits)}}<\/div>",
          field: 'additionalProductivityCredits',
          width:90
        },
        {
          name: 'totalCredit',
          displayName: 'Total credit',
          headerTooltip: 'Total credit',
          cellTooltip: true,
          cellFilter: 'number:2',
          cellClass: 'detailCellRightAlign',
          aggregationType:uiGridConstants.aggregationTypes.sum,
          field: 'totalCredits',
          footerCellFilter:'number:2',
          footerCellTemplate:"<div class=\"myProductionGrid-rightAlign-footer\">{{grid.appScope.vm.getFooter(grid.appScope.vm.totalCredits)}}<\/div>",
          width:110
        }
      ]
    };

    getAssignmentData();
    function getAssignmentData() {

//      https://ptabe2eint-fqt.etc.uspto.gov/PTABAppealsServices//userAssignments-userCredits?applicationUserId=mcarlson1&assignmentTypeCodes=preAppealEwf&startPayPeriod=01012019&endPayPeriod=11182020
      var serviceUrl = CONSTANTS.URL.GET_ASSIGNMENTS_DETAILS;
      serviceUrl +="applicationUserId=" + $scope.ngDialogData.applicationUserId +
       "&assignmentTypeCodes=" + $scope.ngDialogData.assignmentTypeCodes +
       "&startPayPeriod=" + $scope.ngDialogData.startPayPeriod +
       "&endPayPeriod=" + $scope.ngDialogData.endPayPeriod;

//       serviceUrl += "applicationUserId=dglover2&assignmentTypeCodes=preAppealEwf&startPayPeriod=01012019&endPayPeriod=11182020";
       HttpFactory.getActions(serviceUrl).then(function (successResponse) {
        $scope.isLoading = false;
        vm.assignmentsOptions.data = successResponse.data.userAssignmentAndUserCreditsList;
        vm.totalNumOfAssignments = successResponse.data.totalNumOfAssignments;
        vm.totalProductivityCredits = successResponse.data.totalProductivityCredits;
        vm.totalAdditionalProductivityCredits = successResponse.data.totalAdditionalProductivityCredits;
        vm.totalCredits = successResponse.data.totalCredits;
      }, function (failureResponse) {
        $scope.failureMessage = failureResponse.data.message;
        $scope.failureResponse = true;
        $scope.searchTotalLength = 0;
        $scope.isLoading = false;
      });

    }

    function getCreditValue(value) {
      if (value % 1 != 0) {
        return value.toFixed(2);
      }

      return value;
    }

    vm.getFooter = function(value) {
      if (value) {
        return value.toFixed(2);
      }
      value = 0;
      return value.toFixed(2);
    };

    function getCreditValue(field, rowData) {
      if (!field) {
        return 0;
      }
      if (field.indexOf("totalProductivityCredits")>=0) {
        return rowData.totalProductivityCredits;
      } else if (field.indexOf("totalAdditionalProductivityCredits")>=0) {
        return rowData.totalAdditionalProductivityCredits;
      } else {
        return rowData.totalCredits;
      }
    }
  });
})();
