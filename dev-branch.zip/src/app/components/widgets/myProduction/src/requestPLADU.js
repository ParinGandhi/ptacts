(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .controller('RequestPLADUController', function ($scope, ngDialog, $timeout, $filter, HttpFactory, CONSTANTS, CommonHelperService) {
    var vm = this;
    vm.userInfo = $scope.ngDialogData.userInfo;
    var widgetIdentifier = $scope.ngDialogData.widgetIdentifier;
    vm.caseChangeMode = true;
    vm.judge = {
     "fullName": null
    };
    vm.totalDraftDecisionTimeMin= "00";
    var aduFile;
    var reader = new FileReader();
    var fileByteArray = [];

    getSupervisor();

    function getAssignHistory() {

      HttpFactory.getActions("/assignments/closed-assignments-for-credits?serialNumber=" + vm.applicationNumber + "&appealNumber=" + vm.caseNumber + "&userId=" + vm.userInfo.userId)
        .then(function (successResponse) {
          var assignHistory = successResponse.data;
          vm.judgeList=[];
          for (var i = 0; i < assignHistory.length; i++) {

              var dateStr = $filter('date')(assignHistory[i].completionDate, 'MM/dd/yyyy - hh:mm:ss a');
              var item = assignHistory[i].assignmentTypeDescription + ", " + dateStr;
              assignHistory[i].assigneeFullNameText = item;
              vm.judgeList.push(assignHistory[i]);
  
            vm.originalJudgeList = angular.copy(vm.judgeList);
            vm.selectedJudge = vm.judgeList[0];

          }
         }, function (failureResponse) {
          CommonHelperService.setToastr("Failed retrieving assignments for this case", "error");

        }); 
    }

    vm.submitRequest = function() {
      var data = {
        ptabAssignmentIdentifier : vm.selectedJudge.assignmentIdentifier,
        requestedDecisionalUnits: vm.pc,
        reason:vm.correctDuReason,
        supervisorId: vm.sendRequestEmailId.assigneeNumberText,
        completionDate:vm.selectedJudge.completionDate,
        appealNumber:vm.caseNumber,
        serialNumber:vm.applicationNumber,
        caseType:"APPEAL",
        totalDraftDecisionTime : vm.totalDraftDecisionTime + "." + vm.totalDraftDecisionTimeMin,
        personToReceiveCredits : vm.userInfo.userId,
        audit: {
          createUserIdentifier: vm.userInfo.userId,
          lastModifiedUserIdentifier: vm.userInfo.userId
        },
        decisionalUnitsAwarded: vm.userInfo.displayName,
        decisionalUnitsAwardedIdentifier: vm.userInfo.userId,
        assignmentType: vm.selectedJudge.assignmentTypeDescription,
 //       qualifier: vm.qualifier,
 //       specialType: rowData.entity.specialType ? rowData.entity.specialType.trim() != "" ? rowData.entity.specialType : '' : '',
        assignmentTitle: vm.selectedJudge.assignmentTypeDescription,
        dateOfRequest: new Date().getTime(),
        widgetIdentifier: widgetIdentifier,
        // "sendRequestEmailAddress: vm .sendRequestEmailId,
        fileName: ($scope.fileInfo != null || $scope.fileInfo != undefined) ? $scope.fileInfo.name : null,
        attachmentInBytes: fileByteArray,
        creditTypeCode: "RAPC",
        requestStatus: "Submitted"
      }
      vm.disableSubmit = true;
      HttpFactory.putActions(CONSTANTS.URL.MY_CREDITS_REQUESTDU, data)
        .then(function () {
            vm.disableSubmit = false;
            CommonHelperService.setToastr("An assignment to request additional production credits (APC) has been created and assigned to " + vm.sendRequestEmailId.assigneeFullNameText + ".", "success");
          ngDialog.closeAll(true);
          },
          function () {
            vm.disableSubmit = false;
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.APCFail, "error");

          });

    }

    vm.clearForm = function() {
      vm.selectedJudge=null;
      vm.judge.fullName="";
      vm.originalJudgeList = null;
      vm.judgeList=null;
      vm.pc = "";
      vm.totalDraftDecisionTime="";
      vm.totalDraftDecisionTimeMin="00";
      vm.correctDuReason="";
      vm.clearFile();
      vm.metaData = {};
      vm.sendRequestEmailId = vm.supervisorList1[0]; 
    };

    function getCaseStatusInformation() {
     
      HttpFactory.getActions("/case-information/details?serialNumber=" + vm.applicationNumber + "&appealNumber=" + vm.caseNumber)
      .then(function (successResponse) {
        console.info("here");
        vm.metaData = {};
        if (successResponse.data.casetransactionDetails && successResponse.data.casetransactionDetails.length>0) {
          vm.metaData.caseStatus = successResponse.data.casetransactionDetails[successResponse.data.casetransactionDetails.length-1].statusDescription;

          vm.metaData.caseStatusDate = successResponse.data.casetransactionDetails[successResponse.data.casetransactionDetails.length-1].statusCodeDates;
        } 
        vm.metaData.applicationNumber = vm.applicationNumber;
        vm.metaData.caseNumber = vm.caseNumber;
        vm.metaData.caseType = successResponse.data.applicationTypeCategory;
        vm.metaData.panel = successResponse.data.attorneys;
        vm.metaData.parties = successResponse.data.parties;
      }, function (failureResponse) {
        CommonHelperService.setToastr(failureResponse, "error");(failureResponse);
      }); 

    }

    vm.pressEnter = function(event) {
      if (event.keyCode === 13) {
        vm.changeCaseNumber();
      }
    };

    vm.changeCaseNumber = function() {

      var searchNum = vm.newCaseNumber.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, '');
      HttpFactory.getActions(CONSTANTS.URL.CASE_SEARCH + searchNum)
      .then(function (successResponse) {
        vm.caseNumber = successResponse.data.appealNumber[0];
        vm.applicationNumber = successResponse.data.serialNumber[0];
        getCaseStatusInformation();
        getAssignHistory();
        vm.caseChangeMode = false;
      }, function () {
        CommonHelperService.setToastr('Case or application number ' + searchNum + ' not found. Please check the number and try again.', "error");
      });
    };


    vm.checkandClose = function () {
      if ((vm.judge.fullName !== "Select assignment type/Completion date" || vm.judge.fullName != undefined) && (!vm.showList) && vm.judge.fullName != null) {
        vm.judgeListVisible = false;
        vm.showList = true;
        vm.focusOut();
      } else if (vm.judge.fullName == null && !vm.showList) {
        vm.judgeListVisible = true;
        vm.showList = false;
      } else if (vm.showList && vm.judge.fullName != null && !vm.focusMoved) {
        vm.judgeListVisible = true;
      } else if (vm.focusMoved) {
        vm.judgeListVisible = false;
        vm.focusMoved = false;
      }
    }


    vm.showJudgeList = function () {
      if (!vm.judgeListVisible) {
        vm.judgeListVisible = !vm.judgeListVisible;
        vm.checkandClose();
      }
    };

    vm.focusOut = function () {
      vm.focusMoved = true;
      if (vm.judgeListVisible != false) {
        vm.judgeListVisible = false;
      }
    };

    vm.setSelectedJudge = function (judge) {
      if (judge.assigneeFullNameText !== "Select assignment type/Completion date") {
        vm.selectedJudge = judge;
        vm.judge.fullName = judge.assigneeFullNameText;
        vm.judgeListVisible = false;
        vm.showList = false;
      }
    };

    vm.searchForJudge = function (input) {
      var tempList = [];
      if (angular.isDefined(input) && input.fullName.trim() !== "") {
        angular.forEach(vm.originalJudgeList, function (currentJudge) {
          if (currentJudge.assigneeFullNameText.toLowerCase().includes(input.fullName.toLowerCase())) {
            tempList.push(currentJudge);
          }
        });
        vm.judgeList = angular.copy(tempList);
      } else {
        vm.judgeList = angular.copy(vm.originalJudgeList);
      }
    };

    function getSupervisor() {
      vm.supervisorList1 = [];
      vm.currentSupervisor="";
      HttpFactory.getActions("/user-management/supervisors/" + vm.userInfo.userId)
        .then(function (successResponse) {
          var superviorResponse1 = successResponse.data;
          superviorResponse1.forEach(function (element) {
            if (vm.currentSupervisor === element.assigneeFullNameText)
              vm.supervisorList1.push(element);
          });
/*          if (vm.supervisorList1.length === 0 && vm.currentSupervisor !== "") {
            vm.supervisorList1.push(vm.items.entity.supervisorsData[0]);

          }*/
          superviorResponse1.forEach(function (element) {
            if (vm.userInfo.displayName !== element.assigneeFullNameText) {
              vm.supervisorList1.push(element);
            }
          });
          vm.sendRequestEmailId = vm.supervisorList1[0];          
        }, function () {
          // Empty response is ok
        });
    }

    /* istanbul ignore next */
    $scope.getFileInfo = function (file) {
      aduFile = document.getElementById("file1");
      $scope.fileInfo = {};
      $scope.fileInfo.name = aduFile.files[0].name;
      $scope.fileInfo.path = aduFile.value;
      reader.readAsArrayBuffer(aduFile.files[0]);
      reader.onloadend = function (evt) {
        if (evt.target.readyState == FileReader.DONE) {
          var arrayBuffer = evt.target.result,
            array = new Uint8Array(arrayBuffer);
          for (var i = 0; i < array.length; i++) {
            fileByteArray.push(array[i]);
          }
        }
      };
    };

    vm.clearFile = function () {
      $scope.fileInfo = {};
    };
	});
})();
