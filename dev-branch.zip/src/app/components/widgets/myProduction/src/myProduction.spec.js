// (function () {
//     'use strict';
  
//     describe('MyProductionController', function () {
  
//       beforeEach(module('ptabe2e'));
  
//       var vm = this;
//       var scope;
//       var controller, $controller;
//       var $http, $interval, $log, $rootScope, spy, row, url, advancedSearchFlag;
//       var $q, HttpFactoryDeferred, timeout, row, rowRenderIndex, col;
//       var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close', 'open']);
//       var successResponse = {
//         data: {
//           events: {},
//           refreshInterval: 0
//         }
//       };
  
//       var failureResponse = '';
  
  
//       var fakeElement = function (params) {
//         return {
//           scope: function () {
//             return {
//               vm: {
//                 getWidgetZone: function () {
  
//                 },
//                 setWidgetContentHeight: function () {
  
//                 },
//                 userInfo: {
//                   "userId": "pgandhi",
//                   "roleDescription": "Judge"
//                 }
//               }
//             }
//           },
  
//           on: function () {
  
//           }
  
//         }
//       };
//       var fakeVm = {
//         getWidgetZone: function () {
  
//         },
//         setWidgetContentHeight: function () {
  
//         }
//       };
  
//       var refreshGrid = {
//         value: "data"
//       }
  
//       beforeEach(inject(function (_$controller_, _$http_, _$rootScope_, _$timeout_, _$interval_, $compile, _$q_, HttpFactory, CONSTANTS) {
//         $q = _$q_;
//         $http = _$http_;
//         scope = _$rootScope_.$new();
//         $interval = _$interval_;
//         $rootScope = _$rootScope_;
//         timeout = _$timeout_;
  
//         $rootScope.userInfo = {
//           "userId": "pgandhi"
//         }
  
//         // setup the promise
//         HttpFactoryDeferred = _$q_.defer();
//         spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
  
//         $controller = _$controller_;
  
//         scope.definition = {
//           dataUrlText: 'http://localhost:8080/PTABServices/',
//           widgetIdentifier: 12
//         }
  
//         ngDialog.open.and.returnValue({
//           closePromise: {
//             then: function (callback1, callback2) {
//               callback1(refreshGrid);
//             }
//           },
//           then: function (callback3, callback4) {
//             callback3();
//           }
//         });
  
//         spy = spyOn(angular, 'element').and.callFake(fakeElement);
  
  
//         scope.$parent = {
//           $parent: {
//             $parent: {
//               definition: {
//                 zoneWidth: 12
//               }
//             }
//           }
//         }
  
//         controller = $controller('MyProductionController', {
//           $http: $http,
//           $scope: scope,
//           ngDialog: ngDialog,
//           $rootScope: _$rootScope_,
//           $interval: $interval,
//           HttpFactory: HttpFactory
  
//         });
  
//         // spyOn($rootScope, '$on').and.callThrough();
//       }));
  
  
//       afterEach(function () {
//         spy.and.callThrough();
//       });
  
  
//       describe('check functions', function () {
//          it('Should call showParalegalList', function () {
//             scope.paralegalListVisible = true;
//           scope.showParalegalList ();
//         });

//         it('Should call updateThis', function () {
//        var value = "preset";
//          expect(scope.updateThis).toBeDefined();
//           scope.updateThis(value);
//         });

//         it('Should call setSelectedTab', function () {
//             var selectedTab = "preset";
//               expect(scope.setSelectedTab).toBeDefined();
//                scope.setSelectedTab(selectedTab);
//              });

//              it('Should call setSelectedTab for date range if', function () {
//                 var selectedTab = "dateRangeTab";
//                   expect(scope.setSelectedTab).toBeDefined();
//                    scope.setSelectedTab(selectedTab);
//                  });

//         it('Should call buttonClick', function () {
//             var value = "preset";
//               expect(scope.buttonClick).toBeDefined();
//                scope.buttonClick(value);
//              });

//              it('Should call refreshGrid', function () {
//                 var refreshProcess  = true;
//                 scope.userDropDownName = "No paralegal selected";
//                   expect(scope.refreshGrid).toBeDefined();
//                    scope.refreshGrid();
//                  });

//                  it('Should call refreshGrid', function () {
//                     var refreshProcess  = true;
//                     scope.userDropDownName ="No selected";
//                       expect(scope.refreshGrid).toBeDefined();
//                        scope.refreshGrid();
//                      });

//         it('Should call setPayperiod', function () {
//             var value = "1";
//             var type= "from";
//             scope.toChangePayperiod = 1;
//             scope.fromChangePayperiod =2;
//             scope.changedStartDate =undefined;
//             scope.changedEndDate =undefined;
//               expect(scope.setPayperiod).toBeDefined();
//                scope.setPayperiod(type, value);
//              });

//              it('Should call setPayperiod else', function () {
//                 var value = "1";
//                 var type= "to";
//                 scope.toChangePayperiod = 1;
//                 scope.fromChangePayperiod =2;
//                 scope.changedStartDate =undefined;
//                 scope.changedEndDate =undefined;
//                   expect(scope.setPayperiod).toBeDefined();
//                    scope.setPayperiod(type, value);
//                  });
    
//                  it('Should call setPayperiod else', function () {
//                     var value = "1";
//                     var type= "to";
//                     scope.fromPayPeriod = 1;
//                     scope.toPayPeriod =2;
//                     scope.toChangePayperiod = undefined;
//                     scope.fromChangePayperiod =undefined;
//                     scope.changedStartDate =undefined;
//                     scope.changedEndDate =undefined;
//                       expect(scope.setPayperiod).toBeDefined();
//                        scope.setPayperiod(type, value);
//                      });

//                      it('Should call getData', function () {
//                         var data ={"assigneeFullNameText": "1"};
//                           expect(scope.getData).toBeDefined();
//                            scope.getData(data);
//                          });

//                  it('Should call setPayperiod else', function () {
//                     var value = "1";
//                     var type= "to";
//                     scope.toChangePayperiod = 1;
//                     scope.fromChangePayperiod =2;
//                     scope.changedStartDate =1;
//                     scope.changedEndDate =1;
//                       expect(scope.setPayperiod).toBeDefined();
//                        scope.setPayperiod(type, value);
//                      });

//                      it('it should call getProductionDataForParalegal for DT', function () {
//                         scope.showValueOfSelected = "DT";
//                         scope.widgetIdentifier = "123";
//                         scope.startDateHere = "1";
//                         scope.endDateHere="1";
//                         failureResponse = {
//                           data: "FAILED"
//                         };
//                         var paralegalNumber ="123";
//                         var paralegalName = "ABC";
//                         scope.getProductionDataForParalegal(paralegalNumber,paralegalName);
//                       });

//                       it('it should call getProductionDataForParalegal for currentMonth', function () {
//                         scope.showValueOfSelected = "PRESET";
//                         scope.displayPresetType ="currentMonth";
//                         scope.widgetIdentifier = "123";
//                         scope.startDateHere = "1";
//                         scope.endDateHere="1";
//                         failureResponse = {
//                           data: "FAILED"
//                         };
//                         var paralegalNumber ="123";
//                         var paralegalName = "ABC";
//                         scope.getProductionDataForParalegal(paralegalNumber,paralegalName);
//                       });
    
//                       it('it should call getProductionDataForParalegal for previousMonth', function () {
//                         scope.showValueOfSelected = "PRESET";
//                         scope.displayPresetType ="previousMonth";
//                         scope.widgetIdentifier = "123";
//                         scope.startDateHere = "1";
//                         scope.endDateHere="1";
//                         failureResponse = {
//                           data: "FAILED"
//                         };
//                         var paralegalNumber ="123";
//                         var paralegalName = "ABC";
//                         scope.getProductionDataForParalegal(paralegalNumber,paralegalName);
//                       });

//                       it('it should call getProductionDataForParalegal for fiscalYear', function () {
//                         scope.showValueOfSelected = "PRESET";
//                         scope.displayPresetType ="fiscalYear";
//                         scope.widgetIdentifier = "123";
//                         scope.startDateHere = "1";
//                         scope.endDateHere="1";
//                         failureResponse = {
//                           data: "FAILED"
//                         };
//                         var paralegalNumber ="123";
//                         var paralegalName = "ABC";
//                         scope.getProductionDataForParalegal(paralegalNumber,paralegalName);
//                       });

//                     //   it('getProductionDataForParalegal failureResponse ', function () {
//                     //     scope.showValueOfSelected = "PRESET";
//                     //     scope.displayPresetType ="fiscalYear";
//                     //     scope.widgetIdentifier = "123";
//                     //     scope.startDateHere = "1";
//                     //     scope.endDateHere="1";
//                     //     var paralegalNumber ="123";
//                     //     var paralegalName = "ABC";
//                     //  failureResponse = {
//                     //       data: {"message": "message"}
//                     //     };
//                     //     expect(scope.getProductionDataForParalegal).toBeDefined();
//                     //     scope.getProductionDataForParalegal(paralegalNumber,paralegalName);
//                     //     HttpFactoryDeferred.reject(failureResponse);
//                     //     $rootScope.$apply();
//                     //   });

//                       it('it should call getProductionDataForParalegal', function () {
//                         scope.showValueOfSelected = "SSS";
//                         scope.widgetIdentifier = "123";
//                         scope.startDateHere = "1";
//                         scope.endDateHere="1";
//                         failureResponse = {
//                           data: "FAILED"
//                         };
//                         var paralegalNumber ="123";
//                         var paralegalName = "ABC";
//                         // expect(scope.getProductionDataForParalegal).toBeDefined();
//                         scope.getProductionDataForParalegal(paralegalNumber,paralegalName);
//                         // HttpFactoryDeferred.reject(failureResponse);
//                         // $rootScope.$apply();
//                       });
//              it('Should call setFromDate', function () {
//                 var value = "preset";
//                 scope.changedStartDate =undefined;
//                 scope.changedEndDate =undefined;
//                   expect(scope.setFromDate).toBeDefined();
//                    scope.setFromDate(value);
//                  });

//                    it('it should call focusOut', function () {
//                     var showPAList  = false;
//                     expect(scope.focusOut).toBeDefined();
//                     scope.focusOut();
//                   });

//                   it('it should call focusOut', function () {
//                     var pAListVisible = false;
//                     expect(scope.focusOut).toBeDefined();
//                     scope.focusOut();
//                   });

//                   it('it should call showJudgeList2 ', function () {
//                     var judgeListVisible2 = "false";
//                     expect(scope.showJudgeList2 ).toBeDefined();
//                     scope.showJudgeList2 ();
//                   });

//                   it('it should call showJudgeList2 ', function () {
//                     var judgeListVisible2 = true;
//                     expect(scope.showJudgeList2 ).toBeDefined();
//                     scope.showJudgeList2 ();
//                   });

//                   it('it should call showParalegalList  ', function () {
//                     var judgeListVisible2 = true;
//                     expect(scope.showParalegalList  ).toBeDefined();
//                     scope.showParalegalList  ();
//                   });

//                   it('it should call showParalegalList  ', function () {
//                     var judgeListVisible2 = false;
//                     expect(scope.showParalegalList  ).toBeDefined();
//                     scope.showParalegalList  ();
//                   });

//                   it('it should call setSelectedJudge2 ', function () {
//                     var judge = "Select an employee...";
//                     expect(scope.setSelectedJudge2 ).toBeDefined();
//                     scope.setSelectedJudge2 (judge);
//                   });

//                   it('it should call setSelectedJudge3', function () {
//                     var judge = "Select from...";
//                     expect(scope.setSelectedJudge3 ).toBeDefined();
//                     scope.setSelectedJudge3 (judge);
//                   });

//                   it('it should call showJudgeList3', function () {
//                     var judgeListVisible3= false;
//                     expect(scope.showJudgeList3).toBeDefined();
//                     scope.showJudgeList3();
//                   });

//                 //  it('it should call updatePayPeriod', function () {
//                 //     var selectedTab = "do do";
//                 //     scope.toChangePayperiod = "1-2";
//                 //     scope.fromChangePayperiod = "12-12";
//                 //     expect(scope.updatePayPeriod).toBeDefined();
//                 //     scope.updatePayPeriod();
//                 //   });

//             // it('Should invoke getWorker', function () {
//         //   var event = {};
//         //   event.keyCode = 13;
//         //   var searchText = 'pgandhi';
//         //   spyOn(scope, 'simpleSearch');
//         //   expect(scope['simpleSearch']).toBeDefined();
//         //   expect(scope['pressEnter']).toBeDefined();
//         //   scope.pressEnter(event, searchText);
//         //   expect(scope.simpleSearch).toHaveBeenCalled();
//         // });

//          it('Should invoke enterOnActions', function () {
//           var event = {};
//           event.keyCode = 13;
//           var action = 'pgandhi';
//           spyOn(scope, 'myProductionActions');
//           expect(scope['myProductionActions']).toBeDefined();
//           expect(scope['enterOnActions']).toBeDefined();
//           scope.enterOnActions(event, action);
//           expect(scope.myProductionActions).toHaveBeenCalled();
//         });

//              it('Should invoke enterOnActions', function () {
//           var event = {};
//           event.keyCode = 1;
//           var action = 'pgandhi';
//           scope.enterOnActions(event, action);
//           expect(scope.enterOnActions).toBeDefined();
//         });

//         it('Should invoke getFooter', function () {
//             var value = 1.00;
//             // var action = 'pgandhi';
//             scope.getFooter(value);
//             expect(scope.getFooter).toBeDefined();
//           });

//           it('Should invoke getFooter', function () {
//             var value = 0;
//             scope.getFooter(value);
//             expect(scope.getFooter).toBeDefined();
//           });

//                  it('Should call setToDate', function () {
//                     var value = "preset";
//                     scope.changedStartDate =undefined;
//                     scope.changedEndDate =undefined;
//                       expect(scope.setToDate).toBeDefined();
//                        scope.setToDate(value);
//                      });

//                  it('Should call setFromDate ', function () {
//                     var value = "preset";
//                     scope.changedStartDate = 11;
//                     scope.changedEndDate =12;
//                       expect(scope.setFromDate ).toBeDefined();
//                        scope.setFromDate (value);
//                      });

//                      it('Should call setFromDate  else', function () {
//                         var value = "preset";
//                         scope.changedStartDate = 111;
//                         scope.changedEndDate =12;
//                         var z = true;
//                           expect(scope.setFromDate).toBeDefined();
//                            scope.setFromDate(value);
//                          });

// it('Should call setToDate', function () {
//                     var value = "preset";
//                     scope.changedStartDate = 11;
//                     scope.changedEndDate =12;
//                       expect(scope.setToDate).toBeDefined();
//                        scope.setToDate(value);
//                      });

//                      it('Should call setToDate else', function () {
//                         var value = "preset";
//                         scope.changedStartDate = 111;
//                         scope.changedEndDate =12;
//                         var z = true;
//                           expect(scope.setToDate).toBeDefined();
//                            scope.setToDate(value);
//                          });

//         it('listItemUp should call move item', function () {
//           expect(scope.listItemUp).toBeDefined();
//           spyOn(scope, 'moveItem');
//           expect(scope['moveItem']).toBeDefined();
//           scope.listItemUp(1);
//           expect(scope.moveItem).toHaveBeenCalledWith(1, 0);
//         });
  
//         it('listItemDown should call move item', function () {
//           expect(scope.listItemDown).toBeDefined();
//           spyOn(scope, 'moveItem');
//           expect(scope['moveItem']).toBeDefined();
//           scope.listItemDown(1);
//           expect(scope.moveItem).toHaveBeenCalledWith(1, 2);
//         });
  
//         it('it should call myProductionActions', function () {
//           var action = '1561';
//           expect(scope.myProductionActions).toBeDefined();
//           scope.myProductionActions(action);
//         });
  
//         // it('it should call myProductionActions', function () {
//         //     var action = 'enterOtherCredits';
//         //     expect(scope.myProductionActions).toBeDefined();
//         //     scope.myProductionActions(action);
//         //   });

//         // it('it should call openAssignmentInfo ', function () {
//         //   var row = {
//         //     entity: {
//         //       ptabAssignmentIdentifier: "1561"
//         //     }
//         //   }
//         //   expect(scope.openAssignmentInfo).toBeDefined();
//         //   scope.openAssignmentInfo(row);
//         // });
  
//         // it('it should call ngdialogConfig ', function () {
//         //   expect(controller.ngdialogConfig).toBeDefined();
//         //   controller.ngdialogConfig();
//         // });
  
//         // it('it should call enterDate ', function () {
//         //   expect(scope.enterDate).toBeDefined();
//         //   scope.enterDate();
//         // });
  
//         // it('Should invoke getWorker', function () {
//         //   var event = {};
//         //   event.keyCode = 13;
  
//         //   var searchText = 'pgandhi';
  
//         //   spyOn(scope, 'simpleSearch');
//         //   expect(scope['simpleSearch']).toBeDefined();
//         //   expect(scope['pressEnter']).toBeDefined();
//         //   scope.pressEnter(event, searchText);
//         //   expect(scope.simpleSearch).toHaveBeenCalled();
//         // });
  
//         // it(' should call openCaseViewer', function () {
//         //   row = {
//         //     entity: {
//         //       caseNumber: '2018005819',
//         //       applicationNumber: '15007114'
//         //     }
//         //   }
//         //   expect(scope['openCaseViewer']).toBeDefined();
//         //   scope.openCaseViewer(row);
//         // });
  
//         // it(' should get MyCreditsColumns ', function () {
  
//         //   expect(scope.getMyCreditsColumns).toBeDefined();
//         //   scope.getMyCreditsColumns();
//         // });
  
  
//         // it('Should invoke simpleSearch', function () {
//         //   var textToSearch = "pgandhi"
//         //   scope.gridOptions = {
//         //     data: [{}]
//         //   }
//         //   expect(scope['simpleSearch']).toBeDefined();
//         //   scope.simpleSearch(textToSearch);
//         // });
  
//         // it('it should call ngdialogConfig ', function () {
//         //   var template, controller, row, width= false;
//         //   expect(controller.ngdialogConfig).toBeDefined();
//         //   controller.ngdialogConfig(template, controller, row, width);
  
  
//         //   expect(ngDialog.open).toHaveBeenCalled();
  
//         //   expect(ngDialog.open.calls.count()).toBe(1);
//         //   var args = ngDialog.open.calls.argsFor(0);
//         //   expect(args).not.toBe(null);
//         //   expect(args.length).toBe(1);
  
//         //   expect(args[0].controller).toBe('correctDuController');
//         //   expect(typeof args[0].resolve).toBe('object');
//         //   args[0].resolve.items();
//         //   args[0].resolve.readOnly();
//         //   args[0].resolve.rowData();
//         // });
  
//         // it('it should call correctDu ', function () {
//         //   var row = {
  
//         //   }
//         //   expect(scope['correctDu']).toBeDefined();
//         //   scope.correctDu();
  
  
//         //   expect(ngDialog.open).toHaveBeenCalled();
  
//         //   expect(ngDialog.open.calls.count()).toBe(1);
//         //   var args = ngDialog.open.calls.argsFor(0);
//         //   expect(args).not.toBe(null);
//         //   expect(args.length).toBe(1);
  
//         //   expect(args[0].controller).toBe('correctDuController');
//         //   expect(typeof args[0].resolve).toBe('object');
//         //   args[0].resolve.items();
//         //   args[0].resolve.widgetIdentifier();
//         // });
  
  
//         // it('it should call rellocateDu ', function () {
  
//         //   expect(scope['rellocateDu']).toBeDefined();
//         //   scope.rellocateDu();
  
  
//         //   expect(ngDialog.open).toHaveBeenCalled();
  
//         //   expect(ngDialog.open.calls.count()).toBe(2);
//         //   var args = ngDialog.open.calls.argsFor(1);
//         //   expect(args).not.toBe(null);
//         //   expect(args.length).toBe(1);
  
//         //   expect(args[0].controller).toBe('reallocateDuController');
//         //   expect(typeof args[0].resolve).toBe('object');
//         //   args[0].resolve.rowData();
//         //   args[0].resolve.widgetIdentifier();
  
//         // });
  
  
//         // it('it should call requestADU ', function () {
//         //   var row = {
//         //     entity: {
//         //       type: "Request"
//         //     }
//         //   }
//         //   expect(scope['requestADU']).toBeDefined();
//         //   scope.requestADU(row);
  
  
//         //   expect(ngDialog.open).toHaveBeenCalled();
  
//         //   expect(ngDialog.open.calls.count()).toBe(3);
//         //   var args = ngDialog.open.calls.argsFor(2);
//         //   expect(args).not.toBe(null);
//         //   expect(args.length).toBe(1);
  
//         //   expect(args[0].controller).toBe('requestADUController');
//         //   expect(typeof args[0].resolve).toBe('object');
//         //   args[0].resolve.rowData();
//         //   args[0].resolve.requestType();
//         //   args[0].resolve.widgetIdentifier();
  
//         // });
  
//         // it('it should call reconsiderAdu ', function () {
//         //   var row = {
//         //     entity: {
//         //       type: "Reconsideration"
//         //     }
//         //   }
//         //   expect(scope['reconsiderAdu']).toBeDefined();
//         //   scope.reconsiderAdu(row);
  
  
//         //   expect(ngDialog.open).toHaveBeenCalled();
  
//         //   expect(ngDialog.open.calls.count()).toBe(4);
//         //   var args = ngDialog.open.calls.argsFor(3);
//         //   expect(args).not.toBe(null);
//         //   expect(args.length).toBe(1);
  
//         //   expect(args[0].controller).toBe('requestADUController');
//         //   expect(typeof args[0].resolve).toBe('object');
//         //   args[0].resolve.rowData();
//         //   args[0].resolve.requestType();
//         //   args[0].resolve.widgetIdentifier();
  
//         // });
  
//         // it(' should get updateColumns ', function () {
//         //   scope.gridState = {
//         //     paginationSize: 10
//         //   }
//         //   expect(scope.updateColumns).toBeDefined();
//         //   scope.updateColumns();
//         // });
  
  
//         // it('it should call updateCredits ', function () {
//         //   var row = {
//         //     entity: {
//         //       type: "Reconsideration"
//         //     }
//         //   }
//         //   expect(scope['updateCredits']).toBeDefined();
//         //   scope.updateCredits(row);
  
  
//         //   expect(ngDialog.open).toHaveBeenCalled();
  
//         //   expect(ngDialog.open.calls.count()).toBe(5);
//         //   var args = ngDialog.open.calls.argsFor(4);
//         //   expect(args).not.toBe(null);
//         //   expect(args.length).toBe(1);
  
//         //   expect(args[0].controller).toBe('updateCreditsController');
//         //   expect(typeof args[0].resolve).toBe('object');
//         //   args[0].resolve.items();
  
//         // });
  
//         // it(' should get callMyTeam ', function () {
//         //   expect(scope.callMyTeam).toBeDefined();
//         //   scope.callMyTeam();
//         // });
  
//         // it(' should get callMyGroup ', function () {
//         //   expect(scope.callMyGroup).toBeDefined();
//         //   scope.callMyGroup();
//         // });
  
//         // it(' should get getMyTeamCredits ', function () {
//         //   expect(scope.getMyTeamCredits).toBeDefined();
//         //   scope.getMyTeamCredits();
//         // });
  
//         // it(' should get getMyGroupCredits ', function () {
//         //   expect(scope.getMyGroupCredits).toBeDefined();
//         //   scope.getMyGroupCredits();
//         // });
  
//         // it(' should get getTimeFrames ', function () {
//         //   var value = "PREVIOUSMONTH";
//         //   expect(scope.checkTimeFrame).toBeDefined();
//         //   scope.checkTimeFrame(value);
//         // });
  
//         // it(' should get getTimeFrames ', function () {
//         //   var value = "PREVIOUSMONTH";
//         //   expect(scope.getTimeFrames).toBeDefined();
//         //   scope.getTimeFrames(value);
//         // });
  
//       });
  
//     });
//   })();
  