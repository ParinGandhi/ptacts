'use strict';
angular.module('adf.widget.myProduction', ['adf.provider'])
  .config(function (dashboardProvider) {
    dashboardProvider
      .widget('myProduction', {
        title: 'My Production',
        description: 'widget for my production',
        templateUrl: '{widgetsPath}/myProduction/src/view.html',
        edit: {
          templateUrl: '{widgetsPath}/myProduction/src/edit.html'
        }
      });
  }).directive('productionView', function () {
    return {
      restirct: 'E',
      templateUrl: 'app/components/widgets/myProduction/src/productionView.html',
      bindToController: true
    };
  })
  .controller('MyProductionController', function($filter,$timeout, $scope, $log, $window, $sce, $rootScope, HttpFactory, ngDialog,
    CommonHelperService, CONSTANTS, uiGridConstants) {
    var vm = this;
    var date = new Date();
    $scope.hiddenColumnInfo="";
    var cellClassOfCalculationColumns='99calculation';
    $scope.splTab="myTeam";
    $scope.gridRefreshMsg="Click to refresh";
    $scope.startDate = new Date(date.getFullYear(), date.getMonth(), 1);
    $scope.endDate = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    // $scope.currentModal = "myCredits";
    $scope.isLoading = true;
    var isFilterChanged = false;
    var isColumnVisibilityChanged = false;
    var isColumnPinnedChanged = false;
    var isColumnSizeChanged = false;
    var isSortChanged = false;
    var isMyCredits = true;
    var isColumnPositionChanged = false;
    var isPaginationChanged = false;
    var initialLoad = true;
    var initialGridPref = false;
    var getTeamInfoInitial = true;
    var getGroupInfoInitial =true;
    $scope.preferencesChanged =false;
    var hasFilterFlag = 0;
    var scope = angular.element(document.getElementById('mainTabId')).scope();
    vm.userInfo = scope.vm.userInfo;
    var isMyCredits = true;
$scope.noLaterThan = new Date();
    $log.debug("UserID: " + vm.userInfo.userId);
    $scope.optionForRange=null;
    $scope.judge = {
      "fullName": null
    };
// $scope.userRole = $rootScope.userInfo.roleDescription; //Supervisor Paralegal/LIE Patent Attorney Business Administrator Judge  
//     if ( $scope.userRole === "Supervisor" ||$scope.userRole === "Paralegal/LIE" ||$scope.userRole === "Business Administrator")
// {
// $scope.showPayPeriod= true;
// }   
// else{
//   $scope.showPayPeriod= false;
// } 
$scope.isSPL = $rootScope.userInfo.roleDescription ? $rootScope.userInfo.roleDescription.toUpperCase().indexOf('SUPERVISOR')> -1 ? true : false : false;
if($rootScope.userInfo.roleDescription === "Business Administrator"){
  $scope.isSPL =true; 
}
    setPopoverStatus();
  // if($scope.showPayPeriod) {
 vm.selectedTab = "payPeriodTab";
//  $scope.showValueOfSelected ="PP";
 $scope.presetType="fiscalYear";
// }

//  else{
//   vm.selectedTab = "presetTab";
//   $scope.showValueOfSelected ="PRESET";
//   $scope.displayPresetType ="fiscalYear";
//   $scope.presetType="fiscalYear";
//  }
    $scope.changedPreset;

    function initiateScreen() {
      getPayPeriods();
      if ($scope.isSPL) {
        getParalegals();
      }
    }

    initiateScreen();
    $rootScope.$on('broadcastZoneWidth', function (event, param) {
      if ($scope.widgetIdentifier === param.widgetIdentifier) {
        $scope.setWidgetZone(param.zoneWidth);
      }
    });

     /* istanbul ignore next*/
     $rootScope.$on('adfCustomizeWidgetServiceCall', function () {
      if ($rootScope.widgetIdentifier === $scope.widgetIdentifier) {
        switch ($rootScope.widgetHeight) {
          case "widgetHeightSmall":
            $scope.productionGridOptions.paginationPageSize = $scope.productionGridOptions.paginationPageSizes[0];
            break;
          case "widgetHeightMedium":
            $scope.productionGridOptions.paginationPageSize = $scope.productionGridOptions.paginationPageSizes[1];
            break;
          case "widgetHeightLarge":
            $scope.productionGridOptions.paginationPageSize = $scope.productionGridOptions.paginationPageSizes[2];
            break;
          case "widgetHeightXlarge":
            $scope.productionGridOptions.paginationPageSize = $scope.productionGridOptions.paginationPageSizes[3];
            break;
          default:
            break;
        }
        $scope.paginationManual = true;
        $timeout($scope.setPaginationManually, 700);
      }
    });
    /* istanbul ignore next  */
    $scope.gridResize = function () {
      var gridHeight = document.getElementsByClassName('grid');
      for (var i = 0; i < gridHeight.length; i++) {
        if ($scope.$parent.model.widgetIdentifier === $scope.widgetIdentifier) {
          if ($scope.$parent.model.height === 'widgetHeightSmall') {
            gridHeight[i].style.height = '203px';
          } else if ($scope.$parent.model.height === 'widgetHeightMedium') {
            gridHeight[i].style.height = '405px';
          } else if ($scope.$parent.model.height === 'widgetHeightLarge') {
            gridHeight[i].style.height = '815px';
          } else if ($scope.$parent.model.height === 'widgetHeightXlarge') {
            gridHeight[i].style.height = '1515px';
          }
        }
      }
    };
    /*istanbul ignore next*/
    function setGridData(colDefs) {
      if (hasFilterFlag > 0) {

        $scope.numberOfFilters = hasFilterFlag;
        var filteredData = SearchHelperService.filterTable($scope.myData, colDefs);
        $timeout(function () {
          $scope.productionGridOptions.data = filteredData;
          $scope.savedFilteredData = filteredData;
        }, 200);

      } else {
        $scope.numberOfFilters = 0;
        $timeout(function () {
          $scope.productionGridOptions.data = $scope.myData;
        }, 200);

      }
    }
    var scope = angular.element(document.getElementById('mainTabId')).scope();
    $scope.userId = scope.vm.userInfo.userId;
    $scope.userNumber = scope.vm.userInfo.assigneeNumber;
    $scope.displayName = scope.vm.userInfo.displayName;
    $scope.userDropDownName = "No paralegal selected";
    $scope.pcUserId = $scope.userNumber;
    $scope.setWidgetZone = function (zoneWidth) {
      if (angular.isUndefined(zoneWidth)) {
        scope.vm.getWidgetZone($scope.$parent.$parent.$parent.definition);
        $scope.zoneWidth = $scope.$parent.$parent.$parent.definition.zoneWidth;
      } else {
        $scope.zoneWidth = zoneWidth;
      }
    };
    $scope.setWidgetZone();

    function getWidgetIdentifier() {
      if (angular.isDefined($scope.$parent.model)) {
        $scope.widgetIdentifier = $scope.$parent.model.widgetIdentifier;
      } else {
        /* istanbul ignore if */
        $scope.widgetIdentifier = $scope.definition.widgetIdentifier;
      }
    }
    getWidgetIdentifier();

	$scope.showSPLTab = function(tab) {
    $scope.isLoading = true;
    $scope.splTab=tab;
    $scope.totalProductionHours = 0;
    $scope.totalWorkUnits = 0;
    $scope.totalPercentageProduction = 0;
    $scope.totalPercentageProductionStr = 0;
    $scope.totalProductionHoursStr = 0;
    $scope.totalWorkUnitsStr = 0;
    $scope.productionGridOptions.columnDefs = [];
    $scope.productionGridOptions.paginationPageSize = 10;
    $scope.productionGridOptions.data = [];
    if( $scope.splTab=== "myTeam"){
$scope.myteamInfo();
    } else if( $scope.splTab=== "myGroup"){
      $scope.myGroupInfo();
          } else if($scope.splTab=== "Paralegals"){
            $scope.getProductionDataForParalegal(  $scope.judge.assigneeNumberText,$scope.judge.fullName);
          }
          $timeout(function () {
            disableSaveGridPref();
          }, 4000);
	};
    function getPayPeriod() {
      HttpFactory.getActions(CONSTANTS.URL.PAY_PERIOD_DEFAULT)
      .then(function (successResponse) {
      $scope.startDateHere= successResponse.data.startPayPeriodId;
    $scope.endDateHere = successResponse.data.endPayPeriodId;
    $scope.payPeriodStart = successResponse.data.startPayperiod;
    $scope.payPeriodEnd = successResponse.data.endPayperiod;
    $scope.fiscalYearStartPayPeriod = angular.copy($scope.payPeriodStart);
    $scope.fiscalYearEndPayPeriod = angular.copy($scope.payPeriodEnd);
    $scope.fiscalYearEndHerePayPeriod = angular.copy($scope.endDateHere);
    $scope.fiscalYearStartHerePayPeriod = angular.copy($scope.startDateHere);
    $scope.fiscalYearPayPeriod =  successResponse.data.fiscalYearPayPeriods;
    $scope.fiscalYearPayPeriodTo =  successResponse.data.fiscalYearPayPeriods;
    $scope.fromPayPeriod= $scope.payPeriodStart;
    $scope.judge2 = $scope.fromPayPeriod;
    $scope.fromChangePayperiod= $scope.payPeriodStart;
    $scope.originaPayPeriodList = angular.copy($scope.fiscalYearPayPeriod);
   buildPayPeriod($scope.fiscalYearPayPeriod);
    $scope.toPayPeriod = $scope.payPeriodEnd ;
    $scope.judge3 = $scope.toPayPeriod;
    $timeout($scope.setPaginationManually, 700);
      });
    }
    getPayPeriod();

    $scope.paralegalList = [];
    $scope.paralegalList.push("temp1");
    $scope.paralegalList.push("temp2");
    $scope.showParalegalList = function () {
      if (!$scope.paralegalListVisible) {
        $scope.paralegalListVisible = !$scope.paralegalListVisible;
        $scope.popoverVisible = false;
      }
    };

    $scope.lastRefresh = new Date();

    /* Build the grid for myProduction widget */
    function buildMyProductionGrid() {
        $scope.productionGridOptions = CommonHelperService.setCommonGridOptions();
      $scope.productionGridOptions.enableFiltering = false;
      $scope.productionGridOptions.showGridFooter = true;
      $scope.productionGridOptions.showColumnFooter = true;
      $scope.productionGridOptions.enableVerticalScrollbar =uiGridConstants.scrollbars.WHEN_NEEDED;
    $scope.productionGridOptions.multiSelect = true;
    $scope.productionGridOptions.enableSelectAll = true;
    $scope.productionGridOptions.exporterCsvFilename = 'ProductionCreditReport' + CommonHelperService.getCurrentTime() + '.csv';
      /* istanbul ignore next */
      $scope.productionGridOptions.gridMenuCustomItems = [{
        title: 'Save grid preferences',
        action: function () {
          $scope.saveGridPreferences();
        },
        order: 100
      },
      {
        title: 'Export full docket as csv',
        action: function () {
          $scope.exportData();
        },
        order: 210
      }

    ];
    $scope.productionGridOptions.showColumnFooter = true;
    $scope.myCreditsSortableOptions = {
      containment: '#myProductionColums',
      scroll: true,
      axis: 'y',
      cursor: 'move',
      scrollSpeed: 2,
      scrollSensitivity: 160,
      update: function () {
        $rootScope.myCreditsPaColumnsChanged = true;
      }
    };
    
    
     /*istanbul ignore next*/
     $scope.productionGridOptions.onRegisterApi = function (gridApi) {
      $scope.gridApi = gridApi;
      $scope.gridApi.core.on.filterChanged($scope, function () {
        isFilterChanged = true;
        var grid = this.grid;
        $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
        //If there are no filters and no search text, then set the grid data to original data */
        if ($scope.numberOfFilters === 0 && (angular.isUndefined($scope.$$childTail.$$prevSibling.searchText) ||
            $scope.$$childTail.$$prevSibling.searchText === "" ||
            $scope.$$childTail.$$prevSibling.searchText === null)) {
          $scope.productionGridOptions.data = $scope.originalMyCreditData;
          /* If search text is defined and there are filters, then set grid data to filtered data before searching for searched text */
        } else if (angular.isDefined($scope.$$childTail.$$prevSibling.searchText) && $scope.numberOfFilters > 0) {
          $scope.productionGridOptions.data = SearchHelperService.filterGrid(grid, $scope.originalMyCreditData);
          $scope.$parent.$$childHead.simpleSearch($scope.$$childTail.$$prevSibling.searchText);
          /* If search text is defined and there are no filters, then set the grid data to original data before searching for searched text */
        } else if (angular.isDefined($scope.$$childTail.$$prevSibling.searchText) && $scope.numberOfFilters === 0) {
          $scope.productionGridOptions.data = $scope.originalMyCreditData;
          $scope.$parent.$$childHead.simpleSearch($scope.$$childTail.$$prevSibling.searchText);
        } else {
          /* If there are filters and no search text, then set grid data to filtered data */
          $scope.productionGridOptions.data = SearchHelperService.filterGrid(grid, $scope.myData);
        }

        checkForUnsavedChanges();
      });
      $scope.gridApi.core.on.columnVisibilityChanged($scope, function () {
        isColumnVisibilityChanged = true;
        updateColumnDefs($scope.productionGridOptions.columnDefs);
        calculateHiddenColumns($scope.productionGridOptions.columnDefs);
        checkForUnsavedChanges();
      });
      $scope.gridApi.colResizable.on.columnSizeChanged($scope, function () {
        isColumnSizeChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.pinning.on.columnPinned($scope, function () {
        isColumnPinnedChanged = true;
        updateColumnDefs($scope.productionGridOptions.columnDefs);
        checkForUnsavedChanges();
      });

      $scope.gridApi.core.on.sortChanged($scope, function () {
        isSortChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.colMovable.on.columnPositionChanged($scope, function () {
        isColumnPositionChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.pagination.on.paginationChanged($scope, function () {
        isPaginationChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.core.on.renderingComplete($scope, function () {
        $scope.gridResize();
        checkForUnsavedChanges();
      });

    };
    }    
    
    function setPopoverStatus() {
        $scope.payPeriodTab = true;
      $scope.myProductionFromDate = {};
    }

    $scope.moveItem = function (origin, destination) {
      var temp = $scope.selectedCols[destination];
      $scope.selectedCols[destination] = $scope.selectedCols[origin];
      $scope.selectedCols[origin] = temp;
      $rootScope.myCreditsColumnsChanged = true;
    };

    $scope.listItemUp = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex - 1);
    };

    $scope.listItemDown = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex + 1);
    };

    $scope.moveSourcetoDestination = function () {
      angular.forEach($scope.clickedColumn, function (column) {
        column.visible = true;
        $scope.selectedCols.push($scope.availableCols[$scope.availableCols.indexOf(column)]);
        $scope.availableCols.splice($scope.availableCols.indexOf(column), 1);
      });
      $scope.clickedColumn = [];
      $rootScope.myCreditsColumnsChanged = true;
    };

    $scope.moveSourcetoDestinationCancel = function (index) {
      $scope.selectedCols[index].visible = false;
      $scope.availableCols.push($scope.selectedCols[index]);
      $scope.selectedCols.splice(index, 1);
      $rootScope.myCreditsColumnsChanged = true;
    };

    $scope.toggleSelectAll = function () {
      angular.forEach($scope.availableCols, function (column) {
        column.visible = true;
        $scope.selectedCols.push(column);
      });
      $scope.availableCols = [];
      $rootScope.myCreditsColumnsChanged = true;
    };

    $scope.removeAll = function () {
      var tempArray = [];
      $rootScope.myCreditsColumnsChanged = true;
      angular.forEach($scope.selectedCols, function (column) {
        if (!column.mandatory) {
          column.visible = false;
          $scope.availableCols.push(column);
        } else {
          tempArray.push(column);
        }
      });
      $scope.selectedCols = tempArray;
    };

    
    buildMyProductionGrid();

    $scope.focusOut = function () {
      $scope.focusMoved = true;
      if ($scope.pAListVisible != false) {
        $scope.pAListVisible = false;
      }
    };
   $scope.checkandClose = function () {
     if ($scope.judge.fullName == ""){
      $scope.pAListVisible = true;
      $scope.showList = false;
     }
      else if (( $scope.judge.fullName !== "Select paralegal..." ||  $scope.judge.fullName != undefined) && (!$scope.showList) && $scope.judge.fullName != null) {
        $scope.pAListVisible = false;
        $scope.showList = true;
        $scope.focusOut();
      } else if ( $scope.judge.fullName == null && ! $scope.showList) {
        $scope.pAListVisible = true;
        $scope.showList = false;
      } else if ( $scope.showList &&  $scope.judge.fullName != null && ! $scope.focusMoved) {
        $scope.pAListVisible = true;
      } else if ( $scope.focusMoved) {
        $scope.pAListVisible = false;
        $scope.focusMoved = false;
      }
    }

    $scope.showPAList = function () {
      if (! $scope.pAListVisible) {
        $scope.pAListVisible = ! $scope.pAListVisible;
        $scope.checkandClose();
      }
    };

    $scope.setSelectedParalegal = function (data) {
      if (data.assigneeFullNameText !== "Select paralegal...") {
        initialGridPref = true;
        $scope.preferencesChanged = true;
        $scope.paNameNumber = data.assigneeNumberText + "|" +data.assigneeFullNameText; 
        $scope.paSelected =  $scope.paNameNumber;
       $scope.getProductionDataForParalegal(data.assigneeNumberText, data.assigneeFullNameText);
        $scope.selectedJudge = data;
        $scope.judge.fullName = data.assigneeFullNameText;
        $scope.judge.assigneeNumberText = data.assigneeNumberText;
        initialLoad = false;
        data.fullName = data.assigneeFullNameText;
        $scope.searchForPA(data);
        $scope.pAListVisible = false;
        $scope.showList = false;
      } else {
        initialLoad = false;
      }
    };

    function buildPayPeriod(list) {
      $scope.judgeList2 = [];
      $scope.judgeList3 = [];
      angular.forEach(list, function(item) {
        $scope.judgeList2.push(angular.copy(item));
        $scope.judgeList3.push(angular.copy(item));
      });
      $scope.originalPayPeriod = angular.copy($scope.judgeList2);
      $scope.judgeListVisible2 = false;
      $scope.judgeListVisible3 = false;
    }

    /*istanbul ignore next*/
    $scope.getMyCreditsColumns = function () {
      if (isMyCredits || $scope.definition.type === 'myProduction') {
        isMyCredits = false;
        HttpFactory.getActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS + $scope.widgetIdentifier)
          .then(function (successResponse) {
            $scope.updatedMyCreditsColumnList = successResponse.data.selectedColumns;
            $scope.productionGridOptions.paginationPageSize = successResponse.data.paginationSize !== undefined ? successResponse.data.paginationSize : 10;
            $scope.selectedCols = [];
            $scope.availableCols = [];
            angular.forEach($scope.updatedMyCreditsColumnList, function (thisColumn) {
              if (thisColumn.visible) {
                $scope.selectedCols.push(thisColumn);
              } else {
                $scope.availableCols.push(thisColumn);
              }
            });
            $scope.originShowHide = angular.copy($scope.updatedMyCreditsColumnList);
            $scope.loadedColumns = true;
            for (var i = 0; i < $scope.updatedMyCreditsColumnList.length; i++) {
              if (!$scope.updatedMyCreditsColumnList[i].visible) {
                $scope.selectUnselect = false;
                $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
              }
            }
            $timeout($scope.setPaginationManually, 700);
          }, function () {
            // Empty response is ok
          });
      }
    };

    $scope.saveGridPreferences = function () {
      if ($scope.gridApi) {
        $scope.gridState = setGridState($scope.gridApi.saveState.save());
      } else if ($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi) {
        $scope.gridState = setGridState($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi.saveState.save());
      }
      $scope.updateColumns();
      $timeout(function () {
        $scope.preferencesChanged =false;
      }, 500);
      $scope.originalPlName = $scope.judge.fullName;
      $scope.originalPlNumber= $scope.judge.assigneeNumberText;
   $scope.originalPlType =  $scope.rangeType;
     $scope.orignalPlRangeValue= $scope.rangeValue;
    $scope.originalPreset= $scope.displayPresetType;
    $scope.orignalShowValueOfSelected=  $scope.showValueOfSelected;
    };

    $scope.paginationManual = false;


    $scope.setPaginationManually = function () {
      $scope.paginationManual = false;
    };

    function setGridState(gridApiSaveState) {
      return CommonHelperService.setGridWidthMap(gridApiSaveState);
    }

    /* istanbul ignore next  */
    function checkForUnsavedChanges() {
      if (!initialLoad) {
        if (isFilterChanged || isColumnVisibilityChanged || isColumnSizeChanged || isSortChanged || isColumnPositionChanged || isPaginationChanged || isColumnPinnedChanged) {
          $scope.preferencesChanged = true;
        } else {
          $scope.preferencesChanged = false;
        }
      }
    }

    $scope.enterOnActions = function ($event, action) {
      if ($event.keyCode === 13) {
        $scope.myProductionActions(action);
      }
    }
    $scope.myProductionActions = function (action) {
      if (action === 'enterOtherCredits') {
        ngDialog.openConfirm({
          template: 'app/components/widgets/myCredits/enterOtherCreditsModal.html',
          controller: 'EnterOtherCreditsController',
          controllerAs: 'vm',
          width: '95%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            userInfo: function () {
              return vm.userInfo;
            }
          }
        }).then(function () {
          //refresh credits
        }, function () {
          //Intentional blank.  My implement later
        });
      } else if (action === 'editCredits') {
        ngDialog.openConfirm({
          template: 'app/components/widgets/myCredits/editCreditsModal.html',
          controller: 'EditCreditsController',
          controllerAs: 'vm',
          width: '99%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false
        }).then(function () {
          //refresh credits
        }, function () {
          //Intentional blank.  My implement later
        });
      } else if (action === 'requestAPC') {
        var data ={
          userInfo:vm.userInfo,
          widgetIdentifier: $scope.widgetIdentifier
        };
        ngDialog.openConfirm({
          template: 'app/components/widgets/myProduction/src/requestPLADU.html',
          controller: 'RequestPLADUController',
          controllerAs: 'vm',
          width: '70%',
          showClose: false,
          data:data,
          closeByEscape: false,
          closeByDocument: false
        }).then(function () { //refresh credits
        }, function () {//Intentional blank.  My implement later
        });
        
      }
    };

    /* istanbul ignore next: toaster errors*/
    $scope.updateColumns = function () {
      $scope.ppRangeSelected.columnLabel = $scope.rangeType + "|" +$scope.rangeValue;
      $scope.isLoading = true;
      var mycreditScopeList = angular.element(document.getElementById('myProductionColums')).scope();
      var columnsSelected = [];
      var fromModal = false;
      if (angular.isDefined(mycreditScopeList)) {
        columnsSelected = angular.copy(mycreditScopeList.selectedCols);
        angular.forEach(mycreditScopeList.availableCols, function (available) {
          columnsSelected.push(available);
        });

        fromModal = true;
      } else {
        columnsSelected = $scope.columnDetails;
      }

      var updatedColumns = CommonHelperService.setColumnsToUpdate(columnsSelected, fromModal, $scope.gridState, $scope.widgetIdentifier);

      if (angular.isDefined(mycreditScopeList)) {
        mycreditScopeList.originShowHide = angular.copy(updatedColumns.selectedColumns);
      }
      if($scope.isSPL){
      $scope.paAssigneeName.columnLabel = $scope.paSelected;}
      updatedColumns.selectedColumns.push( $scope.paAssigneeName);
      updatedColumns.selectedColumns.push($scope.ppRangeSelected);

      HttpFactory.putActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS, updatedColumns)
        .then(function (successResponse) {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.gridSave, "success");
            $scope.preferencesChanged = false;

            if (fromModal) {
              var newData = successResponse.config.data.selectedColumns;
              $scope.updatedColumnList = newData;

              var setColumnsResponse = CommonHelperService.setColumnDefinitions($scope.updatedColumnList);
              $scope.updatedMyCreditsColumnList = setColumnsResponse.colDefs;
              hasFilterFlag = setColumnsResponse.filterCount;

              updateColumnDefs(setColumnsResponse.colDefs);

              $scope.productionGridOptions.data = CommonHelperService.setGridData(hasFilterFlag, newData, setColumnsResponse.colDefs);

              $scope.numberOfFilters = hasFilterFlag;
              var allGrids = document.getElementsByClassName('ui-grid');
              for (var j = 0; j < allGrids.length; j++) {
                if (angular.element(allGrids[j]).scope().widgetIdentifier === $scope.widgetIdentifier) {
                  updateColumnDefs(setColumnsResponse.colDefs);

                  angular.element(allGrids[j]).scope().productionGridOptions.columnDefs = $scope.productionGridOptions.columnDefs;
                  if ($scope.numberOfFilters > 0) {
                    var filteredData = SearchHelperService.filterTable($scope.myData, setColumnsResponse.colDefs);
                    $scope.productionGridOptions.data = filteredData;
                  } else {

                    $scope.productionGridOptions.data = successResponse.config.data.selectedColumns;
                  }
                  break;
                }
              }
              $rootScope.myCreditsPaColumnsChanged = false;
            }

            $scope.noRecordsFound = true;
          },
          function () {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.gridSaveFail, "error");

          }).finally(function () {
          $scope.isLoading = false;
        });
    };

    /*istanbul ignore next*/
    function updateColumnDefs(columndefs) {
      var selected = [];
      var unselected = [];
      var selectedCount = 0;

      angular.forEach(columndefs, function (col) {
        if (col.visible) {
          selected.push(col);
          selectedCount = selectedCount + 1;
        } else {
          unselected.push(col);
        }
      });
      columndefs = [];
      angular.forEach(selected, function (col) {
        columndefs.push(col);
      });
      unselected.sort(CommonHelperService.alphabetizeAvailableColumns);
      angular.forEach(unselected, function (col) {
        columndefs.push(col);

      });
      $scope.productionGridOptions.columnDefs = columndefs;
      calculateHiddenColumns( $scope.productionGridOptions.columnDefs);
    }

    $scope.displayAllColumns = function() {
      angular.forEach($scope.gridApi.grid.columns , function(item) {
        if (item.cellClass && item.cellClass.indexOf(cellClassOfCalculationColumns)>=0) {
          item.showColumn();
        }
      });

      $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
      $scope.numberOfTotalCaluatedColumns=0;
      $scope.numberOfHiddenColumns=0;
 
    }
    function calculateHiddenColumns(columndefs) {
      $scope.numberOfTotalCaluatedColumns=0;
      $scope.numberOfHiddenColumns=0;
      angular.forEach(columndefs, function (col) {
        if (col.cellClass && col.cellClass.indexOf(cellClassOfCalculationColumns)>=0) {
          $scope.numberOfTotalCaluatedColumns++;
        }
        if (!col.visible && col.cellClass && col.cellClass.indexOf(cellClassOfCalculationColumns)>=0) {
          $scope.numberOfHiddenColumns++;
        }
      });
      var shownColumns = $scope.numberOfTotalCaluatedColumns - $scope.numberOfHiddenColumns;
      if ($scope.numberOfHiddenColumns>0) {
        $scope.hiddenColumnInfo = "You are displaying " + shownColumns + " out of " + $scope.numberOfTotalCaluatedColumns + " columns.  Click to show all columns."; 
      }
    }

    function getValueOfPreset(rangeValue){
      $scope.showValueOfSelected ="PRESET";
      if (rangeValue === "1") {
        $scope.displayPresetType = "currentMonth";
        var date = new Date(), y = date.getFullYear(), m = date.getMonth();
        $scope.firstDayCurrent = new Date(y, m, 1);
       $scope.lastDayCurrent = new Date(y, m + 1, 0); 
      }
      else if(rangeValue === "2"){
        $scope.displayPresetType = "previousMonth";
        var now = new Date();
$scope.prevMonthLastDate = new Date(now.getFullYear(), now.getMonth(), 0);
$scope.prevMonthFirstDate = new Date(now.getFullYear() - (now.getMonth() > 0 ? 0 : 1), (now.getMonth() - 1 + 12) % 12, 1);
      }else {
        $scope.displayPresetType = "fiscalYear";
      }
      $scope.originalPreset = $scope.displayPresetType;
    }

function getPAName(updatedColumnList){
  angular.forEach(updatedColumnList, function (current) {
    if (current.name === "assigneeForProductionCredit") {
      if(current.columnLabel !==  "null") {
        $scope.paSelected = current.columnLabel;
        var res = $scope.paSelected.split("|");
        $scope.paNumber = res[0];
        $scope.paFullName = res[1];
        $scope.judge.fullName =  $scope.paFullName;
        $scope.judge.assigneeNumberText =$scope.paNumber;
        $scope.originalPlName =  $scope.paFullName;
        $scope.originalPlNumber =$scope.paNumber;
      } else{
        $scope.paSelected = "null";
      }
      $scope.paAssigneeName = current;
    } 
    if (current.name ==="rangeForProductionCredit"){
      if(current.columnLabel !==  "null") {
        $scope.rangeSelected = current.columnLabel;
        var res = $scope.rangeSelected.split("|");
        $scope.rangeType = res[0];
        $scope.rangeValue = res[1];
        $scope.originalPlType = $scope.rangeType;
        $scope.orignalPlRangeValue =  $scope.rangeValue;
        if($scope.rangeType === "PP"){
          $scope.showValueOfSelected = $scope.rangeType;
          var rangleSelected = $scope.rangeValue.split("-");
          $scope.rangeValueStart = rangleSelected[0];
          $scope.rangeValueEnd = rangleSelected[1];
          $scope.startDateHere = $scope.rangeValueStart;
          $scope.endDateHere= $scope.rangeValueEnd;
var stringStartDt = $scope.startDateHere.toString();
          var valueWithDashStrt = stringStartDt.substring(0,4) + "-" +stringStartDt.substring(4);
          var stringEndDt = $scope.endDateHere.toString();
          var valueWithDashEnd = stringEndDt.substring(0,4) + "-" +stringEndDt.substring(4);
          $scope.payPeriodStart = valueWithDashStrt;
          $scope.payPeriodEnd =valueWithDashEnd;
        } 
        else if($scope.rangeType === "DT"){
          $scope.showValueOfSelected = $scope.rangeType;
          var rangleSelected = $scope.rangeValue.split("--");
          $scope.rangeValueStart = rangleSelected[0];
          $scope.rangeValueEnd = rangleSelected[1];
          $scope.startDtEpoch = $scope.rangeValueStart;
         $scope.endDtEpoch =$scope.rangeValueEnd;
         $scope.displayDtRangeStart = angular.copy($scope.rangeValueStart);
        //  $scope.displayDtRangeStart = $filter('date')($scope.rangeValueStart,'MMM d, yyyy');
         $scope.displayDtRangeEnd = angular.copy($scope.rangeValueEnd);
        }
        else if($scope.rangeType === "PRESET"){
   getValueOfPreset($scope.rangeValue);
        }
      } else{
        $scope.showValueOfSelected = "PP";
        $scope.rangeSelected = "null";

      }
      $scope.ppRangeSelected = current;
      if(!$scope.isSPL){
        $scope.paAssigneeName = current;
        $scope.judge.assigneeNumberText= vm.userInfo.assigneeNumber;
        $scope.judge.fullName = vm.userInfo.displayName;
      }
    }
    
    $scope.orignalShowValueOfSelected =$scope.showValueOfSelected;
  });
  return  $scope.paAssigneeName;
}
    function getProductionData() {
      if($rootScope.userInfo.roleDescription === "Supervisor" || $rootScope.userInfo.roleDescription === "Business Administrator"){
        var url = "/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier;
      } else { 
      var url = "/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber;
       }
        HttpFactory.getActions(url).then(function (successResponse) {
        $scope.updatedColumnList = successResponse.data.columnDetails;
        $scope.columnDetails = successResponse.data.columnDetails;
        $scope.paralegalNameDefault = getPAName ($scope.updatedColumnList);
        var colDefs = CommonHelperService.setColumnDefinitions($scope.updatedColumnList);
      if (!$scope.initalCall) 
      {
        $scope.isLoading = false;
        $scope.totalProductionHours = successResponse.data.hours;
        $scope.totalWorkUnits = successResponse.data.workUnits;
        $scope.totalPercentageProduction = successResponse.data.totalProdPercentage;
        $scope.totalPercentageProductionStr = successResponse.data.strTotalProdPercentage;
        $scope.totalProductionHoursStr = successResponse.data.strHours;
        $scope.totalWorkUnitsStr = successResponse.data.strWorkUnits;
        $scope.productionGridOptions.columnDefs = colDefs.colDefs;
        $scope.productionGridOptions.paginationPageSize = successResponse.data.paginationSize !== undefined ? successResponse.data.paginationSize : 10;
        $scope.lastRefresh = new Date();
        initialLoad = false;
        $scope.productionGridOptions.data = successResponse.data.productionAssignments;
      }
        if($scope.paralegalNameDefault.columnLabel !== "null" || $scope.judge.fullName !== null){
$scope.getProductionDataForParalegal(  $scope.judge.assigneeNumberText,$scope.judge.fullName);
$scope.preferencesChanged =false;
        }
        else if($scope.initalCall){
          $scope.getGroupNum();
        }
        $timeout($scope.setPaginationManually, 700);
      }, function (failureResponse) {
        $scope.failureMessage = failureResponse.data.message;
        $scope.failureResponse = true;
        $scope.searchTotalLength = 0;
        $scope.isLoading = false;
        initialLoad = false;
      });
    }


    
    $scope.getFooter = function(value) {
      if (value) {
        return value.toFixed(2);
      }
      value = 0;
      return value.toFixed(2);
    }

  
    $scope.getProductionDataForParalegal = function(paralegalNumber, paralegalName) {
      $scope.userDropDownName = paralegalName;
$scope.paralegalNumber = paralegalNumber;
if ($scope.showValueOfSelected ==="PP") {
  $scope.rangeType = $scope.showValueOfSelected;
  $scope.rangeValue =$scope.startDateHere+"-"+$scope.endDateHere;
}
      var url = "/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + paralegalNumber+"&startPayPeriod="+$scope.startDateHere+"&endPayPeriod="+$scope.endDateHere;
     if ($scope.showValueOfSelected ==="DT"){
      $scope.rangeType = $scope.showValueOfSelected;
      $scope.rangeValue =$scope.startDtEpoch +"--"+$scope.endDtEpoch;
       url = "/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + paralegalNumber+ "&startDate="+ $scope.startDtEpoch+ "&endDate="+ $scope.endDtEpoch;
     } else if ($scope.showValueOfSelected ==="PRESET" && $scope.displayPresetType ==="currentMonth"){
      $scope.rangeType = $scope.showValueOfSelected;
      $scope.rangeValue ="1";
      url = "/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + paralegalNumber+"&timeFrame=1";     
    }else if ($scope.showValueOfSelected ==="PRESET" && $scope.displayPresetType ==="previousMonth"){
      $scope.rangeType = $scope.showValueOfSelected;
      $scope.rangeValue ="2";
      url = "/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + paralegalNumber+"&timeFrame=2";
    }else if ($scope.showValueOfSelected ==="PRESET" && $scope.displayPresetType ==="fiscalYear"){
      $scope.rangeType = $scope.showValueOfSelected;
      $scope.rangeValue =$scope.fiscalYearStartHerePayPeriod+"-"+$scope.fiscalYearEndHerePayPeriod; ;
      url ="/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + paralegalNumber+"&startPayPeriod="+$scope.fiscalYearStartHerePayPeriod+"&endPayPeriod="+$scope.fiscalYearEndHerePayPeriod; 
    }
      HttpFactory.getActions(url).then(function (successResponse) {
        if (initialGridPref){
        $scope.preferencesChanged =true;
        } else {
          $scope.preferencesChanged =false;
          initialGridPref = true;
        }

        $scope.updatedColumnList = successResponse.data.columnDetails;
        var colDefs = CommonHelperService.setColumnDefinitions($scope.updatedColumnList);
        $scope.productionGridOptions.columnDefs = colDefs.colDefs;
        if (!$scope.initalCall) {
        $scope.productionGridOptions.data = successResponse.data.productionAssignments;
        $scope.totalProductionHours = successResponse.data.hours;
        $scope.totalWorkUnits = successResponse.data.workUnits;
        $scope.totalPercentageProduction = successResponse.data.totalProdPercentage;
        $scope.totalPercentageProductionStr = successResponse.data.strTotalProdPercentage;
        $scope.totalProductionHoursStr = successResponse.data.strHours;
        $scope.totalWorkUnitsStr = successResponse.data.strWorkUnits;
        $scope.productionGridOptions.paginationPageSize = successResponse.data.paginationSize !== undefined ? successResponse.data.paginationSize : 10;
        $scope.isLoading = false;
        // $scope.updatedColumnList = successResponse.data.columnDetails;
        // var colDefs = CommonHelperService.setColumnDefinitions($scope.updatedColumnList);
        // $scope.productionGridOptions.columnDefs = colDefs.colDefs;
        $timeout($scope.setPaginationManually, 700);
        } else {
          $scope.isLoading = true;
          $scope.getGroupNum();
        }
      }, function (failureResponse) {
        $scope.failureMessage = failureResponse.data.message;
        $scope.failureResponse = true;
        $scope.searchTotalLength = 0;
        $scope.isLoading = false;
        initialLoad = false;
      });
    }

    function disableSaveGridPref(){
      $timeout(function () {
        $scope.preferencesChanged = false;
      }, 1000);  
    }

    function enableSaveGridPref(){
      $timeout(function () {
        $scope.preferencesChanged = true;
      }, 800);  
    }
    $scope.refreshGrid = function () {
      $scope.isLoading =true;
      vm.refreshProcess = true;
      $scope.preferencesChanged =false;
      $scope.judge.fullName =  $scope.originalPlName;
      $scope.judge.assigneeNumberText = $scope.originalPlNumber;
      $scope.rangeType= $scope.originalPlType; // = $scope.rangeType;
      $scope.rangeValue= $scope.orignalPlRangeValue;// =  $scope.rangeValue;
      $scope.displayPresetType =$scope.originalPreset;
      $scope.showValueOfSelected=$scope.orignalShowValueOfSelected;
      if ( $scope.originalPlName == undefined){
        $scope.userDropDownName =  "No paralegal selected";
        $scope.judge.fullName = "";
      }
      if(!$scope.isSPL){
        $scope.originalPlNumber= vm.userInfo.assigneeNumber;
        $scope.originalPlName = vm.userInfo.displayName;
      }
      if($scope.splTab === "myTeam" && $scope.isSPL) {
$scope.myteamInfo();
      } else if ($scope.splTab === "myGroup" && $scope.isSPL) {
        $scope.myGroupInfo();
      }
      else if($scope.userDropDownName === "No paralegal selected" && $scope.isSPL){
        getProductionData();
        } else {
        $scope.getProductionDataForParalegal($scope.originalPlNumber, $scope.originalPlName);
        }
      disableSaveGridPref();
     var valueForRefresh = {
        "fullName" : $scope.judge.fullName,
        "assigneeNumberText" :  $scope.judge.assigneeNumberText
      }
      $scope.searchForPA(valueForRefresh);

      $scope.pAListVisible = false;
      $scope.showList = false;
    };

    $scope.viewAssignments = function (row, fieldName) {
      if (row.entity.payPeriodId != undefined) {
        $scope.payperiodB = row.entity.payPeriodId;
        $scope.payPeridE = row.entity.payPeriodId;
        $scope.sendId = $scope.paralegalNumber;
      } else {
        var rangSelected = row.entity.payPeriod.split("-");
        $scope.payperiodB = rangSelected[0];
        $scope.payPeridE = rangSelected[1];
        $scope.sendId = row.entity.awardeeApplicationUserId;
      }
      var theData = {
        startPayPeriod: $scope.payperiodB,
        endPayPeriod: $scope.payPeridE,
        applicationUserId:$scope.sendId || $scope.pcUserId,
        assignmentTypeCodes:fieldName
      };

      ngDialog.openConfirm({
        template: 'app/components/widgets/myProduction/src/detailAssignmentsModal.html',
        controller: 'DetailAssignmentsController',
        controllerAs: 'vm',
        data: theData,
        width: '70%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false
      }).then(function () {
        //refresh credits
      }, function () {
        //Intentional blank.  My implement later
      });     
    };

    function getPayPeriods() {
      HttpFactory.getActions("/prodn-goal-adjust/all-payperiods")
        .then(function (successResponse) {
          $scope.payPeriods = successResponse.data;
        });
    }

    $scope.getData = function (data) {
      $scope.userDropDownName = data.assigneeFullNameText;
      if (data.assigneeNumberText) {
        getSPLteamMembers(data.assigneeNumberText);
      }
    };

    function getSPLteamMembers(userId) {
      HttpFactory.getActions(CONSTANTS.URL.ASSIGNEEUSERS + userId)
        .then(function () {
            $scope.displayName = scope.vm.userInfo.displayName;
            $scope.userDropDownName = $scope.displayName;
          },
          function () {
            // Empty response is  ok
          });
    }

   $scope.searchForPA = function (input) {
      var tempList = [];
      if (angular.isDefined(input) && input.fullName.trim() !== "") {
        angular.forEach($scope.originalJudgeList, function (currentJudge) {
          if (currentJudge.assigneeFullNameText.toLowerCase().includes(input.fullName.toLowerCase())) {
            tempList.push(currentJudge);
          }
        });
       $scope.judgeList = angular.copy(tempList);
       $scope.pAListVisible = true;
       $scope.showList = false;
      } else {
       $scope.judgeList = angular.copy($scope.originalJudgeList);
      $scope.preferencesChanged =true;
      $scope.productionGridOptions.data = [];
      $scope.totalProductionHours = 0;
      $scope.totalWorkUnits = 0;
      $scope.totalPercentageProduction =0;
      $scope.totalPercentageProductionStr = "0";
      $scope.totalProductionHoursStr = "0";
      $scope.totalWorkUnitsStr = "0";
      $scope.isLoading = false;
     $scope.paSelected = "null";
      var colDefs = CommonHelperService.setColumnDefinitions($scope.updatedColumnList);
      $scope.productionGridOptions.columnDefs = colDefs.colDefs;
       $scope.pAListVisible = false;
       $scope.showList = false;
      }

      if(input.fullName == ""){
$scope.userDropDownName = "No paralegal selected";
      }
    };

    function getParalegals () {
      HttpFactory.getActions(CONSTANTS.URL.ASSIGNEDTO + "userRoleName=Paralegal/LIE")
      .then(function (successResponse) {
        $scope.myParalegals = successResponse.data;
        $scope.judgeList = $scope.myParalegals;
        $scope.originalJudgeList = angular.copy($scope.judgeList);
        $scope.numOfParalegals = $scope.originalJudgeList.length;
      },
      function () {//intentional
      });
    };


    $scope.areAllSelected = function () {
      var columnList = angular.element(document.getElementById('myProduction')).scope();
      for (var i = 0; i < columnList.updatedMyCreditsColumnList.length; i++) {
        if (!columnList.updatedMyCreditsColumnList[i].visible) {
          $scope.selectUnselect = false;
          break;
        } else {
          $scope.selectUnselect = true;
        }
        $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
      }
    };

    function getRole() {
      if ($rootScope.userInfo.roleDescription) {
        if ($rootScope.userInfo.roleDescription.toUpperCase().indexOf('JUDGE') > -1) {
          $scope.isPL = false;
          $scope.isJudge = true;
          return "_JUDGE";
        } else if ($rootScope.userInfo.roleDescription.toUpperCase().indexOf('ATTORNEY') > -1) {
          $scope.isPL = false;
          return "_PA";
        } else if ($rootScope.userInfo.roleDescription.toUpperCase().indexOf('PARALEGAL') > -1) {
          $scope.isPL = true;
          return "_PL";
        } else {
          return "";
        }
      }
    }

    /*istanbul ignore next*/
    vm.getTimeFramesOptions = function () {
      var notInTimeFrames = ['ptabReadOnlyUser', 'ptabDueDateNonEditableUser', 'allowedResourceObjectList', 'ptabDefaultRefreshTime'];
      HttpFactory.getActions(CONSTANTS.URL.MY_CREDITS_TIMEFRAME + "?role=" + getRole())
        .then(function (successResponse) {
          $scope.timeframesResponse = successResponse.data;
          $scope.timeframes = [];
          angular.forEach($scope.timeframesResponse, function (value, key) {
            if (notInTimeFrames.indexOf(key) == -1) {
              $scope.timeframes.push({
                key: key,
                value: value
              });
            }
          });
          $scope.timeframes.sort(function (a, b) {
            return a.value - b.value;
          });
        }, function () {
          // Empty response is ok
        });
    };

    /* istanbul ignore if */
    if (angular.isDefined($scope.$parent.model)) {
      $scope.mycreditsDataUrlList = $scope.$parent.model.dataUrlText;
      $scope.widgetIdentifier = $scope.$parent.model.widgetIdentifier;
      vm.getTimeFramesOptions();
      // vm.getPaCredits($scope.widgetIdentifier);
    } else {
      /* istanbul ignore if */
      if ($scope.definition.type === "myProduction") {
        if (angular.isDefined($scope.$parent.model)) {
          $scope.mycreditsDataUrlList = $scope.$parent.model.dataUrlText;
          vm.getTimeFramesOptions();
          $scope.widgetIdentifier = $scope.definition.widgetIdentifier;
        } else {
          $scope.mycreditsDataUrlList = $scope.definition.dataUrlText;
          vm.getTimeFramesOptions();
          $scope.widgetIdentifier = $scope.definition.widgetIdentifier;
        }
      }
    }
   
    $scope.optionsWithoutStart = {
      connect: true,
      range: {
        min: 2017,
        max: 2020,
      }
    };
    
    $scope.sliderPositions = [2019, 2020];

    $scope.updateThis = function(value){
      $scope.changedPreset = value;
      $scope.presetType =value;
    }

    $scope.setSelectedTab=function(selectedTab){ 
   vm.selectedTab= selectedTab;
    $scope.showError = false;
    $scope.dateNotSelected =false;
    if(vm.selectedTab === "dateRangeTab"){
      $scope.dateNotSelected =true;
      $scope.presetType = "fiscalYear"
    } else {
      $scope.dateNotSelected =false;
      $scope.dateErrowMessage=false;
      $scope.changedStartDate= null;
     $scope.changedEndDate = null;
     $scope.dateFutrueErrowMessage = false;
    }
  }

  $scope.buttonClick = function(value){
    console.log("value = " + value);
  }

  $scope.setPayperiod = function(type, value) {
    if (type==='from') {
      $scope.fromChangePayperiod=value;
    } else {
      $scope.toChangePayperiod = value;
    }
    if( $scope.fromChangePayperiod == undefined){
      $scope.fromChangePayperiod = $scope.fromPayPeriod;
    }
    if( $scope.toChangePayperiod == undefined){
      $scope.toChangePayperiod = $scope.toPayPeriod;
    }
var z = $scope.fromChangePayperiod <=  $scope.toChangePayperiod;
if (z == false){
  $scope.showError = true;
} else {
  $scope.showError = false;
}
}

  $scope.setFromDate = function(value) {
    $scope.changedStartDate = value;
    if  ($scope.changedStartDate && $scope.changedEndDate) { 
      var z = $scope.changedStartDate <=  $scope.changedEndDate;
      if (z == false){
        $scope.dateErrowMessage=true;
        $scope.dateNotSelected =true;
      } else{
        $scope.dateErrowMessage=false;
        $scope.dateNotSelected =false;
      }
    }else{
      $scope.dateNotSelected =true;
    }
    if ( ($scope.changedStartDate > $scope.noLaterThan) || ( $scope.changedEndDate > $scope.noLaterThan)){
      $scope.dateFutrueErrowMessage = true;
    } else {
      $scope.dateFutrueErrowMessage = false;
    }
  }

  $scope.setToDate = function(value) {
    $scope.changedEndDate = value;
    if  ($scope.changedStartDate && $scope.changedEndDate) {
      var z = $scope.changedStartDate <=  $scope.changedEndDate;
      if (z == false){
        $scope.dateErrowMessage=true;
        $scope.dateNotSelected =true;
      }else{
        $scope.dateErrowMessage=false;
        $scope.dateNotSelected =false;
      }
    }else{
      $scope.dateNotSelected =true;
    }
    if ( ($scope.changedStartDate > $scope.noLaterThan) || ( $scope.changedEndDate > $scope.noLaterThan)){
      $scope.dateFutrueErrowMessage = true;
    } else {
      $scope.dateFutrueErrowMessage = false;
    }
  }

  $scope.cancelPayPeriod = function(){
    $scope.disableUpdate = false;
    document.getElementById("myProductionFromPayPeriod" + $scope.widgetIdentifier).value = $scope.fromPayPeriod;
    document.getElementById("myProductionToPayPeriod"+ $scope.widgetIdentifier).value = $scope.toPayPeriod;
    $scope.changedStartDate = $scope.fromPayPeriod;
    $scope.changedEndDate = $scope.toPayPeriod;
    $scope.judge2 = $scope.fromPayPeriod;
    $scope.judge3 = $scope.toPayPeriod;
    $scope.showError = false;
    $scope.dateFutrueErrowMessage = false;
    $scope.dateErrowMessage = false;
    $scope.dateNotSelected = false;
  }

  $scope.changeButtonClicked = function(){
    $scope.showError = false;
    $scope.dateNotSelected = false;
    $scope.disableUpdate = false;
    $scope.dateFutrueErrowMessage = false;
    $scope.dateErrowMessage = false;
  }

    $scope.updatePayPeriod = function () {
      // console.info("tab = " + vm.selectedTab);
      if (vm.selectedTab === "payPeriodTab"){
        $scope.rangeType = "PP";
        $scope.showValueOfSelected ="PP";
          $scope.fromChangePayperiod = $scope.judge2;
          $scope.toChangePayperiod = $scope.judge3;
      var strFrom = $scope.fromChangePayperiod; 
      var resFrom = strFrom.replace("-", "");
      var strTo = $scope.toChangePayperiod; 
      var resTo = strTo.replace("-", "");
      $scope.startDateHere=resFrom;
      $scope.endDateHere=resTo;
      $scope.payPeriodStart = $scope.fromChangePayperiod;
      $scope.payPeriodEnd =  $scope.toChangePayperiod;
      $scope.rangeValue =  $scope.startDateHere + "-" + $scope.endDateHere;
      if($scope.isSPL && $scope.splTab ==="myTeam") {
$scope.myteamInfo("payPeriodTab");
      } else if ($scope.isSPL && $scope.splTab ==="myGroup"){
$scope.myGroupInfo("payPeriodTab");
      }
     else if($scope.userDropDownName === "No paralegal selected" && !$scope.isSPL){
  $scope.getProductionDataForParalegal(vm.userInfo.assigneeNumber, $scope.userDropDownName);        
  enableSaveGridPref();
} 
else if($scope.userDropDownName === "No paralegal selected" && $scope.isSPL){
// $scope.getProductionDataForParalegal(vm.userInfo.assigneeNumber, $scope.userDropDownName);    
// $scope.getProductionDataForParalegal();     
}
else if ($scope.userDropDownName !== "No paralegal selected"){
        $scope.getProductionDataForParalegal($scope.paralegalNumber, $scope.userDropDownName);
        }
      } else if (vm.selectedTab === "dateRangeTab"){
        $scope.showValueOfSelected ="DT";
        if($scope.changedStartDate === undefined || $scope.changedEndDate === undefined ) {
          $scope.dateNotSelected =true;
        }
  $scope.startDtEpoch = Date.parse($scope.changedStartDate);
 $scope.endDtEpoch = Date.parse($scope.changedEndDate);
 $scope.displayDtRangeStart = angular.copy($scope.startDtEpoch);
 $scope.displayDtRangeEnd =  angular.copy($scope.endDtEpoch);
 $scope.rangeType = $scope.showValueOfSelected;
 $scope.rangeValue =$scope.startDtEpoch +"--"+$scope.endDtEpoch;
 if($scope.isSPL && $scope.splTab ==="myTeam") {
  $scope.myteamInfo("dateRangeTab");
        } else if ($scope.isSPL && $scope.splTab ==="myGroup"){
  $scope.myGroupInfo("dateRangeTab");
        }
  else if($scope.userDropDownName === "No paralegal selected" && !$scope.isSPL){
    $scope.getProductionDataForParalegal(vm.userInfo.assigneeNumber, $scope.userDropDownName);        
    enableSaveGridPref();
  } 
  
  else if($scope.userDropDownName === "No paralegal selected" && $scope.isSPL){
  // $scope.getProductionDataForParalegal(vm.userInfo.assigneeNumber, $scope.userDropDownName);    
  }
  else if ($scope.userDropDownName !== "No paralegal selected"){
          $scope.getProductionDataForParalegal($scope.paralegalNumber, $scope.userDropDownName);
          }
      }else if (vm.selectedTab === "presetTab"){
        $scope.showValueOfSelected ="PRESET";
        $scope.displayPresetType= $scope.presetType;
        if($scope.presetType === "fiscalYear"){
        }else if($scope.presetType === "previousMonth"){
          var now = new Date();
$scope.prevMonthLastDate = new Date(now.getFullYear(), now.getMonth(), 0);
$scope.prevMonthFirstDate = new Date(now.getFullYear() - (now.getMonth() > 0 ? 0 : 1), (now.getMonth() - 1 + 12) % 12, 1);
        }else if ($scope.presetType ==="currentMonth"){
          var date = new Date(), y = date.getFullYear(), m = date.getMonth();
 $scope.firstDayCurrent = new Date(y, m, 1);
$scope.lastDayCurrent = new Date(y, m + 1, 0); 
        }
        if($scope.isSPL && $scope.splTab ==="myTeam") {
          $scope.myteamInfo("presetTab");
                } else if ($scope.isSPL && $scope.splTab ==="myGroup"){
          $scope.myGroupInfo("presetTab");
                }
        else if($scope.userDropDownName === "No paralegal selected" && !$scope.isSPL){
          $scope.getProductionDataForParalegal(vm.userInfo.assigneeNumber, $scope.userDropDownName);        
          enableSaveGridPref();
         } 
       else if($scope.userDropDownName === "No paralegal selected" && $scope.isSPL){
        //  $scope.getProductionDataForParalegal();      
        }
        else if ($scope.userDropDownName !== "No paralegal selected"){
                $scope.getProductionDataForParalegal($scope.paralegalNumber, $scope.userDropDownName);
                }
        $scope.presetType = "fiscalYear";
      }
        vm.selectedTab = "payPeriodTab";
        $scope.presetTab=false;
        $scope.payPeriodTab=true;
        $scope.dateFutrueErrowMessage = false;
        $scope.showError = false;
    $scope.preferencesChanged =true;
    };
    $scope.judge2 = null;

    $scope.searchForJudge2 = function (input) {
      var tempList = [];
     if (angular.isDefined(input) && input.trim() !== "") {
      var n = input.length;
       if ($scope.judge3 !== "" && n =='7') {
        $scope.disableUpdate = false;
       } else 
       if(n <'7'){
        $scope.disableUpdate = true;
       }

        angular.forEach($scope.originalPayPeriod, function (currentJudge) {
          if (currentJudge.toLowerCase().includes(input.toLowerCase())) {
            tempList.push(currentJudge);
          }
        });
        if (tempList.length ==0){
          $scope.disableUpdate =true;
                    }
        $scope.judgeList2 = angular.copy(tempList);
      } else {
        $scope.judgeList2 = angular.copy($scope.originalPayPeriod);
        if(input === ""|| $scope.judge3 === "") {
          $scope.disableUpdate = true;
          }
      }
    };

    $scope.showJudgeList2 = function () {
      if (!$scope.judgeListVisible2) {
        $scope.judgeListVisible2 = !$scope.judgeListVisible2;
      }
    };

    $scope.setSelectedJudge2 = function (judge) {
      if (judge !== "Select an employee...") {
        $scope.selectedJudge2 = judge;
        $scope.judge2 = judge;
        $scope.judgeListVisible2 = false;
        $scope.disableUpdate = false;
        $scope.changedStartDate = judge;
        $scope.changedEndDate = $scope.judge3;
        $scope.judge2 =  $scope.changedStartDate;
        var n = judge.length;
         if ($scope.judge2 !== "" && n =='7') {
          $scope.disableUpdate = false;
         } else 
         if(n <'7' || $scope.judge3 == "" || $scope.judge2 == ""){
          $scope.disableUpdate = true;
         }

        document.getElementById("myProductionFromPayPeriod"+ $scope.widgetIdentifier).value = judge;
        if  ($scope.changedStartDate && $scope.changedEndDate) { 
          var z = $scope.changedStartDate <=  $scope.changedEndDate;
          if (z == false){
            $scope.dateErrowMessage=true;
            $scope.dateNotSelected =true;
            $scope.showError = true;
          } else{
            $scope.dateErrowMessage=false;
            $scope.dateNotSelected =false;
            $scope.showError = false;
          }
        }else{
          $scope.dateNotSelected =true;
        }
      }
    };


    $scope.judge3 =  null;

    $scope.searchForJudge3 = function (input) {
      var tempList = [];
      if (angular.isDefined(input) && input.trim() !== "") {
        if ($scope.judge2 !== "") {
          $scope.disableUpdate = false;
         }
         var length = input.length;
          if ($scope.judge3 !== "" && length =='7') {
           $scope.disableUpdate = false;
          } else if(length <'7'){
           $scope.disableUpdate = true;
          }
        angular.forEach($scope.originalPayPeriod, function (currentJudge) {
          if (currentJudge.toLowerCase().includes(input.toLowerCase())) {
            tempList.push(currentJudge);
          }
          if (tempList.length ==0){
$scope.disableUpdate =true;
          }
        });
        $scope.judgeList3 = angular.copy(tempList);
      } else {
        $scope.judgeList3 = angular.copy($scope.originalPayPeriod);
        if($scope.judge2 === ""|| input === "") {
        $scope.disableUpdate = true;
        }
      }
    };

    $scope.showJudgeList3 = function () {
      if (!$scope.judgeListVisible3) {
        $scope.judgeListVisible3 = !$scope.judgeListVisible3;
      }
    };

    $scope.setSelectedJudge3 = function (judge) {
      if (judge !== "Select from...") {
        $scope.selectedJudge3 = judge;
        $scope.judge3 = judge;
        $scope.judgeListVisible3 = false;
        $scope.disableUpdate = false;
        $scope.changedEndDate = judge;
        $scope.changedStartDate = $scope.judge2;
        $scope.judge3 = judge;
        var n = judge.length; // console.log("length :" + n) 
         if ($scope.judge3 !== "" && n =='7') {
          $scope.disableUpdate = false;
         } else 
         if(n <'7' || $scope.judge3 == "" || $scope.judge2 == ""){
          $scope.disableUpdate = true;
         }
        document.getElementById("myProductionToPayPeriod"+ $scope.widgetIdentifier).value = judge;
        if  ($scope.changedStartDate && $scope.changedEndDate) {
          var z = $scope.changedStartDate <=  $scope.changedEndDate;
          if (z == false){
            $scope.dateErrowMessage=true;
            $scope.dateNotSelected =true;
            $scope.showError = true;
          }else{
            $scope.dateErrowMessage=false;
            $scope.dateNotSelected =false;
            $scope.showError = false;
          }
        }else{
          $scope.dateNotSelected =true;
        }
      }
    };

    $scope.showPlCreditOptions = function () {
      ngDialog.open({
        template: "app/components/widgets/myProduction/src/creditValuesPL.html",
        scope: $scope,
        width: '30%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false
      })
  };

  $scope.getPlCreditOptions = function () {
    HttpFactory.getActions(CONSTANTS.URL.PL_CREDIT_OPTIONS)
      .then(function (successResponse) {
        $scope.creditValues = successResponse.data;
      }, function () { // Empty response is ok
      });
  };

$scope.filterObj={};
$scope.searchCreditValues = function (value){
  $scope.filterObj.column = value;
}

$scope.pressEnterForCreditValues = function (value, event) {
  if (event.keyCode === 13) {
    $scope.filterObj.column = value;
  }
}

  /* istanbul ignore next*/
  $scope.exportData = function () {
    var headers = [];
    angular.forEach($scope.columnDetails, function (coldata) {
      if(coldata.columnName[0] !== 'assigneeForProductionCredit' && coldata.columnName[0] !== 'rangeForProductionCredit') {
        headers.push(coldata.columnLabel);
      }
     
    });
    var fields = [];
    angular.forEach($scope.columnDetails, function (coldata) {
      if (coldata.columnName[0] === 'FK_ASSIGNEE_BE_NO') {
        fields.push([coldata.columnName[1], coldata.columnType]);
      } 
   else if(coldata.columnName[0] === 'assigneeForProductionCredit' || coldata.columnName[0] === 'rangeForProductionCredit') {
     console.info("assigneeForProductionCredit");
   }
      else {
        fields.push([coldata.columnName[0], coldata.columnType]);
      }
    });
    var replacer = function (key, value) {
      return value === null ? '' : value;
    };
    var csv = $scope.productionGridOptions.data.map(function (row) {
      return fields.map(function (fieldName) {
        if (fieldName[1] === 'date') {
          if (row[fieldName[0]]) {
            if (fieldName[0] === 'LAST_MODIFIED_TS') {
              return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy hh:mm:ss a') + " ";
            } else {
              return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy') + " ";
            }
          } else {
            return "";
          }
        } else if (fieldName[0] === 'FK_ASSIGNMENT_TYPE_ID') {
          return row['assignmentTypeDescription'];
        } else if (fieldName[0] === 'LAST_MODIFIED_USER_ID') {
          return JSON.stringify(row['lastModifiedUserName'], replacer);
        } else if (fieldName[0] === 'assigneeHistory') {
          return "";
        } else if (fieldName[0] === 'FK_ASSIGNMENT_STATUS_CD') {
          return row['FK_ASSIGNMENT_STATUS_CD'] === 'A' ? "Open" : "Closed";
        } else {
          return JSON.stringify(row[fieldName[0]], replacer);
        }
      }).join(',');
    });
    csv.unshift(headers.join(','));
    csv = csv.join('\r\n');
    var hiddenElement = document.createElement('a');
    hiddenElement.href = URL.createObjectURL(new Blob([csv], {
      type: 'text/csv'
    }));
    hiddenElement.target = '_blank';
    hiddenElement.download = 'ProductionCreditReport ' + CommonHelperService.getCurrentTime() + '.csv';
    hiddenElement.click();
  };

  function setInitalTeam(){
    getTeamInfoInitial = false;
  }

  function setInitalGroup(){
    getGroupInfoInitial = false;
  }
$scope.myteamInfo = function(value){
  $scope.isLoading =true;
  var url='/credits-views/production-credits?creditsWidget=' + $scope.widgetIdentifier+'&applicationUserId='+vm.userInfo.assigneeNumber+ "&startDate="+ $scope.startDtEpoch+ "&endDate="+ $scope.endDtEpoch + '&userType=TEAM';
  if (value == undefined){
    url ="/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&startPayPeriod="+$scope.fiscalYearStartHerePayPeriod+"&endPayPeriod="+$scope.fiscalYearEndHerePayPeriod+ '&userType=TEAM'; 
    if ($scope.showValueOfSelected =='PP') {
      url='/credits-views/production-credits?creditsWidget=' + $scope.widgetIdentifier+'&applicationUserId='+vm.userInfo.assigneeNumber+ "&startPayPeriod="+ $scope.startDateHere+ "&endPayPeriod="+ $scope.endDateHere + "&userType=TEAM";
    }
    else if ($scope.showValueOfSelected =='DT') {
  url='/credits-views/production-credits?creditsWidget=' + $scope.widgetIdentifier+'&applicationUserId='+vm.userInfo.assigneeNumber+ "&startDate="+ $scope.startDtEpoch+ "&endDate="+ $scope.endDtEpoch + "&userType=TEAM";
}else if ($scope.showValueOfSelected== 'PRESET'  && $scope.displayPresetType =='currentMonth'){
  url = "/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&timeFrame=1&userType=TEAM";   
}
else if ($scope.showValueOfSelected== 'PRESET'  && $scope.displayPresetType =='previousMonth'){
  url = "/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&timeFrame=2&userType=TEAM";   
}
else if ($scope.showValueOfSelected== 'PRESET'  && $scope.displayPresetType =='fiscalYear'){
  url ="/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&startPayPeriod="+$scope.fiscalYearStartHerePayPeriod+"&endPayPeriod="+$scope.fiscalYearEndHerePayPeriod+"&userType=TEAM"; 
}
   else if($scope.originalPlType == "DT"){
      url='/credits-views/production-credits?creditsWidget=' + $scope.widgetIdentifier+'&applicationUserId='+vm.userInfo.assigneeNumber+ "&startDate="+ $scope.startDtEpoch+ "&endDate="+ $scope.endDtEpoch + '&userType=TEAM';
    }
    else if ($scope.originalPlType == "PRESET"){
        if($scope.orignalPlRangeValue == '1' || $scope.orignalPlRangeValue == '2') {
      url = "/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&timeFrame="+ $scope.orignalPlRangeValue+"&userType=TEAM";   
    }
  else{
    url ="/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&startPayPeriod="+$scope.fiscalYearStartHerePayPeriod+"&endPayPeriod="+$scope.fiscalYearEndHerePayPeriod+'&userType=TEAM'; 
  }
}
   else if ($scope.originalPlType == "PP"){
   url = '/credits-views/production-credits?creditsWidget='+$scope.widgetIdentifier+'&applicationUserId='+vm.userInfo.assigneeNumber+'&startPayPeriod='+ $scope.startDateHere+'&endPayPeriod='+$scope.endDateHere+'&userType=TEAM' ;
   }
  }
  
  if(value === "dateRangeTab"){
    $scope.rangeType = $scope.showValueOfSelected;
    $scope.rangeValue =$scope.startDtEpoch +"--"+$scope.endDtEpoch;
 url = '/credits-views/production-credits?creditsWidget='+$scope.widgetIdentifier+'&applicationUserId='+vm.userInfo.assigneeNumber+'&startDate='+ $scope.startDtEpoch+'&endDate='+$scope.endDtEpoch+'&userType=TEAM' ;
  }
 else if(value === "payPeriodTab"){
  $scope.rangeType = $scope.showValueOfSelected;
  $scope.rangeValue =$scope.startDateHere+"-"+$scope.endDateHere;
  url = '/credits-views/production-credits?creditsWidget='+$scope.widgetIdentifier+'&applicationUserId='+vm.userInfo.assigneeNumber+'&startPayPeriod='+ $scope.startDateHere+'&endPayPeriod='+$scope.endDateHere+'&userType=TEAM' ;
 }
 else if (value ==="presetTab" && $scope.displayPresetType ==="currentMonth"){
  $scope.rangeType = $scope.showValueOfSelected;
  $scope.rangeValue ="1";
  url = "/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&timeFrame=1&userType=TEAM";     
}else if (value==="presetTab" && $scope.displayPresetType ==="previousMonth"){
  $scope.rangeType = $scope.showValueOfSelected;
  $scope.rangeValue ="2";
  url = "/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&timeFrame=2&userType=TEAM";
}else if (value ==="presetTab" && $scope.displayPresetType ==="fiscalYear"){
  $scope.rangeType = $scope.showValueOfSelected;
  $scope.rangeValue =$scope.fiscalYearStartHerePayPeriod+"-"+$scope.fiscalYearEndHerePayPeriod; ;
  url ="/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&startPayPeriod="+$scope.fiscalYearStartHerePayPeriod+"&endPayPeriod="+$scope.fiscalYearEndHerePayPeriod+ "&userType=TEAM"; 
}
    if($scope.isSPL){
      HttpFactory.getActions(url)
      .then(function (successResponse) {
        getTeamInfoInitial = false;
        $scope.isLoading = false;
        $scope.updatedColumnList = successResponse.data.columnDetails;
        $scope.columnDetails = successResponse.data.columnDetails;
        $scope.numOfMyTeamAssignees =successResponse.data.numOfMyTeamAssignees;
        var colDefs = CommonHelperService.setColumnDefinitions($scope.updatedColumnList);
        $scope.totalProductionHours = successResponse.data.hours;
        $scope.totalWorkUnits = successResponse.data.workUnits;
        $scope.totalPercentageProduction = successResponse.data.totalProdPercentage;
        $scope.totalPercentageProductionStr = successResponse.data.strTotalProdPercentage;
        $scope.totalProductionHoursStr = successResponse.data.strHours;
        $scope.totalWorkUnitsStr = successResponse.data.strWorkUnits;
        $scope.productionGridOptions.columnDefs = colDefs.colDefs;
        calculateHiddenColumns( $scope.productionGridOptions.columnDefs);
        $scope.productionGridOptions.paginationPageSize = successResponse.data.paginationSize !== undefined ? successResponse.data.paginationSize : 10;
        $scope.lastRefresh = new Date();
        initialLoad = false;
        $scope.productionGridOptions.data = successResponse.data.productionAssignments;
        $timeout($scope.setPaginationManually, 700);
      }, function (failureResponse) {
        $scope.failureMessage = failureResponse.data.message;
        $scope.failureResponse = true;
        $scope.searchTotalLength = 0;
        $scope.isLoading = false;
        initialLoad = false;
        if(getTeamInfoInitial)
        {$scope.myteamInfo();
          $timeout(setInitalTeam(), 10000);
        }
      });
    }
}

$scope.getGroupNum = function(){
  if($scope.isSPL){
    HttpFactory.getActions('/credits-views/production-credits?creditsWidget='+$scope.widgetIdentifier+'&applicationUserId='+vm.userInfo.assigneeNumber+'&startPayPeriod='+ $scope.startDateHere+'&endPayPeriod='+$scope.endDateHere+'&userType=GROUP')
    .then(function (successResponse) {
      getGroupInfoInitial =false;
      $scope.numOfMyGroupAssignees = successResponse.data.numOfMyGroupAssignees;
      $scope.initalCall = false;
      $scope.myteamInfo();
    }, function (failureResponse) {
      $scope.failureMessage = failureResponse.data.message;
      if(getGroupInfoInitial)
        {$scope.getGroupNum();
          $timeout(setInitalGroup(), 10000);
        };
    });
  }}

function initialCallTeams() {
  $scope.isLoading =true;
  $scope.initalCall = true;
    getProductionData();
}

initialCallTeams();

$scope.myGroupInfo = function(value){
  $scope.isLoading =true;
  var url='/credits-views/production-credits?creditsWidget=' + $scope.widgetIdentifier+'&applicationUserId='+vm.userInfo.assigneeNumber+ "&startDate="+ $scope.startDtEpoch+ "&endDate="+ $scope.endDtEpoch + "&userType=GROUP";
  if (value == undefined){
url ="/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&startPayPeriod="+$scope.fiscalYearStartHerePayPeriod+"&endPayPeriod="+$scope.fiscalYearEndHerePayPeriod+ "&userType=GROUP"; 
if ($scope.showValueOfSelected =='PP') {
  url='/credits-views/production-credits?creditsWidget=' + $scope.widgetIdentifier+'&applicationUserId='+vm.userInfo.assigneeNumber+ "&startPayPeriod="+ $scope.startDateHere+ "&endPayPeriod="+ $scope.endDateHere + "&userType=GROUP";
}
else if ($scope.showValueOfSelected =='DT') {
  url='/credits-views/production-credits?creditsWidget=' + $scope.widgetIdentifier+'&applicationUserId='+vm.userInfo.assigneeNumber+ "&startDate="+ $scope.startDtEpoch+ "&endDate="+ $scope.endDtEpoch + "&userType=GROUP";
}else if ($scope.showValueOfSelected== 'PRESET'  && $scope.displayPresetType =='currentMonth'){
  url = "/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&timeFrame=1&userType=GROUP";   
}
else if ($scope.showValueOfSelected== 'PRESET'  && $scope.displayPresetType =='previousMonth'){
  url = "/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&timeFrame=2&userType=GROUP";   
}
else if ($scope.showValueOfSelected== 'PRESET'  && $scope.displayPresetType =='fiscalYear'){
  url ="/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&startPayPeriod="+$scope.fiscalYearStartHerePayPeriod+"&endPayPeriod="+$scope.fiscalYearEndHerePayPeriod+"&userType=GROUP"; 
}
   else if($scope.originalPlType == "DT"){
      url='/credits-views/production-credits?creditsWidget=' + $scope.widgetIdentifier+'&applicationUserId='+vm.userInfo.assigneeNumber+ "&startDate="+ $scope.startDtEpoch+ "&endDate="+ $scope.endDtEpoch + "&userType=GROUP";
    }
    else if ($scope.originalPlType == "PRESET"){
        if($scope.orignalPlRangeValue == '1' || $scope.orignalPlRangeValue == '2') {
      url = "/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&timeFrame="+ $scope.orignalPlRangeValue+"&userType=GROUP";   
    }
  else{
    url ="/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&startPayPeriod="+$scope.fiscalYearStartHerePayPeriod+"&endPayPeriod="+$scope.fiscalYearEndHerePayPeriod+"&userType=GROUP"; 
  }
}
   else if ($scope.originalPlType == "PP"){
   url = '/credits-views/production-credits?creditsWidget='+$scope.widgetIdentifier+'&applicationUserId='+vm.userInfo.assigneeNumber+'&startPayPeriod='+ $scope.startDateHere+'&endPayPeriod='+$scope.endDateHere+'&userType=GROUP';
   }
  }
  
  if(value === "dateRangeTab"){
    $scope.rangeType = $scope.showValueOfSelected;
    $scope.rangeValue =$scope.startDtEpoch +"--"+$scope.endDtEpoch;
 url = '/credits-views/production-credits?creditsWidget='+$scope.widgetIdentifier+'&applicationUserId='+vm.userInfo.assigneeNumber+'&startDate='+ $scope.startDtEpoch+'&endDate='+$scope.endDtEpoch+'&userType=GROUP';
  }
 else if(value === "payPeriodTab"){
  $scope.rangeType = $scope.showValueOfSelected;
  $scope.rangeValue =$scope.startDateHere+"-"+$scope.endDateHere;
  url = '/credits-views/production-credits?creditsWidget='+$scope.widgetIdentifier+'&applicationUserId='+vm.userInfo.assigneeNumber+'&startPayPeriod='+ $scope.startDateHere+'&endPayPeriod='+$scope.endDateHere+'&userType=GROUP';
 }
 else if (value ==="presetTab" && $scope.displayPresetType ==="currentMonth"){
  $scope.rangeType = $scope.showValueOfSelected;
  $scope.rangeValue ="1";
  url = "/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&timeFrame=1&userType=GROUP";     
}else if (value==="presetTab" && $scope.displayPresetType ==="previousMonth"){
  $scope.rangeType = $scope.showValueOfSelected;
  $scope.rangeValue ="2";
  url = "/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&timeFrame=2&userType=GROUP";
}else if (value ==="presetTab" && $scope.displayPresetType ==="fiscalYear"){
  $scope.rangeType = $scope.showValueOfSelected;
  $scope.rangeValue =$scope.fiscalYearStartHerePayPeriod+"-"+$scope.fiscalYearEndHerePayPeriod; ;
  url ="/credits-views/production-credits?creditsWidget=" + $scope.widgetIdentifier + "&applicationUserId=" + vm.userInfo.assigneeNumber+"&startPayPeriod="+$scope.fiscalYearStartHerePayPeriod+"&endPayPeriod="+$scope.fiscalYearEndHerePayPeriod+ "&userType=GROUP"; 
}
    if($scope.isSPL){
      HttpFactory.getActions(url)
      .then(function (successResponse) {
          getGroupInfoInitial = false;
        $scope.isLoading = false;
        $scope.updatedColumnList = successResponse.data.columnDetails;
        $scope.columnDetails = successResponse.data.columnDetails;
        $scope.numOfMyGroupAssignees =successResponse.data.numOfMyGroupAssignees;
        var colDefs = CommonHelperService.setColumnDefinitions($scope.updatedColumnList);
        $scope.totalProductionHours = successResponse.data.hours;
        $scope.totalWorkUnits = successResponse.data.workUnits;
        $scope.totalPercentageProduction = successResponse.data.totalProdPercentage;
        $scope.totalPercentageProductionStr = successResponse.data.strTotalProdPercentage;
        $scope.totalProductionHoursStr = successResponse.data.strHours;
        $scope.totalWorkUnitsStr = successResponse.data.strWorkUnits;
        $scope.productionGridOptions.columnDefs = colDefs.colDefs;
        calculateHiddenColumns( $scope.productionGridOptions.columnDefs);
        $scope.productionGridOptions.paginationPageSize = successResponse.data.paginationSize !== undefined ? successResponse.data.paginationSize : 10;
        $scope.lastRefresh = new Date();
        initialLoad = false;
        $scope.productionGridOptions.data = successResponse.data.productionAssignments;
        $timeout($scope.setPaginationManually, 700);
      }, function (failureResponse) {
        $scope.failureMessage = failureResponse.data.message;
        $scope.failureResponse = true;
        $scope.searchTotalLength = 0;
        $scope.isLoading = false;
        initialLoad = false;
      });
    }
}
  });


