'use strict';
angular.module('adf.widget.quarterlyCloseout', ['adf.provider'])
  .config(function (dashboardProvider) {
    dashboardProvider
      .widget('quarterlyClose', {
        title: 'Quarterly closeout',
        description: 'Quarterly closeout',
        templateUrl: '{widgetsPath}/quarterlyCloseout/src/view.html',
        edit: {
          templateUrl: '{widgetsPath}/quarterlyCloseout/src/edit.html'
        }
      });
  })
  .controller('quarterlyCloseoutController', function ($log, $scope, $rootScope, uiGridConstants,
    HttpFactory, $timeout, SearchHelperService, ngDialog, CONSTANTS, $filter, CommonHelperService, $window, i18nService) {

    var vm = this;
    var saveFirstNum;
    var saveSecNum;
    /* istanbul ignore next */
    $rootScope.$on('broadcastZoneWidth', function (event, param) {
      if (($scope.$parent.model) && ($scope.$parent.model.widgetIdentifier === param.widgetIdentifier)) {
        $scope.setWidgetZone(param.zoneWidth);
      }
    });

    i18nService.get('en').gridMenu.exporterAllAsCsv = 'Export filtered data as csv';
    i18nService.get('en').gridMenu.exporterSelectedAsCsv = 'Export selected as csv';
    i18nService.get('en').gridMenu.exporterVisibleAsCsv = 'Export this page as csv';

    var scope = angular.element(document.getElementById('mainTabId')).scope();
    $scope.setWidgetZone = function (zoneWidth) {
      /* istanbul ignore else */
      if (angular.isUndefined(zoneWidth)) {
        scope.vm.getWidgetZone($scope.$parent.$parent.$parent.definition);
        $scope.zoneWidth = $scope.$parent.$parent.$parent.definition.zoneWidth;
        $timeout(scope.vm.setWidgetContentHeight, 200, true, $scope.$parent.model);
      } else {
        scope.vm.setWidgetContentHeight($scope.$parent.model);
        $scope.zoneWidth = zoneWidth;
      }
    };
    $scope.setWidgetZone();

    var isPaginationChanged = false;
    var isColumnPositionChanged = false;
    var isColumnSizeChanged = false;
    var initialLoad = true;
    var isColumnPinnedChanged = false;
    var isColumnVisibilityChanged = false;
    var isFilterChanged = false;
    var isSortChanged = false;
    var hasFilterFlag = 0;
    $scope.selectUnselect = true;
    $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
    $scope.loadedAssignColumns = false;
    $scope.error = false;
    var isQCwidget = true;
    $rootScope.quarterlyCloseoutColumnsChanged = false;
    $scope.isLoading = false;
    $scope.spanShow = false;
    $scope.preferencesChanged = false;
    $scope.assignmentListOrderChanged = false;
    $rootScope.workqueueColumnsChanged = false;
    $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
    $scope.gridRefreshMsg = CONSTANTS.MESSAGES.GRID_REFRESH;
    $scope.loadedColumns = false;

    /* istanbul ignore if  */
    if (angular.isDefined($scope.$parent.model)) {
      $scope.VCDdataUrl = $scope.$parent.model.dataUrlText;
      $scope.widgetIdentifier = $scope.$parent.model.widgetIdentifier;
    } else {
      $scope.VCDdataUrl = $scope.definition.dataUrlText;
      $scope.widgetIdentifier = $scope.definition.widgetIdentifier;
    }


    /* istanbul ignore next*/
    $scope.getQuartColumns = function () {
      if (isQCwidget || $scope.definition.type === 'quarterlyClose') {
        isQCwidget = false;
        HttpFactory.getActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS + $scope.widgetIdentifier)
          .then(function (successResponse) {
            $scope.availableCols = [];
            $scope.selectedCols = [];
            $scope.selectedColumns = successResponse.data.selectedColumns;
            angular.forEach($scope.selectedColumns, function (thisColumn) {
              if (!thisColumn.visible) {
                $scope.availableCols.push(thisColumn);
              } else {
                $scope.selectedCols.push(thisColumn);
              }
            });
            $scope.updatedColumnList = angular.copy($scope.selectedCols);
            $scope.originShowHide = angular.copy($scope.selectedColumns);
            $scope.loadedColumns = true;
          }, function () {
            //intentional
          });
      }
    };
    $scope.getQuartColumns();

    /* istanbul ignore next*/
    $scope.gridOptions = {
      enableRowSelection: true,
      enableSelectAll: true,
      selectionRowHeaderWidth: 35,
      enableColumnResizing: true,
      enableHorizontalScrollbar: 2,
      useExternalFiltering: true,
      paginationPageSizes: [10, 25, 50, 100],
      enableGridMenu: true,
      exporterCsvFilename: 'QuarterlyCloseout_' + CommonHelperService.getCurrentTime() + '.csv',
      exporterOlderExcelCompatibility: true,
      exporterMenuCsv: true,
      exporterMenuExcel: false,
      exporterMenuPdf: false,
      enableFiltering: true,
      rowHeight: 35,
      showGridFooter: true
    };

    $scope.quarterlyCloseoutSortableOptions = {
      containment: '#myquarterlyColums',
      scroll: true,
      axis: 'y',
      cursor: 'move',
      scrollSpeed: 2,
      scrollSensitivity: 160,
      update: function () {
        $rootScope.quarterlyCloseoutColumnsChanged = true;
      }
    };

    /* istanbul ignore next*/
    function buildGridcMenuCustomItems() {
      $scope.gridOptions.gridMenuCustomItems = [{
          title: 'Save grid preferences',
          action: function () {
            $scope.saveGridPreferences();
          },
          order: 100
        }, {
          title: 'Show hidden filters',
          action: function () {
            showHiddenFilteredColumns();
          },
          order: 190
        },
        {
          title: 'Export full docket as csv',
          action: function () {
            $scope.download_csv();
          },
          order: 220
        },
      ];
    }

    /* istanbul ignore next */
    function resetUnsavedChangesFlags() {
      isFilterChanged = false;
      isColumnVisibilityChanged = false;
      isColumnPinnedChanged = false;
      isColumnSizeChanged = false;
      isSortChanged = false;
      isColumnPositionChanged = false;
      isPaginationChanged = false;
      $scope.preferencesChanged = false;
      $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
    }

    $scope.gridOptions = CommonHelperService.setCommonGridOptions();
    buildGridcMenuCustomItems();
    $scope.gridOptions.enableSelectAll = true;
    $scope.gridOptions.showGridFooter = true;
    $scope.gridOptions.enableHorizontalScrollbar = uiGridConstants.scrollbars.WHEN_NEEDED;

    /* istanbul ignore next */
    $scope.gridOptions.exporterFieldCallback = function (grid, row, col, value) {
      $scope.gridOptions.exporterCsvFilename = "QuarterlyCloseout_" + CommonHelperService.getCurrentTime() + '.csv';
      if (col.colDef.type === 'date') {
        value = $filter('date')(value, 'MM/dd/yyyy');
        if (!value) {
          value = "";
        } else {
          value = " " + value;
        }
      }
      value = checkColumnName(col, value);
      return value;
    };

    /* istanbul ignore next */
    function checkColumnName(col, value) {
      if (col.name === "assigneeHistory") {
        value = "Audit log";
      }
      return value;
    }

    /* istanbul ignore next  */
    function showHiddenFilteredColumns() {
      var hiddenFilteredColumns = SearchHelperService.hasHiddenColumnFilters($scope.gridApi.grid.columns);

      angular.forEach(hiddenFilteredColumns, function (column) {
        column.showColumn();
        $scope.preferencesChanged = true;
      });
      $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
    }

    /* istanbul ignore next*/
    $scope.gridOptions.onRegisterApi = function (gridApi) {
      $scope.gridApi = gridApi;
      $scope.gridApi.selection.setMultiSelect(true);
      $scope.gridApi.core.on.filterChanged($scope, function () {
        isFilterChanged = true;
        var grid = this.grid;
        vm.grid = this.grid;
        $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
        /* Change the scope to $scope.$$childHead.$$childHead.searchText after adding loading screen
         If there are no filters and no search text, then set the grid data to original data */
        if ($scope.numberOfFilters === 0 &&
          (angular.isUndefined($scope.$$childTail.$$prevSibling.searchText) ||
            $scope.$$childTail.$$prevSibling.searchText === "" ||
            $scope.$$childTail.$$prevSibling.searchText === null)) {
          $scope.gridOptions.data = $scope.myData;
          /* If search text is defined and there are filters, then set grid data to filtered data before searching for searched text */
        } else if (angular.isDefined($scope.$$childTail.$$prevSibling.searchText) && $scope.numberOfFilters > 0) {
          $scope.gridOptions.data = SearchHelperService.filterGrid(grid, $scope.myData);
          $scope.$parent.$$childHead.simpleSearch($scope.$$childTail.$$prevSibling.searchText);
          /* If search text is defined and there are no filters, then set the grid data to original data before searching for searched text */
        } else if (angular.isDefined($scope.$$childTail.$$prevSibling.searchText) && $scope.numberOfFilters === 0) {
          $scope.gridOptions.data = $scope.myData;
          $scope.$parent.$$childHead.simpleSearch($scope.$$childTail.$$prevSibling.searchText);
        } else {
          /* If there are filters and no search text, then set grid data to filtered data */
          $scope.gridOptions.data = SearchHelperService.filterGrid(grid, $scope.myData);
        }
        checkForUnsavedChanges();
      });
      $scope.gridApi.core.on.columnVisibilityChanged($scope, function () {
        isColumnVisibilityChanged = true;
        updateColumnDefs($scope.gridOptions.columnDefs);
        checkForUnsavedChanges();
      });
      $scope.gridApi.pinning.on.columnPinned($scope, function () {
        isColumnPinnedChanged = true;
        updateColumnDefs($scope.gridOptions.columnDefs);
        checkForUnsavedChanges();
      });
      $scope.gridApi.colResizable.on.columnSizeChanged($scope, function () {
        isColumnSizeChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.core.on.sortChanged($scope, function () {
        isSortChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.selection.on.rowSelectionChanged($scope, function (row) {
        $scope.quickCompleteIndicator = row.entity.quickComplete;
        $scope.selectedRows = $scope.gridApi.selection.getSelectedRows();
      });
      $scope.gridApi.selection.on.rowSelectionChangedBatch($scope, function () {
        $scope.selectedRows = $scope.gridApi.selection.getSelectedRows();
      });
      $scope.gridApi.colMovable.on.columnPositionChanged($scope, function () {
        isColumnPositionChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.pagination.on.paginationChanged($scope, function () {
        isPaginationChanged = true;
        checkForUnsavedChanges();
      });
    };

    /* istanbul ignore next*/
    $scope.download_csv = function () {
      var headers = [];
      var fields = [];
      angular.forEach($scope.updatedColumnList, function (coldata) {
        headers.push(coldata.columnLabel);
        fields.push([coldata.columnName[0], coldata.columnType]);
      });
      var replacer = function (key, value) {
        if (value === null || angular.isUndefined(value)) {
          value = '';
        }
        return value;
      };
      var csv = $scope.myData.map(function (row) {
        return fields.map(function (fieldName) {
          if (fieldName[1] === 'date') {
            if (row[fieldName[0]] === null) {
              return "";
            } else {
              return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy') + " ";
            }
          } else {
            return JSON.stringify(row[fieldName[0]], replacer);
          }
        }).join(',');
      });
      csv.unshift(headers.join(','));
      csv = csv.join('\r\n');
      var hiddenElement = document.createElement('a');
      hiddenElement.href = URL.createObjectURL(new Blob([csv], {
        type: 'text/csv'
      }));
      hiddenElement.target = '_blank';
      hiddenElement.download = 'Quarterly closeout ' + CommonHelperService.getCurrentTime() + '.csv';
      hiddenElement.click();
    };

    /* istanbul ignore next*/
    function setGridData(colDefs) {
      if (hasFilterFlag > 0) {
        $scope.numberOfFilters = hasFilterFlag;
        var filteredData = SearchHelperService.filterTable($scope.myData, colDefs);
        $timeout(function () {
          $scope.gridOptions.data = filteredData;
          $scope.savedFilteredData = filteredData;
          selectAssignmentRows();
        }, 200);
      } else {
        $scope.numberOfFilters = 0;
        $timeout(function () {
          $scope.gridOptions.data = $scope.myData;
          selectAssignmentRows();
        }, 200);
      }
    }

    $scope.moveItem = function (origin, destination) {
      var temp = $scope.selectedCols[destination];
      $scope.selectedCols[destination] = $scope.selectedCols[origin];
      $scope.selectedCols[origin] = temp;
      $rootScope.quarterlyCloseoutColumnsChanged = true;
    };

    $scope.listItemUp = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex - 1);
    };
    $scope.listItemDown = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex + 1);
    };
    $scope.moveSourcetoDestination = function () {
      angular.forEach($scope.clickedColumn, function (column) {
        column.visible = true;
        $scope.selectedCols.push($scope.availableCols[$scope.availableCols.indexOf(column)]);
        $scope.availableCols.splice($scope.availableCols.indexOf(column), 1);
      });
      $scope.clickedColumn = [];
      $rootScope.quarterlyCloseoutColumnsChanged = true;
    };
    $scope.moveSourcetoDestinationCancel = function (index) {
      $scope.selectedCols[index].visible = false;
      $scope.availableCols.push($scope.selectedCols[index]);
      $scope.selectedCols.splice(index, 1);
      $rootScope.quarterlyCloseoutColumnsChanged = true;
    };
    $scope.toggleSelectAll = function () {
      angular.forEach($scope.availableCols, function (column) {
        column.visible = true;
        $scope.selectedCols.push(column);
      });
      $scope.availableCols = [];
      $rootScope.quarterlyCloseoutColumnsChanged = true;
    };
    $scope.removeAll = function () {
      var tempArray = [];
      $rootScope.quarterlyCloseoutColumnsChanged = true;
      angular.forEach($scope.selectedCols, function (column) {
        if (!column.mandatory) {
          column.visible = false;
          $scope.availableCols.push(column);
        } else {
          tempArray.push(column);
        }
      });
      $scope.selectedCols = tempArray;
    };

    /* istanbul ignore next*/
    $scope.saveState = function () {
      $scope.saveGridPreferences();
    };

    $scope.saveGridPreferences = function () {
      if ($scope.gridApi) {
        $scope.gridState = CommonHelperService.setGridWidthMap($scope.gridApi.saveState.save());
      } else if ($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi) {
        $scope.gridState = CommonHelperService.setGridWidthMap($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi.saveState.save());
      }
      if (angular.isDefined($scope.$$childTail) && $scope.$$childTail !== null) {
        $scope.$$childTail.searchText = "";
      }
      $scope.updateColumns();
    };
    $scope.paginationManual = false;
    $scope.setPaginationManually = function () {
      $scope.paginationManual = false;
    };

    function updateColumnDefs(columndefs) {
      var selected = [];
      var unselected = [];
      var selectedCount = 0;
      angular.forEach(columndefs, function (col) {
        if (col.visible) {
          selected.push(col);
          selectedCount = selectedCount + 1;
        } else {
          unselected.push(col);
        }
      });
      columndefs = [];
      angular.forEach(selected, function (col) {
        if (col.displayName === 'Alerts') {
          col = CommonHelperService.addAlertFilters(col, 'quarterlyClose');
        }
        columndefs.push(col);
      });
      unselected.sort(CommonHelperService.alphabetizeAvailableColumns);
      angular.forEach(unselected, function (col) {
        if (col.displayName === 'Alerts') {
          col = CommonHelperService.addAlertFilters(col, 'quarterlyClose');
        }
        columndefs.push(col);
      });
      $scope.gridOptions.columnDefs = columndefs;
    }

    $scope.sortableOptions = {
      containment: '#quarterlyCloseoutColumns',
      scroll: true,
      axis: 'y',
      cursor: 'move',
      scrollSpeed: 2,
      scrollSensitivity: 160,
      update: function () {
        $rootScope.quarterlyCloseoutColumnsChanged = true;
      }
    };

    $scope.openCaseViewer = function (row) {
      $window.open("#/caseViewer/" + row.entity.serialNumber + "/" + row.entity.appealNumber);
    };

    /* istanbul ignore next: toaster error*/
    $scope.bulkCloseout = function () {
      var userId = $window.sessionStorage.getItem("workerNumber");
      ngDialog.open({
        template: "app/components/widgets/assignments/src/bulkCloseout.html",
        controller: 'bulkClosetoutController',
        controllerAs: 'vm',
        scope: $scope,
        width: '52%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,
        resolve: {
          userId: function () {
            return userId;
          },
          assignmentRows: function () {
            return $scope.selectedRows;
          }
        }
      }).closePromise.then(function (dialogData) {
        if (dialogData.value==='Updated') {
          $scope.refreshGrid();
          $scope.$$childTail.$$prevSibling.searchText = null;
        }
      }, function () {
        //intentional
      });
    };

    /* istanbul ignore next*/
    $scope.saveGridPreferences = function () {
      if ($scope.gridApi) {
        $scope.gridState = CommonHelperService.setGridWidthMap($scope.gridApi.saveState.save());
      } else if ($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi) {
        $scope.gridState = CommonHelperService.setGridWidthMap($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi.saveState.save());
      }
      $scope.updateColumns();
    };

    $scope.paginationManual = false;
    $scope.setPaginationManually = function () {
      $scope.paginationManual = false;
    };
    /* istanbul ignore next*/
    $rootScope.$on('adfCustomizeWidgetServiceCall', function () {
      if ($rootScope.widgetIdentifier === $scope.widgetIdentifier) {
        switch ($rootScope.widgetHeight) {
          case "widgetHeightSmall":
            $scope.gridOptions.paginationPageSize = $scope.gridOptions.paginationPageSizes[0];
            break;
          case "widgetHeightMedium":
            $scope.gridOptions.paginationPageSize = $scope.gridOptions.paginationPageSizes[1];
            break;
          case "widgetHeightLarge":
            $scope.gridOptions.paginationPageSize = $scope.gridOptions.paginationPageSizes[2];
            break;
          case "widgetHeightXlarge":
            $scope.gridOptions.paginationPageSize = $scope.gridOptions.paginationPageSizes[3];
            break;
          default:
            break;
        }
        $scope.paginationManual = true;
        $timeout($scope.setPaginationManually, 700);
      }
    });

    /* istanbul ignore next*/
    $scope.areAllSelected = function () {
      var columnList = angular.element(document.getElementById('quarterlyCloseoutColumns')).scope();
      for (var i = 0; i < columnList.updatedColumnList.length; i++) {
        if (!columnList.updatedColumnList[i].visible) {
          $scope.selectUnselect = false;
          break;
        } else {
          $scope.selectUnselect = true;
        }
        $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
      }
    };

    /* istanbul ignore next*/
    $scope.updateColumns = function () {
      $scope.isLoading = true;
      var docketScopeList = angular.element(document.getElementById('myquarterlyColums')).scope();
      var columnsSelected = [];
      var fromModal = false;
      if (angular.isDefined(docketScopeList)) {
        columnsSelected = docketScopeList.selectedCols;
        columnsSelected = angular.copy(docketScopeList.selectedCols);
        angular.forEach(docketScopeList.availableCols, function (available) {
          columnsSelected.push(available);
        });
        fromModal = true;
      } else {
        columnsSelected = $scope.updatedColumnList;
      }
      var updatedColumns = CommonHelperService.setColumnsToUpdate(columnsSelected, fromModal, $scope.gridState, $scope.widgetIdentifier, false);
      if (angular.isDefined(docketScopeList)) {
        docketScopeList.originalAssignments = angular.copy(updatedColumns.selectedColumns);
      }
      updateAssignmentColumnsService(updatedColumns, fromModal);
    };

    /* istanbul ignore next */
    function updateAssignmentColumnsService(updatedColumns, fromModal) {
      HttpFactory.putActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS, updatedColumns)
        .then(function (successResponse) {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.gridSave, "success");
            resetUnsavedChangesFlags();
            if (fromModal) {
              fromModal = false;
              var colDefs = [];
              angular.forEach(successResponse.config.data.selectedColumns, function (fetchedColumn) {
                var columnToBeAdded = {};
                if (!fetchedColumn.visible) {
                  $scope.selectUnselect = false;
                  $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
                }

                // Adding the column display name
                columnToBeAdded.displayName = fetchedColumn.columnLabel;
                // Checking if the field mapped to the column as an alias name
                if (fetchedColumn.columnName.length > 1) {
                  columnToBeAdded.field = fetchedColumn.columnName[1];
                } else {
                  columnToBeAdded.field = fetchedColumn.columnName[0];
                }
                // Setting column type
                columnToBeAdded.type = fetchedColumn.columnType;
                // Setting custom cell filter if one exists
                if (angular.isDefined(fetchedColumn.cellFilter)) {
                  columnToBeAdded.cellFilter = fetchedColumn.cellFilter;
                }
                // Setting visibility of the column
                if (fetchedColumn.mandatory) {
                  columnToBeAdded.visible = true;
                  columnToBeAdded.enableHiding = false;
                } else {
                  columnToBeAdded.visible = fetchedColumn.visible;
                }
                // Setting column width
                columnToBeAdded.width = fetchedColumn.width;
                // Setting custom template if one exists
                if (angular.isDefined(fetchedColumn.cellTemplate)) {
                  columnToBeAdded.cellTemplate = fetchedColumn.cellTemplate;
                }
                // Setting sort properties on column
                columnToBeAdded.sort = fetchedColumn.sort;
                // Setting column filters
                columnToBeAdded.filters = fetchedColumn.filters;
                // Incrementing the filter flag
                if (columnToBeAdded.filters[0].term) {
                  hasFilterFlag = hasFilterFlag + 1;
                }
                colDefs.push(columnToBeAdded);
              });
              $scope.numberOfFilters = hasFilterFlag;
              var allGrids = document.getElementsByClassName('ui-grid');
              for (var j = 0; j < allGrids.length; j++) {
                if (angular.element(allGrids[j]).scope().widgetIdentifier === $scope.widgetIdentifier) {
                  updateColumnDefs(colDefs);
                  angular.element(allGrids[j]).scope().gridOptions.columnDefs = $scope.gridOptions.columnDefs;
                  if ($scope.numberOfFilters > 0) {
                    var filteredData = SearchHelperService.filterTable($scope.myData, colDefs);
                    $scope.gridOptions.data = filteredData;
                  } else {
                    $scope.gridOptions.data = $scope.myData;
                  }
                  break;
                }
              }
              $rootScope.quarterlyCloseoutColumnsChanged = false;
            } else {
              $scope.getQuartData();
            }
          },
          function () {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.gridSaveFail, "error");
          })
        .finally(function () {
          $scope.isLoading = false;
        });
    }

    /* istanbul ignore next*/
    function checkForUnsavedChanges() {
      if (!initialLoad) {
        if (isFilterChanged || isColumnVisibilityChanged || isColumnSizeChanged || isSortChanged || isColumnPositionChanged || isPaginationChanged || isColumnPinnedChanged) {
          $scope.preferencesChanged = true;
          $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_PREFERENCES;
        } else {
          $scope.preferencesChanged = false;
          $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
        }
      }
    }

    $scope.searchForQuat = function (firstNum, secNum) {
      $scope.hasData=true;
      if (firstNum && secNum) {
        $scope.firstNumber = firstNum;
        $scope.secondNumber = secNum;
      } else {
        $scope.firstNumber = $scope.$$childTail.searchNum1;
        $scope.secNumber = $scope.$$childTail.searchNum2;
      }
      saveFirstNum = angular.copy($scope.firstNumber);
      saveSecNum = angular.copy($scope.secNumber);
      if ($scope.firstNumber === "" || $scope.firstNumber === undefined || $scope.secNumber === "" ||
        $scope.secNumber === undefined || ($scope.firstNumber === $scope.secNumber) ||
        ($scope.firstNumber > $scope.secNumber)) {
        $scope.spanShow = false;
        $scope.error = true;
        $scope.showError = "Enter valid case range for search";
        $scope.isLoading = false;
      } else {
        $scope.isLoading = true;
        $scope.spanShow = true;
        $scope.error = false;
        HttpFactory.getActions(CONSTANTS.URL.QUARTERLY_CLOSEOUT + $scope.firstNumber + "&endCase=" + $scope.secNumber + "&widgetId=" + $scope.widgetIdentifier)
          .then(function (successResponse) {
            $scope.lastRefresh = new Date();

            $scope.isLoading = false;
            $scope.gridOptions.data = successResponse.data.docketData;
            $scope.myData = $filter('orderBy')(successResponse.data.docketData, 'appealNumber');

            $scope.updatedColumnList = successResponse.data.columnDetails;
            var setColumnsResponse = CommonHelperService.setColumnDefinitions($scope.updatedColumnList);
            hasFilterFlag = setColumnsResponse.filterCount;
            updateColumnDefs(setColumnsResponse.colDefs);
            $timeout(function () {
              initialLoad = false;
            }, 1000);
            $scope.searchTotalLength = $scope.gridOptions.data.length;
            if ($scope.searchTotalLength === 0) {
              CommonHelperService.setToastr(CONSTANTS.TOASTER.noRecords, "info");
            }
            setGridData(setColumnsResponse.colDefs);
          }, function (failureResponse) {
            $scope.lastRefresh = new Date();
            $scope.failureMessage = failureResponse.data.message;
            $scope.failureResponse = true;
            $scope.searchTotalLength = 0;
            $scope.isLoading = false;
          });
      }
      $scope.$$childTail.searchNum1 = "";
      $scope.$$childTail.searchNum2 = "";
    };

    /* istanbul ignore next*/
    $scope.refreshGrid = function () {
      $scope.isLoading = true;
      $scope.preferencesChanged = false;
      $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
      $scope.$$childTail.searchText = "";
      $scope.enableloading = true;
      $scope.refreashFaild = false;
      $scope.lastRefresh === undefined || null;
      if (saveFirstNum && saveSecNum) {
        $scope.searchForQuat(saveFirstNum, saveSecNum);
      } else {
        $scope.isLoading = false;
      }
    };

    $scope.numberChange = function () {
      $scope.spanShow = false;
      $scope.error = false;
    };

    function selectAssignmentRows() {
      if ($scope.gridApi) {
        $scope.gridApi.selection.clearSelectedRows();
      }
      $scope.selectedRows = [];
      angular.forEach(vm.failedReassignments, function (assignment) {
        angular.forEach($scope.gridOptions.data, function (dataAssignment) {
          if (assignment.assignmentIdentifier === dataAssignment.assignmentIdentifier) {
            $scope.gridApi.grid.modifyRows($scope.gridOptions.data);
            $scope.gridApi.selection.selectRow(dataAssignment);
          }
        });
      });
    }

    $scope.searchData = true;
    $scope.buttonData = false;
    /* istanbul ignore next*/
    angular.element($window).on('resize', function () {
      if ($window.innerWidth <= 991) {
        $scope.buttonData = true;
      } else {
        $scope.buttonData = false;
      }
    });
  });
