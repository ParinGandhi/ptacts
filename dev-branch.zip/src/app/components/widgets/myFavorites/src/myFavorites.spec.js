(function () {
  'use strict';

  describe('myFavoritesController', function () {

    beforeEach(module('ptabe2e'));

    var $controller;
    var vm = this;
    var scope, $rootScope;
    var controller;
    var $http, indextobeUpdated;
    var httpLocalBackend;
    var $q;
    var HttpFactoryDeferred;
    var successResponse, failureResponse, myFavScope;
    var response = {};
    var spy;
    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              userInfo: 1
            }

          }
        }
      }
    };

    myFavScope = {
      showUpdate: true,
      show: true,
      favorites: undefined,
      deletedFavList: [],
      originalFav: "Links"
    }

    beforeEach(inject(function (_$controller_, _$http_, _$rootScope_, _$q_, HttpFactory, CONSTANTS) {
      $q = _$q_;
      $http = _$http_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;

      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);

      spy = spyOn(angular, 'element').and.callFake(fakeElement);
      scope.$parent = {
        model: {
          dataUrlText: 'http://localhost:8080/PTABServices/',
          widgetIdentifier: 12
        }
      }

      scope.definition = {
        dataUrlText: 'http://localhost:8080/PTABServices/',
        widgetIdentifier: 12
      }

      myFavScope = {
        showUpdate: true,
        show: true,
        favorites: undefined,
        deletedFavList: [],
        originalFav: "Links"
      }

      $controller = _$controller_;
      controller = $controller('myFavoritesController', {
        $http: $http,
        $scope: scope,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory
      });
    }));

    afterEach(function () {
      spy.and.callThrough();
    });

    describe('Initializations', function () {
      it('$scope.show should be set true', function () {
        expect(scope.show).toBeDefined;
        expect(scope.show).not.toBeTruthy();
      });
      it('$scope.showupdate should be set true', function () {

        expect(scope.showUpdate).toBeDefined;
        expect(scope.showUpdate).not.toBeTruthy();
      });

    });

    describe('checking functions', function () {


      it('should showUpdateScreen', function () {
        var index = 0;
        var favorites = [{
          'userFavoritesName': 'testFavourite',
          'userFavoritesURL': 'google.com'
        }];
        scope.favorites = favorites;
        expect(scope.showUpdateScreen).toBeDefined();
        scope.showUpdateScreen(index);
        expect(scope.showUpdate).toBeTruthy();
        expect(scope.show).not.toBeTruthy();
        expect(scope.editFavName).toBe('testFavourite');
        expect(scope.editFavUrl).toBe('google.com');
      });

      it('Should clear disableSaveScope', function () {
        expect(scope.disableSaveScope).toBeDefined();
        scope.disableSaveScope();
      });

      it('should clear', function () {

        expect(scope.clear).toBeDefined();
        scope.clear();
        expect(scope.showNameErrorMsg).not.toBeTruthy();
        expect(scope.showUrlErrorMsg).not.toBeTruthy();
      });

      it('Should clear edit', function () {

        expect(scope.clearEdit).toBeDefined();
        scope.clearEdit();
        expect(scope.showList).toBeTruthy();
        expect(scope.addLink).toBeTruthy();
      });

      it('checkValidation ', function () {
        var index = 0;
        var favorites = [{
          'userFavoritesName': 'testFavourite',
          'userFavoritesURL': 'google.com'
        }];
        scope.favorites = favorites;

        scope.editFavName = undefined;
        scope.editFavUrl = "url";
        expect(scope.checkValidation).toBeDefined();
        scope.checkValidation();
        expect(scope.showNameMsg).toBeTruthy();
        expect(scope.nameMessage).toBe('Name is required field.');

        scope.editFavName = '';
        scope.editFavUrl = "url";
        scope.checkValidation();
        expect(scope.showNameMsg).toBeTruthy();
        expect(scope.nameMessage).toBe('Name is required field.');

        scope.editFavName = 'test';
        scope.editFavUrl = '';
        scope.checkValidation();
        expect(scope.showUrlMsg).toBeTruthy();
        expect(scope.showNameMsg).not.toBeTruthy();
        expect(scope.urlMessage).toBe('Url is required field.');

        scope.editFavName = 'test';
        scope.editFavUrl = "test";
        scope.checkValidation();
        expect(scope.showUrlMsg).not.toBeTruthy();
        expect(scope.showNameMsg).not.toBeTruthy();

      });


      it('Should checkForFavNameError ', function () {

        var name = "";
        expect(scope.checkForFavNameError).toBeDefined();
        scope.checkForFavNameError(name);
        expect(scope.showNameErrorMsg).toBeTruthy();
        expect(scope.nameErrorMessage).toBe('Favorites name is required field.');

        var name = undefined;
        scope.checkForFavNameError(name);
        expect(scope.showNameErrorMsg).toBeTruthy();
        expect(scope.nameErrorMessage).toBe('Favorites name is required field.');

        var name = "test";
        scope.checkForFavNameError(name);
        expect(scope.showNameErrorMsg).not.toBeTruthy();

      });


      it('Should checkForFavUrlError ', function () {

        var url = "";
        expect(scope.checkForFavUrlError).toBeDefined();
        scope.checkForFavUrlError(url);
        expect(scope.showUrlErrorMsg).toBeTruthy();
        expect(scope.urlErrorMessage).toBe('Favorites url is required field.');

        var url = undefined;
        scope.checkForFavUrlError(url);
        expect(scope.showUrlErrorMsg).toBeTruthy();
        expect(scope.urlErrorMessage).toBe('Favorites url is required field.');

        var url = "testurl";
        scope.checkForFavUrlError(url);
        expect(scope.showUrlErrorMsg).not.toBeTruthy();
      });


      it('ShowEdit should set scope.show to true', function () {

        expect(scope.showEdit).toBeDefined();
        scope.showEdit();
        expect(scope.showUpdate).not.toBeTruthy();
        expect(scope.show).not.toBeTruthy();
      });

      it('moveItem should swap origin and destination', function () {
        var origin = 0,
          destination = 1;
        var favorites = [{
          'userFavoritesName': 'testFavouriteOrigin',
          'userFavoritesURL': 'google.com'
        }, {
          'userFavoritesName': 'testFavouriteDest',
          'userFavoritesURL': 'bin.com'
        }];
        var favoritesCopy = [{
          'userFavoritesName': 'testFavouriteOrigin',
          'userFavoritesURL': 'google.com'
        }, {
          'userFavoritesName': 'testFavouriteDest',
          'userFavoritesURL': 'bin.com'
        }];
        scope.favorites = favorites;
        expect(scope.moveItem).toBeDefined();
        scope.moveItem(origin, destination);

        expect(scope.favorites[0].userFavoritesName).not.toBe(favoritesCopy[0].userFavoritesName);
        expect(scope.favorites[0].userFavoritesURL).not.toBe(favoritesCopy[0].userFavoritesURL);

      });

      it('listItemUp should call move item', function () {

        expect(scope.listItemUp).toBeDefined();
        spyOn(scope, 'moveItem');
        expect(scope['moveItem']).toBeDefined();
        scope.listItemUp(1);
        expect(scope.moveItem).toHaveBeenCalledWith(1, 0);

      });

      it('listItemDown should call move item', function () {

        expect(scope.listItemDown).toBeDefined();
        spyOn(scope, 'moveItem');
        expect(scope['moveItem']).toBeDefined();
        scope.listItemDown(1);
        expect(scope.moveItem).toHaveBeenCalledWith(1, 2);

      });

      it('addFav should push add item to favourite', function () {

        scope.favName = 'microsoft';
        scope.favUrl = 'bing.com';

        var favorites = [{
          'userFavoritesName': 'testFavourite',
          'userFavoritesURL': 'google.com'
        }];
        scope.favorites = favorites;

        expect(scope.addFav).toBeDefined();
        scope.addFav();
      });

      it('updateFav should update favorites', function () {
        scope.editFavName = 'microsoft';
        scope.editFavUrl = 'bing.com';
        var favorites = [{
          'userFavoritesName': 'testFavourite',
          'userFavoritesURL': 'google.com'
        }];
        scope.favorites = favorites;
        expect(scope.updateFav).toBeDefined();
        scope.showUpdateScreen(0);
        scope.updateFav();
        expect(scope.favorites.length).toBe(1);
        expect(scope.favorites[0].userFavoritesName).toBe(scope.editFavName);
        expect(scope.favorites[0].userFavoritesURL).toBe(scope.editFavUrl);

      });

      it('deleteFav should delete favorites', function () {
        var index = 0;
        var favorites = [{
          'userFavoritesName': 'testFavourite',
          'userFavoritesURL': 'google.com',
          'userFavoritesIdentifier': true
        }];
        scope.favorites = favorites;
        expect(scope.deleteFav).toBeDefined();
        scope.deleteFav(0);

      });

      it('getFav success response ', inject(function ($rootScope) {

        var current;
        successResponse = {
          data: [{
              "userFavoritesIdentifier": 742,
              "userFavoritesName": "Patent Search",
              "userFavoritesURL": "http://my.uspto.gov",
              "defaultIndicator": false,
              "applicationUserData": {
                "applicationUserIdentifier": 5769
              }
            },
            {
              "userFavoritesIdentifier": 743,
              "userFavoritesName": "Test Name",
              "userFavoritesURL": "http://my.testUrl11.gov",
              "defaultIndicator": false,
              "applicationUserData": {
                "applicationUserIdentifier": 5769
              }
            }
          ]
        };
        scope.getFav();
        HttpFactoryDeferred.resolve(successResponse);
        // $rootScope.$apply();
        scope.$digest();
      }));

      it('getFav failureresponse ', function () {

        failureResponse = {
          data: {}
        };
        scope.getFav();
        HttpFactoryDeferred.reject(failureResponse);
        // $rootScope.$apply();
        scope.$digest();
      });


      it('saveFav should save favorites', function () {

        myFavScope = {
          showUpdate: true,
          show: true,
          favorites: undefined,
          deletedFavList: [],
          originalFav: "Links"
        }

        scope.definition = {
          dataUrlText: 'http://localhost:8080/PTABServices/',
          widgetIdentifier: 12
        }

        expect(scope.saveFav).toBeDefined();
        scope.saveFav();


        // var dummyElement = document.createElement('div');
        // scope = $rootScope.$new();

        // document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(dummyElement);
        // var controller = $controller('myFavoritesController', {
        //   $scope: scope
        // });

        // spyOn(document.getElementById("myFavoritesEdit"), 'scope');
        // expect(document.getElementById("myFavoritesEdit").scope).toBeDefined();
      });

    });




  });
})();
