'use strict';

angular.module('adf.widget.myFavorites', ['adf.provider'])
  .config(function (dashboardProvider) {
    dashboardProvider
      .widget('myFavorites', {
        title: 'My Favorites',
        description: 'Contains favorite links for a user',
        templateUrl: '{widgetsPath}/myFavorites/src/view.html',
        edit: {
          templateUrl: '{widgetsPath}/myFavorites/src/edit.html'
        }
      });
  }).controller('myFavoritesController', function ($http,$log, $scope, $rootScope, $timeout, HttpFactory) {
    /* istanbul ignore else  */
    if (angular.isDefined($scope.$parent.model)) {
      $scope.dataUrl = $scope.$parent.model.dataUrlText;
    } else {
      $scope.dataUrl = $scope.definition.dataUrlText;
    }

    $scope.show = false;
    $scope.showUpdate = false;
    $scope.showList = true;
    $scope.addLink = true;
    $scope.disableSaveFlag = false;
    $scope.favorites = [];
    var indextobeUpdated;
    var deletedFav = [];
    $scope.deletedFavList;
    $scope.favName = "";
    $scope.favUrl = "";
    $scope.showUpdateScreen = function (index) {
      $scope.showUpdate = true;
      $scope.show = false;
      $scope.showList = false;
      $scope.addLink = false;
      $scope.editFavName = $scope.favorites[index].userFavoritesName;
      $scope.editFavUrl = $scope.favorites[index].userFavoritesURL;
      indextobeUpdated = index;
      $scope.index = index;
      $scope.showNameMsg = false;
      $scope.showUrlMsg = false;
    };

    $scope.disableSaveScope = function () {

      var saveScope = document.getElementsByClassName('saveMyFavsBtn');
      /* istanbul ignore next  */
      for (var i = 0; i < saveScope.length; i++) {
        var favSaveScope = angular.element(saveScope[i]).scope();
        favSaveScope.disableSaveFlag = false;
      }
    };

    $scope.clear = function () {
      $scope.showList = true;
      $scope.show = false;
      $scope.favName = '';
      $scope.favUrl = '';
      $scope.showNameErrorMsg = false;
      $scope.showUrlErrorMsg = false;
      $scope.disableSaveScope();
    };
    $scope.clearEdit = function () {
      $scope.showUpdate = false;
      $scope.showList = true;
      $scope.addLink = true;
      $scope.disableSaveScope();
    };
    //validations for edit favourites fields
    $scope.checkValidation = function () {
      if (angular.isUndefined($scope.editFavName) || $scope.editFavName.trim().length <= 0) {
        $scope.showNameMsg = true;
        $scope.nameMessage = "Name is required field.";
      } else {
        $scope.showNameMsg = false;
      }

      if (angular.isUndefined($scope.editFavUrl) || $scope.editFavUrl.trim().length <= 0) {
        $scope.showUrlMsg = true;
        $scope.urlMessage = "Url is required field.";
      } else {
        $scope.showUrlMsg = false;
      }
      $scope.disableSave();

    };

    //validations for add favorites fields
    $scope.checkForFavNameError = function (name) {
      if (angular.isUndefined(name) || name.trim().length <= 0) {
        $scope.showNameErrorMsg = true;
        $scope.nameErrorMessage = "Favorites name is required field.";
      } else {
        $scope.showNameErrorMsg = false;
      }
      $scope.disableSave();
    };
    $scope.checkForFavUrlError = function (url) {
      if (angular.isUndefined(url) || url.trim().length <= 0) {
        $scope.showUrlErrorMsg = true;
        $scope.urlErrorMessage = "Favorites url is required field.";
      } else {
        $scope.showUrlErrorMsg = false;
      }
      $scope.disableSave();
    };

    //disable save and close buttons on  error messages
    $scope.disableSave = function () {
      var saveScope = document.getElementsByClassName('saveMyFavsBtn');
      /* istanbul ignore next  */
      for (var i = 0; i < saveScope.length; i++) {
        var favSaveScope = angular.element(saveScope[i]).scope();
        if ($scope.showNameErrorMsg || $scope.showUrlErrorMsg || $scope.showUrlMsg || $scope.showNameMsg) {
          favSaveScope.disableSaveFlag = true;
          $scope.disableSaveFlag = true;
        } else {
          favSaveScope.disableSaveFlag = false;
          $scope.disableSaveFlag = false;
        }
      }
    };

    $scope.showEdit = function () {
      $scope.showUpdate = false;
    };

    // Move list items up or down or swap
    $scope.moveItem = function (origin, destination) {
      var temp = $scope.favorites[destination];
      $scope.favorites[destination] = $scope.favorites[origin];
      $scope.favorites[origin] = temp;
    };

    // Move list item Up
    $scope.listItemUp = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex - 1);
    };

    // Move list item Down
    $scope.listItemDown = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex + 1);
    };

    //add favorite item to list
    $scope.addFav = function () {
      var data = {
        "userFavoritesName": $scope.favName,
        "userFavoritesURL": $scope.favUrl
      };
      /* istanbul ignore next  */
      if (angular.isUndefined($scope.favorites)) {
        $scope.favorites = [];
      }
      $scope.favorites.push(data);
      $scope.show = false;
      $scope.showList = true;
      $scope.favName = '';
      $scope.favUrl = '';
    };

    //update the favorite
    $scope.updateFav = function () {
      $scope.showList = true;
      $scope.addLink = true;
      $scope.favorites[indextobeUpdated].userFavoritesName = $scope.editFavName;
      $scope.favorites[indextobeUpdated].userFavoritesURL = $scope.editFavUrl;
    };

    //delete favorite
    $scope.deleteFav = function (index) {
      var delIdentifier = $scope.favorites[index].userFavoritesIdentifier;
      if (delIdentifier) {
        deletedFav.push(delIdentifier);
      }

      $scope.deletedFavList = deletedFav;
      $scope.favorites.splice(index, 1);
    };

    //get the favorite list
    $scope.getFav = function () {
      HttpFactory.getActions($scope.dataUrl)
        .then(function (successResponse) {
          $scope.favorites = successResponse.data;
          $scope.originalFav = angular.copy($scope.favorites);
        }, function (failureResponse) {
           $log.info(failureResponse);
        });
    };
    $scope.originalFav = angular.copy($scope.favorites);

    //save all operations performed on favorites list
    $scope.saveFav = function () {
      var myFavScope = angular.element(document.getElementById('myFavoritesEdit')).scope();
      /* istanbul ignore if  */
      if (myFavScope.showUpdate) {
        myFavScope.showList = true;
        myFavScope.addLink = true;
        myFavScope.showUpdate = false;
        myFavScope.favorites[myFavScope.index].userFavoritesName = myFavScope.editFavName;
        myFavScope.favorites[myFavScope.index].userFavoritesURL = myFavScope.editFavUrl;
      }
      /* istanbul ignore if  */
      if (myFavScope.show) {
        myFavScope.showList = true;
        myFavScope.addLink = true;
        myFavScope.show = false;
        var data = {
          "userFavoritesName": myFavScope.favName,
          "userFavoritesURL": myFavScope.favUrl
        };
        if (angular.isUndefined(myFavScope.favorites)) {
          myFavScope.favorites = [];
        }
        myFavScope.favorites.push(data);

        myFavScope.favName = '';
        myFavScope.favUrl = '';
      }

      if (angular.isUndefined(myFavScope.deletedFavList)) {
        myFavScope.deletedFavList = [];
      }
      var favorites = {
        "deletedItems": myFavScope.deletedFavList,
        "userFavoriteForms": myFavScope.favorites
      };
      /* istanbul ignore if  */
      if (!angular.equals(myFavScope.favorites, myFavScope.originalFav)) {
        HttpFactory.putActions($scope.dataUrl, favorites)
          .then(function (response) {
            var tempFav = document.getElementsByClassName('favorites-widget-list');
            for (var i = 0; i < tempFav.length; i++) {
              var tmpScope = angular.element(tempFav[i]).scope();
              tmpScope.favorites = response.config.data.userFavoriteForms;
              myFavScope.originalFav = angular.copy(tmpScope.favorites);
            }
          }, function (failureResponse) {
             $log.info(failureResponse);
          });
      }
    };

    //drag drop settings
    $scope.sortableOptions = {
      containment: '#favList',
      scroll: false,
      axis: 'y',
      cursor: 'move'
    };

  });
