'use strict';

angular.module('adf.widget.systemStatus', ['adf.provider'])
  .config(function (dashboardProvider) {
    dashboardProvider
      .widget('systemStatus', {
        title: 'System Status',
        description: 'RSS feed of USPTO System messages',
        controller: "SystemStatusController",
        templateUrl: '{widgetsPath}/systemStatus/src/view.html',
        edit: {
          templateUrl: '{widgetsPath}/systemStatus/src/edit.html'
        }
      });
  }).controller('SystemStatusController', function ($log, $http, $scope, $rootScope, $timeout, HttpFactory, CONSTANTS) {

    /* istanbul ignore next  */
    $rootScope.$on('broadcastZoneWidth', function (event, param) {
      if ($scope.$parent.model.widgetIdentifier === param.widgetIdentifier) {
        $scope.setWidgetZone(param.zoneWidth);
      }
    });

    var scope = angular.element(document.getElementById('mainTabId')).scope();
    $scope.setWidgetZone = function (zoneWidth) {
      if (angular.isUndefined(zoneWidth)) {
        scope.vm.getWidgetZone($scope.$parent.model);
        $scope.zoneWidth = $scope.$parent.model.zoneWidth;
        $timeout(scope.vm.setWidgetContentHeight, 200, true, $scope.$parent.model);
      } else {
        $scope.zoneWidth = zoneWidth;
        scope.vm.setWidgetContentHeight($scope.$parent.model);
      }
    };
    $scope.setWidgetZone();

    $scope.getCurrent = function () {
      return HttpFactory.getActions(CONSTANTS.URL.SYSTEM_STATUS_RSS_FEED)
        .then(function (successResponse) {
          $scope.currentEvents = successResponse.data;
          $scope.currentEvent = successResponse.data.events;
          $scope.enableloading = false;
          $scope.refreashCurrentFaild = false;
        }, function (failureResponse) {
           $log.info(failureResponse);
          if (failureResponse.status === 404) {
            $scope.enableloading = false;
            $scope.refreashCurrentFaild = false;
          } else {
            $scope.refreashCurrentFaild = true;
            $scope.enableloading = false;
            $scope.refreashFailDate = new Date();
            if (angular.isUndefined($scope.refreshDate) || $scope.refreshDate === null) {
              $scope.dateValid = true;
            }
          }
        });
    };

    $scope.getCurrent();
    $scope.getPlanned = function () {
      HttpFactory.getActions(CONSTANTS.URL.PLANNED_EVENTS_RSS_FEED)
        .then(function (successResponse) {
          $scope.plannedEvents = successResponse.data;
          $scope.plannedEvent = successResponse.data.events;
          $scope.enableloading = false;
          $scope.refreashFaild = false;
          $scope.refreshDate = new Date();
        }, function (failureResponse) {
           $log.info(failureResponse);
          if (failureResponse.status === 404) {
            $scope.enableloading = false;
            $scope.refreashFaild = false;
            $scope.refreshDate = new Date();
          } else {
            $scope.refreashFaild = true;
            $scope.refreashFailDate = new Date();
            $scope.enableloading = false;
            if (angular.isUndefined($scope.refreshDate) || $scope.refreshDate === null) {
              $scope.dateValid = true;
            }
          }
        });
    };
    $scope.getPlanned();
    /* istanbul ignore next  */
    setInterval(function () {
      $scope.getCurrent();
    }, 60000);
    /* istanbul ignore next  */
    setInterval(function () {
      $scope.getPlanned();
    }, 3600000);


    $scope.currentTab = 'currentEvents';
    $scope.selectTab = function (currentTab) {
      $scope.currentTab = currentTab;
    };
    $scope.isActiveTab = function (tab) {
      return $scope.currentTab === tab;
    };
    $scope.refreshSystemStatusData = function () {
      $scope.refreshDate === undefined || null;
      $scope.enableloading = true;
      $scope.refreashFaild = false;
      $scope.dateValid = false;
      $scope.refreashCurrentFaild = false;
      /* istanbul ignore next  */
      $scope.getCurrent().then(function () {
        if ($scope.refreashCurrentFaild) {
          $scope.refreashFaild = true;
        } else {
          $scope.getPlanned();
        }

      });
    };

  });
