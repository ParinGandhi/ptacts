(function () {
  'use strict';

  describe('SystemStatusController', function () {

    beforeEach(module('ptabe2e'));

    var vm = this;
    var scope;
    var controller, $controller;
    var $http, $interval, $log, $rootScope, spy;
    var $q, HttpFactoryDeferred;

    var successResponse = {
      data: {
        events: {},
        refreshInterval: 0
      }
    };

    var failureResponse = '';

    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              getWidgetZone: function () {

              },
              setWidgetContentHeight: function () {

              }
            }
          }
        }
      }
    };
    var fakeVm = {
      getWidgetZone: function () {

      },
      setWidgetContentHeight: function () {

      }
    };

    beforeEach(inject(function (_$controller_, _$http_, _$rootScope_, _$interval_, $compile, _$q_, HttpFactory, CONSTANTS) {
      $q = _$q_;
      $http = _$http_;
      scope = _$rootScope_.$new();
      $interval = _$interval_;
      $rootScope = _$rootScope_;

      // setup the promise
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);

      // scope.getCurrent.and.returnValue({
      //   then: function (callback) {
      //     callback();
      //   }
      // });

      $controller = _$controller_;
      scope.$parent = {
        "model": {
          "zoneWidth": 10,
          "widgetIdentifier": 1
        }
      };

      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      controller = $controller('SystemStatusController', {
        // $log: $log,
        $http: $http,
        $scope: scope,
        $rootScope: _$rootScope_,
        $interval: $interval,
        HttpFactory: HttpFactory

      });

      // spyOn($rootScope, '$on').and.callThrough();
    }));


    afterEach(function () {
      spy.and.callThrough();
    });


    describe('check functions', function () {

      it('setWidgetZone should set WidgetZone', function () {
        scope.$parent = {
          "model": {
            "zoneWidth": 10
          }
        };
        var zoneWidth = 10;
        expect(scope.setWidgetZone).toBeDefined();
        scope.setWidgetZone(zoneWidth);
        expect(scope.zoneWidth).toBe(zoneWidth);

        expect(scope.setWidgetZone).toBeDefined();
        scope.setWidgetZone();
        expect(scope.zoneWidth).toBe(zoneWidth);

      });

      it('getCurrent should return successResponse if block  ', function () {

        successResponse = {
          data: {
            events: {},
          }
        };

        HttpFactoryDeferred.resolve(successResponse);
        // $rootScope.$apply();
        scope.$digest();

        scope.getCurrent();
        expect(scope.currentEvents).toBe(successResponse.data);
        expect(scope.currentEvent).toBe(successResponse.data.events);

      });

      it('getCurrent should return failureResponse  ', function () {

        failureResponse = '';

        HttpFactoryDeferred.reject(failureResponse);
        // $rootScope.$apply();
        scope.$digest();

        scope.getCurrent();

      });

      it('getCurrent should return failureResponse  ', function () {

        failureResponse = {
          status: 404
        }

        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();

        scope.getCurrent();

      });

      it('selectTab should set current Tab ', function () {
        scope.currentTab = 'currentEvents';
        expect(scope.currentTab).toBe('currentEvents');
        expect(scope.selectTab).toBeDefined();
        scope.selectTab('newTab');
        expect(scope.currentTab).toBe('newTab');
      });

      it('isActiveTab ', function () {
        scope.currentTab = 'currentEvents';
        expect(scope.isActiveTab).toBeDefined();
        var value = scope.isActiveTab('newTab');
        expect(value).toBe(false);
        var value = scope.isActiveTab('currentEvents');
        expect(value).toBe(true);

      });

      it('refreshSystemStatusData ', function () {
        // spyOn(scope, 'getCurrent');
        // expect(scope.getCurrent).toBeDefined();
        expect(scope.refreshSystemStatusData).toBeDefined();
        scope.refreshSystemStatusData();
        // expect(scope.getCurrent).toHaveBeenCalled();
      });

    });

  });
})();
