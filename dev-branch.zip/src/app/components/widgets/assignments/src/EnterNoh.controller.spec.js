(function () {
    'use strict';

    describe('enterNohController', function () {

        beforeEach(module('ptabe2e'));
        var $controller;
        var vm = this;
        var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open']);
        var controller, scope, $rootScope;
        var timeout;
        var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;
        var showPromoteTypesValues;
        var pdfContent = {
            value: "xsgght"
        }

        var fakeElement = function (params) {
            return {
                scope: function () {
                    return {
                        vm: {
                            workerNumber: "pgandhi"
                        }
                    }
                }
            }
        };

        beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
            $q = _$q_;
            $controller = _$controller_;
            scope = _$rootScope_.$new();
            $rootScope = _$rootScope_;
            HttpFactoryDeferred = _$q_.defer();
            spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);

            $rootScope.sharedItems = [{
                "ptabAssignmentId": "1547",
                "fkAdFkAaSerialNo": "2018005604",
                "fkAdFkAppealNo": "10651537",
                "assignmentType": "RHT"
            }];

            scope.specialType = [{
                valueText: "added",
                descriptionText: "desc"
            }]

            ngDialog.open.and.returnValue({
                closePromise: {
                  then: function (callback1) {
                    callback1(pdfContent);
                  }
                }
              });

              scope.specialHearingType = {
                selectedStatusType: "CT",
                selectedStatusDisplay: "CT"
            }

            scope.hearingAtten = {
                selectedHearingCode: "CT",
                selectedHearingDisplay: "CT"
            }

            spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
            spy = spyOn(angular, 'element').and.callFake(fakeElement);
            controller = $controller('enterNohController', {
                $scope: scope,
                ngDialog: ngDialog,
                $rootScope: _$rootScope_,
                showPromoteTypesValues: showPromoteTypesValues,
                HttpFactory: HttpFactory

            });
        }));

        describe('enterNohController ', function () {

            it('it should get enter notice of hearing ', function () {

                successResponse = {
                    data: {
                        "serialNumber": "09733020",
                        "appealNumber": 2004000447,
                        "sequenceNumber": 1,
                        "reconsiderSequenceNumber": 0,
                        "hrrSequenceNumber": 0,
                        "calendarNumber": null,
                        "counselFullName": null,
                        "hearingLocationIdentifier": 1,
                        "locationDescription": "Alexandria: Room A",
                        "hearingDocketNumber": "B",
                        "hearingDate": 1528171200000,
                        "hearingNoteText": "testing",
                        "hearingTime": "1:00:00 PM EST",
                        "lastModifiedTime": 1541774285000,
                        "lastModifiedUserIdentifier": "rramani",
                        "palmHearingMailedDate": null,
                        "sessionNumber": 1,
                        "specialTypeIndicator": "\u0000",
                        "hearingAttendanceStatusCd":"CT",
                        "hearingAttendanceStatusDesc":"CT",
                        "remoteLocationCd":"CT",
                        "remoteLocationCdDesc":"CT",
                        "statusCode": "PN",
                        "usherWorkerIdentifier": null,
                        "appealJudgePanel": null,
                        "realPartyInInterest": null,
                        "statusCodes": [{
                            descriptionText: "STATUS"
                        }]
                    }
                };

                scope.shareAssign = [{
                    "ptabAssignmentId": "1547",
                    "fkAdFkAaSerialNo": "2018005604",
                    "fkAdFkAppealNo": "10651537",
                    "assignmentType": "UHA"
                }];
                scope.eroh = {
                    statusCode: "CT"
                }

                expect(scope.enternoh).toBeDefined();
                scope.enternoh();

                // HttpFactoryDeferred.resolve(successResponse);
                // $rootScope.$apply();

            });
            it('enternoh failureResponse ', function () {
                var failureResponse = {
                    data: {}
                };

                expect(scope.enternoh).toBeDefined();
                scope.enternoh();

                HttpFactoryDeferred.reject(failureResponse);
                $rootScope.$apply();
            });

            it('should call hearing status', function () {

                successResponse = {
                    data: {
                        valueText: "ABN",
                        descriptionText: "Abandoned, process and finalize draft"
                    }
                };
                expect(scope.hearingStatus).toBeDefined();
                scope.hearingStatus();
                HttpFactoryDeferred.resolve(successResponse);
                $rootScope.$apply();
            });

            it('hearingStatus failureResponse ', function () {
                var failureResponse = {
                    data: {}
                };

                expect(scope.hearingStatus).toBeDefined();
                scope.hearingStatus();
                HttpFactoryDeferred.reject(failureResponse);
                $rootScope.$apply();
            });

            it('should call uhaHearingStatus', function () {

                successResponse = {
                    data: {
                        valueText: "DNM",
                        descriptionText: "Abandoned, process"
                    }
                };
                expect(scope.uhaHearingStatus).toBeDefined();
                scope.uhaHearingStatus();
                HttpFactoryDeferred.resolve(successResponse);
                $rootScope.$apply();
            });

            it('uhaHearingStatus failureResponse ', function () {
                var failureResponse = {
                    data: {}
                };

                expect(scope.uhaHearingStatus).toBeDefined();
                scope.uhaHearingStatus();
                HttpFactoryDeferred.reject(failureResponse);
                $rootScope.$apply();
            });

            it('should call ptvhHearingStatus ', function () {

                expect(scope.ptvhHearingStatus).toBeDefined();
                scope.ptvhHearingStatus();
            });

            it('should call setSelectedSpecialType ', function () {
                var selectedSpecialType, selectedSpecialDisplay;
                expect(scope.setSelectedSpecialType).toBeDefined();
                scope.setSelectedSpecialType(selectedSpecialType, selectedSpecialDisplay);
            });

            it('should call dateEmptyValidation', function () {
                scope.transactionDate = null;
                expect(scope['dateEmptyValidation']).toBeDefined();
                scope.dateEmptyValidation();
            });

            it('should call setSelectedType', function () {
                scope.shareAssign = [{
                    "assignmentType": "EARH"
                }];
                scope.hStatus = {
                    selectedStatusType: "AWTRESP"
                }
                expect(scope.setSelectedType).toBeDefined();
                scope.setSelectedType();

                scope.hStatus = {
                    selectedStatusType: "AWT"
                }
                expect(scope.setSelectedType).toBeDefined();
                scope.setSelectedType();
            });

            it('should call setSelectedType', function () {
                scope.shareAssign = [{
                    "assignmentType": "EARH"
                }];

                scope.hStatus = {
                    selectedStatusType: "AWT"
                }
                expect(scope.setSelectedType).toBeDefined();
                scope.setSelectedType();
            });

            it('should call setSelectedType', function () {
                scope.shareAssign = [{
                    "assignmentType": "SRD"
                }];
                scope.hStatus = {
                    selectedStatusType: "AWTRESP"
                }
                expect(scope.setSelectedType).toBeDefined();
                scope.setSelectedType();

                scope.hStatus = {
                    selectedStatusType: "HRR"
                }
                expect(scope.setSelectedType).toBeDefined();
                scope.setSelectedType();
            });

            it('should call setSelectedType', function () {
                scope.shareAssign = [{
                    "assignmentType": "SRD"
                }];
                scope.hStatus = {
                    selectedStatusType: "HRR"
                }
                expect(scope.setSelectedType).toBeDefined();
                scope.setSelectedType();
            });

            it('should call setSelectedType', function () {
                scope.shareAssign = [{
                    "assignmentType": "PTVH"
                }];
                scope.hStatus = {
                    selectedStatusType: "AWTRESP"
                }
                expect(scope.setSelectedType).toBeDefined();
                scope.setSelectedType();

                scope.hStatus = {
                    selectedStatusType: "CVDH"
                }
                expect(scope.setSelectedType).toBeDefined();
                scope.setSelectedType();
            });

            it('should call setSelectedType', function () {
                scope.shareAssign = [{
                    "assignmentType": "UHA"
                }];
                scope.hStatus = {
                    selectedStatusType: "AWTRESP"
                }
                expect(scope.setSelectedType).toBeDefined();
                scope.setSelectedType();

                scope.hStatus = {
                    selectedStatusType: "AM"
                }
                expect(scope.setSelectedType).toBeDefined();
                scope.setSelectedType();
            });


            it('should call setSelectedType', function () {
                scope.shareAssign = [{
                    "assignmentType": "RHT"
                }];
                scope.hStatus = {
                    selectedStatusType: "AWTRESP"
                }
                expect(scope.setSelectedType).toBeDefined();
                scope.setSelectedType();
            });

            it('should call setSelectedType', function () {
                scope.shareAssign = [{
                    "assignmentType": "UHT"
                }];
                scope.hStatus = {
                    selectedStatusType: "AM"
                }
                expect(scope.setSelectedType).toBeDefined();
                scope.setSelectedType();
            });

            it('it should get special hearing ', function () {

                successResponse = {
                    data: {
                        valueText: "EXOBSERV",
                        descriptionText: "Examiner observing"
                    }
                };
                expect(scope.specialHearing).toBeDefined();
                scope.specialHearing();

                HttpFactoryDeferred.resolve(successResponse);
                $rootScope.$apply();

            });

            it(' special hearing failureResponse ', function () {
                var failureResponse = {
                    data: {}
                };

                expect(scope.specialHearing).toBeDefined();
                scope.specialHearing();
                HttpFactoryDeferred.reject(failureResponse);
                $rootScope.$apply();
            });

            it(' it should get SND  hearing status ', function () {
                successResponse = {
                    data: {
                        valueText: "HRG",
                        descriptionText: "Hearing reschedule granted"
                    }
                };
                expect(scope.srdHearingStatus).toBeDefined();
                scope.srdHearingStatus();

                HttpFactoryDeferred.resolve(successResponse);
                $rootScope.$apply();

            });

            it(' SND  hearing failureResponse ', function () {
                var failureResponse = {
                    data: {}
                };

                expect(scope.srdHearingStatus).toBeDefined();
                scope.srdHearingStatus();
                HttpFactoryDeferred.reject(failureResponse);
                $rootScope.$apply();
            });


            it('should call reviewHearingTranscriptStatus', function () {

                successResponse = {
                    data: {
                        valueText: "ABN",
                        descriptionText: "Abandoned, process and finalize draft"
                    }
                };
                expect(scope.reviewHearingTranscriptStatus).toBeDefined();
                scope.reviewHearingTranscriptStatus();
                HttpFactoryDeferred.resolve(successResponse);
                $rootScope.$apply();
            });

            it('reviewHearingTranscriptStatus failureResponse ', function () {
                var failureResponse = {
                    data: {}
                };

                expect(scope.reviewHearingTranscriptStatus).toBeDefined();
                scope.reviewHearingTranscriptStatus();
                HttpFactoryDeferred.reject(failureResponse);
                $rootScope.$apply();
            });

            it(' it should call confirmSubmit ', function () {
                scope.fileName = true;
                scope.hStatus = {
                    selectedStatusType: "HG"
                }
                scope.remoteLoc = {
                    selectedCode: "TX"
                }
                controller.userInfo = {
                    userId: "hbui2"
                }
                expect(scope.confirmSubmit).toBeDefined();
                scope.confirmSubmit();

                expect(ngDialog.open.calls.count()).toBe(1);
                var args = ngDialog.open.calls.argsFor(0);
                expect(args).not.toBe(null);
                expect(args.length).toBe(1);
        
                expect(args[0].controller).toBe('confirmENohController');
                expect(typeof args[0].resolve).toBe('object');
                args[0].resolve.eroh();
                args[0].resolve.shareAssign();
                args[0].resolve.hStatus();
                args[0].resolve.pdfFileName();
            });

            it(' it should call confirmSubmit ', function () {
                scope.fileName = true;
                scope.hStatus = {
                    selectedStatusType: "AB",
                    selectedStatusDisplay: "Active",
                }
                scope.eroh = {
                    statusCode: "Active"
                }
                scope.specialHearingType = {
                    selectedStatusType: "Active"
                }
                scope.remoteLoc = {
                    selectedCode: "TX"
                }
                scope.shareAssign = [{
                    priorityIndicator : "Y"
                }];
                controller.userInfo = {
                    userId: "hbui2"
                }
                scope.hearingRoomRoster = {};
                scope.currentAssignment = {};
                scope.genPdfFileName = "file";
                expect(scope.confirmSubmit).toBeDefined();
                scope.confirmSubmit();
            });

        });
    });
})();
