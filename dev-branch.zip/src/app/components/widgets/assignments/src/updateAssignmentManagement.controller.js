(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .directive('ewfFileModel', ['$parse', /* istanbul ignore next */ function ($parse) {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var model = $parse(attrs.ewfFileModel);

          element.bind('change', function () {
            scope.$apply(function () {
              // intentional
            });
          });
        }
      };
    }])

    .directive('ewfOnChange', /* istanbul ignore next */ function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var onChangeFunc = scope.$eval(attrs.ewfOnChange);
          element.bind('change', onChangeFunc);
        }
      };
    })
    .controller('updateAssignmentManagementController', function ($scope, $log, ngDialog, HttpFactory, $timeout, $filter, CONSTANTS, items, readOnly, toastr, $rootScope, $http, $sce, $window) {
      var vm = this;
      var scope = angular.element(document.getElementById('mainTabId')).scope();
      $scope.assignmentInfoTab = false;
      $scope.checkReadOnly = readOnly;
      $rootScope.sharedItems = items;
      $scope.pdfShared = $rootScope.pdfRefresh;
      $scope.rehearingPanelingDate = null;
      $scope.selection = null;
      $scope.ptabDueDateNonEditableUser = false;
      $scope.show = true;
      $scope.uploadFile = true;
      $scope.disableUplaod = true;
      $scope.cancelVd = true;
      $scope.disableeWFButton=false;
      $scope.ngrAssignmentCompleteValue = false;
      $scope.dockType=null;
      $scope.status1 = {};
      $scope.status1.open = false;
      $scope.assigneePlaceholders="Loading assignees...";
      if (scope && scope.vm && scope.vm.userInfo) {
        vm.userInfo = scope.vm.userInfo;
      } else if (scope && scope.userInfo) {
        vm.userInfo = scope.userInfo;
      } else {
        vm.userInfo = {
          displayName: $window.sessionStorage.getItem("workerNumber"),
          userId: $window.sessionStorage.getItem("workerNumber")
        };
      }

      $scope.items = items;
      $scope.refreshGrid = false;
      $scope.showPanelingFooter = false;
      $scope.showRehearingFooter = false;
      $scope.isMergedCase = false;
      $rootScope.isMergedCase = false;
      $scope.originaldata = angular.copy($scope.items);
//       if($scope.originaldata[0].assignmentType == "NGRNOR"){
// $scope.ngrAssignment = true;
//       } else{
//         $scope.ngrAssignment = false; 
//       }
      $scope.closedlg = function () {
        ngDialog.closeAll();

      };
      $scope.data = $scope.items[0].globalMetaData;
      $scope.caseTypes = [];
      $scope.mergedApplListForToastr;
      $scope.caseTypes.push($scope.data.caseType);
      $scope.showCheckbox = $scope.items[0].serialNumber.substring(0, 1) == "9" ? true : false

      function getMergedCaseApplications() {
        HttpFactory.getActions("/mergeCase/leadApplication?appealNumber=" + $scope.items[0].appealNumber)
          .then(function (successResponse) {
            $scope.data.mergedApplicationList = successResponse.data;
            $scope.isMergedCase = $scope.data.mergedApplicationList.length > 0 ? true : false;
            $rootScope.isMergedCase = $scope.data.mergedApplicationList.length > 0 ? true : false;
            var tempList = [];
            angular.forEach($scope.data.mergedApplicationList, function (eachCase) {
              tempList.push(eachCase.applicationNumber);
              if (eachCase.caseType) {
                $scope.caseTypes.push(eachCase.caseType);
              }
            });
            $scope.mergedApplListForToastr = tempList.join(", ");
            $rootScope.mergedApplListForToastr = $scope.mergedApplListForToastr;
            console.log("Before: %o", $scope.caseTypes);
            $scope.data.caseTypes = $scope.caseTypes.filter(function (item, pos, self) {
              return self.indexOf(item) == pos;
            });
            console.log("After: %o", $scope.data.caseTypes);
          }, function (failureResponse) {
            console.log(failureResponse);
          });
      }

      getMergedCaseApplications();

      $scope.closeupdatedlg = function (closedlgFlag) {
        if (closedlgFlag) {
          var openDialogs = ngDialog.getOpenDialogs();
          if (openDialogs.length > 1) {
            ngDialog.close(openDialogs[openDialogs.length - 1], true);
          } else {
            ngDialog.closeAll(true);
          }
        } else {
          $scope.refreshGrid = true;
        }
        $scope.delfailed = false;
      };
      $scope.closedeletedialog = function (closedlg) {
        ngDialog.closeAll();
        $scope.delfailed = false;
      };

      $scope.disableInactiveAssignee = false;

      $scope.moreAssignees = false;

      $scope.getNextAssignmentInfo = function(loginId, nextAssigneeValueText) {
          return HttpFactory.getActions(CONSTANTS.URL.ASSIGNEEUSERS + loginId)
            .then(function (assigneeListSuccess) {
              console.log('assigneeListSuccess: ', assigneeListSuccess);
              var myMangers = assigneeListSuccess.data.managersData;
              var myTeamData = assigneeListSuccess.data.teamData;
              var myGroupData = assigneeListSuccess.data.groupData;
              var workQueueData = assigneeListSuccess.data.workQueueData;
              $scope.allUsers=[];
              addUsersToList(myMangers);
              addUsersToList(myTeamData);
              addUsersToList(myGroupData);
              addUsersToList(workQueueData);
              $scope.backupAllUsers = angular.copy($scope.allUsers);
              $scope.assigneePlaceholders="Select assignee";
              return getDefaultAssigneeObject(nextAssigneeValueText);
            }, function (assigneeListFailure) {
              console.log('assigneeListFailure: ', assigneeListFailure);
              return null;
            });
     }

      function getDefaultAssigneeObject(valueText) {
        for (var i=0; i<$scope.allUsers.length; i++) {
          if ($scope.allUsers[i].assigneeNumberText===valueText) {
            return $scope.allUsers[i];
          }
        }
      }

      /* istanbul ignore next*/
      $scope.getAssignedTo = function () {
        HttpFactory.getActions(CONSTANTS.URL.ASSIGNEEUSERS + vm.userInfo.userId)
          .then(function (successResponse) {
            $scope.myMangers = successResponse.data.managersData;
            $scope.myTeamData = successResponse.data.teamData;
            $scope.myGroupData = successResponse.data.groupData;
            $scope.workQueueData = successResponse.data.workQueueData;
            $scope.ptabDueDateNonEditableUser = successResponse.data.ptabDueDateNonEditableUser;

            if ($scope.myGroupData === null) {
              $scope.moreAssignees = true;
            } else {
              $scope.groupLength = $scope.myGroupData.length;
              if ($scope.groupLength === 0) {
                $scope.moreAssignees = true;
              }
            }

            $scope.foundAssigne = false;
            angular.forEach($scope.myMangers, function (item) {
              if (item.assigneeNumberText === $scope.updateAssignment.assignee) {
                $scope.foundAssigne = true;
                $scope.currentAssignee = {
                  assigneeFullNameText: item.assigneeFullNameText,
                  activeCaseCount: item.activeCaseCount,
                  assigneeStatus: item.assigneeStatus,
                  assigneeNumberText: $scope.updateAssignment.assignee
                };
              }
            });
            angular.forEach($scope.myTeamData, function (item) {
              if (item.assigneeNumberText === $scope.updateAssignment.assignee) {
                $scope.foundAssigne = true;
                $scope.currentAssignee = {
                  assigneeFullNameText: item.assigneeFullNameText,
                  activeCaseCount: item.activeCaseCount,
                  assigneeStatus: item.assigneeStatus,
                  assigneeNumberText: $scope.updateAssignment.assignee
                };
              }
            });
            angular.forEach($scope.myGroupData, function (item) {
              if (item.assigneeNumberText === $scope.updateAssignment.assignee) {
                $scope.foundAssigne = true;
                $scope.currentAssignee = {
                  assigneeFullNameText: item.assigneeFullNameText,
                  activeCaseCount: item.activeCaseCount,
                  assigneeStatus: item.assigneeStatus,
                  assigneeNumberText: $scope.updateAssignment.assignee
                };
              }
            });
            angular.forEach($scope.workQueueData, function (item) {
              if (item.assigneeNumberText === $scope.updateAssignment.assignee) {
                $scope.foundAssigne = true;
                $scope.currentAssignee = {
                  assigneeFullNameText: item.assigneeFullNameText,
                  activeCaseCount: item.activeCaseCount,
                  assigneeStatus: item.assigneeStatus,
                  assigneeNumberText: $scope.updateAssignment.assignee
                };
              }
            });
            $scope.scrollDisable = false;
            if (!$scope.foundAssigne) {
              $scope.currentAssignee = {
                assigneeFullNameText: 'Not assigned',
                activeCaseCount: '',
                assigneeStatus: '',
                assigneeNumberText: ""
              };
            }
            $scope.originalcurrentAssignee = angular.copy($scope.currentAssignee);
            $scope.change($scope.currentAssignee);
          },
            function (failureResponse) {
              $scope.currentAssignee = {
                assigneeFullNameText: 'Not assigned',
                activeCaseCount: '',
                assigneeStatus: '',
                assigneeNumberText: ""
              };
              $scope.myAssigne = {};
              $scope.scrollDisable = true;
              $scope.originalcurrentAssignee = angular.copy($scope.currentAssignee);
              $log.info(failureResponse);
            });
      };
      $scope.getAssignedTo();

      function addUsersToList(users) {
        angular.forEach(users, function(aUser) {
          $scope.allUsers.push(aUser);
        });
      }
      $scope.extraData = true;
      $scope.moreAssigneesData = function () {
        $scope.extraData = false;
        $scope.moreAssignees = true;
        $scope.myGroup = $scope.myGroupData;
      };


      $scope.tempArray = [];
      /* istanbul ignore next*/
      $scope.change = function (content) {
        $scope.tempArray.push(content);
        var lengthOftempArray = $scope.tempArray.length - 1;
        $scope.oldObj = $scope.tempArray[lengthOftempArray - 1];
        $scope.newObj = $scope.tempArray[lengthOftempArray];
        if (content.assigneeStatus === "InActive") {
          $scope.disableInactiveAssignee = true;
        } else {
          $scope.disableInactiveAssignee = false;
        }
        if (angular.isNumber($scope.updateAssignment.assignmentCompletionDtdefined) || angular.isDate($scope.updateAssignment.assignmentCompletionDtdefined)) {
          if (!angular.equals($scope.Assignedtoforassignmnt.trim(), content.assigneeFullNameText.trim())) {

            ngDialog.openConfirm({
              template: 'app/components/widgets/assignments/src/whoCompleted.html',
              controller: 'whoCompletedController',
              controllerAs: 'vm',
              width: '25%',
              showClose: false,
              closeByEscape: false,
              closeByDocument: false
            }).then(function () {
              $scope.currentAssignee.assigneeFullNameText = $scope.newObj.assigneeFullNameText;
              $scope.currentAssignee.assigneeStatus = $scope.newObj.assigneeStatus;
              $scope.currentAssignee.activeCaseCount = $scope.newObj.activeCaseCount;
              $scope.currentAssignee.assigneeStatus = $scope.newObj.assigneeStatus;
              $scope.currentAssignee.assigneeNumberText = $scope.newObj.assigneeNumberText;
              $scope.checksave();
              if ($scope.newObj.assigneeStatus === "InActive") {
                $scope.disableInactiveAssignee = true;
              } else {
                $scope.disableInactiveAssignee = false;
              }

            }, function () {
              $scope.currentAssignee.assigneeFullNameText = $scope.oldObj.assigneeFullNameText;
              $scope.currentAssignee.assigneeStatus = $scope.oldObj.assigneeStatus;
              $scope.currentAssignee.assigneeStatus = $scope.oldObj.assigneeStatus;
              $scope.currentAssignee.activeCaseCount = $scope.oldObj.activeCaseCount;
              $scope.currentAssignee.assigneeStatus = $scope.oldObj.assigneeStatus;
              $scope.currentAssignee.assigneeNumberText = $scope.oldObj.assigneeNumberText;
              $scope.checksave();
              if ($scope.oldObj.assigneeStatus === "InActive") {
                $scope.disableInactiveAssignee = true;
              } else {
                $scope.disableInactiveAssignee = false;
              }

            });

          } else {

            $scope.currentAssignee.assigneeFullNameText = content.assigneeFullNameText;
            $scope.currentAssignee.activeCaseCount = content.activeCaseCount;
            $scope.currentAssignee.assigneeStatus = content.assigneeStatus;
            $scope.currentAssignee.assigneeNumberText = content.assigneeNumberText;
            $scope.checksave();
          }
        } else {
          $scope.currentAssignee.assigneeFullNameText = content.assigneeFullNameText;
          $scope.currentAssignee.activeCaseCount = content.activeCaseCount;
          $scope.currentAssignee.assigneeStatus = content.assigneeStatus;
          $scope.currentAssignee.assigneeNumberText = content.assigneeNumberText;
          $scope.checksave();
        }
      };


      $scope.updateAssignment = {};
      if ($scope.items[0].completionDate === null) {
        $scope.completionDatedefined = null;
      } else {
        $scope.completionDatedefined = parseInt($scope.items[0].completionDate, CONSTANTS.GLOBAL.RADIX);
      }
      if (angular.isNumber($scope.completionDatedefined)) {
        $scope.updateAssignment.assignmentCompletionDtdefined = $scope.completionDatedefined;
        $scope.updateAssignment.assignmentCompletionDt = $scope.completionDatedefined;
        $scope.displyPastcompdate = true;
      } else {
        $scope.updateAssignment.assignmentCompletionDt = null;
        $scope.displyPastcompdate = false;
      }

      $scope.updateAssignment.title = $scope.items[0].title;
      $scope.updateAssignment.description = $scope.items[0].description;
      $scope.updateAssignment.dueDate = parseInt($scope.items[0].dueDate, CONSTANTS.GLOBAL.RADIX);
      $scope.dueDatetoCheckbusinessVallidation = angular.copy($scope.updateAssignment.dueDate);
      $scope.updateAssignment.assignmentIdentifier = $scope.items[0].assignmentIdentifier;
      $scope.updateAssignment.noteText = "";
      $scope.updateAssignment.serialNumber = $scope.items[0].serialNumber;
      $scope.updateAssignment.appealNumber = $scope.items[0].appealNumber;
      $scope.updateAssignment.assignmentTypeDescription = $scope.items[0].assignmentTypeDescription;
      $scope.updateAssignment.activeIndicator = $scope.items[0].activeIndicator;
      $scope.updateAssignment.completionDate = parseInt($scope.items[0].completionDate, CONSTANTS.GLOBAL.RADIX);
      $scope.updateAssignment.assigneeRoleDescription = $scope.items[0].assigneeRoleDescription;
      $scope.updateAssignment.assignmentLastModifiedUids = vm.userInfo.userId;
      $scope.updateAssignment.assignee = $scope.items[0].assignee;
      $scope.updateAssignment.assignmentCreateTs = $scope.items[0].audit.createTimestamp;
      $scope.updateAssignment.caseType = $scope.items[0].caseType;
      $scope.updateAssignment.assignmentType = $scope.items[0].assignmentType;
      $scope.updateAssignment.sequenceNumber = $scope.items[0].sequenceNumber;
      $scope.updateAssignment.assignor = $scope.items[0].assignor;
      $scope.updateAssignment.assignmentLockControlNo = $scope.items[0].audit.lockControlNumber;
      $scope.updateAssignment.priorityIndicator = $scope.items[0].priorityIndicator;
      $scope.updateAssignment.createUserIdentifier = $scope.items[0].audit.createUserIdentifier;
      $scope.updateAssignment.pageNumberQuantity = $scope.items[0].pageNumberQuantity;


      $scope.lables = $scope.items[0].standardAssignmentType;

      if ($scope.items[0].standardAssignmentType.MAILDECISION) {
        $scope.lables.VERIFYDECISION = "Verify decision";
      }
      // if($scope.items[0].standardAssignmentType.miscellaneousDoc){
      //   $scope.lables.MAILDECISION = "Mail decision";
      // }
      /* REMOVE BELOW ONCE INTEGRATED WITH SERVICES */
      // $scope.lables = {
      //   "MAILRD": "Enter external court decision",
      //   "ASSIGNMENTINFO": "Assignment Info"
      // };
      /* REMOVE ABOVE ONCE INTEGRATED WITH SERVICES */
      var keys = Object.keys($scope.lables);
      $scope.numOfTabs = keys.length;
      $scope.urltemplate = {};
      $scope.sortAssignmentType = [];
      angular.forEach($scope.lables, function (value, key) {
   /*   	if (value=== 'Mail decision') {
      		$scope.sortAssignmentType.push({
          	key: "VERIFYDECISION",
          	value: "Verify decision"
        	});
      	}*/
        if (value === 'Create panel' || value === 'Update panel' || value === 'Create subsequent decision panel') {
          $scope.showPanelingFooter = true;
          $scope.showRehearingFooter = false;
        }
        if (value === 'Create rehearing panel') {
          $scope.showPanelingFooter = false;
          $scope.showRehearingFooter = true;
        }
        if (key==='VERIFYDECISION') {
          $scope.sortAssignmentType.unshift({
            key: key,
            value: value
          });
        } else {
          $scope.sortAssignmentType.push({
            key: key,
            value: value
          });
        }
      });

      $scope.sortAssignmentType = $scope.sortAssignmentType.sort(function (a, b) {
        return b.key.localeCompare( a.key );
    });



      if ($scope.sortAssignmentType[0].value === "Create decision draft") {
        if (items[0].assigneeRoleCode.indexOf('Judge') > -1) {
          $scope.sortAssignmentType[0].value = "Enter appeal decision action";
          //        $scope.oneZeroOneRulingTooltip =  CONSTANTS.ONEZEROONERULING.tooltip;
        }
      }
      if ($scope.sortAssignmentType[0].value === "Create rehearing decision draft") {
        if (items[0].assigneeRoleCode.indexOf('Judge') > -1) {
          $scope.sortAssignmentType[0].value = "Enter rehearing appeal decision action";
        }
      }
      if ($scope.sortAssignmentType[0].value === "Create subsequent decision draft") {
        if (items[0].assigneeRoleCode.indexOf('Judge') > -1) {
          $scope.sortAssignmentType[0].value = "Enter Subsequent Decision draft";
        }
      }
      if ($scope.sortAssignmentType[0].value === "Document review") {
        if (items[0].assigneeRoleCode.indexOf('Judge') > -1) {
          $scope.sortAssignmentType[0].value = "Decision draft in circulation";
        }
      }
      if ($scope.sortAssignmentType[0].value === "Review rehearing decision draft") {
        if (items[0].assigneeRoleCode.indexOf('Judge') > -1) {
          $scope.sortAssignmentType[0].value = "Rehearing decision draft in circulation";
        }
      }
      if ($scope.sortAssignmentType[0].value === "Review subsequent decision draft") {
        if (items[0].assigneeRoleCode.indexOf('Judge') > -1) {
          $scope.sortAssignmentType[0].value = "Subsequent decision draft in circulation";
        }
      }
      if ($scope.sortAssignmentType[0].value === "Create subsequent decision panel" && $window.sessionStorage.getItem("panelExists") === "true") {
        $scope.sortAssignmentType[0].value = "Update subsequent decision panel";
      }
      if ($scope.sortAssignmentType[0].value === "Create petition draft") {
          $scope.sortAssignmentType[0].value = "Create petition decision draft";
      }
      if ($scope.sortAssignmentType[0].value === "Petition Review") {
        $scope.sortAssignmentType[0].value = "Review petition decision for mailing";
      }
      // if ($scope.sortAssignmentType[0].value === "Assignment info") {
      //   $scope.sortAssignmentType[0].value = "PL mail petition decision";
      // }

      if (Object.keys($scope.lables).length - 1 < 1) {
        $scope.htmlToLoad = "ASSIGNMENTINFO";
        $scope.urltemplate.url = "app/components/widgets/assignments/src/" + $scope.htmlToLoad + ".html";
      } else {
        /* istanbul ignore next*/
        angular.forEach(Object.keys($scope.lables), function (eachLable) {
          if (eachLable !== "ASSIGNMENTINFO" && eachLable !== "MAILDECISION") {
            $scope.disableDelete = true;
            $scope.htmlToLoad = eachLable;
            $scope.urltemplate.url = "app/components/widgets/assignments/src/" + $scope.htmlToLoad + ".html";
          }
        });
      }
      $scope.updateAssignment.docketingNotice = $scope.items[0].standardAssignmentType[0];
      if ($scope.updateAssignment.docketingNotice !== 'Docketing notice') {
        $scope.updateAssignment.assignmentInfo = "Assignment info";
      } else {
        $scope.updateAssignment.docketingNotice = 'Docketing notice';
      }
      $scope.currentAssignee = {};
      $scope.currentAssignee.assigneeNumberText = $scope.updateAssignment.assignee;

      $scope.readyToSaveDate = true;
      $scope.checkDueDate = function () {
        $scope.OnBlurProgress = true;
        $timeout(function () {
          $scope.checksave();
          $scope.OnBlurProgress = false;
          if (angular.isUndefined($scope.updateAssignment.dueDate) || isNaN($scope.updateAssignment.dueDate)) {
            $scope.showErrorMsgDueDate = true;
            $scope.errorMessageDueDate = "The due date cannot be empty. ";
            $scope.readyToSaveDate = false;
          } else {
            $scope.readyToSaveDate = true;
            $scope.showErrorMsgDueDate = false;
          }
        }, 400);
      };
      $scope.readyToSaveTitle = true;
      $scope.checkLengthofUpdateTitletx = function () {
        $scope.checksave();
        if (angular.isUndefined($scope.updateAssignment.title) || $scope.updateAssignment.title < 1) {
          $scope.showErrorMsgTitletx = true;
          $scope.errorMessageTitletx = "The assignment title cannot be empty.";
          $scope.readyToSaveTitle = false;
        } else {
          $scope.readyToSaveTitle = true;
          $scope.showErrorMsgTitletx = false;
        }
      };
      $scope.checkAssignedTotx = function (assigneeto) {
        if (assigneeto) {
          $scope.showAssignedTotx = false;
          $scope.readyToSave = true;
        } else {
          $scope.showAssignedTotx = true;
          $scope.errorAssignedTotx = "The assigned to cannot be empty.";
          $scope.readyToSave = false;

        }

      };
      
      $scope.updatePdfName = function(pdfName, genPdfFileNameForDoc, contentPdf, fileExtractContent) {
    $scope.originalSelectedFile =fileExtractContent;
        $scope.showConvertedPdfName = genPdfFileNameForDoc;
        if($scope.showConvertedPdfName == undefined){
          $scope.showConvertedPdfName =pdfName;
        }
        $scope.pdfNameForDoc =pdfName;
        $scope.fileContentForConvertedPdf = contentPdf;
      };
      
      
      
      $scope.updateAssignmentcall = function (saveflag) {
       
        if ($scope.updateAssignment.assignmentCompletionDt === null) {
          $scope.readyToSavecompletiondt = true;
          $scope.updateAssignment.completionDate = $scope.updateAssignment.assignmentCompletionDt;
        } else {
          $scope.updateAssignment.completionDate = new Date($scope.updateAssignment.assignmentCompletionDt).getTime();
        }
        $scope.updateAssignment.dueDate = new Date($scope.updateAssignment.dueDate).getTime();

        if ($scope.fileInfo) {
          $scope.artifactName = $scope.fileInfo.name.replace(/\"/g, "")
        } else if (document.getElementById("fileName")) {
          $scope.artifactName = document.getElementById("fileName").value;
        }
        if($scope.artifactName ==undefined){
          $scope.artifactName = null;
        }
if( $scope.artifactName ==undefined){
$scope.artifactName = null;
}
if($scope.ngrAssignmentCompleteValue) {
$scope.updateAssignment.completionCode = "Complete";
$scope.updateAssignment.completionDate = new Date().getTime();
}
        $scope.updateAssignmntdata = {
          "assignmentType": $scope.updateAssignment.assignmentType,
          "assignee": $scope.currentAssignee.assigneeNumberText,
          "serialNumber": $scope.updateAssignment.serialNumber,
          "title": $scope.updateAssignment.title,
          "description": $scope.updateAssignment.description,
          "dueDate": $scope.updateAssignment.dueDate,
          "completionDate": $scope.updateAssignment.completionDate,
          "completionCode": $scope.updateAssignment.completionCode,
          "caseType": $scope.updateAssignment.caseType,
          "appealNumber": $scope.updateAssignment.appealNumber,
          "sequenceNumber": $scope.updateAssignment.sequenceNumber,
          "notes": $scope.updateAssignment.noteText,
          "priorityIndicator": ($scope.updateAssignment.priorityIndicator) ? 'Y' : 'N',
          "assignmentIdentifier": $scope.updateAssignment.assignmentIdentifier,
          "assignor": $scope.updateAssignment.assignor,
          "activeIndicator": $scope.updateAssignment.activeIndicator,
          "artifactTitleName": $scope.artifactName,
          "pageNumberQuantity":$scope.updateAssignment.pageNumberQuantity,
          "audit": {
            "createUserIdentifier": $scope.updateAssignment.createUserIdentifier,
            "lastModifiedUserIdentifier": $scope.updateAssignment.assignmentLastModifiedUids,
            "lockControlNumber": $scope.updateAssignment.assignmentLockControlNo,
            "createTimestamp": $scope.updateAssignment.assignmentCreateTs,
            "lastModifiedTimestamp": new Date().getTime()
          }
        };
        // console.log("Update assignment data:", $scope.updateAssignmntdata);
        $scope.updateAssgnmnt($scope.updateAssignmntdata, saveflag);
      };

      $scope.isCompletiondate = false;
      $scope.isUpdateSaved = false;

      /* istanbul ignore next: toaster error*/
      $scope.updateAssgnmnt = function (data, saveflag) {
        if ($scope.updateAssignment.caseType === "EWF") {
          if (!$scope.ewfCompletedFlag && $scope.updateAssignment.assignmentCompletionDt != null && angular.isDefined($scope.updateAssignment.assignmentCompletionDt)) {
            ngDialog.open({
              template: "app/components/widgets/assignments/src/eWFNotCompleted.html",
              scope: $scope,
              width: '30%',
              showClose: false,
              closeByEscape: false,
              closeByDocument: false
            });
            return;
          }
        }
        if ($scope.readyToSaveDate === true && $scope.readyToSavecompletiondt === true && $scope.readyToSaveTitle === true) {
          HttpFactory.putActions(CONSTANTS.URL.UPDATE_ASSIGNMENT, data)
            .then(function (successResponse) {
              $scope.updateAssignment.assignmentLockControlNo = successResponse.data.audit.lockControlNumber;
              $scope.getHistory();
              $scope.isUpdateSaved = true;
              $scope.disablesave = true;

              toastr.clear();

              toastr.error(successResponse.data.message, {
                iconClass: 'toast-success'
              });

              if ($scope.isMergedCase) {
                toastr.success(successResponse.data.title + " assignments for " + $scope.mergedApplListForToastr + " have been closed.", {
                  iconClass: 'toast-success'
                });
              }

              // "<Assignment title> assignments for <list of merged applications> have been closed

              $scope.updateAssignment.noteText = "";
              if (angular.isUndefined($scope.updateAssignment.assignmentCompletionDt) || $scope.updateAssignment.assignmentCompletionDt === null) {
                $scope.updateAssignment.toDisable = false;
                $scope.isCompletiondate = false;

              } else {
                $scope.updateAssignment.toDisable = true;
                $scope.isCompletiondate = true;
                $scope.checkCompletiondate = function () {
                  return $scope.isCompletiondate;
                };
              }

              $scope.closeupdatedlg(saveflag);
            }, function (failureResponse) {
              $scope.disableeWFButton=false;
              toastr.clear();
              toastr.warning(failureResponse.data.message, {
                iconClass: 'toast-warning'
              });
              $scope.closeupdatedlg();

            });
        }
      };

      $scope.assignedrole = function () {

        return HttpFactory.getActions('/user-management/users?employeeNumberText=' + $scope.updateAssignment.assignee)
          .then(function (successResponse) {

            $scope.roleforassignmnt = successResponse.data[0].userRoles[0].roleCode;
            $scope.Assignedtoforassignmnt = successResponse.data[0].assigneeFullNameText;
            if ($scope.content) {
              $scope.content.assigneeFullNameText = $scope.Assignedtoforassignmnt;
            }
            $scope.myusrRole = $scope.roleforassignmnt;
            if ($scope.roleforassignmnt) {
              $scope.showAssignmrentMsgRole = false;
            }
          },
            function (failureResponse) {
              toastr.clear();
            });
      };
      $scope.assignedrole();
      $scope.currentAssignee.assigneeFullNameText = $scope.Assignedtoforassignmnt;
      $scope.originalduedt = angular.copy($scope.updateAssignment.dueDate);
      $scope.originalpriorityIn = angular.copy($scope.updateAssignment.priorityIndicator);
      $scope.originaltaskDescTx = angular.copy($scope.updateAssignment.description);
      $scope.originalnoteText = angular.copy($scope.updateAssignment.noteText);
      $scope.originaltaskTitleTx = angular.copy($scope.updateAssignment.title);
      $scope.originalRole = angular.copy($scope.updateAssignment.assigneeRoleDescription);
      $scope.originalAssignedto = angular.copy($scope.currentAssignee.assigneeFullNameText);
      $scope.originalCompDt = angular.copy($scope.updateAssignment.assignmentCompletionDt);

      $scope.originalPageNumberQuantity = angular.copy($scope.updateAssignment.pageNumberQuantity);

      $scope.assignContent = true;

      /* istanbul ignore next*/
      $scope.cancelupdateAssignDialog = function (currentElement) {
        // var rehearing = angular.element(document.getElementById('rehearingScope')).scope();
        // if (rehearing !== undefined && rehearing !== null) {
        //   var checkAbandon = $scope.checkAbandonChangesForRehearing(rehearing, currentElement);
        //   if (checkAbandon) {
        //     return;
        //   }
        // }
        if ($scope.cancelVd && $scope.items[0].assignmentType === "VD") {

          HttpFactory.deleteActions('/assignments/' + $scope.updateAssignment.assignmentIdentifier + '/' + vm.userInfo.userId)
            .then(function (successResponse) {

              // if (angular.isDefined(successResponse.data.message)) {

              ngDialog.closeAll(true);

              // }
            }, function (failureResponse) {
              $log.info(failureResponse);
              if (angular.isDefined(failureResponse.data.message)) {
                toastr.clear();
                toastr.error("Delete failed " + failureResponse.data.message, {
                  iconClass: 'toast-danger'
                });
              } else {
                toastr.clear();
                toastr.error("delete failed", {
                  iconClass: 'toast-danger'
                });
              }

            });

        }

        if ($scope.updateAssignment.noteText === null) {
          $scope.updateAssignment.noteText = '';
        }

        if ($scope.OnBlurProgress) {
          return;
        }

        if($scope.items[0].assignmentType === "CRR"){
          HttpFactory.deleteActions('/assignments/' + $scope.items[0].assignmentIdentifier + '/' + $scope.items[0].audit.createUserIdentifier)
          .then(function (successResponse) {
            ngDialog.closeAll($scope.refreshGrid);
            sessionStorage.removeItem("selectedFileName");
            sessionStorage.removeItem("filesuccessResponse");
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
        }

        if (!$scope.isUpdateSaved && (!angular.equals($scope.updateAssignment.dueDate, $scope.originalduedt) ||
          !angular.equals($scope.originalCompDt, $scope.updateAssignment.assignmentCompletionDt) ||
          ($scope.updateAssignment.assignee !== $scope.currentAssignee.assigneeNumberText) ||
          !angular.equals($scope.updateAssignment.priorityIndicator, $scope.originalpriorityIn) ||

          !angular.equals($scope.originaltaskDescTx, $scope.updateAssignment.description) ||
          !angular.equals($scope.originaltaskTitleTx, $scope.updateAssignment.title) ||
          !angular.equals($scope.updateAssignment.noteText, $scope.originalnoteText) ||
          !angular.equals($scope.originalHotelingInd, $scope.hotelingInd) ||
          ($scope.isCompletiondate !== false))) {
          ngDialog.open({
            template: 'app/components/widgets/assignments/src/cancelUpdateAssignment.html',
            controller: 'CancelUpdateAssignmentController',
            controllerAs: 'vm',
            width: '25%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              currentElement: function () {
                return currentElement;
              }

            }

          }).closePromise.then(function (revertedData) {
            if (revertedData.value === 'yes') {
              $scope.updateAssignment.title = items[0].title;
              $scope.updateAssignment.priorityIndicator = items[0].priorityIndicator;

              $scope.currentAssignee.assigneeFullNameText = $scope.Assignedtoforassignmnt;
              $scope.updateAssignment.dueDate = parseInt(items[0].dueDat, CONSTANTS.GLOBAL.RADIXe);
              if (items[0].completionDate === null) {
                $scope.updateAssignment.completionDatedefined = items[0].completionDate;
                $scope.updateAssignment.assignmentCompletionDt = items[0].completionDate;
              } else {
                $scope.updateAssignment.completionDatedefined = parseInt(items[0].completionDate, CONSTANTS.GLOBAL.RADIX);
                $scope.updateAssignment.assignmentCompletionDt = parseInt(items[0].completionDate, CONSTANTS.GLOBAL.RADIX);
              }
              $scope.updateAssignment.description = items[0].description;
              $scope.updateAssignment.noteText = "";
              $scope.updateAssignment.assignee = items[0].assignee;
              $scope.currentAssignee.assigneeNumberText = $scope.updateAssignment.assignee;
              $scope.toCheckTabs(currentElement);
            }


          });
        } else {
          $scope.toCheckTabs(currentElement);
          if (currentElement === 'cancel') {
            ngDialog.closeAll($scope.refreshGrid);
            sessionStorage.removeItem("selectedFileName");
            sessionStorage.removeItem("filesuccessResponse");
          }
        }      

      };

      /* istanbul ignore next*/
      $scope.toCheckTabs = function (currentElement) {
        $scope.showRehearingFooter = false;
        $scope.showPanelingFooter = false;
        $scope.htmlToLoad = currentElement;
        $scope.disableDelete = true;
        $scope.urltemplate.url = "app/components/widgets/assignments/src/" + $scope.htmlToLoad + ".html";
        if (currentElement === "ASSIGNMENTINFO") {
          $scope.disableDelete = false;
        }
        if (currentElement === "CRP" || currentElement === "REHEARINGPANELING" || currentElement === "PANELING") {
          $scope.showRehearingFooter = true;
        }
      };
      $scope.opendeleteAssignmentModal = function () {

        ngDialog.open({
          template: "app/components/widgets/assignments/src/deleteAssignmentmentModal.html",
          controller: 'deleteAssignmentmentModalController',
          scope: $scope,
          width: '30%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            ptabId: function () {
              return $scope.updateAssignment.assignmentIdentifier;
            },
            wrkNumbr: function () {
              return vm.userInfo.userId;
            },
            activeIndicator: function () {
              return $scope.updateAssignment.activeIndicator;
            }
          }


        });
      };
      $scope.disablesave = true;
      $scope.readyToSavecompletiondt = true;
      $scope.checkTimedSave = function () {
        $timeout(function () {
          $scope.checkComplitiondate();
        }, 400);
      };
      $scope.checkComplitiondate = function () {
        if (angular.isDate($scope.updateAssignment.assignmentCompletionDt)) {
          $scope.showErrorMsgCompletionDate = false;
          $scope.readyToSavecompletiondt = true;
        } else if (angular.isUndefined($scope.updateAssignment.assignmentCompletionDt)) {
          var compDateElementValue = document.getElementById("reportFromCompletionDate");
          if (compDateElementValue) {
            if (compDateElementValue.value === "") {
              $scope.readyToSavecompletiondt = true;
              $scope.showErrorMsgCompletionDate = false;
            } else {
              $scope.errorMessageCompletionDate = "The completion date is not valid.";
              $scope.showErrorMsgCompletionDate = true;
              $scope.readyToSavecompletiondt = false;
            }
          }
        }
        $scope.checksave();
      };
      $scope.checksave = function () {

        if (!angular.equals($scope.updateAssignment.dueDate, $scope.originalduedt) ||
          !angular.equals($scope.updateAssignment.priorityIndicator, $scope.originalpriorityIn) ||
          !angular.equals($scope.originaltaskDescTx, $scope.updateAssignment.description) ||
          !angular.equals($scope.originaltaskTitleTx, $scope.updateAssignment.title) ||
          !angular.equals($scope.originalCompDt, $scope.updateAssignment.assignmentCompletionDt) ||
          !angular.equals($scope.updateAssignment.noteText, $scope.originalnoteText) || 
          !angular.equals($scope.updateAssignment.pageNumberQuantity, $scope.originalPageNumberQuantity)
          ||
          ($scope.updateAssignment.assignee !== $scope.currentAssignee.assigneeNumberText)) {
          $scope.disablesave = false;
        } else {
          $scope.disablesave = true;
        }

      };
      $scope.dateConverter = function (recievedDate) {
        if (recievedDate != null) {
          return new Date(recievedDate).toLocaleDateString();
        } else {
          return null;
        }
      };
      $scope.ewfCompleted = function () {
        $scope.eWF('COMPLETE');
      };
      $scope.updateEWF = function () {
        $scope.eWF('');

      };
      $scope.eWF = function (completionCode) {
        $scope.disableeWFButton=true;
        $scope.ewfCompletedFlag = true;
        $scope.updateAssignment.completionCode = completionCode;
        $scope.updateAssignment.assignmentCompletionDt = new Date().getTime();
        $scope.assignmentUpdateSave(true);
      };

      var ngrSelectedValue=-1;
      $scope.ngrResponseSelected = function(value) {
        ngrSelectedValue=value;
        $scope.ngrResponse=true;
      }

      $scope.ngrAssignmentComplete= function(){
        if (ngrSelectedValue >=0) {
          $rootScope.ngrOpenCreateAssignment=ngrSelectedValue;
        }

        console.info($scope.ticklerCreateAssignment);
        $scope.ngrAssignmentCompleteValue = true;
        $scope.assignmentUpdateSave(true);
      }
      $scope.getEwfDetails = function () {
        HttpFactory.getActions("/case-information/phases?serialNumber=" + $scope.updateAssignment.serialNumber + "&appealNumber=" + $scope.updateAssignment.appealNumber)
          .then(function (successResponse) {

            $scope.casePhase = successResponse.data;
            $scope.eWFptabReceiptDate = $scope.dateConverter($scope.casePhase.preAppealInfo.ptabReceivedDate);


            $scope.eWFCaseType = $scope.casePhase.masterDocketInfo.caseType;
            $scope.eWFDocketingNoticeDate = $scope.dateConverter($scope.casePhase.masterDocketInfo.docketingNoticeDate);

          }, function (failureResponse) {
            toastr.error(failureResponse, {
              iconClass: 'toast-danger'
            });
          });
      };
      $scope.timedCompdate = function () {
        $scope.OnBlurProgress = true;
        $timeout(function () {
          $scope.checkCompdate();

        }, 400);
      };
      $scope.checkCompdate = function () {
        $scope.OnBlurProgress = false;
        if (angular.isDate($scope.updateAssignment.assignmentCompletionDtdefined)) {
          $scope.showErrorMsgCompletionDatedefined = false;
          $scope.readyToSavecompletiondt = true;
          $scope.updateAssignment.assignmentCompletionDt = $scope.updateAssignment.assignmentCompletionDtdefined;
        } else if (angular.isUndefined($scope.updateAssignment.assignmentCompletionDtdefined)) {
          var definedCompDate2 = document.getElementById("reportFromCompletionDatedefined");
          if (definedCompDate2) {
            if (definedCompDate2.value === "") {
              $scope.readyToSavecompletiondt = true;
              $scope.showErrorMsgCompletionDatedefined = false;
              ngDialog.open({
                template: 'app/components/widgets/assignments/src/completedDateVerification.html',
                width: '25%',
                controller: 'completedDateVerificationController',
                controllerAs: 'vm',
                showClose: false,
                closeByEscape: false,
                closeByDocument: false,
                resolve: {
                  definedCompdate: function () {
                    return $scope.completionDatedefined;
                  }
                }
              }).closePromise.then(function (newDate) {
                $scope.updateAssignment.assignmentCompletionDt = newDate.value;
                $scope.updateAssignment.assignmentCompletionDtdefined = newDate.value;
                $scope.checksave();
              });
            } else {
              $scope.errorMessageCompletionDatedefined = "The completion date is not valid.";
              $scope.showErrorMsgCompletionDatedefined = true;
              $scope.readyToSavecompletiondt = false;
              $scope.updateAssignment.assignmentCompletionDt = $scope.updateAssignment.assignmentCompletionDtdefined;
            }
          }

        }
        $scope.checksave();
      };

      $scope.getHistory = function () {
        HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTHISTORY + $scope.updateAssignment.assignmentIdentifier)
          .then(function (successResponse) {
            $scope.myData = successResponse.data;

          }, function (failureResponse) {
            $log.info(failureResponse);

          });

      };

      /* istanbul ignore next : toaster error */
      $scope.validateBusinnessdateSelected = function (saveflag) {
        $scope.readyToSaveBussinessDate = false;
        var previousDate = new Date($scope.updateAssignment.dueDate).setHours(0, 0, 0, 0);
        return HttpFactory.getActions(CONSTANTS.URL.HOLIDAYCHECKS + "selectedDate=" + new Date($scope.updateAssignment.dueDate).setHours(0, 0, 0, 0))
          .then(function (successResponse) {
            var ResponseDate = successResponse;
            if (ResponseDate.data.isValid !== true) {

              ngDialog.open({
                template: 'app/components/widgets/assignments/src/dateVerification.html',
                width: '25%',
                controller: 'dateVerificationController',
                controllerAs: 'vm',
                showClose: false,
                closeByEscape: false,
                closeByDocument: false,
                resolve: {
                  prevDate: function () {
                    return previousDate;
                  }
                }
              }).closePromise.then(function (modifiedDate) {
                if (angular.isNumber(modifiedDate.value)) {
                  $scope.updateAssignment.dueDate = modifiedDate.value;
                  $scope.readyToSaveBussinessDate = true;
                  $scope.updateAssignmentcall(saveflag);
                } else {
                  document.getElementById("reportDueDate").focus();
                  $scope.updateAssignment.dueDate = previousDate;
                }
              });

            } else {
              $scope.readyToSaveBussinessDate = true;
              $scope.updateAssignmentcall(saveflag);
            }
          },
            function (failureResponse) {
              return failureResponse;
            });
      };

      $scope.assignmentUpdateSave = function (saveflag) {
        if ($scope.OnBlurProgress) {
          return;
        }
        if (new Date($scope.dueDatetoCheckbusinessVallidation).getTime() != new Date($scope.updateAssignment.dueDate).getTime()) {
          $scope.validateBusinnessdateSelected(saveflag);
        } else {
          $scope.updateAssignmentcall(saveflag);
        }
      };

      /*dismissal*/
      $scope.getDismissalList = function () {
        HttpFactory.getActions(CONSTANTS.URL.DISMISSAL)
          .then(function (successResponse) {
            $scope.dismissalList = successResponse.data;
            $scope.valueText;
          }, function (failureResponse) {
            return failureResponse;
          });
      };

      /*remand*/
      $scope.getRemandList = function () {
        HttpFactory.getActions(CONSTANTS.URL.REMAND)
          .then(function (successResponse) {
            $scope.remandList = successResponse.data;
            $scope.valueText;
          }, function (failureResponse) {
            return failureResponse;
          });
      };

      /*edit remand*/
      $scope.getEditRemandList = function () {
        HttpFactory.getActions(CONSTANTS.URL.EDITREMAND)
          .then(function (successResponse) {
            $scope.editremandList = successResponse.data;

          }, function (failureResponse) {
            return failureResponse;
          });
      };

      /*edit dismissal*/
      $scope.getEditDismissalList = function () {
        HttpFactory.getActions(CONSTANTS.URL.EDITDISMISSAL)
          .then(function (successResponse) {
            $scope.editdismissalList = successResponse.data;

          }, function (failureResponse) {
            return failureResponse;
          });
      };

      /*review checklist */
      $scope.getReviewCheck = function () {
        HttpFactory.getActions(CONSTANTS.URL.REVIEWCHECKLIST)
          .then(function (successResponse) {

            $scope.checkList = successResponse.data;
            $scope.valueText;
            angular.forEach($scope.checkList, function (value, key) {
              if (value.valueText.indexOf(';') !== -1) {

                var check = value.valueText.indexOf(';');
                $scope.assignmentTypes = [];
                $scope.assignmentTypes.push(value.valueText.substring(0, check), value.valueText.substring(check + 1));

              }

            });
          }, function (failureResponse) {
            return failureResponse;
          });
      };
      $scope.getReviewCheck();


      $scope.checkListRadio = function (valueText) {
        $scope.showNoteError = false;
        $scope.showDropDown = false;
        if (valueText) {
          if (valueText.indexOf(';') > -1) {
            $scope.showDropDown = true;
          }
        }
      };

      $scope.showNoteError = false;
      $scope.reviewCheckValidation = function () {
        if ($scope.updateAssignment.noteText === undefined) {
          $scope.updateAssignment.noteText = '';
        }

        if ($scope.updateAssignment.noteText.trim().length <= 0) {
          $scope.showNoteError = true;
          $scope.review = false;
          return;
        } else {
          $scope.showNoteError = false;
          $scope.review = true;
        }
      };

      $scope.checkListDrop = function (type) {

        if (angular.isUndefined(type)) {
          $scope.typeSeclected = $scope.assignmentTypes[0];
        } else {
          $scope.typeSeclected = type;
        }
      };
      $scope.submitReviewCheck = function (valueText, typeSeclected) {
        $scope.reviewCheckValidation();
        if (angular.isUndefined(typeSeclected) || valueText.indexOf(';') < 0) {
          typeSeclected = valueText;
        } else if (valueText.indexOf(';') >= 0) {

        }
        $scope.review = true;
        if (valueText === 'COMPLIANT_WITH_ISSUES') {

          if (!$scope.showNoteError) {
            $scope.updateAssignment.completionCode = valueText;
          } else {
            $scope.review = false;
            return;
          }
        } else {
          $scope.updateAssignment.completionCode = typeSeclected;
        }
        $scope.updateAssignment.assignmentCompletionDt = new Date().getTime();
        if ($scope.review) {
          $scope.assignmentUpdateSave(true);
        }
      };
      /* istanbul ignore next*/
      $scope.submitRemandDraft = function (valueText) {
        $scope.review = true;
        $scope.currentAssignee.assigneeNumberText = $scope.items[0].assignor;
        $scope.updateAssignment.assignor = $scope.items[0].assignee;
        if (valueText.toUpperCase() !== "APPROVED") {
          $scope.reviewCheckValidation();
        }
        $scope.updateAssignment.completionCode = valueText;
        $scope.updateAssignment.assignmentCompletionDt = new Date().getTime();
        if ($scope.review) {
          $scope.assignmentUpdateSave(true);
        }
      };
      /* istanbul ignore next*/
      $scope.dismissRemand = function () {
        $scope.updateAssignment.assignmentCompletionDt = new Date().getTime();
        $scope.currentAssignee.assigneeNumberText = $scope.items[0].assignor;
        $scope.updateAssignment.assignor = $scope.items[0].assignee;
        if ($scope.updateAssignment.assignmentType === 'CDD') {
          $scope.updateAssignment.completionCode = 'DISMISSAL_DRAFT';
        }
        if ($scope.updateAssignment.assignmentType === 'CARD') {
          $scope.updateAssignment.completionCode = 'ADMIN_DRAFT';
        }
        if ($scope.updateAssignment.assignmentType === 'EDDAP') {
          $scope.updateAssignment.completionCode = 'DISMISSAL_DRAFT';
        }
        if ($scope.updateAssignment.assignmentType === 'EARDAP') {
          $scope.updateAssignment.completionCode = 'ADMIN_DRAFT';
        }

        $scope.assignmentUpdateSave(true);
      };
      $scope.openUpdateAssignmentHistory = function () {
        ngDialog.open({
          template: 'app/components/widgets/assignments/src/assignmnetHistory.html',
          controller: 'AssignmentHistoryController',
          controllerAs: 'vm',
          width: '80%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            assignmentData: function () {
              return $scope.items[0];
            }
          },
        });
      };

      /* istanbul ignore next */
      $scope.tinymceOptionsforUpdateAssignmnt = {
        plugins: 'link image',
        toolbar: "undo redo  bold italic  link media",
        menu: {},
        browser_spellcheck: true,
        contextmenu: false,
        elementpath: false,

        init_instance_callback: function (editor) {
          var textContentTrigger = function () {
            $scope.newNote = editor.getBody().textContent;
            if ($scope.updateAssignment.noteText.length > 4000) {
              $scope.updateAssignment.noteText = $scope.updateAssignment.noteText.substring(0, 4000);
            }
          };


          editor.on('KeyUp', textContentTrigger);
          editor.on('ExecCommand', textContentTrigger);
          editor.on('SetContent', function (e) {
            if (!e.initial) {
              textContentTrigger();
            }

          });
        }
      };

      $scope.showApplicationList = function (list) {
        console.info("List:" + list);
      };


      $scope.toggle = function ($event) {
        $scope.status1.open = !$scope.status1.open;
      };
      $scope.toggleOnEnter = function ($event) {
        if ($event.keyCode === 13) {
          $scope.status1.open = !$scope.status1.open;
        }
      };
      $scope.createSpace = true;

      $scope.createSp = function () {
        $scope.createSpace = !$scope.createSpace;
      };



      if ($scope.data.panel) {
        angular.forEach($scope.data.panel, function (panel) {
          if (panel.rank === 0) {
            vm.isAttorney = true;
            vm.attorneyName = panel.employeeName;
            $scope.data.checkAttorney = {
              attorneyName: panel.employeeName,
              isAttorney: true
            };
          }
        });
      }
      // $scope.getExternalUrls = function () {
      //   HttpFactory.getActions(CONSTANTS.URL.EXTERNALURLS)
      //     .then(function (successResponse) {
      //       $scope.externalUrls = successResponse.data;
      //     }, function (failureResponse) { });
      // }
      $scope.getExternalUrls = function () {
        HttpFactory.getActions(CONSTANTS.URL.EXTERNALURLS)
          .then(function (successResponse) {
            $scope.externalUrls = [];
            $scope.externalUrlsForAssignment = [];
            for (var key in successResponse.data) {
              var url;
              if (key !== "Open in PTOZone" && key !== "ptabReadOnlyUser" && key !== "allowedResourceObjectList" && key !== "ptabDueDateNonEditableUser" && key !== "ptabDefaultRefreshTime") {
                url = {
                  description: key,
                  url: successResponse.data[key]
                };
                $scope.externalUrls.push(url);
              }
              if (key === "Open in PTOZone") {
                url = {
                  description: key,
                  url: successResponse.data[key]
                };
                $scope.externalUrlsForAssignment.push(url);
              }
            }

          }, function () {
            // Empty response is ok
          });
      };
      $scope.getExternalUrls();

      /**
       * Approve rehearing
       */
      $scope.enableSelectButton = true;
      $scope.newPanel = [];

      /* istanbul ignore next*/
      $scope.getExistingPanel = function () {
        HttpFactory.getActions(CONSTANTS.URL.GET_SELECTED_JUDGES + $scope.updateAssignment.appealNumber + "&applicationNumber=" + $scope.updateAssignment.serialNumber)
          .then(function (successResponse) {
            $scope.selection = "ORIGINAL_PANEL";
            $scope.originalPanelList = [];
            window.sessionStorage.setItem("newReconsiderSeqNo", successResponse.data.judgePanel[0].reconsiderSequenceNumber);
            angular.forEach(successResponse.data.judgePanel, function (panel) {
              var tempPanel = panel;
              if (panel.reconsiderSequenceNumber === 0) {
                if (panel.panelToBeCreated[0].panelSequenceNumber === 1) {
                  tempPanel.panelVersion = "Original panel";
                } else {
                  tempPanel.panelVersion = "Subsequent panel";
                }
              } else {
                tempPanel.panelVersion = ordinalSuffixOf(panel.reconsiderSequenceNumber) + " rehearing panel";
              }
              var removedPending = [];
              for (var i = 0; i < tempPanel.panelToBeCreated.length; i++) {
                if (tempPanel.panelToBeCreated[i].activeIndicator !== "P") {
                  removedPending.push(tempPanel.panelToBeCreated[i]);
                } else {
                  window.sessionStorage.setItem("newSeqNo", tempPanel.panelToBeCreated[i].panelSequenceNumber);
                  $scope.newPanel.push(tempPanel.panelToBeCreated[i]);
                }
              }
              if (removedPending.length > 0) {
                tempPanel.panelToBeCreated = removedPending;
              }
              $scope.originalPanelList.push(tempPanel);
            });


          }, function () {
            // Empty response is ok.
          });
      };

      /* istanbul ignore next*/
      $scope.selectPanel = function (panel) {
        $scope.selectedPanel = panel.panelToBeCreated;
        $scope.selection = "ORIGINAL_PANEL";
        $scope.showSelectedPanel = true;
        window.sessionStorage.setItem("existingReconsiderSeqNo", panel.reconsiderSequenceNumber);
        window.sessionStorage.setItem("existingSeqNo", panel.panelToBeCreated[0].panelSequenceNumber);
      };

      function ordinalSuffixOf(i) {
        var j = i % 10,
          k = i % 100;
        if (j == 1 && k != 11) {
          return i + "st";
        }
        if (j == 2 && k != 12) {
          return i + "nd";
        }
        if (j == 3 && k != 13) {
          return i + "rd";
        }
        return i + "th";
      }

      $scope.generateNewAssignment = function () {
        $scope.showSelectedPanel = false;
        $scope.selectedPanel = [];
        $scope.enableSelectButton = false;
        $scope.rehearingPanelingDate = null;
      };

      $scope.toggleSelectButton = function () {
        $scope.enableSelectButton = true;
      };

      /* istanbul ignore next*/
      $scope.submitPanel = function (selection) {
        $scope.selection = selection;
        if (selection === 'NEW_PANEL' || $scope.rehearingPanelingDate) {


          var existingPanelForRehearing = createRehearingPanel();

          HttpFactory.postActions(CONSTANTS.URL.CREATE_JUDGE_PANEL, existingPanelForRehearing)
            .then(function (successResponse) {

              ngDialog.closeAll(true);
              var message;
              if ($scope.selection === "ORIGINAL_PANEL") {
                message = "Rehearing decision panel created. Paneling date: " + $filter('date')($scope.rehearingPanelingDate, 'MM/dd/yyyy');
              } else if ($scope.selection === "NEW_PANEL") {
                message = "Rehearing decision panel assignment created";
              }
              toastr.success(message, {
                iconClass: 'toast-success'
              });
            }, function () {
              // Empty response is ok
            });
        } else {
          toastr.error(CONSTANTS.TOASTER.rehearingPanel, {
            iconClass: 'toast-danger'
          });
        }
      };

      /* istanbul ignore next*/
      $scope.setDate = function (rehearingPanelingDate) {
        if (rehearingPanelingDate) {
          if (angular.isNumber(rehearingPanelingDate)) {
            $scope.rehearingPanelingDate = rehearingPanelingDate;
          } else {
            $scope.rehearingPanelingDate = rehearingPanelingDate.getTime();
          }
        }
      };

      /* istanbul ignore next*/
      function createRehearingPanel() {
        var panelToBeCreated = [];
        var currentTs = Math.floor(new Date().getTime() / 1000);
        var reconsiderSeqNo;
        var seqNo = parseInt(window.sessionStorage.getItem("newSeqNo"), CONSTANTS.GLOBAL.RADIX);
        if ($scope.selection === "NEW_PANEL") {
          $scope.rehearingPanelingDate = Math.floor(new Date().getTime());
          panelToBeCreated = angular.copy($scope.newPanel);
          reconsiderSeqNo = parseInt(window.sessionStorage.getItem("newReconsiderSeqNo"), CONSTANTS.GLOBAL.RADIX);
          seqNo = parseInt(window.sessionStorage.getItem("newSeqNo"), CONSTANTS.GLOBAL.RADIX);
        } else {
          reconsiderSeqNo = parseInt(window.sessionStorage.getItem("existingReconsiderSeqNo"), CONSTANTS.GLOBAL.RADIX);
          seqNo = parseInt(window.sessionStorage.getItem("existingSeqNo"), CONSTANTS.GLOBAL.RADIX);
        }
        angular.forEach($scope.selectedPanel, function (judge) {
          var panel = {
            "identifier": judge.identifier,
            "panelRank": judge.panelRank,
            "assignedDate": currentTs
          };
          panelToBeCreated.push(panel);
        });

        var panelToCreate = {
          "serialNumber": $scope.updateAssignment.serialNumber,
          "appealNumber": $scope.updateAssignment.appealNumber,
          "audit": {
            "lastModifiedTimestamp": currentTs,
            "lastModifiedUserIdentifier": vm.userInfo.userId,
            "createUserIdentifier": $scope.updateAssignment.createUserIdentifier,
            "lastModifiedUserName": vm.userInfo.userId,
            "createTimestamp": currentTs,
            "lockControlNumber": 0
          },
          "panelAssignment": {
            "assignmentIdentifier": $scope.updateAssignment.assignmentIdentifier,
            "assignmentType": $scope.updateAssignment.assignmentType,
            "assignee": $scope.updateAssignment.assignee,
            "serialNumber": $scope.updateAssignment.serialNumber,
            "title": $scope.updateAssignment.title,
            "description": $scope.updateAssignment.description,
            "dueDate": currentTs,
            "completionDate": currentTs,
            "caseType": $scope.updateAssignment.caseType,
            "appealNumber": $scope.updateAssignment.appealNumber,
            "sequenceNumber": $scope.updateAssignment.sequenceNumber,
            "notes": $scope.updateAssignment.noteText,
            "completionCode": $scope.selection,
            "priorityIndicator": $scope.updateAssignment.priorityIndicator ? "Y" : "N",
            "audit": {
              "createUserIdentifier": vm.userInfo.userId,
              "lastModifiedUserIdentifier": vm.userInfo.userId,
              "lockControlNumber": $scope.lockControlNumber
            }
          },
          "judgePanel": {
            "panelToBeCreated": panelToBeCreated,
            "panelDate": $scope.rehearingPanelingDate,
            "reconsiderSequenceNumber": reconsiderSeqNo,
            "sequenceNumber": seqNo

          }
        };

        return panelToCreate;

      }
      $scope.checkAbandonChangesForRehearing = function (rehearing, currentElement) {

        if (rehearing.vm.items.length > 0) {
          ngDialog.open({
            template: 'app/components/widgets/assignments/src/cancelUpdateAssignment.html',
            controller: 'CancelUpdateAssignmentController',
            controllerAs: 'vm',
            width: '25%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              currentElement: function () {
                return currentElement;
              }

            }

          }).closePromise.then(function (revertedData) {
            if (revertedData.value === 'yes') {
              $scope.showPanelingFooter = false;
              $scope.disableDelete = false;
              $scope.htmlToLoad = currentElement;
              $scope.urltemplate.url = "app/components/widgets/assignments/src/" + $scope.htmlToLoad + ".html";
            } else {
              return;
            }


          });
          return true;
        } else {
          return false;
        }


      };

      $scope.getCreditDetails = function () {
        $scope.rtfBaseLink = CONSTANTS.URL.BASE;
        $scope.serialNumber = $scope.updateAssignment.serialNumber;
        $scope.requestedUnits = "";
        $scope.updatedReason = "";
        $scope.isReasonMandatory = false;
        $scope.role = items[0].assigneeRoleCode;
        HttpFactory.getActions(CONSTANTS.URL.CREDITSBYID + $scope.updateAssignment.assignmentIdentifier + "&creditTypeCode=" + $scope.updateAssignment.assignmentType)
          .then(function (successResponse) {
            $scope.creditDetails = successResponse.data;
            if ($scope.creditDetails.recordHour != null || $scope.creditDetails.recordHour !== undefined) {
              var x = successResponse.data.recordHour;
              var tooString = x.toString();
              $scope.splitNum = tooString.split(".");
              if ($scope.splitNum.length == 1) {
                $scope.timeToDraft = $scope.splitNum[0] + " " + "hr" + " " + "00" + " " + "mins";
              } else if ($scope.splitNum.length > 1) {
                $scope.timeToDraft = $scope.splitNum[0] + " " + "hr" + " " + $scope.splitNum[1] + " " + "mins";
              }
            }

            $scope.decisionalUnitsAwarded = $scope.creditDetails.requestorName;
            if (successResponse.data.workProductUrl && successResponse.data.workProductUrl.trim() != "") {
              $scope.fileName = successResponse.data.workProductUrl.split($scope.serialNumber + "_").pop();
            }
            $scope.todaysDate = "";
            $scope.specialType = "";
            $scope.completionDate = $scope.creditDetails.completionDate == 0 ? null : $scope.creditDetails.completionDate;
            $scope.assignmentTitle = $scope.items[0].title;
            $scope.qualifier = $scope.creditDetails.qualifier;
            $scope.creditAssignedDate= $scope.creditDetails.assignedDate;
            $scope.correctDueDate= new Date($scope.creditDetails.completionDate).getTime();
           
          },
            function () {
              // Empty response is ok
            });
        console.log($scope.updateAssignment.assignmentIdentifier);
      };
      
      $scope.openCaseHistory = function() {
      	  $window.open("#/caseViewer/" + $scope.updateAssignment.serialNumber + "/" + $scope.updateAssignment.appealNumber + "/auditTrail");
      };

      $scope.getPgaDetails = function () {
        $scope.pgaDetails = {};
        HttpFactory.getActions(CONSTANTS.URL.GET_PGA_DETAILS + $scope.updateAssignment.assignmentIdentifier)
          .then(function (successResponse) {
            if (successResponse.data.payPeriodId) {
              var payPeriodString = successResponse.data.payPeriodId.toString();
              $scope.webTaPp = payPeriodString.slice(0, 4) + "-" + payPeriodString.slice(4);
            }
            $scope.pgaDetails = successResponse.data;

          },
            function () {
              // Empty response is ok.
            });
        console.log($scope.updateAssignment.assignmentIdentifier);
      };
      $scope.acceptPgaRequest = function (action, reviewReasonPga, hoursApproved) {
        if (action == "Rejected" && (!reviewReasonPga || reviewReasonPga == "")) {
          $scope.isPgaReasonMandatory = true;
          return;
        } else {
          $scope.isPgaReasonMandatory = false;
        }
        $scope.pgaDetails.requestedHours = !hoursApproved || hoursApproved == "" ? $scope.pgaDetails.requestedHours : hoursApproved;
        $scope.pgaDetails.adjustmentRequestCategory = action;
        $scope.pgaDetails.ptabAssignmentIdentifier = $scope.updateAssignment.assignmentIdentifier;
        $scope.pgaDetails.audit = {
          "lastModifiedUserIdentifier": vm.userInfo.userId,
          "createUserIdentifier": vm.userInfo.userId,
          "lockControlNumber": 0,
          "lastModifiedTimestamp": new Date().getTime(),
          "createTimestamp": new Date().getTime()
        };
        $scope.pgaDetails.reason = reviewReasonPga;
        HttpFactory.putActions(CONSTANTS.URL.ACCEPT_PGA, $scope.pgaDetails)
          .then(function (successResponse) {
            var message = "Request has been approved and this assignment has been closed";
            if (action === "Awarded" && requestedUnits === "") {
              message = "Request has been approved and this assignment has been closed";
            }
            if (action === "Awarded" && requestedUnits !== "") {
              message = "Request has been approved with changes and this assignment has been closed. A notification has been sent to " + $scope.pgaDetails.requestorName + ".";

            }
            if (action === "Rejected") {
              message = "Request has been denied and assignment has been closed. A notification has been sent to " + $scope.pgaDetails.requestorName + ".";
            }
            toastr.success(message, {
              iconClass: 'toast-success'
            });
            ngDialog.closeAll(true);
          },
            function (failureResponse) {
              toastr.error(CONSTANTS.TOASTER.requestFailed, {
                iconClass: 'toast-danger'
              });
            });
      };
      $scope.acceptRequest = function (requestType, requestedUnits, updatedReason) {
        if (requestType == "Rejected" && (!updatedReason || updatedReason == "")) {
          $scope.isReasonMandatory = true;
          return;
        } else {
          $scope.isReasonMandatory = false;
        }
        var acceptdata = {};
        acceptdata = {
          "decisionalUnits": !requestedUnits || requestedUnits == "" ? $scope.creditDetails.additionalDecisionalUnits : requestedUnits,
          "ptabAssignmentIdentifier": $scope.updateAssignment.assignmentIdentifier,
          "reason": updatedReason,
          "appealNumber": $scope.items[0].appealNumber,
          "serialNumber": $scope.items[0].serialNumber,
          "audit": {
            "createUserIdentifier": vm.userInfo.userId,
            "lastModifiedUserIdentifier": vm.userInfo.userId
          },
          "requestorIdentifier": $scope.creditDetails.requestorIdentifier,
          "decisionalUnitsAwardedIdentifier": $scope.creditDetails.decisionalUnitsAwardedIdentifier,
          "requestStatus": requestType,
          "creditTypeCode": $scope.updateAssignment.assignmentType
        };



        HttpFactory.putActions(CONSTANTS.URL.MY_CREDITS_REQUESTDU, acceptdata)
          .then(function (successResponse) {
            var message = "Request has been approved and this assignment has been closed";
            if (requestType === "Awarded" && requestedUnits === "") {
              message = "Request has been approved and this assignment has been closed";
            }
            if (requestType === "Awarded" && requestedUnits !== "") {
              message = "Request has been approved with changes and this assignment has been closed. A notification has been sent to " + $scope.creditDetails.requestorName + ".";

            }
            if (requestType === "Rejected") {
              message = "Request has been denied and assignment has been closed. A notification has been sent to " + $scope.creditDetails.requestorName + ".";
            }
            toastr.success(message, {
              iconClass: 'toast-success'
            });
            ngDialog.closeAll(true);
          },
            function (failureResponse) {
              toastr.error(CONSTANTS.TOASTER.requestFailed, {
                iconClass: 'toast-danger'
              });
            });
      };
      $scope.getAssignmentById = function () {
        return HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTBYID + $scope.updateAssignment.assignmentIdentifier)
          .then(function (successResponse) {
            $scope.lockControlNumber = successResponse.data.audit.lockControlNumber;
          },
            function () {
              // Empty response is ok.
            });
      };

      //method to display PDF
      /* istanbul ignore next */
      $scope.addFile = function (file) {
        if (!vm.fileAdded) {
          vm.fileAdded = true;
          $scope.errorMessage = false;
          var fileName = file.currentTarget.files["0"].name;
          if (angular.isUndefined(fileName)) {
            return;
          } else {
            var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
            if (ext !== 'pdf') {
              $scope.errorMessage = true;
              toastr.error(CONSTANTS.TOASTER.fileUpload, {
                iconClass: 'toast-danger',
                timeOut: 9000000,
                extendedTimeOut: 9000000
              });
            }
            if (!$scope.errorMessage) {
              //   $scope.fileContent.push(file.currentTarget.files["0"]);

              $scope.fileContent = file.currentTarget.files["0"];
              $scope.listOfFileNames = file.currentTarget.files["0"].name;
              $scope.$apply();
            }
            $scope.showPreviewPdf();
          }
        }
      };

      $scope.fileSelect = function (p) {
        if (p.keyCode === '13') {
          document.getElementById('file1').click();
        }
      };

      /* istanbul ignore next */
      $scope.showPreviewPdf = function () {
        $scope.loading = true;
        var pdfDataFile = new FormData();
        // angular.forEach($scope.fileContent, function (value) {
        //   pdfDataFile.append('uploadMultipartFileContents', value);
        // });
        pdfDataFile.append('uploadMultipartFileContents', $scope.fileContent);
        var url = CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.USERGEN + 'appealNumber=' + $scope.items[0].appealNumber +
          '&ptabAssignmentId=' + $scope.updateAssignment.assignmentIdentifier;
        HttpFactory.postPdf(url, pdfDataFile)
          .then(function (successResponse) {
            $scope.dockType= "USER";
            $scope.PostDataResponse = successResponse.data.fileContent;
            $scope.genPdfFileName = successResponse.data.fileName;
            $rootScope.genPdfFileName = successResponse.data.fileName;
            $scope.contentsPreview = 'data:application/pdf;base64,' + $scope.PostDataResponse;
            $rootScope.contentsPreview = $scope.contentsPreview;
            $scope.getPreview($scope.contentsPreview);
            $scope.loading = false;
            $scope.hideAdd = false;
            vm.fileAdded = false;
          }, function () {
            // intentional
          });
      };

      //delete pdf
      $scope.deletePdf = function (index) {
        $scope.listOfFileNames.splice(index, 1);
        $scope.fileContent.splice(index, 1);
      };

      //get call for preview
      /* istanbul ignore next */
      $scope.getPreview = function (contents) {
        $http.get(contents, {
          responseType: 'arraybuffer',
          headers: {
            'Accept': 'application/pdf'
          }
        })
          .success(function (data) {
            var file = new Blob([data], {
              type: 'application/pdf'
            });
            $scope.showDiff = true;
            $scope.disableUplaod = false;
            var fileURL = URL.createObjectURL(file);
            var fileOne = window.URL.createObjectURL(file);
            $scope.pdfContent = $sce.trustAsResourceUrl(fileOne);
            if (null !== $scope.pdfContent && document.getElementById('miscDoc') !== null) {
              angular.element(document.getElementById('miscDoc')).scope().pdfContent = $sce.trustAsResourceUrl(fileURL);
            } else {
              $scope.pdfContent = $sce.trustAsResourceUrl(fileURL);
            }
            if (fileURL !== '' || angular.isDefined(fileURL)) {
              $scope.show = false;
              $scope.showUploadButtons = true;
              $scope.editable = false;
              $scope.pdfStyle = {
                "border": "1px solid grey"
              };
            }
          }).error(function (res) {
            $scope.showDiff = true;
            $scope.disableUplaod = true;
          });
      };

      /* istanbul ignore next */
      $scope.palmUpload = function (docFlag) {
        $scope.items[0].docFlag = docFlag;
        ngDialog.open({
          template: 'app/components/widgets/assignments/src/confirmPdfUpload.html',
          controller: 'pdfUploadController',
          width: '35%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          ariaLabelledById: 'pdfUploadTitle',
          ariaDescribedById: 'pdfUploadTitle',
          resolve: {
            pdfContent: function () {
              return $rootScope.contentsPreview;
            },
            docketInfo: function () {
              return $scope.items;
            },
            mailer: function () {
              return null;
            },
            genPdfFile: function () {
              return $rootScope.genPdfFileName;
            },
            panelData: function () {
              return null;
            },
            decisionType: function () {
              return null;
            },
            decisionDueDate: function () {
              return null;
            },
            decisionDate: function () {
              return null;
            },
            judgeList: function () {
              return null;
            },
            hearingRoomRosterData: function () {
              return null;
            },
            reconsiderSequenceNumber: function () {
              return null;
            },
            adSequenceNumber: function () {
              return null;
            },
            dockType: function(){
              return $scope.dockType;
            },
            appealDecisionData: function(){
              return null;
            }  
          }
        }).closePromise.then(function (pdfData) {
          $scope.$parent.$parent.refreshGrid = true;
          $scope.disableUpload = false;
          if (pdfData.value === 'closeAll') {
            // ngDialog.closeAll('true');
          } else if (angular.isDefined(pdfData.value.fileName)) {
            $scope.fileToEmail = pdfData.value.fileName;
            $scope.uploadPdfContent = 'data:application/pdf;base64,' + pdfData.value.fileContent;
            // $scope.getPreview($scope.uploadPdfContent);
            if (pdfData.value.deliveryMode === 'Electronic' || pdfData.value.deliveryMode === 'EMAIL') {
              $scope.showMailOptions = false;
              toastr.success("Document for case " + $scope.items[0].appealNumber + " has been successfully uploaded. Mailing assignment has been closed", {
                iconClass: 'toast-success'
              });
            } else {
              $scope.showMailOptions = true;
              toastr.success($scope.items[0].assignmentTypeDescription + " for case " + $scope.items[0].appealNumber + " has been successfully uploaded.", {
                iconClass: 'toast-success'
              });
            }
            $scope.uploadPdfContent = 'data:application/pdf;base64,' + pdfData.value.fileContent;

            $scope.getPreview($scope.uploadPdfContent);
            $scope.cancelVd = false;
            $scope.disableUplaod = true;
          } else {
            toastr.error("Upload to PDP for Case " + $scope.items[0].appealNumber + " was unsuccessful.", {
              iconClass: 'toast-danger'
            });
          }
        });
      };

      $scope.getAssignmentById();

      $scope.openApplicationList = function () {
        console.log("Hi");
      };


      $scope.getFileInfo = function (file) {
        var reader = new FileReader();
        var fileByteArray = [];
        var ewfFile = document.getElementById("fileToUpload");
        var fileExtension = ewfFile.files[0].name.split('.').pop();
        $scope.fileInfo = {};
        $scope.fileInfo.name = ewfFile.files[0].name;
        $scope.fileInfo.path = ewfFile.value;
        reader.readAsArrayBuffer(ewfFile.files[0]);
        reader.onloadend = function (evt) {
          if (evt.target.readyState == FileReader.DONE) {
            var arrayBuffer = evt.target.result,
              array = new Uint8Array(arrayBuffer);
            for (var i = 0; i < array.length; i++) {
              fileByteArray.push(array[i]);
            }
          }
        };
      };
      $scope.showHidee = true;
     $scope.previousDate=null;
     $scope.previousValue=null;
      $scope.modifyTimeliness = function (dueDate) {
if( $scope.previousDate == dueDate){
  return;
}else{
  $scope.previousDate =dueDate;
}
        var startDate = new Date($scope.creditAssignedDate);
        var endDate = new Date(dueDate);
        var startYear = startDate.getFullYear();
        var startMonth = startDate.getMonth();
        var endYear = endDate.getFullYear();
        var endMonth = endDate.getMonth();

        $timeout(function () {
          // $scope.requestedUnits = (endMonth - startMonth) + 1 + (12 * (endYear - startYear));
          document.getElementById("correctPtValue").value = (endMonth - startMonth) + 1 + (12 * (endYear - startYear));
        }, 200)

      }
      $scope.showHide = true;
      $scope.setCorrectDueDate = function (requestedUnits) {
        if( $scope.previousValue == requestedUnits){
          return;
        }else{
          $scope.previousValue =requestedUnits;
        }
        $scope.showHide = false;
        if (requestedUnits.trim() == "") {
          $scope.correctDueDate = null;
          $timeout(function () {
            $scope.showHide = true;
          }, 200)
          return;
        }
        var startDateS = new Date($scope.creditAssignedDate);

        startDateS.setMonth(startDateS.getMonth() + parseInt(requestedUnits - 1));
        $timeout(function () {
          $scope.correctDueDate = new Date(startDateS.getFullYear(), startDateS.getMonth() + 1, 0);
          $scope.showHide = true;
        }, 200)

      }
      $scope.clearFile = function () {
        $scope.fileInfo = {};
      };

      $scope.done = function(){
        toastr.success("PL Mail petition decision was successfully uploaded to PDP", {
          iconClass: 'toast-success'
        });
        ngDialog.closeAll(true);
      }

      $scope.closeDocketingNotice = function () {
        ngDialog.closeAll('true');
        toastr.success('Petition decision has been successfully closed.', {
          iconClass: 'toast-success'
        });
      };

    });
})();
