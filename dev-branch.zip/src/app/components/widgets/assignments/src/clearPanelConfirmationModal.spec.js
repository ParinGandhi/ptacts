(function () {
    'use strict';
  
    describe('ClearPanelModalController', function () {
  
      beforeEach(module('ptabe2e'));
      var $controller;
      var vm = this;
      var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close']);
      var flags;
      var controller, scope, $rootScope;
      var timeout;
  
      beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_) {
        $controller = _$controller_;
        scope = _$rootScope_.$new();
        $rootScope = _$rootScope_;
        timeout = _$timeout_;
  
        flags = {
            vm: {
              newTitle: {
                userWorkspaceName: "test",
                structure: "4-4"
              }
            },
            "setCancel": true,
            "content": true,
            "widgetArrange": true
      
          }
  
        controller = $controller('ClearPanelModalController', {
          $scope: scope,
          ngDialog: ngDialog,
          $rootScope: _$rootScope_,
          flags: flags
        });
      }));
  
      describe('ClearPanelModalController ', function () {
  
  
        it('it should call confirmClearPanel ', function () {
            expect(controller['confirmClearPanel']).toBeDefined();
            ngDialog.getOpenDialogs.and.returnValue(ngDialog);
            controller.confirmClearPanel();
          });
  
          it('it should call cancelClearPanelModal ', function () {
            expect(controller['cancelClearPanelModal']).toBeDefined();
            ngDialog.getOpenDialogs.and.returnValue(ngDialog);
            controller.cancelClearPanelModal();
          });
  
      });
    });
  })();
  