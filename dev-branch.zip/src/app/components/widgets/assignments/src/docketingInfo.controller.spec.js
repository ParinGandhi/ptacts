(function () {
  'use strict';

  describe('docketinInfoController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close', 'open']);
    var controller, scope, $rootScope, _$rootScope_;
    var timeout;
    var successResponse, workerNumber, sharedItems, shareAssign;
    var $httpBackend, spy, $q, HttpFactoryDeferred;

    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              userInfo: {
                appUserInfo: [{
                  userIdentiifier: "sbartlett"
                }]
              }
            }
          }
        }
      }
    };
    var shareAssign = [{
      "ptabAssignmentId": "1547",
      "fkAdFkAaSerialNo": "2018005604",
      "fkAdFkAppealNo": "10651537",
      "standardAssignmentType": "Docketing notice",
      "globalMetaData": {
        "briefHearingType": "H"
      }
    }];

    var pdfData = {
      value: {
        deliveryMode: 'Electronic'
      }
    }

    beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      timeout = _$timeout_;
      HttpFactoryDeferred = _$q_.defer();

      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback1) {
            callback1(pdfData);
          }
        },
        then: function (callback3, callback4) {
          callback3();
          callback4();
        }
      });

      $rootScope.sharedItems = [{
        "ptabAssignmentId": "1547",
        "fkAdFkAaSerialNo": "2018005604",
        "fkAdFkAppealNo": "10651537",
        "globalMetaData": {
          "briefHearingType": "H"
        }
      }];
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);
      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      controller = $controller('docketinInfoController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory

      });
    }));

    describe('docketinInfoController ', function () {

      // it('it should call getDocketInfo', function () {
      //   var caseNum = '06000006';
      //   successResponse = {
      //     data: {
      //       address: {
      //         physicalAddress: [{
      //           "applicationDates": {
      //             "hearingStatus": null,
      //             "appealStatus": "DECISION",
      //             "noticeOfAppealDate": 760251600000,
      //             "appealBriefDate": 930542400000,
      //             "oralHearingRequestDate": 937281600000,
      //             "noticeOfHearingMailDate": 930542400000,
      //             "examinerAnswerDate": 782539200000,
      //             "replyBriefDate": 788677200000,
      //             "hearingDate": null,
      //             "docketingNoticeDate": null,
      //             "filingDate": 661755600000
      //           },
      //           "appealDates": {
      //             "hearingStatus": null,
      //             "appealStatus": "DECISION",
      //             "noticeOfAppealDate": 760251600000,
      //             "appealBriefDate": 930542400000,
      //             "oralHearingRequestDate": 937281600000,
      //             "noticeOfHearingMailDate": 930542400000,
      //             "examinerAnswerDate": 782539200000,
      //             "replyBriefDate": 788677200000,
      //             "hearingDate": null,
      //             "docketingNoticeDate": null,
      //             "filingDate": 661755600000
      //           },
      //           "trialDates": null
      //         }]
      //       },
      //       appeal: {
      //         receivedDate: "788677200000"
      //       }

      //     }


      //   };

      //   expect(scope.getDocketInfo).toBeDefined();
      //   scope.getDocketInfo(caseNum);

      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();

      // });

      it('getDocketInfo failureResponse ', function () {
        var caseNum = '06000006';
        var failureResponse = {
          data: {}
        };

        expect(scope.getDocketInfo).toBeDefined();
        scope.getDocketInfo(caseNum);

        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });


      it('getApj1 failureResponse ', function () {
        var failureResponse = {
          data: {}
        };
        expect(scope.getApj1 ).toBeDefined();
        scope.getApj1 ();
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });

      it('getApjPanel failureResponse ', function () {
        var failureResponse = {
          data: {}
        };
        expect(scope.getApjPanel  ).toBeDefined();
        scope.getApjPanel  ();
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });

      it('rtfFile failureResponse ', function () {
        var failureResponse = {
          data: {}
        };
        expect(scope.rtfFile).toBeDefined();
        scope.rtfFile();
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });

      it('getRehearingDecisionType failureResponse ', function () {
        var failureResponse = {
          data: {}
        };
        expect(scope.getRehearingDecisionType).toBeDefined();
        scope.getRehearingDecisionType();
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });

      it('getDecisionType  failureResponse ', function () {
        var failureResponse = {
          data: {}
        };
        expect(scope.getDecisionType).toBeDefined();
        scope.getDecisionType();
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });

      // it('should call convertDocToPdf failureResponse', function () {
      //   scope.appealNumber = "20202020";
      //   scope.shareAssign[0].assignmentIdentifier = "123";
      //   var failureResponse = {
      //     data: {}
      //   };
      //   expect(scope.convertDocToPdf).toBeDefined();
      //   scope.convertDocToPdf();
      //   HttpFactoryDeferred.reject(failureResponse);
      //   $rootScope.$apply();
      // });
      
      it(' should call fileSelect', function () {
        var p = {
          keycode: '1',
        }
        expect(scope.fileSelect).toBeDefined();
        scope.fileSelect(p);
      });

      it(' should call fileSelect', function () {
        var p = {
          keycode: '13'
        }
        expect(scope['fileSelect']).toBeDefined();
        scope.fileSelect(p);
      });


      it(' should call cancelRejectionClaim', function () {
      var rejection = {
        "decisionBelongsTo": {
          "coreIdentifier": "Appeal 2020-001678",
          "supplementalIdentifier": "Application 15/540,978"
        },
        "referenceNotes": [
          {
            "identifier": "2",
            "referenceText": " As discussed above, we do not reach this rejection.",
            "referencedIdentifier": null
          }
        ],
        "decisionSummary": {
          "summaryDetails": null
        },
        "outComeDetails": [
          {
            "referenceRegulation": "103",
            "claimInformation": [
              {
                "referenceType": "UNKNOWN",
                "totalClaims": 20,
                "asCaptured": "1–20",
                "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
              },
              {
                "referenceType": "AFFIRMED",
                "totalClaims": 20,
                "asCaptured": "1–20",
                "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
              },
              {
                "referenceType": "REVERSED",
                "totalClaims": 0,
                "asCaptured": "",
                "expanded": ""
              }
            ],
            "grounds": null,
            "references": "Freeman, Kippola"
          },
          {
            "referenceRegulation": "7-8",
            "claimInformation": [
              {
                "referenceType": "UNKNOWN",
                "totalClaims": 20,
                "asCaptured": "1–20",
                "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
              },
              {
                "referenceType": "AFFIRMED",
                "totalClaims": 0,
                "asCaptured": "",
                "expanded": ""
              },
              {
                "referenceType": "REVERSED",
                "totalClaims": 0,
                "asCaptured": "",
                "expanded": ""
              }
            ],
            "grounds": null,
            "references": "Provisional Non-statutory Double Patenting[footnoteRef:2]"
          }
        ]
      }
      scope.cancelRejectionClaim (rejection);
          expect(scope.cancelRejectionClaim ).toBeDefined();
    });


    it(' should call getRehearingDecisionType', function () {
       successResponse =   [{
        "valueText": "RHD",
        "descriptionText": "Rehearing Decision – Denied"
      }, {
        "valueText": "RDDNGR",
        "descriptionText": "Rehearing Decision – Denied w/ New Ground of Rejection"
      }, {
        "valueText": "RDG",
        "descriptionText": "Rehearing Decision – Granted"
      }, {
        "valueText": "RDGNGR",
        "descriptionText": "Rehearing Decision – Granted w/ New Ground of Rejection"
      }, {
        "valueText": "RDGP",
        "descriptionText": "Rehearing Decision – Granted-in-Part"
      }, {
        "valueText": "RDGINGR",
        "descriptionText": "Rehearing Decision – Granted-in-Part w/ New Ground of Rejection"
      }, {
        "valueText": "RDGPNR",
        "descriptionText": "Rehearing Decision – Granted-in-Part w/ New Grounds of Rejection"
      }, {
        "valueText": "RDN",
        "descriptionText": "Rehearing Decision – No Decision"
      }]
      expect(scope.getRehearingDecisionType ).toBeDefined();
      scope.getRehearingDecisionType ();
      // HttpFactoryDeferred.resolve(successResponse);
      //  $rootScope.$apply();
    });
  

    it(' should call getDecisionType', function () {
      successResponse =   [{
        "valueText": "AFF",
        "descriptionText": "Affirmed"
      }, {
        "valueText": "AR",
        "descriptionText": "Affirmed and Remanded"
      }, {
        "valueText": "ARGR",
        "descriptionText": "Affirmed and Remanded with New Ground of Rejection   "
      }, {
        "valueText": "AGR",
        "descriptionText": "Affirmed with New Ground of Rejection   "
      }, {
        "valueText": "AP",
        "descriptionText": "Affirmed-in-Part"
      }, {
        "valueText": "APR",
        "descriptionText": "Affirmed-in-Part and Remanded"
      }, {
        "valueText": "APRGR",
        "descriptionText": "Affirmed-in-Part and Remanded with New Ground of Rejection   "
      }, {
        "valueText": "APGR",
        "descriptionText": "Affirmed-in-Part with New Ground of Rejection"
      }, {
        "valueText": "CL",
        "descriptionText": "Closed"
      }, {
        "valueText": "DR",
        "descriptionText": "Decision on Order 41.50(d)"
      }, {
        "valueText": "DI",
        "descriptionText": "Dismissal"
      }, {
        "valueText": "FD",
        "descriptionText": "Final Decision"
      }, {
        "valueText": "BDA",
        "descriptionText": "New Board Decision after Board Decision with New Ground of Rejection - Affirmed "
      }, {
        "valueText": "BDAP",
        "descriptionText": "New Board Decision after Board Decision with New Ground of Rejection – Affirmed in Part"
      }, {
        "valueText": "BDNG",
        "descriptionText": "New Board Decision after Board Decision with New Ground of Rejection – New Ground of Rejection"
      }, {
        "valueText": "BDR",
        "descriptionText": "New Board Decision after Board Decision with New Ground of Rejection – Reversed"
      }, {
        "valueText": "NGRB",
        "descriptionText": "New Grounds of Rejection by Board"
      }, {
        "valueText": "ND",
        "descriptionText": "No Decision"
      }, {
        "valueText": "OR",
        "descriptionText": "Order"
      }, {
        "valueText": "OTH",
        "descriptionText": "Other"
      }, {
        "valueText": "PR",
        "descriptionText": "Panel Remand"
      }, {
        "valueText": "PRR",
        "descriptionText": "Panel Remand with New Ground of Rejection   "
      }, {
        "valueText": "RDD",
        "descriptionText": "Rehearing – Denied (For Reexams only - Final and Appealable)"
      }, {
        "valueText": "RE",
        "descriptionText": "Remand to Examiner (41.77(d))"
      }, {
        "valueText": "RD",
        "descriptionText": "Reversed"
      }, {
        "valueText": "RR",
        "descriptionText": "Reversed and Remanded"
      }, {
        "valueText": "RRGR",
        "descriptionText": "Reversed and Remanded with New Ground of Rejection   "
      }, {
        "valueText": "RGR",
        "descriptionText": "Reversed with New Ground of Rejection  "
      }, {
        "valueText": "VA",
        "descriptionText": "Vacated"
      }, {
        "valueText": "VR",
        "descriptionText": "Vacated and Remanded"
      }, {
        "valueText": "VRGR",
        "descriptionText": "Vacated and Remanded with New Ground of Rejection   "
      }, {
        "valueText": "VAGR",
        "descriptionText": "Vacated with New Ground of Rejection   "
      }, {
        "valueText": "VP",
        "descriptionText": "Vacated-in-Part"
      }, {
        "valueText": "VPR",
        "descriptionText": "Vacated-in-Part and Remanded"
      }, {
        "valueText": "VPRGR",
        "descriptionText": "Vacated-in-Part and Remanded with New Ground of Rejection   "
      }, {
        "valueText": "VPGR",
        "descriptionText": "Vacated-in-Part with New Ground of Rejection  "
      }]
     expect(scope.getDecisionType ).toBeDefined();
     scope.getDecisionType ();
   });

    // it(' should call saveRejectionClaim  ', function () {
    //   var rejection = {
    //     "decisionBelongsTo": {
    //       "coreIdentifier": "Appeal 2020-001678",
    //       "supplementalIdentifier": "Application 15/540,978"
    //     },
    //     "referenceNotes": [
    //       {
    //         "identifier": "2",
    //         "referenceText": " As discussed above, we do not reach this rejection.",
    //         "referencedIdentifier": null
    //       }
    //     ],
    //     "decisionSummary": {
    //       "summaryDetails": null
    //     },
    //     "outComeDetails": [
    //       {
    //         "referenceRegulation": "103",
    //         "claimInformation": [
    //           {
    //             "referenceType": "UNKNOWN",
    //             "totalClaims": 20,
    //             "asCaptured": "1–20",
    //             "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
    //           },
    //           {
    //             "referenceType": "AFFIRMED",
    //             "totalClaims": 20,
    //             "asCaptured": "1–20",
    //             "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
    //           },
    //           {
    //             "referenceType": "REVERSED",
    //             "totalClaims": 0,
    //             "asCaptured": "",
    //             "expanded": ""
    //           }
    //         ],
    //         "grounds": null,
    //         "references": "Freeman, Kippola"
    //       },
    //       {
    //         "referenceRegulation": "7-8",
    //         "claimInformation": [
    //           {
    //             "referenceType": "UNKNOWN",
    //             "totalClaims": 20,
    //             "asCaptured": "1–20",
    //             "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
    //           },
    //           {
    //             "referenceType": "AFFIRMED",
    //             "totalClaims": 0,
    //             "asCaptured": "",
    //             "expanded": ""
    //           },
    //           {
    //             "referenceType": "REVERSED",
    //             "totalClaims": 0,
    //             "asCaptured": "",
    //             "expanded": ""
    //           }
    //         ],
    //         "grounds": null,
    //         "references": "Provisional Non-statutory Double Patenting[footnoteRef:2]"
    //       }
    //     ]
    //   }
    //   expect(scope.saveRejectionClaim ).toBeDefined();
    //   scope.saveRejectionClaim (rejection);
    // });

    it(' should call editRejectionClaim ', function () {
      var rejection = {
        "decisionBelongsTo": {
          "coreIdentifier": "Appeal 2020-001678",
          "supplementalIdentifier": "Application 15/540,978"
        },
        "referenceNotes": [
          {
            "identifier": "2",
            "referenceText": " As discussed above, we do not reach this rejection.",
            "referencedIdentifier": null
          }
        ],
        "decisionSummary": {
          "summaryDetails": null
        },
        "outComeDetails": [
          {
            "referenceRegulation": "103",
            "claimInformation": [
              {
                "referenceType": "UNKNOWN",
                "totalClaims": 20,
                "asCaptured": "1–20",
                "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
              },
              {
                "referenceType": "AFFIRMED",
                "totalClaims": 20,
                "asCaptured": "1–20",
                "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
              },
              {
                "referenceType": "REVERSED",
                "totalClaims": 0,
                "asCaptured": "",
                "expanded": ""
              }
            ],
            "grounds": null,
            "references": "Freeman, Kippola"
          },
          {
            "referenceRegulation": "7-8",
            "claimInformation": [
              {
                "referenceType": "UNKNOWN",
                "totalClaims": 20,
                "asCaptured": "1–20",
                "expanded": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
              },
              {
                "referenceType": "AFFIRMED",
                "totalClaims": 0,
                "asCaptured": "",
                "expanded": ""
              },
              {
                "referenceType": "REVERSED",
                "totalClaims": 0,
                "asCaptured": "",
                "expanded": ""
              }
            ],
            "grounds": null,
            "references": "Provisional Non-statutory Double Patenting[footnoteRef:2]"
          }
        ]
      }
      scope.editRejectionClaim(rejection);
      expect(scope.editRejectionClaim).toBeDefined();
    });
      // it('should call change ', function () {
      //   var content = {
      //     name: 'Not assigned',
      //     activeCases: '',
      //     assigneeStatus: '',
      //     beNo: ""
      //   }
      //   scope.currentAssignee = {
      //     name: 'Not assigned',
      //     activeCases: '',
      //     assigneeStatus: '',
      //     beNo: ""
      //   }
      //   expect(scope.change).toBeDefined();
      //   scope.change(content);
      // });



      // Getting $scope.$parent.$parent.refreshGrid=true'

      //   it('Should invoke palmUpload', function () {
      //     scope.contentsPreview = {};
      //     scope.shareAssign = {};
      //     scope.currentAssignee = {
      //       "beNo": "5768"
      //     }

      //     expect(scope['palmUpload']).toBeDefined();
      //     scope.palmUpload();

      //     expect(ngDialog.open).toHaveBeenCalled();

      //     expect(ngDialog.open.calls.count()).toBe(1);
      //     var args = ngDialog.open.calls.argsFor(0);
      //     expect(args).not.toBe(null);
      //     expect(args.length).toBe(1);

      //     expect(args[0].controller).toBe('pdfUploadController');
      //     expect(typeof args[0].resolve).toBe('object');
      //     args[0].resolve.pdfContent();
      //     args[0].resolve.docketInfo();
      //     args[0].resolve.mailedFrom();
      //   });

      //   it('should call closeDocketingNotice ', function () {
      //     expect(ngDialog.close).toBeDefined();
      //     expect(scope.closeDocketingNotice).toBeDefined();
      //     scope.closeDocketingNotice();
      //     expect(ngDialog.close).toHaveBeenCalled();
      //   });

      it('it should call email', function () {

        successResponse = {
          data: {
            "applicationDates": {
              "hearingStatus": null,
              "appealStatus": "DECISION",
              "noticeOfAppealDate": 760251600000,
              "appealBriefDate": 930542400000,
              "oralHearingRequestDate": 937281600000,
              "noticeOfHearingMailDate": 930542400000,
              "examinerAnswerDate": 782539200000,
              "replyBriefDate": 788677200000,
              "hearingDate": null,
              "docketingNoticeDate": null,
              "filingDate": 661755600000
            },
            "appealDates": {
              "hearingStatus": null,
              "appealStatus": "DECISION",
              "noticeOfAppealDate": 760251600000,
              "appealBriefDate": 930542400000,
              "oralHearingRequestDate": 937281600000,
              "noticeOfHearingMailDate": 930542400000,
              "examinerAnswerDate": 782539200000,
              "replyBriefDate": 788677200000,
              "hearingDate": null,
              "docketingNoticeDate": null,
              "filingDate": 661755600000
            },
            "trialDates": null
          }


        };

        expect(scope.email).toBeDefined();
        scope.email();
        // toaster error
        // HttpFactoryDeferred.resolve(successResponse);
        // $rootScope.$apply();

      });

      it('email failureResponse ', function () {

        var failureResponse = {
          data: {}
        };

        expect(scope.email).toBeDefined();
        scope.email();

        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });

      it('it should call systemFile', function () {

        successResponse = {
          data: {
            "applicationDates": {
              "hearingStatus": null,
              "appealStatus": "DECISION",
              "noticeOfAppealDate": 760251600000,
              "appealBriefDate": 930542400000,
              "oralHearingRequestDate": 937281600000,
              "noticeOfHearingMailDate": 930542400000,
              "examinerAnswerDate": 782539200000,
              "replyBriefDate": 788677200000,
              "hearingDate": null,
              "docketingNoticeDate": null,
              "filingDate": 661755600000
            },
            "appealDates": {
              "hearingStatus": null,
              "appealStatus": "DECISION",
              "noticeOfAppealDate": 760251600000,
              "appealBriefDate": 930542400000,
              "oralHearingRequestDate": 937281600000,
              "noticeOfHearingMailDate": 930542400000,
              "examinerAnswerDate": 782539200000,
              "replyBriefDate": 788677200000,
              "hearingDate": null,
              "docketingNoticeDate": null,
              "filingDate": 661755600000
            },
            "trialDates": null
          }


        };

        expect(scope.systemFile).toBeDefined();
        scope.systemFile();

        // HttpFactoryDeferred.resolve(successResponse);
        // $rootScope.$apply();

      });

      // it('systemFile failureResponse ', function () {

      //   var failureResponse = {
      //     data: {}
      //   };

      //   expect(scope.systemFile).toBeDefined();
      //   scope.systemFile();

      //   HttpFactoryDeferred.reject(failureResponse);
      //   $rootScope.$apply();
      // });

      it('should call openFile ', function () {

        expect(scope.openFile).toBeDefined();
        scope.openFile();

      });

      it('should call cancelUpload ', function () {
        expect(scope.cancelUpload).toBeDefined();
        scope.cancelUpload();
      });

      it('should call clearDocument  ', function () {
        scope.verifiedDocument = null;
        scope.extracted= false;
        scope.fileExtractContent=[];
        expect(scope.clearDocument).toBeDefined();
        scope.clearDocument();
      });

      it('should call useConvertedPdf', function () {
        expect(scope.useConvertedPdf).toBeDefined();
        scope.useConvertedPdf();
      });
      
      it('should call useanotherpdf', function () {
        expect(scope.useanotherpdf ).toBeDefined();
        scope.useanotherpdf();
      });
      it('should call dispFile ', function () {
        var file = {
          currentTarget: {
            files: [{
              name: "file"
            }]
          }
        }
        var event;
        expect(scope.dispFile).toBeDefined();
        scope.dispFile(file, event);

      });

      it('should call dispFile ', function () {
        var file = {
          currentTarget: {
            files: [{
              name: undefined
            }]
          }
        }
        var event;
        scope.errorMessage = false;
        expect(scope.dispFile).toBeDefined();
        scope.dispFile(file, event);

      });


      it('should call openCommentsNotesModal ', function () {
        expect(scope.openCommentsNotesModal).toBeDefined();
        scope.openCommentsNotesModal();
      });

      // it('should call selectHearingStatus ', function () {
      //   controller.hearingStatusIndicator = true;
      //   expect(scope.selectHearingStatus).toBeDefined();
      //   scope.selectHearingStatus();
      // });

      it('should call checkForHearingStatusIndicator ', function () {
        expect(scope.checkForHearingStatusIndicator).toBeDefined();
        scope.checkForHearingStatusIndicator();
      });

      it('should call enableUploadButton ', function () {
        expect(scope.enableUploadButton).toBeDefined();
        scope.enableUploadButton();
      });

    });
  });
})();
