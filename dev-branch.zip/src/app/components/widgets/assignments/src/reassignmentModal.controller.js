(function () {
  "use strict";

  angular
    .module('ptabe2e')
    .controller('ReassignmentModalController', function (ngDialog, $log, assignmentRows, HttpFactory, CONSTANTS, toastr, $scope, uiGridConstants, $timeout) {
      var vm = this;
      var scope = angular.element(document.getElementById('mainTabId')).scope();
      vm.userInfo = scope.vm.userInfo;
      vm.assignmentRows = angular.copy(assignmentRows);
      vm.dateType = 'existing';
      vm.invalidBulkDueDate = false;
      vm.useExisting = true;
      vm.bulkDisable = false;
      vm.useExistingUser = true;
      vm.disableAssign = false;
      vm.validUser = true;
      vm.btnDisable = false;
      vm.btnNewAssignee = true;
      var requiredPageCountAssignments;

      var maxHeight = 248;

      vm.height = maxHeight;
      vm.selectOk = function () {
        ngDialog.close(lastDialog());
        };

      $scope.moreAssignees = false;
      var initComplete = false;
      $timeout(function () {
        initComplete = true;
      }, 4000);

      getRequiredAssignmentPageCount();

      function getRequiredAssignmentPageCount() {
        HttpFactory.getActions("/reference-data/code-reference-types?typeCode=MAND_ASSIGNMENTS")
        .then(function (successResponse) {
          requiredPageCountAssignments = successResponse.data[0].descriptionText.split('~');
        }, function (failureResponse) {
          console.log(failureResponse);
        });
      }

      $scope.getAssignedTo = function () {
        vm.btnNewAssignee = true;
        HttpFactory.getActions(CONSTANTS.URL.ASSIGNEEUSERS + vm.userInfo.userId)
          .then(function (successResponse) {
              $scope.myMangers = successResponse.data.managersData;
              $scope.myTeamData = successResponse.data.teamData;
              $scope.myGroupData = successResponse.data.groupData;
              $scope.workQueueData = successResponse.data.workQueueData;
              if ($scope.myGroupData === null) {
                $scope.moreAssignees = true;
              } else {
                $scope.groupLength = $scope.myGroupData.length;
                if ($scope.groupLength === 0) {
                  $scope.moreAssignees = true;
                }
              }

              $scope.foundAssigne = false;
              $scope.scrollDisable = false;
              if (!$scope.foundAssigne) {
                $scope.currentAssignee = {
                  assigneeFullNameText: 'Select user',
                  activeCaseCount: '',
                  assigneeStatus: '',
                  assigneeNumberText: ""
                };
              }
              $scope.originalcurrentAssignee = angular.copy($scope.currentAssignee);
              vm.btnNewAssignee = false;
            },
            function (failureResponse) {
              $scope.currentAssignee = {
                assigneeFullNameText: 'Select user',
                activeCaseCount: '',
                assigneeStatus: '',
                assigneeNumberText: ""
              };
              $scope.myAssigne = {};
              $scope.scrollDisable = true;
              $scope.originalcurrentAssignee = angular.copy($scope.currentAssignee);
              $log.info(failureResponse);
            });
      };
      $scope.getAssignedTo();
      $scope.extraData = true;
      $scope.moreAssigneesData = function () {
        $scope.extraData = false;
        $scope.moreAssignees = true;
        $scope.myGroup = $scope.myGroupData;
      };
      vm.cancelReassign = function () {
        vm.assignmentRows = assignmentRows;
        ngDialog.close(lastDialog());
      };


      vm.checkDueDate = function () {
        console.info("Check due date called initComlete=" + initComplete);
        if (vm.reassignDueDate != null && initComplete) {
          vm.invalidBulkDueDate = false;
        } else if (!vm.reassignDueDate && vm.useExisting) {
          vm.invalidBulkDueDate = false;
        } else {
          vm.invalidBulkDueDate = true;
        }
      };

      function checkAssignedUser() {
        if (vm.useExistingUser) {
          return true;
        }
        return $scope.currentAssignee && $scope.currentAssignee.assigneeNumberText;
      }

      /* istanbul ignore next*/
      vm.reassignWorkers = function () {
        vm.btnDisable = true;
        vm.bulkDisable = true;
        vm.checkDueDate();
        var hasUser = checkAssignedUser();
        vm.invalidAssignee = !hasUser;
        if (vm.invalidBulkDueDate || !hasUser) {
          return;
        }


  

        var missingPageNumbers = checkRequiredPageNumber();
        if (missingPageNumbers.length>0) {
          displayModal(missingPageNumbers);
        } else {
          saveData();
        }
      }

      function displayModal(rows) {
        ngDialog.openConfirm({ 
          template: "app/components/widgets/assignments/src/confirmMissingPageNumbersModal.html",
          controller: 'ConfirmMissingPageNumbersController',
            data: rows,
            controllerAs: 'vm',
            width:"50%"
            
          }).then(function () {
           // proceed
           saveData();
          }, function () {
            //stopp
          });
      }

      function saveData() {
        var reAssignDataArray = [];
        vm.assignmentRows.forEach(function (item) {
          if (vm.useExisting) {
            vm.dueDte = null;
          } else {
            vm.dueDte = new Date(vm.reassignDueDate).getTime();
          }
          var assignee;
          if (!vm.useExistingUser) {
            assignee=$scope.currentAssignee.assigneeNumberText
          } else {
            assignee = item.FK_ASSIGNEE_BE_NO;
          }
          var reAssignObject = {
            "assignee": assignee,
            "serialNumber": item.FK_AD_FK_AA_SERIAL_NO,
            "title": item.TASK_TITLE_TX,
            "description": item.TASK_DESC_TX,
            "dueDate": item.ASSIGNMENT_DUE_DT,
            "assignedDate": item.ASSIGNED_DT,
            "completionDate": item.COMPLETION_DT,
            "appealNumber": item.FK_AD_FK_APPEAL_NO,
            "notes": item.COMMENT_TX,
            "priorityIndicator": item.PRIORITY_IN,
            "assignmentIdentifier": item.assignmentIdentifier,
            "assignmentTypeIdentifier": item.FK_ASSIGNMENT_TYPE_ID,
            "pageNumberQuantity": item.PAGE_COUNT_QT,

            "assignor": vm.userInfo.userId,
            "activeIndicator": item.FK_ASSIGNMENT_STATUS_CD,
            "reassignDueDate": vm.dueDte,
            "audit": {
              "createUserIdentifier": item.CREATOR_USER_ID,
              "lastModifiedUserIdentifier": vm.userInfo.userId,
              "lockControlNumber": item.LOCK_CONTROL_NO,
              "lastModifiedTimestamp": new Date().getTime()
            }
          };
          reAssignDataArray.push(reAssignObject);
        });

        HttpFactory.putActions(CONSTANTS.URL.IMPORT_BULK_REASSIGN, reAssignDataArray)
          .then(function (successResponse) {
            vm.btnDisable = false;
            ngDialog.closeAll(successResponse);
          }, function (failureResponse) {
            toastr.error(CONSTANTS.TOASTER.reassign, {
              iconClass: 'toast-danger'
            });
            vm.bulkDisable = false;
            $log.info(failureResponse);
            vm.btnDisable = false;
          });
      }

      function lastDialog() {
        var openDialogs = ngDialog.getOpenDialogs();
        return openDialogs[openDialogs.length - 1];
      }


      /* istanbul ignore next*/

      $scope.reassignGridOptions = {
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        enableCellEdit: true,
        enableCellEditOnFocus: true,
        cellEditableCondition: true,
        gridMenuShowHideColumns: false,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.WHEN_NEEDED,
        columnDefs: [{
            displayName: "Case #",
            headerTooltip: 'Case #',
            field: "FK_AD_FK_APPEAL_NO",
            type: "string",
            width: 130,
            enableColumnMenu: false,
            enableCellEdit: false

          },
          {
            displayName: "Application #",
            headerTooltip: 'Application #',
            field: "FK_AD_FK_AA_SERIAL_NO",
            type: "string",
            width: 140,
            enableColumnMenu: false,
            enableCellEdit: false

          },
          {
            displayName: "Assignment title",
            headerTooltip: 'Assignment title',
            field: "TASK_TITLE_TX",
            type: "string",
            enableColumnMenu: false,
            enableCellEdit: false
          },
          {
            displayName: "Currently assigned to",
            headerTooltip: 'Currently assigned to',
            field: "assigneeName",
            type: "string",
            width: 200,
            enableColumnMenu: false,
            enableCellEdit: false

          },
          {
            displayName: "Assignment due date",
            headerTooltip: 'Assignment due date',
            cellFilter: "date:'MM/dd/yyyy'",
            field: "ASSIGNMENT_DUE_DT",
            type: "date",
            width: 190,
            enableColumnMenu: false,
            enableCellEdit: false

          },
          {
            // displayName: "Page #s", pageNumberQuantity
            headerCellTemplate: "<div tabindex=\"0\" title=\"Page #s\" style=\"text-align:left; padding-top:5px;padding-left:5px; cursor: copy\">Page #s <sup style='font-size: 8px'>1</sup></div>",
            headerTooltip: 'Page #s',
            field: "PAGE_COUNT_QT",
            type: "number",
            width: 80,
            enableColumnMenu: false,
            enableCellEdit: true,
          }
        ],
        onRegisterApi: function (gridApi) {
          $scope.gridApi = gridApi;
        }
      };

      vm.checkListRadio = function (value) {
        
        if (value !== 'new') {
          vm.useExisting = true;
          vm.reassignDueDate = null;
          vm.invalidBulkDueDate = false;
        } else {
          vm.useExisting = null;
        }
      };

      vm.checkListAssigneeRadio = function (value) {
        vm.assgineeType=value;
        if (value !== 'new') {
          vm.useExistingUser = true;
        } else {
          vm.useExistingUser = false;
        }
      };

      $scope.reassignGridOptions.data = vm.assignmentRows;
      vm.change = function (content) {
        if ($scope.currentAssignee.assigneeFullNameText) {
          vm.disableAssign = false;
        }
        $scope.currentAssignee.assigneeFullNameText = content.assigneeFullNameText;
        $scope.currentAssignee.activeCaseCount = content.activeCaseCount;
        $scope.currentAssignee.assigneeStatus = content.assigneeStatus;
        $scope.currentAssignee.assigneeNumberText = content.assigneeNumberText;
        vm.invalidAssignee=false;

      };

      function checkRequiredPageNumber() {
        var rowsMissingPageNumber=[];
        angular.forEach($scope.reassignGridOptions.data, function(aRow) {
          if (aRow.FK_ASSIGNMENT_TYPE_ID) {
            var strTypeId = aRow.FK_ASSIGNMENT_TYPE_ID.toString();
            if (requiredPageCountAssignments.includes(strTypeId) ) {
              if (!aRow.PAGE_COUNT_QT) {
                rowsMissingPageNumber.push(aRow);
              }
            }
          }
        });
        return rowsMissingPageNumber;
      }
    });
})();
