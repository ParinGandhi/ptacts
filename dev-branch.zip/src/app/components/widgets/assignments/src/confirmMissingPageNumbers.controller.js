(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('ConfirmMissingPageNumbersController', function ($scope) {
      var vm = this;
      vm.assignments = $scope.ngDialogData;


    });
})();
