(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('ViewPanelHistoryController', function ($scope, panelHistory, CommonHelperService, uiGridConstants, $filter, SearchHelperService) {

      $scope.isPanelOnly = false;

      /* istanbul ignore next*/
      $scope.panelHistoryGridOptions = {
        enableGridMenu: true,
        enableSelectAll: true,
        useExternalFiltering: true,
        exporterCsvFilename: 'Panel history ' + ' ' + CommonHelperService.getCurrentTime() + '.csv',
        exporterOlderExcelCompatibility: true,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        gridMenuShowHideColumns: false,
        paginationPageSizes: [10, 25, 50, 100],
        paginationPageSize: 25,
        enableFiltering: true,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.WHEN_NEEDED,
        exporterFieldCallback: function (grid, row, col, value) {
          $scope.panelHistoryGridOptions.exporterCsvFilename = 'Panel history ' + ' ' + CommonHelperService.getCurrentTime() + '.csv';
          if (col.colDef.field === 'panelSequenceNumber') {
            value = "";
          }
          if (col.colDef.type === 'date') {
            if (col.colDef.field === 'assignedDate') {
              value = $filter('date')(value, 'MM/dd/yyyy');
            } else {
              value = $filter('date')(value, 'MM/dd/yyyy hh:mm:ss a');
            }

            if (angular.isUndefined(value) || value === null) {
              value = "";
            } else {
              value = " " + value;
            }
          }
          return value;
        },
        columnDefs: [{
            "displayName": "Decision",
            headerTooltip: 'Decision',
            "field": "decisionCategoryName",
            "type": "string",
            "width": 160
          },
          {
            "displayName": "Panel role",
            headerTooltip: 'Panel role',
            "field": "panelMember",
            "type": "string",
            "width": 135,
            "sort": {
              "direction": uiGridConstants.ASC,
              "priority": 1
            }
          },
          {
            "displayName": "Name",
            headerTooltip: 'Name',
            "field": "panelName",
            "type": "string",
            "width": 180
          },
          {
            "displayName": "Status",
            headerTooltip: 'Status',
            "field": "apjStatus",
            "type": "string",
            "width": 115,
            "sort": {
              "direction": uiGridConstants.ASC,
              "priority": 2
            }
          },
          {
            "displayName": "Paneled date",
            headerTooltip: 'Paneled date',
            "field": "assignedDate",
            "type": "date",
            "cellFilter": 'date:"MM/dd/yyyy"',
            "width": 160
          },
          {
            "displayName": "Updated by",
            headerTooltip: 'Updated by',
            "field": "lastModifiedUserId",
            "type": "string",
            "width": 145
          },
          {
            "displayName": "Decision code",
            headerTooltip: 'Decision code',
            "field": "location",
            "type": "string",
            "width": 145
          },
          {
            "displayName": "Timestamp",
            headerTooltip: 'Timestamp',
            "field": "lastModifiedTs",
            "type": "date",
            "cellFilter": 'date:"MM/dd/yyyy hh:mm:ss a"',
            "width": 180
          },
          {
            "displayName": "",
            "field": "panelSequenceNumber",
            "type": "string",
            "sort": {
              "direction": uiGridConstants.DESC,
              "priority": 0
            },
            "visible": false
          }

        ],
        onRegisterApi: function (gridApi) {
          $scope.gridApi = gridApi;
          $scope.gridApi.core.on.filterChanged($scope, function () {
            var grid = this.grid;
            $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
            if ($scope.numberOfFilters === 0) {
              $scope.panelHistoryGridOptions.data = panelHistory;
            } else {
              $scope.panelHistoryGridOptions.data = SearchHelperService.filterGrid(grid, panelHistory);

            }
          });
        }
      };


      $scope.panelHistoryGridOptions.data = panelHistory;

      $scope.paneledOnly = [];
      angular.forEach(panelHistory, function (panel) {
        if (panel.activeIndicator === 'Y') {
          $scope.paneledOnly.push(panel);
        }
      });


      $scope.togglePaneled = function () {
        $scope.isPanelOnly = !$scope.isPanelOnly;
        if ($scope.isPanelOnly) {
          $scope.panelHistoryGridOptions.data = $scope.paneledOnly;
        } else {
          $scope.panelHistoryGridOptions.data = panelHistory;
        }
      };

    });
})();
