(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .controller('panelDecisionController', function ($scope, $log, ngDialog, HttpFactory, CONSTANTS, toastr, $rootScope) {
      var vm = this;
      var scope = angular.element(document.getElementById('mainTabId')).scope();
      vm.userInfo = scope.vm.userInfo;
      $scope.fileContent = [];
      $scope.multiPdf = [];
      $scope.show = true;
      $scope.editable = true;
      $scope.showPreview = true;
      $scope.fileUploadDisable = true;
      $scope.disableDecisionDraft=false;
      $scope.hideAdd = true;
      $scope.shareAssign = $rootScope.sharedItems;
      $scope.caseNum = $rootScope.sharedItems[0].serialNumber;

      $scope.disableConfirm = false;
      $scope.notesText = {

      };
      $scope.tinymceOptionsforCaseNotes = {
        plugins: 'link image',
        toolbar: "undo redo bold italic",
        menu: {},
        browser_spellcheck: true,
        contextmenu: false,
        elementpath: false,

        init_instance_callback: /* istanbul ignore next*/ function (editor) {
          var textContentTrigger = function () {
            $scope.newNote = editor.getBody().textContent;
          };

          editor.on('KeyUp', textContentTrigger);
          editor.on('ExecCommand', textContentTrigger);
          editor.on('SetContent', function (e) {
            if (!e.initial) {
              textContentTrigger();
            }
          });
        }
      };

      /* Actions in Decision Action*/
      $scope.getActionsList = function () {
        HttpFactory.getActions(CONSTANTS.URL.ACTIONS)
          .then(function (successResponse) {
            $scope.actionsList = successResponse.data;

          }, function (failureResponse) {
            return failureResponse;
          });
      };

      /* 101 ruling*/
      $scope.getRuling = function () {
        HttpFactory.getActions("/appeals/special_type/" + $scope.shareAssign[0].serialNumber + "/" + $scope.shareAssign[0].appealNumber)
          .then(function (successResponse) {
            $scope.ruling = successResponse.data;
            if ($scope.ruling.exsistingTypes.length > 0) {
              angular.forEach($scope.ruling.exsistingTypes, function (exsistingType) {
                if (exsistingType.typeNameText === 'UT' && exsistingType.checked === true) {
                  $scope.rulingCheck = exsistingType.checked;
                  $scope.originalCheck = exsistingType.checked;
                }
              });
            }
          }, function (failureResponse) {
            return failureResponse;
          });
      };
      $scope.getRuling();

      /*update 101 ruling*/
      $scope.putUpdateRuling = function () {
        if ($scope.rulingCheck !== $scope.originalCheck) {
          $scope.rulingTypes = [];
          if ($scope.rulingCheck) {
            var rulingType = {
              "fkSpecialTypId": null,
              "isChecked": $scope.rulingCheck
            };
            angular.forEach($scope.ruling.allTypes, function (allTypes) {
              if (allTypes.typeNameText === 'UT') {
                rulingType.fkSpecialTypId = allTypes.specialTypeIdentifier;
              }
            });
            $scope.rulingTypes.push(rulingType);
          }

          if ($scope.ruling.exsistingTypes.length > 0) {
            angular.forEach($scope.ruling.exsistingTypes, function (column) {
              if (column.typeNameText !== 'UT') {
                var specialType = {
                  "fkSpecialTypId": column.specialTypeIdentifier,
                  "isChecked": true
                };
                $scope.rulingTypes.push(specialType);
              }
            });
          }

          $scope.updateRuling = {
            "specialTypes": $scope.rulingTypes,
            "serialNumber": $scope.shareAssign[0].serialNumber,
            "appealNumber": $scope.shareAssign[0].appealNumber,
            "lifeCycle": null,
            "audit": {
              "createUserIdentifier": $scope.shareAssign[0].audit.createUserIdentifier,
              "lastModifiedUserIdentifier": $scope.shareAssign[0].audit.lastModifiedUserIdentifier,
              "lastModifiedUserName": $scope.shareAssign[0].audit.lastModifiedUserName,
              "lockControlNumber": $scope.shareAssign[0].audit.lockControlNumber,
              "createTimestamp": $scope.shareAssign[0].audit.createTimestamp,
              "lastModifiedTimestamp": new Date().getTime()
            }
          };
          HttpFactory.putActions("/appeals/special_type", $scope.updateRuling)
            .then(function (successResponse) {
                $log.info(successResponse);
              },
              function (failureResponse) {
                return failureResponse;
              });
        }
      };

      /* get CDD*/
      $scope.getCdd = function () {
        HttpFactory.getActions(CONSTANTS.URL.CREATEDECISION)
          .then(function (successResponse) {
            $scope.cdd = successResponse.data;

          }, function (failureResponse) {
            return failureResponse;
          });
      };

      /* get subsequent create decision draft*/
      $scope.getSubCdd = function () {
        HttpFactory.getActions(CONSTANTS.URL.SUBCREATEDECISION)
          .then(function (successResponse) {
            $scope.csdd = successResponse.data;

          }, function (failureResponse) {
            return failureResponse;
          });
      };

      /*get Create rehearing decision*/
      $scope.getCrdd = function () {
        HttpFactory.getActions(CONSTANTS.URL.CREATEREHEARING)
          .then(function (successResponse) {
            $scope.crdd = successResponse.data;

          }, function (failureResponse) {
            return failureResponse;
          });
      };
      /*get review rehearing decision*/
      $scope.getRrd = function () {
        HttpFactory.getActions(CONSTANTS.URL.REVIEWREHEARING)
          .then(function (successResponse) {
            $scope.rrd = successResponse.data;

          }, function (failureResponse) {
            return failureResponse;
          });
      };

      /*get Rdd*/
      $scope.getRdd = function () {
        HttpFactory.getActions(CONSTANTS.URL.REVIEWDECISION)
          .then(function (successResponse) {
            $scope.rdd = successResponse.data;

          }, function (failureResponse) {
            return failureResponse;
          });
      };
      /*get Review Subsequent Decision Draft*/
      $scope.getRsdd = function () {
        HttpFactory.getActions(CONSTANTS.URL.REVIEWSUBDECISION)
          .then(function (successResponse) {
            $scope.rsdd = successResponse.data;

          }, function (failureResponse) {
            return failureResponse;
          });
      };
      /* get apj1 name */
      /* istanbul ignore next */
      $scope.getApjName = function () {
        HttpFactory.getActions("/appeal-judge-panels?appealNumber=" + $scope.shareAssign[0].appealNumber + "&applicationNumber=" + $scope.shareAssign[0].serialNumber)
          .then(function (successResponse) {
            angular.forEach(successResponse.data.judgePanel[0].panelToBeCreated, function (panel) {
              if (panel.activeIndicator === "Y" && panel.panelRank === 1) {
                $scope.apj1 = panel.panelName;
                $scope.apj1Identifer = panel.identifier;
              }
            });
            for(var i=0;i<successResponse.data.judgePanel[0].panelToBeCreated.length;i++){
              if(successResponse.data.judgePanel[0].panelToBeCreated[i].identifier == vm.userInfo.appUserInfo[0].userIdentiifier) {
                $scope.disableDecisionDraft=false;
                break;
              }
              else {
                $scope.disableDecisionDraft=true;
              }
            }
          }, function (failureResponse) {
            return failureResponse;
          });
      };

      $scope.action = {};
      if ($scope.shareAssign[0].assignmentType === 'CDDD' ||
        $scope.shareAssign[0].assignmentType === 'CRDD' ||
        $scope.shareAssign[0].assignmentType === 'CSDD') {
        $scope.action.selectedActionDisplay = "Ready for draft review";
        $scope.action.selectedActionType = "RDD";
      }
      if (($scope.shareAssign[0].assignmentType === 'RDDD' || $scope.shareAssign[0].assignmentType === 'RSDD' || $scope.shareAssign[0].assignmentType === 'RRDD') &&
        ($scope.shareAssign[0].assigneeRoleCode === 'Judge')) {
        $scope.action.selectedActionDisplay = "Ready for Mailing";
        $scope.action.selectedActionType = "RM";
      }
      /* istanbul ignore next */
      $scope.setSelectedAction = function (selectedActionType, selectedActionDisplay) {
        $scope.action.selectedActionType = selectedActionType;
        $scope.action.selectedActionDisplay = selectedActionDisplay;
      };

      /* istanbul ignore next */
      $scope.assignedrole = function () {


        return HttpFactory.getActions('/user-management/users?employeeNumberText=' + $scope.shareAssign[0].assignee)
          .then(function (successResponse) {

              $scope.roleforassignmnt = successResponse.data[0].userRoles[0].roleCode;
              $scope.assigneId = successResponse.data[0].assigneeNumberText;
              $scope.Assignedtoforassignmnt = successResponse.data[0].assigneeFullNameText;
              $scope.content.assigneeFullNameText = $scope.Assignedtoforassignmnt;
              $scope.myusrRole = $scope.roleforassignmnt;
              if ($scope.roleforassignmnt) {
                $scope.showAssignmrentMsgRole = false;
              }
            },
            function (failureResponse) {
              $log.info(failureResponse);
              toastr.clear();
              toastr.error(CONSTANTS.TOASTER.role, {
                iconClass: 'toast-danger'
              });
            });
      };
      $scope.docReviewComplt = function (cc) {
        ngDialog.open({
          template: 'app/components/widgets/assignments/src/confirmDocReview.html',
          controller: 'confirmDocReviewController',
          width: '25%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            shareAssign: function () {
              return $scope.shareAssign[0];
            },
            assignedTo: function () {
              return $scope.assigneId;
            },
            rddCompletionCode: function () {
              return cc;
            },
            rrddCompletionCode: function () {
              return cc;
            },
            updateAssignment: function () {
              return $scope.updateAssignment;
            }
          }
        }).closePromise.then(function (modifiedDate) {
          // intentional
        });

      };
      /* istanbul ignore next */
      $scope.enternoh = function () {
        HttpFactory.getActions(CONSTANTS.URL.ENOH + "appealNumber=" + $scope.shareAssign[0].appealNumber)
          .then(function (successResponse) {
              $scope.eroh = successResponse.data;
              $scope.eroh.lastModifiedTime = parseInt(successResponse.data.lastModifiedTime, CONSTANTS.GLOBAL.RADIX);

            },
            function (failureResponse) {
              $log.info(failureResponse);
            });
      };


      /* call to submit response*/
      /* istanbul ignore next */
      function lastDialog() {
        var openDialogs = ngDialog.getOpenDialogs();
        return openDialogs[openDialogs.length - 1];
      }

      $scope.confirmDecision = function (dec) {
        $scope.disableDecisionDraft=true;
        if (dec == 'No') {
          ngDialog.close(lastDialog());
        } else {
          $scope.disableConfirm = true;
          if ($scope.shareAssign[0].assignmentType === 'CDDD' || $scope.shareAssign[0].assignmentType === 'CRDD') {
            if (angular.isDefined($scope.cdd)) {
              $scope.action.selectedActionType = $scope.cdd[0].valueText;
            }
            if (angular.isDefined($scope.crdd)) {
              $scope.action.selectedActionType = $scope.crdd[0].valueText;
            }
          }
          if ($scope.shareAssign[0].assigneeRoleCode === 'Patent Attorney') {
            $scope.action.selectedActionType = 'APJ_DECISION';
          }
          $scope.shareAssign[0].priorityIndicator = $scope.shareAssign[0].priorityIndicator ? 'Y' : 'N';
          $scope.shareAssign[0].completionCode = $scope.action.selectedActionType;
          $scope.currentAssignment = $scope.shareAssign[0];
          var data = {
            "assignmentType": $scope.shareAssign[0].assignmentType,
            "assignee": $scope.shareAssign[0].assignee,
            "serialNumber": $scope.shareAssign[0].serialNumber,
            "title": $scope.shareAssign[0].title,
            "description": $scope.shareAssign[0].description,
            "dueDate": $scope.shareAssign[0].dueDate,
            "completionDate": new Date().getTime(),
            "completionCode": $scope.action.selectedActionType,
            "caseType": $scope.shareAssign[0].caseType,
            "appealNumber": $scope.shareAssign[0].appealNumber,
            "sequenceNumber": $scope.shareAssign[0].sequenceNumber,
            "notes": $scope.updateAssignment.noteText,
            "priorityIndicator": $scope.shareAssign[0].priorityIndicator,
            "assignmentIdentifier": $scope.shareAssign[0].assignmentIdentifier,
            "assignor": $scope.shareAssign[0].assignor,
            "activeIndicator": $scope.shareAssign[0].activeIndicator,
            "audit": {
              "createUserIdentifier": vm.userInfo.userId,
              "lastModifiedUserIdentifier": vm.userInfo.userId,
              "lockControlNumber": $scope.shareAssign[0].audit.lockControlNumber,
              "createTimestamp": $scope.shareAssign[0].audit.createTimestamp,
              "lastModifiedTimestamp": new Date().getTime()
            },
            "nextAssignee": $scope.apj1Identifer
          };

          HttpFactory.putActions(CONSTANTS.URL.UPDATE_ASSIGNMENT, data)
            .then(function (successResponse) {
              $scope.disableDecisionDraft=true;
              $log.info(successResponse);
              if ($scope.action.selectedActionType === 'RDD') {
                toastr.success(CONSTANTS.TOASTER.rdd, {
                  iconClass: 'toast-success'
                });
              } else if ($scope.action.selectedActionType === 'RM') {
                toastr.success(CONSTANTS.TOASTER.rm, {
                  iconClass: 'toast-success'
                });
              } else if (angular.isDefined($scope.cdd) && ($scope.action.selectedActionType === $scope.cdd[0].valueText || $scope.action.selectedActionType === 'APJ_DECISION')) {
                toastr.success(CONSTANTS.TOASTER.decisionDraft, {
                  iconClass: 'toast-success'
                });
              } else if (angular.isDefined($scope.crdd) && ($scope.action.selectedActionType === $scope.crdd[0].valueText || $scope.action.selectedActionType === 'APJ_DECISION')) {
                toastr.success(CONSTANTS.TOASTER.rehearingDraft, {
                  iconClass: 'toast-success'
                });
              } else if (angular.isDefined($scope.csdd) && ($scope.action.selectedActionType === $scope.csdd[0].valueText || $scope.action.selectedActionType === 'APJ_DECISION')) {
                toastr.success(CONSTANTS.TOASTER.subsequentDraft, {
                  iconClass: 'toast-success'
                });
              }
              ngDialog.closeAll('true');

              $scope.loading = false;
              $scope.hideAdd = false;

              $scope.putUpdateRuling();

            }, function (failureResponse) {
              $scope.disableDecisionDraft=false;
              toastr.clear();
              toastr.error(failureResponse.data.message, {
                iconClass: 'toast-danger'
              });
            });

        }
      };

      $scope.confirmSaveDecision = function () {
        if ($scope.action.selectedActionType == 'RM') {
          ngDialog.open({
            template: 'app/components/widgets/assignments/src/panelDecConfirm.html',
            // controller: '',
            scope: $scope,
            width: '25%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              panelDec: function () {
                return $scope.action.selectedActionDisplay;
              }
            }
          });

          $scope.decValue = $scope.action.selectedActionDisplay;
        } else {
          $scope.confirmDecision();
        }
      };



    });
})();
