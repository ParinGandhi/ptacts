'use strict';

angular
  .module('adf.widget.assignments', ['adf.provider', 'ui.bootstrap'])
  .config(function (dashboardProvider) {
    dashboardProvider
      .widget('assignments', {
        title: 'Assignments',
        description: 'View Tasks Widget',
        templateUrl: '{widgetsPath}/assignments/src/view.html',
        edit: {
          templateUrl: '{widgetsPath}/assignments/src/edit.html'
        }
      });
  })
  .directive('assignmentView', function () {
    return {
      restirct: 'E',
      templateUrl: 'app/components/widgets/assignments/src/assignmentsView.html',
      bindToController: true
    };
  }).controller('AssignmentController', function ($log, $scope, $rootScope, uiGridConstants, i18nService,
    HttpFactory, $timeout, SearchHelperService, ngDialog, toastr, CONSTANTS, $filter, CommonHelperService, $window) {
    $scope.hideGrid = true;
    var vm = this;
    $scope.assignmentTypePlaceholder="Loading types..."
    $scope.oneZeroOneRulingTooltip = CONSTANTS.ONEZEROONERULING.tooltip;
    var widgetRandomId = (Math.floor((Math.random() * 1000) + 1)).toString();
    $scope.advancedSearchStartDateId = "advancedSearchStartDate-" + widgetRandomId;
    $scope.advancedSearchEndDateId = "advancedSearchEndDate-" + widgetRandomId;
    var currentEditRow;
    var isSPL = $rootScope.userInfo.roleDescription ? $rootScope.userInfo.roleDescription.toUpperCase().indexOf('SUPERVISOR')> -1 ? true : false : false;
    $scope.isSPL = isSPL;
    if($rootScope.userInfo.roleDescription === "Business Administrator"){
      isSPL =true; 
    }
    var requiredPageCountAssignments;

    if (isSPL) {
      getRequiredAssignmentPageCount();
    }

    /* istanbul ignore next */
    $rootScope.$on('broadcastZoneWidth', function (event, param) {
      if ($scope.$parent.model) {
        if ($scope.$parent.model.widgetIdentifier === param.widgetIdentifier) {
          $scope.setWidgetZone(param.zoneWidth);
        }
      }
    });
    i18nService.get('en').gridMenu.exporterAllAsCsv = 'Export filtered data as csv';
    i18nService.get('en').gridMenu.exporterVisibleAsCsv = 'Export this page as csv';
    i18nService.get('en').gridMenu.exporterSelectedAsCsv = 'Export selected as csv';
    var scope = angular.element(document.getElementById('mainTabId')).scope();


    function getRequiredAssignmentPageCount() {
      HttpFactory.getActions("/reference-data/code-reference-types?typeCode=MAND_ASSIGNMENTS")
      .then(function (successResponse) {
        requiredPageCountAssignments = successResponse.data[0].descriptionText.split('~');
      }, function (failureResponse) {
        console.log(failureResponse);
      });
    }

    $scope.setWidgetZone = function (zoneWidth) {
      /* istanbul ignore else */
      if (angular.isUndefined(zoneWidth)) {
        scope.vm.getWidgetZone($scope.$parent.$parent.$parent.definition);
        $scope.zoneWidth = $scope.$parent.$parent.$parent.definition.zoneWidth;
        $timeout(scope.vm.setWidgetContentHeight, 200, true, $scope.$parent.model);
      } else {
        scope.vm.setWidgetContentHeight($scope.$parent.model);
        $scope.zoneWidth = zoneWidth;
      }
    };
    $scope.setWidgetZone();
    $scope.selectUnselect = true;
    $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);

    var initialLoad = true;
    var isFilterChanged = false;
    var isColumnPinnedChanged = false;
    var isColumnVisibilityChanged = false;
    var isColumnSizeChanged = false;
    var isSortChanged = false;
    var isColumnPositionChanged = false;
    var isPaginationChanged = false;
    var hasFilterFlag = 0;
    $scope.loadedAssignColumns = false;
    var isAssignments = true;
    $scope.preferencesChanged = false;
    $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
    $scope.gridRefreshMsg = CONSTANTS.MESSAGES.GRID_REFRESH;
    var isGridRefreshed = false;
    $scope.isLoading = false;
    $scope.url;
    $scope.assignmentListOrderChanged = false;
    $rootScope.assignmentColumnsChanged = false;

    /* istanbul ignore next */
    function resetUnsavedChangesFlags() {
      isFilterChanged = false;
      isColumnVisibilityChanged = false;
      isColumnPinnedChanged = false;
      isColumnSizeChanged = false;
      isSortChanged = false;
      isColumnPositionChanged = false;
      isPaginationChanged = false;
      $scope.preferencesChanged = false;
      $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
    }
    $scope.assignmentGridOptions = CommonHelperService.setCommonGridOptions();
    $scope.assignmentGridOptions.enableCellEditOnFocus = true;


    $scope.assignmentGridOptions.enableSelectAll = true;
    $scope.assignmentGridOptions.showGridFooter = true;
    $scope.assignmentGridOptions.enableHorizontalScrollbar = uiGridConstants.scrollbars.WHEN_NEEDED;
    $scope.assignmentGridOptions.exporterCsvFilename = 'Assignments_' + CommonHelperService.getCurrentTime() + '.csv';

    /* istanbul ignore next */
    $scope.assignmentGridOptions.exporterFieldCallback = function (grid, row, col, value) {
      $scope.assignmentGridOptions.exporterCsvFilename = 'Assignments_' + CommonHelperService.getCurrentTime() + '.csv';
      if (col.colDef.type === 'date') {
        if (col.colDef.field === 'LAST_MODIFIED_TS') {
          value = $filter('date')(value, 'MM/dd/yyyy hh:mm:ss a');
        } else {
          value = $filter('date')(value, 'MM/dd/yyyy');
        }
        if (!value) {
          value = "";
        } else {
          value = " " + value;
        }
      }
      if (col.colDef.field === 'assignmentTypeDescription') {

      }
      if (col.colDef.field === 'FK_ASSIGNMENT_STATUS_CD') {
        return value = value === 'A' ? "Open" : "Closed";
      }
      value = checkColumnName(col, value);
      return value;
    };

    /* istanbul ignore next */
    function checkColumnName(col, value) {
      if (col.name === "assigneeHistory") {
        value = "";
      }
      if (col.name === 'alert') {
        if (angular.isDefined(value)) {

          var cleanList = [];
          value = value.split(",");
          angular.forEach(value, function (item) {
            if (item.trim() !== "" && item !== 'end') {
              cleanList.push(item);
            }
          });
          value = cleanList.join();
        }
      }
      return value;
    }

    function getCirculationAssignments() {
      HttpFactory.getActions("/reference-data/code-reference-types?typeCode=CIRCULATION_MANAGER")
        .then(function (successResponse) {
          $scope.circulationAssignments = successResponse.data[0].descriptionText.split('~');
        }, function (failureResponse) {
          console.log(failureResponse);
        });
    }

    getCirculationAssignments();

    $scope.show101Info = function () {
      ngDialog.open({
        template: 'app/components/widgets/assignments/src/rulingInfo.html',
        controller: 'RulingInfoController',
        controllerAs: 'vm',
        width: '40%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false
      });
    };

    /* istanbul ignore next*/
    $scope.assignmentGridOptions.gridMenuCustomItems = [{
        title: 'Save grid preferences',
        action: function () {
          $scope.saveGridPreferences();
        },
        order: 100
      }, {
        title: 'Show hidden filters',
        action: function () {
          showHiddenFilteredColumns();
        },
        order: 190
      },
      {
        title: 'Export full docket as csv',
        action: function () {
          $scope.download_csv();
        },
        order: 220
      },
      {
        title: 'Mandatory columns',
        order: 221
      },
      {
        title: 'Assignment due date',
        icon: 'fas fa-check',
        order: 224
      },
      {
        title: 'Assignment title',
        icon: 'fas fa-check',
        order: 225
      },
      {
        title: 'Case #',
        icon: 'fas fa-check',
        order: 226
      }
    ];


    /* istanbul ignore next  */
    function showHiddenFilteredColumns() {
      var hiddenFilteredColumns = SearchHelperService.hasHiddenColumnFilters($scope.gridApi.grid.columns);
      angular.forEach(hiddenFilteredColumns, function (column) {
        column.showColumn();
        $scope.preferencesChanged = true;
      });
      $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
    }


    /* istanbul ignore next*/
    $scope.assignmentGridOptions.onRegisterApi = function (gridApi) {
      $scope.gridApi = gridApi;
      $scope.gridApi.selection.setMultiSelect(true);
        
      $scope.gridApi.core.notifyDataChange = function (val) {
        updateEditedRow();
      };

      $scope.gridApi.core.on.filterChanged($scope, function () {
        isFilterChanged = true;
        var grid = this.grid;
        vm.grid = this.grid;
        $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
        /* Change the scope to $scope.$$childHead.$$childHead.searchText after adding loading screen
         If there are no filters and no search text, then set the grid data to original data */
        if ($scope.numberOfFilters === 0 &&
          (angular.isUndefined($scope.$$childTail.$$prevSibling.searchText) ||
            $scope.$$childTail.$$prevSibling.searchText === "" ||
            $scope.$$childTail.$$prevSibling.searchText === null)) {
          $scope.assignmentGridOptions.data = $scope.myData;
          /* If search text is defined and there are filters, then set grid data to filtered data before searching for searched text */
        } else if (angular.isDefined($scope.$$childTail.$$prevSibling.searchText) && $scope.numberOfFilters > 0) {
          $scope.assignmentGridOptions.data = SearchHelperService.filterGrid(grid, $scope.myData);
          $scope.$parent.$$childHead.simpleSearch($scope.$$childTail.$$prevSibling.searchText);
          /* If search text is defined and there are no filters, then set the grid data to original data before searching for searched text */
        } else if (angular.isDefined($scope.$$childTail.$$prevSibling.searchText) && $scope.numberOfFilters === 0) {
          $scope.assignmentGridOptions.data = $scope.myData;
          $scope.$parent.$$childHead.simpleSearch($scope.$$childTail.$$prevSibling.searchText);
        } else {
          /* If there are filters and no search text, then set grid data to filtered data */
          $scope.assignmentGridOptions.data = SearchHelperService.filterGrid(grid, $scope.myData);
        }
        checkForUnsavedChanges();
      });


      $scope.gridApi.pinning.on.columnPinned($scope, function () {
        isColumnPinnedChanged = true;
        updateColumnDefs($scope.assignmentGridOptions.columnDefs);
        checkForUnsavedChanges();
      });


      $scope.gridApi.core.on.columnVisibilityChanged($scope, function () {
        isColumnVisibilityChanged = true;
        updateColumnDefs($scope.assignmentGridOptions.columnDefs);
        checkForUnsavedChanges();
      });


      $scope.gridApi.colResizable.on.columnSizeChanged($scope, function () {
        isColumnSizeChanged = true;
        checkForUnsavedChanges();
      });


      $scope.gridApi.core.on.sortChanged($scope, function () {
        isSortChanged = true;
        checkForUnsavedChanges();
      });


      $scope.gridApi.selection.on.rowSelectionChanged($scope, function (row) {
        $scope.quickCompleteIndicator = row.entity.quickComplete;
        $scope.selectedRows = $scope.gridApi.selection.getSelectedRows();
      });


      $scope.gridApi.selection.on.rowSelectionChangedBatch($scope, function () {
        $scope.selectedRows = $scope.gridApi.selection.getSelectedRows();
      });


      $scope.gridApi.colMovable.on.columnPositionChanged($scope, function () {
        isColumnPositionChanged = true;
        checkForUnsavedChanges();
      });


      $scope.gridApi.pagination.on.paginationChanged($scope, function () {
        isPaginationChanged = true;
        checkForUnsavedChanges();
      });
    };

    /* istanbul ignore next*/
    $scope.download_csv = function () {
      var headers = [];
      angular.forEach($scope.columnsData, function (coldata) {
        headers.push(coldata.columnLabel);
      });
      var fields = [];
      angular.forEach($scope.columnsData, function (coldata) {
        if (coldata.columnName[0] === 'FK_ASSIGNEE_BE_NO') {
          fields.push([coldata.columnName[1], coldata.columnType]);
        } else {
          fields.push([coldata.columnName[0], coldata.columnType]);
        }
      });
      var replacer = function (key, value) {
        return value === null ? '' : value;
      };
      var csv = $scope.myData.map(function (row) {
        return fields.map(function (fieldName) {
          if (fieldName[1] === 'date') {
            if (row[fieldName[0]]) {
              if (fieldName[0] === 'LAST_MODIFIED_TS') {
                return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy hh:mm:ss a') + " ";
              } else {
                return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy') + " ";
              }
            } else {
              return "";
            }
          } else if (fieldName[0] === 'FK_ASSIGNMENT_TYPE_ID') {
            return row['assignmentTypeDescription'];
          } else if (fieldName[0] === 'LAST_MODIFIED_USER_ID') {
            return JSON.stringify(row['lastModifiedUserName'], replacer);
          } else if (fieldName[0] === 'assigneeHistory') {
            return "";
          } else if (fieldName[0] === 'FK_ASSIGNMENT_STATUS_CD') {
            return row['FK_ASSIGNMENT_STATUS_CD'] === 'A' ? "Open" : "Closed";
          } else {
            return JSON.stringify(row[fieldName[0]], replacer);
          }
        }).join(',');
      });
      csv.unshift(headers.join(','));
      csv = csv.join('\r\n');
      var hiddenElement = document.createElement('a');
      hiddenElement.href = URL.createObjectURL(new Blob([csv], {
        type: 'text/csv'
      }));
      hiddenElement.target = '_blank';
      hiddenElement.download = 'Assignments ' + CommonHelperService.getCurrentTime() + '.csv';
      hiddenElement.click();
    };

    /* istanbul ignore next*/
    $scope.openAssignmentDialog = function (dataToPass) {
      var initData={};
       if (dataToPass) {
         initData=dataToPass;
       }
       $scope.clearAssignmentTimeout();
      var data = {};
      ngDialog.open({
        template: "app/components/widgets/assignments/src/createAssignment.html",
        controller: 'CreateAssignmentController',
        scope: $scope,
        width: '60%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,
        resolve: {
          newData: function () {
            return data;
          },
          initData: function() {
            return initData;
          }
        }
      }).closePromise.then(function (refreshGrid) {
        if (refreshGrid.value) {
          $timeout(function () {
            $scope.refreshGrid();
          }, 400);
        } else {
          startAutoRefresh();
        }
      }, function () {
        startAutoRefresh();
      });
    };


    /* istanbul ignore if*/
    if (angular.isDefined($scope.$parent.model)) {
      $scope.assignmentDataUrlList = $scope.$parent.model.dataUrlText.split(",").reduce(function (map, col) {
        map[col.split(":")[0]] = col.split(":")[1];
        return map;
      }, {});
      $scope.widgetIdentifier = $scope.$parent.model.widgetIdentifier;
    } else {
      /* istanbul ignore if*/
      if ($scope.definition.type === "assignments") {
        $scope.url = $scope.$parent.$parent.$parent.$$childHead.$$childTail.$$childHead.url;
        $scope.assignmentDataUrlList = $scope.definition.dataUrlText.split(",").reduce(function (map, col) {
          map[col.split(":")[0]] = col.split(":")[1];
          return map;
        }, {});
        $scope.widgetIdentifier = $scope.definition.widgetIdentifier;
      }
    }


    $scope.getAssignmentColumns = function () {
      if (isAssignments || $scope.definition.type === 'assignments') {
        isAssignments = false;
        HttpFactory.getActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS + $scope.widgetIdentifier)
          .then(function (successResponse) {
            $scope.selectedColumns = successResponse.data.selectedColumns;
            $scope.selectedCols = [];
            $scope.availableCols = [];
            angular.forEach($scope.selectedColumns, function (thisColumn) {
              if (thisColumn.visible) {
                $scope.selectedCols.push(thisColumn);
              } else {
                $scope.availableCols.push(thisColumn);
              }
            });
            $log.debug('Selected:');
            $log.debug($scope.selectedCols);
            $log.debug('Available: ');
            $log.debug($scope.availableCols);
            $scope.originShowHide = angular.copy($scope.selectedColumns);
            $scope.assignmentsAvailableCols = angular.copy($scope.selectedCols);
            $scope.loadedAssignColumns = true;
            for (var i = 0; i < $scope.selectedColumns.length; i++) {
              if (!$scope.selectedColumns[i].visible) {
                $scope.selectUnselect = false;
                $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
              }
            }
            $log.debug("Assignment (" + $scope.widgetIdentifier + ") getAssignmentColumns success response: ");
            $log.debug(successResponse);
          }, function (failureResponse) {
            $log.debug("Assignment (" + $scope.widgetIdentifier + ") getAssignmentColumns failure response: ");
            $log.debug(failureResponse);
          });
      }
    };


    $scope.onKeyup = function (url, advancedSearchFlag, $event) {
      if ($event.keyCode === 13) {
        $scope.setUrl(url, advancedSearchFlag);
      }
    };


    $scope.enterOnActions = function ($event, functionToInvoke) {
      if ($event.keyCode === 13 && functionToInvoke) {
        $scope[functionToInvoke]();
      }
    };


    $scope.setUrl = function (url, advancedSearchFlag) {
      if ($scope.gridApi) {
        $scope.gridApi.selection.clearSelectedRows();
        $scope.assignmentGridOptions.data = null;
      }
      if (url === 'advanceSearch') {
        $scope.url = '/assignment-views/advanceSearch/' + $scope.widgetIdentifier;
      } else {
        $scope.url = url;
      }

      $scope.selectedRows = [];
      $scope.searchData = !advancedSearchFlag;
      $scope.advancedSearchFlag = advancedSearchFlag;
      if (advancedSearchFlag) {
        $scope.advancedSearch();
      } else {
        $scope.getAssignments();
      }
    };


    /* istanbul ignore next*/
    function setGridData(colDefs) {
      if (hasFilterFlag > 0) {
        $scope.numberOfFilters = hasFilterFlag;
        var filteredData = SearchHelperService.filterTable($scope.myData, colDefs);
        $timeout(function () {
          $scope.assignmentGridOptions.data = filteredData;
          $scope.savedFilteredData = filteredData;
          selectAssignmentRows();
        }, 200);
      } else {
        $scope.numberOfFilters = 0;
        $timeout(function () {
          $scope.assignmentGridOptions.data = $scope.myData;
          selectAssignmentRows();
        }, 200);
      }
    }


    /* istanbul ignore next: toaster error*/
    $scope.getAssignments = function () {
      $scope.enableloading = true;
      $scope.refreashFaild = false;
      $scope.isLoading = true;
      HttpFactory.getActions($scope.url)
        .then(function (successResponse) {
          $scope.clearAssignmentTimeout();
          $scope.enableloading = false;
          $scope.refreashFaild = false;
          $scope.lastRefresh = new Date();
          $scope.dateValid = false;
          if (angular.isDefined(successResponse.data.assignmentsData)) {
            $scope.myData = successResponse.data.assignmentsData;
            $scope.columnsData = successResponse.data.columnDetails;
            $scope.selectedCols = [];
            $scope.availableCols = [];
            angular.forEach($scope.columnsData, function (thisColumn) {
              if (thisColumn.visible) {
                $scope.selectedCols.push(thisColumn);
              } else {
                $scope.availableCols.push(thisColumn);
              }
            });
            $scope.originalData = angular.copy(successResponse.data.assignmentsData);
            $scope.updatedColumnList = successResponse.data.columnDetails;
            $scope.originalAssignments = angular.copy($scope.updatedColumnList);
            var setColumnsResponse = CommonHelperService.setColumnDefinitions($scope.updatedColumnList);
            $scope.selectUnselect = setColumnsResponse.selectUnselect;
            $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
            hasFilterFlag = setColumnsResponse.filterCount;
            updateColumnDefs(setColumnsResponse.colDefs);
            setGridData(setColumnsResponse.colDefs);
            $scope.hideGrid = false;
            $scope.assignmentGridOptions.paginationPageSize = successResponse.data.paginationSize !== undefined ? successResponse.data.paginationSize : 25;
            $scope.preferencesChanged = false;
            $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
            $timeout($scope.setPaginationManually, 700);
            $scope.noRecordsFound = false;
            $timeout(function () {
              initialLoad = false;
            }, 2000);
            if (isGridRefreshed) {
              toastr.success(CONSTANTS.TOASTER.refreshData, {
                iconClass: 'toast-success'
              });
            }
            $scope.ptabDefaultRefreshTime = successResponse.data.ptabDefaultRefreshTime;
            startAutoRefresh();
          }
        }, function (failureResponse) {
          startAutoRefresh();
          $scope.assignmentGridOptions.data = [];
          $scope.myData = [];
          if (failureResponse.status === 404) {
            $scope.enableloading = false;
            $scope.refreashFaild = false;
            $scope.lastRefresh = new Date();
            $scope.dateValid = false;
            toastr.info(CONSTANTS.TOASTER.refreshFailure, {
              iconClass: 'toast-info'
            });
          } else {
            $scope.refreashFaild = true;
            $scope.refreashFailDate = new Date();
            $scope.enableloading = false;
            if (angular.isUndefined($scope.lastRefresh) || $scope.lastRefresh === null) {
              $scope.dateValid = true;
            }
            toastr.info(failureResponse.data.message, {
              iconClass: 'toast-info'
            });
          }
        })
        .finally(function () {
          $scope.isLoading = false;
        });
    };


    function startAutoRefresh() {
      if (!$scope.ptabDefaultRefreshTime) {
        return;
      }
      $scope.assignmentTimeout = $timeout(function () {
        vm.mySelectedRows = angular.copy($scope.gridApi.selection.getSelectedRows());
        vm.tempColumnDefs = angular.copy($scope.assignmentGridOptions.columnDefs);
        vm.tempNumberOfFilters = angular.copy($scope.numberOfFilters);
        $scope.enableloading = true;
        $scope.refreashFaild = false;
        $scope.lastRefresh === undefined || null;
        if ($scope.advancedSearchFlag && $scope.enableAdvSearch()) {
          $scope.performAdvSearch();
        } else {
          HttpFactory.getActions($scope.url)
            .then(function (successResponse) {
              $scope.enableloading = false;
              $scope.refreashFaild = false;
              $scope.lastRefresh = new Date();
              $scope.dateValid = false;
              if (angular.isDefined(successResponse.data.assignmentsData)) {
                $scope.myData = successResponse.data.assignmentsData;
                $scope.columnsData = successResponse.data.columnDetails;
                $scope.originalData = angular.copy(successResponse.data.assignmentsData);
                $scope.assignmentGridOptions.columnDefs = angular.copy(vm.tempColumnDefs);
                hasFilterFlag = angular.copy(vm.tempNumberOfFilters);
                setGridData($scope.assignmentGridOptions.columnDefs);
                angular.forEach(vm.mySelectedRows, function (row) {
                  $scope.gridApi.selection.selectRow(row);
                });
                if ($scope.numberOfFilters > 0) {
                  $scope.assignmentGridOptions.data = SearchHelperService.filterGrid($scope.$$childHead.$$childHead.$$nextSibling.grid, $scope.myData);
                } else {
                  $scope.assignmentGridOptions.data = $scope.originalData;
                }
                $scope.enableloading = false;
                $scope.hideGrid = false;
                $timeout(function () {
                  initialLoad = false;
                }, 2000);
                if (isGridRefreshed) {
                  toastr.success(CONSTANTS.TOASTER.refreshData, {
                    iconClass: 'toast-success'
                  });
                }
                startAutoRefresh();
              }
            }, function (failureResponse) {
              $scope.assignmentGridOptions.data = [];
              if (failureResponse.status === 404) {
                $scope.enableloading = false;
                $scope.refreashFaild = false;
                $scope.lastRefresh = new Date();
                $scope.dateValid = false;
                toastr.info(CONSTANTS.TOASTER.refreshFailure, {
                  iconClass: 'toast-info'
                });
              } else {
                $scope.refreashFaild = true;
                $scope.refreashFailDate = new Date();
                $scope.enableloading = false;
                if (angular.isUndefined($scope.lastRefresh) || $scope.lastRefresh === null) {
                  $scope.dateValid = true;
                }
                toastr.info(failureResponse.data.message, {
                  iconClass: 'toast-info'
                });
              }
            })
            .finally(function () {
              $scope.isLoading = false;
            });
        }
      }, $scope.ptabDefaultRefreshTime);
    }


    $scope.clearAssignmentTimeout = function () {
      if ($scope.assignmentTimeout) {
        $timeout.cancel($scope.assignmentTimeout);
      }
    };


    $scope.validateTeamLead = function () {
      HttpFactory.getActions(CONSTANTS.URL.VALIDATETEAMLEAD + "userId=" + $rootScope.userInfo.userId)
        .then(function (successResponse) {
          $scope.disableHierarchy = successResponse.data;
        }, function (failureResponse) {
          console.info(failureResponse);
        });
    };
    $scope.validateTeamLead();


    $scope.moveItem = function (origin, destination) {
      var temp = $scope.selectedCols[destination];
      $log.debug("Initial");
      $log.debug($scope.selectedCols);
      $scope.selectedCols[destination] = $scope.selectedCols[origin];
      $log.debug("Origin moved to destination");
      $log.debug($scope.selectedCols);
      $scope.selectedCols[origin] = temp;
      $log.debug("Final");
      $log.debug($scope.selectedCols);
      $scope.assignmentListOrderChanged = true;
      $rootScope.assignmentColumnsChanged = true;
      var adfScope = angular.element(document.getElementById('assignmentsEdit')).scope();
      adfScope.showErrorMsg = true;
    };


    $scope.listItemUp = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex - 1);
    };


    $scope.listItemDown = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex + 1);
    };


    $scope.moveSourcetoDestination = function () {
      angular.forEach($scope.clickedColumn, function (column) {
        column.visible = true;
        $scope.selectedCols.push($scope.availableCols[$scope.availableCols.indexOf(column)]);
        $scope.availableCols.splice($scope.availableCols.indexOf(column), 1);
      });
      $scope.clickedColumn = [];
      $rootScope.assignmentColumnsChanged = true;
    };


    $scope.moveSourcetoDestinationCancel = function (index) {
      $scope.selectedCols[index].visible = false;
      $scope.availableCols.push($scope.selectedCols[index]);
      $scope.selectedCols.splice(index, 1);
      $rootScope.assignmentColumnsChanged = true;
    };


    $scope.toggleSelectAll = function () {
      angular.forEach($scope.availableCols, function (column) {
        column.visible = true;
        $scope.selectedCols.push(column);
      });
      $scope.availableCols = [];
      $rootScope.assignmentColumnsChanged = true;
    };


    $scope.removeAll = function () {
      var tempArray = [];
      $rootScope.assignmentColumnsChanged = true;
      angular.forEach($scope.selectedCols, function (column) {
        if (!column.mandatory) {
          column.visible = false;
          $scope.availableCols.push(column);
        } else {
          tempArray.push(column);
        }
      });
      $scope.selectedCols = tempArray;
    };


    /* istanbul ignore next*/
    $scope.saveState = function () {
      $scope.saveGridPreferences();
    };

    $scope.canEdit = function(row) {
      return checkAssignmentTypes(row.entity);
    };

    var oldValue;
    function checkEdit($scope) {
      var isEditable = checkAssignmentTypes($scope.row.entity);
      currentEditRow = $scope.row.entity;
      oldValue = currentEditRow.PAGE_COUNT_QT;
      return isEditable;
    }

    function updateEditedRow() {
      if (currentEditRow) {
        if (!currentEditRow.PAGE_COUNT_QT || currentEditRow.PAGE_COUNT_QT===0 ) {
          CommonHelperService.setToastr("A page count of at least 1 is required, reseting value to " + oldValue, "error");
          currentEditRow.PAGE_COUNT_QT=oldValue;
          return;
        }

        if (currentEditRow.PAGE_COUNT_QT === oldValue) {
          return;
        }
        vm.getAssignmentById(currentEditRow.assignmentIdentifier).then(function (item) {
          if (!item && !item[0]) {
            CommonHelperService.setToastr("Error updating page count, reseting value to " + oldValue, "error");
            currentEditRow.PAGE_COUNT_QT=oldValue;
            return;
          }
          var reAssignDataArray = [];
          var theOldValue = angular.copy(oldValue);
          if (!theOldValue) {
            theOldValue = "no value";
          }
          item[0].notes="Page count changed from " + theOldValue + " to " + currentEditRow.PAGE_COUNT_QT;
        
          item[0].pageNumberQuantity=currentEditRow.PAGE_COUNT_QT;
          reAssignDataArray.push(item[0]);
          HttpFactory.putActions(CONSTANTS.URL.IMPORT_BULK_REASSIGN, reAssignDataArray)
          .then(function (successResponse) {
            CommonHelperService.setToastr("Successfully updated page count", "success", 3000);
          }, function (failureResponse) {
            CommonHelperService.setToastr("Error updating page count, reseting value to " + oldValue, "error");
            currentEditRow.PAGE_COUNT_QT=oldValue;
 
          }); 
        });
      }        
    }

    $scope.checkForChanges = function(row) {
      console.log("checking for chagnes");
    }

    function checkAssignmentTypes(row) {    
      if (!isSPL) {
        return false;
      }
      try {
        var strTypeId = row.FK_ASSIGNMENT_TYPE_ID.toString();
   
        if (requiredPageCountAssignments.includes(strTypeId) ) {
          return true;
        }
    
      } catch(error) {

      }
      return false;
    }

    function getRequiredAssignmentPageCount() {
      HttpFactory.getActions("/reference-data/code-reference-types?typeCode=MAND_ASSIGNMENTS")
      .then(function (successResponse) {
        requiredPageCountAssignments = successResponse.data[0].descriptionText.split('~');
      }, function (failureResponse) {
        console.log(failureResponse);
      });
    }

    $scope.getCaseNumber = function(row) {
      console.info("row here");
    }

    function updateColumnDefs(columndefs) {
      var selected = [];
      var unselected = [];
      var selectedCount = 0;
      angular.forEach(columndefs, function (col) {
        if (col.cellEditMethod) {
          col.width=85;
          col.cellEditableCondition=checkEdit;
          col.cellTemplate ="<div ng-if=\"!grid.appScope.canEdit(row)\" style=\"margin-left:10px; padding-top:5px;\" class=\"truncateTitle\">{{row.entity.PAGE_COUNT_QT}}</div> <div ng-if=\"grid.appScope.canEdit(row)\"  title=\"Click edit button to change value, press Esc to cancel and press enter to save\" style=\"margin-left:10px; padding-top:5px;\" class=\"truncateTitle\" ng-model=\"row.entity.PAGE_COUNT_QT\">{{row.entity.PAGE_COUNT_QT}} <i style=\"padding-right:6px;padding-top:3px;\" class=\"fa fa-edit pull-right\"></i></div>";
        }

        if (col.visible) {
          selected.push(col);
          selectedCount = selectedCount + 1;
        } else {
          unselected.push(col);
        }
      });
      columndefs = [];
      angular.forEach(selected, function (col) {
        if (col.displayName === 'Alerts') {
          col = CommonHelperService.addAlertFilters(col, 'assignments');
        }
        columndefs.push(col);
      });
      unselected.sort(CommonHelperService.alphabetizeAvailableColumns);
      angular.forEach(unselected, function (col) {
        if (col.displayName === 'Alerts') {
          col = CommonHelperService.addAlertFilters(col, 'assignments');
        }
        columndefs.push(col);
      });
      $scope.assignmentGridOptions.columnDefs = columndefs;
    }


    $scope.showFilteringHelp = function () {
      ngDialog.open({
        template: 'app/components/helperComponents/filterHelp/filteringHelp.html',
        controller: 'CommonDialogController',
        controllerAs: 'vm',
        width: '54%',
        showClose: false
      }).then(function () {
        // intentional
      }, function () {
        // intentional
      });
    };


    $scope.sortableOptions = {
      containment: '#assignColumns',
      scroll: true,
      axis: 'y',
      cursor: 'move',
      scrollSpeed: 2,
      scrollSensitivity: 160,
      update: function () {
        $rootScope.assignmentColumnsChanged = true;
      }
    };


    /* istanbul ignore next*/
    $scope.clearSearch = function (clearSearchText) {
      if (clearSearchText) {
        $scope.$$childTail.$$prevSibling.searchText = undefined;
        $scope.$$childTail.searchText = undefined;
      }
      if ($scope.numberOfFilters > 0) {
        $scope.assignmentGridOptions.data = SearchHelperService.filterGrid($scope.$$childHead.$$childHead.$$nextSibling.grid, $scope.myData);
      } else {
        $scope.assignmentGridOptions.data = $scope.originalData;
      }
    };


    /* istanbul ignore next*/
    $scope.simpleSearch = function (textToSearch) {
      if (textToSearch !== $scope.previousTextToSearch) {
        $scope.previousTextToSearch = angular.copy(textToSearch);
        $scope.clearSearch(false);
      }
      var simpleSearchResults = [];
      angular.forEach($scope.assignmentGridOptions.data, function (thisRow) {
        for (var key in thisRow) {
          if (rowContainsValue(thisRow, key)) {
            if (thisRow[key].toString().toLowerCase().includes(textToSearch.trim().toLowerCase())) {
              simpleSearchResults.push(thisRow);
              break;
            }
          } else {
            var thisDate = new Date(thisRow[key]);
            var dateToCompare = getDateRow(thisDate);
            if (dateToCompare.includes(textToSearch.trim())) {
              simpleSearchResults.push(thisRow);
              break;
            }
          }
        }
      });
      displayNoResults(simpleSearchResults);
      $scope.assignmentGridOptions.data = simpleSearchResults;
    };


    /* istanbul ignore next */
    function getDateRow(thisDate) {
      var month = thisDate.getMonth() + 1;
      if (month < 10) {
        month = '0' + month.toString();
      }
      var date = thisDate.getDate();
      if (date < 10) {
        date = '0' + date.toString();
      }
      return month + '/' + date + '/' + thisDate.getFullYear();
    }


    function displayNoResults(simpleSearchResults) {
      if (simpleSearchResults.length === 0) {
        toastr.error(CONSTANTS.TOASTER.noRecords, {
          iconClass: 'toast-danger'
        });
      }
    }


    /* istanbul ignore next */
    function rowContainsValue(thisRow, key) {
      var validKey = thisRow.hasOwnProperty(key) && thisRow[key];
      return validKey && (isNaN(parseInt(thisRow[key], CONSTANTS.GLOBAL.RADIX)) || thisRow[key].toString().length !== 13);
    }

    $scope.openCaseViewer = function (row) {
      $window.sessionStorage.setItem("id", row.entity.assignmentIdentifier);
      $window.open("#/caseViewer/" + row.entity.FK_AD_FK_AA_SERIAL_NO + "/" + row.entity.FK_AD_FK_APPEAL_NO);
    };
    vm.getAssignmentById = function (ptabID) {
      return HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTBYID + ptabID)
        .then(function (successResponse) {
            $scope.item = successResponse.data;
            $scope.itemsSelected = [];
            $scope.itemsSelected.push($scope.item);
            return $scope.itemsSelected;
          },
          function (failureResponse) {
            $scope.itemsSelected = [];
            $log.debug(failureResponse);
            return failureResponse;
          });
    };

    function openPromoteToAppealModal(row) {
      ngDialog.open({
              template: "app/components/widgets/assignments/src/promoteToAppealAdminModal.html",
              controller: 'PromoteToAppealAdminModalController',
              scope: $scope,
              width: '80%',
              showClose: false,
              closeByEscape: false,
              closeByDocument: false,
              resolve: {
                items: function () {
                  return $scope.itemsSelected;
                }
              }
            }).closePromise.then(function (refreshGrid) {
                $scope.refreshGrid();
               $scope.$$childTail.$$prevSibling.searchText = undefined;
            }, function () {
              // intentional
            });
    }

    /* istanbul ignore next: toaster error*/
    $scope.openupdateAssignmentModal = function (row) {
      if (angular.isDefined(row)) {
        $scope.mySelectedRows = [];
        $scope.mySelectedRows.push(row.entity);
      } else {
        $scope.mySelectedRows = $scope.gridApi.selection.getSelectedRows();
      }
      if ($scope.mySelectedRows.length === 0) {
        toastr.clear();
        toastr.error(CONSTANTS.TOASTER.selectRow, {
          iconClass: 'toast-danger'
        });
      } else {
        $scope.clearAssignmentTimeout();
        vm.getAssignmentById($scope.mySelectedRows[0].assignmentIdentifier).then(function () {
          if ($scope.circulationJudgeAssignments && ($scope.itemsSelected[0].assigneeRoleCode === 'Judge' && $scope.circulationJudgeAssignments.includes($scope.itemsSelected[0].assignmentType)) || $scope.circulationAssignments.includes($scope.itemsSelected[0].assignmentType)) {
          window.open("#/circulation/" + $scope.itemsSelected[0].serialNumber + "/" +$scope.itemsSelected[0].appealNumber);
          //window.open("#/circulation/" + row.entity.FK_AD_FK_AA_SERIAL_NO + "/" + row.entity.FK_AD_FK_APPEAL_NO);
          } else if ($scope.itemsSelected[0].assignmentType.indexOf("ATP") === 0){
            openPromoteToAppealModal(row);

          } else {
            $scope.itemsSelected[0].priorityIndicator = $scope.itemsSelected[0].priorityIndicator === 'Y' ? true : false;
            ngDialog.open({
              template: "app/components/widgets/assignments/src/updateAssignmentModal.html",
              controller: 'updateAssignmentManagementController',
              scope: $scope,
              width: '62%',
              appendClassName: 'ngdialog-content-cust',
              showClose: false,
              closeByEscape: false,
              closeByDocument: false,
              resolve: {
                items: function () {
                  return $scope.itemsSelected;
                },
                readOnly: function () {
                  return false;
                }
              }
            }).closePromise.then(function (refreshGrid) {
              if ($rootScope.ngrOpenCreateAssignment===0) {
                var data = {
                  appealNumber:$scope.mySelectedRows[0].FK_AD_FK_APPEAL_NO,
                  assignmentTitle:"Create dismissal assignment",
                  assignmentTypeCode : "CDD",
                  assignmentTypeDisplayName : "Create dismissal draft"
                };
                $scope.openAssignmentDialog(data);
              }
              $rootScope.ngrOpenCreateAssignment=null;

              if (refreshGrid.value) {
                $scope.refreshGrid();
                $scope.$$childTail.$$prevSibling.searchText = undefined;
              } else {
                startAutoRefresh();
              }
              delete $rootScope.sharedItems;
            }, function () {
              // intentional
            });
          }
        });
      }
    };

    $scope.assignmentListEnterKey = function(event, assignmentDisplayName) {
      if (event.keyCode===13) {
        if ( $scope.assignmentTypeList.length>0) {
          $scope.setSelectedJudge($scope.assignmentTypeList[0]);
        }
      }
    }

    $scope.showJudgeList = function () {
      if ($scope.assignmentTypePlaceholder==='Loading types...') {
        return;
      }
      if (!$scope.judgeListVisible) {
        $scope.judgeListVisible = !$scope.judgeListVisible;
      }
    };

    $scope.setSelectedJudge = function (judge) {
      if (judge.displayName !== "No type selected") {
       $scope.selectedAssignmentType = judge;
         $scope.advancedSearchObj.selectedType = judge.assignmentTypeCode;
         $scope.enableAdvSearch();
      } else {
        $scope.selectedAssignmentType={};
        $scope.advancedSearchObj.selectedType='';
        $scope.enableAdvSearch();
      }
      $scope.judgeListVisible=false;
    };


    $scope.selectJudgeEntered = function(event, judge) {
      if (event.keyCode === 13) {
        $scope.setSelectedJudge(judge);
      }
    };

    $scope.searchForJudge = function (input) {
      
      $scope.judgeListVisible=true;
      $scope.enableAdvSearch();
      var tempList = [];
      if (angular.isDefined(input) && input.displayName.trim() !== "") {
        angular.forEach($scope.stndAssignmentTypes, function (currentJudge) {
          if (currentJudge.displayName.toLowerCase().includes(input.displayName.toLowerCase())) {
            tempList.push(currentJudge);
          }
        });
        $scope.assignmentTypeList = angular.copy(tempList);
      } else {
        $scope.assignmentTypeList = angular.copy($scope.stndAssignmentTypes);
        var noneSelectedObject = {
          value:"",
          displayName:"No type selected"
        };
        $scope.assignmentTypeList.unshift(noneSelectedObject);
      }
    };

    function getCirculationJudgeAssignments() {
      HttpFactory.getActions("/reference-data/code-reference-types?typeCode=CIRCULATION_JUDGE")
        .then(function (successResponse) {
          $scope.circulationJudgeAssignments = successResponse.data[0].descriptionText.split('~');
        }, function (failureResponse) {
          console.log(failureResponse);
        });
    }

    getCirculationJudgeAssignments();


    /* istanbul ignore next: toaster error*/
    $scope.bulkReassign = function () {
      var userId = $window.sessionStorage.getItem("workerNumber");
      $scope.clearAssignmentTimeout();
      ngDialog.open({
        template: "app/components/widgets/assignments/src/reassignmentModal.html",
        controller: 'ReassignmentModalController',
        controllerAs: 'vm',
        scope: $scope,
        width: '52%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,
        resolve: {
          userId: function () {
            return userId;
          },
          assignmentRows: function () {
            return $scope.selectedRows;
          }
        }
      }).closePromise.then(function (responseData) {
        if (!responseData.value) {
          startAutoRefresh();
          return;
        }
        var successResponse = responseData.value;
        $scope.assignmentsData = successResponse.data;
        var verb = " assignments have ";
        if ($scope.selectedRows.length - $scope.assignmentsData.length === 1) {
          verb = " assignment has ";
        }
        if ($scope.assignmentsData.length === 0) {
          toastr.success($scope.selectedRows.length + verb + " been successfully reassigned.", {
            iconClass: 'toast-success'
          });
        } else if ($scope.selectedRows.length === $scope.assignmentsData.length) {
          toastr.error(CONSTANTS.TOASTER.reassignFail, {
            iconClass: 'toast-danger'
          });
          return;
        } else {
          toastr.error($scope.selectedRows.length - $scope.assignmentsData.length + verb +
            "been successfully reassigned.  " + $scope.assignmentsData.length + " assignment(s) failed to be reassigned.", {
              iconClass: 'toast-warning'
            });
        }
        vm.failedReassignments = angular.copy($scope.assignmentsData);
        $scope.refreshGrid();
        $scope.$$childTail.$$prevSibling.searchText = undefined;
      }, function () {
        startAutoRefresh();
      });
    };


    /* istanbul ignore next*/
    $scope.saveGridPreferences = function () {
      if ($scope.gridApi) {
        $scope.gridState = CommonHelperService.setGridWidthMap($scope.gridApi.saveState.save());
      } else if ($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi) {
        $scope.gridState = CommonHelperService.setGridWidthMap($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi.saveState.save());
      }
      $scope.updateColumns();
    };

    $scope.paginationManual = false;


    $scope.setPaginationManually = function () {
      $scope.paginationManual = false;
    };


    /* istanbul ignore next*/
    $rootScope.$on('adfCustomizeWidgetServiceCall', function () {
      if ($rootScope.widgetIdentifier === $scope.widgetIdentifier) {
        switch ($rootScope.widgetHeight) {
          case "widgetHeightSmall":
            $scope.assignmentGridOptions.paginationPageSize = $scope.assignmentGridOptions.paginationPageSizes[0];
            break;
          case "widgetHeightMedium":
            $scope.assignmentGridOptions.paginationPageSize = $scope.assignmentGridOptions.paginationPageSizes[1];
            break;
          case "widgetHeightLarge":
            $scope.assignmentGridOptions.paginationPageSize = $scope.assignmentGridOptions.paginationPageSizes[2];
            break;
          case "widgetHeightXlarge":
            $scope.assignmentGridOptions.paginationPageSize = $scope.assignmentGridOptions.paginationPageSizes[3];
            break;
          default:
            break;
        }
        $scope.paginationManual = true;
        $timeout($scope.setPaginationManually, 700);
      }
    });


    /* istanbul ignore next*/
    $scope.areAllSelected = function () {
      var columnList = angular.element(document.getElementById('assignColumns')).scope();
      for (var i = 0; i < columnList.updatedColumnList.length; i++) {
        if (!columnList.updatedColumnList[i].visible) {
          $scope.selectUnselect = false;
          break;
        } else {
          $scope.selectUnselect = true;
        }
        $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
      }
    };


    /* istanbul ignore next*/
    $scope.updateColumns = function () {
      $scope.isLoading = true;
      var docketScopeList = angular.element(document.getElementById('assignColumns')).scope();
      var columnsSelected = [];
      var fromModal = false;
      if (angular.isDefined(docketScopeList)) {
        columnsSelected = docketScopeList.selectedCols;
        columnsSelected = angular.copy(docketScopeList.selectedCols);
        angular.forEach(docketScopeList.availableCols, function (available) {
          columnsSelected.push(available);
        });
        fromModal = true;
      } else {
        columnsSelected = $scope.updatedColumnList;
      }
      var updatedColumns = CommonHelperService.setColumnsToUpdate(columnsSelected, fromModal, $scope.gridState, $scope.widgetIdentifier, false);
      if (angular.isDefined(docketScopeList)) {
        docketScopeList.originalAssignments = angular.copy(updatedColumns.selectedColumns);
      }
      updateAssignmentColumnsService(updatedColumns, fromModal);
    };


    /* istanbul ignore next */
    function updateAssignmentColumnsService(updatedColumns, fromModal) {
      HttpFactory.putActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS, updatedColumns)
        .then(function (successResponse) {
            toastr.success(CONSTANTS.TOASTER.gridSave, {
              iconClass: 'toast-success'
            });
            resetUnsavedChangesFlags();
            if (fromModal) {
              fromModal = false;
              var colDefs = [];
              angular.forEach(successResponse.config.data.selectedColumns, function (fetchedColumn) {
                var columnToBeAdded = {};
                if (!fetchedColumn.visible) {
                  $scope.selectUnselect = false;
                  $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
                }
                // Adding the column display name
                columnToBeAdded.displayName = fetchedColumn.columnLabel;
                // Checking if the field mapped to the column as an alias name
                if (fetchedColumn.columnName.length > 1) {
                  columnToBeAdded.field = fetchedColumn.columnName[1];
                } else {
                  columnToBeAdded.field = fetchedColumn.columnName[0];
                }
                if (columnToBeAdded.field === "alert") {
                  columnToBeAdded.cellTemplate = 'app/components/widgets/assignmentBasedDocket/src/assignmentBasedDocketFlags.html';
                }
                if (columnToBeAdded.field === 'ASSIGNMENT_DUE_DT') {
                  columnToBeAdded.cellTemplate = 'app/components/widgets/assignmentBasedDocket/src/assignmentBasedDocketRowTemplate.html';
                }
                // Setting column type
                columnToBeAdded.type = fetchedColumn.columnType;

                // Setting custom cell filter if one exists
                if (angular.isDefined(fetchedColumn.cellFilter)) {
                  columnToBeAdded.cellFilter = fetchedColumn.cellFilter;
                }
                // Setting visibility of the column
                if (fetchedColumn.mandatory) {
                  columnToBeAdded.visible = true;
                  columnToBeAdded.enableHiding = false;
                } else {
                  columnToBeAdded.visible = fetchedColumn.visible;
                }
                // Setting column width
                columnToBeAdded.width = fetchedColumn.width;
                // Setting custom template if one exists
                if (angular.isDefined(fetchedColumn.cellTemplate)) {
                  columnToBeAdded.cellTemplate = fetchedColumn.cellTemplate;
                }
                // Setting sort properties on column
                columnToBeAdded.sort = fetchedColumn.sort;
                // Setting column filters
                columnToBeAdded.filters = fetchedColumn.filters;
                // Incrementing the filter flag
                if (columnToBeAdded.filters[0].term) {
                  hasFilterFlag = hasFilterFlag + 1;
                }
                colDefs.push(columnToBeAdded);
              });
              $scope.numberOfFilters = hasFilterFlag;
              var allGrids = document.getElementsByClassName('ui-grid');
              for (var j = 0; j < allGrids.length; j++) {
                if (angular.element(allGrids[j]).scope().widgetIdentifier === $scope.widgetIdentifier) {
                  updateColumnDefs(colDefs);
                  angular.element(allGrids[j]).scope().assignmentGridOptions.columnDefs = $scope.assignmentGridOptions.columnDefs;
                  if ($scope.numberOfFilters > 0) {
                    var filteredData = SearchHelperService.filterTable($scope.myData, colDefs);
                    $scope.assignmentGridOptions.data = filteredData;
                  } else {

                    $scope.assignmentGridOptions.data = $scope.myData;
                  }
                  break;
                }
              }
              $rootScope.assignmentColumnsChanged = false;
            } else {
              $scope.getAssignments();
            }
          },
          function () {
            toastr.error(CONSTANTS.TOASTER.gridSaveFail, {
              iconClass: 'toast-danger'
            });
          })
        .finally(function () {
          $scope.isLoading = false;
        });
    }

    /* istanbul ignore next*/
    $scope.exportData = function () {
      var dataToExport = [];
      if ($scope.assignmentGridOptions.data.length !== $scope.myData.length) {
        angular.forEach($scope.assignmentGridOptions.data, function (currentRow) {
          dataToExport.push(currentRow.ID);
        });
      }
      HttpFactory.exportFile($scope.VCDdataUrl, dataToExport)
        .then(function () {
          // intentional
        }, function () {
          // intentional
        });
    };


    $scope.pressEnter = function (event, searchText) {
      if (event.keyCode === 13) {
        $scope.simpleSearch(searchText);
      }
    };
    /* istanbul ignore next*/
    function checkForUnsavedChanges() {
      if (!initialLoad) {
        if (isFilterChanged || isColumnVisibilityChanged || isColumnSizeChanged || isSortChanged || isColumnPositionChanged || isPaginationChanged || isColumnPinnedChanged) {
          $scope.preferencesChanged = true;
          $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_PREFERENCES;
        } else {
          $scope.preferencesChanged = false;
          $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
        }
      }
    }


    /* istanbul ignore next*/
    $scope.refreshGrid = function () {
      $scope.clearAssignmentTimeout();
      $scope.preferencesChanged = false;
      $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
      isGridRefreshed = true;
      $scope.$$childTail.searchText = "";
      $scope.enableloading = true;
      $scope.refreashFaild = false;
      $scope.lastRefresh === undefined || null;
      if ($scope.advancedSearchFlag && $scope.enableAdvSearch()) {
        $scope.performAdvSearch();
      } else {
        $scope.getAssignments();
      }
    };


    $scope.openAssignmentHistory = function (row) {
      $scope.assignData = row.entity;
      ngDialog.open({
        template: 'app/components/widgets/assignments/src/assignmnetHistory.html',
        controller: 'AssignmentHistoryController',
        controllerAs: 'vm',
        width: '80%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,
        resolve: {
          assignmentData: function () {
            return $scope.assignData;
          }
        }
      });
    };


    function selectAssignmentRows() {
      if ($scope.gridApi) {
        $scope.gridApi.selection.clearSelectedRows();
      }
      $scope.selectedRows = [];
      angular.forEach(vm.failedReassignments, function (assignment) {
        angular.forEach($scope.assignmentGridOptions.data, function (dataAssignment) {
          if (assignment.assignmentIdentifier === dataAssignment.assignmentIdentifier) {
            $scope.gridApi.grid.modifyRows($scope.assignmentGridOptions.data);
            $scope.gridApi.selection.selectRow(dataAssignment);
          }
        });
      });
    }


    /* istanbul ignore next: toaster error*/
    $scope.quickclose = function () {
      $scope.slectedrow = $scope.gridApi.selection.getSelectedRows();
      if ($scope.slectedrow.length === 0) {
        toastr.clear();
        toastr.error(CONSTANTS.TOASTER.selectRow, {
          iconClass: 'toast-danger'
        });
      } else {
        vm.getAssignmentById($scope.slectedrow[0].assignmentIdentifier).then(function () {
          $scope.quickupdateAssignmntdata = {
            "assignmentType": $scope.itemsSelected[0].assignmentType,
            "assignee": $scope.itemsSelected[0].assignee,
            "serialNumber": $scope.itemsSelected[0].serialNumber,
            "title": $scope.itemsSelected[0].title,
            "description": $scope.itemsSelected[0].description,
            "dueDate": $scope.itemsSelected[0].dueDate,
            "completionDate": new Date().getTime(),
            "caseType": $scope.itemsSelected[0].caseType,
            "appealNumber": $scope.itemsSelected[0].appealNumber,
            "sequenceNumber": $scope.itemsSelected[0].sequenceNumber,
            "notes": $scope.itemsSelected[0].notes,
            "assigneeRoleDescription": $scope.itemsSelected[0].assigneeRoleDescription,
            "priorityIndicator": $scope.itemsSelected[0].priorityIndicator,
            "assignmentIdentifier": $scope.itemsSelected[0].assignmentIdentifier,
            "assignor": $scope.itemsSelected[0].assignor,
            "activeIndicator": $scope.itemsSelected[0].activeIndicator,
            "audit": {
              "createUserIdentifier": $scope.itemsSelected[0].audit.createUserIdentifier,
              "lastModifiedUserIdentifier": $rootScope.userInfo.userId,
              "lockControlNumber": $scope.itemsSelected[0].audit.lockControlNumber,
              "createTimestamp": $scope.itemsSelected[0].audit.createTimestamp,
              "lastModifiedTimestamp": new Date().getTime()
            }
          };
          $scope.quickupdate($scope.quickupdateAssignmntdata);
        });
      }
    };


    /* istanbul ignore next: toaster error*/
    $scope.quickupdate = function (data) {
      HttpFactory.putActions(CONSTANTS.URL.UPDATE_ASSIGNMENT, data)
        .then(function () {
          toastr.clear();
          toastr.error(CONSTANTS.TOASTER.quickUpdateSuccess, {
            iconClass: 'toast-success'
          });
          $scope.getAssignments();
        }, function (failureResponse) {
          if (failureResponse.status === 404) {
            toastr.clear();
            toastr.warning(failureResponse.data.message, {
              iconClass: 'toast-warning'
            });
          } else {
            toastr.clear();
            toastr.error(CONSTANTS.TOASTER.quickUpdateFail, {
              iconClass: 'toast-danger'
            });
          }
        });
    };


    $scope.searchData = true;
    $scope.advancedSearch = function () {
      $scope.isLoading = true;
      $scope.resetAdvancedSearch();
      $scope.searchData = false;
      $scope.getAssingnmentTypes();
      $scope.getTeamMembers();
      $scope.getAssingnmentStatus();
      $scope.getAssingnmentCaseTypes();
    };
    $scope.buttonData = false;
    /* istanbul ignore next*/
    angular.element($window).on('resize', function () {
      if ($window.innerWidth <= 991) {
        $scope.buttonData = true;
      } else {
        $scope.buttonData = false;
      }
    });


    $scope.getAssingnmentTypes = function () {
      HttpFactory.getActions(CONSTANTS.URL.STND_ASSIGNMENT_TYPE)
        .then(function (successResponse) {
            $scope.stndAssignmentTypes = successResponse.data;
            $scope.assignmentTypeList = angular.copy(successResponse.data);
            var noneSelectedObject = {
              value:"",
              displayName:"No type selected"
            };
            $scope.assignmentTypeList.unshift(noneSelectedObject);
            $scope.assignmentTypePlaceholder="No type selected";
          },
          function () {
            // intentional
          });
    };

    $scope.getTeamMembers = function () {
      HttpFactory.getActions(CONSTANTS.URL.ASSIGNEEUSERS + $rootScope.userInfo.userId)
        .then(function (successResponse) {
          $scope.teammates = [];
          $scope.role = $rootScope.userInfo.roleDescription;
          if ($scope.role === "Supervisor") {
            $scope.leadRole = "All Paralegal  users";
          } else if ($scope.role === "Patent Attorney") {
            $scope.leadRole = "All Patent Attorney users";
          } else if ($scope.role === "Judge") {
            $scope.leadRole = "All Judge users";
          } else if ($scope.role === "Business Administrator") {
            $scope.leadRole = "All paralegals, all PAs, all judges";
          }
            if (successResponse.data.groupData && successResponse.data.groupData.length > 0) {
 
              $scope.teammates = successResponse.data.groupData;
            }
            if (successResponse.data.teamData && successResponse.data.teamData.length > 0) {
              angular.forEach(successResponse.data.teamData, function(item) {
                $scope.teammates.push(item);
              });
            }

            var sortedList = $scope.teammates.sort(function (a, b) {
              if (a.assigneeFullNameText < b.assigneeFullNameText) {
                return -1;
              }
              if (a.assigneeFullNameText > b.assigneeFullNameText) {
                return 1;
              }
              return 0;
            });
            $scope.teammates = sortedList;
          },
          function () {
            // intentional
          });
    };

    $scope.getAssingnmentCaseTypes = function () {
      HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTS_CASE_TYPES)
        .then(function (successResponse) {
            $scope.casetypes = successResponse.data;

          },
          function () {
            $scope.casetypes = [];
          });
    };

    $scope.getAssingnmentStatus = function () {
      HttpFactory.getActions(CONSTANTS.URL.STND_ASSIGNMENT_STATUS)
        .then(function (successResponse) {
            $scope.stndAssignmentStatus = successResponse.data;
          },
          function () {
            // intentional
          });
    };
    $scope.advancedSearchObj = {};
    $scope.diasbleAdvancedSearch = true;

    $scope.timedEnableAdvSearch = function () {
      $timeout(function () {
        $scope.enableAdvSearch();
      }, 400);
    };
    $scope.enableAdvSearch = function () {
      $scope.diasbleAdvancedSearch = true;
      if ((angular.isDefined($scope.advancedSearchObj.selectedType) &&
          $scope.advancedSearchObj.selectedType !== "") ||
        (angular.isDefined($scope.advancedSearchObj.selectedStatus) &&
          $scope.advancedSearchObj.selectedStatus !== "") ||
        (angular.isDefined($scope.advancedSearchObj.selectedCaseType) &&
          $scope.advancedSearchObj.selectedCaseType !== "") ||
        angular.isDefined($scope.advancedSearchObj.startDate) &&
        $scope.advancedSearchObj.startDate !== "" ||
        angular.isDefined($scope.advancedSearchObj.endDate) &&
        $scope.advancedSearchObj.endDate !== "" ||
        (angular.isDefined($scope.advancedSearchObj.selectedMember) &&
          $scope.advancedSearchObj.selectedMember !== "") ||
        (angular.isDefined($scope.advancedSearchObj.selectedCaseStatus) &&
          $scope.advancedSearchObj.selectedCaseStatus !== "")) {
        $scope.diasbleAdvancedSearch = false;
      }
      return !$scope.diasbleAdvancedSearch;
    };

    $scope.resetAdvancedSearch = function () {
      $scope.advancedSearchObj = {};
      $scope.selectedAssignmentType={};
      $scope.enableAdvSearch();
      $scope.getAssignments();
    };


    $scope.performAdvSearch = function () {
      $scope.judgeListVisible = false;
      $scope.enableloading = true;
      $scope.isLoading = true;
      var serachUrl = CONSTANTS.URL.ASSIGNMENTS_ADV_SEARCH + $scope.widgetIdentifier;
      if (angular.isDefined($scope.advancedSearchObj.selectedType) && $scope.advancedSearchObj.selectedType !== "") {
        serachUrl = serachUrl + '&assignmentTypeCode=' + $scope.advancedSearchObj.selectedType;
      }
      if (angular.isDefined($scope.advancedSearchObj.selectedStatus) && $scope.advancedSearchObj.selectedStatus !== "" && $scope.advancedSearchObj.selectedStatus !== "DEFAULT") {
        serachUrl = serachUrl + '&assignmentStatusCode=' + $scope.advancedSearchObj.selectedStatus;
      }
      if (angular.isDefined($scope.advancedSearchObj.selectedCaseStatus) && $scope.advancedSearchObj.selectedCaseStatus !== "" && $scope.advancedSearchObj.selectedCaseStatus !== "DEFAULT") {
        var statusCode = $scope.advancedSearchObj.selectedCaseStatus === 'A' ? 'ACTIVE' : 'CLOSED';
        var assignmentStatusCode = $scope.advancedSearchObj.selectedCaseStatus;
        serachUrl = serachUrl + '&caseStatus=' + statusCode + '&assignmentStatusCode=' + assignmentStatusCode;
      }
      if (angular.isDefined($scope.advancedSearchObj.selectedCaseType) && $scope.advancedSearchObj.selectedCaseType !== "") {
        serachUrl = serachUrl + '&caseType=' + $scope.advancedSearchObj.selectedCaseType;
      }
      if (angular.isDefined($scope.advancedSearchObj.selectedMember) && $scope.advancedSearchObj.selectedMember !== "") {
        var memberList = [];
        memberList.push($scope.advancedSearchObj.selectedMember);
        serachUrl = serachUrl + '&assigneeNumbers=' + memberList;
      }
      if (angular.isDefined($scope.advancedSearchObj.startDate) && $scope.advancedSearchObj.startDate !== "") {
        serachUrl = serachUrl + '&startDate=' + new Date($scope.advancedSearchObj.startDate).getTime();
      }
      if (angular.isDefined($scope.advancedSearchObj.endDate) && $scope.advancedSearchObj.endDate !== "") {
        serachUrl = serachUrl + '&endDate=' + new Date($scope.advancedSearchObj.endDate).getTime();
      }
      /* istanbul ignore next*/
      HttpFactory.getActions(serachUrl)
        .then(function (successResponse) {
            $scope.enableloading = false;
            $scope.$$childTail.$$prevSibling.searchText = undefined;
            $scope.gridApi.grid.clearAllFilters();
            $scope.myData = successResponse.data.assignmentsData;
            $scope.columnsData = successResponse.data.columnDetails;
            $scope.selectedCols = [];
            $scope.availableCols = [];
            angular.forEach($scope.columnsData, function (thisColumn) {
              if (thisColumn.visible) {
                $scope.selectedCols.push(thisColumn);
              } else {
                $scope.availableCols.push(thisColumn);
              }
            });
            $scope.originalData = angular.copy(successResponse.data.assignmentsData);
            $scope.updatedColumnList = successResponse.data.columnDetails;
            $scope.originalAssignments = angular.copy($scope.updatedColumnList);
            var setColumnsResponse = CommonHelperService.setColumnDefinitions($scope.updatedColumnList);
            $scope.selectUnselect = setColumnsResponse.selectUnselect;
            $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
            hasFilterFlag = setColumnsResponse.filterCount;
            updateColumnDefs(setColumnsResponse.colDefs);
            setGridData(setColumnsResponse.colDefs);
            $scope.assignmentGridOptions.data = $scope.myData;
            $scope.hideGrid = false;
            $scope.isLoading = false;
            startAutoRefresh();
          },
          function (failureResponse) {
            toastr.clear();
            toastr.error(failureResponse.data.message, {
              iconClass: 'toast-danger'
            });
            $scope.assignmentGridOptions.data = [];
            $scope.myData = [];
            $scope.originalData = [];
            $scope.isLoading = false;
            $scope.enableloading = false;
          });
      $scope.nullvalue = null;

    };
  });
