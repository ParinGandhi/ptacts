(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .directive('fileModel', ['$parse', function ($parse) {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var model = $parse(attrs.fileModel);
          var modelSetter = model.assign;

          element.bind('change', function () {
            scope.$apply(function () {
              modelSetter(scope, element[0].files[0]);
            });
          });
        }
      };
    }])

    .directive('customOnChange', function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var onChangeFunc = scope.$eval(attrs.customOnChange);
          element.bind('change', onChangeFunc);
        }
      };
    })
    .controller('PJRPDController', function ($timeout, $scope, ngDialog, HttpFactory, $log, CONSTANTS, AssignmentHelperService, $http, toastr, $sce, $rootScope, $filter, CommonHelperService) {

      $scope.infoContent='Click "Approve for mailing" button to close this assignment and send "Mail petition decision" assignment to ';
      $scope.buttonText ="Approve for mailing";
      $scope.selectFile=true;
      AssignmentHelperService.getDocument($rootScope.sharedItems[0].serialNumber).then(function(document) {
        if (document) {
          $scope.verifiedDocument = document;
        } else {
          toastr.error("Failed to retrieve decision document", {
            iconClass: 'toast-danger'
          });
        }
      });
    
      getDefaultUser();
      var clFile;
      var reader = new FileReader();
      var fileByteArray = [];
    $scope.fileExtractContent = [];
      $scope.getFileInfo = function () {
        $scope.pdfNameForDoc =null;
        clFile = document.getElementById("fileVerifyDecision");
        $scope.fileInfo = {};
        $scope.fileInfo.name = clFile.files[0].name;
        $scope.fileExtractContent.push(clFile.files[0]);
        $scope.verifiedDocument = {};
        $scope.verifiedDocument.fileName  = $scope.fileInfo.name;
        $scope.docLink =  $scope.verifiedDocument.fileName;
        $scope.fileInfo.path = clFile.value;
        reader.readAsArrayBuffer(clFile.files[0]);
        reader.onloadend = function (evt) {
          if (evt.target.readyState === FileReader.DONE) {
            var arrayBuffer = evt.target.result,
              array = new Uint8Array(arrayBuffer);
            for (var i = 0; i < array.length; i++) {
              fileByteArray.push(array[i]);
            }
          }
        };
      };
  
      $scope.clearDocument = function() {
        $scope.verifiedDocument = null;
        $scope.extracted=false;
        $scope.fileExtractContent = [];
        $scope.revalidate =false;
        $scope.editedInformation = false;
      };
  
      function getDefaultUser() {
        AssignmentHelperService.getDefaultUser(CONSTANTS.URL.DEFAULT_PETITION_USER).then(function(returnValue) {
          $scope.getNextAssignmentInfo(returnValue.descriptionText, returnValue.valueText).then(function(currentAssignee) {
            $scope.setSelectedJudge(currentAssignee);
            });
        });   
      }
     
      $scope.submitReviewDraft = function() {
        $scope.saveInProgress=true;
        var updateAssignmentObject = AssignmentHelperService.getUpdateAssignmentObject($scope.updateAssignment)
        saveAssignment(updateAssignmentObject);
      };


      function createNextAssignment() {
        var nextAssignment ={
          code:"PMPD",
          title:"Mail petition decision",
          assignee: $scope.selectedAssignmentType.assigneeNumberText
        };

        var newAssignment = AssignmentHelperService.getCreateAssignmentObject($scope.updateAssignment, nextAssignment);
      
      
        AssignmentHelperService.createAssignment(newAssignment).then(function(serviceResponse) {
          $scope.saveInProgress=false;
          if (!serviceResponse) {
            updatePopulation(newAssignment);
          } else {
            $scope.saveInProgress=false;
            toastr.clear();
            toastr.warning(serviceResponse.data.message, {
              iconClass: 'toast-warning'
            });
          }
        });
      }

      function updatePopulation(createdAssignment)  {
        AssignmentHelperService.calUpdatePopulation(createdAssignment).then(function(serviceResponse) {
          $scope.saveInProgress=false;
          if (!serviceResponse) {
            toastr.clear();
            toastr.success("Review pettiion by Chief Judge review completed and Mail petition decision assignment created and sent to " + $scope.selectedAssignmentType.assigneeFullNameText, {
              iconClass: 'toast-success'
            });
            $scope.saveInProgress=false;
          
            ngDialog.closeAll(true);
          } else {
            $scope.saveInProgress=false;
            toastr.clear();
            toastr.warning(serviceResponse.data.message, {
              iconClass: 'toast-warning'
            });
          }
        });
      }

      function saveAssignment(data) {
        HttpFactory.putActions(CONSTANTS.URL.UPDATE_ASSIGNMENT, data)
        .then(function (successResponse) {

          $scope.updateAssignment.assignmentLockControlNo = successResponse.data.audit.lockControlNumber;
          $scope.isUpdateSaved = true;
          $scope.disablesave = true;

          toastr.clear();

          toastr.error(successResponse.data.message, {
            iconClass: 'toast-success'
          });

          if ($scope.isMergedCase) {
            toastr.success(successResponse.data.title + " assignments for " + $scope.mergedApplListForToastr + " have been closed.", {
              iconClass: 'toast-success'
            });
          }

          // "<Assignment title> assignments for <list of merged applications> have been closed

          $scope.updateAssignment.noteText = "";
          if (angular.isUndefined($scope.updateAssignment.assignmentCompletionDt) || $scope.updateAssignment.assignmentCompletionDt === null) {
            $scope.updateAssignment.toDisable = false;
            $scope.isCompletiondate = false;

          } else {
            $scope.updateAssignment.toDisable = true;
            $scope.isCompletiondate = true;
            $scope.checkCompletiondate = function () {
              return $scope.isCompletiondate;
            };
          }

          $scope.finished=true;
          $scope.disableSaveButton=false;

          createNextAssignment();
        }, function (failureResponse) {
          $scope.saveInProgress=false;
          $scope.disableeWFButton=false;
          toastr.clear();
          toastr.warning(failureResponse.data.message, {
            iconClass: 'toast-warning'
          });
        });
      }


      $scope.assignmentListEnterKey = function(event) {
        if (event.keyCode===13) {
          if ( $scope.allUsers.length>0) {
            $scope.setSelectedJudge($scope.allUsers[0]);
            $scope.dontMakeVisible=true;
          }
        }
      }
  
      $scope.showJudgeList = function () {
        if ($scope.assigneePlaceholders==='Loading assignees...') {
          return;
        }

        if ($scope.dontMakeVisible) {
            $scope.dontMakeVisible=false;
        return;
        }
        if (!$scope.judgeListVisible) {
          $scope.judgeListVisible = !$scope.judgeListVisible;
        }
      };
  
      $scope.setSelectedJudge = function (judge) {
        if (judge.assigneeFullNameText !== "Select assignee") {
         $scope.selectedAssignmentType = judge;
        } else {
          $scope.selectedAssignmentType={};
        }
        $scope.judgeListVisible=false;
      };
  
  
      $scope.selectJudgeEntered = function(event, judge) {
        if (event.keyCode === 13) {
          $scope.setSelectedJudge(judge);
        }
      };
  
      $scope.searchForJudge = function (input) {
        $scope.judgeListVisible=true;
        var tempList = [];
        if (angular.isDefined(input) && input.assigneeFullNameText.trim() !== "") {
          angular.forEach($scope.backupAllUsers, function (currentJudge) {
            if (currentJudge.assigneeFullNameText.toLowerCase().includes(input.assigneeFullNameText.toLowerCase())) {
              tempList.push(currentJudge);
            }
          });
          $scope.allUsers = angular.copy(tempList);
        } else {
          $scope.allUsers = angular.copy($scope.backupAllUsers);
        }
      };
  });
})();
