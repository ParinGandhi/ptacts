(function () {
  'use strict';

  describe('confirmDocReviewController', function () {

    beforeEach(module('ptabe2e'));
    var $controller, spy;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['close', 'closeAll', 'getOpenDialogs']);
    var controller, scope, $rootScope, rddCompletionCode, shareAssign, $q, successResponse, HttpFactoryDeferred, updateAssignment;

    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              userInfo: {
                appUserInfo: [{
                  userIdentiifier: "sbartlett"
                }]
              }
            }
          }
        }
      }
    };

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);

      spy = spyOn(angular, 'element').and.callFake(fakeElement);
      shareAssign = {
        appealNumber: "2019002010",
        assignee: "5768",
        assignmentType: "RDDD",
        priorityIndicator: "Y",
        audit: {
          lockContolNumber: 1
        }
      }
      updateAssignment = {
        "noteText": "hello"
      }
      rddCompletionCode = "COMPLETE"
      controller = $controller('confirmDocReviewController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        shareAssign: shareAssign,
        rddCompletionCode: rddCompletionCode,
        updateAssignment: updateAssignment

      });
    }));
    afterEach(function () {
      spy.and.callThrough();
    });

    describe('confirmDocReviewController ', function () {

      it('should call abandonChanges ', function () {
        var ngDialogArray = [ngDialog, ngDialog];
        expect(ngDialog.close).toBeDefined();
        expect(scope.abandonChanges).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        scope.abandonChanges();
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog, true);

        expect(ngDialog.close).toBeDefined();
        expect(scope.abandonChanges).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        scope.abandonChanges();
        expect(ngDialog.close).toHaveBeenCalled();
      });

      it('it should call assignedrole successResponse', function () {
        successResponse = {
          data: [{
            "inputDate": 1546120487000,
            "assigneeFullNameText": "Parin",
            "assigneeNumberText": "gandhi",
            userRoles: [{
              roleCode: "admin"
            }]
          }]
        }

        expect(scope.assignedrole).toBeDefined();
        scope.assignedrole();

        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();
      });

      it('assignedrole failureResponse ', function () {

        var failureResponse = {
          data: {}
        };

        expect(scope.assignedrole).toBeDefined();
        scope.assignedrole();
        // HttpFactoryDeferred.reject(failureResponse);
        // $rootScope.$apply();

      });

      it('it should call confirmDecision', function () {
        expect(scope.confirmDecision).toBeDefined();
        scope.confirmDecision();
      });

    });
  });
})();
