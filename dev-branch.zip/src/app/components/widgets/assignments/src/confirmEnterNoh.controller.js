(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .controller('confirmENohController', function ($scope, ngDialog, HttpFactory, CONSTANTS, toastr, eroh, shareAssign, hStatus, pdfFileName, transactionDate, dockType) {
      var vm = this;
      $scope.dockType = dockType;
      vm.cancel = function () {
        ngDialog.closeAll();
      };

      $scope.abandonChanges = function () {
        ngDialog.close(lastDialog(), false);
      };

      function lastDialog() {
        var openDialogs = ngDialog.getOpenDialogs();
        return openDialogs[openDialogs.length - 1];
      }
      /* istanbul ignore next*/
      $scope.closeDialog = function (popupsToClose, pdfData) {
        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose], pdfData);
        } else {
          ngDialog.close();
        }
      };
      /* istanbul ignore next*/
      $scope.submitResponse = function () {
        $scope.disableUpload = true;
        $scope.loading = true;

        eroh.statusCode = hStatus.selectedStatusType;
        $scope.hearingRoomRoster = eroh;
        $scope.hearingRoomRoster.transactionDate = transactionDate ? new Date(transactionDate).getTime() : new Date();
        shareAssign.completionDate = new Date().getTime();
        shareAssign.priorityIndicator = shareAssign.priorityIndicator ? 'Y' : 'N';
        shareAssign.completionCode = hStatus.selectedStatusType;
        $scope.currentAssignment = shareAssign;
        $scope.currentAssignment.transactionDate = $scope.hearingRoomRoster.transactionDate;
        var data = {
          "hearingRoomRoster": $scope.hearingRoomRoster,
          "currentAssignment": $scope.currentAssignment,
          "fileName": pdfFileName,
          "docType": $scope.dockType
        };

        HttpFactory.putActions(CONSTANTS.URL.SUBMITENOH, data)
          .then(function (successResponse) {

            $scope.disableUpload = false;
            toastr.success(CONSTANTS.TOASTER.srd, {
              iconClass: 'toast-success'
            });
            $scope.pdfContentPreview = successResponse.data.fileContent;
            $scope.closeDialog(1, $scope.pdfContentPreview);

          }, function (failureResponse) {
            $scope.disableUpload = false;
            toastr.clear();
            toastr.error(failureResponse.data.message, {
              iconClass: 'toast-danger'
            });
          });

      };


    });
})();
