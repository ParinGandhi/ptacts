(function () {
  "use strict";
  angular
    .module('ptabe2e')
    .controller('completedDateVerificationController', function (ngDialog, $timeout, definedCompdate) {
      var vm = this;
      var emptydate = null;
      vm.revertAllChanges = function () {
        closeDialogDt(1);
      };

      function closeChangesDialog(popupsToClose) {
        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose], definedCompdate);
        } else {
          ngDialog.close();
        }
      }

      function closeDialogDt(popupsToClose) {
        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose], emptydate);
        } else {
          ngDialog.close();
        }
      }

      vm.closeDialog = function () {
        closeChangesDialog(1);
      };
    });
})();
