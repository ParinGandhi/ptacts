(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('CARDDController', function (HttpFactory, $rootScope, $log, $window, CommonHelperService, ngDialog, CONSTANTS) {

      var vm = this;
      var selectedRow = $rootScope.sharedItems[0];
      var assignmentType = null;

      vm.disableButton = true;


      /** GET call to retrieve a list of panel administrators */
      function getPanelAdmins() {
        HttpFactory.getActions('/user-management/user-privileges?identifier=Panel%20Administrators')
          .then(function (panelAdminList) {
            $log.log('panelAdminList: ', panelAdminList);
            vm.panelAdminList = panelAdminList.data;
            vm.originalPanelAdminList = angular.copy(panelAdminList.data);
          }, function (panelAdminsFailure) {
            $log.log('panelAdminsFailure: ', panelAdminsFailure);

          });
      }

      getPanelAdmins();


      /** Function to set the selected panel admin. It will also enable the Create button */
      vm.selectPanelAdmin = function (panelAdmin) {
        vm.disableButton = false;
        vm.selectedPanelAdmin = panelAdmin;
      };


      /** Function to set the label of the button based on assignment type */
      function setButtonLabel() {
        switch (selectedRow.assignmentType) {
          case 'CARDRAFT':
            vm.buttonLabel = "Admin remand draft completed";
            break;
          case 'CDDRAFT':
            vm.buttonLabel = "Dismissal draft completed";
            break;
          default:
            break;
        }
      }

      setButtonLabel();


      /** This function will search for the panel admin */
      vm.searchForPanelAdmin = function (input) {
        var tempList = [];
        if (angular.isDefined(input) && input.trim() !== "") {
          angular.forEach(vm.originalPanelAdminList, function (currentPanelAdmin) {
            if (currentPanelAdmin.assigneeFullNameText.toLowerCase().includes(input.toLowerCase())) {
              tempList.push(currentPanelAdmin);
            }
          });
          vm.panelAdminList = angular.copy(tempList);
        } else {
          vm.panelAdminList = angular.copy(vm.originalPanelAdminList);
        }
      };


      /** Function to submit the asdmin remand or dismissal */
      vm.draftCompleted = function () {
        var currentTime = new Date().getTime();
        $log.log("selectedRow: ", selectedRow);
        var assignmentInfo = angular.copy(selectedRow);
        assignmentInfo.completionDate = currentTime;
        assignmentInfo.priorityIndicator = assignmentInfo.priorityIndicator ? 'Y' : 'N';

        if (assignmentInfo.assignmentType === 'CDDRAFT') {
          assignmentInfo.completionCode = 'ADMIN_PANEL';
          assignmentType = "Dismissal draft";
        }
        if (assignmentInfo.assignmentType === 'CARDRAFT') {
          assignmentInfo.completionCode = 'ADMIN_PANEL';
          assignmentType = "Admin remand draft";
        }

        var adminRemandDismissalObject = {
          "serialNumber": assignmentInfo.serialNumber,
          "appealNumber": assignmentInfo.appealNumber,
          "panelDate": null,
          "fileName": null,
          "currentAssignment": assignmentInfo,
          "newAssignment": assignmentInfo,
          'judgeData': {
            "identifier": vm.selectedPanelAdmin.assigneeNumberText
          },
          "audit": {
            "createUserIdentifier": assignmentInfo.audit.createUserIdentifier,
            "lastModifiedUserIdentifier": $window.sessionStorage.getItem('workerNumber'),
            "lastModifiedTimestamp": currentTime,
            "createdUserName": assignmentInfo.audit.createdUserName,
            "lastModifiedUserName": assignmentInfo.audit.lastModifiedUserName,
            "createTimestamp": assignmentInfo.audit.createTimestamp,
            "lockControlNumber": assignmentInfo.audit.lockControlNumber
          }
        };

        $log.log("adminRemandDismissalObject: ", adminRemandDismissalObject);
        HttpFactory.postActions('/ptab-notice/panelAdmin', adminRemandDismissalObject)
          .then(function (adminRemandDismissalPostSuccess) {
            $log.log('adminRemandDismissalPostSuccess: ', adminRemandDismissalPostSuccess);
            CommonHelperService.setToastr("Successfully created " + assignmentType + " assignment", "success");
            ngDialog.closeAll(true);
          }, function (adminRemandDismissalPostFailure) {
            $log.log('adminRemandDismissalPostFailure: ', adminRemandDismissalPostFailure);
            CommonHelperService.setToastr("Failure creating " + assignmentType + " assignment", "error");
          });

      };


      /** This function will open the panel history modal */
      /* istanbul ignore next */
      vm.viewPanelHistory = function () {
        HttpFactory.getActions(CONSTANTS.URL.GET_PANEL_HISTORY + selectedRow.appealNumber)
          .then(function (successResponse) {
            vm.tempPanelHistory = [];
            vm.panelHistory = [];
            angular.forEach(successResponse.data.judgePanel, function (record) {
              $log.info(record);
              var tempRecord = [];
              var sortedPanelList = record.panelToBeCreated;
              for (var i = 0; i < sortedPanelList.length; i++) {
                if (sortedPanelList[i].activeIndicator !== "P") {
                  sortedPanelList[i].panelVersion = "Original panel";
                  tempRecord.push(sortedPanelList[i]);
                  vm.panelHistory.push(sortedPanelList[i]);
                }
              }
              if (tempRecord.length > 0) {
                vm.tempPanelHistory.push(tempRecord);
              }
            });

            if (angular.isDefined(vm.panelHistory) && vm.panelHistory.length > 0) {
              ngDialog.open({
                template: "app/components/widgets/assignments/src/viewPanelHistory.html",
                controller: 'ViewPanelHistoryController',
                controllerAs: 'vm',
                width: '50%',
                showClose: false,
                closeByEscape: false,
                closeByDocument: false,
                resolve: {
                  panelHistory: function () {
                    return vm.panelHistory;
                  }
                }
              });
            } else {
              CommonHelperService.setToastr(CONSTANTS.TOASTER.noPanelHistory, 'error');
            }
          }, function () {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.noPanelHistory, 'error');
          });
      };


    });
})();
