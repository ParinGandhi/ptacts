(function () {
  'use strict';

  describe('CommentsNotesController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['getOpenDialogs', 'close']);
    var controller, scope, $rootScope;
    var timeout;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;
    var caseInfo, maxSequenceNumbers, notesList, commentsList;
    maxSequenceNumbers = {
      notes: "hi"
    }
    caseInfo = [{
      "text": "added"
    }]

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      $rootScope.userInfo = {
        userId: "sbartlett"
      }
      controller = $controller('CommentsNotesController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        caseInfo: caseInfo,
        maxSequenceNumbers: maxSequenceNumbers,
        notesList: notesList,
        commentsList: commentsList,
        HttpFactory: HttpFactory

      });
    }));

    describe('CommentsNotesController ', function () {

      it('it should call successResponse ', function () {

        successResponse = {
          data: {
          }
        };

        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();
      });

      it(' failureResponse ', function () {

        var failureResponse = {
          data: {}
        };
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });

      it('should call addComment  ', function () {

        expect(controller.addComment).toBeDefined();
        controller.addComment();
      });

      it('should call addComment ', function () {
        expect(controller.addNote).toBeDefined();
        controller.addNote();
      });

      it('should call closeModal ', function () {
        var ngDialogArray = [ngDialog, ngDialog];
        expect(ngDialog.close).toBeDefined();
        expect(controller.closeModal).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        controller.closeModal();
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog);

        expect(ngDialog.close).toBeDefined();
        expect(controller.closeModal).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.closeModal();
        expect(ngDialog.close).toHaveBeenCalled();
      });

      it('should call addComment ', function () {
        controller.tableData = [];
        controller.notesList = [{
          noteText: "added",
          audit: {
            lastModifiedUserIdentifier: "gandhi",
            lastModifiedTimestamp: "2019"
          }
        }];
        controller.commentsList = [{
          commentText: "added",
          audit: {
            lastModifiedUserIdentifier: "gandhi",
            lastModifiedTimestamp: "2019"
          }
        }];
        expect(controller.createTableData).toBeDefined();
        controller.createTableData();
      });

      it('should call checkComment ', function () {
        controller.selectedComment  = "comment"
        expect(controller.checkComment).toBeDefined();
        controller.checkComment();
      });

      it('should call checkNotes ', function () {
        controller.enteredNote = "added";
        expect(controller.checkNotes).toBeDefined();
        controller.checkNotes();
      });

      it('should call checkNotes ', function () {
        expect(controller.checkNotes).toBeDefined();
        controller.checkNotes();
      });

      it('should call saveNotesAndComments ', function () {
        controller.newComments = [{
          commentText: "added"
        },{
          commentText: "added"
        }]
        expect(controller.saveNotesAndComments).toBeDefined();
        controller.saveNotesAndComments();
      });

      it('should call saveNotesAndComments ', function () {
        controller.newNotes = [{
          noteText: "added"
        },{
          noteText: "added"
        }]
        expect(controller.saveNotesAndComments).toBeDefined();
        controller.saveNotesAndComments();
      });

      it('should call saveComments ', function () {
        var a = {
          sequenceNumber : 0
        }
        var b = {
          sequenceNumber : 1
        }
        successResponse = {
          data: {
            sort: function (a, b){

            }
          }
        };

        expect(controller.saveComments).toBeDefined();
        controller.saveComments();

        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();
      });

      it('should call saveNotes ', function () {
        var a = {
          sequenceNumber : 0
        }
        var b = {
          sequenceNumber : 1
        }
        successResponse = {
          data: {
            appealNoteHistoryList: {
              sort: function (a, b){

              }
            }
          }
        };

        expect(controller.saveNotes).toBeDefined();
        controller.saveNotes();

        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();
      });

      it('saveNotes failureResponse ', function () {

        var failureResponse = {
          data: {}
        };
        expect(controller.saveNotes).toBeDefined();
        controller.saveNotes();

        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });

      it('saveComments failureResponse ', function () {

        var failureResponse = {
          data: {}
        };

        expect(controller.saveComments).toBeDefined();
        controller.saveComments();

        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });
    });
  });
})();
