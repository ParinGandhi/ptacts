(function () {
  'use strict';

  describe('ReassignmentModalController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'closeAll', 'getOpenDialogs', 'close']);
    var controller, scope, $rootScope;
    var timeout;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;

    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              userInfo: "eswift"
            }
          }
        }
      }
    };




    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);

      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      var assignmentRows = {
        firstName: "testing"
      }

      successResponse = {
        data: {
          managersData: {
            managersData: 'managersData'
          },
          teamData: {
            teamData: 'teamData'
          },
          groupData: {
            groupData: 'groupData'
          },
          workQueueData: {
            workQueueData: 'workQueueData'
          }
        }
      };

      controller = $controller('ReassignmentModalController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory,
        assignmentRows: assignmentRows,
        successResponse: successResponse

      });
    }));

    describe('ReassignmentModalController ', function () {

      it('it should call selectOk ', function () {
        expect(controller['selectOk']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.selectOk();
      });

      it('it should call getAssignedTo  ', function () {
        expect(scope.getAssignedTo).toBeDefined();
        scope.getAssignedTo();
        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();
      });

      it('it should call getAssignedTo with no groupData', function () {

        successResponse.data.groupData = null;

        expect(scope.getAssignedTo).toBeDefined();
        scope.getAssignedTo();
        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();
      });

      it('it should call getAssignedTo with groupData length as 0', function () {

        successResponse.data.groupData = [];

        expect(scope.getAssignedTo).toBeDefined();
        scope.getAssignedTo();
        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();
      });


      it('it should call getAssignedTo and retrieve failureResponse', function () {

        failureResponse = {
          data: {}
        };

        expect(scope.getAssignedTo).toBeDefined();
        scope.getAssignedTo();
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();

      });

      it('it should call moreAssigneesData ', function () {
        expect(scope.moreAssigneesData).toBeDefined();
        scope.moreAssigneesData();
      });


      it('it should call cancelReassign', function () {
        expect(controller['cancelReassign']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.cancelReassign();
      });


    });
  });
})();
