(function () {
  'use strict';

  describe('completedDateVerificationController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close']);
    var controller, scope, $rootScope;
    var definedCompdate;

    beforeEach(inject(function (_$controller_, _$rootScope_) {
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;


      controller = $controller('completedDateVerificationController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        definedCompdate: definedCompdate
      });
    }));

    describe('completedDateVerificationController ', function () {


      it('it should call closeDialog ', function () {

        var ngDialogArray = [ngDialog, ngDialog];
        var definedCompdate;
        expect(ngDialog.close).toBeDefined();
        expect(controller['closeDialog']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        controller.closeDialog();
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog, definedCompdate);

        expect(ngDialog.close).toBeDefined();
        expect(controller['closeDialog']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.closeDialog();
        expect(ngDialog.close).toHaveBeenCalledWith();

      });

      it('it should call revertAllChanges ', function () {

        var ngDialogArray = [ngDialog, ngDialog];
        var emptydate;
        expect(ngDialog.close).toBeDefined();
        expect(controller['revertAllChanges']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray, emptydate);
        controller.revertAllChanges();
        expect(ngDialog.close).toHaveBeenCalledWith();

        expect(ngDialog.close).toBeDefined();
        expect(controller['revertAllChanges']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.revertAllChanges();
        expect(ngDialog.close).toHaveBeenCalledWith();

      });


    });
  });
})();
