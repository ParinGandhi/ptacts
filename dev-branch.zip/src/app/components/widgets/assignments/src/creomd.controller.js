(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('CREOMDController', function (HttpFactory, $rootScope, $log, $window, CommonHelperService, ngDialog, CONSTANTS) {

      var vm = this;
      vm.submitted = false;
      var selectedRow = $rootScope.sharedItems[0];
      vm.documentType = $rootScope.sharedItems[0].assignmentTypeDescription;
      vm.isCreateAssignment = $rootScope.sharedItems[0].assignmentTypeDescription.toLowerCase().includes("create");
      vm.notes = $rootScope.sharedItems[0].notes;


      function setModal() {
        if (vm.isCreateAssignment) {
          vm.nextAssignment = "Review " + $rootScope.sharedItems[0].assignmentTypeDescription.split(" ").slice(1).join(" ");
          vm.buttonLabel = "Submit for review";
        } else {
          vm.nextAssignment = "Mail " + $rootScope.sharedItems[0].assignmentTypeDescription.split(" ").slice(1).join(" ");
          vm.buttonLabel = "Ready for mail";
        }
        vm.message = 'Select "' + vm.buttonLabel + '" to generate and assign a "' + vm.nextAssignment + '" assignment';
      }
      setModal();

      /** Function to submit the asdmin remand or dismissal */
      vm.draftCompleted = function () {
        vm.submitted = true;
        var currentTime = new Date().getTime();
        $log.log("selectedRow: ", selectedRow);
        var assignmentInfo = angular.copy(selectedRow);
        assignmentInfo.completionDate = currentTime;
        assignmentInfo.priorityIndicator = assignmentInfo.priorityIndicator ? 'Y' : 'N';
        var completionCode = vm.isCreateAssignment ? "CREATE_" + selectedRow.assignmentType : "REVIEW_" + selectedRow.assignmentType;


        var data = {
          "assignmentType": assignmentInfo.assignmentType,
          "assignee": assignmentInfo.assignee,
          "serialNumber": assignmentInfo.serialNumber,
          "title": assignmentInfo.title,
          "description": assignmentInfo.description,
          "dueDate": assignmentInfo.dueDate,
          "completionDate": new Date().getTime(),
          "completionCode": completionCode,
          "caseType": assignmentInfo.caseType,
          "appealNumber": assignmentInfo.appealNumber,
          "sequenceNumber": assignmentInfo.sequenceNumber,
          "priorityIndicator": assignmentInfo.priorityIndicator,
          "assignmentIdentifier": assignmentInfo.assignmentIdentifier,
          "assignor": assignmentInfo.assignor,
          "activeIndicator": assignmentInfo.activeIndicator,
          "documentReviewerName": $window.sessionStorage.getItem("workerNumber"),
          "documentReviewDate": new Date().getTime(),
          "notes": vm.notes,
          "audit": {
            "createUserIdentifier": $window.sessionStorage.getItem("workerNumber"),
            "lastModifiedUserIdentifier": $window.sessionStorage.getItem("workerNumber"),
            "lockControlNumber": assignmentInfo.audit.lockControlNumber,
            "createTimestamp": assignmentInfo.audit.createTimestamp,
            "lastModifiedTimestamp": new Date().getTime()
          }

        };

        HttpFactory.putActions(CONSTANTS.URL.UPDATE_ASSIGNMENT, data)
          .then(function (erratumOrderMiscSuccess) {
            CommonHelperService.setToastr(erratumOrderMiscSuccess.data.message, "success");
            ngDialog.closeAll(true);
          }, function (erraturmOrderMiscFailure) {
            CommonHelperService.setToastr(erraturmOrderMiscFailure.data.message, "error");
          }).finally(function () {
            vm.submitted = false;
          });

      };

    });
})();
