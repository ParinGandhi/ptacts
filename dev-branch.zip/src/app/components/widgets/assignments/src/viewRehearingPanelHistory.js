(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('ViewRehearingPanelHistoryController', function ($scope, panelHistory, CommonHelperService, uiGridConstants, $filter) {

      /* istanbul ignore next */
      $scope.panelHistoryGridOptions = {
        enableGridMenu: true,
        enableSelectAll: true,
        useExternalFiltering: false,
        exporterCsvFilename: 'Rehearing_panel_history_' + CommonHelperService.getCurrentTime() + '.csv',
        exporterOlderExcelCompatibility: true,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        gridMenuShowHideColumns: false,
        paginationPageSizes: [10, 25, 50, 100],
        paginationPageSize: 25,
        enableFiltering: true,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.WHEN_NEEDED,
        exporterFieldCallback: function (grid, row, col, value) {
          $scope.panelHistoryGridOptions.exporterCsvFilename = 'Rehearing_panel_history_' + CommonHelperService.getCurrentTime() + '.csv';
          if (col.colDef.type === 'date') {
            if (col.colDef.field === 'panelDate') {
              value = $filter('date')(value, 'MM/dd/yyyy');
            } else {
              value = $filter('date')(value, 'MM/dd/yyyy hh:mm:ss a');
            }

            if (angular.isUndefined(value) || value === null) {
              value = "";
            } else {
              value = " " + value;
            }
          }
          return value;
        },
        columnDefs: [{
            "displayName": "Decision",
            headerTooltip: 'Decision',
            "field": "decisionCategoryName",
            "type": "string",
            "width": 160
          },
          {
            "displayName": "Panel role",
            headerTooltip: 'Panel role',
            "field": "panelMember",
            "type": "string",
            "width": 135,
            "sort": {
              "direction": uiGridConstants.ASC,
              "priority": 2
            }
          },
          {
            "displayName": "Name",
            headerTooltip: 'Name',
            "field": "panelName",
            "type": "string",
            "width": 180
          },
          {
            "displayName": "Status",
            headerTooltip: 'Status',
            "field": "apjStatus",
            "type": "string",
            "width": 115
          },
          {
            "displayName": "Paneled date",
            headerTooltip: 'Paneled date',
            "field": "assignedDate",
            "type": "date",
            "cellFilter": 'date:"MM/dd/yyyy"',
            "width": 160,
            "sort": {
              "direction": uiGridConstants.DESC,
              "priority": 1
            }
          },
          {
            "displayName": "Updated by",
            headerTooltip: 'Updated by',
            "field": "lastModifiedUserId",
            "type": "string",
            "width": 145
          },
          {
            "displayName": "Decision code",
            headerTooltip: 'Decision code',
            "field": "location",
            "type": "string",
            "width": 145,
            "sort": {
              "direction": uiGridConstants.DESC,
              "priority": 0
            }
          },
          {
            "displayName": "Timestamp",
            headerTooltip: 'Timestamp',
            "field": "lastModifiedTs",
            "type": "date",
            "cellFilter": 'date:"MM/dd/yyyy hh:mm:ss a"',
            "width": 180
          }
        ],
        onRegisterApi: function (gridApi) {
          $scope.gridApi = gridApi;
        }
      };

      $scope.tempPanelHistory = [];

      angular.forEach(panelHistory.judgePanel, function (panel) {
        var tempPanelVersion = panel.reconsiderSequenceNumber;
        angular.forEach(panel.panelToBeCreated, function (panelToBeCreated) {
          panelToBeCreated.panelVersion = setGridTitle(tempPanelVersion);
          $scope.tempPanelHistory.push(panelToBeCreated);
        });
      });

      $scope.allPanelHistory = $scope.tempPanelHistory.filter(function (el) {
        return el != null;
      });
      $scope.panelHistoryGridOptions.data = $scope.allPanelHistory;

      $scope.rehearingPaneledOnly = [];
      angular.forEach($scope.allPanelHistory, function (panel) {
        if (panel.activeIndicator === "Y") {
          $scope.rehearingPaneledOnly.push(panel);
        }
      });

      function setGridTitle(index) {
        if (index === 0) {
          return "Initial decision";
        } else {
          return ordinalSuffixOf(index) + " rehearing panel";
        }
      }

      function ordinalSuffixOf(i) {
        var j = i % 10,
          k = i % 100;
        if (j == 1 && k != 11) {
          return i + "st";
        }
        if (j == 2 && k != 12) {
          return i + "nd";
        }
        if (j == 3 && k != 13) {
          return i + "rd";
        }
        return i + "th";
      }


      $scope.isRehearingPaneledOnly = false;

      $scope.toggleRehearingPaneled = function () {
        $scope.isRehearingPaneledOnly = !$scope.isRehearingPaneledOnly;
        if ($scope.isRehearingPaneledOnly) {
          $scope.panelHistoryGridOptions.data = $scope.rehearingPaneledOnly;
        } else {
          $scope.panelHistoryGridOptions.data = $scope.allPanelHistory;
        }
      };


    });
})();
