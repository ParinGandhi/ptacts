(function () {
  'use strict';
  /**
   * pdfUpload Controller is attached to the confirm pdf upload dialog
   */
  angular
    .module('ptabe2e')
    .controller('submitPdfController', function (ngDialog, HttpFactory, CONSTANTS, $scope, $rootScope, shareAssign,
      hearingAtten, $http, $sce, genPdfFile, hStatus, specialHearingType, remoteLoc, CommonHelperService,
      eroh, transactionDate, $log, dockType) {
      var vm = this;
      // $rootScope.responseFail = false;
      var scope = angular.element(document.getElementById('mainTabId')).scope();
      // $scope.currentDocketInfo = angular.copy(docketInfo[0]);
      $scope.shareAssign = shareAssign;
      $scope.hearingAtten = hearingAtten;
      $scope.hStatus = hStatus;
      $scope.specialHearingType = specialHearingType;
      $scope.remoteLoc = remoteLoc;
      $scope.eroh = eroh;
      $scope.genPdfFile = genPdfFile;
      $scope.transactionDate = transactionDate;
      // $scope.title = $scope.docInfo.docFlag ? "Upload documents?" : "Update status code?"
      // $scope.message = $scope.docInfo.docFlag ? "Are you sure you want to upload the documents?" : "Are you sure you want to update the status codes?"
      $scope.dockType = dockType;

      $scope.disableAssignmentType = false;

      vm.userInfo = scope.vm.userInfo;

      $scope.showError = false;
      $scope.closeAnnouncementDialog = function (popupsToClose, pdfData) {
        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose], pdfData);
        } else {
          ngDialog.close();
        }
      };

      /* istanbul ignore next */
      $scope.submitResponse = function () {
        $scope.disableUpload = true;
        $scope.loading = true;
        $scope.eroh.statusCode = $scope.hStatus.selectedStatusType;
        if ($scope.hearingAtten) {
          $scope.eroh.hearingAttendanceStatusCd = $scope.hearingAtten.selectedHearingCode;
        }
        $scope.eroh.specialTypeIndicator = $scope.specialHearingType.selectedStatusType;
        $scope.eroh.remoteLocationCd = $scope.remoteLoc.selectedCode;
        if ($scope.eroh.remoteLocationCd === "NR") {
          $scope.eroh.remoteUsersCount = 0;
        }
        // $scope.eroh.remoteUsersCount  = $scope.remoteUsersCount;
        $scope.hearingRoomRoster = $scope.eroh;
        $scope.hearingRoomRoster.lastModifiedTime = new Date().getTime();
        $scope.hearingRoomRoster.lastModifiedUserIdentifier = vm.userInfo.userId;
        $scope.hearingRoomRoster.transactionDate = $scope.transactionDate ? new Date($scope.transactionDate).getTime() : new Date();
        $scope.shareAssign.priorityIndicator = $scope.shareAssign.priorityIndicator ? 'Y' : 'N';
        $scope.shareAssign.completionCode = $scope.eroh.hearingAttendanceStatusCd ? $scope.eroh.hearingAttendanceStatusCd : $scope.hStatus.selectedStatusType;
        $scope.currentAssignment = $scope.shareAssign;
        $scope.currentAssignment.audit = {
          "createUserIdentifier": vm.userInfo.userInfo,
          "lastModifiedUserIdentifier": vm.userInfo.userId,
          "lastModifiedTimestamp": new Date().getTime(),
          "createdUserName": vm.userInfo.displayName,
          "lastModifiedUserName": vm.userInfo.displayName,
          "createTimestamp": new Date().getTime(),
          "lockControlNumber": 0
        };
        $scope.currentAssignment.transactionDate = $scope.hearingRoomRoster.transactionDate;
        var data = {
          "hearingRoomRoster": $scope.hearingRoomRoster,
          "currentAssignment": $scope.currentAssignment,
          "fileName": $scope.genPdfFile,
          "docType": $scope.dockType
        };

        HttpFactory.putActions(CONSTANTS.URL.SUBMITENOH, data)
          .then(function (successResponse) {
            $scope.disableUpload = false;
            $scope.showError = false;
            $scope.PostDataResponse = successResponse.data;
            $scope.closeAnnouncementDialog(1, $scope.PostDataResponse);
          }, function (failureResponse) {
            $scope.disableUpload = false;
            $scope.showError = false;
            CommonHelperService.setToastr(failureResponse.data.message, "error");
          });

      };





      /* function to close popup */
      $scope.cancel = function () {
        $scope.closeAnnouncementDialog(1);
      };
      /* istanbul ignore next */
      $scope.getPreview = function (contents) {

        $http.get(contents, {
            responseType: 'arraybuffer',
            headers: {
              'Accept': 'application/pdf'
            }
          })
          .success(function (data) {
            var file = new Blob([data], {
              type: 'application/pdf'
            });
            var fileURL = URL.createObjectURL(file);
            // $scope.uploadedPdfContent = $sce.trustAsResourceUrl(fileURL);
            var fileOne = window.URL.createObjectURL(file);
            // document.querySelector("iframe").src = $sce.trustAsResourceUrl(fileOne);
            $scope.pdfContent = $sce.trustAsResourceUrl(fileOne);
            if (fileURL !== '' || angular.isDefined(fileURL)) {
              $scope.show = false;
              $scope.editable = false;
              $scope.pdfStyle = {
                "border": "1px solid grey"
              };
            }

            closeAnnouncementDialog(1, $scope.PostDataResponse);
          }).error(function (res) {
            $log.info('ERROR' + res);
          });
      };



    });
})();
