(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .directive('duFileModel', ['$parse', /* istanbul ignore next */ function ($parse) {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {

          element.bind('change', function () {
            scope.$apply(function () {
              // intentional
            });
          });
        }
      };
    }])

    .directive('duOnChange', /* istanbul ignore next */ function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var onChangeFunc = scope.$eval(attrs.duOnChange);
          element.bind('change', onChangeFunc);
        }
      };
    })
    .controller('reviewRequestsController', function ($scope, ngDialog, items, type, widgetIdentifier, HttpFactory, CONSTANTS, CommonHelperService) {
        var vm = this;
        var scope = angular.element(document.getElementById('mainTabId')).scope();
        vm.type = type;
        switch (type) {
          // review reconsideration for additional decisional units (ADU)
          case 'RRCDU':
            vm.currentLabel = 'Current due date points';
            vm.requestedLabel = 'Requested due date points';
            vm.panelTitle = 'Review correct due date points';
            vm.creditType = "PTs ";
            break;
            //   case 'PC':
            //     vm.currentLabel = 'Current production credits';
            //     vm.requestedLabel = 'Requested production credits';
            //     vm.panelTitle = 'Review correct production credits (PC)';
            //     vm.creditType = "PCs ";
            //     break;
            //   case "ADU":
            //     vm.currentLabel = 'Total time to draft decision *';
            //     vm.requestedLabel = '# of additional decisional units requested';
            //     vm.panelTitle = 'Request additional decisional units (ADU)';
            //     vm.creditType = "ADUs ";
            //     vm.showInfo = true;
            //     break;
            //   case "RDU":
            //     vm.currentLabel = 'My decision units (DU)';
            //     vm.requestedLabel = 'DU(s) to share';
            //     vm.panelTitle = 'Reallocate decisional units (DU)';
            //     vm.creditType = "ADUs reallocated ";
            //     break;
            //   case "RCDU":
            //     vm.currentLabel = 'Total time to draft decision *';
            //     vm.requestedLabel = '# of additional decisional units requested';
            //     vm.panelTitle = 'Reconsideration for additional decisional units (ADU)';
            //     vm.supervisorTitle = "2nd line supervisor *";
            //     vm.creditType = "ADUs ";
            //     vm.showInfo = true;
            //     break;
          default:
            // review reconsideration for additional decisional units (ADU)
            vm.currentLabel = 'Total time to draft decision';
            vm.requestedLabel = '# of additional decisional units requested';
            vm.approvedLabel = '# of additional units to award';
            vm.panelTitle = 'Review reconsideration for additional decisional units (ADU)';
            break;
        }

        // vm.requestedLabel += " *";
        vm.userInfo = scope.vm.userInfo;
        buildCaseData(items.entity);
        vm.currentDU = items.entity.decisionalUnits;
        vm.completionDateLabel = "Decision mail date";
        vm.currentADU = items.entity.additionalDecisionalUnits;
        vm.newDU = "";
        vm.newADU = "";
        vm.todaysDate = new Date().getTime();
        vm.correctDuReason = "";
        vm.assignmentId = items.entity.ptabAssignmentId;
        vm.assignmentTitle = items.entity.assignmentTitle;
        vm.specialType = items.entity.specialType;
        vm.specialTypeTooltip = CONSTANTS.SPECIAL_TYPE_REQUEST.tooltip;
        vm.appealNumber = items.entity.appealNumber;
        vm.assignmentType = items.entity.assignmentType;
        vm.role = items.entity.roleName;
        vm.decisionalUnitsAwarded = items.entity.decisionalUnitsAwarded;
        vm.decisionalUnitsAwardedIdentifier = items.entity.decisionalUnitsAwardedIdentifier;
        vm.lockControlNumber = items.entity.lockControlNumber;
        vm.caseType = items.entity.caseType;
        vm.serialNumber = items.entity.serialNumber;
        vm.completionDate = items.entity.completionDate;
        vm.qualifier = items.entity.qualifier;
        vm.showErrorMessageReason = false;
        vm.showErrorMessageDU = false;
        vm.readyToSave = false;
        var duFile;
        var reader = new FileReader();
        var fileByteArray = [];
        vm.disableSubmit = false;
        vm.sendRequestEmailId = "";
        vm.originalReqId = angular.copy(vm.sendRequestEmailId);
        vm.originalnewDU = angular.copy(vm.newDU);
        vm.originalcorrectDuReason = angular.copy(vm.correctDuReason);
        $scope.cancelupdateAssignDialog = function () {
          // intentional
        };
        vm.checkreason = function () {
          if (vm.correctDuReason === null || vm.correctDuReason === "" || angular.isUndefined(vm.correctDuReason)) {
            vm.errorMessageForReason = "Reason is mandatory";
            vm.showErrorMessageReason = true;
            vm.readyToSaveReason = false;
          } else {
            vm.showErrorMessageReason = false;
            vm.readyToSaveReason = true;
          }
        };
        vm.checkDu = function () {
          if (vm.newDU === null || vm.newDU === "" || angular.isUndefined(vm.newDU)) {
            vm.errorMessageForDU = "Decisional units are mandatory";
            vm.showErrorMessageDU = true;
            vm.readyToSaveDU = false;
          } else {
            vm.showErrorMessageDU = false;
            vm.readyToSaveDU = true;
          }
        };
        vm.checkMandatoryFields = function () {
          vm.checkDu();
          vm.checkreason();

        };


        vm.abandonRequest = function () {
          ngDialog.closeAll();
        };

        function buildCaseData(data) {
          vm.caseData = {
            caseNumber: data.appealNumber,
            applicationNumber: data.serialNumber,
            caseType: data.caseType
          };

          vm.caseData.caseTypes = [];
          vm.caseData.caseTypes.push(data.caseType);

        }

        /*istanbul ignore next: toaster error */
        vm.correctCredits = function () {
          vm.checkMandatoryFields();
          if (vm.readyToSaveDU && vm.readyToSaveReason) {
            var data = {
              "decisionalUnits": vm.currentDU,
              "requestedDecisionalUnits": vm.newDU,
              "reason": vm.correctDuReason,
              "supervisorName": $scope.supervisor,
              "completionDate": vm.completionDate,
              "appealNumber": vm.appealNumber,
              "serialNumber": vm.serialNumber,
              "caseType": vm.caseType,
              "audit": {
                "createUserIdentifier": vm.userInfo.userId,
                "lastModifiedUserIdentifier": vm.userInfo.userId
              },
              "decisionalUnitsAwarded": vm.decisionalUnitsAwarded,
              "decisionalUnitsAwardedIdentifier": vm.decisionalUnitsAwardedIdentifier,
              "assignmentType": vm.assignmentType,
              "qualifier": vm.qualifier,
              "assignmentTitle": vm.assignmentTitle,
              "dateOfRequest": new Date().getTime(),
              "widgetIdentifier": widgetIdentifier,
              "specialType": items.entity.specialType ? items.entity.specialType.trim() != "" ? items.entity.specialType : '' : '',
              "sendRequestEmailAddress": vm.sendRequestEmailId,
              "fileName": ($scope.fileInfo != null || $scope.fileInfo != undefined) ? $scope.fileInfo.name : null,
              "attachmentInBytes": fileByteArray
            };
            vm.disableSubmit = true;
            HttpFactory.putActions(CONSTANTS.URL.MY_CREDITS_REQUESTDU + "?requestType=CORRECTDECISIONALUNITS", data)
              .then(function () {
                vm.disableSubmit = false;
                CommonHelperService.setToastr("", "clear");
                CommonHelperService.setToastr(CONSTANTS.TOASTER.cdu, "success");
                ngDialog.closeAll(true);

              }, function () {
                vm.disableSubmit = false;
                CommonHelperService.setToastr("", "clear");
                CommonHelperService.setToastr(CONSTANTS.TOASTER.cduFail, "error");


              });
          }
        };
        vm.abandonChanges = function () {
          if (!angular.equals(vm.originalReqId, vm.sendRequestEmailId) ||
            !angular.equals(vm.originalnewDU, vm.newDU) ||
            !angular.equals(vm.originalcorrectDuReason, vm.correctDuReason)) {
            ngDialog.open({
              template: 'app/components/widgets/myCredits/cancelChanges.html',
              controller: 'CancelChangesController',
              controllerAs: 'vm',
              width: '25%',
              showClose: false,
              closeByEscape: false,
              closeByDocument: false


            }).closePromise.then(function () {
              // intentional
            });
          } else {
            ngDialog.closeAll();
          }
        };

        vm.confirmDecisionDeny = function () {
          ngDialog.open({
            template: 'app/components/widgets/myCredits/confirmdeny.html',
            // controller: 'CancelChangesController',
            controllerAs: 'vm',
            width: '25%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false
          });
        };

        /* istanbul ignore next */
        $scope.getFileInfo = function (file) {
          duFile = document.getElementById("file1");
          $scope.fileInfo = {};
          $scope.fileInfo.name = duFile.files[0].name;
          $scope.fileInfo.path = duFile.value;
          reader.readAsArrayBuffer(duFile.files[0]);
          reader.onloadend = function (evt) {
            if (evt.target.readyState == FileReader.DONE) {
              var arrayBuffer = evt.target.result,
                array = new Uint8Array(arrayBuffer);
              for (var i = 0; i < array.length; i++) {
                fileByteArray.push(array[i]);
              }
            }
          };
        };


        vm.clearFile = function () {
          $scope.fileInfo = {};
        };

        /*istanbul ignore next: toaster error */
        vm.updateCredits = function () {
          var data = {
            "ptabAssignmentId": vm.assignmentId,
            "decisionalUnits": vm.newDU,
            "additionalDecisionalUnits": vm.newADU,
            "reason": vm.reason,
            "lockControlNo": vm.lockControlNumber,
            "lastModifiedUserIdentifier": vm.userInfo.userId,
            "createUserIdentifier": vm.userInfo.userId

          };
          HttpFactory.putActions(CONSTANTS.URL.UPDATE_CREDITS, data)
            .then(function () {
              CommonHelperService.setToastr("", "clear");
              CommonHelperService.setToastr(CONSTANTS.TOASTER.creditsSuccess, "success");
              ngDialog.closeAll(true);

            }, function (failureResponse) {
              CommonHelperService.setToastr("", "clear");
              CommonHelperService.setToastr(failureResponse.data.message, "error");
            });
        };
      }

    );
})();
