(function () {
  'use strict';

  fdescribe('CreateAssignmentController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close', 'open']);
    var newData;
    var initData;
    var controller, scope, $rootScope;
    var timeout, createAssignment;
    var successResponse, failureResponse, workerNumber;
    var $httpBackend, spy, $q, HttpFactoryDeferred;

    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              userInfo: {
                userId: "pgandhi",
                appUserInfo:[
                  {
                    userIdentiifier: "5890"
                  }
                ]
              }
            }
          }
        }
      }
    };


    beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      timeout = _$timeout_;
      HttpFactoryDeferred = _$q_.defer();
      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback1) {
            callback1();

          }
        },
        then: function (callback3, callback4) {
          callback3();
          callback4();
        }
      });

      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);

      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      controller = $controller('CreateAssignmentController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        newData: newData,
        initData: initData,
        HttpFactory: HttpFactory

      });
    }));

    describe('CreateAssignmentController ', function () {


      //   it('it should call myUserRole  ', function () {
      //     var selectedRole = "PTABE2E_Administrator";
      //     var selectedUser = "5768";

      //     expect(scope['myUserRole']).toBeDefined();
      //     successResponse = {
      //       "assignees": [{
      //         "beNo": "5778",
      //         "name": "Baker, Patrick",
      //         "activeCases": "6",
      //         "assigneeStatus": "Active",
      //         "role": null,
      //         "description": null
      //       }, {
      //         "beNo": "1810",
      //         "name": "Bartlett, Steven",
      //         "activeCases": "0",
      //         "assigneeStatus": "Active",
      //         "role": null,
      //         "description": null
      //       }, {
      //         "beNo": "26",
      //         "name": "Brock, Alan",
      //         "activeCases": "0",
      //         "assigneeStatus": "InActive",
      //         "role": null,
      //         "description": null
      //       }, {
      //         "beNo": "5779",
      //         "name": "Bui, Jacqueline",
      //         "activeCases": "3",
      //         "assigneeStatus": "Active",
      //         "role": null,
      //         "description": null
      //       }]

      //     };

      //     successResponse.data = {
      //       assignees: [{
      //         "beNo": "5768",
      //         "name": "Baker, Patrick",
      //         "activeCases": "6",
      //         "assigneeStatus": "Active",
      //         "role": null,
      //         "description": null
      //       }, {
      //         "beNo": "5779",
      //         "name": "Bui, Jacqueline",
      //         "activeCases": "3",
      //         "assigneeStatus": "Active",
      //         "role": null,
      //         "description": null
      //       }]
      //     }
      //     var item = {
      //       "beNo": "5768",
      //       "name": "Baker, Patrick",
      //       "activeCases": "6",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }


      //     scope.myUserRole(selectedRole, selectedUser);
      //     HttpFactoryDeferred.resolve(successResponse);
      //     $rootScope.$apply();


      //   });

      //   it('it should call myUserRole found assignee false', function () {
      //     var selectedRole = "PTABE2E_Administrator";
      //     var selectedUser = "5778";

      //     expect(scope['myUserRole']).toBeDefined();
      //     successResponse = {
      //       "assignees": [{
      //         "beNo": "5778",
      //         "name": "Baker, Patrick",
      //         "activeCases": "6",
      //         "assigneeStatus": "Active",
      //         "role": null,
      //         "description": null
      //       }, {
      //         "beNo": "1810",
      //         "name": "Bartlett, Steven",
      //         "activeCases": "0",
      //         "assigneeStatus": "Active",
      //         "role": null,
      //         "description": null
      //       }, {
      //         "beNo": "26",
      //         "name": "Brock, Alan",
      //         "activeCases": "0",
      //         "assigneeStatus": "InActive",
      //         "role": null,
      //         "description": null
      //       }, {
      //         "beNo": "5779",
      //         "name": "Bui, Jacqueline",
      //         "activeCases": "3",
      //         "assigneeStatus": "Active",
      //         "role": null,
      //         "description": null
      //       }]

      //     };

      //     successResponse.data = {
      //       assignees: [{
      //         "beNo": "5768",
      //         "name": "Baker, Patrick",
      //         "activeCases": "6",
      //         "assigneeStatus": "Active",
      //         "role": null,
      //         "description": null
      //       }, {
      //         "beNo": "5779",
      //         "name": "Bui, Jacqueline",
      //         "activeCases": "3",
      //         "assigneeStatus": "Active",
      //         "role": null,
      //         "description": null
      //       }]
      //     }
      //     var item = {
      //       "beNo": "5768",
      //       "name": "Baker, Patrick",
      //       "activeCases": "6",
      //       "assigneeStatus": "Active",
      //       "role": null,
      //       "description": null
      //     }

      //     scope.myUserRole(selectedRole, selectedUser);
      //     HttpFactoryDeferred.resolve(successResponse);
      //     $rootScope.$apply();


      //   });

      //   it('myUserRole get Actions failureResponse ', function () {
      //     var selectedRole = "PTABE2E_Administrator";
      //     var selectedUser = "5768";
      //     var failureResponse = {
      //       data: {}
      //     };
      //     scope.myUserRole(selectedRole, selectedUser);
      //     HttpFactoryDeferred.reject(failureResponse);
      //     $rootScope.$apply();
      //   });



      it('Should invoke getAssignedTo success', function () {
        scope.Assignedtoforassignmnt = "Ramani, Ravi ";

        successResponse = {
          data: {
            managersData: [{
              assigneeNumberText: "5772",
              assigneeFullNameText: "Ramani, Ravi ",
              activeCaseCount: 0,
              assigneeStatus: "Active",
              userRoles: [{
                roleCode: "PTABE2E_Administrator",
                roleDescription: "Business Admin",
              }]
            }],
            teamData: [{
                assigneeNumberText: "5768",
                assigneeFullNameText: "Gandhi, Parin ",
                activeCaseCount: 60,
                assigneeStatus: "Active",
                userRoles: [{
                  roleCode: "PTABE2E_Administrator",
                  roleDescription: "Business Admin",
                }]
              },
              {
                assigneeNumberText: "5831",
                assigneeFullNameText: "Korem, Divesh Reddy",
                activeCaseCount: 7,
                assigneeStatus: "Active",
                userRoles: [{
                  roleCode: "PTABE2E_Administrator",
                  roleDescription: "Business Admin"
                }]
              },
              {
                assigneeNumberText: "5791",
                assigneeFullNameText: "Murali, Krishna ",
                activeCaseCount: 15,
                assigneeStatus: "Active",
                userRoles: [{
                  roleCode: "PTABE2E_Administrator",
                  roleDescription: "Business Admin"
                }]
              }
            ],
            groupData: [{
                assigneeNumberText: "5768",
                assigneeFullNameText: "Gandhi, Parin ",
                activeCaseCount: 60,
                assigneeStatus: "Active",
                userRoles: [{
                  roleCode: "PTABE2E_Administrator",
                  roleDescription: "Business Admin"
                }]
              },
              {
                assigneeNumberText: "5890",
                assigneeFullNameText: "Koduru, Sasidhar ",
                activeCaseCount: 1,
                assigneeStatus: "Active",
                userRoles: [{
                  roleCode: "PTABE2E_Administrator",
                  roleDescription: "Business Admin"
                }]
              },
              {
                assigneeNumberText: "5831",
                assigneeFullNameText: "Korem, Divesh Reddy",
                activeCaseCount: 7,
                assigneeStatus: "Active",
                userRoles: [{
                  roleCode: "PTABE2E_Administrator",
                  roleDescription: "Business Admin"
                }]
              },
              {
                assigneeNumberText: "5791",
                assigneeFullNameText: "Murali, Krishna ",
                activeCaseCount: 15,
                assigneeStatus: "Active",
                userRoles: [{
                  roleCode: "PTABE2E_Administrator",
                  roleDescription: "Business Admin"
                }]
              },
              {
                assigneeNumberText: "5770",
                assigneeFullNameText: "Mylar, Madhukar ",
                activeCaseCount: 5,
                assigneeStatus: "Active",
                userRoles: [{
                  roleCode: "PTABE2E_Administrator",
                  roleDescription: "Business Admin"
                }]
              }
            ]
          }
        }
        expect(scope['getAssignedTo']).toBeDefined();
        scope.getAssignedTo();

        HttpFactoryDeferred.resolve(successResponse);
        scope.$apply();
      });


      it('Should invoke getAssignedTo success', function () {
        scope.Assignedtoforassignmnt = "Ramani, Ravi ";

        successResponse = {
          data: {
            managersData: [{
              assigneeNumberText: "5772",
              assigneeFullNameText: "Ramani, Ravi ",
              activeCaseCount: 0,
              assigneeStatus: "Active",
              userRoles: [{
                roleCode: "PTABE2E_Administrator",
                roleDescription: "Business Admin"
              }]
            }],
            teamData: [{
                assigneeNumberText: "5768",
                assigneeFullNameText: "Gandhi, Parin ",
                activeCaseCount: 60,
                assigneeStatus: "Active",
                userRoles: [{
                  roleCode: "PTABE2E_Administrator",
                  roleDescription: "Business Admin"
                }]
              },
              {
                assigneeNumberText: "5831",
                assigneeFullNameText: "Korem, Divesh Reddy",
                activeCaseCount: 7,
                assigneeStatus: "Active",
                userRoles: [{
                  roleCode: "PTABE2E_Administrator",
                  roleDescription: "Business Admin"
                }]
              },
              {
                assigneeNumberText: "5791",
                assigneeFullNameText: "Murali, Krishna ",
                activeCaseCount: 15,
                assigneeStatus: "Active",
                userRoles: [{
                  roleCode: "PTABE2E_Administrator",
                  roleDescription: "Business Admin"
                }]
              }
            ],
            groupData: null
          }
        }
        expect(scope['getAssignedTo']).toBeDefined();
        scope.getAssignedTo();

        HttpFactoryDeferred.resolve(successResponse);
        scope.$apply();
      });


      it('Should invoke getAssignedTo success', function () {
        scope.Assignedtoforassignmnt = "Ramani, Ravi ";

        successResponse = {
          data: {
            managersData: [{
              assigneeNumberText: "5772",
              assigneeFullNameText: "Ramani, Ravi ",
              activeCaseCount: 0,
              assigneeStatus: "Active",
              userRoles: [{
                roleCode: "PTABE2E_Administrator",
                roleDescription: "Business Admin"
              }]
            }],
            teamData: [{
                assigneeNumberText: "5768",
                assigneeFullNameText: "Gandhi, Parin ",
                activeCaseCount: 60,
                assigneeStatus: "Active",
                userRoles: [{
                  roleCode: "PTABE2E_Administrator",
                  roleDescription: "Business Admin"
                }]
              },
              {
                assigneeNumberText: "5831",
                assigneeFullNameText: "Korem, Divesh Reddy",
                activeCaseCount: 7,
                assigneeStatus: "Active",
                userRoles: [{
                  roleCode: "PTABE2E_Administrator",
                  roleDescription: "Business Admin"
                }]
              },
              {
                assigneeNumberText: "5791",
                assigneeFullNameText: "Murali, Krishna ",
                activeCaseCount: 15,
                assigneeStatus: "Active",
                userRoles: [{
                  roleCode: "PTABE2E_Administrator",
                  roleDescription: "Business Admin"
                }]
              }
            ],
            groupData: []
          }
        }
        expect(scope['getAssignedTo']).toBeDefined();
        scope.getAssignedTo();

        HttpFactoryDeferred.resolve(successResponse);
        scope.$apply();
      });


      it('Should invoke getAssignedTo failure response', function () {
        scope.currentAssignee = {
          assigneeFullNameText: 'Not assigned',
          activeCaseCount: '',
          assigneeStatus: '',
          assigneeNumberText: ""
        };
        var failureResponse = {
          data: {}
        };

        expect(scope['getAssignedTo']).toBeDefined();
        scope.getAssignedTo();
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });

      it('Should invoke pressEnter', function () {
        expect(scope['moreAssigneesData']).toBeDefined();
        scope.moreAssigneesData();
      });

      it('Should invoke pressEnter', function () {
        var event = {};
        event.keyCode = 13;

        spyOn(scope, 'getCaseTypes');
        expect(scope['getCaseTypes']).toBeDefined();
        expect(scope['pressEnter']).toBeDefined();
        scope.pressEnter(event);
        expect(scope.getCaseTypes).toHaveBeenCalled();
      });


      it('should invoke getAssignmentTypes successfully', function () {
        successResponse: {
          data: "Success"
        }
        expect(scope['getAssignmentTypes']).toBeDefined();
        scope.getAssignmentTypes();

        HttpFactoryDeferred.resolve(successResponse);
        scope.$apply();
      });

      it('should invoke getAssignmentTypes and fail', function () {
        failureResponse: {
          data: "Failure"
        }
        expect(scope['getAssignmentTypes']).toBeDefined();
        scope.getAssignmentTypes();

        HttpFactoryDeferred.reject(failureResponse);
        scope.$apply();
      });

      //   it('Should invoke getCaseTypes success response', function () {
      //     scope.createAssignment = {
      //       "complitionDateInMs": 1532712182719
      //     }
      //     var casenumber = ""

      //     expect(scope['getCaseTypes']).toBeDefined();
      //     scope.getCaseTypes(casenumber);
      //   });

      //   it('Should invoke getCaseTypes success response', function () {
      //     scope.createAssignment = {
      //       "complitionDateInMs": 1532712182719
      //     }
      //     var casenumber = '06000006'

      //     successResponse = {
      //       data: {
      //         "assignmentType": [{
      //             "assignmentTypeCode": "ATP2",
      //             "sequenceNumber": 102,
      //             "descriptionText": "Review Checklist Assignment To POC2",
      //             "displayName": "Review Checklist Assignment To POC2",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "ATP3",
      //             "sequenceNumber": 103,
      //             "descriptionText": "Assignment To POC3",
      //             "displayName": "Assignment To POC3",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "PTABTC",
      //             "sequenceNumber": 104,
      //             "descriptionText": "Appeal not ready for PTAB review",
      //             "displayName": "Appeal not ready for PTAB review",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "PTABCR90",
      //             "sequenceNumber": 105,
      //             "descriptionText": "Appeal not ready for PTAB review (Reexam ex parte)",
      //             "displayName": "Appeal not ready for PTAB review (Reexam ex parte)",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "PTABCR95",
      //             "sequenceNumber": 106,
      //             "descriptionText": "Appeal not ready for PTAB review (Reexam Inter parte)",
      //             "displayName": "Appeal not ready for PTAB review (Reexam Inter parte)",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "AADM",
      //             "sequenceNumber": 1,
      //             "descriptionText": "Assigned to Administrator",
      //             "displayName": "Assigned to Administrator",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "ACFC",
      //             "sequenceNumber": 2,
      //             "descriptionText": "Assigned to Chief Clerk",
      //             "displayName": "Assigned to Chief Clerk",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "ADCC",
      //             "sequenceNumber": 3,
      //             "descriptionText": "Assigned to Deputy Chief Clerk",
      //             "displayName": "Assigned to Deputy Chief Clerk",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "AFLC",
      //             "sequenceNumber": 4,
      //             "descriptionText": "Assigned to File Clerk",
      //             "displayName": "Assigned to File Clerk",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "ALGT",
      //             "sequenceNumber": 5,
      //             "descriptionText": "Assigned to Legal Technician",
      //             "displayName": "Assigned to Legal Technician",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "ALIE",
      //             "sequenceNumber": 6,
      //             "descriptionText": "Assigned to LIE",
      //             "displayName": "Assigned to LIE",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "ALPLG",
      //             "sequenceNumber": 7,
      //             "descriptionText": "Assigned to Lead Paralegal",
      //             "displayName": "Assigned to Lead Paralegal",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "APAS",
      //             "sequenceNumber": 10,
      //             "descriptionText": "Assignment of Appeal Number",
      //             "displayName": "Assignment of Appeal Number",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "APGA",
      //             "sequenceNumber": 11,
      //             "descriptionText": "Assigned to Program Analyst",
      //             "displayName": "Assigned to Program Analyst",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "APLG",
      //             "sequenceNumber": 12,
      //             "descriptionText": "Assigned to Paralegal",
      //             "displayName": "Assigned to Paralegal",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "APMA",
      //             "sequenceNumber": 13,
      //             "descriptionText": "Assigned to Program Management Analyst",
      //             "displayName": "Assigned to Program Management Analyst",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "APWD",
      //             "sequenceNumber": 15,
      //             "descriptionText": "Appeal Awaiting BPAI Docketing",
      //             "displayName": "Appeal Awaiting BPAI Docketing",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "ARPLG",
      //             "sequenceNumber": 17,
      //             "descriptionText": "Assigned to Reviewing Paralegal",
      //             "displayName": "Assigned to Reviewing Paralegal",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "ASLI",
      //             "sequenceNumber": 18,
      //             "descriptionText": "Assigned to SLIE",
      //             "displayName": "Assigned to SLIE",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "ASSIGNED",
      //             "sequenceNumber": 20,
      //             "descriptionText": "Panel Assigned",
      //             "displayName": "Panel Assigned",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "PLIE",
      //             "sequenceNumber": 21,
      //             "descriptionText": "Pending on LIE's Docket",
      //             "displayName": "Pending on LIE's Docket",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "REASSIGNED",
      //             "sequenceNumber": 23,
      //             "descriptionText": "Reassigned",
      //             "displayName": "Reassigned",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "STAGE 1",
      //             "sequenceNumber": 24,
      //             "descriptionText": "Stage 1 Review",
      //             "displayName": "Stage 1 Review",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "STAGE 2",
      //             "sequenceNumber": 25,
      //             "descriptionText": "Stage 2 Review",
      //             "displayName": "Stage 2 Review",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "STAGE 3",
      //             "sequenceNumber": 26,
      //             "descriptionText": "Stage 3 Review",
      //             "displayName": "Stage 3 Review",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "AFCK",
      //             "sequenceNumber": 27,
      //             "descriptionText": "AFCK",
      //             "displayName": "AFCK",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "ATP1",
      //             "sequenceNumber": 101,
      //             "descriptionText": "Review Checklist Assignment To POC1",
      //             "displayName": "Review Checklist Assignment To POC1",
      //             "assignmentCategory": "PRE-APPEAL"
      //           },
      //           {
      //             "assignmentTypeCode": "ATP4",
      //             "sequenceNumber": 103,
      //             "descriptionText": "Assignment To POC4",
      //             "displayName": "Assignment To POC4",
      //             "assignmentCategory": "PRE-APPEAL"
      //           }
      //         ],
      //         "caseType": "PRE-APPEAL",
      //         "nextBusinessDate": 1537761600000,
      //         "serialNumber": "90013948",
      //         "appealNumber": null,
      //         "seqNumber": null
      //       }
      //     }

      //     expect(scope['getCaseTypes']).toBeDefined();
      //     scope.getCaseTypes(casenumber);

      //     // HttpFactoryDeferred.resolve(successResponse);
      //     // $rootScope.$apply();
      //   });

      //   // it('Should invoke getCaseTypes failure response', function () {
      //   //   scope.createAssignment = {
      //   //     "complitionDateInMs": 1532712182719
      //   //   }
      //   //   var casenumber = '06000006'
      //   //   var failureResponse = {
      //   //     data: {}
      //   //   };

      //   //   expect(scope['getCaseTypes']).toBeDefined();
      //   //   scope.getCaseTypes(casenumber);
      //   //   HttpFactoryDeferred.reject(failureResponse);
      //   //   $rootScope.$apply();
      //   // });

      //   it('Should invoke setSelectedType', function () {
      //     var selectedAssignmentType = 'ATP1',
      //       selectedAssignmentTypeDisplayName = 'ATP1';
      //     expect(scope['setSelectedType']).toBeDefined();
      //     scope.setSelectedType(selectedAssignmentType, selectedAssignmentTypeDisplayName);
      //   });

      //   it('Should invoke buildAssignmentData ', function () {
      //     scope.createAssignment = {
      //       "complitionDateInMs": 1532712182719
      //     }
      //     expect(scope['buildAssignmentData']).toBeDefined();
      //     scope.buildAssignmentData();
      //   });

      //   // toaster error
      //   it('Should invoke postAssignment success response', function () {

      //     var data = {
      //       "serialNumber": '06000006'
      //     }

      //     successResponse = {
      //       data: {
      //         "beNo": "5768",
      //         "name": "Baker, Patrick",
      //         "activeCases": "6",
      //         "assigneeStatus": "Active",
      //         "role": null,
      //         "description": null
      //       }
      //     }

      //     expect(scope['postAssignment']).toBeDefined();
      //     scope.postAssignment(data);

      //     // HttpFactoryDeferred.resolve(successResponse);
      //     // $rootScope.$apply();
      //   });

      //   // toaster error
      //   it('Should invoke postAssignment failure response', function () {
      //     var data = {
      //       "serialNumber": '06000006'
      //     }
      //     var failureResponse = {
      //       data: {}
      //     };

      //     expect(scope['postAssignment']).toBeDefined();
      //     scope.postAssignment(data);
      //     // HttpFactoryDeferred.reject(failureResponse);
      //     // $rootScope.$apply();
      //   });

      //   it('Should invoke assignmentDateModel ', function () {
      //     scope.assignmentSaveCloseValTest = true;
      //     var ngDialogArray = [ngDialog, ngDialog];
      //     expect(ngDialog.close).toBeDefined();
      //     expect(scope['assignmentDateModel']).toBeDefined();
      //     ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
      //     scope.assignmentDateModel();
      //     expect(ngDialog.close).toHaveBeenCalledWith(ngDialog);

      //     expect(ngDialog.close).toBeDefined();
      //     expect(scope['assignmentDateModel']).toBeDefined();
      //     ngDialog.getOpenDialogs.and.returnValue(ngDialog);
      //     scope.assignmentDateModel();
      //     expect(ngDialog.close).toHaveBeenCalledWith();
      //   });

      //   it('Should invoke assignmentDateModel ', function () {
      //     scope.assignmentSaveCloseValTest = false;
      //     var ngDialogArray = [ngDialog, ngDialog];
      //     expect(ngDialog.close).toBeDefined();
      //     expect(scope['assignmentDateModel']).toBeDefined();
      //     ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
      //     scope.assignmentDateModel();
      //     expect(ngDialog.close).toHaveBeenCalledWith(ngDialog);

      //     expect(ngDialog.close).toBeDefined();
      //     expect(scope['assignmentDateModel']).toBeDefined();
      //     ngDialog.getOpenDialogs.and.returnValue(ngDialog);
      //     scope.assignmentDateModel();
      //     expect(ngDialog.close).toHaveBeenCalledWith();
      //   });


      //   it('Should invoke assignmentSave ', function () {
      //     expect(scope['assignmentSave']).toBeDefined();
      //     scope.assignmentSave();
      //   });

      //   it('Should invoke assignmentSaveAndClose ', function () {
      //     expect(scope['assignmentSaveAndClose']).toBeDefined();
      //     scope.assignmentSaveAndClose();
      //   });

      //   it('Should invoke closeAssignment ', function () {
      //     expect(ngDialog.closeAll).toBeDefined();
      //     expect(scope['closeAssignment']).toBeDefined();
      //     scope.closeAssignment();
      //     expect(ngDialog.closeAll).toHaveBeenCalledWith();

      //   });

      it('Should invoke assignmentSaveCloseVal if', function () {
        scope.readyToSaveTitle = true;
        scope.readyToSaveType = true;
        scope.readyToSaveRole = true;
        scope.readyToSaveCaseNumber = true;
        scope.readyToSaveAssignedTo = true;
        scope.readyToSaveDate = true;
        scope.readyToSaveCdate = true;

        var ngDialogArray = [ngDialog, ngDialog];
        // expect(ngDialog.close).toBeDefined();
        expect(scope['assignmentSaveCloseVal']).toBeDefined();
        // ngDialog.getOpenDialogs.and.returnValue(ngDialogArray, true);
        scope.assignmentSaveCloseVal();
        // expect(ngDialog.close).toHaveBeenCalledWith(ngDialog, true);

        // expect(ngDialog.closeAll).toBeDefined();
        expect(scope['assignmentSaveCloseVal']).toBeDefined();
        // ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        scope.assignmentSaveCloseVal();
        // expect(ngDialog.closeAll).toHaveBeenCalledWith(true);
      });

      it('Should invoke assignmentSaveCloseVal else', function () {
        scope.readyToSaveTitle = false;
        expect(scope['assignmentSaveCloseVal']).toBeDefined();
        scope.assignmentSaveCloseVal();
      });

      it('Should invoke assignmentSaveVal if', function () {
        scope.readyToSaveTitle = true;
        scope.readyToSaveType = true;
        scope.readyToSaveRole = true;
        scope.readyToSaveCaseNumber = true;
        scope.readyToSaveAssignedTo = true;
        scope.readyToSaveDate = true;
        scope.readyToSaveCdate = true;
        expect(scope['assignmentSaveVal']).toBeDefined();
        scope.assignmentSaveVal();
      });

      it('Should invoke assignmentSaveVal else', function () {
        scope.readyToSaveTitle = false;
        expect(scope['assignmentSaveVal']).toBeDefined();
        scope.assignmentSaveVal();
      });

      it('Should invoke checkLengthTitletx if', function () {
        scope.createAssignment = {
          "taskTitleTx": undefined
        }
        expect(scope['checkLengthTitletx']).toBeDefined();
        scope.checkLengthTitletx();
      });

      it('Should invoke checkLengthTitletx else', function () {
        scope.createAssignment = {
          "taskTitleTx": "ATP4"
        }
        expect(scope['checkLengthTitletx']).toBeDefined();
        scope.checkLengthTitletx();
      });

      it('Should invoke checkLengthAssingmentType if', function () {
        scope.createAssignment = {
          "selectedType": undefined
        }
        expect(scope['checkLengthAssingmentType']).toBeDefined();
        scope.checkLengthAssingmentType();
      });

      it('Should invoke checkLengthAssingmentType else', function () {
        scope.createAssignment = {
          "selectedType": "ATP4"
        }
        expect(scope['checkLengthAssingmentType']).toBeDefined();
        scope.checkLengthAssingmentType();
      });

      //   //   it('Should invoke checkLengthAssingmentRole if', function () {
      //   //     scope.createAssignment = {
      //   //       "selectedRole": undefined
      //   //     }
      //   //     expect(scope['checkLengthAssingmentRole']).toBeDefined();
      //   //     scope.checkLengthAssingmentRole();
      //   //   });

      //   //   it('Should invoke checkLengthAssingmentRole else', function () {
      //   //     scope.createAssignment = {
      //   //       "selectedRole": "PTABE2E_Administrator"
      //   //     }
      //   //     expect(scope['checkLengthAssingmentRole']).toBeDefined();
      //   //     scope.checkLengthAssingmentRole();
      //   //   });

      it('Should invoke checkDueDate if', function () {
        scope.createAssignment = {
          "dueDateInMs": undefined
        }
        expect(scope['checkDueDate']).toBeDefined();
        scope.checkDueDate();
      });

      it('Should invoke checkDueDate else', function () {
        scope.createAssignment = {
          "dueDateInMs": 1532712182719
        }
        expect(scope['checkDueDate']).toBeDefined();
        scope.checkDueDate();
      });

      it('Should invoke checkCompletionDate if', function () {

        var newDate = new Date('7/29/2015');
        scope.createAssignment = {
          "complitionDateInMs": newDate
        }
        expect(scope['checkCompletionDate']).toBeDefined();
        scope.checkCompletionDate();
      });

      it('Should invoke checkCompletionDate  else if', function () {
        scope.createAssignment = {
          "complitionDateInMs": undefined
        }
        var compDateValue = "";
        expect(scope['checkCompletionDate']).toBeDefined();
        scope.checkCompletionDate();
      });

      it('Should invoke checkCompletionDate  else', function () {
        scope.createAssignment = {
          "complitionDateInMs": 1532712182719
        }
        expect(scope['checkCompletionDate']).toBeDefined();
        scope.checkCompletionDate();
      });

      it('Should invoke checkCaseNumbertx if', function () {
        scope.createAssignment = {
          "caseNumberTx": undefined
        }
        expect(scope['checkCaseNumbertx']).toBeDefined();
        scope.checkCaseNumbertx();
      });

      it('Should invoke checkCaseNumbertx else if', function () {
        scope.createAssignment = {
          "caseNumberTx": 1532712182719
        }
        scope.orignlacasenum = 123458
        expect(scope['checkCaseNumbertx']).toBeDefined();
        scope.checkCaseNumbertx();
      });

      it('Should invoke checkCaseNumbertx else', function () {
        scope.createAssignment = {
          "caseNumberTx": 1532712182719
        }
        expect(scope['checkCaseNumbertx']).toBeDefined();
        scope.checkCaseNumbertx();
      });

      it('Should invoke checkAssignedTotx if', function () {
        scope.currentAssignee = {
          "name": "Not assigned"
        }
        expect(scope['checkAssignedTotx']).toBeDefined();
        scope.checkAssignedTotx();
      });

      it('Should invoke checkAssignedTotx else', function () {
        scope.currentAssignee = {
          "name": "Admin2"
        }
        expect(scope['checkAssignedTotx']).toBeDefined();
        scope.checkAssignedTotx();
      });

      it('Should invoke cancelAssignDialog if', function () {
        scope.currentAssignee = "pgandhi"
        scope.originalcurrentAssignee = "cdanda"
        scope.newTitle = "test"
        scope.createAssignment = {
          "taskTitleTx": "titletest"
        }
        expect(scope['cancelAssignDialog']).toBeDefined();
        scope.cancelAssignDialog();

        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(1);
        var args = ngDialog.open.calls.argsFor(0);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('CancelAssignmentController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.newData();
        args[0].resolve.originalData();
        args[0].resolve.currentAssignee();
        args[0].resolve.originalcurrentAssignee();
      });

      // it('Should invoke cancelAssignDialog else', function () {
        // expect(ngDialog.closeAll).toBeDefined();
        // expect(scope['cancelAssignDialog']).toBeDefined();
        // scope.cancelAssignDialog();
        // expect(ngDialog.closeAll).toHaveBeenCalledWith(false);
      // });

      it('Should invoke closeAssignmentDate ', function () {
        var ngDialogArray = [ngDialog, ngDialog];
        expect(ngDialog.close).toBeDefined();
        expect(scope['closeAssignmentDate']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        scope.closeAssignmentDate();
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog);

        expect(ngDialog.close).toBeDefined();
        expect(scope['closeAssignmentDate']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        scope.closeAssignmentDate();
        expect(ngDialog.close).toHaveBeenCalledWith();

      });

      it('it should call validateBusinnessdateSelected success', function () {

        expect(scope['validateBusinnessdateSelected']).toBeDefined();
        successResponse = {
          "assignees": [{
            "beNo": "5778",
            "name": "Baker, Patrick",
            "activeCases": "6",
            "assigneeStatus": "Active",
            "role": null,
            "description": null
          }, {
            "beNo": "1810",
            "name": "Bartlett, Steven",
            "activeCases": "0",
            "assigneeStatus": "Active",
            "role": null,
            "description": null
          }, {
            "beNo": "26",
            "name": "Brock, Alan",
            "activeCases": "0",
            "assigneeStatus": "InActive",
            "role": null,
            "description": null
          }, {
            "beNo": "5779",
            "name": "Bui, Jacqueline",
            "activeCases": "3",
            "assigneeStatus": "Active",
            "role": null,
            "description": null
          }]

        };

        successResponse.data = {
          assignees: [{
            "beNo": "5768",
            "name": "Baker, Patrick",
            "activeCases": "6",
            "assigneeStatus": "Active",
            "role": null,
            "description": null
          }, {
            "beNo": "5779",
            "name": "Bui, Jacqueline",
            "activeCases": "3",
            "assigneeStatus": "Active",
            "role": null,
            "description": null
          }]
        }
        var item = {
          "beNo": "5768",
          "name": "Baker, Patrick",
          "activeCases": "6",
          "assigneeStatus": "Active",
          "role": null,
          "description": null
        }

        scope.validateBusinnessdateSelected();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$apply;
        // $rootScope.$apply();
        //toaster error
        // HttpFactoryDeferred.resolve(successResponse);
        // scope.$digest();
      });

      it('validateBusinnessdateSelected get Actions failureResponse ', function () {
        var failureResponse = {
          data: {}
        };
        scope.validateBusinnessdateSelected();
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });


      //   it('Should invoke openAssignmentDate ', function () {
      //     expect(ngDialog.open).toBeDefined();
      //     expect(scope['openAssignmentDate']).toBeDefined();
      //     scope.openAssignmentDate();
      //     expect(ngDialog.open).toHaveBeenCalled();

      //   });

      it('should invoke closeAssignment', function () {
        var ngDialogArray = [ngDialog, ngDialog];
        // expect(ngDialog.close).toBeDefined();
        expect(scope['assignmentSaveCloseVal']).toBeDefined();
        // ngDialog.getOpenDialogs.and.returnValue(ngDialogArray, true);
        scope.assignmentSaveCloseVal();
        // expect(ngDialog.close).toHaveBeenCalledWith(ngDialog, true);

        // expect(ngDialog.closeAll).toBeDefined();
        expect(scope['assignmentSaveCloseVal']).toBeDefined();
        // ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        scope.assignmentSaveCloseVal();
        // expect(ngDialog.closeAll).toHaveBeenCalledWith(true);

        expect(scope['closeAssignment']).toBeDefined();
        scope.closeAssignment();
      });


    });


  });
})();
