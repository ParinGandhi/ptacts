(function () {
  "use strict";

  angular
    .module('ptabe2e')
    .controller('bulkClosetoutController', function (ngDialog, CommonHelperService, assignmentRows, HttpFactory, CONSTANTS, $scope, uiGridConstants) {
      var vm = this;
      var scope = angular.element(document.getElementById('mainTabId')).scope();
      vm.userInfo = scope.vm.userInfo;
      vm.assignmentRows = assignmentRows;
      vm.showError = false;
      vm.firstTimeOpen = true;
      vm.disableCloseout = true;

      vm.cancelCloseout = function () {
        ngDialog.close(lastDialog());
      };

      vm.closeoutDateCheck = function () {
        if ((vm.closeoutDueDate === null || vm.closeoutDueDate === "" || vm.closeoutDueDate === "undefined") && !vm.firstTimeOpen) {
          vm.showError = true;
        } else {
          vm.showError = false;
        }
      };

      function lastDialog() {
        var openDialogs = ngDialog.getOpenDialogs();
        return openDialogs[openDialogs.length - 1];
      }

      /* istanbul ignore next*/
      $scope.bulkCloseoutGridOptions = {
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        gridMenuShowHideColumns: false,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.WHEN_NEEDED,
        columnDefs: [{
            displayName: "Case #",
            headerTooltip: 'Case #',
            field: "appealNumber",
            type: "number",
            enableColumnMenu: false
          },
          {
            displayName: "Application #",
            headerTooltip: 'Application #',
            field: "serialNumber",
            type: "string",
            enableColumnMenu: false
          },
          {
            displayName: "Special type",
            headerTooltip: 'Special type',
            field: "specialType",
            type: "string",
            enableColumnMenu: false
          },
          {
            displayName: "Current phase",
            headerTooltip: 'Current phase',
            field: "casePhase",
            type: "string",
            enableColumnMenu: false
          },
          {
            displayName: "Case due date",
            headerTooltip: 'Case due date',
            cellFilter: "date:'MM/dd/yyyy'",
            field: "appealDueDate",
            type: "date",
            enableColumnMenu: false
          }
        ],
        onRegisterApi: function (gridApi) {
          $scope.gridApi = gridApi;
        }
      };

      $scope.bulkCloseoutGridOptions.data = vm.assignmentRows;

      vm.closeoutDateChanged = function () {
        vm.firstTimeOpen = false;
        if (vm.closeoutDueDate === null || vm.closeoutDueDate === undefined || vm.closeoutDueDate === "") {
          vm.showError = true;
        } else {
          vm.epoch = new Date(vm.closeoutDueDate).getTime();
          var list = [];
          vm.assignmentRows.forEach(function (element) {
            var newDate = {
              "appealNumber": element.appealNumber,
              "serialNumber": element.serialNumber,
              "appealType": element.appealType,
              "caseStatus": element.caseStatus,
              "casePhase": element.casePhase,
              "panelInfo": element.panelInfo,
              "specialType": element.specialType,
              "appealDueDate": element.appealDueDate,
              "nextCaseDueDate": vm.epoch,
              "audit": {
                "lastModifiedUserIdentifier": vm.userInfo.userId,
                "createUserIdentifier": vm.userInfo.userId,
                "lastModifiedTimestamp": new Date().getTime()
              }
            };
            list.push(newDate);
          });

          HttpFactory.putActions(CONSTANTS.URL.QUARTERLY_CLOSEOUT_DATE, list)
            .then(function () {
              ngDialog.closeAll("Updated");
              CommonHelperService.setToastr(CONSTANTS.TOASTER.quarterlyCloseoutSuccess, "success", 8000);
            }, function (failureResponse) {
              CommonHelperService.setToastr(CONSTANTS.TOASTER.quarterlyCloseoutError, "error", 8000);
            });
        }
      };

    });
})();
