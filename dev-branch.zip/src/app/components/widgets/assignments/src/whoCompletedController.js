(function () {
  "use strict";
  angular
    .module('ptabe2e')
    .controller('whoCompletedController', function () {
      // intentional
    });
})();
