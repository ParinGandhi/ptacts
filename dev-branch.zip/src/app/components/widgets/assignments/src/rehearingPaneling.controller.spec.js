(function () {
  'use strict';

  describe('RehearingPanelingController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'closeAll']);
    var controller, scope, $rootScope, $CommonHelperService;
    var timeout;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, selectedJudgeSuccessResponse, failureResponse;
    var showPromoteTypesValues;
    var response = {
      value: "notes"
    }


    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory, _CommonHelperService_) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      $CommonHelperService = _CommonHelperService_;
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn($CommonHelperService, 'setToastr').and.callFake(function () {
        return "toastr";
      });

      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback1) {
            callback1(response);
          }
        }
      });


      successResponse = {
        data: {
          decisions: [{
            requestDate: "Request date"
          }],
          judgePanel: [{
            reconsiderSequenceNumber: 1,
            panelToBeCreated: [{
              lastModifiedUserName: "sbartlett"
            }]
          }],
          assignedAttorneyList: [{
            assigneeNumberText: "123",
            assigneeFullNameText: "sbartlett"
          }],
          nonAssignedAttorneyList: [{
            assigneeNumberText: "456",
            assigneeFullNameText: "tlee7"
          }]
        }
      }

      $rootScope.sharedItems = [{
        "serialNumber": "10300247",
        "sequenceNumber": 0,
        "appealNumber": "2019000445",
        "lifeCycle": null,
        "audit": {
          "lastModifiedTimestamp": 1541787963000,
          "lastModifiedUserIdentifier": "gandhi9",
          "createUserIdentifier": "asankineni",
          "createdUserName": "Sankineni, Archana ",
          "lastModifiedUserName": "Gandhi, Parin ",
          "createTimestamp": 1541787963426,
          "lockControlNumber": 0
        },
        "assignmentIdentifier": 1896,
        "assignmentType": "UeWF",
        "assignmentTypeIdentifier": "58",
        "assignee": "5768",
        "assignor": "5767",
        "caseType": "APPEAL",
        "priorityIndicator": "N",
        "activeIndicator": "A",
        "title": "Update eWF - 2019000445",
        "description": "Update the electronic working file (eWF) for this case, including judges' names.",
        "notes": null,
        "assignedDate": 1541787963000,
        "dueDate": 1542085200000,
        "completionDate": null,
        "palmMailedDate": null,
        "standardAssignmentType": {
          "UPDATEEWF": "Update eWF",
          "ASSIGNMENTINFO": "Assignment info"
        },
        "completedUserName": null,
        "lastModifiedUserName": null,
        "noOfActiveCases": 0,
        "assignmentStatusCode": "A",
        "assigneeRoleCode": null,
        "assigneeRoleDescription": null,
        "assignmentSequence": null,
        "reconsiderSequence": null,
        "pendingLocationText": null,
        "assignmentTypeDescription": "Update eWF",
        "completionCode": null,
        "message": null,
        "globalMetaData": {
          "applicationNumber": "10300247",
          "caseNumber": "2019000445",
          "parties": null,
          "panel": [{
              "employeeName": "GERSTENBLITH, BART A",
              "rank": 1
            },
            {
              "employeeName": "MOHANTY, BIBHU ",
              "rank": 2
            },
            {
              "employeeName": "GERSTENBLITH, BART ",
              "rank": 3
            }
          ],
          "briefHearingType": "On brief",
          "caseType": "REGULAR",
          "caseStatus": "Update eWF",
          "caseStatusDate": 1541514377000,
          "applicationStatusDescriptionText": "On Appeal -- Awaiting Decision by the Board of Appeals"
        }
      }];


      controller = $controller('RehearingPanelingController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        showPromoteTypesValues: showPromoteTypesValues,
        HttpFactory: HttpFactory

      });
    }));

    describe('RehearingPanelingController ', function () {

      it('should call getDisciplineList and return successResponse', function () {

        expect(scope.getDisciplineList).toBeDefined();
        scope.getDisciplineList();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();

      });


      it('should call getDisciplineList and return failureResponse', function () {

        expect(scope.getDisciplineList).toBeDefined();
        scope.getDisciplineList();
        HttpFactoryDeferred.reject();
        scope.$digest();

      });

      it('should call getSectionList and return successResponse', function () {

        expect(scope.getSectionList).toBeDefined();
        scope.getSectionList();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();

      });


      it('should call getSectionList and return failureResponse', function () {

        expect(scope.getSectionList).toBeDefined();
        scope.getSectionList();
        HttpFactoryDeferred.reject();
        scope.$digest();

      });


      it('should call getRehearingRequestDate and return successResponse ', function () {

        expect(scope.getRehearingRequestDate).toBeDefined();
        scope.getRehearingRequestDate();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();

      });


      it('should call getDecisionDueDate with rehearingPanelDate as epcoh and returns successResponse', inject(function ($timeout) {

        scope.rehearingPanelDate = 1558109976;

        expect(scope.getDecisionDueDate).toBeDefined();
        scope.getDecisionDueDate();
        $timeout.flush();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();

      }));


      it('should call getDecisionDueDate with rehearingPanelDate as date and returns failureResponse', inject(function ($timeout) {

        scope.rehearingPanelDate = new Date();
        failureResponse = {
          data: {
            message: "Failed!"
          }
        }

        expect(scope.getDecisionDueDate).toBeDefined();
        scope.getDecisionDueDate();
        $timeout.flush();
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();

      }));


      it('should call getJudgeList with initialLoad and return successResponse', function () {

        var successResponse = {
          data: {
            judgesToPanel: [{
                assigneeNumberText: 123
              },
              {
                assigneeNumberText: 456
              }
            ]
          }
        }

        expect(scope.getJudgeList).toBeDefined();
        scope.getJudgeList('initialLoad');
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest;

      });


      it('should call getJudgeList with selectedDiscipline and selectedSection as all and return successResponse', function () {

        var successResponse = {
          data: {
            judgesToPanel: [{
                assigneeNumberText: 123
              },
              {
                assigneeNumberText: 456
              }
            ]
          }
        }
        scope.selectedDiscipline = "all";
        scope.selectedSection = "all";

        expect(scope.getJudgeList).toBeDefined();
        scope.getJudgeList();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest;

      });



      it('should call getJudgeList with selectedDiscipline as all and selectedSection as something and return successResponse', function () {

        var successResponse = {
          data: {
            judgesToPanel: [{
                assigneeNumberText: 123
              },
              {
                assigneeNumberText: 456
              }
            ]
          }
        }
        scope.selectedDiscipline = "all";
        scope.selectedSection = "something";

        expect(scope.getJudgeList).toBeDefined();
        scope.getJudgeList();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest;

      });


      it('should call getJudgeList with selectedDiscipline as something and selectedSection as all and return successResponse', function () {

        var successResponse = {
          data: {
            judgesToPanel: [{
                assigneeNumberText: 123
              },
              {
                assigneeNumberText: 456
              }
            ]
          }
        }
        scope.selectedDiscipline = "something";
        scope.selectedSection = "all";

        expect(scope.getJudgeList).toBeDefined();
        scope.getJudgeList();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest;

      });



      it('should call getJudgeList with selectedDiscipline as something and selectedSection as something and return successResponse', function () {

        var successResponse = {
          data: {
            judgesToPanel: [{
                assigneeNumberText: 123
              },
              {
                assigneeNumberText: 456
              }
            ]
          }
        }
        scope.selectedDiscipline = "something";
        scope.selectedSection = "something";

        expect(scope.getJudgeList).toBeDefined();
        scope.getJudgeList();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest;

      });



      it('should call getJudgeList with selectedDiscipline as something and return successResponse', function () {

        var successResponse = {
          data: {
            judgesToPanel: [{
                assigneeNumberText: 123
              },
              {
                assigneeNumberText: 456
              }
            ]
          }
        }
        scope.selectedDiscipline = "something";

        expect(scope.getJudgeList).toBeDefined();
        scope.getJudgeList();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest;

      });



      it('should call getJudgeList with selectedSection as something and return successResponse', function () {

        var successResponse = {
          data: {
            judgesToPanel: [{
                assigneeNumberText: 123
              },
              {
                assigneeNumberText: 456
              }
            ]
          }
        }
        scope.selectedSection = "something";

        expect(scope.getJudgeList).toBeDefined();
        scope.getJudgeList();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest;

      });



      it('should call getJudgeList with selectedDiscipline as all and selectedSection as "" and return successResponse', function () {

        var successResponse = {
          data: {
            judgesToPanel: [{
                assigneeNumberText: 123
              },
              {
                assigneeNumberText: 456
              }
            ]
          }
        }
        scope.selectedDiscipline = "all";
        scope.selectedSection = "";

        expect(scope.getJudgeList).toBeDefined();
        scope.getJudgeList();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest;

      });



      it('should call getJudgeList with selectedDiscipline as "" and selectedSection as all and return successResponse', function () {

        var successResponse = {
          data: {
            judgesToPanel: [{
                assigneeNumberText: 123
              },
              {
                assigneeNumberText: 456
              }
            ]
          }
        }
        scope.selectedDiscipline = "";
        scope.selectedSection = "all";

        expect(scope.getJudgeList).toBeDefined();
        scope.getJudgeList();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest;

      });



      it('should call getAttorneyList and return successResponse', function () {

        scope.judgesToPanel = [{
          assigneeNumberText: "sbartlett"
        }]

        expect(scope.getAttorneyList).toBeDefined();
        scope.getAttorneyList();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest;

      });



      it('should call getAttorneyList and return failureResponse', function () {

        scope.judgesToPanel = [{
          assigneeNumberText: "sbartlett"
        }]

        failureResponse = {
          data: {
            message: "Failed"
          }
        }

        expect(scope.getAttorneyList).toBeDefined();
        scope.getAttorneyList();
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest;

      });



      it('it should call removeJudgeFromPanel  ', function () {

        scope.judgesToPanel = [{
            "assigneeNumberText": "5922",
            "assigneeFullNameText": "Saindon, William "
          },
          {
            "assigneeNumberText": "468",
            "assigneeFullNameText": "Weatherly, Mitchell "
          },
          {
            "assigneeNumberText": "6003",
            "assigneeFullNameText": "BARRETT, KEN B"
          },
          {
            "assigneeNumberText": "6005",
            "assigneeFullNameText": "WIEDER, BRUCE "
          },
          {
            "assigneeNumberText": "6006",
            "assigneeFullNameText": "CAPP, WILLIAM A"
          }
        ];

        expect(scope['removeJudgeFromPanel']).toBeDefined();
        scope.removeJudgeFromPanel(1);
        scope.$digest();


      });


      it('it should call removeJudgeFromPanel  ', function () {

        scope.judgesToPanel = [{
          "assigneeNumberText": "5922",
          "assigneeFullNameText": "Saindon, William "
        }];

        expect(scope['removeJudgeFromPanel']).toBeDefined();
        scope.removeJudgeFromPanel(0);
        scope.$digest();


      });



      it('it should call removeAllJudgesFromPanel', function () {

        scope.judgesToPanel = [{
            "assigneeNumberText": "5922",
            "assigneeFullNameText": "Saindon, William "
          },
          {
            "assigneeNumberText": "468",
            "assigneeFullNameText": "Weatherly, Mitchell "
          },
          {
            "assigneeNumberText": "6003",
            "assigneeFullNameText": "BARRETT, KEN B"
          },
          {
            "assigneeNumberText": "6005",
            "assigneeFullNameText": "WIEDER, BRUCE "
          },
          {
            "assigneeNumberText": "6006",
            "assigneeFullNameText": "CAPP, WILLIAM A"
          }
        ];


        expect(scope['removeAllJudgesFromPanel']).toBeDefined();
        scope.removeAllJudgesFromPanel();

      });



      it('it should call moveJudgeToPanel with more than 3 judges ', function () {

        scope.judgeList = [{
            "assigneeNumberText": "5922",
            "assigneeFullNameText": "Saindon, William "
          },
          {
            "assigneeNumberText": "468",
            "assigneeFullNameText": "Weatherly, Mitchell "
          },
          {
            "assigneeNumberText": "6003",
            "assigneeFullNameText": "BARRETT, KEN B"
          },
          {
            "assigneeNumberText": "6005",
            "assigneeFullNameText": "WIEDER, BRUCE "
          },
          {
            "assigneeNumberText": "6006",
            "assigneeFullNameText": "CAPP, WILLIAM A"
          }
        ];

        scope.judgeIndex = ["4"];

        expect(scope['moveJudgeToPanel']).toBeDefined();
        scope.moveJudgeToPanel();

      });


      it('it should call moveJudgeToPanel with less than 3 judges ', function () {

        scope.judgesToPanel = [{
          "assigneeNumberText": "6054",
          "assigneeFullNameText": "Dougal, Brent M..",
          "workerNumber": "93078",
          "rankId": 4,
          "$$hashKey": "object:5140"
        }]

        scope.judgeList = [{
          "assigneeNumberText": "5922",
          "assigneeFullNameText": "Saindon, William "
        }];

        scope.judgeIndex = ["0"];

        expect(scope['moveJudgeToPanel']).toBeDefined();
        scope.moveJudgeToPanel();

      });


      it('it should call dataSelected  ', function () {

        expect(scope.dataSelected).toBeDefined();
        scope.dataSelected(1);

      });


      it('it should call copyPA ', function () {
        var patentAttorney = "Admin";
        expect(scope['copyPA']).toBeDefined();
        scope.copyPA(patentAttorney);
      });


      it('it should call viewNotes ', function () {
        var row = {
          entity: {
            type: "Reconsideration"
          }
        }
        expect(scope.viewNotes).toBeDefined();
        scope.viewNotes();


        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(1);
        var args = ngDialog.open.calls.argsFor(0);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        // expect(args[0].controller).toBe('RehearingPanelingController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.savedPanelNote();
        args[0].resolve.numbers();

      });



    });
  });

})();
