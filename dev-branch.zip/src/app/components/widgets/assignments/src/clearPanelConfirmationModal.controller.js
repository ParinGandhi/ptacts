(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('ClearPanelModalController', function (ngDialog) {
      var vm = this;

      vm.confirmClearPanel = function (clearPanel) {
        ngDialog.closeAll(clearPanel);
      };

      vm.cancelClearPanelModal = function () {
        ngDialog.close(lastDialog());
      };

      function lastDialog() {
        var openDialogs = ngDialog.getOpenDialogs();
        return openDialogs[openDialogs.length - 1];
      }

    });
})();
