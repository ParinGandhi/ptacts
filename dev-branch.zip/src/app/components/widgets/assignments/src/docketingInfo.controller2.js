(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .directive('fileModel', ['$parse', function ($parse) {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var model = $parse(attrs.fileModel);
          var modelSetter = model.assign;

          element.bind('change', function () {
            scope.$apply(function () {
              modelSetter(scope, element[0].files[0]);
            });
          });
        }
      };
    }])

    .directive('customOnChange', function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var onChangeFunc = scope.$eval(attrs.customOnChange);
          element.bind('change', onChangeFunc);
        }
      };
    })
    .controller('docketinInfoController2', function ($timeout, $scope, ngDialog, HttpFactory, $log, CONSTANTS, $http, toastr, $sce, $rootScope, $filter, CommonHelperService) {
      var vm = this;
      vm.fileAdded1 = false;
      $scope.spinnerShow =false;
      $scope.fileExtractContent = [];
      var scope = angular.element(document.getElementById('mainTabId')).scope();
      vm.userInfo = scope.vm.userInfo;
      if (vm.userInfo.appUserInfo[0]) {
        vm.fullName = vm.userInfo.appUserInfo[0].fullName;
      } else {
        vm.fullName = vm.userInfo.appUserInfo.fullName;
      }

      $scope.currentAssignee = {
        assigneeNumberText: vm.userInfo.assigneeNumber,
        assigneeFullNameText: vm.userInfo.displayName
      };
      $scope.listOfFileNames = [];
      $scope.fileContent = [];
      $scope.multiPdf = [];
      $scope.anotherFile = false;
      $scope.anotherFile1 = false;
      $scope.docketFileContent = [];
      $scope.show = true;
      $scope.editable = true;
      $scope.showPreview = true;
      $scope.fileUploadDisable = true;
      $scope.hideAdd = true;
      $scope.shareAssign = $rootScope.sharedItems;
      $scope.shareAssign[0].assignmentType="MDN";
      $scope.caseNum = $rootScope.sharedItems[0].serialNumber;
      $scope.appealNumber = $rootScope.sharedItems[0].appealNumber;
      $scope.assignmentTypeForRtf = $rootScope.sharedItems[0].assignmentType;
      $scope.rtfBaseLink = CONSTANTS.URL.BASE;
      $scope.transactionDate = new Date().getTime();
      $scope.enterDays = '';
      vm.hearingStatusIndicator = '';
      $scope.showHearingStatus = false;
      $scope.showUploadButton = false;
      $scope.readyToCreateRemand = false;
      $scope.showFastTrack = false;
      $scope.decisionDocument = "Use system converted PDF";
      $scope.showVerifyDecision = true;
      $scope.anotherFile = false;
      $scope.anotherFile1 = false;
      $scope.revalidate =false;
      $scope.footerEditValue =false;
      $scope.hidePalm =true;
      $scope.dockType=null;
      // $scope.editedInformation = true;
      var clFile;
      var reader = new FileReader();
      var fileByteArray = [];
      /* istanbul ignore next */
    $scope.getFileInfo = function () {
      $scope.pdfNameForDoc =null;
      clFile = document.getElementById("fileVerifyDecision");
      $scope.fileInfo = {};
      $scope.fileInfo.name = clFile.files[0].name;
      $scope.fileExtractContent.push(clFile.files[0]);
      $scope.verifiedDocument = {};
      $scope.verifiedDocument.fileName  = $scope.fileInfo.name;
      $scope.docLink =  $scope.verifiedDocument.fileName;
      $scope.fileInfo.path = clFile.value;
      reader.readAsArrayBuffer(clFile.files[0]);
      reader.onloadend = function (evt) {
        if (evt.target.readyState === FileReader.DONE) {
          var arrayBuffer = evt.target.result,
            array = new Uint8Array(arrayBuffer);
          for (var i = 0; i < array.length; i++) {
            fileByteArray.push(array[i]);
          }
        }
      };
    };
 
    $scope.clearDocument = function() {
      $scope.verifiedDocument = null;
      $scope.extracted=false;
      $scope.fileExtractContent = [];
      $scope.revalidate =false;
      $scope.editedInformation = false;
    };
    $scope.saveDecSummary = function(responseObject){
      HttpFactory.postActions(CONSTANTS.URL.SAVE_DEC_SUMMARY, responseObject
        )
        .then(function (successResponse) {
         console.log (successResponse);
         $timeout(function () {
          document.getElementById('moveToMD').click();
       }, 200);
        }, function () {
          $timeout(function () {
            document.getElementById('moveToMD').click();
         }, 200);
          // intentional
        });
    }
    $scope.continueToMailDec = function() {
      $scope.showVerifyDecision = false;
var rejectionss = [];
      for (var i = 0; i <  $scope.rejections.length; i++) {
        rejectionss.push($scope.rejections[i]);
      }
      if($scope.outcome != null) {
      rejectionss.push($scope.outcome);
      }
      var responseObject =  {
        "proceedingCoreId": $scope.caseNum,
        "proceedingSupplementaryId": $scope.appealNumber,
        "proceedingType": "Appeal",
        "descriptionTx": null,
        "extractedContent": {
          "decisionBelongsTo": $scope.decisionBelongsTo,
         "referenceNotes": $scope.referenceNotes,
         "decisionSummary": $scope.decisionSummary,
         "groundsTable": rejectionss,
         "totalGrounds":$scope.totalGround,
         "validationrules": $scope.validationRules,
        },
        "audit": {
          "createUserIdentifier":vm.userInfo.displayName,
          "lastModifiedUserIdentifier": vm.userInfo.userId,
          "lastModifiedTimestamp": new Date().getTime(),
          "createdUserName":  vm.userInfo.userId,
          "lastModifiedUserName": vm.userInfo.displayName,
          "createTimestamp":  new Date().getTime(),
          "lockControlNumber": $scope.shareAssign[0].audit.lockControlNumber
        }
      };

      if($scope.docHasError){
console.log("error");
ngDialog.openConfirm({ 
  template: "app/components/widgets/assignments/src/errorWithDoc.html",
  scope: $scope,
  width: '30%',
  showClose: false,
  closeByEscape: false,
  closeByDocument: false
    })
  .then(function () {
    $scope.saveDecSummary(responseObject);
  }, function () {
    $scope.rejectionEdit = false;
    $scope.revalidate =true;
    $scope.editedInformation = true;
  });
      }
    else  if ($scope.exception) {
  ngDialog.openConfirm({ 
    template: "app/components/widgets/assignments/src/exceptionErrorModal.html",
    scope: $scope,
    width: '30%',
    showClose: false,
    closeByEscape: false,
    closeByDocument: false
      })
    .then(function () {
      $scope.saveDecSummary(responseObject);
      // console.log("Yes");
      // $scope.rejectionEdit = false; 
      // $scope.revalidate =false;
    }, function () {
      $scope.rejectionEdit = false;
      $scope.revalidate =true;
      $scope.editedInformation = true;
    });
}
   else{
    $scope.saveDecSummary(responseObject);
    $scope.rejectionEdit = false; 
    $scope.revalidate =false;
   } 

      // $scope.saveDecSummary(responseObject);
    //   HttpFactory.postActions(CONSTANTS.URL.SAVE_DEC_SUMMARY, responseObject
    // )
    // .then(function (successResponse) {
    //  console.log (successResponse);
    // }, function () {
    //   // intentional
    // });
    };

    $scope.useConvertedPdf = function(){
      $scope.anotherFile= false;
      $scope.anotherFile1 = false;
      $scope.decisionDocument = "Use system converted PDF";
      $scope.clearFile();
      $scope.anotherFile = false;
      $scope.fileExtractContent = $scope.originalSelectedFile;
      $scope.convertDocToPdf();
    };

    $scope.useanotherpdf = function(){
      $scope.anotherFile1 = true;
      $scope.anotherFile = true;
      $scope.decisionDocument = "Choose another file";
    };

    /* istanbul ignore next */
$scope.convertDocToPdf= function(){
  var pdfDataFileForDoc = new FormData();
  angular.forEach($scope.fileExtractContent, function (value) {
    pdfDataFileForDoc.append('uploadMultipartFileContents', value);
  });
  var url= CONSTANTS.URL.DOC_TO_PDF + $scope.appealNumber + CONSTANTS.URL.DOC_PDF_ASSIGN_ID + $scope.shareAssign[0].assignmentIdentifier;
  HttpFactory.postPdf( url, pdfDataFileForDoc)
  .then(function (successResponse) {
    $scope.PostDataResponseForDoc = successResponse.data.fileContent;
    $scope.genPdfFileNameForDoc = successResponse.data.fileName;
    $scope.wordDocFileName = successResponse.data.wordDocFileName;
    $scope.contentsPreviewForDoc= 'data:application/pdf;base64,' + $scope.PostDataResponseForDoc;
    $scope.getPreview($scope.contentsPreviewForDoc);
  }, function (failureResponse) {
    $log.info(failureResponse.data.message);
  });
}; 

    $scope.extractSelectedDocument = function() {
      $scope.convertDocToPdf();
      $scope.extracted=true;
      // var ruleList = [];
      var indexPeriod = $scope.verifiedDocument.fileName.indexOf(".");
      $scope.updatedPdf = $scope.verifiedDocument.fileName.substring(0, indexPeriod) + ".pdf";
      var pdfDataFile = new FormData();
      angular.forEach($scope.fileExtractContent, function (value) {
        pdfDataFile.append('uploadMultipartFileContents', value);
      });
    HttpFactory.postPdf( CONSTANTS.URL.MAIL_DOC, pdfDataFile)
      .then(function (successResponse) { 
        getExceptionsAndData(successResponse.data);
        $scope.docHasError =false;
      }, function (failureResponse) {
        $scope.docHasError =true;
        $scope.exception =false;
        $scope.rejections = [];
        $scope.exceptionsLength = 0;
        $scope.showConvertedPdfName = $scope.updatedPdf;
        toastr.error(failureResponse.data.message, {
          iconClass: 'toast-danger'
        });
      });
    };

    $scope.editRejectionClaim = function(rejection) {
      if ($scope.rejectionEdit) {
        return;
      }
      rejection.editMode = true;
      $scope.rejectionEdit = angular.copy(rejection);
      angular.forEach(rejection.claimInformation, function(row) {
        if (row.referenceType ==='AFFIRMED') {
        $scope.rejectionEdit.affirmed = row.asCaptured; }
         else if(row.referenceType ==='REVERSED'){
          $scope.rejectionEdit.reversed = row.asCaptured;
         } else if(row.referenceType ==='REJECTED'||row.referenceType == 'PETITIONED'){
          $scope.rejectionEdit.rejected = row.asCaptured;
         }
        }
      );       
    };

   function getExceptionsAndData(successResponse){
    var ruleList = [];
    $scope.PostDataResponse = successResponse;
    $scope.rejections = [];
    var rejection = $scope.PostDataResponse;
    $scope.decisionBelongsTo = rejection.decisionBelongsTo;
    $scope.referenceNotes = rejection.referenceNotes;
    $scope.decisionSummary = rejection.decisionSummary;
    $scope.totalGround = rejection.totalGrounds;
for (var i = 0; i < rejection.groundsTable.length; i++) {
$scope.rejections.push(rejection.groundsTable[i]);
if(rejection.groundsTable[i].appliedRules != null && rejection.groundsTable[i].appliedRules.length >0 ){ //&& (i < rejection.groundsTable.length-1 || rejection.groundsTable.length == 1)
var exceptionRuleApplied = rejection.groundsTable[i].appliedRules;
ruleList.push(exceptionRuleApplied);
}
}
$scope.validationRules = successResponse.validationrules;
angular.forEach($scope.validationRules, function(rule){
  if(rule.identifier == 'cciv:2'){
    $scope.cciv2ErrorDescription = rule.description;
  }
  // console.log( $scope.cciv2ErrorDescription);
   })
$scope.exceptionsLength = ruleList.length;
if($scope.exceptionsLength >0) {
$scope.displayedException = [];
$scope.columnErrorsdisplayedException = [];
angular.forEach(ruleList,function(rule){
angular.forEach(rule,function(arule){
var identifiers = arule.refIdentifier.split(",");
for (var i=0;i<identifiers.length;i++) {
  var uniqueException = CommonHelperService.checkUnique($scope.displayedException,identifiers[i]);
  if (!uniqueException){
    $scope.displayedException.push(CommonHelperService.getValidationRule($scope.validationRules,identifiers[i]));
  }
}
if (arule.columnErrors != null) {
  for (var i=0;i<arule.columnErrors.length;i++) {
        var columnErrors = arule.columnErrors[i];
          var columnErrorsuniqueException = CommonHelperService.checkUniqueError($scope.columnErrorsdisplayedException,columnErrors);
          if (!columnErrorsuniqueException){
            $scope.columnErrorsdisplayedException.push(columnErrors);
          }
      }}
});
});
$scope.exception = true;
 } else {
   $scope.exception =false;
 }
$scope.allFields = angular.copy($scope.rejections);
var lastOne =   $scope.rejections.length;
var size = lastOne-1 ;
if (size >0) {
$scope.outcome =  $scope.allFields.pop();
$scope.outcome.editode = false;
$scope.rejections =   $scope.allFields;
}else{
$scope.outcome = null;
}
   }
    $scope.revalidateTable = function(){
      var rejectionss = [];
      for (var i = 0; i <  $scope.rejections.length; i++) {
        rejectionss.push($scope.rejections[i]);
      }
      if($scope.outcome != null)
      { rejectionss.push($scope.outcome);
      }
      var responseObject =  {
          "decisionBelongsTo": $scope.decisionBelongsTo,
          "decisionSummary": $scope.decisionSummary,
          "groundsTable": rejectionss,
         "referenceNotes": $scope.referenceNotes,
         "totalGrounds":$scope.totalGround,
         "validationrules": $scope.validationRules
      };
      HttpFactory.putActions(CONSTANTS.URL.DECISION_SUMMARY_REVALIDATE, responseObject)
      .then(function (successResponse) {
        getExceptionsAndData(successResponse.data);
      }, function () {
        // intentional
      });
$scope.rejectionEdit = false; 
$scope.revalidate =false;
$scope.footerEditValue =false;
$scope.editedInformation =false;   
    }

    $scope.saveRejectionClaim = function(rejection) {
      $scope.editedInformation = true;
      $scope.revalidate = true;
      rejection.editMode = false;
     // rejection.statute = $scope.rejectionEdit.statute;
      rejection.statuteAsCaptured = $scope.rejectionEdit.statuteAsCaptured;
      rejection.referencesBasis = $scope.rejectionEdit.referencesBasis;
     angular.forEach(rejection.claimInformation, function(row) {
      if (row.referenceType ==='AFFIRMED') {
        angular.forEach($scope.rejectionEdit.claimInformation, function(row1) {
          if (row1.referenceType ==='AFFIRMED') {
        row.asCaptured =   $scope.rejectionEdit.affirmed ; }
          }
        );  
      }
       });
       angular.forEach(rejection.claimInformation, function(row) {
        if (row.referenceType ==='REVERSED') {
          angular.forEach($scope.rejectionEdit.claimInformation, function(row1) {
            if (row1.referenceType ==='REVERSED') {
              row.asCaptured=  $scope.rejectionEdit.reversed ; }
            }
          ); 
         }
        });
        angular.forEach(rejection.claimInformation, function(row) {
          if (row.referenceType ==='REJECTED'||row.referenceType == 'PETITIONED') {
            angular.forEach($scope.rejectionEdit.claimInformation, function(row1) {
              if (row1.referenceType ==='REJECTED' ||row.referenceType == 'PETITIONED') {
                row.asCaptured=  $scope.rejectionEdit.rejected ; }
              }
            ); 
           }
          });
      rejection.groundAsCaptured = $scope.rejectionEdit.groundAsCaptured;
      $scope.rejectionEdit=null;
    };

    $scope.saveFooter = function(footer) {
      $scope.footerEditValue =false;
      $scope.editedInformation = true;
      footer.editMode = false;
      $scope.revalidate = true;
// console.log($scope.footerEdit);
footer.groundAsCaptured = $scope.footerEdit.groundAsCaptured;
        footer.statuteAsCaptured = $scope.footerEdit.statuteAsCaptured;
      angular.forEach(footer.claimInformation, function(row) {
       if (row.referenceType ==='AFFIRMED') {
         angular.forEach($scope.footerEdit.claimInformation, function(row1) {
           if (row1.referenceType ==='AFFIRMED') {
         row.asCaptured =   $scope.footerEdit.affirmed ; }
           }
         );  
       }
        });
       angular.forEach(footer.claimInformation, function(row) {
         if (row.referenceType ==='REJECTED') {
           angular.forEach($scope.footerEdit.claimInformation, function(row1) {
             if (row1.referenceType ==='REJECTED') {
               row.asCaptured=  $scope.footerEdit.rejected ; }
             }
           ); 
          }
         });
         angular.forEach(footer.claimInformation, function(row) {
           if (row.referenceType ==='REVERSED') {
             angular.forEach($scope.footerEdit.claimInformation, function(row1) {
               if (row1.referenceType ==='REVERSED') {
                 row.asCaptured=  $scope.footerEdit.reversed ; }
               }
             ); 
            }
           });
           
      $scope.footerEdit=null;
   }

    $scope.editFooter = function(footer) {
      $scope.footerEditValue =true;
      if ($scope.footerEdit) {
        return;
      }
      footer.editMode = true;
     $scope.outcome.editode = true;
      $scope.footerEdit = angular.copy(footer);
      if ( footer.claimInformation.length == 0 ){
       console.log( $scope.footerEdit.statuteAsCaptured);

      }else if (footer.claimInformation.length > 0 ){
       angular.forEach(footer.claimInformation, function(row) {
         if (row.referenceType ==='AFFIRMED') {
         $scope.footerEdit.affirmed = row.asCaptured; }
          else if(row.referenceType ==='REVERSED'){
           $scope.footerEdit.reversed = row.asCaptured;
          }  else if(row.referenceType ==='REJECTED' ||row.referenceType == 'PETITIONED'){
           $scope.footerEdit.rejected = row.asCaptured;
          } 
        }
       ); 
     }
 };
    
    $scope.cancelFooter = function(footer) {
      footer.editMode = false;
      $scope.footerEdit = null;
      if( $scope.editedInformation)
      {    $scope.revalidate = true; //    $scope.saveEnabled = false;
      } else {
        $scope.revalidate = false;
        $scope.footerEditValue =false;
        // $scope.rejectionEdit =false; //$scope.saveEnabled = true;
      }
      // $scope.revalidate = false;
      // $scope.footerEditValue =false;
    };

    $scope.cancelRejectionClaim = function(rejection) {
	rejection.editMode=false;
  $scope.rejectionEdit=null;
  if( $scope.editedInformation)
  {       $scope.revalidate = true;
    //$scope.saveEnabled = false;
  } else {
  $scope.revalidate = false; // $scope.saveEnabled = true;
  }
  // $scope.revalidate = false;
    };

    $scope.editTheFootnote = function(refNotes) {
      $scope.editedFootnote = angular.copy(refNotes);
      refNotes.editMode=true;
      $scope.footNoteEditMode=true; 
    };

    $scope.cancelFootnote = function(refNotes) {
      refNotes.editMode=false;
      $scope.footNoteEditMode=false;
    };

    $scope.saveFootnote = function(refNotes) {
      refNotes.identifier = $scope.editedFootnote.identifier;
      refNotes.referenceText = $scope.editedFootnote.referenceText;
      refNotes.editMode=false;
      $scope.footNoteEditMode=false;
      $scope.saveEnabled=true;
      orderFootnotes();
      checkFootnotes();
    }

    function orderFootnotes() {
      angular.forEach($scope.referenceNotes, function(footNote) {
        try {
          footeNote.identifierValue = parseInt(footNote.identifier);
        } catch(error) {
          // intentionally left blank
        }
        
      });
    }

    $scope.cancelFooter = function(footer) {
      footer.editMode = false;
      $scope.footerEdit = null;
      vm.revalidate =false;
      if(vm.editedInformation)
      {      $scope.saveEnabled = false;
      } else if(!vm.editedInformation && $scope.oldDataExtracted){
        $scope.saveEnabled = false;
       }else {
       $scope.saveEnabled = true;
      }
    };

      /*Get Apj dropdown*/
  $scope.getApj1 = function () {
        HttpFactory.getActions(CONSTANTS.URL.APJ1)
          .then(function (successResponse) {

            $scope.apjoneList = successResponse.data;
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };
      /*Get Apj dorpdown*/
      $scope.getApjPanel = function () {
        HttpFactory.getActions(CONSTANTS.URL.APJPANEL)
          .then(function (successResponse) {

            $scope.apjPanelList = successResponse.data;
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };

      /**set selection value for apj panel */

      $scope.selectedDecision = {};
      $scope.selectedDecisionApj = {};
      $scope.selectedDecisionPA = {};
      /* istanbul ignore next*/
      $scope.setSelected = function (value, description) {
        $scope.selectedDecision.value = value;
        $scope.selectedDecision.description = description;
        if ($scope.selectedDecision.value === 'PERCURIAM' || $scope.selectedDecision.value === 'per curiam' || $scope.selectedDecision.value === 'Per Curiam') {
          $scope.selectedDecisionApj.description = $scope.selectedDecision.description;
          $scope.selectedDecisionPA.description = $scope.selectedDecision.description;
          $scope.judgesToPanel.rulingCategory;
          angular.forEach($scope.judgesToPanel, function (judgeList) {
            judgeList.rulingCategory = value;
            $scope.selectedDecisionApj.description = "Per Curiam";
          });
        }
      };

      /* istanbul ignore next*/
      $scope.setSelectedApj = function (value, description, id) {
        $scope.judgesToPanel[id + 1].rulingCategory = value;
        $scope.selectedDecisionApj.description = $scope.judgesToPanel[id + 1].rulingCategory.descriptionText;
        $scope.selectedDecisionApj.value = $scope.judgesToPanel[id + 1].rulingCategory.valueText;
        if (value === 'PERCURIAM' || value === 'per curiam' || value === 'Per Curiam') {
          $scope.selectedDecisionPA.description = value;
          $scope.selectedDecision.value = value;
          $scope.selectedDecision.description = description;
          $scope.judgesToPanel.rulingCategory;
          angular.forEach($scope.judgesToPanel, function (judgeList) {
            judgeList.rulingCategory = value;
            $scope.selectedDecisionApj.description = "Per Curiam";
          });
        }

      };

      /* istanbul ignore next*/
      $scope.setSelectedPA = function (value, description) {
        $scope.selectedDecisionPA.value = value;
        $scope.selectedDecisionPA.description = description;
        if (value === 'PERCURIAM' || value === 'per curiam' || value === 'Per Curiam') {
          $scope.selectedDecision.value = value;
          $scope.selectedDecision.description = description;
          $scope.judgesToPanel.rulingCategory;
          angular.forEach($scope.judgesToPanel, function (judgeList) {
            judgeList.rulingCategory = value;
            $scope.selectedDecisionApj.description = "Per Curiam";
          });
        }
        $scope.judgesToPanel[$scope.judgesToPanel.length - 1].rulingCategory = value;

      };
      /* istanbul ignore next */
      $scope.getDocketInfo = function (appNum, appealNumber) {
        angular.forEach($scope.shareAssign[0].standardAssignmentType, function (eachType) {
          if (eachType === 'Docketing notice') {

            HttpFactory.getActions(CONSTANTS.URL.APPEAL_METADATA + "?caseNumber=" + appNum + "&appealNumber=" + appealNumber)
              .then(function (successResponse) {
                $scope.docketInfo = successResponse.data;
                $scope.appellant = successResponse.data.appeal.appellants;
                $scope.address = successResponse.data.address.physicalAddress[0];
                $scope.receiptDate = successResponse.data.appeal.receivedDate;
              }, function (failureResponse) {
                $log.info(failureResponse);
              });
          }
        });
      };

      $scope.getDocketInfo($scope.shareAssign[0].serialNumber, $scope.shareAssign[0].appealNumber);
      /* istanbul ignore next */
      $scope.assignedrole = function () {


        return HttpFactory.getActions('/user-management/users?employeeNumberText=' + $scope.updateAssignment.assignee)
          .then(function (successResponse) {

              $scope.roleforassignmnt = successResponse.data[0].userRoles[0].roleCode;
              $scope.Assignedtoforassignmnt = successResponse.data[0].assigneeFullNameText;
              $scope.content.assigneeFullNameText = $scope.Assignedtoforassignmnt;
              $scope.myusrRole = $scope.roleforassignmnt;
              if ($scope.roleforassignmnt) {
                $scope.showAssignmrentMsgRole = false;
              }
            },
            function () {
              toastr.clear();
              toastr.error(CONSTANTS.TOASTER.role, {
                iconClass: 'toast-danger'
              });
            });
      };

      $scope.getRole = function () {
        HttpFactory.getActions(CONSTANTS.URL.ROLETYPE)
          .then(function (successResponse) {
              $scope.myRole = successResponse.data;
            },
            function (failureResponse) {
              $log.info(failureResponse);
            });
      };

      $scope.getRole();

      $scope.docReviewComplt = function () {
        ngDialog.open({
          template: 'app/components/widgets/assignments/src/confirmDocReview.html',
          controller: 'confirmDocReviewController',
          width: '25%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            shareAssign: function () {
              return $scope.shareAssign[0];
            }
          }
        }).closePromise.then(function () {
          // intentional
        });

      };

      /* istanbul ignore next*/
      $scope.openApplentDialog = function () {


        $scope.partiesShow = "Appellants";
        $scope.caseDetailsData = {
          "applicationNumber": $scope.shareAssign[0].serialNumber,
          "appealNumber": $scope.shareAssign[0].appealNumber
        };
        ngDialog.open({
          template: "app/components/helperComponents/appellantsPartiesAndRealParties/appellantsPartiesAndRealParties.html",
          controller: 'AppellantsPartiesController',
          scope: $scope,
          width: '60%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,

          resolve: {
            partiesData: function () {
              return $scope.caseDetailsData;
            },
            partiesFlag: function () {
              return $scope.partiesShow;
            },

          }
        }).closePromise.then(function () {
          $scope.getDocketInfo($scope.shareAssign[0].serialNumber, $scope.shareAssign[0].appealNumber);

        }, function () {
          // intentional
        });
      };
      /* istanbul ignore next */
      $scope.myUserRole = function (selectedUser, changedRole) {
        $scope.assignedrole().then(function () {
          if (angular.isUndefined(changedRole)) {
            $scope.docketUserRole = $scope.roleforassignmnt;
          } else {
            $scope.docketUserRole = changedRole;
          }
          $scope.getAssignedTo = function () {


            HttpFactory.getActions(CONSTANTS.URL.ASSIGNEDTO + "roleCode=" + $scope.docketUserRole)
              .then(function (successResponse) {
                  $scope.myAssigne = successResponse.data;
                  $scope.currentSelectedRole = $scope.docketUserRole;
                  $scope.foundAssigne = false;
                  angular.forEach($scope.myAssigne, function (item) {
                    if (item.assigneeNumberText === selectedUser) {
                      $scope.foundAssigne = true;
                      $scope.currentAssignee = {
                        assigneeFullNameText: item.assigneeFullNameText,
                        activeCaseCount: item.activeCaseCount,
                        assigneeStatus: item.assigneeStatus,
                        assigneeNumberText: selectedUser
                      };
                    }
                  });
                  $scope.scrollDisable = false;
                  if (!$scope.foundAssigne) {
                    $scope.currentAssignee = {
                      assigneeFullNameText: 'Not assigned',
                      activeCaseCount: '',
                      assigneeStatus: '',
                      assigneeNumberText: ""
                    };
                  }
                  $scope.originalcurrentAssignee = angular.copy($scope.currentAssignee);
                  $scope.change($scope.currentAssignee);
                },
                function (failureResponse) {
                  $scope.currentAssignee = {
                    assigneeFullNameText: 'Not assigned',
                    activeCaseCount: '',
                    assigneeStatus: '',
                    assigneeNumberText: ""
                  };
                  $scope.myAssigne = {};
                  $scope.scrollDisable = true;
                  $scope.originalcurrentAssignee = angular.copy($scope.currentAssignee);
                  $log.info(failureResponse);
                });
          };
          angular.forEach(Object.keys($scope.lables), function (eachLable) {
            if (eachLable === 'DOCKETINGINFO') {
              $scope.getAssignedTo();
            }
          });
        });
      };
      /* istanbul ignore next */
      $scope.change = function (content) {
        if (content.assigneeStatus === "InActive") {
          $scope.disableInactiveAssignee = true;
        } else {
          $scope.disableInactiveAssignee = false;
        }
        $scope.currentAssignee.assigneeFullNameText = content.assigneeFullNameText;
        $scope.currentAssignee.activeCaseCount = content.activeCaseCount;
        $scope.currentAssignee.assigneeStatus = content.assigneeStatus;
        $scope.currentAssignee.assigneeNumberText = content.assigneeNumberText;
        $scope.checksave();
      };
      /* istanbul ignore next */
      $scope.palmUpload = function () {
        if ($scope.shareAssign[0].assignmentType === "MDN" || $scope.shareAssign[0].assignmentType === "SNH"){
       var userDisp= document.getElementById("userNoticeFlag").style.display;
        var userNot = document.getElementById("userGeneratedMark");
        if (userNot && userNot.innerHTML==='user-generated)' && userDisp !== "none") {
          $scope.dockType="USER";
        }
        }
        $scope.shareAssign.newAssigneeNum = $scope.currentAssignee.assigneeNumberText;
        if ($scope.shareAssign[0].assignmentType === 'PDAP' || $scope.shareAssign[0].assignmentType === 'PARAP') {
          $scope.shareAssign.panelingDate = $scope.panelingDate;
          if ($scope.destjudgeList.length > 0) {
            $scope.shareAssign.adminIdentifier = $scope.destjudgeList[0].assigneeNumberText;
          } else {
            $scope.shareAssign.adminIdentifier = $scope.destjudgePanelList[0].assigneeNumberText;

          }
        }
if ($scope.shareAssign[0].assignmentType ==="MD" && $scope.decisionDocument === "Use system converted PDF"){ 
  $scope.genPdfFileName = $scope.showConvertedPdfName;
  $scope.contentsPreview = $scope.fileContentForConvertedPdf;
  $scope.getPreview($scope.contentsPreview);
  $scope.dockType = "SYSTEM";
} else if($scope.decisionDocument === "Choose another file"){
  $scope.dockType = "USER";
  $scope.getPreview($scope.contentsPreview);
}
        ngDialog.open({
          template: 'app/components/widgets/assignments/src/confirmPdfUpload.html',
          controller: 'pdfUploadController',
          width: '35%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          ariaLabelledById: 'pdfUploadTitle',
          ariaDescribedById: 'pdfUploadTitle',
          resolve: {
            pdfContent: function () {
              return $scope.contentsPreview;
            },
            docketInfo: function () {
              return $scope.shareAssign;
            },
            mailer: function () {
              return $scope.currentAssignee.assigneeFullNameText;
            },
            genPdfFile: function () {
              return $scope.genPdfFileName;
            },
            panelData: function () {
              return $scope.panell;
            },
            decisionType: function () {
              return $scope.selectedDecisionValue;
            },
            decisionDueDate: function () {
              return $scope.responseDueDate;
            },
            decisionDate: function () {
              return $scope.transactionDate;
            },
            judgeList: function () {
              return $scope.judgesToPanel;
            },
            hearingRoomRosterData: function () {
              return $scope.hearingRoomRosterData;
            },
            reconsiderSequenceNumber: function () {
              return $scope.rsNum;
            },
            adSequenceNumber: function () {
              return $scope.adsNum;
            },
            dockType: function(){
              return $scope.dockType;
            },
            appealDecisionData: function(){
              return null;
            }
          }
        }).closePromise.then(function (pdfData) {
          $scope.currentAssignment = pdfData.value.currentAssignment;
          $scope.$parent.$parent.refreshGrid = true;
          $scope.disableUpload = false;
              $scope.showPreview = false;
              $scope.disableSaveButton = false;
              toastr.success(CONSTANTS.TOASTER.docketNotice, {
                iconClass: 'toast-success'
              });
              toastr.success(CONSTANTS.TOASTER.IfwUpload, {
                iconClass: 'toast-success'
              });

              if ($rootScope.isMergedCase) {
                toastr.success($scope.shareAssign[0].title + " assignments for " + $rootScope.mergedApplListForToastr + " have been closed.", {
                  iconClass: 'toast-success'
                });
              }

              $scope.fileToEmail = pdfData.value.fileName;
              if (pdfData.value.deliveryMode === 'Electronic' || pdfData.value.deliveryMode === 'EMAIL') {
                $scope.showButtons = false;
                $scope.gotoChecklist( $scope.currentAssignment);
                toastr.success(CONSTANTS.TOASTER.docketingNoticeClose, {
                  iconClass: 'toast-success'
                });
              } else {
                $scope.showButtons = true;
              }
              $scope.uploadPdfContent = 'data:application/pdf;base64,' + pdfData.value.fileContent;
              if (pdfData.value.fileContent !== undefined) {
                $rootScope.pdfRefresh = true;
              } else {
                $rootScope.pdfRefresh = false;
              }
              $scope.getPreview($scope.uploadPdfContent);
           
        });
      };
      /* istanbul ignore next*/
      vm.setToastMessage = function (message, messagetwo, messagethree, pdfData) {
        $scope.showPreview = false;
        toastr.success(message + $scope.shareAssign[0].appealNumber + messagetwo, {
          iconClass: 'toast-success'
        });
        $scope.fileToEmail = pdfData.value.fileName;
        if (pdfData.value.deliveryMode === 'Electronic' || pdfData.value.deliveryMode === 'EMAIL') {
          $scope.showButtons = false;
          toastr.success(messagethree, {
            iconClass: 'toast-success'
          });
        } else {
          $scope.showButtons = true;
        }
        $scope.uploadPdfContent = 'data:application/pdf;base64,' + pdfData.value.fileContent;
        if (pdfData.value.fileContent !== undefined) {
          $rootScope.pdfRefresh = true;
        } else {
          $rootScope.pdfRefresh = false;
        }
        $scope.getPreview($scope.uploadPdfContent);
      };
      $scope.panell = {};
      $scope.panell.assigneeFullNameText = 'No type selected';

      $scope.checkUpload = function (panel) {

        $scope.panell = panel;
        $scope.fileUploadDisable = false;



      };
      /* istanbul ignore next */
      $scope.closeDocketingNotice = function () {
        //ngDialog.closeAll('true');
        if ($scope.shareAssign[0].assignmentType === 'MDN') {
          toastr.success(CONSTANTS.TOASTER.docketingNoticeClose, {
            iconClass: 'toast-success'
          });
        } else if ($scope.shareAssign[0].assignmentType === 'PDISM') {
          toastr.success(CONSTANTS.TOASTER.dismissalClosed, {
            iconClass: 'toast-success'
          });
        } else if ($scope.shareAssign[0].assignmentType === 'PDAP') {
          toastr.success(CONSTANTS.TOASTER.processDismissal, {
            iconClass: 'toast-success'
          });
        } else if ($scope.shareAssign[0].assignmentType === 'PARAP') {
          toastr.success(CONSTANTS.TOASTER.admiRemand, {
            iconClass: 'toast-success'
          });
        }
        if ($scope.shareAssign[0].assignmentType === 'MD' || $scope.shareAssign[0].assignmentType === 'MRD') {
          toastr.success(CONSTANTS.TOASTER.mailingClosed, {
            iconClass: 'toast-success'
          });
        } else {
          toastr.success(CONSTANTS.TOASTER.admiRemand, {
            iconClass: 'toast-success'
          });
        }

        $scope.hideButtons=true;
        $scope.gotoChecklist( $scope.currentAssignment);
      };
      /* istanbul ignore next */
      $scope.successMessages = function (data) {
        $scope.showPreview = false;
        toastr.success(CONSTANTS.TOASTER.noh, {
          iconClass: 'toast-success'
        });
        toastr.success(CONSTANTS.TOASTER.ifw, {
          iconClass: 'toast-success'
        });
        toastr.success(CONSTANTS.TOASTER.snoh, {
          iconClass: 'toast-success'
        });
        $scope.fileToEmail = data.value.fileName;
        if (data.value.deliveryMode === 'Electronic' || data.value.deliveryMode === 'EMAIL') {
          $scope.showButtons = false;

        } else {
          $scope.showButtons = true;
        }
        $scope.uploadPdfContent = 'data:application/pdf;base64,' + data.value.fileContent;
        if (data.value.fileContent !== undefined) {
          $rootScope.pdfRefresh = true;
        } else {
          $rootScope.pdfRefresh = false;
        }
        $scope.getPreview($scope.uploadPdfContent);
        return;
      };

      $scope.email = function () {

        /* istanbul ignore next */
        HttpFactory.postActions(CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.UPLOAD_EMAIL + 'fileToEmail=' + $scope.fileToEmail +
            '&appealNumber=' + $scope.shareAssign[0].appealNumber +
            '&serialNumber=' + $scope.shareAssign[0].serialNumber +
            '&assignmentType=' + $scope.shareAssign[0].assignmentType
          )
          .then(function (successResponse) {
            
            $scope.emailResponse = successResponse.data;
            toastr.success(CONSTANTS.TOASTER.email, {
              iconClass: 'toast-success'
            });
            if ($rootScope.isMergedCase) {
              toastr.success($scope.shareAssign[0].title + " assignments for " + $rootScope.mergedApplListForToastr + " have been closed.", {
                iconClass: 'toast-success'
              });
            }

            $scope.hideButtons=true;
            $scope.gotoChecklist( $scope.currentAssignment);
          }, function () {
            // intentional
          });
      };

      /* istanbul ignore next */
      $scope.getSnoh = function () {
        HttpFactory.getActions(CONSTANTS.URL.SNOH + "serialNumber=" + $scope.shareAssign[0].serialNumber + "&appealNumber=" + $scope.shareAssign[0].appealNumber)
          .then(function (successResponse) {
              $scope.noh = successResponse.data;
              $scope.patentAddr = successResponse.data.patentAddress;
              if ($scope.noh.fastTrackCase) {
                $scope.showFastTrack = true;
              }
            },
            function (failureResponse) {
              $log.info(failureResponse);
            });
      };
      //common method to display PDF
      /* istanbul ignore next */
      $scope.addFile = function (file) {
        if (!vm.fileAdded1) {
          vm.fileAdded1 = true;
          $scope.errorMessage = false;
          var fileName = file.currentTarget.files["0"].name;
          if (angular.isUndefined(fileName)) {
            return;
          } else {
            var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
            if (ext !== 'pdf') {
              $scope.errorMessage = true;

              toastr.error(CONSTANTS.TOASTER.fileUpload, {
                iconClass: 'toast-danger',
                timeOut: 9000000,
                extendedTimeOut: 9000000

              });
            }
            if (!$scope.errorMessage) {
              $scope.fileContent.push(file.currentTarget.files["0"]);
              $scope.listOfFileNames.push(file.currentTarget.files["0"].name);
              $scope.$apply();
            }
          }
        }
      };

      $scope.fileSelect = function (p) {
        if (p.keyCode === '13') {
          document.getElementById('file1').click();
        }
      };
      /* istanbul ignore next */
      $scope.showPreviewPdf = function () {
        $scope.loading = true;
        var pdfDataFile = new FormData();
        angular.forEach($scope.fileContent, function (value) {
          pdfDataFile.append('uploadMultipartFileContents', value);
        });
        HttpFactory.postPdf(CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.USERGEN + 'appealNumber=' + $scope.shareAssign[0].appealNumber +
            '&ptabAssignmentId=' + $scope.shareAssign[0].assignmentIdentifier, pdfDataFile)
          .then(function (successResponse) {
            $scope.dockType= "USER";
            $scope.documentType(true);
            $scope.PostDataResponse = successResponse.data.fileContent;
            $scope.genPdfFileName = successResponse.data.fileName;
            $scope.contentsPreview = 'data:application/pdf;base64,' + $scope.PostDataResponse;
            $scope.getPreview($scope.contentsPreview);
            $scope.loading = false;
            $scope.hideAdd = false;
          }, function () {
            // intentional
          });
      };

      //delete pdf
      $scope.deletePdf = function (index) {
        $scope.listOfFileNames.splice(index, 1);
        $scope.fileContent.splice(index, 1);

      };

      /* istanbul ignore next */
      $scope.dispFile = function (file) {
        if ($scope.dontCallAgain) {
          return;
        }
        $scope.dontCallAgain=true;
        $timeout(function () {
         $scope.dontCallAgain=false;
       }, 1000);
        $scope.spinnerShow =true;
        $scope.hidePalm = true;
        $scope.errorMessage = false;
        var fileName = file.currentTarget.files["0"].name;
        if (angular.isUndefined(fileName)) {
          return;
        } else {
          var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
          if (ext !== 'pdf') {
            $scope.errorMessage = true;
            $scope.spinnerShow =false;
            toastr.error(CONSTANTS.TOASTER.fileUpload, {
              iconClass: 'toast-danger',
              timeOut: 9000000,
              extendedTimeOut: 9000000

            });
          }
          if (!$scope.errorMessage) {
            $scope.anotherFile1 = false;
            $scope.anotherFile= false;
            var pdfDataFile = new FormData();
            if ($scope.shareAssign[0].assignmentType === 'MDN' || $scope.shareAssign[0].assignmentType ===
              'SNH') {
              $scope.docketFileContent.push(file.currentTarget.files["0"]);
              angular.forEach($scope.docketFileContent, function (value, key) {
                pdfDataFile.append('uploadMultipartFileContents', value);
              });
            } else{
              $scope.docketFileContent = [];
              $scope.docketFileContent.push(file.currentTarget.files["0"]);
              pdfDataFile.append('uploadMultipartFileContents', $scope.docketFileContent[0]);
            }
            $scope.loading = true;
            HttpFactory.postPdf(CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.USERGEN + 'appealNumber=' + $scope.shareAssign[0].appealNumber +
                '&ptabAssignmentId=' + $scope.shareAssign[0].assignmentIdentifier, pdfDataFile)
              .then(function (successResponse) {
$scope.spinnerShow =false;
$scope.dockType = "USER";
                $scope.PostDataResponse = successResponse.data.fileContent;
                $scope.genPdfFileName = successResponse.data.fileName;
                $scope.contentsPreview = 'data:application/pdf;base64,' + $scope.PostDataResponse;
                $scope.fileName= successResponse.data.fileName.split(/-(.+)/)[1];
                $scope.fileNameDis = $scope.fileName;
                $scope.getPreview($scope.contentsPreview);
                $timeout(function () {
                  $scope.loading = false;
               $scope.hidePalm =false;
                }, 2000);
              }, function (failureResponse) {
                 var errorMessage = failureResponse.data.message;
                 if (errorMessage == null || errorMessage === undefined){
                   errorMessage = "Error uploading the document."
                 }
                $scope.spinnerShow =false;
                $scope.enableUpload=false;
                $timeout(function () {
                  $scope.loading =false;
                  $scope.hidePalm =true;
                }, 2000);
              });
          }
        }
      };
      //get call for preview

      /* istanbul ignore next */

      $scope.getPreview = function (contents) {
        $http.get(contents, {
            responseType: 'arraybuffer',
            headers: {
              'Accept': 'application/pdf'
            }
          })
          .success(function (data) {
            var file = new Blob([data], {
              type: 'application/pdf'
            });
            var fileURL = URL.createObjectURL(file);
            var fileOne = window.URL.createObjectURL(file);
            $scope.pdfContent = $sce.trustAsResourceUrl(fileOne);
            if (null !== $scope.pdfContent && document.getElementById('sendNoticeOfHearingPreview') !== null) {
              angular.element(document.getElementById('sendNoticeOfHearingPreview')).scope().pdfContent = $sce.trustAsResourceUrl(fileURL);
            } else {
              $scope.pdfContent = $sce.trustAsResourceUrl(fileURL);
            }
            if (fileURL !== '' || angular.isDefined(fileURL)) {
              $scope.show = false;
              $scope.editable = false;
              $scope.pdfStyle = {
                "border": "1px solid grey"
              };
            }
          }).error(function () {
            // intentional
          });
      };
      //SERVER file, URL will be replaced by services URL
      $scope.systemFile = function () {
        $scope.loading = true;
        $scope.hideAdd = false;
        /* istanbul ignore next*/
        HttpFactory.postPdf(CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.SYSGEN + 'appealNumber=' + $scope.shareAssign[0].appealNumber +
            '&ptabAssignmentId=' + $scope.shareAssign[0].assignmentIdentifier + '&serialNumber=' + $scope.caseNum + '&orderType=' + "NOTICE")
          .then(function (successResponse) {
           $scope.dockType= "SYSTEM";
            $scope.PostDataResponse = successResponse.data;
            $scope.contentsPreview = 'data:application/pdf;base64,' + $scope.PostDataResponse.fileContent;
            $scope.genPdfFileName = successResponse.data.fileName;
            $scope.getRtfFileName = successResponse.data.rtfFileName[0];
            $scope.getPreview($scope.contentsPreview);
            $scope.loading = false;
            $scope.fileNumber = 0;
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };

      //LOCAL file
      function clickElem(elem) {
        var eventMouse = document.createEvent("MouseEvents");
        eventMouse.initMouseEvent("click", true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
        elem.dispatchEvent(eventMouse);
      }
      /* istanbul ignore next */
      $scope.openFile = function () {
        var fileInput = document.createElement("input");

        var readFile = function (e) {
          var file = e.target.files[0];
          if (!file) {
            return;
          }
          var reader = new FileReader();
          reader.onload = function (e) {
            var contents = e.target.result;
            dispFile(contents);
            document.body.removeChild(fileInput);
          };
          reader.readAsDataURL(file);
        };
        fileInput.type = 'file';
        fileInput.onchange = readFile;
        fileInput.accept = 'application/pdf';
        document.body.appendChild(fileInput);
        clickElem(fileInput);
      };

      $scope.cancelUpload = function () {
        $scope.pdfContent = '';
        $scope.editable = true;
        $scope.show = true;
        $scope.hideAdd = true;
        $scope.pdfStyle = {
          "border": "none"
        };
      };

      /* get apj1 list */
      /* istanbul ignore next */
      $scope.getApjName = function () {
        HttpFactory.getActions("/appeal-judge-panels?appealNumber=" + $scope.shareAssign[0].appealNumber + "&applicationNumber=" + $scope.shareAssign[0].serialNumber)
          .then(function (successResponse) {
            angular.forEach(successResponse.data.judgePanel, function (dataApj) {

              if (dataApj.reconsiderSequenceNumber === successResponse.data.judgePanel.length - 1) {
                angular.forEach(dataApj.panelToBeCreated, function (panel) {
                  if (panel.activeIndicator === "Y" && panel.panelRank === 1) {
                    $scope.apj1 = panel.panelName;
                    $scope.apj1Identifer = panel.identifier;
                    $scope.panell.assigneeFullNameText = panel.panelName;
                    $scope.panell.assigneeNumberText = panel.identifier;
                    if($scope.panell.assigneeFullNameText) {
                      $scope.fileUploadDisable = false;
                    }
                  }
                });
              }
            });
          }, function (failureResponse) {
            return failureResponse;
          });
      };

      $scope.getApjName();
      /* istanbul ignore next */
      $scope.getSelectedJudgeList = function () {
        HttpFactory.getActions(CONSTANTS.URL.GET_SELECTED_JUDGES + $scope.shareAssign[0].appealNumber + "&applicationNumber=" + $scope.shareAssign[0].serialNumber)
          .then(function (successResponse) {
            var tempList = [];
            $scope.rsNum = successResponse.data.judgePanel[0].reconsiderSequenceNumber;
            $scope.panelToBeCreatedArray = successResponse.data.judgePanel[0].panelToBeCreated;
            var lowest = 0;
            var highest = 0;
            var tmp;
            for (var i = $scope.panelToBeCreatedArray.length - 1; i >= 0; i--) {
              tmp = $scope.panelToBeCreatedArray[i].panelSequenceNumber;
              if (tmp < lowest) lowest = tmp;
              if (tmp > highest) highest = tmp;
            }
            $scope.adsNum = highest;
            angular.forEach(successResponse.data.judgePanel[0].panelToBeCreated, function (panel) {


              if (panel.activeIndicator === "Y" || panel.activeIndicator === "P") {

                if (panel.panelRank === 0) {
                  $scope.paName = panel.panelName;
                  $scope.paRank = panel.panelRank;
                }
                tempList[panel.panelRank - 1] = {
                  "identifier": panel.identifier,
                  "panelName": panel.panelName,
                  "panelRank": panel.panelRank,
                  "activeIndicator": panel.activeIndicator,
                  "reconsiderSequenceNumber": panel.reconsiderSequenceNumber,
                  "lastModifiedUserIdentifier": vm.userInfo.userId,
                  "lastModifiedTimestamp": new Date().getTime(),
                  "serialNumber": $scope.shareAssign[0].serialNumber,
                  "appealNumber": $scope.shareAssign[0].appealNumber,
                };
              }
            });

            $scope.judgesToPanel = tempList;
            if (angular.isDefined($scope.paRank) && $scope.paRank - 1 === -1) {
              var tempOrder = tempList[-1];
              tempList[tempList.length] = tempOrder;
            }
            $scope.apjList = [];
            $scope.tempApjList = tempList;
            $scope.apjList = $scope.tempApjList;
          });
      };
      /*istanbul ignore next */
      $scope.responseTime = function (enterDays) {
        $scope.enterDays = enterDays;
        if (enterDays > 0) {
          $scope.enableUpload = false;
          $scope.hidePalm = false;
        } else if(enterDays == null || enterDays === ""){
          $scope.hidePalm = true;
        }
        var tt = $scope.transactionDate;

        var date = new Date(tt);
        var newdate = new Date(date);
        $scope.responseDueDate = newdate.setDate(newdate.getDate() + enterDays);
        var dd = newdate.getDate();
        var mm = newdate.getMonth() + 1;
        var y = newdate.getFullYear();

        var someFormattedDate = mm + '/' + dd + '/' + y;
        $scope.responseTimeValue = someFormattedDate;

      };

      $scope.rtfFile = function () {
        HttpFactory.getActions(CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.DOWNLOAD_RTF + 'fileName=' + $scope.getRtfFileName)
          .then(function (successResponse) {
            $log.info(successResponse);
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };

      /*decision type rehearing mail decision*/
      $scope.getRehearingDecisionType = function () {
        HttpFactory.getActions(CONSTANTS.URL.REHEARING_DECISION_TYPE)
          .then(function (successResponse) {

            $scope.rehearingDecision = successResponse.data;
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };
      /*decision type mail decision*/
      $scope.getDecisionType = function () {
        HttpFactory.getActions(CONSTANTS.URL.DECISIONTYPE)
          .then(function (successResponse) {
            $scope.decisionList = successResponse.data;
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };
      $scope.setRule = true;
      /* istanbul ignore next */
      $scope.getRule = function (value, description) {
        $scope.setRule = false;
        $scope.selectedDecisionDisplay = description;
        $scope.selectedDecisionValue = value;
        HttpFactory.getActions(CONSTANTS.URL.RULETYPE + value + '/' + $scope.shareAssign[0].serialNumber)
          .then(function (successResponse) {
            $scope.ruleList = successResponse.data;
            if ($scope.ruleList.decisionRuleName !== 'N/A') {
              $scope.enableUpload = true;
              $scope.responseTime($scope.enterDays);
            } else {
              $scope.enableUpload = false;
            }

            if($scope.decisionDocument === "Use system converted PDF" && !$scope.enableUpload){
              $scope.hidePalm = false;
            } else if($scope.decisionDocument === "Choose another file" &&$scope.enableUpload &&  $scope.fileNameDis != null){
              $scope.hidePalm = true;
            } else if($scope.decisionDocument === "Use system converted PDF" && $scope.enableUpload){
              $scope.hidePalm = true;
            } else if($scope.decisionDocument === "Choose another file" && !$scope.enableUpload){
              $scope.hidePalm = false;
            }
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };
      // process rehearing controller
      $scope.selectedRow = $rootScope.sharedItems[0];
      vm.getAttorneys = function () {
        HttpFactory.getActions(CONSTANTS.URL.PANELADMINISTRATORS + "identifier=Panel Administrators")
          .then(function (successResponse) {
            $scope.judgeList = successResponse.data;
            $scope.destjudgeList = [];
            $scope.oldList = angular.copy($scope.destjudgeList);
            $scope.originalList = angular.copy($scope.judgeList);
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };
      vm.getAttorneys();
      vm.hidePanel = true;
      /* istanbul ignore next*/
      vm.getPanel = function () {
        HttpFactory.getActions(CONSTANTS.URL.GET_PANEL_HISTORY + $scope.selectedRow.appealNumber)
          .then(function (successResponse) {

            var tempList = [];
            var setPanelDate = true;
            angular.forEach(successResponse.data, function (judge) {
              angular.forEach(judge, function (panelToBeCreated) {
                angular.forEach(panelToBeCreated.panelToBeCreated, function (panel) {
                  if (panel.activeIndicator === "P" || panel.activeIndicator === "Y") {
                    tempList[panel.panelRank - 1] = {
                      "assigneeNumberText": panel.identifier,
                      "assigneeFullNameText": panel.panelName
                    };
                    if (panel.panelRank === 0) {
                      $scope.selectedAttorney = panel.identifier;
                      $scope.patentAttorneyName = panel.panelName;
                    }
                    if (setPanelDate) {
                      $scope.panelingDate = panel.assignedDate;
                      setPanelDate = false;
                    }
                  }
                });
              });
            });
            $scope.destjudgePanelList = tempList.filter(function (el) {
              return angular.isDefined(el);
            });
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };
      $scope.dataSelected = function (a) {
        $scope.tempItem = $scope.judgeList[a];
        $scope.items = a;

      };
      /* istanbul ignore next  */
      $scope.moveJudgeToPanel = function () {
        $scope.tempArray = [];
        angular.forEach($scope.items, function (itemTodelete) {
          $scope.itemToMove = $scope.judgeList[itemTodelete];
          $scope.tempArray.push($scope.itemToMove);
          if (!$scope.destjudgeList.includes($scope.itemToMove) && $scope.itemToMove !== "" && $scope.itemToMove !== undefined) {
            var obj = $scope.judgeList[itemTodelete];
            var i = 0;
            angular.forEach($scope.originalList, function (each) {
              i++;
              if (each.assigneeNumberText === obj.assigneeNumberText) {
                $scope.indeForOrignal = i;
              }
            });

            $scope.destjudgeList.push($scope.itemToMove);
          }
        });
        angular.forEach($scope.tempArray, function (itemTodelete) {
          var i = 0;
          angular.forEach($scope.originalList, function (each) {
            i++;
            if (each.assigneeNumberText === itemTodelete.assigneeNumberText) {
              $scope.indeForOrignal = i;
            }
          });
          var j = 0;
          angular.forEach($scope.judgeList, function (each) {
            j++;
            if (each.assigneeNumberText === itemTodelete.assigneeNumberText) {
              $scope.indexForjudge = j;
            }
          });
          $scope.originalList.splice($scope.indeForOrignal - 1, 1);
          $scope.judgeList.splice($scope.indexForjudge - 1, 1);

        });
        if ($scope.destjudgeList.length > 1) {
          $scope.originalList.push($scope.destjudgeList[0]);
          $scope.judgeList.push($scope.destjudgeList[0]);
          $scope.destjudgeList.splice($scope.destjudgeList[0], 1);
        }
        vm.hidePanel = false;
        $scope.itemToMove = "";
        $scope.items = "";
        $scope.enableUploadButton();
      };
      /* istanbul ignore next  */
      $scope.criteriaMatch = function (input) {
        $scope.searchText = input;
        $scope.itemToMove = "";
        var tempList = [];
        if (angular.isDefined(input) && input.trim() !== "") {
          angular.forEach($scope.judgeList, function (currentJudge) {
            if (currentJudge.assigneeFullNameText.toLowerCase().includes(input.toLowerCase())) {
              tempList.push(currentJudge);
            }
          });
          $scope.judgeList = angular.copy(tempList);
        } else {
          tempList = angular.copy($scope.originalList);
          for (var i = 0; i < $scope.destjudgeList.length; i++) {
            for (var j = 0; j < tempList.length; j++) {
              if (tempList[j].assigneeNumberText === $scope.destjudgeList[i].assigneeNumberText) {
                tempList.splice(j, 1);
              }
            }
          }
          $scope.judgeList = tempList;
        }
      };
      /** This function will open the panel notes modal */
      $scope.viewNotes = function () {
        var numbers = {
          "applicationNumber": $scope.selectedRow.serialNumber,
          "appealNumber": $scope.selectedRow.appealNumber
        };
        ngDialog.open({
          template: "app/components/widgets/assignments/src/panelingNotesModal.html",
          controller: 'PanelingNotesController',
          controllerAs: 'vm',
          scope: $scope,
          width: '50%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            savedPanelNote: function () {
              return $rootScope.savedPanelNotes;
            },
            numbers: function () {
              return numbers;
            }
          }
        }).closePromise.then(function (response) {
          $rootScope.panelNotes = response.value;
          $rootScope.savedPanelNotes = response.value;
        });
      };
      /** This function will open the panel history modal */
      /* istanbul ignore next */
      $scope.viewPanelHistory = function () {
        // HttpFactory.getActions(CONSTANTS.URL.GET_SELECTED_JUDGES + $scope.selectedRow.appealNumber + "&applicationNumber=" + $scope.selectedRow.serialNumber)
        HttpFactory.getActions(CONSTANTS.URL.GET_PANEL_HISTORY + $scope.selectedRow.appealNumber + "&applicationNumber=" + $scope.selectedRow.serialNumber)
          .then(function (successResponse) {
            $scope.panelHistory = successResponse.data;
            if (angular.isDefined($scope.panelHistory)) {
              ngDialog.open({
                template: "app/components/widgets/assignments/src/viewPanelHistory.html",
                controller: 'ViewPanelHistoryController',
                controllerAs: 'vm',
                scope: $scope,
                width: '50%',
                showClose: false,
                closeByEscape: false,
                closeByDocument: false,
                resolve: {
                  panelHistory: function () {
                    return $scope.panelHistory.judgePanel[0].panelToBeCreated;
                  }
                }
              });
            } else {
              toastr.error(CONSTANTS.TOASTER.noPanelHistory, {
                iconClass: 'toast-danger'
              });
            }
          }, function () {
            toastr.error(CONSTANTS.TOASTER.noPanelHistory, {
              iconClass: 'toast-danger'
            });
          });
      };


      $scope.maxSequenceNumbers = {};
      /* istanbul ignore next*/
      $scope.getNotesList = function () {
        HttpFactory.getActions('/case-information/notes?serialNumber=' + $scope.shareAssign[0].serialNumber + '&appealNumber=' + $scope.shareAssign[0].appealNumber)
          .then(function (successResponse) {
            successResponse.data.appealNoteHistoryList.sort(function (a, b) {
              return b.sequenceNumber - a.sequenceNumber;
            });
            if (successResponse.data.appealNoteHistoryList.length > 0) {
              var value = successResponse.data.appealNoteHistoryList[0].noteText;
              if (value.indexOf('/p') > -1) {
                var tempStr = successResponse.data.appealNoteHistoryList[0].noteText.slice(3, successResponse.data.appealNoteHistoryList[0].noteText.length - 4);
              } else {
                var tempStr = successResponse.data.appealNoteHistoryList[0].noteText;
              }
              $scope.latestNote = "Note: " + tempStr + " <br> <b> by " + successResponse.data.appealNoteHistoryList[0].audit.lastModifiedUserIdentifier +
                " (" + $filter('date')(successResponse.data.appealNoteHistoryList[0].audit.lastModifiedTimestamp, 'MM/dd/yyyy hh:mm a') + ") </b>";
              $scope.maxSequenceNumbers.notes = successResponse.data.appealNoteHistoryList[0].sequenceNumber;
            } else {
              $scope.maxSequenceNumbers.notes = -1;
            }
            $scope.notesList = successResponse.data.appealNoteHistoryList;
          }, function () {
            // intentional
          });
      };

      $scope.getNotesList();
      /* istanbul ignore next*/
      $scope.getCommentsList = function () {
        HttpFactory.getActions('/appeal-comment-history?serialNumber=' + $scope.shareAssign[0].serialNumber + '&appealNumber=' + $scope.shareAssign[0].appealNumber)
          .then(function (successResponse) {
            successResponse.data.sort(function (a, b) {
              return b.sequenceNumber - a.sequenceNumber;
            });
            if (successResponse.data.length > 0) {
              $scope.latestComment = "Comment: " + successResponse.data[0].commentText + " <br> <b> by " +
                successResponse.data[0].audit.lastModifiedUserIdentifier + " (" +
                $filter('date')(successResponse.data[0].audit.lastModifiedTimestamp, 'MM/dd/yyyy hh:mm a') + ") </b>";
              $scope.maxSequenceNumbers.comments = successResponse.data[0].sequenceNumber;
            } else {
              $scope.maxSequenceNumbers.comments = -1;
            }
            $scope.commentsList = successResponse.data;
          }, function () {
            // intentional
          });
      };

      $scope.getMailingNotes = function () {
        HttpFactory.getActions('/circulation-notes?appealNumber=' + $scope.shareAssign[0].appealNumber + '&serialNumber=' + $scope.shareAssign[0].serialNumber)
          .then(function (successResponse) {
            if (successResponse.data.mailingNotes[0]) {
              $scope.mailingNotes = successResponse.data.mailingNotes[0].noteText;
              $scope.noteModifiedBy = "<b> by "+ successResponse.data.mailingNotes[0].noteModifiedBy + " (" +
                $filter('date')(successResponse.data.mailingNotes[0].audit.lastModifiedTimestamp, 'MM/dd/yyyy hh:mm a') + ")</b>";
            }

          }, function () {
            // intentional
          });
      };


      $scope.getCommentsList();

      $scope.openCommentsNotesModal = function () {
        ngDialog.open({
          template: 'app/components/widgets/assignments/src/commentsNotesModal.html',
          controller: 'CommentsNotesController',
          controllerAs: 'vm',
          width: '57%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            notesList: function () {
              return $scope.notesList;
            },
            commentsList: function () {
              return $scope.commentsList;
            },
            caseInfo: function () {
              return $scope.shareAssign;
            },
            maxSequenceNumbers: function () {
              return $scope.maxSequenceNumbers;
            }
          }
        }).closePromise.then(function () {
          $scope.getNotesList();
          $scope.getCommentsList();
        });
      };

      $scope.hearingStatusSelected = false;

      $scope.selectHearingStatus = function () {
        $scope.hearingStatusSelected = true;
        $scope.hearingRoomRosterData.statusCode = vm.hearingStatusIndicator;
        $scope.enableUploadButton();
      };
      /* istanbul ignore next*/
      $scope.checkForHearingStatusIndicator = function () {

        if ($scope.shareAssign[0].globalMetaData.briefHearingType === "Heard") {
          HttpFactory.getActions('/hearing-room-rosters?appealNumber=' + $scope.appealNumber)
            .then(function (successResponse) {
              $scope.hearingRoomRosterData = successResponse.data;
              var currentDate = Math.floor(new Date().getTime() / 1000) * 1000;
              if (successResponse.data.hearingDate > currentDate) {

                $scope.showHearingStatus = true;
              }
            }, function () {
              // intentional
            });
        }
      };
      $scope.checkForHearingStatusIndicator();


      $scope.enableUploadButton = function () {
        $scope.readyToCreateRemand = true;
        if ($scope.showHearingStatus && $scope.hearingStatusSelected && !vm.hidePanel && $scope.showPreview && $scope.show) {
          $scope.showUploadButton = true;
        } else if (!$scope.showHearingStatus && !vm.hidePanel && $scope.showPreview && $scope.show) {
          $scope.showUploadButton = true;
        }
      };


      $scope.selectFiles = function () {
        ngDialog.open({
          template: "app/components/widgets/assignments/src/addFileNOH.html",
          controller: 'docketinInfoController',
          scope: $scope,
          width: '45%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,

          resolve: {
            partiesData: function () {
              return $scope.caseDetailsData;
            },
            partiesFlag: function () {
              return $scope.partiesShow;
            }

          }
        }).closePromise.then(function (data) {
          if (data.value !== "No file" && data.value !== 0) {
            $scope.fileNumber = data.value;
          }
          $scope.getDocketInfo($scope.shareAssign[0].serialNumber, $scope.shareAssign[0].appealNumber);

        }, function () {
          // intentional
        });
      };

      $scope.clearFile = function(){
        $scope.fileNameDis = null;
        $scope.anotherFile = true;
        $scope.editedInformation = false;
      };

      /* istanbul ignore next*/
      $scope.downloadDisable = function (value) {
        if (value) {
          document.getElementById("downloadPdfEdit").disabled = true;
        } else {
          document.getElementById("downloadPdfEdit").disabled = false;
        }
      };

      $scope.documentType = function (value) {
        if (value) {
          document.getElementById("systemNoticeFlag").style.display = "none";
          document.getElementById("userNoticeFlag").style.display = "block";
        } else {
          document.getElementById("systemNoticeFlag").style.display = "block";
          document.getElementById("userNoticeFlag").style.display = "none";
        }

      };


      $scope.createAdminRemand = function () {
        var dateScope = angular.element(document.getElementById("carPanelDate")).scope();
        var carPanelDate;
        if (angular.isNumber(dateScope.panelingDate)) {
          carPanelDate = dateScope.panelingDate;
        } else {
          carPanelDate = dateScope.panelingDate.getTime();
        }
        var assignmentInfo = angular.copy($scope.shareAssign);
        assignmentInfo[0].priorityIndicator = assignmentInfo[0].priorityIndicator ? 'N' : 'Y';

        if (assignmentInfo[0].assignmentType === 'CDD') {
          assignmentInfo[0].completionCode = 'DISMISSAL_DRAFT';
        }
        if (assignmentInfo[0].assignmentType === 'CARD') {
          assignmentInfo[0].completionCode = 'ADMIN_DRAFT';
        }

        var createAdminRemandObject = {
          "serialNumber": $scope.caseNum,
          "appealNumber": $scope.appealNumber,
          "panelDate": carPanelDate,
          "fileName": null,
          "currentAssignment": assignmentInfo[0],
          "newAssignment": assignmentInfo[0],
          'judgeData': {
            "identifier": $scope.destjudgeList[0].assigneeNumberText
          },
          "audit": {
            "createUserIdentifier": $scope.shareAssign[0].audit.createUserIdentifier,
            "lastModifiedUserIdentifier": vm.userInfo.userId,
            "lastModifiedTimestamp": new Date().getTime(),
            "createdUserName": $scope.shareAssign[0].audit.createdUserName,
            "lastModifiedUserName": $scope.shareAssign[0].audit.lastModifiedUserName,
            "createTimestamp": $scope.shareAssign[0].audit.createTimestamp,
            "lockControlNumber": $scope.shareAssign[0].audit.lockControlNumber
          }
        };
        $scope.readyToCreateRemand = false;
        $log.info("Create admin remand object: %o", createAdminRemandObject);
        HttpFactory.postActions(CONSTANTS.URL.PROCESSREMAND, createAdminRemandObject)
          .then(function (successResponse) {
            $log.info(successResponse);
            toastr.success(CONSTANTS.TOASTER.assignmentClosed, {
              iconClass: 'toast-success'
            });
           // ngDialog.closeAll('true');
          }, function (failureResponse) {
            $log.info(failureResponse);
            $scope.readyToCreateRemand = true;
          });
      };

    });
})();
