(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('CommentsNotesController', function (caseInfo, maxSequenceNumbers, $log, HttpFactory, $timeout, $rootScope, CONSTANTS, ngDialog, notesList, commentsList) {
      var vm = this;
      vm.userInfo = $rootScope.userInfo;
      vm.notesList = notesList;
      vm.commentsList = commentsList;
      vm.tableData = [];
      vm.disableCommentButton = true;
      vm.disableNotesButton = true;
      vm.selectedComment = "default";
      vm.newNotes = [];
      vm.newComments = [];
      vm.notesSequenceNumber = maxSequenceNumbers.notes;
      vm.commentsSequenceNumber = maxSequenceNumbers.comments;


      /**
       * TinyMCE editor configurations for the note section
       */
      /* istanbul ignore next */
      vm.commentsNotesTinymceOptions = {
        plugins: 'link image',
        toolbar: "undo redo bold italic",
        menu: {},
        browser_spellcheck: true,
        contextmenu: false,
        elementpath: false,
        init_instance_callback: function (editor) {
          var textContentTrigger = function () {
            vm.newNote = editor.getBody().textContent;
          };
          editor.on('KeyUp', textContentTrigger);
          editor.on('ExecCommand', textContentTrigger);
          editor.on('SetContent', function (e) {
            if (!e.initial) {
              textContentTrigger();
            }
          });
        }
      };

      $timeout(function () {
        setAriaAttribute('mceu_0', 'Undo');
        setAriaAttribute('mceu_1', 'Redo');
        setAriaAttribute('mceu_2', 'Bold');
        setAriaAttribute('mceu_3', "Italic");
        setAriaAttribute('mceu_4', "insert link");
      }, 2000);

      function setAriaAttribute(timeMcButtonId, text) {
        try {
          var tinyMcButton = document.getElementById(timeMcButtonId);
          var tinyMcButtonHTML = tinyMcButton.childNodes[0];
          tinyMcButtonHTML.setAttribute("aria-label", text);
        } catch (error) {
          $log.info("Error finding TinyMCE button");
        }
      }

      /**
       * This function will retrieve the list of comments to populate the dropdown
       */
      HttpFactory.getActions(CONSTANTS.URL.COMMENT_LIST)
        .then(function (successResponse) {
          vm.commentsDropdownList = successResponse.data;
        }, function () { //intentional
        });



      vm.addComment = function () {
        vm.commentsSequenceNumber++;
        vm.newComments.push(vm.createContent("comment", vm.selectedComment));
        var newComment = {
          "text": vm.selectedComment.descriptionText,
          "type": "Comment",
          "lastModifiedUserId": vm.userInfo.userId
        };
        vm.tableData.unshift(newComment);
        vm.selectedComment = "";
        vm.disableSaveButton = false;
        vm.disableCommentButton = true;
      };

      vm.addNote = function () {
        vm.notesSequenceNumber++;
        vm.newNotes.push(vm.createContent("note", vm.enteredNote));
        var newNote = {
          "text": vm.enteredNote,
          "type": "Note",
          "lastModifiedUserId": vm.userInfo.userId
        };
        vm.tableData.unshift(newNote);
        vm.enteredNote = "";
        vm.disableSaveButton = false;
        vm.disableNotesButton = true;
      };

      vm.closeModal = function () {
        var thisModal = ngDialog.getOpenDialogs();
        ngDialog.close(thisModal[thisModal.length - 1]);
      };

      vm.createTableData = function () {
        vm.tableData = [];
        angular.forEach(vm.notesList, function (note) {
          var tempNote = {
            "text": note.noteText,
            "type": "Note",
            "lastModifiedUserId": note.audit.lastModifiedUserIdentifier,
            "lastModifiedTime": note.audit.lastModifiedTimestamp
          };
          vm.tableData.push(tempNote);
        });
        angular.forEach(vm.commentsList, function (comment) {
          var tempComment = {
            "text": comment.commentText,
            "type": "Comment",
            "lastModifiedUserId": comment.audit.lastModifiedUserIdentifier,
            "lastModifiedTime": comment.audit.lastModifiedTimestamp
          };
          vm.tableData.push(tempComment);
        });
        vm.tableData.sort(function (a, b) {
          return b.lastModifiedTime - a.lastModifiedTime;
        });
        vm.disableSaveButton = true;

      };

      vm.createTableData();

      vm.checkComment = function () {
        if (vm.selectedComment !== "default") {
          vm.disableCommentButton = false;
        }
      };

      vm.checkNotes = function () {
        var html = vm.enteredNote;
        var div = document.createElement("div");
        div.innerHTML = html;
        var notesToCheck = div.innerText;
        if (vm.enteredNote && vm.enteredNote !== "" && notesToCheck.trim() !== "") {
          vm.disableNotesButton = false;
        } else {
          vm.disableNotesButton = true;
        }
      };

      vm.createContent = function (contentType, noteOrComment) {

        var content = {
          "serialNumber": caseInfo[0].serialNumber,
          "appealNumber": caseInfo[0].appealNumber,
          "audit": {
            "lastModifiedUserIdentifier": vm.userInfo.userId
          }
        };
        if (contentType === "comment") {
          content.commentText = noteOrComment.descriptionText;
          content.sequenceNumber = vm.commentsSequenceNumber;
        } else if (contentType === "note") {
          content.noteText = noteOrComment;
          content.sequenceNumber = vm.notesSequenceNumber;
        }

        return content;
      };

      vm.saveNotesAndComments = function () {
        if (vm.newComments.length > 0) {
          vm.saveComments();
        } else {
          if (vm.newNotes.length > 0) {
            vm.saveNotes();
          }
        }
      };

      vm.saveAndClose = function () {
        vm.saveNotesAndComments();
        $timeout(function () {
          vm.closeModal();
        }, 2000);
      };

      /* istanbul ignore next */
      vm.saveComments = function () {
        var postCommentsObject = {};
        postCommentsObject.commentHistoryList = vm.newComments;
        HttpFactory.postActions('/appeal-comment-history', postCommentsObject)
          .then(function (successResponse) {
            $log.info(successResponse.data);
            successResponse.data.sort(function (a, b) {
              return b.sequenceNumber - a.sequenceNumber;
            });
            vm.commentsList = successResponse.data;
            vm.newComments = [];
          }, function (failureResponse) {
            $log.info(failureResponse);
          })
          .finally(function () {
            if (vm.newNotes.length > 0) {
              vm.saveNotes();
            } else {
              vm.createTableData();
            }
          });
      };

      /* istanbul ignore next */
      vm.saveNotes = function () {
        var postNotesObject = {};
        postNotesObject.appealNoteHistoryList = vm.newNotes;
        HttpFactory.postActions('/case-information/notes', postNotesObject)
          .then(function (successResponse) {
            $log.info(successResponse.data);
            successResponse.data.appealNoteHistoryList.sort(function (a, b) {
              return b.sequenceNumber - a.sequenceNumber;
            });
            vm.notesList = successResponse.data.appealNoteHistoryList;
            vm.newNotes = [];
          }, function (failureResponse) {
            $log.info(failureResponse);
          })
          .finally(function () {
            vm.createTableData();
          });
      };

    });
})();
