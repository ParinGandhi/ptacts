(function () {
  'use strict';

  describe('PanelingNotesController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['close', 'getOpenDialogs']);
    var controller, scope, $rootScope, savedPanelNote, HttpFactoryDeferred, successResponse, $q, $http;
    var numbers = {
      "applicationNumber": "123",
      "appealNumber": "456"
    };



    beforeEach(inject(function (_$controller_, _$rootScope_, _$http_, _$q_, HttpFactory) {
      $q = _$q_;
      $http = _$http_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;

      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      $controller = _$controller_;


      controller = $controller('PanelingNotesController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        savedPanelNote: savedPanelNote,
        numbers: numbers

      });



    }));

    describe('PanelingNotesController ', function () {

      // it('it should call checksave', function () {


      //   // controller.numbers = {
      //   //   "applicationNumber": "123",
      //   //   "appealNumber": "456"
      //   // };

      //   controller.panelNotes = [];

      //   expect(controller['checksave']).toBeDefined();
      //   controller.checksave();
      // });

      it('it should call cancelPanelNotesModal ', function () {
        expect(controller['cancelPanelNotesModal']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.cancelPanelNotesModal();
      });

      it('it should call savePanelNote ', function () {
        expect(controller['savePanelNote']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.savePanelNote();
      });

    });
  });
})();
