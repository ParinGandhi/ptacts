(function () {
  "use strict";

  angular.module('ptabe2e')
    .controller('AssignmentHistoryController', function ($scope, $filter, uiGridConstants, assignmentData, ngDialog,
      SearchHelperService, HttpFactory, $log, CONSTANTS, CommonHelperService) {

      $scope.assignmentData = assignmentData;
      /* istanbul ignore next  */
      $scope.gridOptions = {
        enableGridMenu: true,
        enableSelectAll: true,
        useExternalFiltering: true,
        exporterCsvFilename: 'Assignment history ' + CommonHelperService.getCurrentTime() + '.csv',
        exporterOlderExcelCompatibility: true,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        gridMenuShowHideColumns: false,
        paginationPageSizes: [10, 25, 50, 100],
        paginationPageSize: 10,
        enableFiltering: true,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.WHEN_NEEDED,
        exporterFieldCallback: function (grid, row, col, value) {
          $scope.gridOptions.exporterCsvFilename = 'Assignment history ' + CommonHelperService.getCurrentTime() + '.csv';
          if (col.colDef.type === 'date') {
            if (col.name === 'lastModifiedDate') {
              value = $filter('date')(value, 'MM/dd/yyyy hh:mm:ss a');
            } else {
              value = $filter('date')(value, 'MM/dd/yyyy');
            }
            if (angular.isUndefined(value) || value === null) {
              value = "";
            } else {
              value = " " + value;
            }
          }
          return value;
        },
        onRegisterApi: function (gridApi) {
          $scope.gridApi = gridApi;
          $scope.gridApi.core.on.filterChanged($scope, function () {
            var grid = this.grid;
            $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
            if ($scope.numberOfFilters === 0) {
              $scope.gridOptions.data = $scope.myData.caseDetailsData;
            } else {
              var assignmentFilteredData = SearchHelperService.filterGrid(grid, $scope.myData);
              $scope.gridOptions.data = assignmentFilteredData;

            }
          });
        }
      };
      $scope.isLoading = true;
      $scope.showFilters = false;
      HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTHISTORY + assignmentData.assignmentIdentifier)
        .then(function (successResponse) {
          $scope.myData = successResponse.data;
          var assignmentColDefs = [];
          for (var i = 0; i < $scope.myData.columnDetails.length; i++) {
            var assignmentCol = {};
            assignmentCol.field = $scope.myData.columnDetails[i].name;
            if ($scope.myData.columnDetails[i].typeDefinition === "Date") {
              assignmentCol.type = 'date';
              assignmentCol.cellFilter = 'date:"MM/dd/yyyy"';
            }
            if (assignmentCol.field === "lastModifiedDate") {
              if ($scope.myData.columnDetails[i].typeDefinition === "Date") {
                assignmentCol.type = 'date';
                assignmentCol.cellFilter = 'date:"MM/dd/yyyy hh:mm:ss a"';
              }
            }
            if (assignmentCol.field === "noteText") {
              assignmentCol.cellTemplate =
                '<div class="truncateTitle" title="view update note" style="cursor: pointer; margin-left: 8px; padding-top:5px">' +
                '<a ng-click="grid.appScope.openUpdateData(row)" target="_blank" class="reportListName" id="{{COL_FIELD}}" >' +
                "{{COL_FIELD}}" + '</a>' +
                '</div>';
            }
            assignmentCol.enableHiding = false;
            assignmentCol.displayName = $scope.myData.columnDetails[i].label;
            assignmentCol.headerTooltip = $scope.myData.columnDetails[i].label;
            assignmentCol.field = $scope.myData.columnDetails[i].name;
            assignmentColDefs.push(assignmentCol);
          }

          $scope.gridOptions.columnDefs = assignmentColDefs;
          $scope.gridOptions.data = $scope.myData.caseDetailsData;
          $scope.isLoading = false;
        }, function (failureResponse) {
          $log.info(failureResponse);
          $scope.isLoading = false;
        });

      $scope.toggleFilteringAssignment = function () {
        $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
        $scope.gridApi.grid.clearAllFilters();
        $scope.gridOptions.data = $scope.myData.caseDetailsData;
        $scope.numberOfFilters = 0;
      };

      $scope.showFilteringAssignment = function () {
        ngDialog.open({
          template: 'app/components/helperComponents/filterHelp/filteringHelp.html',
          controller: 'CommonDialogController',
          controllerAs: 'vm',
          showClose: false
        }).then(function () { //intentional
        }, function () { //intentional
        });
      };

      $scope.getAssignmentDetails = function () {
        HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTBYID + assignmentData.assignmentIdentifier)
          .then(function (successResponse) {
              $scope.assignmentDetails = successResponse.data;
            },
            function (failureResponse) {
              $log.info(failureResponse);
            });
      };
      $scope.getAssignmentDetails();

      $scope.openUpdateData = function (row) {
        $scope.updateData = row.entity;
        ngDialog.open({
          template: 'app/components/widgets/assignments/src/updateData.html',
          scope: $scope,
          width: '50%',
          showClose: false
        });
      };

    });
})();
