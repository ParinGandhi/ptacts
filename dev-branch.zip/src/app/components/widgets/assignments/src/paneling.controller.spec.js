// (function () {
//   'use strict';

//   describe('PanelingController', function () {

//     beforeEach(module('ptabe2e'));
//     var $controller;
//     var vm = this;
//     var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'closeAll']);
//     var controller, scope, $rootScope;
//     var timeout;
//     var sharedItems, dateScope;
//     var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;
//     var response = {
//       value: "notes"
//     }
//     beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
//       $q = _$q_;
//       $controller = _$controller_;
//       scope = _$rootScope_.$new();
//       $rootScope = _$rootScope_;
//       HttpFactoryDeferred = _$q_.defer();
//       spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);

//       ngDialog.open.and.returnValue({
//         closePromise: {
//           then: function (callback1) {
//             callback1(response);
//           }
//         }
//       });

//       dateScope = {
//         panelingDate: new Date()
//       }

//       successResponse = {
//         data: {
//           decisions: [{
//             requestDate: "Request date"
//           }],
//           judgePanel: [{
//             reconsiderSequenceNumber: 1,
//             panelToBeCreated: [{
//               lastModifiedUserName: "sbartlett"
//             }]
//           }],
//           assignedAttorneyList: [{
//             assigneeNumberText: "123",
//             assigneeFullNameText: "sbartlett"
//           }],
//           nonAssignedAttorneyList: [{
//             assigneeNumberText: "456",
//             assigneeFullNameText: "tlee7"
//           }]
//         }
//       }

//       $rootScope.sharedItems = [{
//         "serialNumber": "10300247",
//         "sequenceNumber": 0,
//         "appealNumber": "2019000445",
//         "lifeCycle": null,
//         "audit": {
//           "lastModifiedTimestamp": 1541787963000,
//           "lastModifiedUserIdentifier": "gandhi9",
//           "createUserIdentifier": "asankineni",
//           "createdUserName": "Sankineni, Archana ",
//           "lastModifiedUserName": "Gandhi, Parin ",
//           "createTimestamp": 1541787963426,
//           "lockControlNumber": 0
//         },
//         "assignmentIdentifier": 1896,
//         "assignmentType": "UeWF",
//         "assignmentTypeIdentifier": "58",
//         "assignee": "5768",
//         "assignor": "5767",
//         "caseType": "APPEAL",
//         "priorityIndicator": "N",
//         "activeIndicator": "A",
//         "title": "Update eWF - 2019000445",
//         "description": "Update the electronic working file (eWF) for this case, including judges' names.",
//         "notes": null,
//         "assignedDate": 1541787963000,
//         "dueDate": 1542085200000,
//         "completionDate": null,
//         "palmMailedDate": null,
//         "standardAssignmentType": {
//           "UPDATEEWF": "Update eWF",
//           "ASSIGNMENTINFO": "Assignment info"
//         },
//         "completedUserName": null,
//         "lastModifiedUserName": null,
//         "noOfActiveCases": 0,
//         "assignmentStatusCode": "A",
//         "assigneeRoleCode": null,
//         "assigneeRoleDescription": null,
//         "assignmentSequence": null,
//         "reconsiderSequence": null,
//         "pendingLocationText": null,
//         "assignmentTypeDescription": "Update eWF",
//         "completionCode": null,
//         "message": null,
//         "globalMetaData": {
//           "applicationNumber": "10300247",
//           "caseNumber": "2019000445",
//           "parties": null,
//           "panel": [{
//               "employeeName": "GERSTENBLITH, BART A",
//               "rank": 1
//             },
//             {
//               "employeeName": "MOHANTY, BIBHU ",
//               "rank": 2
//             },
//             {
//               "employeeName": "GERSTENBLITH, BART ",
//               "rank": 3
//             }
//           ],
//           "briefHearingType": "On brief",
//           "caseType": "REGULAR",
//           "caseStatus": "Update eWF",
//           "caseStatusDate": 1541514377000,
//           "applicationStatusDescriptionText": "On Appeal -- Awaiting Decision by the Board of Appeals"
//         }
//       }];


//       controller = $controller('PanelingController', {
//         $scope: scope,
//         ngDialog: ngDialog,
//         $rootScope: _$rootScope_,
//         HttpFactory: HttpFactory

//       });
//     }));


//     describe('PanelingController ', function () {


//       it('should call getDisciplineList and return successResponse', function () {

//         expect(scope.getDisciplineList).toBeDefined();
//         scope.getDisciplineList();
//         HttpFactoryDeferred.resolve(successResponse);
//         scope.$digest();

//       });


//       it('should call getDisciplineList and return failureResponse', function () {

//         expect(scope.getDisciplineList).toBeDefined();
//         scope.getDisciplineList();
//         HttpFactoryDeferred.reject();
//         scope.$digest();

//       });



//       it('should call getSectionList and return successResponse', function () {

//         expect(scope.getSectionList).toBeDefined();
//         scope.getSectionList();
//         HttpFactoryDeferred.resolve(successResponse);
//         scope.$digest();

//       });


//       it('should call getSectionList and return failureResponse', function () {

//         expect(scope.getSectionList).toBeDefined();
//         scope.getSectionList();
//         HttpFactoryDeferred.reject();
//         scope.$digest();

//       });



//       it('should call getJudgeList with initialLoad and return successResponse', function () {

//         var successResponse = {
//           data: {
//             judgesToPanel: [{
//                 assigneeNumberText: 123
//               },
//               {
//                 assigneeNumberText: 456
//               }
//             ]
//           }
//         };



//         expect(scope.getJudgeList).toBeDefined();
//         scope.getJudgeList('initialLoad');
//         HttpFactoryDeferred.resolve(successResponse);
//         scope.$digest;

//       });


//       it('should call getJudgeList with selectedDiscipline and selectedSection as all and return successResponse', function () {

//         var successResponse = {
//           data: {
//             judgesToPanel: [{
//                 assigneeNumberText: 123
//               },
//               {
//                 assigneeNumberText: 456
//               }
//             ]
//           }
//         }
//         scope.selectedDiscipline = "all";
//         scope.selectedSection = "all";

//         expect(scope.getJudgeList).toBeDefined();
//         scope.getJudgeList();
//         HttpFactoryDeferred.resolve(successResponse);
//         scope.$digest;

//       });



//       it('should call getJudgeList with selectedDiscipline as all and selectedSection as something and return successResponse', function () {

//         var successResponse = {
//           data: {
//             judgesToPanel: [{
//                 assigneeNumberText: 123
//               },
//               {
//                 assigneeNumberText: 456
//               }
//             ]
//           }
//         }
//         scope.selectedDiscipline = "all";
//         scope.selectedSection = "something";

//         expect(scope.getJudgeList).toBeDefined();
//         scope.getJudgeList();
//         HttpFactoryDeferred.resolve(successResponse);
//         scope.$digest;

//       });


//       it('should call getJudgeList with selectedDiscipline as something and selectedSection as all and return successResponse', function () {

//         var successResponse = {
//           data: {
//             judgesToPanel: [{
//                 assigneeNumberText: 123
//               },
//               {
//                 assigneeNumberText: 456
//               }
//             ]
//           }
//         }
//         scope.selectedDiscipline = "something";
//         scope.selectedSection = "all";

//         expect(scope.getJudgeList).toBeDefined();
//         scope.getJudgeList();
//         HttpFactoryDeferred.resolve(successResponse);
//         scope.$digest;

//       });



//       it('should call getJudgeList with selectedDiscipline as something and selectedSection as something and return successResponse', function () {

//         var successResponse = {
//           data: {
//             judgesToPanel: [{
//                 assigneeNumberText: 123
//               },
//               {
//                 assigneeNumberText: 456
//               }
//             ]
//           }
//         }
//         scope.selectedDiscipline = "something";
//         scope.selectedSection = "something";

//         expect(scope.getJudgeList).toBeDefined();
//         scope.getJudgeList();
//         HttpFactoryDeferred.resolve(successResponse);
//         scope.$digest;

//       });



//       it('should call getJudgeList with selectedDiscipline as something and return successResponse', function () {

//         var successResponse = {
//           data: {
//             judgesToPanel: [{
//                 assigneeNumberText: 123
//               },
//               {
//                 assigneeNumberText: 456
//               }
//             ]
//           }
//         }
//         scope.selectedDiscipline = "something";

//         expect(scope.getJudgeList).toBeDefined();
//         scope.getJudgeList();
//         HttpFactoryDeferred.resolve(successResponse);
//         scope.$digest;

//       });



//       it('should call getJudgeList with selectedSection as something and return successResponse', function () {

//         var successResponse = {
//           data: {
//             judgesToPanel: [{
//                 assigneeNumberText: 123
//               },
//               {
//                 assigneeNumberText: 456
//               }
//             ]
//           }
//         }
//         scope.selectedSection = "something";

//         expect(scope.getJudgeList).toBeDefined();
//         scope.getJudgeList();
//         HttpFactoryDeferred.resolve(successResponse);
//         scope.$digest;

//       });



//       it('should call getJudgeList with selectedDiscipline as all and selectedSection as "" and return successResponse', function () {

//         var successResponse = {
//           data: {
//             judgesToPanel: [{
//                 assigneeNumberText: 123
//               },
//               {
//                 assigneeNumberText: 456
//               }
//             ]
//           }
//         }
//         scope.selectedDiscipline = "all";
//         scope.selectedSection = "";

//         expect(scope.getJudgeList).toBeDefined();
//         scope.getJudgeList();
//         HttpFactoryDeferred.resolve(successResponse);
//         scope.$digest;

//       });



//       it('should call getJudgeList with selectedDiscipline as "" and selectedSection as all and return successResponse', function () {

//         var successResponse = {
//           data: {
//             judgesToPanel: [{
//                 assigneeNumberText: 123
//               },
//               {
//                 assigneeNumberText: 456
//               }
//             ]
//           }
//         }
//         scope.selectedDiscipline = "";
//         scope.selectedSection = "all";

//         expect(scope.getJudgeList).toBeDefined();
//         scope.getJudgeList();
//         HttpFactoryDeferred.resolve(successResponse);
//         scope.$digest;

//       });




//       it('it should call moveJudgeToPanel with more than 3 judges ', function () {

//         scope.judgeList = [{
//             "assigneeNumberText": "5922",
//             "assigneeFullNameText": "Saindon, William "
//           },
//           {
//             "assigneeNumberText": "468",
//             "assigneeFullNameText": "Weatherly, Mitchell "
//           },
//           {
//             "assigneeNumberText": "6003",
//             "assigneeFullNameText": "BARRETT, KEN B"
//           },
//           {
//             "assigneeNumberText": "6005",
//             "assigneeFullNameText": "WIEDER, BRUCE "
//           },
//           {
//             "assigneeNumberText": "6006",
//             "assigneeFullNameText": "CAPP, WILLIAM A"
//           }
//         ];

//         scope.judgeIndex = ["4"];

//         expect(scope['moveJudgeToPanel']).toBeDefined();
//         scope.moveJudgeToPanel();

//       });


//       it('it should call moveJudgeToPanel with less than 3 judges ', function () {

//         scope.judgesToPanel = [{
//           "assigneeNumberText": "6054",
//           "assigneeFullNameText": "Dougal, Brent M..",
//           "workerNumber": "93078",
//           "rankId": 4,
//           "$$hashKey": "object:5140"
//         }]

//         scope.judgeList = [{
//           "assigneeNumberText": "5922",
//           "assigneeFullNameText": "Saindon, William "
//         }];

//         scope.judgeIndex = ["0"];

//         expect(scope['moveJudgeToPanel']).toBeDefined();
//         scope.moveJudgeToPanel();

//       });


//       it('it should call removeJudgeFromPanel  ', function () {

//         scope.judgesToPanel = [{
//             "assigneeNumberText": "5922",
//             "assigneeFullNameText": "Saindon, William "
//           },
//           {
//             "assigneeNumberText": "468",
//             "assigneeFullNameText": "Weatherly, Mitchell "
//           },
//           {
//             "assigneeNumberText": "6003",
//             "assigneeFullNameText": "BARRETT, KEN B"
//           },
//           {
//             "assigneeNumberText": "6005",
//             "assigneeFullNameText": "WIEDER, BRUCE "
//           },
//           {
//             "assigneeNumberText": "6006",
//             "assigneeFullNameText": "CAPP, WILLIAM A"
//           }
//         ];

//         expect(scope['removeJudgeFromPanel']).toBeDefined();
//         scope.removeJudgeFromPanel(1);
//         scope.$digest();


//       });


//       it('it should call removeJudgeFromPanel  ', function () {

//         scope.judgesToPanel = [{
//           "assigneeNumberText": "5922",
//           "assigneeFullNameText": "Saindon, William "
//         }];

//         expect(scope['removeJudgeFromPanel']).toBeDefined();
//         scope.removeJudgeFromPanel(0);
//         scope.$digest();


//       });



//       it('it should call removeAllJudgesFromPanel', function () {

//         scope.judgesToPanel = [{
//             "assigneeNumberText": "5922",
//             "assigneeFullNameText": "Saindon, William "
//           },
//           {
//             "assigneeNumberText": "468",
//             "assigneeFullNameText": "Weatherly, Mitchell "
//           },
//           {
//             "assigneeNumberText": "6003",
//             "assigneeFullNameText": "BARRETT, KEN B"
//           },
//           {
//             "assigneeNumberText": "6005",
//             "assigneeFullNameText": "WIEDER, BRUCE "
//           },
//           {
//             "assigneeNumberText": "6006",
//             "assigneeFullNameText": "CAPP, WILLIAM A"
//           }
//         ];


//         expect(scope['removeAllJudgesFromPanel']).toBeDefined();
//         scope.removeAllJudgesFromPanel();

//       });


//       it('it should call dataSelected  ', function () {

//         expect(scope.dataSelected).toBeDefined();
//         scope.dataSelected(1);

//       });


//       // it('it should call criteriaMatch', function () {

//       //   scope.originalJudgeList = [{
//       //     "assigneeNumberText": "6006",
//       //     "assigneeFullNameText": "CAPP"
//       //   }];

//       //   expect(scope.criteriaMatch).toBeDefined();
//       //   scope.criteriaMatch("CAPP");
//       //   scope.$digest();

//       // });


//       // it('it should call submitPanel   ', function () {

//       //   scope.panelingDate = new Date();
//       //   scope.userInfo = {
//       //     "userId": "testing"
//       //   };
//       //   scope.judgesToPanel = [{
//       //       "assigneeNumberText": "123"
//       //     },
//       //     {
//       //       "assigneeNumberText": "456"
//       //     },
//       //     {
//       //       "assigneeNumberText": "789"
//       //     }
//       //   ];

//       //   expect(scope['submitPanel']).toBeDefined();
//       //   scope.submitPanel();
//       //   // HttpFactoryDeferred.resolve(successResponse);
//       //   // $rootScope.$apply();
//       //   scope.$digest();

//       // });


//       it('it should call copyPA ', function () {
//         var patentAttorney = "Admin";
//         expect(scope['copyPA']).toBeDefined();
//         scope.copyPA(patentAttorney);
//       });

//       // it('it should call submitPanel   ', function () {

//       //   scope.userInfo = {
//       //     "userId": "testing"
//       //   };
//       //   scope.judgesToPanel = [{
//       //       "assigneeNumberText": "123"
//       //     },
//       //     {
//       //       "assigneeNumberText": "456"
//       //     },
//       //     {
//       //       "assigneeNumberText": "789"
//       //     }
//       //   ];
//       //   scope.selectedRow = {
//       //     "priorityIndicator": false
//       //   };

//       //   expect(scope['submitPanel']).toBeDefined();
//       //   scope.submitPanel();
//       //   // HttpFactoryDeferred.resolve(successResponse);
//       //   // $rootScope.$apply();
//       //   scope.$digest();

//       // });

//       // it('it should call openSaveAndCloseDialog ', function () {
//       //   var closeDialog = true;
//       //   expect(scope['openSaveAndCloseDialog']).toBeDefined();
//       //   scope.openSaveAndCloseDialog(closeDialog);

//       //   expect(ngDialog.open).toHaveBeenCalled();

//       //   expect(ngDialog.open.calls.count()).toBe(1);
//       //   var args = ngDialog.open.calls.argsFor(0);
//       //   expect(args).not.toBe(null);
//       //   expect(args.length).toBe(1);

//       //   expect(args[0].controller).toBe('PanelSaveModalController');
//       //   expect(typeof args[0].resolve).toBe('object');
//       //   args[0].resolve.flags();

//       // });

//       // it('it should call openSaveAndCloseDialog ', function () {
//       //   var flags = true;
//       //   expect(scope['openSaveAndCloseDialog']).toBeDefined();
//       //   scope.openSaveAndCloseDialog(flags);


//       //   expect(ngDialog.open).toHaveBeenCalled();

//       //   expect(ngDialog.open.calls.count()).toBe(1);
//       //   var args = ngDialog.open.calls.argsFor(0);
//       //   expect(args).not.toBe(null);
//       //   expect(args.length).toBe(1);

//       //   expect(args[0].controller).toBe('PanelSaveModalController');
//       //   expect(typeof args[0].resolve).toBe('object');
//       //   args[0].resolve.flags();

//       // });

//       // it('it should call createPanelObject ', function () {
//       //   var useTodaysDate = new Date();
//       //   expect(scope['createPanelObject']).toBeDefined();
//       //   scope.createPanelObject(useTodaysDate);
//       // });

//       it('it should call viewNotes ', function () {
//         var row = {
//           entity: {
//             type: "Reconsideration"
//           }
//         }
//         expect(scope['viewNotes']).toBeDefined();
//         scope.viewNotes();


//         expect(ngDialog.open).toHaveBeenCalled();

//         expect(ngDialog.open.calls.count()).toBe(1);
//         var args = ngDialog.open.calls.argsFor(0);
//         expect(args).not.toBe(null);
//         expect(args.length).toBe(1);

//         expect(args[0].controller).toBe('PanelingNotesController');
//         expect(typeof args[0].resolve).toBe('object');
//         args[0].resolve.savedPanelNote();
//         args[0].resolve.numbers();

//       });

//       it('should call listUp', function () {

//         scope.judgesToPanel = [{
//             assigneeNumberText: 123
//           },
//           {
//             assigneeNumberText: 456
//           },
//           {
//             assigneeNumberText: 789
//           }, {
//             assigneeNumberText: 963
//           }, {
//             assigneeNumberText: 852
//           }
//         ];

//         expect(scope.listUp).toBeDefined();
//         scope.listUp(2);
//       });


//       it('should call listDown', function () {

//         scope.judgesToPanel = [{
//             assigneeNumberText: 123
//           },
//           {
//             assigneeNumberText: 456
//           },
//           {
//             assigneeNumberText: 789
//           }, {
//             assigneeNumberText: 963
//           }, {
//             assigneeNumberText: 852
//           }
//         ];

//         expect(scope.listDown).toBeDefined();
//         scope.listDown(2);
//       });



//       it('should call checkPanelHolidays', function () {
//         var successResponse = {
//           data: {
//             isValid: true,
//             judgePanel: [{
//                 assigneeNumberText: 123
//               },
//               {
//                 assigneeNumberText: 456
//               },
//               {
//                 assigneeNumberText: 789
//               }, {
//                 assigneeNumberText: 963
//               }, {
//                 assigneeNumberText: 852
//               }
//             ]
//           }

//         }
//         expect(scope.checkPanelHolidays).toBeDefined();
//         scope.checkPanelHolidays(1559062624);
//         HttpFactoryDeferred.resolve(successResponse);
//         scope.$digest;
//       });


//       // it('should call checkPanelHolidays with no date', function () {
//       //   expect(scope.checkPanelHolidays).toBeDefined();
//       //   scope.checkPanelHolidays();
//       // });

//       // it('it should call checkForChanges ', function () {

//       //   expect(scope['checkForChanges']).toBeDefined();
//       //   scope.checkForChanges();


//       //   expect(ngDialog.open).toHaveBeenCalled();

//       //   expect(ngDialog.open.calls.count()).toBe(1);
//       //   var args = ngDialog.open.calls.argsFor(0);
//       //   expect(args).not.toBe(null);
//       //   expect(args.length).toBe(1);

//       //   expect(args[0].controller).toBe('PanelUnsavedChangesController');
//       //   expect(typeof args[0].resolve).toBe('object');

//       // });

//       // it('it should call checkForChanges ', function () {

//       //   expect(scope['checkForChanges']).toBeDefined();
//       //   scope.checkForChanges();
//       //   expect(ngDialog.closeAll).toHaveBeenCalled();
//       // });

//       // it('it should call cancelCreatePanel ', function () {
//       //   angular.element(document.getElementById('special')).scope() = {
//       //     judgesToPanel: [{
//       //       "assigneeNumberText": "123"
//       //     }]
//       //   }
//       //   expect(scope['cancelCreatePanel']).toBeDefined();
//       //   scope.cancelCreatePanel();
//       // });

//     });
//   });
// })();
