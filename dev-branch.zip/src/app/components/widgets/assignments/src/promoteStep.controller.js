(function () {
  "use strict";

  angular.module('ptabe2e')
    .controller('promoteStepController', function ($scope, ngDialog, $log, $rootScope, SearchHelperService, HttpFactory, CONSTANTS, CommonHelperService, $window) {

      var vm = this;
      var workerNumber, appUserRole, appUserIdentiifier, lockControlNumber;
      $scope.shareAssign = $rootScope.sharedItems;
      var scope = angular.element(document.getElementById('mainTabId')).scope();
      vm.userInfo = scope.vm.userInfo;
      workerNumber = vm.userInfo.appUserInfo[0].loginId;
      appUserRole = vm.userInfo.appUserInfo[0].roleDescription;
      appUserIdentiifier = vm.userInfo.appUserInfo[0].userIdentiifier;
      $scope.row = {
        'serialNumber': $scope.shareAssign[0].serialNumber,
        'appealNumber': $scope.shareAssign[0].appealNumber
      };

      $scope.getPromoteAppeal = function () {
        HttpFactory.getActions(CONSTANTS.URL.GET_PROMOTE + $scope.shareAssign[0].serialNumber)
          .then(function (successResponse) {
              lockControlNumber = successResponse.data.caseDetailsData[0].preAppeal.audit.lockControlNumber;
              $scope.appealAssignment = successResponse.data.caseDetailsData[0].appealAssignment;
              $scope.promoteData = successResponse.data.caseDetailsData[0].preAppealInfo;
              $scope.promoteData.appealForwardingFeePaid = $scope.promoteData.appealForwardingFeePaid ? 'Yes' : 'No';
              $scope.promoteData.respondentBriefFeePaid = $scope.promoteData.respondentBriefFeePaid ? 'Yes' : 'No';
              $scope.promoteData.replyBriefTimelyFiledIndicator = $scope.promoteData.replyBriefTimelyFiledIndicator ? 'Yes' : 'No';
              $scope.promoteData.replyBriefDueDateExpIndicator = $scope.promoteData.replyBriefDueDateExpIndicator ? 'Yes' : 'No';
              $scope.promoteData.petitionsFiledIndicator = $scope.promoteData.petitionsFiledIndicator ? 'Yes' : 'No';
            },
            function (failureResponse) {
              $log.info(failureResponse);
              $scope.appealAssignment = $scope.row;
            });
      };

      $scope.cancelPromote = function () {
        ngDialog.closeAll();
      };

      $scope.warningBeforePromote = function () {
        $scope.appealAssignment.fromWorkQueue = true;
        ngDialog.open({
          template: 'app/importManager/warningBeforePromote.html',
          controller: 'WarningBeforePromoteController',
          width: '40%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            promoteToAppealWarning: function () {
              return $scope.appealAssignment;
            }
          }
        }).closePromise.then(function (promoteToAppealWarning) {
          if (promoteToAppealWarning.value) {
            $scope.showPromoteTypes(promoteToAppealWarning.value);
          }
        }, function () {
          // Cancel button is clicked.
        });
      };

      /* istanbul ignore next */
      $scope.reject = function (appealAssignment) {
        vm.orgignalText = $scope.appealAssignment.notes;
        ngDialog.open({
          template: 'app/importManager/reject.html',
          controller: 'RejectController',
          controllerAs: 'vm',
          width: '42%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            rejectData: function () {
              return $scope.appealAssignment;
            }
          }
        }).closePromise.then(function (appealAssignment) {
          vm.noteToSave = appealAssignment.value.notes;
          angular.element(document.getElementById('rejectNotes')).scope().vm.rejectData.notes = vm.orgignalText;
          if (angular.isDefined(appealAssignment.value.serialNumber)) {
            $scope.rejectImportManagerData(appealAssignment.value);
          }
        }, function () {
          // Cancel from modal
        });
      };

      $scope.rejectImportManagerData = function (rejectData) {
        $scope.isLoading = true;
        var rejectObject = {
          "serialNumber": rejectData.serialNumber,
          "sequenceNumber": rejectData.sequenceNumber,
          "notes": vm.noteToSave,
          "assignmentIdentifier": rejectData.assignmentIdentifier,
          "audit": {
            "createUserIdentifier": rejectData.audit.createUserIdentifier,
            "lastModifiedUserIdentifier": workerNumber,
            "lockControlNumber": lockControlNumber
          }
        };
        /* istanbul ignore next */
        HttpFactory.putActions(CONSTANTS.URL.IMPORT_REJECT, rejectObject)
          .then(function (successResponse) {
            var dataAfterReject = {
              'userIdentifier': workerNumber
            };

            // $scope.importedPreAppealData(dataAfterReject).then(function () {
            CommonHelperService.setToastr("The case " + rejectObject.serialNumber + " was successfully rejected.", "success");
            // });

          }, function (failureResponse) {
            $log.info(failureResponse);
            $scope.isLoading = false;
            CommonHelperService.setToastr(failureResponse.data.message, "error");

          });
      };

      /* istanbul ignore next */
      $scope.showPromoteTypes = function () {
        $scope.appealAssignment.fromWorkQueue = true;

        ngDialog.open({
          template: 'app/importManager/promoteTypesSelect.html',
          controller: 'PromoteTypesSelectController',
          width: '48%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            showPromoteTypesValues: function () {
              return $scope.appealAssignment;
            }
          }
        }).closePromise.then(function (showPromoteTypesValues) {
          if (showPromoteTypesValues.value) {
            $scope.openPromoteToAppeal(showPromoteTypesValues.value);
          }
        }, function () {
          // Cancel from modal
        });
      };

      $scope.openPromoteToAppeal = function (value) {
        $scope.getRole();
        $scope.promoteInfo = $scope.appealAssignment;
        $scope.promoteInfo.ptaAssignment = true;
        $scope.promoteInfo.workerNumber = $window.sessionStorage.getItem("workerNumber");
        $scope.promoteInfo.fromWorkQueue=true;
        // ngDialog.close();
        ngDialog.open({
          template: 'app/importManager/promoteToAppeal.html',
          controller: 'PromoteToAppealController2',
          controllerAs: '$scope',
          width: '60%',

          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            promoteToAppeal: function () {
              return $scope.promoteInfo;
            },
            appUserInfo: function () {
              return appUserRole;
            },
            appUserIdentiifier: function () {
              return appUserIdentiifier;
            }
          }
        }).closePromise.then(function (returnValue) {
          $scope.goToNext(returnValue);
         }, function () {
           // Cancel from modal
         });
      };

      $scope.updatePromteData = function () {

        var data = {
          'userIdentifier': workerNumber
        };

        return $scope.importedPreAppealData(data);
      };

      $scope.importedPreAppealData = function (data, number) {
        $scope.loaded = true;
        $scope.enableloading = true;
        $scope.refreashFaild = false;
        if (data) {
          return;
        }

        return HttpFactory.postActions(CONSTANTS.URL.IMPORTMANAGER, data)
          .then(function (successResponse) {
              $scope.enableloading = false;
              $scope.refreashFaild = false;
              $scope.dateValid = false;
              $scope.refreshDate = new Date();
              //   loadImporedGridData(successResponse);

              $scope.isLoading = false;
              angular.element(document.getElementsByClassName('grid')).scope().isLoading = false;
            },
            /* istanbul ignore next */
            function (failureResponse) {
              $scope.isLoading = false;
              $log.info(failureResponse);
              if (failureResponse.status === 404) {
                $scope.enableloading = false;
                $scope.refreashFaild = false;
                $scope.dateValid = false;
                $scope.refreshDate = new Date();
                CommonHelperService.setToastr("", "clear");
                CommonHelperService.setToastr(CONSTANTS.TOASTER.noCasesQualified, "info", 30000, 30000);
              } else {
                $scope.refreashFaild = true;
                $scope.refreashFailDate = new Date();
                $scope.enableloading = false;
                if (angular.isUndefined($scope.refreshDate) || $scope.refreshDate === null) {
                  $scope.dateValid = true;
                }
                CommonHelperService.setToastr("", "clear");
                CommonHelperService.setToastr(CONSTANTS.TOASTER.failedLoad, "error", 30000, 30000);
              }
            });
      };

      function loadImporedGridData(successResponse) {
        $scope.gridOptions.data = {};
        $scope.gridOptions.columnDefs = [];
        $scope.myData = successResponse.data;

        $scope.tasksAvailable = $scope.myData.tasks;
        $scope.preAppealData = [];
        $scope.appealAssignmentData = [];
        for (var j = 0; j < $scope.myData.caseDetailsData.length; j++) {
          $scope.myData.caseDetailsData[j].preAppealInfo.assignmentData = $scope.myData.caseDetailsData[j].appealAssignment;
          $scope.myData.caseDetailsData[j].preAppealInfo.assignmentData.preAppealLockControlNo = $scope.myData.caseDetailsData[j].preAppeal.audit.lockControlNumber;
          $scope.preAppealData.push($scope.myData.caseDetailsData[j].preAppealInfo);
          $scope.appealAssignmentData.push($scope.myData.caseDetailsData[j].appealAssignment);
        }
        var preAppealColDefs = [];
        var hasFilterFlag = 0;
        processColumnDetails(preAppealColDefs);
        /* istanbul ignore if */
        if (hasFilterFlag > 0) {

          $scope.numberOfFilters = hasFilterFlag;
          var filteredData = SearchHelperService.filterTableForImportManager($scope.myData, preAppealColDefs);
          $scope.gridOptions.data = filteredData;
        } else {
          $scope.numberOfFilters = 0;
          $scope.gridOptions.data = $scope.preAppealData;
        }

        $scope.gridOptions.columnDefs = preAppealColDefs;
        $scope.gridOptions.data = dataProcessPreAppeal($scope.preAppealData, $scope.myData.columnDetails);

        $scope.appealAssignment = $scope.appealAssignmentData;
      }

      function processColumnDetails(preAppealColDefs) {
        for (var i = 0; i < $scope.myData.columnDetails.length; i++) {
          var preAppealCol = {};
          if ($scope.myData.columnDetails[i].typeDefinition === "Date") {
            preAppealCol.type = 'date';
            preAppealCol.cellFilter = 'date:"MM/dd/yyyy"';

          } else {
            preAppealCol.type = 'string';
          }
          preAppealCol.displayName = $scope.myData.columnDetails[i].label;
          preAppealCol.field = $scope.myData.columnDetails[i].name;
          preAppealCol.showItems = $scope.myData.columnDetails[i].selected;
          preAppealCol.leftPin = $scope.myData.columnDetails[i].pinToLeft;
          preAppealCol.rightPin = $scope.myData.columnDetails[i].pinToRight;
          if ($scope.myData.columnDetails[i].cellTemplate != null && $scope.myData.columnDetails[i].cellTemplate !== undefined) {
            preAppealCol.cellTemplate = $scope.myData.columnDetails[i].cellTemplate;
          }
          preAppealCol.width = 140;

          processPreAppealColumns(preAppealCol);
          processManualImportColumn(preAppealCol);

          preAppealColDefs.push(preAppealCol);
        }
      }

      function processManualImportColumn(preAppealCol) {
        if (preAppealCol.field === "promote") {
          preAppealCol.cellClass = manualColorApply;
        }
      }

      function manualColorApply(grid, row, col, rowIndex, colIndex) {
        var color = '';
        var val = grid.getCellValue(row, col);
        if (val === 'Manual Import') {
          color = 'blue';
        }
        return color;
      }

      function processPreAppealColumns(preAppealCol) {
        if (preAppealCol.showItems === true) {
          preAppealCol.visible = true;
        } else {
          preAppealCol.visible = false;
        }

        if (preAppealCol.leftPin === true) {
          preAppealCol.pinnedLeft = true;
        }

        if (preAppealCol.rightPin === true) {
          preAppealCol.pinnedRight = true;
        }

        if (preAppealCol.field === "serialNumber") {
          preAppealCol.enableHiding = false;
          preAppealCol.width = 140;
          preAppealCol.cellTemplate = 'app/importManager/dropDown.html';

        }
        if (preAppealCol.field === "dav") {

          preAppealCol.cellTemplate =

            '<div style="cursor: pointer; padding-top:5px">' +
            '<a href="https://www.uspto.gov/" target="_blank" class="davName" id="{{COL_FIELD}}" >' +
            "<u>{{COL_FIELD}}</u>" + '</a>' +
            '</div>';
        }

      }

      function dataProcessPreAppeal(preAppealData, preAppealColumns) {
        var index = 0;
        preAppealData.forEach(function (row) {
          if (row.manualImportIndicator) {
            vm.selectedRow = index;
          }
          index++;
          preAppealColumns.forEach(function (preAppealColumn) {
            dataProcessBooleanValues(row, preAppealColumn);
            dataProcessDeliveryMode(row, preAppealColumn);
          });

        });
        return preAppealData;
      }

      function dataProcessBooleanValues(row, preAppealColumn) {
        if (preAppealColumn.typeDefinition === 'Boolean') {

          if (row[preAppealColumn.name] === true) {
            row[preAppealColumn.name] = row[preAppealColumn.name] ? 'Yes' : null;
          }
          if (row[preAppealColumn.name] === false) {
            row[preAppealColumn.name] = row[preAppealColumn.name] ? null : 'No';
          }
        }

      }

      function dataProcessDeliveryMode(row, preAppealColumn) {
        if (preAppealColumn.name === 'deliveryMode') {

          if (row[preAppealColumn.name] === "MAIL") {
            row[preAppealColumn.name] = row[preAppealColumn.name] ? 'PAPER' : null;
          }
          if (row[preAppealColumn.name] === "EMAIL") {
            row[preAppealColumn.name] = row[preAppealColumn.name] ? 'ELECTRONIC' : null;
          }
        }
      }

      $scope.getRole = function () {
        HttpFactory.getActions(CONSTANTS.URL.ROLETYPE)
          .then(function (successResponse) {
              $scope.myRole = successResponse.data;
            },
            function (failureResponse) {
              $log.info(failureResponse);
            });
      };


    });

})();
