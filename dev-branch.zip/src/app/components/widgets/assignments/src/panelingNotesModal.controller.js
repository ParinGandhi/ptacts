(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('PanelingNotesController', function (ngDialog, savedPanelNote, HttpFactory, numbers) {

      var vm = this;
      vm.panelNotes = angular.copy(savedPanelNote);
      vm.numbers = numbers;

      /* istanbul ignore next */
      vm.getNotesHistory = function () {
        HttpFactory.getActions('/appeal-judge-panels/note-history?applicationNumber=' + vm.numbers.applicationNumber + '&appealNumber=' + vm.numbers.appealNumber)
          .then(function (successResponse) {
            vm.notesHistory = successResponse.data;
          }, function () {
            // intentional
          });
      };

      /* istanbul ignore next */
      vm.getNotesHistory();

      vm.checksave = function () {
        if (vm.panelNotes.length > 0) {
          vm.disableSubmitPanel = false;
        } else {
          vm.disableSubmitPanel = true;
        }
      };

      vm.cancelPanelNotesModal = function () {
        vm.panelNotes = angular.copy(savedPanelNote);
        ngDialog.close(lastDialog());
      };

      vm.savePanelNote = function () {
        ngDialog.close(lastDialog(), vm.panelNotes);
      };

      function lastDialog() {
        var openDialogs = ngDialog.getOpenDialogs();
        return openDialogs[openDialogs.length - 1];
      }

    });
})();
