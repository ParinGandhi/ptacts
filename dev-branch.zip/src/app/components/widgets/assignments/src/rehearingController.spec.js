(function () {
    'use strict';
  
    describe('rehearingController', function () {
  
      beforeEach(module('ptabe2e'));
      var $controller;
      var vm = this;
      var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open']);
      var controller, scope, $rootScope;
      var timeout;
      var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;
  
      beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
        $q = _$q_;
        $controller = _$controller_;
        scope = _$rootScope_.$new();
        $rootScope = _$rootScope_;
        HttpFactoryDeferred = _$q_.defer();
        spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
  
        $rootScope.sharedItems = {

            "isUpdateRehearing": true,
              "decisionData": [{
                  "completionCode": "COMPLETE",
                  "rank": 1
                },
                {
                  "completionCode": "CANCEL",
                  "rank": 2
                }
              ]
            }

  
        controller = $controller('rehearingController', {
          $scope: scope,
          ngDialog: ngDialog,
          $rootScope: _$rootScope_,
          HttpFactory: HttpFactory
  
        });
      }));
  
      describe('rehearingController ', function () {
  
        it('should call submitRehearing ', function () {
            controller.assignmentObject = [{
                "completionCode": "COMPLETE"
            }]
          expect(controller.submitRehearing).toBeDefined();
          controller.submitRehearing();
        });
        it('should call cancelHearing', function () {
            controller.assignmentObject = [{
                "completionCode": "CANCEL",
                "audit":{
                    "createUserIdentifier":"pgandhi"
                }
            }]
            expect(controller.cancelHearing).toBeDefined();
            controller.cancelHearing();
          });

          it('should call submitRehearing', function () {
            controller.assignmentObject = [{
                "assignmentType": "Mail decision",
                "audit":{
                    "createUserIdentifier":"pgandhi"
                }
            }]
            expect(controller.postRehearing).toBeDefined();
            controller.postRehearing();
          });

          it('should call clearRequest', function () {
            expect(controller.clearRequest).toBeDefined();
            controller.clearRequest();
          });

          it('should call cancelEditingRequest', function () {
            expect(controller.cancelEditingRequest).toBeDefined();
            controller.cancelEditingRequest();
          });

          it('should call setSelectedRequester', function () {
            expect(controller.setSelectedRequester).toBeDefined();
            controller.setSelectedRequester();
          });

          it('should call setSelectedRequest', function () {
            expect(controller.setSelectedRequest).toBeDefined();
            controller.setSelectedRequest();
          });

          it('should call checkFiledDate', function () {
            expect(controller.checkFiledDate).toBeDefined();
            controller.checkFiledDate();
          });

          it('should call setEditedRequester', function () {
              var value = true;
            expect(controller.setEditedRequester).toBeDefined();
            controller.setEditedRequester(value);
          });


          it('should call setEditedRequest', function () {
              var value = true;
            expect(controller.setEditedRequest).toBeDefined();
            controller.setEditedRequest(value);
          });

          it('should call editRequest', function () {
              var index=0, item = {
                requester:"pgandhi",
                request:"yes"
              }
            expect(controller.editRequest).toBeDefined();
            controller.editRequest(index, item);
          });

          it('should call checkRequest', function () {
            expect(controller.checkRequest).toBeDefined();
            controller.checkRequest();
          });

          it('should call applyRequest', function () {
            expect(controller.applyRequest).toBeDefined();
            controller.applyRequest();
          });

          it('should call addRequest', function () {
            expect(controller.addRequest).toBeDefined();
            controller.addRequest();
          });

          it('should call dateConvert', function () {
              var recievedDate = null;
            expect(controller.dateConvert).toBeDefined();
            controller.dateConvert(recievedDate);
          });

          it('should call deleteRequest', function () {
            var index = 1;
            expect(controller.deleteRequest).toBeDefined();
            controller.deleteRequest(index);
          });

          it('should call getRequester', function () {
            expect(controller.getRequester).toBeDefined();
            controller.getRequester();
          });

          it('should call getRequest', function () {
            expect(controller.getRequest).toBeDefined();
            controller.getRequest();
          });

          it('should call openRehearingHistory', function () {
            scope.reHearingInformation = {
 
                "applicationNumber": "95000042",
                "appealNumber": "2019002621"
              }
              controller.assignmentObject = [{
                "completionCode": "COMPLETE",             
                "applicationNumber": "95000042",
                "appealNumber": "2019002621"
            }]
            expect(controller.openRehearingHistory).toBeDefined();
            controller.openRehearingHistory();
          });

      });
    });
  })();
  