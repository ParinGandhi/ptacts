(function () {
  'use strict';

  describe('PanelSaveModalController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var successResponse, failureResponse;
    var $httpBackend, $q, spy, HttpFactoryDeferred, $CommonHelperService;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'closeAll', 'getOpenDialogs', 'close']);
    var flags, completionCode, panelToCreate = {
      panelAssignment: [{

      }]
    };
    var controller, scope, $rootScope;
    var timeout;

    beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_, _$httpBackend_, _$q_, HttpFactory, _CommonHelperService_) {
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      timeout = _$timeout_;
      $CommonHelperService = _CommonHelperService_;
      $httpBackend = _$httpBackend_;

      HttpFactoryDeferred = _$q_.defer();
      // spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn($CommonHelperService, 'setToastr').and.callFake(function () {
        return "toastr";
      });

      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback) {
            callback({
              value: 1
            });
          }
        },
        then: function (callback2) {
          callback2({
            value: 2
          });
        }
      });

      flags = {
        vm: {
          newTitle: {
            userWorkspaceName: "test",
            structure: "4-4"
          }
        },
        "setCancel": true,
        "content": true,
        "widgetArrange": true
      }

      panelToCreate = {
        judgePanel: {
          panelDate: false
        },
        panelAssignment: {
          completionCode: 'COMPLETE',
          completionDate: new Date()
        }
      };

      controller = $controller('PanelSaveModalController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        flags: flags,
        completionCode: completionCode,
        panelToCreate: panelToCreate
      });
    }));

    describe('PanelSaveModalController ', function () {


      it('it should call closeCurrentDialog ', function () {
        expect(controller['closeCurrentDialog']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.closeCurrentDialog();
      });

      it('it should call saveChanges ', function () {
        expect(controller['saveChanges']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.saveChanges();
      });

      it('it should call saveAndSubmit ', function () {
        expect(controller['saveAndSubmit']).toBeDefined();
        controller.saveAndSubmit();
        var args = ngDialog.open.calls.argsFor(0);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        expect(typeof args[0].resolve).toBe('object');
        // expect(typeof args[1].resolve).toBe('object');
        args[0].resolve.createPanelData();
        args[0].resolve.flags();

      });

      it('should call submitPanel with successResponse', function () {
        successResponse = "Success";
        expect(controller.submitPanel).toBeDefined();
        controller.submitPanel();
        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();
      });


      it('should call submitPanel with failureResponse', function () {
        failureResponse = "Failure";
        expect(controller.submitPanel).toBeDefined();
        controller.submitPanel();
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });

    });
  });
})();
