(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .controller('rehearingController', function (ngDialog, $scope, $rootScope, CONSTANTS, HttpFactory, $window, toastr, $timeout) {
      var vm = this;
      var scope = angular.element(document.getElementById('mainTabId')).scope();
      if (scope) {
        vm.userInfo = scope.vm.userInfo;
      } else {
        vm.userInfo = {
          displayName: $window.sessionStorage.getItem("workerNumber"),
          userId: $window.sessionStorage.getItem("workerNumber")
        };
      }
      vm.addNewRow = false;
      vm.editMode = false;
      vm.requesterNoNull = false;
      vm.requestNoNull = false;
      vm.readyToSave = true;
      vm.assignmentObject = $rootScope.sharedItems;
      vm.updateRehearingRequest = vm.assignmentObject.isUpdateRehearing;
      if (vm.updateRehearingRequest) {
        vm.existingItems = vm.assignmentObject.decisionData[0];
        vm.addNewRow = true;
      }
      vm.submitRehearing = function () {
        vm.notDiscard = true;
        vm.assignmentObject[0].completionCode = "COMPLETE";
        vm.postRehearing();
      };
      vm.cancelHearing = function () {
        vm.assignmentObject[0].completionCode = "CANCEL";
        vm.notDiscard = false;
        // vm.postRehearing();
        vm.deleteAssignment();
      };

      /* istanbul ignore next*/
      vm.postRehearing = function (submitType) {
        vm.appealDecisionObj = [];
        if (vm.items.length > 0) {
          angular.forEach(vm.items, function (item) {
            if (item.ptabReceivedDate === "" || item.ptabReceivedDate === " ") {
              var ptabDate = null;
            } else {
              ptabDate = item.ptabReceivedDate;
            }
            var obj = {
              serialNumber: vm.assignmentObject[0].serialNumber,
              appealNumber: vm.assignmentObject[0].appealNumber,
              adReconsiderSequenceNumber: vm.assignmentObject[0].sequenceNumber,
              audit: {
                lastModifiedTimestamp: new Date().getTime(),
                lastModifiedUserIdentifier: vm.userInfo.userId
              },
              dueDateAssignedDate: ptabDate,
              requestDate: item.filedDate,
              requestorCode: item.requester.valueText,
              rehearingRequestInputCode: item.request.valueText
            };
            vm.appealDecisionObj.push(obj);
          });
        } else {
          if (vm.notDiscard) {
            toastr.warning(CONSTANTS.TOASTER.rehearing, {
              iconClass: 'toast-warning'
            });
            return;
          }
        }

        $scope.updateAssignmntdata = {
          "assignmentType": vm.assignmentObject[0].assignmentType,
          "assignee": vm.assignmentObject[0].assignee,
          "serialNumber": vm.assignmentObject[0].serialNumber,
          "title": vm.assignmentObject[0].title,
          "description": vm.assignmentObject[0].description,
          "dueDate": vm.assignmentObject[0].dueDate,
          "completionDate": new Date().getTime(),
          "completionCode": vm.assignmentObject[0].completionCode,
          "caseType": vm.assignmentObject[0].caseType,
          "appealNumber": vm.assignmentObject[0].appealNumber,
          "sequenceNumber": vm.assignmentObject[0].sequenceNumber,
          "notes": vm.assignmentObject[0].noteText,
          "priorityIndicator": (vm.assignmentObject[0].priorityIndicator) ? 'Y' : 'N',
          "assignmentIdentifier": vm.assignmentObject[0].assignmentIdentifier,
          "assignor": vm.assignmentObject[0].assignor,
          "activeIndicator": vm.assignmentObject[0].activeIndicator,
          "audit": {
            "createUserIdentifier": vm.assignmentObject[0].audit.createUserIdentifier,
            "lastModifiedUserIdentifier": vm.userInfo.userId,
            "lockControlNumber": vm.assignmentObject[0].audit.lockControlNumber,
            "createTimestamp": vm.assignmentObject[0].audit.assignmentCreateTs,
            "lastModifiedTimestamp": new Date().getTime()
          }
        };
        if (!vm.notDiscard) {
          vm.appealDecisionObj = [];
        }
        if (vm.appealDecisionObj.length > 0) {
          $scope.updateAssignmntdata.transactionDate = vm.appealDecisionObj[vm.appealDecisionObj.length - 1].requestDate ? new Date(vm.appealDecisionObj[vm.appealDecisionObj.length - 1].requestDate).getTime() : new Date();
        }

        var dataObject = {
          decisionAssignment: $scope.updateAssignmntdata,
          decisions: vm.appealDecisionObj
        };

        HttpFactory.postActions(CONSTANTS.URL.APPEAL_DECISION, dataObject)
          .then(function (successResponse) {
            if (vm.notDiscard) {
              toastr.error(CONSTANTS.TOASTER.successRehearing, {
                iconClass: 'toast-success'
              });

            } else {

              toastr.error(CONSTANTS.TOASTER.closeRehearing, {
                iconClass: 'toast-success'
              });

            }
            ngDialog.closeAll();
          }, function (failureResponse) {
            toastr.warning(failureResponse.data.message, {
              iconClass: 'toast-warning'
            });
          });
      };

      vm.deleteAssignment = function () {
        HttpFactory.deleteActions('/assignments/' + vm.assignmentObject[0].assignmentIdentifier + '/' + vm.assignmentObject[0].audit.createUserIdentifier)
          .then(function (successResponse) {
            ngDialog.closeAll();
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };

      vm.items = [];
      vm.requestList = ["Request"];
      vm.clearRequest = function () {
        vm.filedDateNoNull = false;
        vm.requesterNoNull = false;
        vm.requester = "";
        vm.rehearingFiledDate = "";
        vm.ptabReceivedDate = "";
        vm.addNewRow = false;
        if (!vm.updateRehearingRequest) {
          if (vm.items.length === 0) {
            if (vm.assignmentObject[0].serialNumber.substring(0, 2) === "95") {
              vm.request = vm.requestList[0];
            }

          }
        }

      };

      vm.cancelEditingRequest = function () {
        vm.filedDateNoNull = false;
        vm.selectedIndex = vm.items.length + 2;
      };
      vm.setSelectedRequester = function (requester) {
        if (requester !== undefined && requester !== "") {
          vm.requesterNoNull = false;
        }
        vm.requester = requester;
      };
      vm.setSelectedRequest = function (value) {
        if (value !== undefined && value !== "") {
          vm.requestNoNull = false;
        }
        vm.request = value;
      };
      vm.checkFiledDate = function () {
        $timeout(function () {
          if (angular.isDefined(vm.rehearingFiledDate) && vm.rehearingFiledDate != null) {
            vm.filedDateNoNull = false;
          }
        }, 200);

      };
      vm.setEditedRequester = function (value) {
        vm.editedRequester = value;
      };
      vm.setEditedRequest = function (value) {
        vm.editedRequest = value;
      };

      /* istanbul ignore next*/
      vm.editRequest = function (index, item) {
        vm.selectedIndex = index;

        vm.filedDateNoNull = false;
        vm.toBeEditedRequester = item.requester;
        vm.editedRequester = item.requester;
        vm.toBeEditedRequest = item.request;
        vm.editedRequest = item.request;
        vm.editedRehearingFiledDate = item.filedDate;
        vm.editedPtabReceivedDate = item.ptabReceivedDate;
        vm.toBeEditedFiledDate = item.filedDate;
        if (!vm.updateRehearingRequest) {
          if (vm.items.length === 1) {
            if (vm.assignmentObject[0].serialNumber.substring(0, 2) === "95") {
              vm.request = vm.tempSingleRequest[0];
              vm.requestList = [];
              vm.requestList.push(vm.tempSingleRequest[0]);
            }

          }
        }
      };

      /* istanbul ignore next*/
      vm.checkRequest = function () {
        if (!vm.updateRehearingRequest) {
          if (vm.items.length > 0) {
            if (vm.assignmentObject[0].serialNumber.substring(0, 2) === "95") {
              vm.requestList = vm.copyOfRequestList;
            }

          }
        }
        vm.selectedIndex = vm.items.length + 2;

      };

      /* istanbul ignore next*/
      vm.applyRequest = function (index) {
        if (vm.editedPtabReceivedDate !== null && vm.editedPtabReceivedDate !== "" && angular.isDefined(vm.editedPtabReceivedDate)) {
          var dateCheck = new Date(vm.editedPtabReceivedDate).getTime();
        } else {
          dateCheck = "";
        }
        vm.readyToSave = true;
        if (angular.isUndefined(vm.editedRehearingFiledDate) || vm.editedRehearingFiledDate === null || vm.editedRehearingFiledDate === "") {
          vm.filedDateNoNull = true;
          vm.readyToSave = false;
        } else {
          vm.filedDateNoNull = false;
        }
        if (!vm.readyToSave) {
          return;
        }
        var obj = {
          requester: vm.editedRequester,
          request: vm.editedRequest,
          filedDate: new Date(vm.editedRehearingFiledDate).getTime(),
          ptabReceivedDate: dateCheck
        };
        vm.items[index] = obj;
        vm.selectedIndex = vm.items.length + 2;
      };

      /* istanbul ignore next*/
      vm.addRequest = function () {
        vm.selectedIndex = vm.items.length + 2;
        if (vm.ptabReceivedDate !== null && vm.ptabReceivedDate !== "" && angular.isDefined(vm.ptabReceivedDate)) {
          var dateCheckR = new Date(vm.ptabReceivedDate).getTime();
        } else {
          dateCheckR = "";
        }
        vm.readyToSave = true;
        if (angular.isUndefined(vm.requester) || vm.requester === "") {
          vm.requesterNoNull = true;
          vm.readyToSave = false;

        }
        if (angular.isUndefined(vm.request) || vm.request === "") {
          vm.requestNoNull = true;
          vm.readyToSave = false;
        }
        if (angular.isUndefined(vm.rehearingFiledDate) || vm.rehearingFiledDate === null || vm.rehearingFiledDate === "") {
          vm.filedDateNoNull = true;
          vm.readyToSave = false;
        }
        if (!vm.readyToSave) {
          return;
        }

        var obj = {
          requester: vm.requester,
          request: vm.request,
          filedDate: new Date(vm.rehearingFiledDate).getTime(),
          ptabReceivedDate: dateCheckR
        };

        vm.items.push(obj);
        if (!vm.updateRehearingRequest) {
          if (vm.items.length > 0) {
            if (vm.assignmentObject[0].serialNumber.substring(0, 2) === "95") {
              vm.requestList = vm.copyOfRequestList;
            }

          }
        }
        vm.addNewRow = false;
        vm.requester = "";
        vm.rehearingFiledDate = null;
        vm.ptabReceivedDate = null;
      };
      vm.dateConvert = function (recievedDate) {
        if (recievedDate != null) {
          return new Date(recievedDate).toLocaleDateString();
        } else {
          return null;
        }
      };
      vm.deleteRequest = function (index) {
        vm.items.splice(index, 1);
      };

      /* istanbul ignore next*/
      vm.getRequester = function () {
        HttpFactory.getActions("/reference-data/code-reference-types?typeCode=REQUESTOR").then(
          function (successResponse) {
            vm.requesterList = successResponse.data;
            vm.tempRequester = angular.copy(vm.requesterList);
            vm.requesterList = [];
            angular.forEach(vm.tempRequester, function (requester) {
              //checking for interparte
              if (vm.assignmentObject[0].serialNumber.substring(0, 2) === "95") {
                if (requester.valueText !== 'ER') {

                  vm.requesterList.push(requester);
                  vm.tempSingleRequest = angular.copy(vm.requesterList);
                }
              } else {
                if (requester.valueText !== 'TPR') {
                  vm.requesterList.push(requester);
                }
              }
            });
          }
        );
      };

      /* istanbul ignore next*/
      vm.getRequest = function () {
        HttpFactory.getActions("/reference-data/code-reference-types?typeCode=REQUEST").then(
          function (successResponse) {
            vm.requestList = successResponse.data;
            angular.forEach(vm.requestList, function (request) {
              if (vm.assignmentObject[0].serialNumber.substring(0, 2) === "95") {
                vm.copyOfRequestList = angular.copy(vm.requestList);
                if (!vm.updateRehearingRequest) {
                  if (request.descriptionText === 'Request') {

                    vm.requestList = [];
                    vm.requestList.push(request);
                    vm.request = vm.requestList[0];
                    vm.tempSingleRequest = angular.copy(vm.requestList);
                  }

                } else {
                  vm.request = vm.requestList[1];
                }


              } else {
                if (request.descriptionText === 'Request') {
                  vm.request = request;
                  vm.editedRequest = request;
                  vm.requestList = [];
                  vm.requestList.push(request);

                }
              }

            });

          }
        );

      };
      vm.getRequester();
      vm.getRequest();

      vm.openRehearingHistory = function () {
        $window.open("#/caseViewer/" + vm.assignmentObject[0].serialNumber + "/" + vm.assignmentObject[0].appealNumber + "/auditTrail-decisionHistoryGrid");
        document.getElementById('auditTrail').className = 'active';
      };
    });
})();
