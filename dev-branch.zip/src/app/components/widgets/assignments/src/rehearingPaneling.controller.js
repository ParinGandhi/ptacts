(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .controller('RehearingPanelingController', function ($scope, $rootScope, toastr, CONSTANTS, HttpFactory, $log, CommonHelperService, ngDialog, $window, $timeout) {
      $scope.selectedRow = $rootScope.sharedItems[0];
      $rootScope.panelLockControlNumber = $scope.selectedRow.audit.lockControlNumber;
      $log.debug("Selected row:");
      $log.debug($scope.selectedRow);
      $scope.userInfo = $rootScope.userInfo;
      if (!$scope.userInfo) {
        $scope.userInfo = {
          "userId": $window.sessionStorage.getItem("workerNumber")
        };
      }
      $scope.extraData = true;
      $scope.disableMove = true;
      $scope.disableSubmitPanel = true;
      $scope.judgesToPanel = [];
      $scope.originalJudgesToPanel = [];
      $scope.judgeList = [];
      $scope.myData = [];
      $scope.noAttorney = true;
      $scope.selectedDiscipline = "";
      $scope.selectedSection = "";
      $rootScope.panelToBeDeleted = [];
      $scope.rehearingPanelDate;
      $scope.rehearingDecisionDueDate = "";
      $scope.rehearingPanelChanged = false;

      $scope.getDisciplineList = function () {
        HttpFactory.getActions(CONSTANTS.URL.GET_DISCIPLINES)
          .then(function (successResponse) {
            $scope.disciplineList = successResponse.data;
          }, function () {
            toastr.error(CONSTANTS.TOASTER.disciplines, {
              iconClass: 'toast-danger'
            });
          });
      };

      $scope.getDisciplineList();

      /** This function will retrieve the list of sections */
      $scope.getSectionList = function () {
        HttpFactory.getActions(CONSTANTS.URL.GET_SECTIONS)
          .then(function (successResponse) {
            $scope.sectionList = successResponse.data;
            $log.debug("Section list:");
            $log.debug($scope.sectionList);
          }, function () {
            toastr.error(CONSTANTS.TOASTER.selections, {
              iconClass: 'toast-danger'
            });
          });
      };

      $scope.getSectionList();

      /** This function will retrieve a list of judges. On initial load, or if 'all' is selected from dropdown,
       * all judges will be displayed. It will also remove the judges that are on the panel from the judge list
       */
      $scope.getJudgeList = function (params) {
        var url = setUrl(params);
        HttpFactory.getActions(url)
          .then(function (successResponse) {
            $scope.judgeList = successResponse.data;
            for (var i = 0; i < $scope.judgeList.length; i++) {
              angular.forEach($scope.judgesToPanel, function (paneledJudge) {
                if (paneledJudge.assigneeNumberText === $scope.judgeList[i].assigneeNumberText) {
                  $scope.judgeList.splice(i, 1);
                }
              });
            }
            $scope.originalJudgeList = angular.copy(successResponse.data);
            $log.debug("Judge list %o", $scope.judgeList);

          }, function () {
            toastr.error(CONSTANTS.TOASTER.judges, {
              iconClass: 'toast-danger'
            });
            $scope.judgeList = [];
          });
      };

      $scope.getJudgeList('initialLoad');

      /* istanbul ignore next */
      function setUrl(params) {
        // Get all judges on initial load or if "Select a discipline/section" is selected or "all" is selected for both
        if (params === "initialLoad" || ($scope.selectedDiscipline === "" &&
            $scope.selectedSection === "") ||
          ($scope.selectedDiscipline === "all" &&
            $scope.selectedSection === "all")) {
          return CONSTANTS.URL.GET_ALL_JUDGES;
        }
        // If both discipline and section are selected
        if (angular.isDefined($scope.selectedDiscipline) && $scope.selectedDiscipline !== "" && angular.isDefined($scope.selectedSection) && $scope.selectedSection !== "") {
          // If selected discipline is set to all, then all judges for the selected section are returned
          if ($scope.selectedDiscipline === "all") {
            return CONSTANTS.URL.GET_JUDGES + "sectionText=" + $scope.selectedSection;
            // If selected section is set to all, then all judges for the selected discipline are returned
          } else if ($scope.selectedSection === "all") {
            return CONSTANTS.URL.GET_JUDGES + "disciplineCode=" + $scope.selectedDiscipline;
            // Return the combined judge list
          } else {
            return CONSTANTS.URL.GET_JUDGES + "sectionText=" + $scope.selectedSection + "&disciplineCode=" + $scope.selectedDiscipline;
          }
          // Return list of judges based on selected discipline
        } else if (angular.isDefined($scope.selectedDiscipline) && $scope.selectedDiscipline !== "" && $scope.selectedDiscipline !== "all") {
          return CONSTANTS.URL.GET_JUDGES + "disciplineCode=" + $scope.selectedDiscipline;
          // Return list of judges based on selected section
        } else if (angular.isDefined($scope.selectedSection) && $scope.selectedSection !== "" && $scope.selectedSection !== "all") {
          return CONSTANTS.URL.GET_JUDGES + "sectionText=" + $scope.selectedSection;
          // Return all judges if either discipline or section is set to all and the other is set to "Select a ...."
        } else if (($scope.selectedDiscipline === "all" && $scope.selectedSection === "") || ($scope.selectedDiscipline === "" && $scope.selectedSection === "all")) {
          return CONSTANTS.URL.GET_ALL_JUDGES;
        }
      }


      /** This function will retrieve a list of judges that have already been added to the panel for the given appeal number.
       * It will iterate through the list and display only active judges
       */
      $scope.getSelectedJudgeList = function () {
        HttpFactory.getActions(CONSTANTS.URL.GET_SELECTED_JUDGES + $scope.selectedRow.appealNumber + "&applicationNumber=" + $scope.selectedRow.serialNumber)
          .then(function (successResponse) {
            var tempList = [];
            var previousPanelTempList = [];
            $scope.originalPanel = [];
            $scope.previousPanel = [];
            var latestPanel = 0;

            /** Iterate through judge panel. If the panel rank is 0 (Patent Attorney), then set that at the selected attorney.
             *  Else add the judges in the order of their rank
             */
            window.sessionStorage.setItem("reconsiderSeqNo", successResponse.data.judgePanel[0].reconsiderSequenceNumber);
            for (var i = 0; i < successResponse.data.judgePanel[latestPanel].panelToBeCreated.length; i++) {
              if (successResponse.data.judgePanel[latestPanel].panelToBeCreated[i].panelRank === 0) {
                $scope.selectedAttorney = successResponse.data.judgePanel[latestPanel].panelToBeCreated[i].identifier;
                $rootScope.selectedAttorney = successResponse.data.judgePanel[latestPanel].panelToBeCreated[i].identifier;
                $scope.previousPA = successResponse.data.judgePanel[latestPanel].panelToBeCreated[i];
              } else {
                var panel;
                if (successResponse.data.judgePanel[latestPanel].panelToBeCreated[i].activeIndicator === "P") {
                  panel = {
                    panelMember: successResponse.data.judgePanel[latestPanel].panelToBeCreated[i].panelMember,
                    panelName: successResponse.data.judgePanel[latestPanel].panelToBeCreated[i].panelName,
                    assigneeNumberText: successResponse.data.judgePanel[latestPanel].panelToBeCreated[i].identifier
                  };
                  tempList[successResponse.data.judgePanel[latestPanel].panelToBeCreated[i].panelRank] = panel;
                  window.sessionStorage.setItem("seqNo", successResponse.data.judgePanel[latestPanel].panelToBeCreated[i].panelSequenceNumber);
                } else {
                  panel = {
                    panelMember: successResponse.data.judgePanel[latestPanel].panelToBeCreated[i].panelMember,
                    panelName: successResponse.data.judgePanel[latestPanel].panelToBeCreated[i].panelName,
                    assigneeNumberText: successResponse.data.judgePanel[latestPanel].panelToBeCreated[i].identifier
                  };
                  previousPanelTempList[successResponse.data.judgePanel[latestPanel].panelToBeCreated[i].panelRank] = panel;
                }
              }

            }
            $scope.originalPanel = tempList.filter(function (el) {
              return el != null;
            });

            $scope.previousPanel = previousPanelTempList.filter(function (el) {
              return el != null;
            });

            if ($scope.previousPA) {
              $scope.previousPanel.push($scope.previousPA);
            }



            $log.debug("Temp list of initial judges: %o", tempList);
            $scope.judgesToPanel = angular.copy($scope.originalPanel);
            $scope.originalJudgesToPanel = angular.copy($scope.originalPanel);
            validateSubmit();
          }, function () {
            // intentional
          });
      };

      $scope.getSelectedJudgeList();


      /** This function will retrieve a list of attorneys based on the first selected judge in the panel (APJ1) */
      /* istanbul ignore next */
      $scope.getAttorneyList = function () {
        if ($scope.judgesToPanel.length > 0) {
          HttpFactory.getActions(CONSTANTS.URL.GET_ATTORNEY_LIST + $scope.judgesToPanel[0].assigneeNumberText)
            .then(function (successResponse) {
              var assignedList = successResponse.data.assignedAttorneyList;
              assignedList.push({
                assigneeNumberText: "divider",
                assigneeFullNameText: "---------------"
              });
              $scope.attorneyList = assignedList.concat(successResponse.data.nonAssignedAttorneyList);

              $scope.noAttorney = false;
              if (!$scope.selectedAttorney) {
                $scope.selectedAttorney = 'default';
              }
            }, function (failureResponse) {
              $scope.attorneyList = [];
              $log.debug(failureResponse);
              $scope.selectedAttorney = 'default';
              $scope.noAttorney = true;
            });
        }
      };


      $scope.getRehearingRequestDate = function () {
        HttpFactory.getActions('/decision-history?appealNumber=' + $scope.selectedRow.appealNumber + '&serialNumber=' + $scope.selectedRow.serialNumber)
          .then(function (successResponse) {
            $scope.rehearingRequestDate = successResponse.data.decisions[0].requestDate;


          }, function (failureResponse) {
            // intentional
          });
      };

      $scope.getRehearingRequestDate();


      $scope.getDecisionDueDate = function () {
        $timeout(function () {
          $scope.calculateDecisionDueDate();
        }, 200);
      };

      $scope.calculateDecisionDueDate = function () {
        var rehearingPanelDate;
        if (angular.isNumber($scope.rehearingPanelDate)) {
          rehearingPanelDate = $scope.rehearingPanelDate;
        } else {
          rehearingPanelDate = $scope.rehearingPanelDate.getTime();
        }
        var referenceDataQuery = {
          "assignmentType": $scope.selectedRow.assignmentType,
          "date": rehearingPanelDate,
          "caseNumber": $scope.selectedRow.appealNumber
        };

        HttpFactory.postActions("/reference-data/business-date", referenceDataQuery)
          .then(function (successResponse) {
            $scope.rehearingDecisionDueDate = new Date(successResponse.data).getTime();

          }, function (failureResponse) {
            // intentional
          });
      };



      /** This function will move the selected judge in the panel up */
      $scope.listUp = function (itemIndex) {
        $scope.rehearingPanelChanged = true;
        $scope.judgesToPanel = CommonHelperService.moveListItem($scope.judgesToPanel, itemIndex, itemIndex - 1);
        $scope.getAttorneyList();
      };

      /** This function will move the selected judge in the panel down */
      $scope.listDown = function (itemIndex) {
        $scope.rehearingPanelChanged = true;
        $scope.judgesToPanel = CommonHelperService.moveListItem($scope.judgesToPanel, itemIndex, itemIndex + 1);
        $scope.getAttorneyList();
      };


      /** This function will move the judges from the judge list to the panel */
      $scope.moveJudgeToPanel = function () {
        angular.forEach($scope.judgeIndex, function (column) {
          $scope.addJudge = true;
          var judge;
          if ($scope.judgesToPanel.length === 0) {
            judge = {
              "assigneeNumberText": $scope.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIX)].assigneeNumberText,
              "panelMember": "APJ" + ($scope.judgesToPanel.length + 1),
              "panelName": $scope.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIX)].assigneeFullNameText
            };
            $scope.judgesToPanel.push(judge);
            $scope.addJudge = false;
          } else {
            for (var i = 0; i < $scope.judgesToPanel.length; i++) {

              if ($scope.judgesToPanel[i].assigneeNumberText === $scope.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIX)].assigneeNumberText) {
                toastr.error($scope.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIXn)].assigneeFullNameText + " has already been added to the panel", {
                  iconClass: 'toast-danger'
                });
                $scope.addJudge = false;
                break;
              }
            }
          }
          if ($scope.addJudge) {
            judge = {
              "assigneeNumberText": $scope.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIX)].assigneeNumberText,
              "panelMember": "APJ" + ($scope.judgesToPanel.length + 1),
              "panelName": $scope.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIX)].assigneeFullNameText
            };
            $scope.judgesToPanel.push(judge);
          }
        });

        function sortNumber(a, b) {
          return b - a;
        }

        $scope.judgeIndex.sort(sortNumber);

        angular.forEach($scope.judgeIndex, function (column) {
          $scope.judgeList.splice(parseInt(column, CONSTANTS.GLOBAL.RADIX), 1);
        });

        $scope.clickedColumn = [];
        $scope.rehearingPanelChanged = true;

        $scope.disableMove = true;
        $rootScope.judgesToPanel = angular.copy($scope.judgesToPanel);
        validateSubmit();
      };

      /** This function will remove the judge from the panel */
      $scope.removeJudgeFromPanel = function (index) {
        var toDelete = {
          "identifier": $scope.judgesToPanel[index].assigneeNumberText,
          "panelRank": index + 1
        };
        $rootScope.panelToBeDeleted.push(toDelete);
        $scope.judgesToPanel.splice(index, 1);
        $rootScope.judgesToPanel = angular.copy($scope.judgesToPanel);
        $scope.getAttorneyList();
        validateSubmit();
        if ($scope.judgesToPanel.length === 0) {
          $scope.panelingDate = '';
          $scope.noAttorney = true;
        }
        if (index === 0) {
          var paToDelete = {
            "identifier": $scope.selectedAttorney,
            "panelRank": index
          };
          $rootScope.panelToBeDeleted.push(paToDelete);
          $scope.selectedAttorney = 'default';
          $rootScope.selectedAttorney = 'default';
        }
        $scope.rehearingPanelChanged = true;
      };

      /** This function will remove all the judges from the panel */
      $scope.removeAllJudgesFromPanel = function () {
        for (var i = 0; i < $scope.judgesToPanel.length; i++) {
          var remove = {};
          remove.identifier = $scope.judgesToPanel[i].assigneeNumberText;
          remove.panelRank = i + 1;
          $rootScope.panelToBeDeleted.push(remove);
        }
        $scope.selectedAttorney = 'default';
        $rootScope.selectedAttorney = 'default';
        $scope.judgesToPanel = [];
        $scope.panelingDate = '';
        $scope.noAttorney = true;
        $scope.rehearingPanelChanged = true;
        validateSubmit();
      };
      /*istanbul ignore next */
      $scope.openClearPanelConfirmationModal = function (completionCode) {
        if ($scope.judgesToPanel.length === 0) {
          ngDialog.open({
            template: "app/components/widgets/assignments/src/clearPanelConfirmationModal.html",
            controller: "ClearPanelModalController",
            controllerAs: "vm",
            scope: $scope,
            width: '35%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false
          }).closePromise.then(function (clearPanel) {
            if (clearPanel.value) {
              $scope.clearPanelIndicator = "Y";
              $scope.submitPanel();
            } else {
              $scope.clearPanelIndicator = "N";
            }
          });
        } else {
          $scope.submitPanel(completionCode);
        }
      };

      /** This function will limit the list of selected judges to 9
       * This is subject to removal once the PO's decide on a maximum number of allowed judges on the panel
       */
      $scope.dataSelected = function (judge) {
        $scope.disableMove = false;
        $scope.judgeIndex = judge;
      };

      /** This function will disable the submit panel button until at least 3 judges are paneled */
      function validateSubmit() {
        $scope.disableSubmitPanel = false;
        if (($scope.judgesToPanel.length < 3) || ($scope.selectedRow.briefHearingTypeCode === CONSTANTS.TYPE_CODES.HEARD && $scope.judgesToPanel.length === 0)) {
          $scope.disableSubmitPanel = true;
        }
        $scope.getAttorneyList();
      }



      /* istanbul ignore next */
      $scope.criteriaMatch = function (input) {
        var tempList = [];
        if (angular.isDefined(input) && input.trim() !== "") {
          angular.forEach($scope.originalJudgeList, function (currentJudge) {
            if (currentJudge.assigneeFullNameText.toLowerCase().includes(input.toLowerCase())) {
              tempList.push(currentJudge);
            }
          });
          $scope.judgeList = angular.copy(tempList);
        } else {
          tempList = angular.copy($scope.originalJudgeList);
          for (var i = 0; i < $scope.judgesToPanel.length; i++) {
            for (var j = 0; j < tempList.length; j++) {
              if (tempList[j].assigneeFullNameText === $scope.judgesToPanel[i].assigneeFullNameText) {
                tempList.splice(j, 1);
              }
            }
          }
          $scope.judgeList = angular.copy(tempList);
        }
      };

      /** This function will submit the panel */
      /* istanbul ignore next */
      $scope.submitPanel = function (completionCode) {
        $scope.completionCode = completionCode;
        var data;
        var flags = {
          "showInitialMessage": false,
          "showNoDateMessage": false,
          "showConfirmSubmitMessage": false
        };
        if (!$scope.rehearingDecisionDueDate) {
          toastr.error(CONSTANTS.TOASTER.rehearingDate, {
            iconClass: 'toast-danger'
          });
        } else {
          if ($scope.clearPanelIndicator === 'Y') {

            var currentTime = Math.floor(new Date().getTime() / 1000);
            data = {
              "assignmentType": $scope.selectedRow.assignmentType,
              "assignee": $scope.selectedRow.assignee,
              "serialNumber": $scope.selectedRow.serialNumber,
              "title": $scope.selectedRow.title,
              "description": $scope.selectedRow.description,
              "dueDate": $scope.selectedRow.dueDate,
              "completionDate": currentTime,
              "caseType": $scope.selectedRow.caseType,
              "appealNumber": $scope.selectedRow.appealNumber,
              "sequenceNumber": $scope.selectedRow.sequenceNumber,
              "notes": "",
              "priorityIndicator": $scope.selectedRow.priorityIndicator,
              "assignmentIdentifier": $scope.selectedRow.assignmentIdentifier,
              "assignor": $scope.selectedRow.assignor,
              "activeIndicator": $scope.selectedRow.activeIndicator,
              "clearPanelIndicator": $scope.clearPanelIndicator,
              "completionCode": "CLEAR_PANEL",
              "audit": {
                "createUserIdentifier": $scope.userInfo.userId,
                "lastModifiedUserIdentifier": $scope.userInfo.userId,
                "lockControlNumber": 0,
                "createTimestamp": currentTime,
                "lastModifiedTimestamp": currentTime
              }
            };
            updatePanel(data);
          } else if (dateIsValid()) {
            data = $scope.createPanelObject(false);
            flags.showConfirmSubmitMessage = true;
            openDateRequiredModal(flags, data);
          } else {
            data = $scope.createPanelObject(true);
            flags.showInitialMessage = true;
            openDateRequiredModal(flags, data);
          }
        }
      };

      $scope.copyPA = function (patentAttorney) {
        $rootScope.selectedAttorney = angular.copy(patentAttorney);
      };


      /** This function will facilitate saving or save and closing the create panel modal */
      /* istanbul ignore next */
      $scope.savePanel = function (closeDialog) {
        if (angular.isDefined(closeDialog)) {
          if (closeDialog.customMessage) {
            $scope.message = "Changes to the panel have been saved and the assigmnent remains open.";
          } else {
            $scope.message = "Panel successfully updated.";
          }
          var flags = {
            "showSaveAndClose": false,
            "showSubmitAndClose": false
          };
          // Save and close


          if (closeDialog.showSaveDialog) {
            if (angular.element(document.getElementById('judgesToPanelList')).scope().judgesToPanel.length >= 3) {
              flags.showSubmitAndClose = true;
            } else {
              flags.showSaveAndClose = true;
            }

            var panelToBeCreated = $scope.createPanelObject(false);

            ngDialog.open({
              template: "app/components/widgets/assignments/src/panelSaveModal.html",
              controller: 'PanelSaveModalController',
              controllerAs: 'vm',
              scope: $scope,
              width: '30%',
              showClose: false,
              closeByEscape: false,
              closeByDocument: false,
              resolve: {
                flags: function () {
                  return flags;
                },
                panelToCreate: function () {
                  return panelToBeCreated;
                },
                completionCode: function () {
                  return 'ORIGINAL_PANEL';
                }
              }
            }).closePromise.then(function (response) {
              if (response.value) {
                var scope = angular.element(document.getElementById('judgesToPanelList')).scope();
                $scope.originalJudgesToPanel = scope.judgesToPanel;
                scope.originalJudgesToPanel = scope.judgesToPanel;
                var data = $scope.createPanelObject(!dateIsValid());
                createPanel(data);
                ngDialog.closeAll();
              }
            });
          } else {
            var scope = angular.element(document.getElementById('judgesToPanelList')).scope();
            $scope.originalJudgesToPanel = scope.judgesToPanel;
            scope.originalJudgesToPanel = scope.judgesToPanel;
            var data = $scope.createPanelObject(!dateIsValid());
            createPanel(data);
          }
          if (closeDialog.saveAndClose) {
            ngDialog.closeAll();
          }
        }
      };

      /** This function will open the save and close modal */
      /* istanbul ignore next */
      $scope.openSaveAndCloseDialog = function (flags) {

        ngDialog.open({
          template: "app/components/widgets/assignments/src/panelSaveModal.html",
          controller: 'PanelSaveModalController',
          controllerAs: 'vm',
          scope: $scope,
          width: '30%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            flags: function () {
              return flags;
            }
          }
        }).closePromise.then(function (response) {
          if (response.value) {

            var tempDecisionDate = document.getElementById('rehearingDecisionDueDate').value;
            $scope.rehearingDecisionDueDate = new Date(tempDecisionDate).getTime();
            var tempPanelDate = document.getElementById('rehearingPanelDate').value;
            $scope.rehearingPanelDate = new Date(tempPanelDate).getTime();
            $scope.submitPanel('COMPLETE');
          } else {
            var data = $scope.createPanelObject(!dateIsValid());
            createPanel(data);
          }
        });
      };


      /** This function will check if a paneling date is entered */
      function dateIsValid() {
        var dateScope = angular.element(document.getElementById('rehearingPanelDate')).scope();
        return (($scope.rehearingPanelDate !== null && $scope.rehearingPanelDate !== undefined) ||
          (angular.isDefined(dateScope.rehearingPanelDate) && dateScope.rehearingPanelDate !== ""));
      }

      /** This function will create the panel object before saving or submitting */
      /* istanbul ignore next */
      $scope.createPanelObject = function (useTodaysDate) {
        $log.debug($scope.selectedRow);
        $log.debug($scope.judgesToPanel);
        var scope = angular.element(document.getElementById('judgesToPanelList')).scope();
        var dateScope = angular.element(document.getElementById('rehearingPanelingDate')).scope();
        var currentTs = Math.floor(new Date().getTime() / 1000);
        var panelToBeCreated = [];
        var apjRank = 1;
        var panelDate = "";
        var priorityInd = "";
        if ($scope.selectedRow.priorityIndicator) {
          priorityInd = "Y";
        } else {
          priorityInd = "N";
        }
        if (useTodaysDate) {
          panelDate = new Date().getTime();
        } else if (angular.isNumber(dateScope.rehearingPanelDate)) {
          panelDate = dateScope.rehearingPanelDate;
        } else if (angular.isDefined(dateScope.rehearingPanelDate)) {
          panelDate = dateScope.rehearingPanelDate.getTime();
        }

        angular.forEach(scope.judgesToPanel, function (judge) {
          var panel = {
            "identifier": judge.assigneeNumberText,
            "panelRank": apjRank,
            "panelType": "APJ",
            "hotellingIndicator": $scope.hotelingInd ? "Y" : "N",
            "assignedDate": currentTs
          };
          panelToBeCreated.push(panel);
          apjRank++;
        });




        if (angular.isDefined($rootScope.selectedAttorney) && $rootScope.selectedAttorney.length > 0 && $rootScope.selectedAttorney !== "default") {
          var panel = {
            "identifier": $rootScope.selectedAttorney,
            "panelRank": 0
          };
          panelToBeCreated.unshift(panel);
        }

        return {
          "serialNumber": $scope.selectedRow.serialNumber,
          "appealNumber": $scope.selectedRow.appealNumber,
          "audit": {
            "lastModifiedTimestamp": currentTs,
            "lastModifiedUserIdentifier": $scope.userInfo.userId,
            "createUserIdentifier": $scope.selectedRow.audit.createUserIdentifier,
            "createdUserName": $scope.selectedRow.audit.createdUserName,
            "lastModifiedUserName": $scope.userInfo.userId,
            "createTimestamp": $scope.selectedRow.audit.createTimestamp,
            "lockControlNumber": $rootScope.panelLockControlNumber
          },
          "panelAssignment": {
            "assignmentIdentifier": $scope.selectedRow.assignmentIdentifier,
            "assignmentType": $scope.selectedRow.assignmentType,
            "assignee": $scope.selectedRow.assignee,
            "serialNumber": $scope.selectedRow.serialNumber,
            "title": $scope.selectedRow.title,
            "description": $scope.selectedRow.description,
            "dueDate": $scope.selectedRow.dueDate,
            "completionDate": $scope.selectedRow.completionDate,
            "caseType": $scope.selectedRow.caseType,
            "appealNumber": $scope.selectedRow.appealNumber,
            "sequenceNumber": $scope.selectedRow.sequenceNumber,
            "notes": $scope.selectedRow.notes,
            "completionCode": $scope.completionCode,
            "priorityIndicator": priorityInd,
            "clearPanelIndicator": $scope.clearPanelIndicator,
            "audit": {
              "createUserIdentifier": $scope.userInfo.userId,
              "lastModifiedUserIdentifier": $scope.userInfo.userId,
              "lockControlNumber": $rootScope.panelLockControlNumber
            }
          },
          "judgePanel": {
            "panelToBeCreated": panelToBeCreated,
            "panelToBeDeleted": $rootScope.panelToBeDeleted,
            "panelNotes": $rootScope.panelNotes,
            "panelDate": panelDate,
            "reconsiderSequenceNumber": parseInt(window.sessionStorage.getItem("reconsiderSeqNo"), CONSTANTS.GLOBAL.RADIX),
            "sequenceNumber": parseInt(window.sessionStorage.getItem("seqNo"), CONSTANTS.GLOBAL.RADIX)
          },
          "rehearingData": {
            "rehearingDecisionDueDate": $scope.rehearingDecisionDueDate
          }
        };

      };

      /** This function will open the date required modal is trying to submit panel without entering a paneling date */
      /* istanbul ignore next */
      function openDateRequiredModal(flags, data) {
        ngDialog.open({
          template: "app/components/widgets/assignments/src/panelingMessageModal.html",
          controller: 'PanelingMessageModalController',
          controllerAs: 'vm',
          scope: $scope,
          width: '25%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            createPanelData: function () {
              return data;
            },
            flags: function () {
              return flags;
            },
            circulationInProcess: function () {
              return $scope.selectedRow.circulationInProcess;
            }
          }
        }).closePromise.then(function (response) {
          if (response.value) {
            $log.debug(response.value);
          }
        });
      }


      /** This function is used to update or submit the panel */
      /* istanbul ignore next */
      function createPanel(data) {
        HttpFactory.postActions(CONSTANTS.URL.CREATE_JUDGE_PANEL, data)
          .then(function (successResponse) {
            $log.debug(successResponse);
            window.sessionStorage.setItem("seqNo", successResponse.data.judgePanel.sequenceNumber);
            if (successResponse.data.panelAssignment) {
              $rootScope.panelLockControlNumber = angular.copy(successResponse.data.panelAssignment.audit.lockControlNumber);
            } else if (successResponse.data) {
              $rootScope.panelLockControlNumber = angular.copy(successResponse.data.audit.lockControlNumber);
            }
            // toastr.success("The panel has been successfully updated.", {
            toastr.success($scope.message, {
              iconClass: 'toast-success'
            });
            $rootScope.savedPanelNotes = '';
            if ($scope.closeDialog) {
              ngDialog.closeAll(true);
            }
          }, function (failureResponse) {
            $log.debug(failureResponse);
            toastr.error(failureResponse.data.message, {
              iconClass: 'toast-danger'
            });
          })
          .finally(function () {
            $scope.rehearingPanelChanged = false;
          });
      }

      /** This function will open the panel history modal */
      /* istanbul ignore next */
      $scope.viewPanelHistory = function () {
        HttpFactory.getActions(CONSTANTS.URL.GET_PANEL_HISTORY + $scope.selectedRow.appealNumber)
          //$http.get("http://localhost:8080/PTABAppealsServices/appeal-judge-panels/panel-history?appealNumber=2010009172")
          .then(function (successResponse) {
            $scope.panelHistory = successResponse.data;
            if (angular.isDefined($scope.panelHistory)) {
              ngDialog.open({
                template: "app/components/widgets/assignments/src/viewRehearingPanelHistory.html",
                controller: 'ViewRehearingPanelHistoryController',
                controllerAs: 'vm',
                scope: $scope,
                width: '60%',
                showClose: false,
                closeByEscape: false,
                closeByDocument: false,
                resolve: {
                  panelHistory: function () {
                    return $scope.panelHistory;
                  }
                }
              });
            } else {
              toastr.error(CONSTANTS.TOASTER.noPanelHistory, {
                iconClass: 'toast-danger'
              });
            }
          }, function () {
            toastr.error(CONSTANTS.TOASTER.noPanelHistory, {
              iconClass: 'toast-danger'
            });
          });
      };

      /** This function will open the panel notes modal */
      $scope.viewNotes = function () {
        var numbers = {
          "applicationNumber": $scope.selectedRow.serialNumber,
          "appealNumber": $scope.selectedRow.appealNumber
        };
        ngDialog.open({
          template: "app/components/widgets/assignments/src/panelingNotesModal.html",
          controller: 'PanelingNotesController',
          controllerAs: 'vm',
          scope: $scope,
          width: '50%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            savedPanelNote: function () {
              return $rootScope.savedPanelNotes;
            },
            numbers: function () {
              return numbers;
            }
          }
        }).closePromise.then(function (response) {
          $rootScope.panelNotes = response.value;
          $rootScope.savedPanelNotes = response.value;
        });
      };

      /** This function will check for changes on the modal and prompt when calcelling */
      /* istanbul ignore next */
      $scope.checkForChanges = function () {
        var scope = angular.element(document.getElementById('judgesToPanelList')).scope();
        if (!angular.equals(scope.originalJudgesToPanel, scope.judgesToPanel)) {
          var panelToCreate = $scope.createPanelObject(false);
          ngDialog.open({
            template: "app/components/widgets/assignments/src/panelUnsavedChanges.html",
            controller: 'PanelUnsavedChangesController',
            controllerAs: 'vm',
            scope: $scope,
            width: '37%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              lessThanThreeApjs: function () {
                return angular.element(document.getElementById('special')).scope().judgesToPanel.length < 3;
              },
              panelToCreate: function () {
                return panelToCreate;
              },
              completionCode: function () {
                return 'ORIGINAL_PANEL';
              }
            }
          }).closePromise.then(function (response) {
            $log.debug(response);
            if (angular.isDefined(response.value)) {
              if (angular.isDefined(response.value.completionCode) && response.value.completionCode === 'COMPLETE') {
                $scope.openClearPanelConfirmationModal('ORIGINAL_PANEL');
              } else if (!response.value) {
                ngDialog.closeAll();
              } else {
                $scope.savePanel(response.value);
              }
            }
          });
        } else {
          $rootScope.savedPanelNotes = "";
          ngDialog.closeAll();
        }
      };

      /** This function will facilitate the cancel modal */
      /* istanbul ignore next */
      $scope.cancelCreatePanel = function () {
        $scope.checkForChanges();
      };

      /*istanbul ignore next */
      function updatePanel(data) {
        HttpFactory.putActions(CONSTANTS.URL.UPDATE_PANEL, data)
          .then(function (successResponse) {

            toastr.success(CONSTANTS.TOASTER.clearPanel, {
              iconClass: 'toast-success'
            });
            if ($scope.closeDialog) {
              ngDialog.closeAll(true);
            }
          }, function (failureResponse) {
            // intentional
          });
      }



    });
})();
