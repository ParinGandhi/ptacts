(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .directive('fileModel', ['$parse', function ($parse) {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var model = $parse(attrs.fileModel);
          var modelSetter = model.assign;

          element.bind('change', function () {
            scope.$apply(function () {
              modelSetter(scope, element[0].files[0]);
            });
          });
        }
      };
    }])

    .directive('customOnChange', function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var onChangeFunc = scope.$eval(attrs.customOnChange);
          element.bind('change', onChangeFunc);
        }
      };
    })
    .controller('miscellaneousDocController', function ($timeout, $log, $scope, ngDialog, HttpFactory, CONSTANTS, $http, toastr, $sce, $rootScope, $window) {
      var vm = this;
      vm.fileAdded = false;
      var scope = angular.element(document.getElementById('mainTabId')).scope();
      vm.userInfo = scope.vm.userInfo;
      $scope.fileNumber = 0;
      if (vm.userInfo.appUserInfo[0]) {
        vm.fullName = vm.userInfo.appUserInfo[0].fullName;
      } else {
        vm.fullName = vm.userInfo.appUserInfo.fullName;
      }
      $scope.listOfFileNames = [];
      $scope.fileContent = [];
      $scope.multiPdf = [];
      $scope.docketFileContent = [];
      $scope.show = true;
      $scope.editable = true;
      $scope.showPreview = true;
      $scope.fileUploadDisable = true;
      $scope.hideAdd = true;
      $scope.shareAssign = $rootScope.sharedItems;
      $scope.caseNum = $rootScope.sharedItems[0].serialNumber;
      $scope.appealNumber = $rootScope.sharedItems[0].appealNumber;
      $scope.assignmentTypeForRtf = $rootScope.sharedItems[0].assignmentType;
      $scope.rtfBaseLink = CONSTANTS.URL.BASE;
      $scope.transactionDate = new Date().getTime();
      $scope.enterDays = '';
      vm.hearingStatusIndicator = '';
      $scope.showHearingStatus = false;
      $scope.showUploadButton = false;
      $scope.readyToCreateRemand = false;
      $scope.dockType = null;
      /* istanbul ignore next */
      $scope.getDocketInfo = function (appNum, appealNumber) {
        angular.forEach($scope.shareAssign[0].standardAssignmentType, function () {
          HttpFactory.getActions(CONSTANTS.URL.APPEAL_METADATA + "?caseNumber=" + appNum + "&appealNumber=" + appealNumber)
            .then(function (successResponse) {
              $scope.docketInfo = successResponse.data;
            }, function (failureResponse) {
              $log.info(failureResponse);
            });
        });
      };

      getDecisionData();
      getSelectedJudgeList();
      getApj1();
      getApjPanel();

      function getDecisionData() {
        HttpFactory.getActions(CONSTANTS.URL.APPEAL_DECISION_DATA + "?appealNumber=" + $scope.appealNumber + "&serialNumber=" + $scope.caseNum)
          .then(function (successResponse) {
            $scope.appealDecisionData = successResponse.data;
            $scope.decisionTypeCode = successResponse.data.decisionTypeCode;
            $scope.selectedDecisionValue = successResponse.data.decisionTypeName
            $scope.apj1RulingCategory = successResponse.data.judgePanel[0].rulingCategory;
            $scope.apjPanel1RulingCategory = successResponse.data.judgePanel[1].rulingCategory;
            $scope.apjPanel2RulingCategory = successResponse.data.judgePanel[2].rulingCategory;
            HttpFactory.getActions(CONSTANTS.URL.PDP_TRAN_CODE + "?serialNumber=" + $scope.caseNum + "&appealNumber=" + $scope.appealNumber + "&proceedingType=" + successResponse.data.decisionTypeName)
              .then(function (successResponse) {
                $scope.documentCode = successResponse.data.decisionOutcome;
                $scope.officialDateEpoch = successResponse.data.decisionMailDate;
              }, function (failureResponse) {
                console.log(failureResponse);
              })
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      }

      /* istanbul ignore next */
      $scope.openPdfCombine = function () {
        HttpFactory.getActions("/data-documents/pdf?serialNumber=" + $scope.caseNum + '&docCode=' + $scope.documentCode + '&officialStrtDate=' + $scope.officialDateEpoch)
          .then(function (successResponse) {
            $scope.pdfContentDoc = 'data:application/pdf;base64,' + successResponse.data.fileContent;
            $http.get($scope.pdfContentDoc, {
              responseType: 'arraybuffer'
            })
              .success(function (data) {
                var file = new Blob([data], {
                  type: 'application/pdf'
                });
                var fileURL = URL.createObjectURL(file);
                if ($scope.pdfContentDoc !== null) {
                  //angular.element(document.getElementById('documentPreview')).scope().pdfContentDoc = $sce.trustAsResourceUrl(fileURL);
                } else {
                  $scope.pdfContentDoc = $sce.trustAsResourceUrl(fileURL);
                }
                if (fileURL !== '' || angular.isDefined(fileURL)) {
                  $scope.pdfStyle = {
                    "border": "1px solid grey"
                  };
                }
                $window.open(fileURL);
              }).error(function () {
                // Intentional
              });
          }, function (failureResponse) {
            toastr.error(failureResponse);
          });
      };


      //method to display PDF
      /* istanbul ignore next */
      $scope.addFile = function (file) {
        if (!vm.fileAdded) {
          vm.fileAdded = true;
          $scope.errorMessage = false;
          var fileName = file.currentTarget.files["0"].name;
          if (angular.isUndefined(fileName)) {
            return;
          } else {
            var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
            if (ext !== 'pdf') {
              $scope.errorMessage = true;
              toastr.error(CONSTANTS.TOASTER.fileUpload, {
                iconClass: 'toast-danger',
                timeOut: 9000000,
                extendedTimeOut: 9000000
              });
            }
            if (!$scope.errorMessage) {
              $scope.fileContent.push(file.currentTarget.files["0"]);
              $scope.listOfFileNames.push(file.currentTarget.files["0"].name);
              $scope.$apply();
            }
          }
        }
      };

      $scope.fileSelect = function (p) {
        if (p.keyCode === '13') {
          document.getElementById('file1').click();
        }
      };


      /* istanbul ignore next */
      $scope.showPreviewPdf = function () {
        $scope.loading = true;
        var pdfDataFile = new FormData();
        angular.forEach($scope.fileContent, function (value) {
          pdfDataFile.append('uploadMultipartFileContents', value);
        });
        HttpFactory.postPdf(CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.USERGEN + 'appealNumber=' + $scope.shareAssign[0].appealNumber +
          '&ptabAssignmentId=' + $scope.shareAssign[0].assignmentIdentifier, pdfDataFile)
          .then(function (successResponse) {
            $scope.dockType = "USER";
            $scope.PostDataResponse = successResponse.data.fileContent;
            $scope.genPdfFileName = successResponse.data.fileName;
            $rootScope.genPdfFileName = successResponse.data.fileName;
            $scope.contentsPreview = 'data:application/pdf;base64,' + $scope.PostDataResponse;
            $rootScope.contentsPreview = $scope.contentsPreview;
            $scope.getPreview($scope.contentsPreview);
            $scope.loading = false;
            $scope.hideAdd = false;
          }, function () {
            // intentional
          });
      };

      //delete pdf
      $scope.deletePdf = function (index) {
        $scope.listOfFileNames.splice(index, 1);
        $scope.fileContent.splice(index, 1);
      };

      //get call for preview
      /* istanbul ignore next */
      $scope.getPreview = function (contents) {
        $http.get(contents, {
          responseType: 'arraybuffer',
          headers: {
            'Accept': 'application/pdf'
          }
        })
          .success(function (data) {
            var file = new Blob([data], {
              type: 'application/pdf'
            });
            var fileURL = URL.createObjectURL(file);
            var fileOne = window.URL.createObjectURL(file);
            $scope.pdfContent = $sce.trustAsResourceUrl(fileOne);
            if (null !== $scope.pdfContent && document.getElementById('miscDoc') !== null) {
              angular.element(document.getElementById('miscDoc')).scope().pdfContent = $sce.trustAsResourceUrl(fileURL);
            } else {
              $scope.pdfContent = $sce.trustAsResourceUrl(fileURL);
            }
            if (fileURL !== '' || angular.isDefined(fileURL)) {
              $scope.show = false;
              $scope.editable = false;
              $scope.pdfStyle = {
                "border": "1px solid grey"
              };
            }
          }).error(function () {
            // intentional
          });
      };

      $scope.cancelUpload = function () {
        $scope.pdfContent = '';
        $scope.editable = true;
        $scope.show = true;
        $scope.hideAdd = true;
        $scope.pdfStyle = {
          "border": "none"
        };
      };

      $scope.selectFilespdf = function () {
        ngDialog.open({
          template: "app/components/widgets/assignments/src/addMiscFile.html",
          controller: 'miscellaneousDocController',
          controllerAs: "vm",
          scope: $scope,
          width: '45%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            partiesData: function () {
              return $scope.caseDetailsData;
            },
            partiesFlag: function () {
              return $scope.partiesShow;
            }
          }
        }).closePromise.then(function (data) {
          if (data.value !== "No file" && data.value !== 0) {
            $scope.fileNumber = data.value;
          }
          $scope.getDocketInfo($scope.shareAssign[0].serialNumber, $scope.shareAssign[0].appealNumber);
        }, function () {
          // intentional
        });
      };


      /* istanbul ignore next */
      $scope.palmUpload = function () {
        ngDialog.open({
          template: 'app/components/widgets/assignments/src/confirmPdfUpload.html',
          controller: 'pdfUploadController',
          width: '35%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          ariaLabelledById: 'pdfUploadTitle',
          ariaDescribedById: 'pdfUploadTitle',
          resolve: {
            pdfContent: function () {
              return $rootScope.contentsPreview;
            },
            docketInfo: function () {
              return $scope.shareAssign;
            },
            mailer: function () {
              return $scope.appealDecisionData.decisionMailerName;
            },
            genPdfFile: function () {
              return $rootScope.genPdfFileName;
            },
            panelData: function () {
              return null;
            },
            decisionType: function () {
              return $scope.selectedDecisionValue;
            },
            decisionDueDate: function () {
              return $scope.appealDecisionData.decisionDueDate;
            },
            decisionDate: function () {
              return $scope.appealDecisionData.decisionDate;
            },
            judgeList: function () {
              return $scope.judgesToPanel;
            },
            hearingRoomRosterData: function () {
              return null;
            },
            reconsiderSequenceNumber: function () {
              return $scope.appealDecisionData.adReconsiderSequenceNumber;
            },
            adSequenceNumber: function () {
              return $scope.appealDecisionData.adSequenceNumber;
            },
            dockType: function () {
              return $scope.dockType;
            },
            appealDecisionData: function () {
              return $scope.appealDecisionData;
            }
          }
        }).closePromise.then(function (pdfData) {
          $scope.$parent.$parent.refreshGrid = true;
          $scope.disableUpload = false;
          if (angular.isDefined(pdfData.value.fileName)) {
            if ($scope.shareAssign[0].assignmentType === 'MSCDOC') {
              $scope.showPreview = false;
              toastr.success("Docketing notice upload for Case " + $scope.shareAssign[0].appealNumber + " was successful.", {
                iconClass: 'toast-success'
              });
            }
            if ($scope.shareAssign[0].assignmentType === 'MISCMD') {
              $scope.showPreview = false;
              toastr.success("Decision upload for Case " + $scope.shareAssign[0].appealNumber + " was successful.", {
                iconClass: 'toast-success'
              });
            }
            if ($scope.shareAssign[0].assignmentType === 'MISCSNH') {
              $scope.showPreview = false;
              toastr.success("Notice of hearing upload for Case " + $scope.shareAssign[0].appealNumber + " was successful.", {
                iconClass: 'toast-success'
              });
            }
            $scope.uploadPdfContent = 'data:application/pdf;base64,' + pdfData.value.fileContent;
            if (pdfData.value.fileContent !== undefined) {
              $rootScope.pdfRefresh = true;
            } else {
              $rootScope.pdfRefresh = false;
            }
            $scope.getPreview($scope.uploadPdfContent);
          } else {
            toastr.error("Upload to PDP for Case " + $scope.shareAssign[0].appealNumber + " was unsuccessful.", {
              iconClass: 'toast-danger'
            });
          }
          if (pdfData.value.deliveryMode === 'Electronic' || pdfData.value.deliveryMode === 'EMAIL') {
            $scope.showButtons = false;
            toastr.success(CONSTANTS.TOASTER.mailingClosed, {
              iconClass: 'toast-success'
            });
          } else {
            $scope.showButtons = true;
          }
        });
      };

      $scope.goToNextTab = function () {
        $scope.urltemplate.url = "app/components/widgets/assignments/src/MAILDECISION.html",
          $scope.showVerifyDecision = false;
        $scope.htmlToLoad = "Mail decision";
      }

      $scope.getDecisionType = function () {
        HttpFactory.getActions(CONSTANTS.URL.DECISIONTYPE)
          .then(function (successResponse) {
            $scope.decisionList = successResponse.data;
            //if($scope.adhocFlag){
            $scope.selectedDecisionDisplay = $scope.decisionTypeCode;
            //   $scope.loading = false;
            //   $scope.enableUpload = false;
            //   $scope.setRule = false;
            //   $scope.showPreview = true;
            //   $scope.spinnerShow = false;
            //   $scope.getRule($scope.appealDecisionData.decisionTypeName,$scope.decisionTypeCode)
            // }
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };

      $scope.getRule = function (value, description) {
        $scope.setRule = false;
        $scope.selectedDecisionDisplay = description;
        $scope.selectedDecisionValue = value;
        // HttpFactory.getActions(CONSTANTS.URL.RULETYPE + value + '/' + $scope.shareAssign[0].serialNumber)
        //   .then(function (successResponse) {
        //     $scope.ruleList = successResponse.data;
        //     if ($scope.ruleList.decisionRuleName !== 'N/A') {
        //       $scope.enableUpload = true;
        //       $scope.responseTime($scope.enterDays);
        //     } else {
        //       $scope.enableUpload = false;
        //     }

        //     if($scope.decisionDocument === "Use system converted PDF" && !$scope.enableUpload){
        //       $scope.hidePalm = false;
        //     } else if($scope.decisionDocument === "Choose another file" &&$scope.enableUpload &&  $scope.fileNameDis != null){
        //       $scope.hidePalm = true;
        //     } else if($scope.decisionDocument === "Use system converted PDF" && $scope.enableUpload){
        //       $scope.hidePalm = true;
        //     } else if($scope.decisionDocument === "Choose another file" && !$scope.enableUpload){
        //       $scope.hidePalm = false;
        //     }
        //     if($scope.adhocFlag){
        //       $scope.hidePalm = false;
        //     }
        //   }, function (failureResponse) {
        //     $log.info(failureResponse);
        //   });
      };

      function getSelectedJudgeList() {
        HttpFactory.getActions(CONSTANTS.URL.GET_SELECTED_JUDGES + $scope.shareAssign[0].appealNumber + "&applicationNumber=" + $scope.shareAssign[0].serialNumber)
          .then(function (successResponse) {
            var tempList = [];
            $scope.rsNum = successResponse.data.judgePanel[0].reconsiderSequenceNumber;
            $scope.panelToBeCreatedArray = successResponse.data.judgePanel[0].panelToBeCreated;
            var lowest = 0;
            var highest = 0;
            var tmp;
            for (var i = $scope.panelToBeCreatedArray.length - 1; i >= 0; i--) {
              tmp = $scope.panelToBeCreatedArray[i].panelSequenceNumber;
              if (tmp < lowest) lowest = tmp;
              if (tmp > highest) highest = tmp;
            }
            $scope.adsNum = highest;
            angular.forEach(successResponse.data.judgePanel[0].panelToBeCreated, function (panel) {


              if (panel.activeIndicator === "Y" || panel.activeIndicator === "P") {

                if (panel.panelRank === 0) {
                  $scope.paName = panel.panelName;
                  $scope.paRank = panel.panelRank;
                }
                tempList[panel.panelRank - 1] = {
                  "identifier": panel.identifier,
                  "panelName": panel.panelName,
                  "panelRank": panel.panelRank,
                  "activeIndicator": panel.activeIndicator,
                  "reconsiderSequenceNumber": panel.reconsiderSequenceNumber,
                  "lastModifiedUserIdentifier": vm.userInfo.userId,
                  "lastModifiedTimestamp": new Date().getTime(),
                  "serialNumber": $scope.shareAssign[0].serialNumber,
                  "appealNumber": $scope.shareAssign[0].appealNumber,
                };
              }
            });

            $scope.judgesToPanel = tempList;
            if (angular.isDefined($scope.paRank) && $scope.paRank - 1 === -1) {
              var tempOrder = tempList[-1];
              tempList[tempList.length] = tempOrder;
            }
            $scope.apjList = [];
            $scope.tempApjList = tempList;
            $scope.apjList = $scope.tempApjList;
          });
      };

      /*Get Apj dropdown*/
      function getApj1() {
        HttpFactory.getActions(CONSTANTS.URL.APJ1)
          .then(function (successResponse) {

            $scope.apjoneList = successResponse.data;
              angular.forEach($scope.apjoneList, function (judgeList) {
                if (judgeList.descriptionText = $scope.apj1RulingCategory) {
                  $scope.setSelected(judgeList.valueText, judgeList.descriptionText);
                }
              });
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };
      /*Get Apj dorpdown*/
      function getApjPanel() {
        HttpFactory.getActions(CONSTANTS.URL.APJPANEL)
          .then(function (successResponse) {

            $scope.apjPanelList = successResponse.data;
              angular.forEach($scope.apjPanelList, function (judgeList) {
                if (judgeList.descriptionText = $scope.apjPanel1RulingCategory) {
                  $scope.setSelectedApj(judgeList.valueText, judgeList.descriptionText, 0);
                }
                if (judgeList.descriptionText = $scope.apjPanel2RulingCategory) {
                  $scope.setSelectedPA(judgeList.valueText, judgeList.descriptionText);
                }
              });
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };

      /**set selection value for apj panel */

      $scope.selectedDecision = {};
      $scope.selectedDecisionApj = {};
      $scope.selectedDecisionPA = {};
      /* istanbul ignore next*/
      $scope.setSelected = function (value, description) {
        $scope.selectedDecision.value = value;
        $scope.selectedDecision.description = description;
        if ($scope.selectedDecision.value === 'PERCURIAM' || $scope.selectedDecision.value === 'per curiam' || $scope.selectedDecision.value === 'Per Curiam') {
          $scope.selectedDecisionApj.description = $scope.selectedDecision.description;
          $scope.selectedDecisionPA.description = $scope.selectedDecision.description;
          $scope.judgesToPanel.rulingCategory;
          angular.forEach($scope.judgesToPanel, function (judgeList) {
            judgeList.rulingCategory = value;
            $scope.selectedDecisionApj.description = "Per Curiam";
          });
        }
      };

      /* istanbul ignore next*/
      $scope.setSelectedApj = function (value, description, id) {
        $scope.judgesToPanel[id + 1].rulingCategory = value;
        $scope.selectedDecisionApj.description = $scope.judgesToPanel[id + 1].rulingCategory.descriptionText;
        $scope.selectedDecisionApj.value = $scope.judgesToPanel[id + 1].rulingCategory.valueText;
        if (value === 'PERCURIAM' || value === 'per curiam' || value === 'Per Curiam') {
          $scope.selectedDecisionPA.description = value;
          $scope.selectedDecision.value = value;
          $scope.selectedDecision.description = description;
          $scope.judgesToPanel.rulingCategory;
          angular.forEach($scope.judgesToPanel, function (judgeList) {
            judgeList.rulingCategory = value;
            $scope.selectedDecisionApj.description = "Per Curiam";
          });
        }

      };

      /* istanbul ignore next*/
      $scope.setSelectedPA = function (value, description) {
        $scope.selectedDecisionPA.value = value;
        $scope.selectedDecisionPA.description = description;
        if (value === 'PERCURIAM' || value === 'per curiam' || value === 'Per Curiam') {
          $scope.selectedDecision.value = value;
          $scope.selectedDecision.description = description;
          $scope.judgesToPanel.rulingCategory;
          angular.forEach($scope.judgesToPanel, function (judgeList) {
            judgeList.rulingCategory = value;
            $scope.selectedDecisionApj.description = "Per Curiam";
          });
        }
        $scope.judgesToPanel[$scope.judgesToPanel.length - 1].rulingCategory = value;

      };

      $scope.email = function () {

        /* istanbul ignore next */
        HttpFactory.postActions(CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.UPLOAD_EMAIL + 'fileToEmail=' + $scope.fileToEmail +
            '&appealNumber=' + $scope.shareAssign[0].appealNumber +
            '&serialNumber=' + $scope.shareAssign[0].serialNumber +
            '&assignmentType=' + $scope.shareAssign[0].assignmentType
          )
          .then(function (successResponse) {
            $scope.emailResponse = successResponse.data;
            toastr.success(CONSTANTS.TOASTER.email, {
              iconClass: 'toast-success'
            });
            if ($rootScope.isMergedCase) {
              toastr.success($scope.shareAssign[0].title + " assignments for " + $rootScope.mergedApplListForToastr + " have been closed.", {
                iconClass: 'toast-success'
              });
            }

          }, function () {
            // intentional
          });
      };

      $scope.done = function(){
        ngDialog.closeAll(true);
      }

    });
})();
