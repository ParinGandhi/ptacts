// (function () {
//     'use strict';
  
//     describe('confirmENohController', function () {
  
//       beforeEach(module('ptabe2e'));
//       var $controller;
//       var vm = this;
//       var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close']);
//       var eroh, shareAssign, hStatus, pdfFileName, transactionDate;
//       var controller, scope, $rootScope;
//       var timeout;
  
//       var shareAssign = [{
//         "ptabAssignmentId": "1547",
//         "fkAdFkAaSerialNo": "2018005604",
//         "fkAdFkAppealNo": "10651537",
//         "standardAssignmentType": "Docketing notice"
//       }];
  
  
//       var eroh = {
          
//       "serialNumber":"95000296",
//       "appealNumber":2019000810,
//       "sequenceNumber":1,
//       "reconsiderSequenceNumber":0,
//       "hrrSequenceNumber":0,
//       "calendarNumber":null,
//       "counselFullName":null,
//       "hearingLocationIdentifier":1,
//       "locationDescription":"Alexandria: Room A",
//       "hearingDocketNumber":"B",
//       "hearingDate":1528171200000,
//       "hearingNoteText":"testing for update",
//       "hearingTime":"2:00:00 PM EST",
//       "lastModifiedTime":1541739600000,
//       "lastModifiedUserIdentifier":"gandhi9",
//       "palmHearingMailedDate":null,
//       "sessionNumber":1,
//       "specialTypeIndicator":"Y",
//       "statusCode":"Hearing reschedule granted",
//       "usherWorkerIdentifier":null,
//       "appealJudgePanel":null,
//       "realPartyInInterest":null

//       }
//       var hStatus = {
//         "selectedStatusDisplay" : "Hearing reschedule requested"
//       }

//       var pdfFileName = 
//         "Send Reschedule Decision_2019000809_3746_CustomCertificate.pdf"
      
      
//       beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_) {
//         $controller = _$controller_;
//         scope = _$rootScope_.$new();
//         $rootScope = _$rootScope_;
//         timeout = _$timeout_;
  
  
//         controller = $controller('confirmENohController', {
//           $scope: scope,
//           ngDialog: ngDialog,
//           $rootScope: _$rootScope_,
//           eroh: eroh,
//           shareAssign: shareAssign,
//           hStatus: hStatus,
//           pdfFileName: pdfFileName,
//           transactionDate:transactionDate 

//         });
//       }));
  
//       describe('confirmENohController ', function () {
  
  
//         it('it should call cancel ', function () {
//             expect(controller['cancel']).toBeDefined();
//             controller.cancel();
//           });
  
//           it('it should call abandonChanges ', function () {
//             expect(scope['abandonChanges']).toBeDefined();
//             ngDialog.getOpenDialogs.and.returnValue(ngDialog);
//             scope.abandonChanges();
//           });
  
//           it('it should call submitResponse ', function () {
//             scope.submitResponse();
//           });
  
//       });
//     });
//   })();
  