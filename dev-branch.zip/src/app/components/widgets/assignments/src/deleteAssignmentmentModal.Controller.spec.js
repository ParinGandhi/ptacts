(function () {
  'use strict';

  describe('deleteAssignmentmentModalController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var controller, scope, $rootScope;
    var successResponse, wrkNumbr, ptabId, activeIndicator;
    var $httpBackend, spy, $q, HttpFactoryDeferred;
    var $ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'closeAll']);

    activeIndicator = "A"
    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              getWidgetZone: function () {

              },
              setWidgetContentHeight: function () {

              }
            }
          }
        }
      }
    };

    // var toasterMsg = function (params){
    //   return true;
    // }

    beforeEach(inject(function (_$controller_, _$rootScope_, _$httpBackend_, _$q_, HttpFactory) {
      $q = _$q_;
      scope = _$rootScope_.$new();
      $controller = _$controller_;
      $rootScope = _$rootScope_;
      $httpBackend = _$httpBackend_;
      $ngDialog.open.and.returnValue({
        then: function (callback1, callback2) {
          callback1();
          callback2();
        }
      });
      scope.ptabId = 1142450;
      scope.wrkNumbr = 'pgandhi';

      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'deleteActions').and.returnValue(HttpFactoryDeferred.promise);
      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      // spyOn(angular, 'toastr').and.callFake(function (arguments) {
      //   // return whatever you want to here
      //   return true
      // })

      controller = $controller('deleteAssignmentmentModalController', {
        $scope: scope,
        ngDialog: $ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory,
        wrkNumbr: wrkNumbr,
        ptabId: ptabId,
        activeIndicator: activeIndicator
      });
    }));

    afterEach(function () {
      spy.and.callThrough();
    });

    describe('deleteAssignmentmentModalController ', function () {

      it('it should call closedltdlg ', function () {
        activeIndicator = "D"
        expect(scope['closedltdlg']).toBeDefined();
        expect($ngDialog.closeAll).toBeDefined();
        scope.closedltdlg();
        expect($ngDialog.closeAll).toHaveBeenCalledWith(true);
      });

      it('confirmanouncementDelete success response if', function () {

        successResponse = {
          data: {
            message: "deleted"
          }
        };
        expect(scope['confirmanouncementDelete']).toBeDefined();
        scope.confirmanouncementDelete();

        // HttpFactoryDeferred.resolve(successResponse);
        // scope.$digest();

      });

      it('confirmanouncementDelete success response else', function () {

        successResponse = {
          data: {
            message: undefined
          }
        };

        expect(scope['confirmanouncementDelete']).toBeDefined();
        scope.confirmanouncementDelete();

        // HttpFactoryDeferred.resolve(successResponse);
        // scope.$digest();
      });

      it('confirmanouncementDelete failureResponse if', function () {

        var failureResponse = {
          data: {
            message: "can't delete"
          }
        };
        expect(scope.confirmanouncementDelete).toBeDefined();
        scope.confirmanouncementDelete();

        // HttpFactoryDeferred.reject(failureResponse);
        // scope.$digest();


      });

      it('confirmanouncementDelete failureResponse else', function () {

        var failureResponse = {
          data: {
            message: undefined
          }
        };
        expect(scope['confirmanouncementDelete']).toBeDefined();
        scope.confirmanouncementDelete();

        // HttpFactoryDeferred.reject(failureResponse);
        // scope.$digest();


      });

    });


  });
})();
