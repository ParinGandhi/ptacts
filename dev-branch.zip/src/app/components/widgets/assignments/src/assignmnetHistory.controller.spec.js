(function () {
  'use strict';

  describe('AssignmentHistoryController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var controller, scope, $rootScope;
    var successResponse, assignmentData;
    var $httpBackend, spy, $q, HttpFactoryDeferred;
    var $ngDialog = jasmine.createSpyObj('ngDialog', ['open']);

    assignmentData = {
      "ptabAssignmentId": 1142301
    }
    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              getWidgetZone: function () {

              },
              setWidgetContentHeight: function () {

              }
            },
            // gridApi: {
            //   core: {
            //     on: {
            //       filterChanged: function () {
            //         grid = this.grid;
            //       }
            //     }
            //   }
            // }
          }
        }
      }
    };

    beforeEach(inject(function (_$controller_, _$rootScope_, _$httpBackend_, _$q_, HttpFactory) {
      $q = _$q_;
      scope = _$rootScope_.$new();
      $controller = _$controller_;
      $rootScope = _$rootScope_;
      $httpBackend = _$httpBackend_;
      $ngDialog.open.and.returnValue({
        then: function (callback1, callback2) {
          callback1();
          callback2();
        }
      });
      // grid = this.grid;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      controller = $controller('AssignmentHistoryController', {
        $scope: scope,
        ngDialog: $ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory,
        assignmentData: assignmentData
      });
    }));

    describe('AssignmentHistoryController ', function () {

      it('it should call gridOPtions', function () {

        // need to change the this in controller as vm
        // var grid;
        // grid = this.grid;
        var gridApi = {
          core: {
            on: {
              filterChanged: function () {
                // callback(this.grid);
              }
            },
          },
        };

        // controller.grid = {

        //   columns: [{
        //     "name": "applicatoinNumber",
        //     column: {
        //       filters: [{
        //         "value": "224"
        //       }]
        //     }

        //   }]
        // }

        // var column = {
        //   filters: [{
        //     "value": "224"
        //   }]
        // }

        expect(scope.gridOptions).toBeDefined();
        expect(scope.gridOptions.onRegisterApi).toBeDefined();
        scope.gridOptions.onRegisterApi(gridApi);
        expect(scope.gridApi).toBe(gridApi);
        // expect(grid).toBe(this.grid);
        scope.gridApi.core.on.filterChanged();

      });

      it('get Actions success response ', function () {

        successResponse = {
          data: {
            "columnDetails": [{
                "name": "lastModifiedDate",
                "label": "lastModifiedDate",
                "typeDefinition": "Date",
                "defaultOrder": "desc",
                "selected": true
              },
              {
                "name": "update",
                "label": "update",
                "typeDefinition": "String",
                "defaultOrder": "desc",
                "selected": false
              },
              {
                "name": "techCenter",
                "label": "Tech Center",
                "typeDefinition": "Number",
                "defaultOrder": "desc",
                "selected": true
              },
              {
                "name": "noteText",
                "label": "noteText",
                "typeDefinition": "String",
                "defaultOrder": "desc",
                "selected": true
              }
            ],
            "caseDetailsData": [{
              "proceedingId": "27253",
              "petitionerTechcenter": null,
              "hearingDate": null,
              "proceedingNumber": null,
              "status": "Submitted"
            }]
          }

        };
        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();

        expect(scope.myData).toBe(successResponse.data);
      });

      it('get Actions failureResponse ', function () {

        var failureResponse = {
          data: {}
        };
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });


      it('it should call toggleFilteringAssignment', function () {


        scope.gridOptions = {
          enableFiltering: true,
          data: "test"
        };

        scope.myData = {
          caseDetailsData: {

          }
        }
        // scope.showFilters = true;
        scope.gridApi = {
          core: {
            notifyDataChange: function (val) {

            }
          },
          grid: {
            clearAllFilters: function (val) {

            }
          }
        };

        expect(scope.toggleFilteringAssignment).toBeDefined();
        scope.toggleFilteringAssignment();
      });


      it('it should open showFilteringAssignment  ', function () {

        var existingCount = $ngDialog.open.calls.count();
        expect(scope.showFilteringAssignment).toBeDefined();
        scope.showFilteringAssignment();
        expect($ngDialog.open).toHaveBeenCalled();

        expect($ngDialog.open.calls.count()).toBe(existingCount + 1);
        var args = $ngDialog.open.calls.argsFor(existingCount);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);
      });

      it('it should open openUpdateData ', function () {
        var row = {
          "entity": {

          }
        }
        var existingCount = $ngDialog.open.calls.count();
        expect(scope.openUpdateData).toBeDefined();
        scope.openUpdateData(row);
        expect($ngDialog.open).toHaveBeenCalled();

        expect($ngDialog.open.calls.count()).toBe(existingCount + 1);
        var args = $ngDialog.open.calls.argsFor(existingCount);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);
      });

    });


  });
})();
