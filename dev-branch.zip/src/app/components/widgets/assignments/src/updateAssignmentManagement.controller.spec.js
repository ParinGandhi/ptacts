// (function () {
//     'use strict';
  
//     describe('updateAssignmentManagementController', function () {
  
//       beforeEach(module('ptabe2e'));
//       var $controller;
//       var vm = this;
//       var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close', 'open', 'openConfirm']);
//       var items, events, readOnly;
//       var controller, scope, $rootScope;
//       var timeout, createAssignment;
//       var successResponse, userInfo, revertedData, type, currentElement, rehearing;
//       var $httpBackend, spy, $q, HttpFactoryDeferred;
  
//       var fakeElement = function (params) {
//         return {
//           scope: function () {
//             return {
//               vm: {
//                 userInfo: {
//                   userId: "pgandhi"
//                 }
//               }
//             }
//           }
//         }
//       };
  
//       items = [{
//         globalMetaData: {
//           panel: [{
//             rank : 0,
//             employeeName: "sbartlett"
//           }]
//         },
//         standardAssignmentType: [{
//           "beNo": "5768",
//           "name": "Baker, Patrick",
//           "activeCases": "6",
//           "assigneeStatus": "Active",
//           "role": null,
//           "description": null
//         }],
//         "assignmentIdentifier": 1589,
//         "assignmentType": "DNMA",
//         "assignmentTypeDescription": "0",
//         "activeIndicator": "A",
//         "assignedDate": "1532530402",
//         "completionDate": "1532530402",
//         "pendingLocationText": "Pending",
//         "assignee": "5768",
//         "serialNumber": "14368609",
//         "sequenceNumber": "0",
//         "reconsiderSequenceNo": "0",
//         "palmMailedDate": "1532530402",
//         "assignmentNo": "0",
//         "title": "Import manager default title",
//         "description": "Import manager default description",
//         "assignor": "fhan",
//         "dueDate": "1532530402",
//         "assignmentStatusCode": "C",
//         "caseType": "APPEAL",
//         "creatorUserId": null,
//         "createTs": "1532530402",
//         "completerNumber": null,
//         "proceedingCoreIdentifier": null,
//         "proceedingSupIdentifier": null,
//         "notes": "Test Appeal create Note",
//         "preExistentIdentifier": null,
//         "priorityIndicator": "N",
//         "audit": {
//           "lastModifiedUserIdentifier": "465",
//           "createUserIdentifier": "465",
//           "lastModifiedTimestamp": "1532530402",
//           "createdUserName": "fhan",
//           "lastModifiedUserName": "fhan",
//           "createTimestamp": "1532530402",
//           "lockControlNumber": "0"
//         }
  
//       }]
  
//       revertedData = {
//         assignmentDueDt: 1500000000,
//         noteText: null,
//         assignmentCompletionDt: 1500000000,
//         value: 'yes'
//       }
//       var modifiedDate = {
//         value: 152525
//       }

//     //   rehearing = {
//     //       vm : {
//     //         items: [{
//     //             "priorityIndicator": "N"
//     //         }]
//     //       }
//     //   }
  
//       beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_, _$q_, HttpFactory) {
//         $q = _$q_;
//         $controller = _$controller_;
//         scope = _$rootScope_.$new();
//         $rootScope = _$rootScope_;
//         timeout = _$timeout_;
//         HttpFactoryDeferred = _$q_.defer();
//         scope.oldObj = {
//           name: "pgandhi",
//           assigneeStatus: "Assigned"
//         }
        
//         ngDialog.open.and.returnValue({
//           closePromise: {
//             then: function (callback1) {
//               callback1(revertedData);
//               callback1(modifiedDate);
//             }
//           },
//           then: function (callback3, callback4) {
//             callback3();
//             callback4();
//           }
//         });
  
//         ngDialog.openConfirm.and.returnValue({
//           then: function (callback3, callback4) {
//             callback3(scope.oldObj);
//             // callback4();
//           }
//         });
  
  
//         spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
//         spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
//         spy = spyOn(angular, 'element').and.callFake(fakeElement);
  
//         controller = $controller('updateAssignmentManagementController', {
//           $scope: scope,
//           ngDialog: ngDialog,
//           $rootScope: _$rootScope_,
//           items: items,
//           readOnly: readOnly,
//           HttpFactory: HttpFactory,
//           rehearing:rehearing
  
//         });
//       }));
  
//       describe('updateAssignmentManagementController ', function () {

//         it('Should invoke closedlg ', function () {
//           expect(ngDialog.closeAll).toBeDefined();
//           expect(scope['closedlg']).toBeDefined();
//           scope.closedlg();
//           expect(ngDialog.closeAll).toHaveBeenCalled();
  
//         });
  
//         it('Should invoke closeupdatedlg ', function () {
//           var closedlg = true;
//           var ngDialogArray = [ngDialog, ngDialog];
//           expect(ngDialog.close).toBeDefined();
//           expect(scope['closeupdatedlg']).toBeDefined();
//           ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
//           scope.closeupdatedlg(closedlg);
//           expect(ngDialog.close).toHaveBeenCalledWith(ngDialog, true);
  
//           expect(ngDialog.closeAll).toBeDefined();
//           expect(scope['closeupdatedlg']).toBeDefined();
//           ngDialog.getOpenDialogs.and.returnValue(ngDialog);
//           scope.closeupdatedlg(closedlg);
//           expect(ngDialog.closeAll).toHaveBeenCalledWith(true);
  
//         });
  
//         it('Should invoke closeupdatedlg else ', function () {
//           var closedlg = false;
//           expect(scope['closeupdatedlg']).toBeDefined();
//           scope.closeupdatedlg(closedlg);
  
//         });
  
//         it('Should invoke closedeletedialog ', function () {
//           expect(ngDialog.closeAll).toBeDefined();
//           expect(scope['closedeletedialog']).toBeDefined();
//           scope.closedeletedialog();
//           expect(ngDialog.closeAll).toHaveBeenCalled();
  
//         });
  
//         //   it('it should call myUserRole  ', function () {
//         //     var changedRole = "PTABE2E_Administrator";
//         //     var selectedUser = "5768";
  
//         //     expect(scope['myUserRole']).toBeDefined();
//         //     successResponse = [{
//         //       "assigneeNumberText": "5768",
//         //       "assigneeFullNameText": "Gandhi, Parin ",
//         //       "activeCaseCount": 121,
//         //       "assigneeStatus": "Active",
//         //       "userRoles": [{
//         //         "roleCode": "PTABE2E_Administrator",
//         //         "roleDescription": "Business Admin"
//         //       }]
//         //     }]
  
  
//         //     successResponse.data = [{
//         //       "assigneeNumberText": "5768",
//         //       "assigneeFullNameText": "Gandhi, Parin ",
//         //       "activeCaseCount": 121,
//         //       "assigneeStatus": "Active",
//         //       "userRoles": [{
//         //         "roleCode": "PTABE2E_Administrator",
//         //         "roleDescription": "Business Admin"
//         //       }]
//         //     }]
//         //     var item = {
//         //       "assigneeNumberText": "5768",
//         //       "assigneeFullNameText": "Gandhi, Parin ",
//         //       "activeCaseCount": 121,
//         //       "assigneeStatus": "Active",
//         //       "userRoles": [{
//         //         "roleCode": "PTABE2E_Administrator",
//         //         "roleDescription": "Business Admin"
//         //       }]
//         //     }
  
//         //     scope.myUserRole(changedRole, selectedUser);
//         //     HttpFactoryDeferred.resolve(successResponse);
//         //     $rootScope.$apply();
  
  
//         //   });
  
//         //   it('it should call myUserRole found assignee false', function () {
//         //     var changedRole = "PTABE2E_Administrator";
//         //     var selectedUser = "5768";
  
//         //     expect(scope['myUserRole']).toBeDefined();
//         //     successResponse = [{
//         //       "assigneeNumberText": "5768",
//         //       "assigneeFullNameText": "Gandhi, Parin ",
//         //       "activeCaseCount": 121,
//         //       "assigneeStatus": "Active",
//         //       "userRoles": [{
//         //         "roleCode": "PTABE2E_Administrator",
//         //         "roleDescription": "Business Admin"
//         //       }]
//         //     }]
//         //     successResponse.data = [{
//         //       "assigneeNumberText": "5768",
//         //       "assigneeFullNameText": "Gandhi, Parin ",
//         //       "activeCaseCount": 121,
//         //       "assigneeStatus": "Active",
//         //       "userRoles": [{
//         //         "roleCode": "PTABE2E_Administrator",
//         //         "roleDescription": "Business Admin"
//         //       }]
//         //     }]
//         //     var item = {
//         //       "assigneeNumberText": "5768",
//         //       "assigneeFullNameText": "Gandhi, Parin ",
//         //       "activeCaseCount": 121,
//         //       "assigneeStatus": "Active",
//         //       "userRoles": [{
//         //         "roleCode": "PTABE2E_Administrator",
//         //         "roleDescription": "Business Admin"
//         //       }]
//         //     }
  
//         //     scope.myUserRole(changedRole, selectedUser);
//         //     HttpFactoryDeferred.resolve(successResponse);
//         //     $rootScope.$apply();
  
  
  
//         //   });
  
//         // it('myUserRole get Actions failureResponse ', function () {
//         //   var changedRole = "PTABE2E_Administrator";
//         //   var selectedUser = "5768";
//         //   var failureResponse = {
//         //     data: {}
//         //   };
//         //   scope.myUserRole(changedRole, selectedUser);
//         //   HttpFactoryDeferred.reject(failureResponse);
//         //   $rootScope.$apply();
//         // });
  
//         // it('Should invoke Change', function () {
//         //   var content = {
//         //     name: "pgandhi",
//         //     assigneeStatus: "Assigned"
//         //   }
  
//         //   expect(scope['change']).toBeDefined();
//         //   scope.change(content);
//         // });
  
//         //   it('getRole get Actions failureResponse ', function () {
//         //     var failureResponse = {
//         //       data: {}
//         //     };
//         //     scope.getRole();
//         //     HttpFactoryDeferred.reject(failureResponse);
//         //     $rootScope.$apply();
//         //   });
  
//         //   it('Should invoke checkLengthAssingmentRole if', function () {
//         //     scope.roleforassignmnt = undefined;
  
//         //     expect(scope['checkLengthAssingmentRole']).toBeDefined();
//         //     scope.checkLengthAssingmentRole();
//         //   });
  
//         //   it('Should invoke checkLengthAssingmentRole else', function () {
//         //     scope.roleforassignmnt = "PTAB_Admin"
//         //     expect(scope['checkLengthAssingmentRole']).toBeDefined();
//         //     scope.checkLengthAssingmentRole();
//         //   });
  
//         it('Should invoke getAssignedTo success', function () {
//           scope.Assignedtoforassignmnt = "Ramani, Ravi ";
  
//           successResponse = {
//             data: [{
//               managersData: [{
//                 assigneeNumberText: "5772",
//                 assigneeFullNameText: "Ramani, Ravi ",
//                 activeCaseCount: 0,
//                 assigneeStatus: "Active",
//                 userRoles: [{
//                   roleCode: "PTABE2E_Administrator",
//                   roleDescription: "Business Admin",
//                 }],
//               }],
//               teamData: [{
//                   assigneeNumberText: "5768",
//                   assigneeFullNameText: "Gandhi, Parin ",
//                   activeCaseCount: 60,
//                   assigneeStatus: "Active",
//                   userRoles: [{
//                     roleCode: "PTABE2E_Administrator",
//                     roleDescription: "Business Admin",
//                   }],
//                 },
//                 {
//                   assigneeNumberText: "5831",
//                   assigneeFullNameText: "Korem, Divesh Reddy",
//                   activeCaseCount: 7,
//                   assigneeStatus: "Active",
//                   userRoles: [{
//                     roleCode: "PTABE2E_Administrator",
//                     roleDescription: "Business Admin",
//                   }],
//                 },
//                 {
//                   assigneeNumberText: "5791",
//                   assigneeFullNameText: "Murali, Krishna ",
//                   activeCaseCount: 15,
//                   assigneeStatus: "Active",
//                   userRoles: [{
//                     roleCode: "PTABE2E_Administrator",
//                     roleDescription: "Business Admin",
//                   }],
//                 },
//               ],
//               groupData: [{
//                   assigneeNumberText: "5768",
//                   assigneeFullNameText: "Gandhi, Parin ",
//                   activeCaseCount: 60,
//                   assigneeStatus: "Active",
//                   userRoles: [{
//                     roleCode: "PTABE2E_Administrator",
//                     roleDescription: "Business Admin",
//                   }],
//                 },
//                 {
//                   assigneeNumberText: "5890",
//                   assigneeFullNameText: "Koduru, Sasidhar ",
//                   activeCaseCount: 1,
//                   assigneeStatus: "Active",
//                   userRoles: [{
//                     roleCode: "PTABE2E_Administrator",
//                     roleDescription: "Business Admin",
//                   }],
//                 },
//                 {
//                   assigneeNumberText: "5831",
//                   assigneeFullNameText: "Korem, Divesh Reddy",
//                   activeCaseCount: 7,
//                   assigneeStatus: "Active",
//                   userRoles: [{
//                     roleCode: "PTABE2E_Administrator",
//                     roleDescription: "Business Admin",
//                   }],
//                 },
//                 {
//                   assigneeNumberText: "5791",
//                   assigneeFullNameText: "Murali, Krishna ",
//                   activeCaseCount: 15,
//                   assigneeStatus: "Active",
//                   userRoles: [{
//                     roleCode: "PTABE2E_Administrator",
//                     roleDescription: "Business Admin",
//                   }],
//                 },
//                 {
//                   assigneeNumberText: "5770",
//                   assigneeFullNameText: "Mylar, Madhukar ",
//                   activeCaseCount: 5,
//                   assigneeStatus: "Active",
//                   userRoles: [{
//                     roleCode: "PTABE2E_Administrator",
//                     roleDescription: "Business Admin",
//                   }],
//                 },
//               ],
//             }]
//           }
//           expect(scope['getAssignedTo']).toBeDefined();
//           scope.getAssignedTo();
  
//           // HttpFactoryDeferred.resolve(successResponse);
//           // $rootScope.$apply();
//         });
  
//         it('Should invoke moreAssigneesData ', function () {
//           expect(scope['moreAssigneesData']).toBeDefined();
//           scope.moreAssigneesData();
//         });
  
//         it('Should invoke getEwfDetails success', function () {
  
//           successResponse = {
//             data: {
//               serialNumber: "14009317",
//               sequenceNumber: null,
//               appealNumber: "2018005882",
//               lifeCycle: null,
//               audit: null,
//               preAppealInfo: {
//                 ptabReceivedDate: 1537625912000,
//                 appealNumberText: 2018005882,
//                 preAppealReviewAssigneeName: "Gandhi, Parin",
//                 appealAssignedDate: 1537625977000,
//                 applicationFilingDate: 1380600000000,
//               },
//               masterDocketInfo: {
//                 appealNumber: 2018005882,
//                 docketingNoticeMailedUserName: null,
//                 docketingNoticeDate: null,
//                 ewfCompletionDate: null,
//                 ewfCreatedUserName: null,
//                 masterDocketDate: null,
//                 masterDocketDiscipline: "Biotech",
//                 caseType: "B",
//               },
//               hearingInfo: {
//                 appealNumber: null,
//                 appealPanelJudgeOne: null,
//                 appealPanelJudgeTwo: null,
//                 appealPanelJudgeThree: null,
//                 panelDate: null,
//                 hearingNoticeDate: null,
//                 hearingNoticeMailedUserName: null,
//                 hearingDate: null,
//                 caseType: "B",
//                 heard: null,
//               },
//               panellingInfo: {
//                 appealPanelJudgeOne: null,
//                 appealPanelJudgeTwo: null,
//                 appealPanelJudgeThree: null,
//                 panelDate: null,
//                 caseType: "B",
//                 heard: null,
//               },
//               decisionInfo: {
//                 draftDecisionReviewCompletionDate: null,
//                 panelCirculationCompletionDate: null,
//                 decisionOutcome: null,
//                 decisionMailedUserName: null,
//                 decisionMailDate: null,
//                 draftReviewDecisionCompleted: false,
//               },
//               caseClosedInfo: {
//                 caseClosedDate: null
//               },
//             }
//           }
//           expect(scope['getEwfDetails']).toBeDefined();
//           scope.getEwfDetails();
  
//           // HttpFactoryDeferred.resolve(successResponse);
//           // scope.$apply();
//         });
  
//         it('Should invoke checkDueDate if', function () {
//           scope.updateAssignment = {
//             "dueDate": undefined
//           }
//           expect(scope['checkDueDate']).toBeDefined();
//           scope.checkDueDate();
//           timeout.flush();
//         });
  
//         it('Should invoke checkDueDate else', function () {
//           scope.updateAssignment = {
//             "dueDate": 201000854000
//           }
//           expect(scope['checkDueDate']).toBeDefined();
//           scope.checkDueDate();
//           timeout.flush();
//         });
  
//         it('Should invoke checkLengthofUpdateTitletx if', function () {
//           scope.updateAssignment = {
//             "title": undefined
//           }
//           expect(scope['checkLengthofUpdateTitletx']).toBeDefined();
//           scope.checkLengthofUpdateTitletx();
//         });
  
//         it('Should invoke checkLengthofUpdateTitletx else', function () {
//           scope.updateAssignment = {
//             "title": "ATP4"
//           }
//           expect(scope['checkLengthofUpdateTitletx']).toBeDefined();
//           scope.checkLengthofUpdateTitletx();
//         });
  
//         it('Should invoke checkAssignedTotx if', function () {
//           var assigneeto = true;
//           expect(scope['checkAssignedTotx']).toBeDefined();
//           scope.checkAssignedTotx(assigneeto);
//         });
  
//         it('Should invoke checkAssignedTotx else', function () {
//           var assigneeto = false;
//           expect(scope['checkAssignedTotx']).toBeDefined();
//           scope.checkAssignedTotx(assigneeto);
//         });
  
//         // it('getCaseTypes successResponse ', function () {
//         //   var getCaseTypes = {
//         //     data: {
//         //       caseType: "ATP1"
//         //     }
//         //   };
//         //   expect(scope.getCaseTypes).toBeDefined();
//         //   scope.getCaseTypes();
  
//         //   // HttpFactoryDeferred.resolve(successResponse);
//         //   // $rootScope.$apply();
//         // });
  
//         //toaster error
//         // it('getCaseTypes failureResponse ', function () {
//         //   var failureResponse = {
//         //     data: {}
//         //   };
//         //   expect(scope.getCaseTypes).toBeDefined();
//         //   scope.getCaseTypes();
  
//         //   HttpFactoryDeferred.reject(failureResponse);
//         //   $rootScope.$apply();
//         // });
  
//         it('Should invoke cancelupdateAssignDialog if', function () {
//           // var event = {
//           //   currentTarget: {
//           //     textContent: 'Cancel',
//           //     id: 'assignCloseButton'
//           //   }
//           // }
//           // var currentElement = "DOCKETINGINFO";
//           // scope.setCancel = true;
//           // scope.OnBlurProgress = true;
//           // scope.isUpdateSaved = false;
  
//           // scope.updateAssignment = {
//           //   assignmentDueDt: 1500000000,
//           //   noteText: null,
//           //   assignmentCompletionDt: 1500000000
//           // }
//           // scope.originalduedt = 151515252525;
//           // scope.originalCompDt = 151515252525;
//           // scope.roleforassignmnt = "PTAB_Administrator";
//           // scope.myusrRole = "PTAB_Admin";
//           // scope.isCompletiondate = true;
  
//           // expect(scope['cancelupdateAssignDialog']).toBeDefined();
//           // scope.cancelupdateAssignDialog(event, scope, currentElement);
  
//           // expect(ngDialog.open).toHaveBeenCalled();
  
//           // expect(ngDialog.open.calls.count()).toBe(2);
//           // var args = ngDialog.open.calls.argsFor(1);
//           // expect(args).not.toBe(null);
//           // expect(args.length).toBe(1);
  
//           // expect(args[0].controller).toBe('CancelUpdateAssignmentController');
//           // expect(typeof args[0].resolve).toBe('object');
//           // args[0].resolve.events();
//           // args[0].resolve.updateAssign();
//         });
  
//         it('Should invoke cancelupdateAssignDialog else text content cancel', function () {
//           var event = {
//             currentTarget: {
//               textContent: 'save'
//             }
//           }
//           var currentElement = "ASSIGNMENTINFO";
//           scope.setCancel = false;
//           scope.OnBlurProgress = false;
//           scope.isUpdateSaved = false;
//           scope.updateAssignment = {
//             assignmentDueDt: 1500000000,
//             noteText: null,
//             assignmentCompletionDt: 1500000000
//           }
//           scope.originalduedt = 151515252525;
//           scope.originalCompDt = 151515252525;
//           scope.roleforassignmnt = "PTAB_Administrator";
//           scope.myusrRole = "PTAB_Admin";
//           scope.isCompletiondate = true;
  
  
//           expect(scope['cancelupdateAssignDialog']).toBeDefined();
//           //scope.cancelupdateAssignDialog(currentElement);
//         });
  
  
//         it('Should invoke cancelupdateAssignDialog Assignment info', function () {
//           var event = {
//             currentTarget: {
//               textContent: 'Assignment info'
//             }
//           }
//           var currentElement = "CREATEEWF";
//           scope.setCancel = false;
//           scope.OnBlurProgress = false;
//           scope.isUpdateSaved = false;
//           scope.disableDelete = false;
//           scope.updateAssignment = {
//             assignmentDueDt: 1500000000,
//             noteText: null,
//             assignmentCompletionDt: 1500000000
//           }
//           scope.originalduedt = 151515252525;
//           scope.originalCompDt = 151515252525;
//           scope.roleforassignmnt = "PTAB_Administrator";
//           scope.myusrRole = "PTAB_Admin";
//           scope.isCompletiondate = true;
  
  
//           expect(scope['cancelupdateAssignDialog']).toBeDefined();
//           //scope.cancelupdateAssignDialog(currentElement);
//         });
  
//         it('Should invoke cancelupdateAssignDialog Docketing notice', function () {
//           var event = {
//             currentTarget: {
//               textContent: 'Docketing notice'
//             }
//           }
//           var currentElement = "REVIEWCHECKLIST";
//           scope.setCancel = false;
//           scope.OnBlurProgress = false;
//           scope.isUpdateSaved = false;
//           scope.disableDelete = true;
//           scope.updateAssignment = {
//             assignmentDueDt: 1500000000,
//             noteText: null,
//             assignmentCompletionDt: 1500000000
//           }
//           scope.originalduedt = 151515252525;
//           scope.originalCompDt = 151515252525;
//           scope.roleforassignmnt = "PTAB_Administrator";
//           scope.myusrRole = "PTAB_Admin";
//           scope.isCompletiondate = true;
  
  
//           expect(scope['cancelupdateAssignDialog']).toBeDefined();
//           //scope.cancelupdateAssignDialog(currentElement);
//         });
  
//         it('Should invoke cancelupdateAssignDialog else', function () {
//           var event = {
//             currentTarget: {
//               textContent: 'Assignment info'
//             }
//           }
  
//           scope.setCancel = true;
//           scope.OnBlurProgress = false;
//           scope.isUpdateSaved = true;
  
//           scope.updateAssignment = {
//             assignmentDueDt: 1500000000,
//             noteText: null,
//             assignmentCompletionDt: 1500000000
//           }
//           scope.originalduedt = 151515252525;
//           scope.originalCompDt = 151515252525;
//           scope.roleforassignmnt = "PTAB_Administrator";
//           scope.myusrRole = "PTAB_Admin";
//           scope.isCompletiondate = true;
  
//           expect(scope['cancelupdateAssignDialog']).toBeDefined();
//           //scope.cancelupdateAssignDialog(currentElement);
//         });
  
//         it('Should invoke cancelupdateAssignDialog else', function () {
//           var event = {
//             currentTarget: {
//               textContent: 'Docketing notice'
//             }
//           }
//           scope.setCancel = true;
//           scope.OnBlurProgress = false;
//           scope.isUpdateSaved = true;
  
//           scope.updateAssignment = {
//             assignmentDueDt: 1500000000,
//             noteText: null,
//             assignmentCompletionDt: 1500000000
//           }
//           scope.originalduedt = 151515252525;
//           scope.originalCompDt = 151515252525;
//           scope.roleforassignmnt = "PTAB_Administrator";
//           scope.myusrRole = "PTAB_Admin";
//           scope.isCompletiondate = true;
  
//           expect(scope['cancelupdateAssignDialog']).toBeDefined();
//          // scope.cancelupdateAssignDialog(currentElement);
//         });
  
//         it('Should invoke cancelupdateAssignDialog else', function () {
//           var event = {
//             currentTarget: {
//               textContent: 'Cancel',
//               id: 'assignCloseButton'
//             }
//           }
  
//           scope.setCancel = true;
//           scope.OnBlurProgress = false;
//           scope.isUpdateSaved = true;
  
//           scope.updateAssignment = {
//             assignmentDueDt: 1500000000,
//             noteText: null,
//             assignmentCompletionDt: 1500000000
//           }
//           scope.originalduedt = 151515252525;
//           scope.originalCompDt = 151515252525;
//           scope.roleforassignmnt = "PTAB_Administrator";
//           scope.myusrRole = "PTAB_Admin";
//           scope.isCompletiondate = true;
  
//           expect(scope['cancelupdateAssignDialog']).toBeDefined();
//           //scope.cancelupdateAssignDialog(currentElement);
//         });
  
//         it('Should invoke toCheckTabs', function () {
//           currentElement = 'DOCKETINGINFO';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'ASSIGNMENTINFO';
//           expect(scope['toCheckTabs']).toBeDefined();
//           //scope.toCheckTabs(currentElement);
  
//           currentElement = 'CREATEEWF';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'UPDATEEWF';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'REVIEWCHECKLIST';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'DISMISSAL';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'REMAND';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'EDITDISMISSAL';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'EDITREMAND';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'PDISMISSAL';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'PADMINREMAND';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'PANELING';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'SNOH';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'ENOH';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'SRD';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'PTVH';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'CDD';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'PANELDECISION';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'MAILDECISION';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'UHAT';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'REVIEWHT';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);
  
//           currentElement = 'UHT';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);

//           currentElement = 'CRP';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);

//           currentElement = 'RRDD';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);

//           currentElement = 'CRDD';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);

//           currentElement = 'RRD';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);

//           currentElement = 'UPDATEREHEARINGEWF';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);

//           currentElement = 'APPROVEREHEARINGPANEL';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);

//           currentElement = 'REHEARINGPANELING';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);

//           currentElement = 'MRD';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);

//           currentElement = 'CREATESDD';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);

//           currentElement = 'RSDD';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);

//           currentElement = 'MSDD';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);

//           currentElement = 'CDLD';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);

//           currentElement = 'EDD';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);

//           currentElement = 'PARD';
//           expect(scope['toCheckTabs']).toBeDefined();
//           scope.toCheckTabs(currentElement);

//         });
  
  
//         it('Should invoke opendeleteAssignmentModal', function () {
//           scope.updateAssignment = {
//             "ptabAssignmentId": 1162,
//             "activeIn": "A"
//           }
//           controller.userInfo.userId = "pgandhi"
  
//           expect(scope['opendeleteAssignmentModal']).toBeDefined();
//           scope.opendeleteAssignmentModal();
  
//           expect(ngDialog.open).toHaveBeenCalled();
  
//           expect(ngDialog.open.calls.count()).toBe(1);
//           var args = ngDialog.open.calls.argsFor(0);
//           expect(args).not.toBe(null);
//           expect(args.length).toBe(1);
  
//           expect(args[0].controller).toBe('deleteAssignmentmentModalController');
//           expect(typeof args[0].resolve).toBe('object');
//           args[0].resolve.ptabId();
//           args[0].resolve.wrkNumbr();
//           args[0].resolve.activeIndicator();
//         });
  
//         it('Should invoke checkTimedSave', function () {
//           expect(scope['checkTimedSave']).toBeDefined();
//           scope.checkTimedSave();
//           timeout.flush();
//         });
  
//         it('Should invoke updateEWF', function () {
//           expect(scope['updateEWF']).toBeDefined();
//           scope.updateEWF();
//         });
  
  
//         it('Should invoke checkComplitiondate ', function () {
//           scope.updateAssignment = {
//             "assignmentCompletionDt": new Date("05/20/2018")
//           }
//           expect(scope['checkComplitiondate']).toBeDefined();
//           scope.checkComplitiondate();
//         });
  
//         it('Should invoke checkComplitiondate else if', function () {
//           scope.updateAssignment = {
//             "assignmentCompletionDt": undefined
//           }
//           var x = document.getElementById('reportFromCompletionDatedefined').value = "";
//           expect(scope['checkComplitiondate']).toBeDefined();
//           scope.checkComplitiondate();
//         });
  
//         it('Should invoke checkComplitiondate else if', function () {
//           scope.updateAssignment = {
//             "assignmentCompletionDt": undefined
//           }
//           var x = document.getElementById('reportFromCompletionDatedefined').value = "defined";
//           expect(scope['checkComplitiondate']).toBeDefined();
//           scope.checkComplitiondate();
//         });
  
//         it('Should invoke checkComplitiondate ', function () {
//           scope.updateAssignment = {
//             "assignmentCompletionDt": 1532712182719
//           }
//           expect(scope['checkComplitiondate']).toBeDefined();
//           scope.checkComplitiondate();
//         });
  
  
//         it('Should invoke checksave if', function () {
  
//           scope.updateAssignment = {
//             assignmentDueDt: 150000000025,
//             priorityIn: "Y",
//             taskDescTx: "TASK",
//             taskTitleTx: "TITLE",
//             assignmentCompletionDt: 150000252525,
//             noteText: "NOTE"
//           }
//           scope.originalduedt = 150000000000;
//           scope.originalpriorityIn = "N";
//           scope.originaltaskDescTx = "true";
//           scope.originaltaskTitleTx = "true";
//           scope.originalCompDt = 150000252500;
//           scope.originalnoteText = "true";
//           expect(scope['checksave']).toBeDefined();
//           scope.checksave();
//         });
  
//         it('Should invoke checksave else', function () {
//           expect(scope['checksave']).toBeDefined();
//           scope.checksave();
//         });
  
//         it('Should invoke dateConverter', function () {
//           var recievedDate = null;
//           expect(scope['dateConverter']).toBeDefined();
//           scope.dateConverter(recievedDate);
//         });
  
  
//         it('Should invoke dateConverter', function () {
//           var recievedDate = "07/25/2018";
//           expect(scope['dateConverter']).toBeDefined();
//           scope.dateConverter(recievedDate);
//         });
  
//         it('Should invoke ewfCompleted', function () {
//           expect(scope['ewfCompleted']).toBeDefined();
//           scope.ewfCompleted();
//         });
  
//         it('Should invoke getEwfDetails success', function () {
//           scope.Assignedtoforassignmnt = "Ramani, Ravi ";
  
//           successResponse = {
//             data: {
//               "serialNumber": "13377245",
//               "sequenceNumber": 0,
//               "appealNumber": null,
//               "lifeCycle": null,
//               "audit": null,
//               "preAppealInfo": {
//                 "ptabReceivedDate": 1537545597000,
//                 "appealNumberText": null,
//                 "preAppealReviewAssigneeName": "Gandhi, Parin",
//                 "appealAssignedDate": null,
//                 "applicationFilingDate": 1323406800000
//               },
//               "masterDocketInfo": {
//                 "appealNumber": null,
//                 "docketingNoticeMailedUserName": null,
//                 "docketingNoticeDate": null,
//                 "ewfCompletionDate": null,
//                 "ewfCreatedUserName": null,
//                 "masterDocketDate": null,
//                 "masterDocketDiscipline": null,
//                 "caseType": null
//               },
//               "hearingInfo": {
//                 "appealNumber": null,
//                 "appealPanelJudgeOne": null,
//                 "appealPanelJudgeTwo": null,
//                 "appealPanelJudgeThree": null,
//                 "panelDate": null,
//                 "hearingNoticeDate": null,
//                 "hearingNoticeMailedUserName": null,
//                 "hearingDate": null,
//                 "caseType": null,
//                 "heard": null
//               },
//               "panellingInfo": {
//                 "appealPanelJudgeOne": null,
//                 "appealPanelJudgeTwo": null,
//                 "appealPanelJudgeThree": null,
//                 "panelDate": null,
//                 "caseType": null,
//                 "heard": null
//               },
//               "decisionInfo": {
//                 "draftDecisionReviewCompletionDate": null,
//                 "panelCirculationCompletionDate": null,
//                 "decisionOutcome": null,
//                 "decisionMailedUserName": null,
//                 "decisionMailDate": null,
//                 "draftReviewDecisionCompleted": false
//               },
//               "caseClosedInfo": {
//                 "caseClosedDate": null
//               }
//             }
//           }
  
//           expect(scope['getEwfDetails']).toBeDefined();
//           scope.getEwfDetails();
  
//           // HttpFactoryDeferred.resolve(successResponse);
//           // $rootScope.$apply();
//         });
  
//         it('Should invoke timedCompdate', function () {
//           expect(scope['timedCompdate']).toBeDefined();
//           scope.timedCompdate();
//           timeout.flush();
//         });
  
  
//         it('Should invoke checkCompdate if', function () {
  
//           scope.updateAssignment = {
//             assignmentCompletionDtdefined: new Date("05/20/2018")
//           }
//           expect(scope['checkCompdate']).toBeDefined();
//           scope.checkCompdate();
//         });
  
//         it('Should invoke checkCompdate else if', function () {
//           scope.updateAssignment = {
//             assignmentCompletionDtdefined: undefined
//           }
//           var x = document.getElementById('reportFromCompletionDatedefined').value = "";
//           scope.completionDatedefined = 150000000000
//           expect(scope['checkCompdate']).toBeDefined();
//           scope.checkCompdate();
  
//           expect(ngDialog.open).toHaveBeenCalled();
  
//           expect(ngDialog.open.calls.count()).toBe(2);
//           var args = ngDialog.open.calls.argsFor(1);
//           expect(args).not.toBe(null);
//           expect(args.length).toBe(1);
  
//           expect(args[0].controller).toBe('completedDateVerificationController');
//           expect(typeof args[0].resolve).toBe('object');
//           args[0].resolve.definedCompdate();
  
//         });
  
//         it('Should invoke checkCompdate else if', function () {
//           scope.updateAssignment = {
//             assignmentCompletionDtdefined: undefined
//           }
//           var x = document.getElementById('reportFromCompletionDatedefined').value = "defined";
//           scope.completionDatedefined = 150000000000
//           expect(scope['checkCompdate']).toBeDefined();
//           scope.checkCompdate();
  
//         });
  
//         it('Should invoke checkCompdate else ', function () {
//           scope.updateAssignment = {
//             assignmentCompletionDtdefined: 150000000000
//           }
//           expect(scope['checkCompdate']).toBeDefined();
//           scope.checkCompdate();
//         });
  
  
//         it('it should call getHistory success', function () {
  
//           successResponse.data = {
  
//           }
  
//           expect(scope['getHistory']).toBeDefined();
//           scope.getHistory();
//           // HttpFactoryDeferred.resolve(successResponse);
//           // scope.$digest();
//         });
  
//         it('it should call getDismissalList success', function () {
  
//           successResponse.data = {
  
//           }
  
//           expect(scope['getDismissalList']).toBeDefined();
//           scope.getDismissalList();
//           // HttpFactoryDeferred.resolve(successResponse);
//           // scope.$digest();
//         });
  
//         it('it should call validateBusinnessdateSelected success', function () {
  
//           expect(scope['validateBusinnessdateSelected']).toBeDefined();
//           successResponse = {
//             "assignees": [{
//               "beNo": "5778",
//               "name": "Baker, Patrick",
//               "activeCases": "6",
//               "assigneeStatus": "Active",
//               "role": null,
//               "description": null
//             }, {
//               "beNo": "1810",
//               "name": "Bartlett, Steven",
//               "activeCases": "0",
//               "assigneeStatus": "Active",
//               "role": null,
//               "description": null
//             }, {
//               "beNo": "26",
//               "name": "Brock, Alan",
//               "activeCases": "0",
//               "assigneeStatus": "InActive",
//               "role": null,
//               "description": null
//             }, {
//               "beNo": "5779",
//               "name": "Bui, Jacqueline",
//               "activeCases": "3",
//               "assigneeStatus": "Active",
//               "role": null,
//               "description": null
//             }]
  
//           };
  
//           successResponse.data = {
//             assignees: [{
//               "beNo": "5768",
//               "name": "Baker, Patrick",
//               "activeCases": "6",
//               "assigneeStatus": "Active",
//               "role": null,
//               "description": null
//             }, {
//               "beNo": "5779",
//               "name": "Bui, Jacqueline",
//               "activeCases": "3",
//               "assigneeStatus": "Active",
//               "role": null,
//               "description": null
//             }]
//           }
//           var item = {
//             "beNo": "5768",
//             "name": "Baker, Patrick",
//             "activeCases": "6",
//             "assigneeStatus": "Active",
//             "role": null,
//             "description": null
//           }
  
//           scope.validateBusinnessdateSelected();
//           //toaster error
//           // HttpFactoryDeferred.resolve(successResponse);
//           // scope.$digest();
//         });
  
//         it('validateBusinnessdateSelected get Actions failureResponse ', function () {
//           var failureResponse = {
//             data: {}
//           };
//           scope.validateBusinnessdateSelected();
//           // HttpFactoryDeferred.reject(failureResponse);
//           // scope.$digest();
//         });
  
//         it('Should invoke assignmentUpdateSave if', function () {
//           scope.OnBlurProgress = true;
//           expect(scope['assignmentUpdateSave']).toBeDefined();
//           scope.assignmentUpdateSave();
//         });
//         it('Should invoke assignmentUpdateSave', function () {
//           scope.OnBlurProgress = false;
//           expect(scope['assignmentUpdateSave']).toBeDefined();
//           scope.assignmentUpdateSave();
//         });
//         it('Should invoke assignmentUpdateSave', function () {
//           scope.OnBlurProgress = false;
//           scope.dueDatetoCheckbusinessVallidation = "07/25/2018";
//           scope.updateAssignment = {
//             assignmentDueDt: "07/25/2018"
//           }
//           expect(scope['assignmentUpdateSave']).toBeDefined();
//           scope.assignmentUpdateSave();
//         });
//         it('Should invoke checkListRadio', function () {
//           var valueText = "DISMISSAL";
//           expect(scope['checkListRadio']).toBeDefined();
//           scope.checkListRadio(valueText);
//         });
  
//         it('Should invoke checkListRadio if', function () {
//           var valueText = "DISMISSAL;";
//           expect(scope['checkListRadio']).toBeDefined();
//           scope.checkListRadio(valueText);
//         });
  
//         it('Should invoke reviewCheckValidation if', function () {
//           scope.updateAssignment = {
//             "noteText": undefined
//           }
//           expect(scope['reviewCheckValidation']).toBeDefined();
//           scope.reviewCheckValidation();
//         });
  
//         it('Should invoke reviewCheckValidation if', function () {
//           expect(scope['reviewCheckValidation']).toBeDefined();
//           scope.reviewCheckValidation();
//         });
  
//         it('Should invoke reviewCheckValidation else', function () {
//           scope.updateAssignment = {
//             "noteText": "added"
//           }
//           expect(scope['reviewCheckValidation']).toBeDefined();
//           scope.reviewCheckValidation();
//         });
  
  
//         it('Should invoke checkListDrop', function () {
//           type = undefined;
//           scope.assignmentTypes = [{
  
//           }]
//           expect(scope['checkListDrop']).toBeDefined();
//           scope.checkListDrop(type);
//         });
  
//         it('Should invoke checkListDrop', function () {
//           type = "ATP1";
//           expect(scope['checkListDrop']).toBeDefined();
//           scope.checkListDrop(type);
//         });
  
//         it('Should invoke submitReviewCheck if', function () {
//           scope.showNoteError = false;
//           var valueText = "",
//             typeSeclected = undefined;
//           expect(scope['submitReviewCheck']).toBeDefined();
//           scope.submitReviewCheck(valueText, typeSeclected);
  
  
//           var valueText = "COMPLAINT;",
//             typeSeclected = "Assignment";
//           expect(scope['submitReviewCheck']).toBeDefined();
//           scope.submitReviewCheck(valueText, typeSeclected);
//         });
  
//         it('Should invoke submitReviewCheck else', function () {
//           scope.showNoteError = false;
//           var valueText = "COMPLIANT_WITH_ISSUES",
//             typeSeclected = "";
//           expect(scope['submitReviewCheck']).toBeDefined();
//           scope.submitReviewCheck(valueText, typeSeclected);
//         });
  
  
//         it('Should invoke submitReviewCheck else', function () {
//           scope.showNoteError = true;
//           var valueText = "COMPLIANT_WITH_ISSUES",
//             typeSeclected = "";
//           expect(scope['submitReviewCheck']).toBeDefined();
//           scope.submitReviewCheck(valueText, typeSeclected);
//         });
  
//         it('Should invoke openUpdateAssignmentHistory', function () {
//           scope.items = [{
//             assignmentCompletionDtdefined: 150000000000
//           }]
//           expect(scope['openUpdateAssignmentHistory']).toBeDefined();
//           scope.openUpdateAssignmentHistory();
  
  
//           expect(ngDialog.open).toHaveBeenCalled();
  
//           expect(ngDialog.open.calls.count()).toBe(3);
//           var args = ngDialog.open.calls.argsFor(2);
//           expect(args).not.toBe(null);
//           expect(args.length).toBe(1);
  
//           expect(args[0].controller).toBe('AssignmentHistoryController');
//           expect(typeof args[0].resolve).toBe('object');
//           args[0].resolve.assignmentData();
  
//         });
  
//         it('Should call createSp', function () {
//           scope.showNoteError = false;
//           expect(scope['createSp']).toBeDefined();
//           scope.createSp();
//         });
  
//       });
//     });
//   })();
  