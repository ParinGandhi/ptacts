(function () {
  "use strict";

  angular
    .module('ptabe2e')
    .controller('CancelUpdateAssignmentController', function (ngDialog, $scope, $timeout, currentElement) {
      var vm = this;

      $scope.currentElement = currentElement;
      vm.revertAllChanges = function () {

        closeChangesDialog(1, 'yes');
        if ($scope.currentElement !== 'cancel') {
          return;
        } else {
          /*istanbul ignore next */
          ngDialog.closeAll();
        }
      };

      function closeChangesDialog(popupsToClose, originalData) {


        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose], originalData);
        } else {
          ngDialog.close();
        }
      }


      vm.closeDialog = function () {
        closeChangesDialog(1, 'no');
      };
    });
})();
