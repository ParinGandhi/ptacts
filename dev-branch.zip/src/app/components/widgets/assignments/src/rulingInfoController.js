(function () {
  "use strict";

  angular.module('ptabe2e')
    .controller('RulingInfoController', function (CONSTANTS) {

      var vm = this;
      vm.rulingInfo = CONSTANTS.ONEZEROONERULING.tooltip;

      vm.rulingInfoAddedText = CONSTANTS.ONEZEROONERULING.addedText;

    });
})();
