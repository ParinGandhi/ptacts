(function () {
  'use strict';

  describe('ViewPanelHistoryController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll']);
    var controller, scope, $rootScope;
    var timeout;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;
    var panelHistory;

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      panelHistory = [{
        activeIndicator: "Y"
      }]

      controller = $controller('ViewPanelHistoryController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        panelHistory: panelHistory,
        HttpFactory: HttpFactory

      });
    }));

    describe('ViewPanelHistoryController ', function () {

      it('it should call togglePaneled', function () {
        expect(scope.togglePaneled).toBeDefined();
        scope.togglePaneled();
      });

      it('it should call togglePaneled with false', function () {
        scope.isPanelOnly = true;
        expect(scope.togglePaneled).toBeDefined();
        scope.togglePaneled();
      });

    });
  });
})();
