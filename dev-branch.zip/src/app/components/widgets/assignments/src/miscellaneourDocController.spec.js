(function () {
  'use strict';

  describe('miscellaneousDocController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open']);
    var controller, scope, $rootScope;
    var p, index;
    var spy, $q, HttpFactoryDeferred;
    var showPromoteTypesValues;
    // var pdfContent = {
    //   value: "xsgght"
    // }

    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              workerNumber: "pgandhi",
              userInfo: {
                appUserInfo: [{
                  userIdentiifier: "sbartlett",
                  fullName: "Steve Bartlett"
                }]
              }
            }
          }
        }
      }
    };

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);

      $rootScope.sharedItems = [{
        "ptabAssignmentId": "1547",
        "fkAdFkAaSerialNo": "2018005604",
        "fkAdFkAppealNo": "10651537",
        "assignmentType": "RHT"
      }];

      scope.specialType = [{
        valueText: "added",
        descriptionText: "desc"
      }]

      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback) {
            callback({
              value: 1
            });
          }
        }
      });

      scope.specialHearingType = {
        selectedStatusType: "CT",
        selectedStatusDisplay: "CT"
      }

      scope.hearingAtten = {
        selectedHearingCode: "CT",
        selectedHearingDisplay: "CT"
      }

      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      spy = spyOn(angular, 'element').and.callFake(fakeElement);
      controller = $controller('miscellaneousDocController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        showPromoteTypesValues: showPromoteTypesValues,
        HttpFactory: HttpFactory

      });
    }));

    describe('miscellaneousDocController ', function () {

      it(' should call fileSelect', function () {
        p = {
          keycode: "1",
        }
        expect(scope['fileSelect']).toBeDefined();
        scope.fileSelect(p);
      });

      it(' should call fileSelect', function () {
        p = {
          keycode: '13'
        }
        expect(scope['fileSelect']).toBeDefined();
        scope.fileSelect(p);
      });

      it(' should call deletePdf', function () {
        index = "1"
        expect(scope['deletePdf']).toBeDefined();
        scope.deletePdf(index);
      });


      it('it should open selectFilespdf', function () {
        scope.caseDetailsData = {};
        scope.partiesShow = {};
        expect(scope['selectFilespdf']).toBeDefined();
        scope.selectFilespdf();
        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(1);
        var args = ngDialog.open.calls.argsFor(0);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('miscellaneousDocController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.partiesData();
        args[0].resolve.partiesFlag();
      });

      it('should call cancelUpload', function () {
        expect(scope.cancelUpload).toBeDefined();
        scope.cancelUpload();
      });

    });
  });
})();
