(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('PromoteToAppealAdminModalController', function ($scope, $log, ngDialog, HttpFactory, $timeout, $filter, CONSTANTS, items, toastr, $rootScope, $http, $sce, $window) {
     
      var workerNumber, appUserRole, appUserIdentiifier, lockControlNumber;
      $scope.stepsComplete = [
        false, false, false
      ];
      $scope.screen=0;
      $scope.continueButtonText = "Continue";
      $scope.userInfo = $rootScope.userInfo;

      $scope.disableSaveButton=true;
      var scope = angular.element(document.getElementById('mainTabId')).scope();
      $rootScope.sharedItems = items;
      $scope.pdfShared = $rootScope.pdfRefresh;
      $scope.show = true;
      $scope.uploadFile = true;
      $scope.disableUplaod = true;
      $scope.cancelVd = true;
      $scope.disableeWFButton=false;
      $scope.ngrAssignmentCompleteValue = false;
      $scope.dockType=null;
      $scope.status1 = {};
      $scope.status1.open = false;
      if (!$scope.userInfo) {
        $scope.userInfo = {
          displayName: $window.sessionStorage.getItem("workerNumber"),
          userId: $window.sessionStorage.getItem("workerNumber")
        };
      }

      

     $scope.items = items;
      $scope.refreshGrid = false;
      $scope.showPanelingFooter = false;
      $scope.showRehearingFooter = false;
      $scope.isMergedCase = false;
      $rootScope.isMergedCase = false;
      $scope.originaldata = angular.copy($scope.items);
//     
      $scope.closedlg = function () {
        ngDialog.closeAll();

      };
      $scope.data = $scope.items[0].globalMetaData;
      $scope.data.caseNumber="--";
      $scope.data.caseTypes = [];
      $scope.mergedApplListForToastr;
      $scope.data.caseTypes.push($scope.data.caseType); 

      function setContinueButtonStatus() {
        $scope.disableSaveButton=true;
      }

       $scope.getPromoteAppeal = function () {
         HttpFactory.getActions(CONSTANTS.URL.GET_PROMOTE + $scope.data.applicationNumber)
          .then(function (successResponse) {
              lockControlNumber = successResponse.data.caseDetailsData[0].preAppeal.audit.lockControlNumber;
              $scope.appealAssignment = successResponse.data.caseDetailsData[0].appealAssignment;
              $scope.promoteData = successResponse.data.caseDetailsData[0].preAppealInfo;
              $scope.promoteData.appealForwardingFeePaid = $scope.promoteData.appealForwardingFeePaid ? 'Yes' : 'No';
              $scope.promoteData.respondentBriefFeePaid = $scope.promoteData.respondentBriefFeePaid ? 'Yes' : 'No';
              $scope.promoteData.replyBriefTimelyFiledIndicator = $scope.promoteData.replyBriefTimelyFiledIndicator ? 'Yes' : 'No';
              $scope.promoteData.replyBriefDueDateExpIndicator = $scope.promoteData.replyBriefDueDateExpIndicator ? 'Yes' : 'No';
              $scope.promoteData.petitionsFiledIndicator = $scope.promoteData.petitionsFiledIndicator ? 'Yes' : 'No';
            },
            function (failureResponse) {
              $log.info(failureResponse);
            });
       };
      $scope.getPromoteAppeal(); 
      $scope.getExternalUrls = function () {
        HttpFactory.getActions(CONSTANTS.URL.EXTERNALURLS)
          .then(function (successResponse) {
            $scope.externalUrls = [];
            $scope.externalUrlsForAssignment = [];
            for (var key in successResponse.data) {
              var url;
              if (key !== "Open in PTOZone" && key !== "ptabReadOnlyUser" && key !== "allowedResourceObjectList" && key !== "ptabDueDateNonEditableUser" && key !== "ptabDefaultRefreshTime") {
                url = {
                  description: key,
                  url: successResponse.data[key]
                };
                $scope.externalUrls.push(url);
              }
              if (key === "Open in PTOZone") {
                url = {
                  description: key,
                  url: successResponse.data[key]
                };
                $scope.externalUrlsForAssignment.push(url);
              }
            }

          }, function () {
            // Empty response is ok
          });
      };
      $scope.getExternalUrls();

      $scope.warningBeforePromote = function () {
 //       $scope.appealAssignment.fromWorkQueue = true;
        ngDialog.open({
          template: 'app/importManager/warningBeforePromote.html',
          controller: 'WarningBeforePromoteController',
          width: '40%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            promoteToAppealWarning: function () {
              return $scope.appealAssignment;
            }
          }
        }).closePromise.then(function (promoteToAppealWarning) {
          if (promoteToAppealWarning.value) {
            $scope.showPromoteTypes(promoteToAppealWarning.value);
          }
        }, function () {
          // Cancel button is clicked.
        });
      };

            /* istanbul ignore next */
            $scope.showPromoteTypes = function () {
              $scope.appealAssignment.fromWorkQueue = true;
              ngDialog.open({
                template: 'app/importManager/promoteTypesSelect.html',
                controller: 'PromoteTypesSelectController',
                width: '48%',
                showClose: false,
                closeByEscape: false,
                closeByDocument: false,
                resolve: {
                  showPromoteTypesValues: function () {
                    return $scope.appealAssignment;
                  }
                }
              }).closePromise.then(function (showPromoteTypesValues) {
                if (showPromoteTypesValues.value) {
                  $scope.openPromoteToAppeal(showPromoteTypesValues.value);
                }
              }, function () {
                // Cancel from modal
              });
      };

      $scope.goToNext = function(data) {
        $rootScope.sharedItems=[];
          $rootScope.sharedItems.push(data.value.currentAssignment);
          $rootScope.sharedItems[0].globalMetaData= $scope.data;
console.info("Got here to adamin");
        $scope.stepsComplete[0]=true;
        $scope.disableSaveButton=false;
        $scope.data.caseNumber = data.value.currentAssignment.appealNumber;
      };


      $scope.gotoChecklist = function(data) {
        console.info("Here is checklist");
        $scope.updateAssignment = data;
        $scope.stepsComplete[1]=true;
        $scope.disableSaveButton=false;
      };

      $scope.openPromoteToAppeal = function () {
        $scope.getRole();
        $scope.promoteInfo = $scope.appealAssignment;
        $scope.promoteInfo.ptaAssignment = true;
        $scope.promoteInfo.workerNumber = $window.sessionStorage.getItem("workerNumber");
        // ngDialog.close();
        ngDialog.open({
          template: 'app/importManager/promoteToAppeal.html',
          controller: 'PromoteToAppealController',
          width: '60%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          scope: $scope,
          resolve: {
            promoteToAppeal: function () {
              return $scope.promoteInfo;
            },
            appUserInfo: function () {
              return appUserRole;
            },
            appUserIdentiifier: function () {
              return appUserIdentiifier;
            }
          }
        });
      };

      $scope.getRole = function () {
        HttpFactory.getActions(CONSTANTS.URL.ROLETYPE)
          .then(function (successResponse) {
              $scope.myRole = successResponse.data;
            },
            function (failureResponse) {
              $log.info(failureResponse);
            });
      };

      $scope.next = function() {
        if ($scope.screen===2) {
          ngDialog.closeAll();
        }
        $scope.screen++;
        $scope.disableSaveButton=true;
        if ($scope.screen===2) {
          $scope.getReviewCheck();
          $scope.continueButtonText = "Done";
        }
      }

      /*review checklist */
      $scope.getReviewCheck = function () {
      HttpFactory.getActions(CONSTANTS.URL.REVIEWCHECKLIST)
        .then(function (successResponse) {

          $scope.checkList = successResponse.data;
          $scope.valueText;
          angular.forEach($scope.checkList, function (value, key) {
            if (value.valueText.indexOf(';') !== -1) {

              var check = value.valueText.indexOf(';');
              $scope.assignmentTypes = [];
              $scope.assignmentTypes.push(value.valueText.substring(0, check), value.valueText.substring(check + 1));

            }

          });
        }, function (failureResponse) {
          return failureResponse;
        });
      };

      $scope.checkListDrop = function (type) {

        if (angular.isUndefined(type)) {
          $scope.typeSeclected = $scope.assignmentTypes[0];
        } else {
          $scope.typeSeclected = type;
        }
      };
      $scope.getEwfDetails = function () {
        HttpFactory.getActions("/case-information/phases?serialNumber=" + $scope.data.applicationNumber + "&appealNumber=" + $scope.data.caseNumber)
          .then(function (successResponse) {

            $scope.casePhase = successResponse.data;
            $scope.eWFptabReceiptDate = $scope.dateConverter($scope.casePhase.preAppealInfo.ptabReceivedDate);


            $scope.eWFCaseType = $scope.casePhase.masterDocketInfo.caseType;
            $scope.eWFDocketingNoticeDate = $scope.dateConverter($scope.casePhase.masterDocketInfo.docketingNoticeDate);

          }, function (failureResponse) {
            toastr.error(failureResponse, {
              iconClass: 'toast-danger'
            });
          });
      };

      $scope.dateConverter = function (recievedDate) {
        if (recievedDate != null) {
          return new Date(recievedDate).toLocaleDateString();
        } else {
          return null;
        }
      };

      $scope.reviewCheckValidation = function () {
        if ($scope.updateAssignment.noteText === undefined) {
          $scope.updateAssignment.noteText = '';
        }

        if ($scope.updateAssignment.noteText.trim().length <= 0) {
          $scope.showNoteError = true;
          $scope.review = false;
          return;
        } else {
          $scope.showNoteError = false;
          $scope.review = true;
        }
      };
      $scope.submitReviewCheck = function (valueText, typeSeclected) {
        $scope.reviewCheckValidation();
        if (angular.isUndefined(typeSeclected) || valueText.indexOf(';') < 0) {
          typeSeclected = valueText;
        } else if (valueText.indexOf(';') >= 0) {

        }
        $scope.review = true;
        if (valueText === 'COMPLIANT_WITH_ISSUES') {

          if (!$scope.showNoteError) {
            $scope.updateAssignment.completionCode = valueText;
          } else {
            $scope.review = false;
            return;
          }
        } else {
          $scope.updateAssignment.completionCode = typeSeclected;
        }
        $scope.updateAssignment.assignmentCompletionDt = new Date().getTime();
        if ($scope.review) {
          $scope.assignmentUpdateSave(true);
        }
      };

      $scope.assignmentUpdateSave = function (saveflag) {
        if ($scope.OnBlurProgress) {
          return;
        }
        if (new Date($scope.dueDatetoCheckbusinessVallidation).getTime() != new Date($scope.updateAssignment.dueDate).getTime()) {
          $scope.validateBusinnessdateSelected(saveflag);
        } else {
          $scope.updateAssignmentcall(saveflag);
        }
      };

            /* istanbul ignore next : toaster error */
      $scope.validateBusinnessdateSelected = function (saveflag) {
        $scope.readyToSaveBussinessDate = false;
        var previousDate = new Date($scope.updateAssignment.dueDate).setHours(0, 0, 0, 0);
        return HttpFactory.getActions(CONSTANTS.URL.HOLIDAYCHECKS + "selectedDate=" + new Date($scope.updateAssignment.dueDate).setHours(0, 0, 0, 0))
          .then(function (successResponse) {
            var ResponseDate = successResponse;
            if (ResponseDate.data.isValid !== true) {

              ngDialog.open({
                template: 'app/components/widgets/assignments/src/dateVerification.html',
                width: '25%',
                controller: 'dateVerificationController',
                controllerAs: 'vm',
                showClose: false,
                closeByEscape: false,
                closeByDocument: false,
                resolve: {
                  prevDate: function () {
                    return previousDate;
                  }
                }
              }).closePromise.then(function (modifiedDate) {
                if (angular.isNumber(modifiedDate.value)) {
                  $scope.updateAssignment.dueDate = modifiedDate.value;
                  $scope.readyToSaveBussinessDate = true;
                  $scope.updateAssignmentcall(saveflag);
                } else {
                  document.getElementById("reportDueDate").focus();
                  $scope.updateAssignment.dueDate = previousDate;
                }
              });

            } else {
              $scope.readyToSaveBussinessDate = true;
              $scope.updateAssignmentcall(saveflag);
            }
          },
            function (failureResponse) {
              return failureResponse;
            });
      };

            /* istanbul ignore next : toaster error */
            $scope.validateBusinnessdateSelected = function (saveflag) {
              $scope.readyToSaveBussinessDate = false;
              var previousDate = new Date($scope.updateAssignment.dueDate).setHours(0, 0, 0, 0);
              return HttpFactory.getActions(CONSTANTS.URL.HOLIDAYCHECKS + "selectedDate=" + new Date($scope.updateAssignment.dueDate).setHours(0, 0, 0, 0))
                .then(function (successResponse) {
                  var ResponseDate = successResponse;
                  if (ResponseDate.data.isValid !== true) {
      
                    ngDialog.open({
                      template: 'app/components/widgets/assignments/src/dateVerification.html',
                      width: '25%',
                      controller: 'dateVerificationController',
                      controllerAs: 'vm',
                      showClose: false,
                      closeByEscape: false,
                      closeByDocument: false,
                      resolve: {
                        prevDate: function () {
                          return previousDate;
                        }
                      }
                    }).closePromise.then(function (modifiedDate) {
                      if (angular.isNumber(modifiedDate.value)) {
                        $scope.updateAssignment.dueDate = modifiedDate.value;
                        $scope.readyToSaveBussinessDate = true;
                        $scope.updateAssignmentcall(saveflag);
                      } else {
                        document.getElementById("reportDueDate").focus();
                        $scope.updateAssignment.dueDate = previousDate;
                      }
                    });
      
                  } else {
                    $scope.readyToSaveBussinessDate = true;
                    $scope.updateAssignmentcall(saveflag);
                  }
                },
                  function (failureResponse) {
                    return failureResponse;
                  });
            };

            $scope.checkListRadio = function (valueText) {
              $scope.showNoteError = false;
              $scope.showDropDown = false;
              if (valueText) {
                if (valueText.indexOf(';') > -1) {
                  $scope.showDropDown = true;
                }
              }
            };
      
            $scope.showNoteError = false;

            $scope.updateAssignmentcall = function (saveflag) {
       
              if ($scope.updateAssignment.assignmentCompletionDt === null) {
                $scope.readyToSavecompletiondt = true;
                $scope.updateAssignment.completionDate = $scope.updateAssignment.assignmentCompletionDt;
              } else {
                $scope.updateAssignment.completionDate = new Date($scope.updateAssignment.assignmentCompletionDt).getTime();
              }
              $scope.updateAssignment.dueDate = new Date($scope.updateAssignment.dueDate).getTime();
      
              if ($scope.fileInfo) {
                $scope.artifactName = $scope.fileInfo.name.replace(/\"/g, "")
              } else if (document.getElementById("fileName")) {
                $scope.artifactName = document.getElementById("fileName").value;
              }
              if($scope.artifactName ==undefined){
                $scope.artifactName = null;
              }
      if( $scope.artifactName ==undefined){
      $scope.artifactName = null;
      }
      if($scope.ngrAssignmentCompleteValue) {
      $scope.updateAssignment.completionCode = "Complete";
      $scope.updateAssignment.completionDate = new Date().getTime();
      }
              $scope.updateAssignmntdata = {
                "assignmentType": $scope.updateAssignment.assignmentType,
                "assignee": $scope.updateAssignment.assignee,
                "serialNumber": $scope.updateAssignment.serialNumber,
                "title": $scope.updateAssignment.title,
                "description": $scope.updateAssignment.description,
                "dueDate": $scope.updateAssignment.dueDate,
                "completionDate": $scope.updateAssignment.completionDate,
                "completionCode": $scope.updateAssignment.completionCode,
                "caseType": $scope.updateAssignment.caseType,
                "appealNumber": $scope.updateAssignment.appealNumber,
                "sequenceNumber": $scope.updateAssignment.sequenceNumber,
                "notes": $scope.updateAssignment.noteText,
                "priorityIndicator": ($scope.updateAssignment.priorityIndicator) ? 'Y' : 'N',
                "assignmentIdentifier": $scope.updateAssignment.assignmentIdentifier,
                "assignor": $scope.updateAssignment.assignor,
                "activeIndicator": $scope.updateAssignment.activeIndicator,
                "artifactTitleName": $scope.artifactName,
                "pageNumberQuantity":$scope.updateAssignment.pageNumberQuantity,
                "audit": {
                  "createUserIdentifier": $scope.updateAssignment.createUserIdentifier,
                  "lastModifiedUserIdentifier": $scope.updateAssignment.assignmentLastModifiedUids,
                  "lockControlNumber": 0,
                  "createTimestamp": $scope.updateAssignment.assignmentCreateTs,
                  "lastModifiedTimestamp": new Date().getTime()
                }
              };
              // console.log("Update assignment data:", $scope.updateAssignmntdata);
              $scope.updateAssgnmnt($scope.updateAssignmntdata, saveflag);
            };

            $scope.updateAssgnmnt = function (data, saveflag) {
   //           data.caseType = "APPEAL";
              data.assignmentType = "RC";
              if (data.caseType === "EWF") {
                if (!$scope.ewfCompletedFlag && $scope.updateAssignment.assignmentCompletionDt != null && angular.isDefined($scope.updateAssignment.assignmentCompletionDt)) {
                  ngDialog.open({
                    template: "app/components/widgets/assignments/src/eWFNotCompleted.html",
                    scope: $scope,
                    width: '30%',
                    showClose: false,
                    closeByEscape: false,
                    closeByDocument: false
                  });
                  return;
                }
              }
             
                HttpFactory.putActions(CONSTANTS.URL.UPDATE_ASSIGNMENT, data)
                  .then(function (successResponse) {
                    $scope.updateAssignment.assignmentLockControlNo = successResponse.data.audit.lockControlNumber;
                    $scope.isUpdateSaved = true;
                    $scope.disablesave = true;
      
                    toastr.clear();
      
                    toastr.error(successResponse.data.message, {
                      iconClass: 'toast-success'
                    });
      
                    if ($scope.isMergedCase) {
                      toastr.success(successResponse.data.title + " assignments for " + $scope.mergedApplListForToastr + " have been closed.", {
                        iconClass: 'toast-success'
                      });
                    }
      
                    // "<Assignment title> assignments for <list of merged applications> have been closed
      
                    $scope.updateAssignment.noteText = "";
                    if (angular.isUndefined($scope.updateAssignment.assignmentCompletionDt) || $scope.updateAssignment.assignmentCompletionDt === null) {
                      $scope.updateAssignment.toDisable = false;
                      $scope.isCompletiondate = false;
      
                    } else {
                      $scope.updateAssignment.toDisable = true;
                      $scope.isCompletiondate = true;
                      $scope.checkCompletiondate = function () {
                        return $scope.isCompletiondate;
                      };
                    }
      
                    $scope.finished=true;
                    $scope.disableSaveButton=false;
                  }, function (failureResponse) {
                    $scope.disableeWFButton=false;
                    toastr.clear();
                    toastr.warning(failureResponse.data.message, {
                      iconClass: 'toast-warning'
                    });
                
      
                  });
              
            };
    });
})();
