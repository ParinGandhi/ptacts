(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .controller('PanelSaveModalController', function (ngDialog, flags, $log, completionCode, panelToCreate, toastr, HttpFactory, CONSTANTS, $window) {
      var vm = this;
      vm.flags = flags;

      vm.closeCurrentDialog = function () {
        ngDialog.close(lastDialog());
      };


      vm.saveChanges = function () {
        ngDialog.close(lastDialog(), true);
      };

      vm.saveAndSubmit = function () {
        if (!panelToCreate.judgePanel.panelDate) {
          var dateFlags = {
            "showInitialMessage": true,
            "showNoDateMessage": false,
            "showConfirmSubmitMessage": false
          };
          ngDialog.close(lastDialog());
          ngDialog.open({
            template: "app/components/widgets/assignments/src/panelingMessageModal.html",
            controller: 'PanelingMessageModalController',
            controllerAs: 'vm',
            width: '25%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              createPanelData: function () {
                return panelToCreate;
              },
              flags: function () {
                return dateFlags;
              },
              circulationInProcess: function () {
                return null;
              }
            }
          }).closePromise.then(function (response) {
            if (response.value) {
              $log.info(response.value);
            }
          });
        } else {
          vm.submitPanel();
        }
      };

      vm.submitPanel = function () {
        panelToCreate.panelAssignment.completionCode = completionCode;
        panelToCreate.panelAssignment.completionDate = new Date().getTime();

        HttpFactory.postActions(CONSTANTS.URL.CREATE_JUDGE_PANEL, panelToCreate)
          .then(function (successResponse) {

            $window.sessionStorage.setItem("panelExists", true);
            toastr.success(CONSTANTS.TOASTER.updatePanel, {
              iconClass: 'toast-success'
            });
            ngDialog.closeAll(false);
          }, function (failureResponse) {
            // intentional
          });
      };

      function lastDialog() {
        var openDialogs = ngDialog.getOpenDialogs();
        return openDialogs[openDialogs.length - 1];
      }



    });
})();
