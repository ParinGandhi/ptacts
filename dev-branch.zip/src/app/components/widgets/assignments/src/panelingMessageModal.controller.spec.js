(function () {
  'use strict';

  describe('PanelingMessageModalController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['close', 'closeAll', 'getOpenDialogs']);
    var controller, scope, $rootScope;
    var timeout, createPanelData, flags, circulationInProcess;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;

    flags = {
      showInitialMessage: false,
      showNoDateMessage: true,
      showConfirmSubmitMessage: false
    }

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);



      controller = $controller('PanelingMessageModalController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory,
        createPanelData: createPanelData,
        flags: flags,
        circulationInProcess:circulationInProcess

      });
    }));

    describe('PanelingMessageModalController ', function () {

      it('it should call selectOk ', function () {
        expect(controller['selectOk']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.selectOk();
      });

      it('it should call selectNo ', function () {
        expect(controller['selectNo']).toBeDefined();
        controller.selectNo();
      });

      it('it should call selectYes ', function () {
        expect(controller['selectYes']).toBeDefined();
        controller.selectYes();
      });

      it('it should call cancelSubmitPanel ', function () {
        expect(controller['cancelSubmitPanel']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.cancelSubmitPanel();
      });

      // it('it should call submitPanel ', function () {
      //   var successResponse = {
      //     data: {

      //     }
      //   }
      //   expect(controller['submitPanel']).toBeDefined();
      //   controller.submitPanel();

      //   // HttpFactoryDeferred.resolve(successResponse);
      //   // $rootScope.$apply();
      // });

      // it('it should call submitPanel ', function () {
      //   var failureResponse = {
      //     data: {

      //     }
      //   }
      //   expect(controller['submitPanel']).toBeDefined();
      //   controller.submitPanel();

      //   HttpFactoryDeferred.reject(failureResponse);
      //   $rootScope.$apply();
      // });

    });
  });
})();
