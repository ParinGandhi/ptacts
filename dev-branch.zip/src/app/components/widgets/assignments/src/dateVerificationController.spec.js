(function () {
  'use strict';

  describe('dateVerificationController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close']);
    var prevDate;
    var controller, scope, $rootScope;
    var timeout;

    prevDate = {
      'noteText': 'hi'
    }

    beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_) {
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      timeout = _$timeout_;


      controller = $controller('dateVerificationController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        prevDate: prevDate
      });
    }));

    describe('dateVerificationController ', function () {


      it('it should call closeDialog ', function () {

        var ngDialogArray = [ngDialog, ngDialog];
        expect(ngDialog.close).toBeDefined();
        expect(controller['closeDialog']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        controller.closeDialog();
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog);

        expect(ngDialog.close).toBeDefined();
        expect(controller['closeDialog']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.closeDialog();
        expect(ngDialog.close).toHaveBeenCalledWith();

      });

      it('it should call revertAllChanges ', function () {

        var ngDialogArray = [ngDialog, ngDialog];
        expect(ngDialog.close).toBeDefined();
        expect(controller['revertAllChanges']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        controller.revertAllChanges();
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog);

        expect(ngDialog.close).toBeDefined();
        expect(controller['revertAllChanges']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.revertAllChanges();
        expect(ngDialog.close).toHaveBeenCalledWith();

      });


    });
  });
})();
