(function () {
  'use strict';

  describe('CancelUpdateAssignmentController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close']);
    var controller, scope, $rootScope;
    var timeout, updateAssign, currentElement;


    beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_) {
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      timeout = _$timeout_;

      controller = $controller('CancelUpdateAssignmentController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        updateAssign: updateAssign,
        currentElement: currentElement

      });
    }));

    describe('CancelUpdateAssignmentController ', function () {


      it('it should call closeDialog ', function () {

        var ngDialogArray = [ngDialog, ngDialog];
        var originalData = 'no';
        expect(ngDialog.close).toBeDefined();
        expect(controller['closeDialog']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        controller.closeDialog();
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog, originalData);

        expect(ngDialog.close).toBeDefined();
        expect(controller['closeDialog']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.closeDialog();
        expect(ngDialog.close).toHaveBeenCalledWith();

      });

      it('it should call revertAllChanges if', function () {

        scope.events = {
          currentTarget: {
            textContent: 'Assignment info'
          }
        }

        scope.updateAssign = {
          'assignContent': false,
          'disableDelete': false
        }
        var ngDialogArray = [ngDialog, ngDialog];
        var originalData = 'yes';
        expect(ngDialog.close).toBeDefined();
        expect(controller['revertAllChanges']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        controller.revertAllChanges(scope.events, scope.updateAssign);
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog, originalData);

        expect(ngDialog.close).toBeDefined();
        expect(controller['revertAllChanges']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.revertAllChanges(scope.events, scope.updateAssign);
        expect(ngDialog.close).toHaveBeenCalledWith();

      });

      it('it should call revertAllChanges else if', function () {

        scope.events = {
          currentTarget: {
            textContent: 'Docketing notice'
          }
        }
        scope.updateAssign = {
          assignContent: true,
          disableDelete: true
        }

        var ngDialogArray = [ngDialog, ngDialog];
        var originalData = 'yes';
        expect(ngDialog.close).toBeDefined();
        expect(controller['revertAllChanges']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        controller.revertAllChanges(scope.events, scope.updateAssign);
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog, originalData);

        expect(ngDialog.close).toBeDefined();
        expect(controller['revertAllChanges']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.revertAllChanges(scope.events, scope.updateAssign);
        expect(ngDialog.close).toHaveBeenCalledWith();

      });

      // it('it should call revertAllChanges else', function () {

      //   scope.events = {
      //     currentTarget: {
      //       textContent: 'other'
      //     }
      //   }
      //   scope.updateAssign = {}
      //   // expect(ngDialog.closeAll).toBeDefined();
      //   // expect(controller['revertAllChanges']).toBeDefined();
      //   // controller.revertAllChanges();
      //   // expect(ngDialog.closeAll).toHaveBeenCalledWith();


      //   var ngDialogArray = [ngDialog, ngDialog];
      //   var currentElement = 'yes';
      //   // expect(ngDialog.close).toBeDefined();
      //   expect(ngDialog.closeAll).toBeDefined();
      //   expect(controller['revertAllChanges']).toBeDefined();
      //   // ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
      //   controller.revertAllChanges(currentElement);
      //   // expect(ngDialog.close).toHaveBeenCalledWith(ngDialog, originalData);
      //   expect(ngDialog.closeAll).toHaveBeenCalled();

      //   // expect(ngDialog.close).toBeDefined();
      //   // expect(ngDialog.closeAll).toBeDefined();
      //   // expect(controller['revertAllChanges']).toBeDefined();
      //   // ngDialog.getOpenDialogs.and.returnValue(ngDialog);
      //   // controller.revertAllChanges(scope.events, scope.updateAssign);
      //   // expect(ngDialog.close).toHaveBeenCalledWith();
      //   // expect(ngDialog.closeAll).toHaveBeenCalled();

      // });


    });
  });
})();
