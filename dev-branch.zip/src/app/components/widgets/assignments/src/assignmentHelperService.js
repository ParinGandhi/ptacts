'use strict';
angular.module('ptabe2e').factory('AssignmentHelperService', function (HttpFactory, CONSTANTS) {

  var assignmentHelperService = {
    createAssignment: createAssignment,
    getCreateAssignmentObject: getCreateAssignmentObject,
    getUpdateAssignmentObject: getUpdateAssignmentObject,
    getDefaultUser:getDefaultUser,
    checkPetitionInProgress:checkPetitionInProgress,
    getDocument:getDocument,
    getUserInfo:getUserInfo,
    calUpdatePopulation:calUpdatePopulation
  };

  function checkPetitionInProgress(serialNumber, appealNumber) {
    return HttpFactory.getActions("/petition/check-if-petition-inprocess?serialNumber=" + serialNumber + "&appealNumber=" + appealNumber).then(function (successResponse) {
        return successResponse;
    }, function (failureResponse) { 
      return null;
    });
  }
  
  function getDocument(serialNumber) {
    return HttpFactory.getActions("/petition?serialNumber=" + serialNumber).then(function (successResponse) {
      var startIndex = successResponse.data.fileName.indexOf(serialNumber)+9; 
      var verifiedDocument = {
        fileName:successResponse.data.fileName.substring(startIndex),
        fileLink: successResponse.data.fileName
      };
      return verifiedDocument;
    }, function (failureResponse) { 
      return null;
    });
  }

  function calUpdatePopulation(createAssignment) {
      //petition/update-proceeding-population
     return  HttpFactory.putActions("/petition/update-proceeding-population", createAssignment)
      .then(function (successResponse) {
        return null;
     }, function (failureResponse) {
       return failureResponse;
     });
  }

  function getUserInfo(loginId) {
    HttpFactory.getActions(CONSTANTS.URL.DEAFULTS + loginId)
    .then(function (successResponse) {
      return successResponse.data.caseDetailsData;
    }, function () {
      // Empty results are ok.
    });  
  }

  function getDefaultUser(url) {
  
      return HttpFactory.getActions(url)
      .then(function (assigneeListSuccess) {
        
        if (assigneeListSuccess.data[0].descriptionText.indexOf("~")>=0) {
          var tempUserId = assigneeListSuccess.data[0].descriptionText.indexOf("~");

          var  defaultUserId = assigneeListSuccess.data[0].descriptionText.substring(0, tempUserId);
          var splicedUser = angular.copy(assigneeListSuccess.data[0]);
 
          var assigneeNumber = splicedUser.descriptionText.substring(tempUserId+1);
          splicedUser.descriptionText=defaultUserId;
          splicedUser.valueText = assigneeNumber;
          return splicedUser;
        }

       return assigneeListSuccess.data[0];
      }, function (assigneeListFailure) {
        console.info('assigneeListFailure: ', assigneeListFailure);
        return null;
      });

  }

  function getUpdateAssignmentObject(updateAssignment) {
    if (updateAssignment.assignmentCompletionDt === null) {
 
      updateAssignment.completionDate = updateAssignment.assignmentCompletionDt;
    } else {
      updateAssignment.completionDate = new Date(updateAssignment.assignmentCompletionDt).getTime();
    }
    updateAssignment.dueDate = new Date(updateAssignment.dueDate).getTime();

    

  updateAssignment.completionDate = new Date().getTime();
  var updateAssignmntdata = {
      "assignmentType": updateAssignment.assignmentType,
    "assignee": updateAssignment.assignee,
      "serialNumber": updateAssignment.serialNumber,
      "title": updateAssignment.title,
      "description": updateAssignment.description,
      "dueDate": updateAssignment.dueDate,
      "completionDate": updateAssignment.completionDate,
      "completionCode": "PETITION",
      "caseType": updateAssignment.caseType,
      "appealNumber": updateAssignment.appealNumber,
      "sequenceNumber": updateAssignment.sequenceNumber,
      "notes": updateAssignment.noteText,
      "priorityIndicator": (updateAssignment.priorityIndicator) ? 'Y' : 'N',
      "assignmentIdentifier": updateAssignment.assignmentIdentifier,
      "assignor": updateAssignment.assignor,
      "activeIndicator": updateAssignment.activeIndicator,
      "pageNumberQuantity":updateAssignment.pageNumberQuantity,
      "audit": {
        "createUserIdentifier": updateAssignment.createUserIdentifier,
        "lastModifiedUserIdentifier": updateAssignment.assignmentLastModifiedUids,
        "lockControlNumber": updateAssignment.assignmentLockControlNo,
        "createTimestamp": updateAssignment.assignmentCreateTs,
        "lastModifiedTimestamp": new Date().getTime()
      }
    };
    return updateAssignmntdata;
  }

  function getCreateAssignmentObject(updateAssignment, nextAssignment) {
    var createAssignmentObject = {};
    createAssignmentObject.assignmentType = nextAssignment.code;
    createAssignmentObject.dueDate = (new Date()).getTime();
    createAssignmentObject.assignee = nextAssignment.assignee;
    createAssignmentObject.appealNumber = updateAssignment.appealNumber;
    createAssignmentObject.serialNumber = updateAssignment.serialNumber;
    createAssignmentObject.priorityIndicator="N";
    createAssignmentObject.sequenceNumber=updateAssignment.sequenceNumber+1;
    createAssignmentObject.title=nextAssignment.title;
    createAssignmentObject.audit = {
      "createUserIdentifier":updateAssignment.assignmentLastModifiedUids,
      "lastModifiedUserIdentifier":updateAssignment.assignmentLastModifiedUids,
    };
    return createAssignmentObject;
  }

  function createAssignment(createAssignment) {
    return HttpFactory.postActions(CONSTANTS.URL.CREATEASSIGNMENT, createAssignment)
    .then(function (successResponse) {
     return successResponse;
    }, function (failureResponse) {
     return failureResponse;
    });
  }

  



  return assignmentHelperService;
});
