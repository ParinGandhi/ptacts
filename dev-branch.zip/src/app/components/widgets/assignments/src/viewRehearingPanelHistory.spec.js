(function () {
  'use strict';

  describe('ViewRehearingPanelHistoryController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll']);
    var controller, scope, $rootScope;
    var timeout;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;
    var panelHistory;


    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);

      panelHistory = {
        "judgePanel": [{
            "reconsiderSequenceNumber": 0,
            "audit": {
              "createUserIdentifier": null,
              "createdUserName": null,
              "lockControlNumber": null,
              "lastModifiedUserIdentifier": "Johnson, Toi ",
              "lastModifiedUserName": null,
              "lastModifiedTimestamp": 1355979600000,
              "createTimestamp": null
            },
            "panelDate": 1355979600000,
            "panelToBeCreated": [{
                "assignedDate": 1355979600000,
                "activeIndicator": "Y",
                "panelSequenceNumber": 1,
                "identifier": "6143",
                "panelRank": 0,
                "apjStatus": "Paneled",
                "panelMember": "Patent Attorney",
                "decisionCategoryName": "Rehearing",
                "lastModifiedUserId": "Johnson, Toi ",
                "location": "D1R2",
                "panelName": "ADAMS, DONALD ",
                "lastModifiedTs": 1355979600000
              },
              {
                "assignedDate": 1355979600000,
                "activeIndicator": "Y",
                "panelSequenceNumber": 1,
                "identifier": "6024",
                "panelRank": 3,
                "apjStatus": "Paneled",
                "panelMember": "APJ3",
                "decisionCategoryName": "Rehearing",
                "lastModifiedUserId": "Johnson, Toi ",
                "location": "D1R2",
                "panelName": "QUINN, MIRIAM L.",
                "lastModifiedTs": 1355979600000
              }
            ]
          },
          {
            "reconsiderSequenceNumber": 1,
            "audit": {
              "createUserIdentifier": null,
              "createdUserName": null,
              "lockControlNumber": null,
              "lastModifiedUserIdentifier": "Johnson, Toi ",
              "lastModifiedUserName": null,
              "lastModifiedTimestamp": 1355979600000,
              "createTimestamp": null
            },
            "panelDate": 1355979600000,
            "panelToBeCreated": [{
                "assignedDate": 1355979600000,
                "activeIndicator": "Y",
                "panelSequenceNumber": 1,
                "identifier": "6143",
                "panelRank": 0,
                "apjStatus": "Paneled",
                "panelMember": "Patent Attorney",
                "decisionCategoryName": "Rehearing",
                "lastModifiedUserId": "Johnson, Toi ",
                "location": "D1R2",
                "panelName": "ADAMS, DONALD ",
                "lastModifiedTs": 1355979600000
              },
              {
                "assignedDate": 1355979600000,
                "activeIndicator": "Y",
                "panelSequenceNumber": 1,
                "identifier": "6024",
                "panelRank": 3,
                "apjStatus": "Paneled",
                "panelMember": "APJ3",
                "decisionCategoryName": "Rehearing",
                "lastModifiedUserId": "Johnson, Toi ",
                "location": "D1R2",
                "panelName": "QUINN, MIRIAM L.",
                "lastModifiedTs": 1355979600000
              }
            ]
          },
          {
            "reconsiderSequenceNumber": 2,
            "audit": {
              "createUserIdentifier": null,
              "createdUserName": null,
              "lockControlNumber": null,
              "lastModifiedUserIdentifier": "Johnson, Toi ",
              "lastModifiedUserName": null,
              "lastModifiedTimestamp": 1355979600000,
              "createTimestamp": null
            },
            "panelDate": 1355979600000,
            "panelToBeCreated": [{
                "assignedDate": 1355979600000,
                "activeIndicator": "Y",
                "panelSequenceNumber": 1,
                "identifier": "6143",
                "panelRank": 0,
                "apjStatus": "Paneled",
                "panelMember": "Patent Attorney",
                "decisionCategoryName": "Rehearing",
                "lastModifiedUserId": "Johnson, Toi ",
                "location": "D1R2",
                "panelName": "ADAMS, DONALD ",
                "lastModifiedTs": 1355979600000
              },
              {
                "assignedDate": 1355979600000,
                "activeIndicator": "Y",
                "panelSequenceNumber": 1,
                "identifier": "6024",
                "panelRank": 3,
                "apjStatus": "Paneled",
                "panelMember": "APJ3",
                "decisionCategoryName": "Rehearing",
                "lastModifiedUserId": "Johnson, Toi ",
                "location": "D1R2",
                "panelName": "QUINN, MIRIAM L.",
                "lastModifiedTs": 1355979600000
              }
            ]
          },
          {
            "reconsiderSequenceNumber": 3,
            "audit": {
              "createUserIdentifier": null,
              "createdUserName": null,
              "lockControlNumber": null,
              "lastModifiedUserIdentifier": "Johnson, Toi ",
              "lastModifiedUserName": null,
              "lastModifiedTimestamp": 1355979600000,
              "createTimestamp": null
            },
            "panelDate": 1355979600000,
            "panelToBeCreated": [{
                "assignedDate": 1355979600000,
                "activeIndicator": "Y",
                "panelSequenceNumber": 1,
                "identifier": "6143",
                "panelRank": 0,
                "apjStatus": "Paneled",
                "panelMember": "Patent Attorney",
                "decisionCategoryName": "Rehearing",
                "lastModifiedUserId": "Johnson, Toi ",
                "location": "D1R2",
                "panelName": "ADAMS, DONALD ",
                "lastModifiedTs": 1355979600000
              },
              {
                "assignedDate": 1355979600000,
                "activeIndicator": "Y",
                "panelSequenceNumber": 1,
                "identifier": "6024",
                "panelRank": 3,
                "apjStatus": "Paneled",
                "panelMember": "APJ3",
                "decisionCategoryName": "Rehearing",
                "lastModifiedUserId": "Johnson, Toi ",
                "location": "D1R2",
                "panelName": "QUINN, MIRIAM L.",
                "lastModifiedTs": 1355979600000
              }
            ]
          },
          {
            "reconsiderSequenceNumber": 4,
            "audit": {
              "createUserIdentifier": null,
              "createdUserName": null,
              "lockControlNumber": null,
              "lastModifiedUserIdentifier": "Johnson, Toi ",
              "lastModifiedUserName": null,
              "lastModifiedTimestamp": 1355979600000,
              "createTimestamp": null
            },
            "panelDate": 1355979600000,
            "panelToBeCreated": [{
                "assignedDate": 1355979600000,
                "activeIndicator": "Y",
                "panelSequenceNumber": 1,
                "identifier": "6143",
                "panelRank": 0,
                "apjStatus": "Paneled",
                "panelMember": "Patent Attorney",
                "decisionCategoryName": "Rehearing",
                "lastModifiedUserId": "Johnson, Toi ",
                "location": "D1R2",
                "panelName": "ADAMS, DONALD ",
                "lastModifiedTs": 1355979600000
              },
              {
                "assignedDate": 1355979600000,
                "activeIndicator": "Y",
                "panelSequenceNumber": 1,
                "identifier": "6024",
                "panelRank": 3,
                "apjStatus": "Paneled",
                "panelMember": "APJ3",
                "decisionCategoryName": "Rehearing",
                "lastModifiedUserId": "Johnson, Toi ",
                "location": "D1R2",
                "panelName": "QUINN, MIRIAM L.",
                "lastModifiedTs": 1355979600000
              }
            ]
          }
        ],
        "validUserRole": "Y"
      };


      controller = $controller('ViewRehearingPanelHistoryController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        panelHistory: panelHistory,
        HttpFactory: HttpFactory

      });
    }));

    describe('ViewRehearingPanelHistoryController ', function () {

      // it('it should call createGridOptions ', function () {
      //     var panel, index=0;
      //     scope.rehearingPanelHistory = [{
      //       gridOptions: "rehearingPanelHistoryGridOptions"
      //     }]
      //     expect(scope['createGridOptions']).toBeDefined();
      //     scope.createGridOptions(panel, index);
      // });

      it('should call toggleRehearingPaneled', function () {
        scope.isRehearingPaneledOnly = true;
        expect(scope.toggleRehearingPaneled).toBeDefined();
        scope.toggleRehearingPaneled();
      });

      it('should call toggleRehearingPaneled', function () {
        scope.isRehearingPaneledOnly = false;
        expect(scope.toggleRehearingPaneled).toBeDefined();
        scope.toggleRehearingPaneled();
      });

    });
  });
})();
