(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .controller('confirmDocReviewController', function ($log, $scope, ngDialog, HttpFactory, CONSTANTS, toastr, shareAssign, rddCompletionCode, updateAssignment) {
      var scope = angular.element(document.getElementById('mainTabId')).scope();
      $scope.disableConfirm = false;
      $scope.updateAssignment = updateAssignment;
      if (scope.vm.userInfo.appUserInfo[0]) {
        $scope.appUserId = scope.vm.userInfo.appUserInfo[0].userIdentiifier;
      } else {
        $scope.appUserId = scope.vm.userInfo.appUserInfo.userIdentiifier;
      }
      $scope.caseNo = shareAssign.appealNumber;
      $scope.bNo = shareAssign.assignee;

      $scope.abandonChanges = function () {
        ngDialog.close(lastDialog(), true);
      };

      function lastDialog() {
        var openDialogs = ngDialog.getOpenDialogs();
        return openDialogs[openDialogs.length - 1];
      }

      /* istanbul ignore next: toaster error */
      $scope.assignedrole = function () {

        return HttpFactory.getActions('/user-management/users?employeeNumberText=' + shareAssign.assignee)
          .then(function (successResponse) {

              $scope.roleforassignmnt = successResponse.data[0].userRoles[0].roleCode;
              $scope.assigneId = successResponse.data[0].assigneeNumberText;
              $scope.Assignedtoforassignmnt = successResponse.data[0].assigneeFullNameText;
              $scope.myusrRole = $scope.roleforassignmnt;
              if ($scope.roleforassignmnt) {
                $scope.showAssignmrentMsgRole = false;
              }
            },
            function (failureResponse) {
              $log.info(failureResponse);
              toastr.clear();
              toastr.error(CONSTANTS.TOASTER.role, {
                iconClass: 'toast-danger'
              });
            });
      };

      /* call to submit response*/
      /* istanbul ignore next */
      $scope.confirmDecision = function () {
        $scope.disableYes = true;
        $scope.disableConfirm = true;
        if ((shareAssign.assignmentType === 'RDDD' || shareAssign.assignmentType === 'RRDD' || shareAssign.assignmentType === 'RSDD') && angular.isDefined(rddCompletionCode)) {
          $scope.selectedCompletionCode = rddCompletionCode;
        }

        shareAssign.priorityIndicator = shareAssign.priorityIndicator ? 'Y' : 'N';
        shareAssign.completionCode = $scope.selectedCompletionCode;
        $scope.currentAssignment = shareAssign;
        var data = {
          "assignmentType": shareAssign.assignmentType,
          "assignee": shareAssign.assignee,
          "serialNumber": shareAssign.serialNumber,
          "title": shareAssign.title,
          "description": shareAssign.description,
          "dueDate": shareAssign.dueDate,
          "completionDate": new Date().getTime(),
          "completionCode": $scope.selectedCompletionCode,
          "caseType": shareAssign.caseType,
          "appealNumber": shareAssign.appealNumber,
          "sequenceNumber": shareAssign.sequenceNumber,
          "priorityIndicator": shareAssign.priorityIndicator,
          "assignmentIdentifier": shareAssign.assignmentIdentifier,
          "assignor": shareAssign.assignor,
          "activeIndicator": shareAssign.activeIndicator,
          "documentReviewerName": scope.vm.userInfo.userId,
          "documentReviewDate": new Date().getTime(),
          "notes": $scope.updateAssignment.noteText,
          "audit": {
            "createUserIdentifier": scope.vm.userInfo.userId,
            "lastModifiedUserIdentifier": scope.vm.userInfo.userId,
            "lockControlNumber": shareAssign.audit.lockControlNumber,
            "createTimestamp": shareAssign.audit.createTimestamp,
            "lastModifiedTimestamp": new Date().getTime()
          }

        };

        HttpFactory.putActions(CONSTANTS.URL.UPDATE_ASSIGNMENT, data)
          .then(function (successResponse) {
            $log.info(successResponse);
            toastr.success(CONSTANTS.TOASTER.draftReview, {
              iconClass: 'toast-success'
            });

            ngDialog.closeAll('true');
          }, function (failureResponse) {
            $scope.disableYes = false;
            toastr.clear();
            toastr.error(failureResponse.data.message, {
              iconClass: 'toast-danger'
            });
          });

      };


    });
})();
