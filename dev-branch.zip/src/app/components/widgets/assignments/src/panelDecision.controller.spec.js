(function () {
  'use strict';

  describe('panelDecisionController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'close', 'open', 'getOpenDialogs']);
    var controller, scope, $rootScope;
    var timeout;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;

    var modifiedDate = "2019";
    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              userInfo: "gandhi9"
            }
          }
        }
      }
    };

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);

      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback1) {
            callback1(modifiedDate);
          }
        }
      });

      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      $rootScope.sharedItems = [{
        "serialNumber": "10300247",
        "sequenceNumber": 0,
        "appealNumber": "2019000445",
        "lifeCycle": null,
        "audit": {
          "lastModifiedTimestamp": 1541787963000,
          "lastModifiedUserIdentifier": "gandhi9",
          "createUserIdentifier": "asankineni",
          "createdUserName": "Sankineni, Archana ",
          "lastModifiedUserName": "Gandhi, Parin ",
          "createTimestamp": 1541787963426,
          "lockControlNumber": 0
        },
        "assignmentIdentifier": 1896,
        "assignmentType": "UeWF",
        "assignmentTypeIdentifier": "58",
        "assignee": "5768",
        "assignor": "5767",
        "caseType": "APPEAL",
        "priorityIndicator": "N",
        "activeIndicator": "A",
        "title": "Update eWF - 2019000445",
        "description": "Update the electronic working file (eWF) for this case, including judges' names.",
        "notes": null,
        "assignedDate": 1541787963000,
        "dueDate": 1542085200000,
        "completionDate": null,
        "palmMailedDate": null,
        "standardAssignmentType": {
          "UPDATEEWF": "Update eWF",
          "ASSIGNMENTINFO": "Assignment info"
        },
        "completedUserName": null,
        "lastModifiedUserName": null,
        "noOfActiveCases": 0,
        "assignmentStatusCode": "A",
        "assigneeRoleCode": null,
        "assigneeRoleDescription": null,
        "assignmentSequence": null,
        "reconsiderSequence": null,
        "pendingLocationText": null,
        "assignmentTypeDescription": "Update eWF",
        "completionCode": null,
        "message": null,
        "globalMetaData": {
          "applicationNumber": "10300247",
          "caseNumber": "2019000445",
          "parties": null,
          "panel": [{
              "employeeName": "GERSTENBLITH, BART A",
              "rank": 1
            },
            {
              "employeeName": "MOHANTY, BIBHU ",
              "rank": 2
            },
            {
              "employeeName": "GERSTENBLITH, BART ",
              "rank": 3
            }
          ],
          "briefHearingType": "On brief",
          "caseType": "REGULAR",
          "caseStatus": "Update eWF",
          "caseStatusDate": 1541514377000,
          "applicationStatusDescriptionText": "On Appeal -- Awaiting Decision by the Board of Appeals"
        }
      }];


      controller = $controller('panelDecisionController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory

      });
    }));

    describe('panelDecisionController ', function () {

      // it(' getActionsList  successResponse', function () {

      //   successResponse = {
      //     data: {

      //     }
      //   };
      //   expect(scope.getActionsList).toBeDefined();
      //   scope.getActionsList();

      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();
      // });

      it(' getActionsList  failureResponse ', function () {
        var failureResponse = {
          data: {}
        };

        expect(scope.getActionsList).toBeDefined();
        scope.getActionsList();

        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();

      });


      // it(' getCdd  successResponse', function () {

      //   successResponse = {
      //     data: {

      //     }
      //   };
      //   expect(scope.getCdd).toBeDefined();
      //   scope.getCdd();

      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();
      // });

      it(' getCdd  failureResponse ', function () {
        var failureResponse = {
          data: {}
        };

        expect(scope.getCdd).toBeDefined();
        scope.getCdd();

        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();

      });


      // it(' getSubCdd  successResponse', function () {

      //   successResponse = {
      //     data: {

      //     }
      //   };
      //   expect(scope.getSubCdd).toBeDefined();
      //   scope.getSubCdd();

      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();

      // });

      it(' getSpecialTypes  failureResponse ', function () {
        var failureResponse = {
          data: {}
        };

        expect(scope.getSubCdd).toBeDefined();
        scope.getSubCdd();

        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();

      });


      // it(' getCrdd  successResponse', function () {

      //   successResponse = {
      //     data: {

      //     }
      //   };
      //   expect(scope.getCrdd).toBeDefined();
      //   scope.getCrdd();

      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();
      // });

      it(' getSpecialTypes  failureResponse ', function () {
        var failureResponse = {
          data: {}
        };

        expect(scope.getCrdd).toBeDefined();
        scope.getCrdd();

        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();

      });


      // it(' getRrd  successResponse', function () {

      //   successResponse = {
      //     data: {

      //     }
      //   };

      //   expect(scope.getRrd).toBeDefined();
      //   scope.getRrd();

      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();
      // });

      it(' getRrd  failureResponse ', function () {
        var failureResponse = {
          data: {}
        };

        expect(scope.getRrd).toBeDefined();
        scope.getRrd();

        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();

      });

      // it(' getRdd  successResponse', function () {

      //   successResponse = {
      //     data: {

      //     }
      //   };

      //   expect(scope.getRdd).toBeDefined();
      //   scope.getRdd();

      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();
      // });

      it(' getRdd  failureResponse ', function () {
        var failureResponse = {
          data: {}
        };

        expect(scope.getRdd).toBeDefined();
        scope.getRdd();

        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();

      });

      // it(' getRsdd  successResponse', function () {

      //   successResponse = {
      //     data: {

      //     }
      //   };
      //   expect(scope.getRsdd).toBeDefined();
      //   scope.getRsdd();

      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();
      // });

      it(' getRsdd  failureResponse ', function () {
        var failureResponse = {
          data: {}
        };

        expect(scope.getRsdd).toBeDefined();
        scope.getRsdd();

        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();

      });


      it('it should call docReviewComplt ', function () {

        expect(scope['docReviewComplt']).toBeDefined();
        scope.docReviewComplt();


        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(1);
        var args = ngDialog.open.calls.argsFor(0);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('confirmDocReviewController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.shareAssign();
        args[0].resolve.assignedTo();
        args[0].resolve.rddCompletionCode();
        args[0].resolve.rrddCompletionCode();

      });

    });
  });
})();
