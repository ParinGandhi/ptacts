(function () {
  'use strict';

  describe('PanelUnsavedChangesController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var controller, scope, $rootScope, $CommonHelperService;
    var successResponse, failureResponse;
    var $httpBackend, spy, $q, HttpFactoryDeferred;
    var lessThanThreeApjs, completionCode, panelToCreate;

    var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'close', 'closeAll', 'getOpenDialogs']);

    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              getWidgetZone: function () {

              },
              setWidgetContentHeight: function () {

              }
            }
          }
        }
      }
    };

    beforeEach(inject(function (_$controller_, _$rootScope_, _$httpBackend_, _$q_, HttpFactory, _CommonHelperService_) {
      $q = _$q_;
      scope = _$rootScope_.$new();
      $controller = _$controller_;
      $rootScope = _$rootScope_;
      $httpBackend = _$httpBackend_;
      $CommonHelperService = _CommonHelperService_;
      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback) {
            callback({
              value: 1
            });

          }
        }
      });
      HttpFactoryDeferred = _$q_.defer();
      // spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn($CommonHelperService, 'setToastr').and.callFake(function () {
        return "toastr";
      });
      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      panelToCreate = {
        judgePanel: {
          panelDate: false
        },
        panelAssignment: {
          completionCode: 'COMPLETE',
          completionDate: new Date()
        }
      };

      controller = $controller('PanelUnsavedChangesController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory,
        lessThanThreeApjs: lessThanThreeApjs,
        completionCode: completionCode,
        panelToCreate: panelToCreate
      });
    }));

    describe('PanelUnsavedChangesController ', function () {

      it('it should call cancel ', function () {
        expect(controller.cancel).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.cancel();
      });

      it('should call abandonChanges', function () {

        expect(controller.abandonChanges).toBeDefined();
        controller.abandonChanges();

      });

      it('should call saveAndClose', function () {
        expect(controller.saveAndClose).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.saveAndClose();
      });

      it('should call submitPanelAndClose with no panel date', function () {
        panelToCreate.judgePanel.panelDate = false;
        expect(controller.submitPanelAndClose).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.submitPanelAndClose();
      });


      it('should call submitPanel with successResponse', function () {
        successResponse = "Success";
        expect(controller.submitPanel).toBeDefined();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
        controller.submitPanel();
      });


      it('should call submitPanel with failureResponse', function () {
        failureResponse = "Failure";
        expect(controller.submitPanel).toBeDefined();
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
        controller.submitPanel();
      });


    });
  });
})();
