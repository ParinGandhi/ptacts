(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('CreateAssignmentController', function ($scope, $log, ngDialog, HttpFactory, CONSTANTS, newData, initData, toastr) {
      var vm = this;
      var scope = angular.element(document.getElementById('mainTabId')).scope();
      vm.userInfo = scope.vm.userInfo;
      $scope.newData = newData;
      $scope.refreshAssignmntGrid = false;
      $scope.caseData = {};
      $scope.change = function (content) {
        $scope.currentAssignee.assigneeFullNameText = content.assigneeFullNameText;
        $scope.currentAssignee.activeCaseCount = content.activeCaseCount;
        $scope.currentAssignee.assigneeStatus = content.assigneeStatus;
        $scope.currentAssignee.assigneeNumberText = content.assigneeNumberText;
      };
      $scope.scrollDisable = true;
      $scope.caseRoleDisable = true;

      $scope.moreAssignees = false;
      $scope.getAssignedTo = function () {
        HttpFactory.getActions(CONSTANTS.URL.ASSIGNEEUSERS + vm.userInfo.userId)
          .then(function (successResponse) {
              $scope.myMangers = successResponse.data.managersData;
              $scope.myTeamData = successResponse.data.teamData;
              $scope.myGroupData = successResponse.data.groupData;
              $scope.workQueueData = successResponse.data.workQueueData;
              if ($scope.myGroupData === null) {
                $scope.moreAssignees = true;
              } else {
                $scope.groupLength = $scope.myGroupData.length;
                if ($scope.groupLength === 0) {
                  $scope.moreAssignees = true;
                }
              }
              $scope.foundAssigne = false;

              if (!$scope.foundAssigne) {
                $scope.currentAssignee = {
                  assigneeFullNameText: 'Not assigned',
                  activeCaseCount: '',
                  assigneeStatus: '',
                  assigneeNumberText: ""
                };
              }
              $scope.originalcurrentAssignee = angular.copy($scope.currentAssignee);
              $scope.change($scope.currentAssignee);

              if (initData && initData.appealNumber) {
                presetValues();
              } else {
                initData = null;
              }
            },
            function (failureResponse) {
              $scope.scrollDisable = true;
              $scope.currentAssignee = {
                assigneeFullNameText: 'Not assigned',
                activeCaseCount: '',
                assigneeStatus: '',
                assigneeNumberText: ""
              };
              $scope.myAssigne = {};
              $scope.originalcurrentAssignee = angular.copy($scope.currentAssignee);
              $log.info(failureResponse);
            });
      };
      $scope.getAssignedTo();
      function presetValues() {
        $scope.createAssignment.taskTitleTx=initData.assignmentTitle;
        $scope.createAssignment.caseNumberTx = initData.appealNumber;
        $scope.getCaseTypes(initData.appealNumber);
      }

      $scope.extraData = true;
      $scope.moreAssigneesData = function () {
        $scope.extraData = false;
        $scope.moreAssignees = true;
        $scope.myGroup = $scope.myGroupData;
      };

      $scope.pressEnter = function (event, casenumber) {
        if (event.keyCode === 13) {
          $scope.getCaseTypes(casenumber);
        }
      };

      $scope.caseTypeDisable = true;


      /* istanbul ignore next: toaster error */
      $scope.getCaseTypes = function (casenumber) {
        $scope.orignlacasenum = angular.copy(casenumber);
        $scope.myusrNo = casenumber;

        if (casenumber === "" || angular.isUndefined(casenumber)) {
          $scope.caseTypeDisable = false;
        } else {
          HttpFactory.getActions(CONSTANTS.URL.CASENO + "caseNumber=" + $scope.myusrNo)
            .then(function (successResponse) {
              $scope.caseData = successResponse.data;
              $scope.caseTypeDisable = false;
              $scope.getAssignmentTypes();


            }, function (failureResponse) {
              $log.info(failureResponse);
              $scope.caseTypeDisable = true;
              toastr.clear();
              toastr.error($scope.myusrNo + " does not exist in PTAB-E2E, you may want to import a new case into" +
                " PTAB-E2E for this XXX application number prior to creating an assignment.", {
                  iconClass: 'toast-danger'
                });
            });
        }


      };

      $scope.getAssignmentTypes = function () {

        HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTMODIFIEDTYPES + "caseNumber=" + $scope.caseData.serialNumber + "&appealNumber=" + $scope.caseData.appealNumber)
          .then(function (successResponse) {
              $scope.myAssignmentType = successResponse.data;

              if (initData && initData.appealNumber) {
                $scope.setSelectedType(initData.assignmentTypeCode,initData.assignmentTypeDisplayName);
                $scope.checkLengthAssingmentType();
                initData = null;
              }
            },
            function (failureResponse) {
              $log.info(failureResponse);
            });
      };

      $scope.closeAssignment = function () {
        closeChangesDialog(1);
        $scope.createAssignment = {};
        $scope.showErrorMsgTitletx = false;
        $scope.showAssignedTotx = false;
        $scope.showCaseNumbertx = false;
        $scope.showErrorMsgDueDate = false;
        $scope.showAssignmrentMsgRole = false;
        $scope.showAssignmrentMsgType = false;

      };

      $scope.createAssignment = {};
      $scope.createAssignment.selectedTypeDisplay = "No type selected";
      $scope.setSelectedType = function (selectedAssignmentType, selectedAssignmentTypeDisplayName) {
        $scope.createAssignment.selectedType = selectedAssignmentType;
        $scope.createAssignment.selectedTypeDisplay = selectedAssignmentTypeDisplayName;
        if(selectedAssignmentType == "ADHOC_ASSIGNMENTS"){
          vm.initiateErratumOrderMisc();
        }
      };

      vm.initiateErratumOrderMisc = function () {
        HttpFactory.getActions("/case-information/details?serialNumber=" + $scope.caseData.serialNumber + "&appealNumber=" + $scope.caseData.appealNumber).then(function (successResponse) {
          vm.caseInfo = successResponse.data;
        var initiateInfo = vm.caseInfo;
        initiateInfo.casePaneled = vm.caseInfo.attorneys ? vm.caseInfo.attorneys.length > 0 : false;
        initiateInfo.applicationNumber = $scope.caseData.serialNumber;
        ngDialog.open({
          template: 'app/caseViewer/erratumOrderMisc/erratumOrderMisc.modal.html',
          controller: 'ErratumOrderMiscController',
          controllerAs: 'vm',
          appendClassName: 'ngdialog-cust',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            caseInfo: function () {
              return initiateInfo;
            }
          }
        }).closePromise.then(function (results) {
          console.log('results: ', results);
        });
      })
      };

      $scope.buildAssignmentData = function (beNo, closeIndicator) {

        $scope.createAssignment.dueDateInMs = (new Date($scope.createAssignment.dueDateInMs).getTime() / 1000) * 1000;
        if ($scope.createAssignment.complitionDateInMs != null) {
          $scope.createAssignment.complitionDateInMs = (new Date($scope.createAssignment.complitionDateInMs).getTime() / 1000) * 1000;
        }
        var assignmentData = {
          "assignmentType": $scope.createAssignment.selectedType,
          "assignee": beNo,
          "serialNumber": $scope.caseData.serialNumber,
          "title": $scope.createAssignment.taskTitleTx,
          "description": $scope.createAssignment.assignmentDescription,
          "dueDate": $scope.createAssignment.dueDateInMs,
          "completionDate": $scope.createAssignment.complitionDateInMs,
          "caseType": $scope.caseData.caseType,
          "appealNumber": $scope.caseData.appealNumber,
          "sequenceNumber": $scope.caseData.seqNumber,
          "notes": $scope.createAssignment.assignmentNote,
          "priorityIndicator": ($scope.createAssignment.selectedIndicator) ? 'Y' : 'N',
          "audit": {
            "createUserIdentifier": vm.userInfo.userId,
            "lastModifiedUserIdentifier": vm.userInfo.userId
          }
        };

        $scope.postAssignment(assignmentData, closeIndicator);
      };

      $scope.postAssignment = function (data, closeIndicator) {
        /* istanbul ignore next */
        HttpFactory.postActions(CONSTANTS.URL.CREATEASSIGNMENT, data)
          .then(function (successResponse) {
            $scope.createAssignment = {};
            $scope.caseData = {};
            $scope.createAssignment.dueDateInMs = new Date($scope.today.getTime());
            $scope.caseTypeDisable = true;
            $scope.caseRoleDisable = true;
            $scope.readyToSaveTitle = false;
            $scope.readyToSaveType = false;
            $scope.readyToSaveDate = false;
            $scope.readyToSaveCaseNumber = false;
            $scope.readyToSaveAssignedTo = false;
            $scope.createAssignment.selectedTypeDisplay = "No type selected";
            $scope.createAssignment.complitionDateInMs = null;
            $scope.currentAssignee = {
              assigneeFullNameText: 'Not assigned',
              activeCaseCount: '',
              assigneeStatus: '',
              assigneeNumberText: ""
            };
            $scope.refreshAssignmntGrid = true;
            $scope.myAssigne = {};
            $scope.scrollDisable = true;
            $log.info("success post");
            toastr.clear();
            toastr.success(CONSTANTS.TOASTER.assignment, {
              iconClass: 'toast-success'
            });
            if (closeIndicator) {
              closeSaveDialog(1);
            }
          }, function (failureResponse) {
            $log.info(failureResponse);
            toastr.clear();
            toastr.error(failureResponse.data.message, {
              iconClass: 'toast-danger'
            });

          });
      };


      $scope.saveAssignment = function () {
        $scope.checkLengthTitletx();
        $scope.checkLengthAssingmentType();
        $scope.checkDueDate();
        $scope.checkCaseNumbertx();
        $scope.checkAssignedTotx();
      };

      $scope.assignmentSaveCloseVal = function (beNo) {
        if ($scope.readyToSaveTitle && $scope.readyToSaveType && $scope.readyToSaveCaseNumber &&
          $scope.readyToSaveAssignedTo && $scope.readyToSaveDate && $scope.readyToSaveCdate) {
          $scope.buildAssignmentData(beNo, true);
          // closeSaveDialog(1);
        } else {
          $scope.saveAssignment();
        }
      };


      $scope.assignmentSaveVal = function (beNo) {
        if ($scope.readyToSaveTitle && $scope.readyToSaveType && $scope.readyToSaveCaseNumber && $scope.readyToSaveAssignedTo &&
          $scope.readyToSaveDate && $scope.readyToSaveCdate) {
          $scope.buildAssignmentData(beNo, false);
        } else {
          $scope.saveAssignment();
        }
      };

      $scope.checkLengthTitletx = function () {
        if (angular.isUndefined($scope.createAssignment.taskTitleTx) || $scope.createAssignment.taskTitleTx.length < 1) {
          $scope.showErrorMsgTitletx = true;
          $scope.errorMessageTitletx = "The assignment title cannot be empty.";
          $scope.readyToSaveTitle = false;
        } else {
          $scope.readyToSaveTitle = true;
          $scope.showErrorMsgTitletx = false;
        }
      };

      $scope.checkLengthAssingmentType = function () {
        if (angular.isUndefined($scope.createAssignment.selectedType) || $scope.createAssignment.selectedType.length < 1) {
          $scope.showAssignmrentMsgType = true;
          $scope.errorAssignmrentMsgType = "The assignment type cannot be empty.";
          $scope.readyToSaveType = false;
          $scope.caseRoleDisable = true;
          $scope.colorChange = true;
          $scope.scrollDisable = true;
          $scope.currentAssignee = {
            assigneeFullNameText: 'Not assigned',
            activeCaseCount: '',
            assigneeStatus: '',
            assigneeNumberText: ""
          };
        } else {
          $scope.scrollDisable = false;
          $scope.readyToSaveType = true;
          $scope.caseRoleDisable = false;
          $scope.colorChange = true;
          $scope.showAssignmrentMsgType = false;
        }
      };


      $scope.checkDueDate = function () {
        if (angular.isUndefined($scope.createAssignment.dueDateInMs)) {
          $scope.showErrorMsgDueDate = true;
          $scope.errorMessageDueDate = "The due date cannot be empty.";
          $scope.readyToSaveDate = false;
        } else {
          $scope.readyToSaveDate = true;
          $scope.showErrorMsgDueDate = false;
        }
      };
      $scope.readyToSaveCdate = true;
      $scope.createAssignment.complitionDateInMs = null;
      $scope.checkCompletionDate = function () {
        if (angular.isDate($scope.createAssignment.complitionDateInMs)) {
          $scope.errorMessageCompdate = "false";
          $scope.errorMesageCompletionDate = undefined;
          $scope.readyToSaveCdate = true;
        } else if (angular.isUndefined($scope.createAssignment.complitionDateInMs)) {
          try {
            var compDateValue = document.getElementById("completedIdDate").value;
            /* istanbul ignore if */
            if (compDateValue === "") {
              $scope.errorMessageCompdate = "false";
              $scope.errorMesageCompletionDate = undefined;
              $scope.readyToSaveCdate = true;
            } else {
              $scope.errorMessageCompdate = "true";
              $scope.errorMesageCompletionDate = "date not valid";
              $scope.readyToSaveCdate = false;
            }
          } catch(error) {

          }
        
        }
      };

      $scope.checkCaseNumbertx = function () {
        if (angular.isUndefined($scope.createAssignment.caseNumberTx) || $scope.createAssignment.caseNumberTx.length < 1) {
          $scope.showCaseNumbertx = true;
          $scope.errorCaseNumbertx = "The case number cannot be empty.";
          $scope.createAssignment.selectedTypeDisplay = "No type selected";
          $scope.caseRoleDisable = true;
          $scope.caseTypeDisable = true;
          $scope.caseData.casetype = "";
          $scope.scrollDisable = true;
          $scope.currentAssignee = {
            assigneeFullNameText: 'Not assigned',
            activeCaseCount: '',
            assigneeStatus: '',
            assigneeNumberText: ""
          };
          $scope.readyToSaveCaseNumber = false;
        } else if (angular.isDefined($scope.orignlacasenum) && $scope.orignlacasenum !== $scope.createAssignment.caseNumberTx) {
          $scope.createAssignment.selectedType = "";
          $scope.caseRoleDisable = true;
          $scope.caseData.caseType = "";
          $scope.scrollDisable = true;
          $scope.caseTypeDisable = true;
          $scope.currentAssignee = {
            assigneeFullNameText: 'Not assigned',
            activeCaseCount: '',
            assigneeStatus: '',
            assigneeNumberText: ""
          };
        } else {

          $scope.readyToSaveCaseNumber = true;
          $scope.showCaseNumbertx = false;
        }
      };

      $scope.checkAssignedTotx = function () {
        if ($scope.currentAssignee.assigneeFullNameText === "Not assigned") {
          $scope.showAssignedTotx = true;
          $scope.errorAssignedTotx = "The assigned to cannot be empty.";
          $scope.readyToSaveAssignedTo = false;
        } else if ($scope.currentAssignee.assigneeFullNameText !== "Not assigned") {
          $scope.showAssignedTotx = false;
          $scope.readyToSaveAssignedTo = true;
        }
      };

      $scope.today = new Date();
      $scope.createAssignment.dueDateInMs = new Date($scope.today.getTime());
      $scope.newTitle = angular.copy($scope.createAssignment.taskTitleTx);
      $scope.newType = angular.copy($scope.createAssignment.selectedType);
      $scope.newCaseNumber = angular.copy($scope.createAssignment.caseNumberTx);
      $scope.newDescription = angular.copy($scope.createAssignment.assignmentDescription);
      $scope.newDueDate = angular.copy($scope.createAssignment.dueDateInMs);
      $scope.newComplitionDate = angular.copy($scope.createAssignment.complitionDateInMs);
      $scope.newNote = angular.copy($scope.createAssignment.assignmentNote);
      $scope.newIndicator = angular.copy($scope.createAssignment.selectedIndicator);
      $scope.cancelAssignDialog = function () {
        if (!angular.equals($scope.currentAssignee, $scope.originalcurrentAssignee) ||
          !angular.equals($scope.newTitle, $scope.createAssignment.taskTitleTx) ||
          !angular.equals($scope.newType, $scope.createAssignment.selectedType) ||
          !angular.equals($scope.newCaseNumber, $scope.createAssignment.caseNumberTx) ||
          !angular.equals($scope.newDescription, $scope.createAssignment.assignmentDescription) ||
          !angular.equals($scope.newDueDate, $scope.createAssignment.dueDateInMs) ||
          !angular.equals($scope.newNote, $scope.createAssignment.assignmentNote) ||
          !angular.equals($scope.newIndicator, $scope.createAssignment.selectedIndicator) ||
          !angular.equals($scope.newComplitionDate, $scope.createAssignment.complitionDateInMs)) {
          ngDialog.open({
            template: 'app/components/widgets/assignments/src/cancelAssignment.html',
            controller: 'CancelAssignmentController',
            controllerAs: 'vm',
            width: '25%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              newData: function () {
                return $scope.newData;
              },
              originalData: function () {
                return $scope.originalData;
              },
              currentAssignee: function () {
                return $scope.currentAssignee;
              },
              originalcurrentAssignee: function () {
                return $scope.originalcurrentAssignee;
              }
            }
          });
        } else {
          closeChangesDialog(1);
        }

      };
      /* istanbul ignore next*/
      $scope.validateBusinnessdateSelected = function () {
        $scope.dateValidFlag = false;
        return HttpFactory.getActions(CONSTANTS.URL.HOLIDAYCHECKS + "selectedDate=" + new Date($scope.createAssignment.dueDateInMs).setHours(0, 0, 0, 0))
          .then(function (successResponse) {
              var ResponseDate = successResponse;
              if (ResponseDate.data.isValid !== true) {
                $scope.dateValidFlag = true;


              }
              return successResponse;
            },
            function (failureResponse) {
              return failureResponse;
            });
      };

      $scope.assignmentDateModel = function (beNo) {
        closeChangesDialog(1);
        if ($scope.assignmentSaveCloseValTest === true) {
          $scope.assignmentSaveCloseVal(beNo);
        } else {
          $scope.assignmentSaveVal(beNo);
        }
      };

      $scope.assignmentSave = function (beNo) {
        /* istanbul ignore next */
        $scope.validateBusinnessdateSelected().then(function () {
          if ($scope.dateValidFlag === false) {

            $scope.assignmentSaveVal(beNo);

          } else {
            $scope.openAssignmentDate(beNo);
          }
        });
      };

      $scope.assignmentSaveAndClose = function (beNo) {
        $scope.assignmentSaveCloseValTest = true;
        /* istanbul ignore next */
        $scope.validateBusinnessdateSelected().then(function () {
          if ($scope.dateValidFlag === false) {
            $scope.assignmentSaveCloseVal(beNo);

          } else {
            $scope.openAssignmentDate(beNo);
          }
        });
      };

      function closeChangesDialog(popupsToClose) {
        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose]);
        } else {
          if ($scope.refreshAssignmntGrid) {
            ngDialog.closeAll(true);
          } else {
            ngDialog.close();
          }
        }
      }

      function closeSaveDialog(popupsToClose) {
        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose], true);
        } else {
          ngDialog.closeAll(true);
        }
      }

      $scope.closeAssignmentDate = function () {
        closeChangesDialog(1);
        $scope.saveAssignment();
        try {
          document.getElementById("reportFromDate").focus();
        } catch(error) {
          
        }
     

      };

      /* istanbul ignore next*/
      $scope.openAssignmentDate = function (beNo) {
        $scope.employeeNo = beNo;
        ngDialog.open({
          template: 'app/components/widgets/assignments/src/dueDateAssignment.html',
          scope: $scope,
          width: '25%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
        });
      };
    }).directive('disableAutoClose', function () {
      /* directive for disabling the default
          close on 'click' behavior */
      return {
        link: function ($scope, $element) {
          $element.on('click', function ($event) {

            $event.stopPropagation();
          });
        }
      };
    });
})();
