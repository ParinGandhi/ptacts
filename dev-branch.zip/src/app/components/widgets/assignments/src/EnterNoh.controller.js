(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .directive('fileModel', ['$parse', /* istanbul ignore next */ function ($parse) {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var model = $parse(attrs.fileModel);
          var modelSetter = model.assign;

          element.bind('change', function () {
            scope.$apply(function () {
              modelSetter(scope, element[0].files[0]);
            });
          });
        }
      };
    }])
    .directive('customOnChange', function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var onChangeFunc = scope.$eval(attrs.customOnChange);
          element.bind('change', onChangeFunc);
        }
      };
    })
    .controller('enterNohController', function ($scope, $log, $http, $sce, ngDialog, HttpFactory, CONSTANTS, toastr, $rootScope) {
      var vm = this;
      var scope = angular.element(document.getElementById('mainTabId')).scope();
      vm.userInfo = scope.vm.userInfo;
      $scope.listOfFileNames = [];
      $scope.fileContent = [];
      $scope.assignmentTypeForRtf = $rootScope.sharedItems[0].assignmentType;
      $scope.rtfBaseLink = CONSTANTS.URL.BASE;
      $scope.multiPdf = [];
      $scope.docketFileContent = [];
      $scope.show = true;
      $scope.editable = true;
      $scope.showPreview = true;
      $scope.fileUploadDisable = true;
      $scope.hideAdd = true;
      $scope.shareAssign = $rootScope.sharedItems;
      $scope.caseNum = $rootScope.sharedItems[0].serialNumber;
      var transDate = new Date().getTime();
      $scope.transactionDate = transDate;
      $scope.specialTypeIndicator = 'N';
      $scope.showMandatory = false;
      $scope.hearingAtten = {};
      $scope.remoteLoc = {};
      $scope.remoteViewDisabled = true;
      $scope.remoteDisableSubmit = true;
      $scope.remoteLoc = {};
      $scope.finalPreview = true;
      $scope.dockType = null;
      /* istanbul ignore next */
      $scope.getMetaData = function (appNum) {
        // angular.forEach($scope.shareAssign[0].standardAssignmentType, function (eachType) {
        // if (eachType === 'Docketing notice') {

        HttpFactory.getActions(CONSTANTS.URL.APPEAL_METADATA + "?caseNumber=" + appNum + "&appealNumber=" + $scope.shareAssign[0].appealNumber)
          .then(function (successResponse) {
            $scope.docketInfo = successResponse.data;
            $scope.appellant = successResponse.data.appeal.appellants;
            $scope.address = successResponse.data.address.physicalAddress[0];
            $scope.receiptDate = successResponse.data.appeal.receivedDate;
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
        // }
        // });
      };

      /*istanbul ignore next */
      $scope.enternoh = function () {
        HttpFactory.getActions(CONSTANTS.URL.ENOH + "appealNumber=" + $scope.shareAssign[0].appealNumber)
          .then(function (successResponse) {
            $scope.eroh = successResponse.data;
            $scope.specialHearingType.selectedStatusType = successResponse.data.specialTypeIndicator;
            $scope.specialHearingType.selectedStatusDisplay = successResponse.data.specialTypeDescription;
            $scope.hearingAtten.selectedHearingCode = successResponse.data.hearingAttendanceStatusCd;
            $scope.hearingAtten.selectedHearingDisplay = successResponse.data.hearingAttendanceStatusDesc;
            $scope.remoteLoc.selectedCode = successResponse.data.remoteLocationCd;
            $scope.remoteLoc.selectedDescription = successResponse.data.remoteLocationCdDesc;
            if ($scope.shareAssign[0].assignmentType === 'UHA') {
              $scope.hStatus.selectedStatusDisplay = successResponse.data.statusCodeDescription;
              $scope.hStatus.selectedStatusType = successResponse.data.statusCode;
              if ($scope.hStatus.selectedStatusType === "AM" || $scope.hStatus.selectedStatusType === "NS") {
                $scope.disableSubmit = false;
              } else {
                $scope.disableSubmit = true;
              }
            }
            if ($scope.eroh.statusCode === 'CT' || $scope.eroh.statusCode === 'CV' || $scope.eroh.statusCode === 'CVVA' ||
              $scope.eroh.statusCode === 'CVTX' || $scope.eroh.statusCode === 'CVCO' || $scope.eroh.statusCode === 'CVMI' ||
              $scope.eroh.statusCode === 'CVNO' || $scope.eroh.statusCode === 'CVCA') {
              if (successResponse.data.statusCodes != null) {
                var firstKey = successResponse.data.statusCodes[0].descriptionText;
                $scope.hStatus.selectedStatusDisplay = firstKey;
                $scope.ptvhHearingStatus(successResponse.data.statusCodes);
              }

            }
            // if($scope.shareAssign[0].assignmentType === 'PTVH') {
            //    $scope.remoteLoc.selectedDescription = successResponse.data.remoteLocationCdDesc;
            // }
          },
            function (failureResponse) {
              $log.info(failureResponse);
            });
      };


      //get for remote viewing locations for enter response to NOH
      $scope.getRemoteLocations = function () {
        HttpFactory.getActions(CONSTANTS.URL.REMOTEVIEWINGLOC + $scope.shareAssign[0].appealNumber)
          .then(function (successResponse) {
            $scope.remoteLoc = successResponse.data;
            $scope.remoteLoc.selectedDescription = $scope.remoteLoc[0].descriptionText;
            $scope.remoteLoc.selectedCode = $scope.remoteLoc[0].valueText;

          },
            function (failureResponse) {
              $log.info(failureResponse);
            });
      };
      //get for hearing status type for  Enter response to NOH
      $scope.hearingStatus = function () {
        HttpFactory.getActions(CONSTANTS.URL.STATUSNOH + $scope.shareAssign[0].appealNumber)
          .then(function (successResponse) {
            $scope.status = successResponse.data;

          },
            function (failureResponse) {
              $log.info(failureResponse);
            });
      };

      //get for hearing status type for  send reschedule decesion
      $scope.srdHearingStatus = function () {
        HttpFactory.getActions(CONSTANTS.URL.STATUSSRD)
          .then(function (successResponse) {
            $scope.status = successResponse.data;

          },
            function (failureResponse) {
              $log.info(failureResponse);
            });
      };

      //get for hearing status type for  send reschedule decesion
      $scope.ptvhHearingStatus = function (data) {
        $scope.status = data;


      };

      //get for hearing status type for  send reschedule decesion
      $scope.uhaHearingStatus = function () {
        HttpFactory.getActions(CONSTANTS.URL.UPDATESTATUSUHA)
          .then(function (successResponse) {
            $scope.status = successResponse.data;

          },
            function (failureResponse) {
              $log.info(failureResponse);
            });
      };

      //hearing Date validation in update Hearing attandance
      /*istanbul ignore next */
      $scope.dateEmptyValidation = function () {
        if (!angular.isDefined($scope.transactionDate)) {
          $log.info($scope.transactionDate);
          var transDate = new Date().getTime();
          $scope.transactionDate = transDate;
          ngDialog.open({
            template: 'app/components/widgets/assignments/src/hearingDateValidation.html',
            scope: $scope,
            width: '25%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
          });
        }

      };

      /*istanbul ignore next */
      $scope.disableSubmit = true;
      $scope.hStatus = {};
      $scope.specialHearingType = {};
      if ($scope.shareAssign[0].assignmentType === 'EARH') {
        $scope.hStatus.selectedStatusDisplay = "Awaiting response to NOH";
      } else if ($scope.shareAssign[0].assignmentType === 'SRD') {
        $scope.hStatus.selectedStatusDisplay = "Hearing reschedule requested";
      } else if ($scope.shareAssign[0].assignmentType === 'RHT' || $scope.shareAssign[0].assignmentType === 'UHT') {
        $scope.hStatus.selectedStatusDisplay = "Appearance made";
        $scope.hStatus.selectedStatusType = "AM";
        if ($scope.hStatus.selectedStatusType === "AM") {
          $scope.disableSubmit = false;
        } else {
          $scope.disableSubmit = true;
        }
      }

      /* istanbul ignore next */
      $scope.setSelectedHeringAtten = function (selectedStatusType, selectedStatusDisplay) {
        $scope.hearingAtten.selectedHearingDisplay = selectedStatusDisplay;
        $scope.hearingAtten.selectedHearingCode = selectedStatusType;
        if ($scope.shareAssign[0].assignmentType === 'UHA') {
          if ($scope.hearingAtten.selectedHearingCode === "AM" || $scope.hearingAtten.selectedHearingCode === "NS") {
            $scope.disableSubmit = false;
          } else {
            $scope.disableSubmit = true;
          }
        }
      };

      /*istanbul ignore next */
      $scope.setSelectedType = function (selectedStatusType, selectedStatusDisplay) {
        $scope.hStatus.selectedStatusType = selectedStatusType;
        $scope.hStatus.selectedStatusDisplay = selectedStatusDisplay;
        if ($scope.shareAssign[0].assignmentType === 'EARH') {
          if ($scope.hStatus.selectedStatusType !== "AWTRESP") {
            $scope.disableSubmit = false;
          } else {
            $scope.disableSubmit = true;
          }

          if ($scope.hStatus.selectedStatusType === "AR") {
            $scope.disableSubmit = true;
          }

        } else if ($scope.shareAssign[0].assignmentType === 'SRD') {
          if ($scope.hStatus.selectedStatusType !== "HRR") {
            $scope.disableSubmit = false;
          } else {
            $scope.disableSubmit = true;
          }
        } else if ($scope.shareAssign[0].assignmentType === 'PTVH') {
          if ($scope.hStatus.selectedStatusType !== "CVDH" && $scope.hStatus.selectedStatusType !== "CTPH") {
            $scope.disableSubmit = false;
          } else {
            $scope.disableSubmit = true;
          }
        } else if ($scope.shareAssign[0].assignmentType === 'RHT' || $scope.shareAssign[0].assignmentType === 'UHT') {
          if ($scope.hStatus.selectedStatusType === "AM") {
            $scope.disableSubmit = false;
          } else {
            $scope.disableSubmit = true;
          }
        }

      };


      $scope.setSelectedSpecialType = function (selectedSpecialType, selectedSpecialDisplay) {
        $scope.specialHearingType.selectedStatusType = selectedSpecialType;
        $scope.specialHearingType.selectedStatusDisplay = selectedSpecialDisplay;

      };

      $scope.setRemoteLocation = function (selectedCode, selectedDescription) {
        if ($scope.hStatus.selectedStatusDisplay.toLowerCase() === "awaiting response to noh") {

          $scope.remoteDisableSubmit = true;
          if (selectedCode == "NR") {
            $scope.remoteViewDisabled = true;
            $scope.eroh.remoteUsersCount = "";
          } else {
            $scope.remoteViewDisabled = false;
          }
        } else {
          if (selectedCode == "NR") {
            $scope.remoteViewDisabled = true;
            $scope.remoteDisableSubmit = false;
            $scope.eroh.remoteUsersCount = "";
          } else {
            $scope.remoteViewDisabled = false;
            $scope.remoteDisableSubmit = true;
            $scope.disableSubmit = true;
          }
        }
        $scope.remoteLoc.selectedCode = selectedCode;
        $scope.remoteLoc.selectedDescription = selectedDescription;
      };
      $scope.remoteViewLoc = function () {
        if ($scope.hStatus.selectedStatusDisplay.toLowerCase() === "awaiting response to noh") {
          $scope.remoteDisableSubmit = true;
        } else {
          $scope.remoteDisableSubmit = false;
        }
      };

      $scope.specialHearing = function () {
        HttpFactory.getActions(CONSTANTS.URL.SPECIALSTATUSNOH)
          .then(function (successResponse) {
            $scope.special = successResponse.data;
          },
            function (failureResponse) {
              $log.info(failureResponse);
            });
      };
      $scope.specialHearing();


      //get review hearing transcript
      $scope.reviewHearingTranscriptStatus = function () {
        HttpFactory.getActions(CONSTANTS.URL.RHTSTATUS)
          .then(function (successResponse) {
            $scope.status = successResponse.data;

          },
            function (failureResponse) {
              $log.info(failureResponse);
            });
      };
      /*multi select dropdown*/

      /* istanbul ignore next */
      $scope.dropdownEvents = {
        onInitDone: function (item) {
          $log.info(item);
        },
        onItemSelect: function (item) {
          // intentional
        },
        onSelectAll: function (item) {
          // intentional
        },
        onItemDeselect: function () {
          // intentional
        }
      };

      /* istanbul ignore next */
      $scope.selectedRoles = [];
      angular.forEach($scope.specialType, function (role) {
        var data = {
          'code': role.valueText,
          'label': role.descriptionText
        };
        $scope.selectedRoles.push(data);
      });


      //common method to display PDF name
      /* istanbul ignore next */
      $scope.selectFile = function (file, event) {

        $scope.errorMessage = false;
        var fileName = file.currentTarget.files["0"].name;
        if (angular.isUndefined(fileName)) {
          return;
        } else {
          $scope.showMandatory = false;
          var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
          if (ext !== 'pdf') {
            $scope.errorMessage = true;

            toastr.error(CONSTANTS.TOASTER.fileUpload, {
              iconClass: 'toast-danger',
              timeOut: 9000000,
              extendedTimeOut: 9000000

            });
          }
          if (!$scope.errorMessage) {

            $scope.fileName = file.currentTarget.files["0"].name;
            $scope.fileContent = file.currentTarget.files["0"];
            var pdfDataFile = new FormData();
            pdfDataFile.append('uploadMultipartFileContents', $scope.fileContent);
            HttpFactory.postPdf(CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.USERGEN + 'appealNumber=' + $scope.shareAssign[0].appealNumber +
              '&ptabAssignmentId=' + $scope.shareAssign[0].assignmentIdentifier, pdfDataFile)
              .then(function (successResponse) {
                $scope.dockType = "USER";
                $scope.genPdfFileName = successResponse.data.fileName;

                $scope.loading = false;
              }, function () {
                // intentional
              });
          }
        }
      };


      /* ngdialog for confiming the submit*/
      /*istanbul ignore next */
      $scope.confirmSubmit = function () {

        if ($scope.fileName) {
          $scope.showMandatory = false;
          if ($scope.hStatus.selectedStatusType === 'HG') {

            ngDialog.open({
              template: 'app/components/widgets/assignments/src/confirmEnoh.html',
              controller: 'confirmENohController',
              width: '25%',
              showClose: false,
              closeByEscape: false,
              closeByDocument: false,
              resolve: {
                eroh: function () {
                  return $scope.eroh;
                },
                shareAssign: function () {
                  return $scope.shareAssign[0];
                },
                hStatus: function () {
                  return $scope.hStatus;
                },
                pdfFileName: function () {
                  return $scope.genPdfFileName;
                },
                transactionDate: function () {
                  return $scope.transactionDate;
                },
                dockType: function () {
                  return $scope.dockType;
                }

              }
            }).closePromise.then(function (pdfContent) {
              if (pdfContent.value) {
                $scope.loading = true;
                $scope.contentsPreview = 'data:application/pdf;base64,' + pdfContent.value;
                $scope.getPreview($scope.contentsPreview);
                $scope.loading = false;
                $scope.showPreview = false;
              }
            });

          } else {
            $scope.submitResponse();
          }
        } else {
          $scope.showMandatory = true;
          toastr.clear();
          toastr.error(CONSTANTS.TOASTER.fileMandatory, {
            iconClass: 'toast-danger'
          });
        }
      };


      /* call to submit response*/
      /* istanbul ignore next */
      $scope.submitResponse = function () {

        $scope.loading = true;
        if ($scope.shareAssign[0].assignmentType !== 'UHT') {
          $scope.eroh.statusCode = $scope.hStatus.selectedStatusType;
        }
        if ($scope.hearingAtten) {
          $scope.eroh.hearingAttendanceStatusCd = $scope.hearingAtten.selectedHearingCode;
        }
        $scope.eroh.specialTypeIndicator = $scope.specialHearingType.selectedStatusType;
        if ($scope.remoteLoc) {
          $scope.eroh.remoteLocationCd = $scope.remoteLoc.selectedCode;
        }
        if ($scope.eroh.remoteLocationCd === "NR") {
          $scope.eroh.remoteUsersCount = 0;
        }
        // $scope.eroh.remoteUsersCount  = $scope.remoteUsersCount;
        $scope.hearingRoomRoster = $scope.eroh;
        $scope.hearingRoomRoster.lastModifiedTime = new Date().getTime();
        $scope.hearingRoomRoster.lastModifiedUserIdentifier = vm.userInfo.userId;
        $scope.hearingRoomRoster.transactionDate = $scope.transactionDate ? new Date($scope.transactionDate).getTime() : new Date();
        $scope.shareAssign[0].priorityIndicator = $scope.shareAssign[0].priorityIndicator ? 'Y' : 'N';
        $scope.shareAssign[0].completionCode = $scope.eroh.hearingAttendanceStatusCd ? $scope.eroh.hearingAttendanceStatusCd : $scope.hStatus.selectedStatusType;
        $scope.currentAssignment = $scope.shareAssign[0];
        $scope.currentAssignment.audit = {
          "createUserIdentifier": vm.userInfo.userInfo,
          "lastModifiedUserIdentifier": vm.userInfo.userId,
          "lastModifiedTimestamp": new Date().getTime(),
          "createdUserName": vm.userInfo.displayName,
          "lastModifiedUserName": vm.userInfo.displayName,
          "createTimestamp": new Date().getTime(),
          "lockControlNumber": 0
        };
        $scope.currentAssignment.transactionDate = $scope.hearingRoomRoster.transactionDate;
        var data = {
          "hearingRoomRoster": $scope.hearingRoomRoster,
          "currentAssignment": $scope.currentAssignment,
          "fileName": $scope.genPdfFileName,
          "docType": $scope.dockType
        };

        HttpFactory.putActions(CONSTANTS.URL.SUBMITENOH, data)
          .then(function (successResponse) {

            if ($scope.shareAssign[0].assignmentType === 'EARH') {
              toastr.success(CONSTANTS.TOASTER.nohClose, {
                iconClass: 'toast-success'
              });
              ngDialog.closeAll('true');
            } else if ($scope.shareAssign[0].assignmentType === 'SRD') {
              toastr.success(CONSTANTS.TOASTER.srd, {
                iconClass: 'toast-success'
              });
              if ($scope.hStatus.selectedStatusType === 'HD') {
                $scope.pdfContentPreview = successResponse.data.fileContent;
                $scope.contentsPreview = 'data:application/pdf;base64,' + $scope.pdfContentPreview;
                $scope.getPreview($scope.contentsPreview);
                $scope.loading = false;
                $scope.showPreview = false;
              }
            } else if ($scope.shareAssign[0].assignmentType === 'UHA') {
              toastr.success(CONSTANTS.TOASTER.uha, {
                iconClass: 'toast-success'
              });
              ngDialog.closeAll('true');
            } else if ($scope.shareAssign[0].assignmentType === 'PTVH') {
              toastr.success(CONSTANTS.TOASTER.ptvh, {
                iconClass: 'toast-success'
              });
              $scope.pdfContentPreview = successResponse.data.fileContent;
              $scope.contentsPreview = 'data:application/pdf;base64,' + $scope.pdfContentPreview;
              $scope.getPreview($scope.contentsPreview);
              $scope.loading = false;
              $scope.showPreview = false;
            } else if ($scope.shareAssign[0].assignmentType === 'RHT') {
              toastr.success(CONSTANTS.TOASTER.rth, {
                iconClass: 'toast-success'
              });
              ngDialog.closeAll('true');
            } else if ($scope.shareAssign[0].assignmentType === 'UHT') {
              $scope.pdfContentPreview = successResponse.data.fileContent;
              $scope.contentsPreview = 'data:application/pdf;base64,' + $scope.pdfContentPreview;
              $scope.getPreview($scope.contentsPreview);
              $scope.loading = false;
              $scope.showPreview = false;
              toastr.success(CONSTANTS.TOASTER.ut, {
                iconClass: 'toast-success'
              });
            }
            $scope.$parent.$parent.refreshGrid = true;


            $scope.loading = false;
            $scope.hideAdd = false;
          }, function (failureResponse) {
            toastr.clear();
            toastr.error(failureResponse.data.message, {
              iconClass: 'toast-danger'
            });
            $scope.showPreview = true;
            $scope.loading = false;
          });

      };

      $scope.fileSelect = function (p) {
        if (p.keyCode == '13') {
          document.getElementById('file1').click();
        }
      };

      $scope.backUpload = function () {
        $scope.disableSubmit = true;
        $scope.remoteDisableSubmit = true;
        $scope.pdfContent = '';
        $scope.editable = true;
        $scope.show = true;
        $scope.showPreview = true;
        $scope.hideAdd = true;
        $scope.pdfStyle = {
          "border": "none"
        };
      };
      //SERVER file, URL will be replaced by services URL
      $scope.systemGeneratePdf = function () {
        $scope.loading = true;
        $scope.hideAdd = false;
        /* istanbul ignore next*/
        HttpFactory.postPdf(CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.SYSGEN + 'appealNumber=' + $scope.shareAssign[0].appealNumber +
          '&ptabAssignmentId=' + $scope.shareAssign[0].assignmentIdentifier + '&serialNumber=' + $scope.caseNum + '&orderType=' + $scope.hStatus.selectedStatusType)
          .then(function (successResponse) {
            $scope.dockType = "SYSTEM";
            $scope.PostDataResponse = successResponse.data;
            $scope.contentsPreview = 'data:application/pdf;base64,' + $scope.PostDataResponse.fileContent;
            $scope.genPdfFileName = successResponse.data.fileName;
            $scope.getRtfFileName = successResponse.data.rtfFileName[0];
            $scope.getPreview($scope.contentsPreview);
            $scope.loading = false;
            $scope.fileNumber = 0;
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };

      /* istanbul ignore next*/
      $scope.downloadDisable = function (value) {
        if (value) {
          document.getElementById("editOrder").disabled = true;
        } else {
          document.getElementById("editOrder").disabled = false;
        }
      };

      $scope.documentType = function (value) {
        if (value) {
          document.getElementById("systemGenFlag").style.display = "none";
          document.getElementById("userGenFlag").style.display = "block";
        } else {
          document.getElementById("systemGenFlag").style.display = "block";
          document.getElementById("userGenFlag").style.display = "none";
        }

      };

      /* istanbul ignore next */
      $scope.showPreviewPdf = function () {
        $scope.loading = true;
        $scope.showPreview = false;
        var pdfDataFile = new FormData();
        angular.forEach($scope.fileContent, function (value) {
          pdfDataFile.append('uploadMultipartFileContents', value);
        });
        HttpFactory.postPdf(CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.USERGEN + 'appealNumber=' + $scope.shareAssign[0].appealNumber +
          '&ptabAssignmentId=' + $scope.shareAssign[0].assignmentIdentifier, pdfDataFile)
          .then(function (successResponse) {
            $scope.documentType(true);
            $scope.dockType = "USER";
            $scope.PostDataResponse = successResponse.data.fileContent;
            $scope.genPdfFileName = successResponse.data.fileName;
            $scope.contentsPreview = 'data:application/pdf;base64,' + $scope.PostDataResponse;
            $scope.getPreview($scope.contentsPreview);
            $scope.loading = false;
            $scope.hideAdd = false;
          }, function () {
            // intentional
          });
      };
      /* istanbul ignore next */
      $scope.addFile = function (file) {
        if (!vm.fileAdded1) {
          vm.fileAdded1 = true;
          $scope.errorMessage = false;
          var fileName = file.currentTarget.files["0"].name;
          if (angular.isUndefined(fileName)) {
            return;
          } else {
            var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
            if (ext !== 'pdf') {
              $scope.errorMessage = true;

              toastr.error(CONSTANTS.TOASTER.fileUpload, {
                iconClass: 'toast-danger',
                timeOut: 9000000,
                extendedTimeOut: 9000000

              });
            }
            if (!$scope.errorMessage) {
              $scope.fileContent.push(file.currentTarget.files["0"]);
              $scope.listOfFileNames.push(file.currentTarget.files["0"].name);
              $scope.$apply();
            }
          }
        }
      };

      //delete pdf
      $scope.deletePdf = function (index) {
        $scope.listOfFileNames.splice(index, 1);
        $scope.fileContent.splice(index, 1);

      };

      /* istanbul ignore next*/
      $scope.openApplentDialog = function () {


        $scope.partiesShow = "Appellants";
        $scope.caseDetailsData = {
          "applicationNumber": $scope.shareAssign[0].serialNumber,
          "appealNumber": $scope.shareAssign[0].appealNumber
        };
        ngDialog.open({
          template: "app/components/helperComponents/appellantsPartiesAndRealParties/appellantsPartiesAndRealParties.html",
          controller: 'AppellantsPartiesController',
          scope: $scope,
          width: '60%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,

          resolve: {
            partiesData: function () {
              return $scope.caseDetailsData;
            },
            partiesFlag: function () {
              return $scope.partiesShow;
            },

          }
        }).closePromise.then(function () {
          $scope.getMetaData($scope.shareAssign[0].serialNumber, $scope.shareAssign[0].appealNumber);

        }, function () {
          // intentional
        });
      };

      /* istanbul ignore next */
      $scope.palmUpload = function () {
        if ($scope.shareAssign[0].assignmentType === "PTVH" || $scope.shareAssign[0].assignmentType === "SRD") {
          var userDisp = document.getElementById("userGenFlag").style.display;
          var userNot = document.getElementById("userGeneratedMark");
          if (userNot && userNot.innerHTML === 'user-generated)' && userDisp !== "none") {
            $scope.dockType = "USER";
          }
        }
        //$scope.shareAssign.newAssigneeNum = $scope.currentAssignee.assigneeNumberText;

        ngDialog.open({
          template: 'app/components/widgets/assignments/src/submitPdfUpload.html',
          controller: 'submitPdfController',
          width: '35%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          ariaLabelledById: 'pdfUploadTitle',
          ariaDescribedById: 'pdfUploadTitle',
          resolve: {
            shareAssign: function () {
              return $scope.shareAssign[0];
            },

            genPdfFile: function () {
              return $scope.genPdfFileName;
            },
            hearingAtten: function () {
              return $scope.hearingAtten;
            },
            hStatus: function () {
              return $scope.hStatus;
            },
            specialHearingType: function () {
              return $scope.specialHearingType;
            },
            remoteLoc: function () {
              return $scope.remoteLoc;
            },
            eroh: function () {
              return $scope.eroh;
            },
            transactionDate: function () {
              return $scope.transactionDate;
            },
            dockType: function () {
              return $scope.dockType;
            }
          }
        }).closePromise.then(function (pdfData) {
          $scope.$parent.$parent.refreshGrid = true;
          $scope.disableUpload = false;
          if (angular.isDefined(pdfData.value)) {
            if ($scope.shareAssign[0].assignmentType === 'PTVH') {
              toastr.success(CONSTANTS.TOASTER.ptvh, {
                iconClass: 'toast-success'
              });
            } else if ($scope.shareAssign[0].assignmentType === 'SRD') {
              toastr.success(CONSTANTS.TOASTER.srd, {
                iconClass: 'toast-success'
              });
            }

            $scope.pdfContentPreview = pdfData.value.fileContent;
            $scope.contentsPreview = 'data:application/pdf;base64,' + $scope.pdfContentPreview;
            $scope.getPreview($scope.contentsPreview);
            $scope.loading = false;
            $scope.showPreview = false;
            $scope.show = true;
            $scope.finalPreview = false;

          }
          // if ($scope.shareAssign[0].assignmentType === 'MDN') {
          //   $scope.showPreview = false;
          //   toastr.success("Docketing notice was successfully entered in PTAB E2E", {
          //     iconClass: 'toast-success'
          //   });
          //   toastr.success("Upload to IFW was successful", {
          //     iconClass: 'toast-success'
          //   });

          //   if ($rootScope.isMergedCase) {
          //     toastr.success($scope.shareAssign[0].title + " assignments for " + $rootScope.mergedApplListForToastr + " have been closed.", {
          //       iconClass: 'toast-success'
          //     });
          //   }

          //   $scope.fileToEmail = pdfData.value.fileName;
          //   if (pdfData.value.deliveryMode === 'Electronic' || pdfData.value.deliveryMode === 'EMAIL') {
          //     $scope.showButtons = false;
          //     toastr.success("Docketing notice assignment has been closed.", {
          //       iconClass: 'toast-success'
          //     });
          //   } else {
          //     $scope.showButtons = true;
          //   }
          //   $scope.uploadPdfContent = 'data:application/pdf;base64,' + pdfData.value.fileContent;
          //   if (pdfData.value.fileContent !== undefined) {
          //     $rootScope.pdfRefresh = true;
          //   } else {
          //     $rootScope.pdfRefresh = false;
          //   }
          //   $scope.getPreview($scope.uploadPdfContent);
          // } else if ($scope.shareAssign[0].assignmentType === 'MSDD') {
          //   $scope.showPreview = false;
          //   toastr.success("Subsequent decision for Case " + $scope.shareAssign[0].appealNumber + " has been successfully uploaded to IFW.", {
          //     iconClass: 'toast-success'
          //   });
          //   $scope.fileToEmail = pdfData.value.fileName;
          //   if (pdfData.value.deliveryMode === 'Electronic' || pdfData.value.deliveryMode === 'EMAIL') {
          //     $scope.showButtons = false;
          //     toastr.success("Mailing assignment has been successfully closed.", {
          //       iconClass: 'toast-success'
          //     });
          //   } else {
          //     $scope.showButtons = true;
          //   }
          //   $scope.uploadPdfContent = 'data:application/pdf;base64,' + pdfData.value.fileContent;
          //   if (pdfData.value.fileContent !== undefined) {
          //     $rootScope.pdfRefresh = true;
          //   } else {
          //     $rootScope.pdfRefresh = false;
          //   }
          //   $scope.getPreview($scope.uploadPdfContent);
          // }

          // }
        });
      };

      $scope.selectDocuments = function () {
        ngDialog.open({
          template: "app/components/widgets/assignments/src/addFileNOH.html",
          controller: 'enterNohController',
          scope: $scope,
          width: '45%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,

          resolve: {
            partiesData: function () {
              return $scope.caseDetailsData;
            },
            partiesFlag: function () {
              return $scope.partiesShow;
            }

          }
        }).closePromise.then(function (data) {
          if (data.value !== "No file" && data.value !== 0) {
            $scope.fileNumber = data.value;
          }
          $scope.getMetaData($scope.shareAssign[0].serialNumber, $scope.shareAssign[0].appealNumber);

        }, function () {
          // intentional
        });
      };

      //get call for preview
      /* istanbul ignore next */
      $scope.getPreview = function (contents) {

        $http.get(contents, {
          responseType: 'arraybuffer',
          headers: {
            'Accept': 'application/pdf'
          }
        })
          .success(function (data) {
            var file = new Blob([data], {
              type: 'application/pdf'
            });
            $scope.showPreview = false;
            var fileURL = URL.createObjectURL(file);
            var fileOne = window.URL.createObjectURL(file);
            $scope.pdfContent = $sce.trustAsResourceUrl(fileOne);

            if (null !== $scope.pdfContent && document.getElementById('userGenPreview') !== null) {
              angular.element(document.getElementById('userGenPreview')).scope().pdfContent = $sce.trustAsResourceUrl(fileURL);
            } else {
              $scope.pdfContent = $sce.trustAsResourceUrl(fileURL);
            }

            if (fileURL !== '' || angular.isDefined(fileURL)) {
              $scope.show = false;
              $scope.editable = false;
              $scope.pdfStyle = {
                "border": "1px solid grey"
              };
            }
          }).error(function (res) {
            // intentional
          });
      };

      $scope.requestConfirmation = function () {
        if ($scope.hStatus.selectedStatusType == "HG") {
          var data = {};
          data.title = "Confirmation";
          data.message = "Case " + $scope.shareAssign[0].appealNumber + " has Fast-Track status. Uploading oral hearing reschedule grant order will remove the fast-track status for this case.";
          ngDialog.openConfirm({
            template: 'app/circulation/confirmRequestModal.html',
            controller: 'ConfirmRequestModalController',
            data: data,
            width: '30%',
            controllerAs: 'vm'
          }).then(function () {
            $scope.systemGeneratePdf();
          });
        }
        else {
          $scope.systemGeneratePdf();
        }
      }

    });
})();
