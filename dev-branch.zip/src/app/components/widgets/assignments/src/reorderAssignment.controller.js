(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('ReorderPanelAssignmentController', function (CommonHelperService, CONSTANTS, HttpFactory, $rootScope, ngDialog, $window, toastr) {
      var vm = this;
      var assignmentInfo = $rootScope.sharedItems[0];
      vm.selectedDiscipline = "";
      vm.selectedSection = "";
      vm.patentAttorneyExists = false;
      vm.originalPatentAttorney = {
        panelRank: null,
        name: null,
        identifier: null
      };
      vm.comments = null;
      var apj1Name;
      vm.panelToBeDeleted = [];
      vm.updating = false;
      vm.panelChanged = false;



      function getPanel() {
        var url = "/circulation/getPanelReorderDetails?appealNumber=" + assignmentInfo.appealNumber + "&serialNumber=" + assignmentInfo.serialNumber;
        // var url = "/circulation/getPanelReorderDetails?appealNumber=2019006009&serialNumber=14902242";
        HttpFactory.getActions(url)
          .then(function (getPanelSuccess) {
            console.log('getPanelSuccess: ', getPanelSuccess);
            vm.originalPanel = setPanelForDisplay(getPanelSuccess.data.originalPanel);
            vm.requestedPanel = setPanelForDisplay(getPanelSuccess.data.requestedPanel);
            vm.updatedPanel = angular.copy(vm.requestedPanel);

            vm.requestedPanelToDisplayString = " ";
            for (var i = 0; i < vm.requestedPanel.length; i++) {
              vm.requestedPanelToDisplayString += vm.requestedPanel[i].name;
              if (i !== vm.requestedPanel.length - 1) {
                vm.requestedPanelToDisplayString += " | ";
              }
            }


            vm.getAttorneyList();
          }, function (getPanelFailure) {
            console.log('getPanelFailure: ', getPanelFailure);
          });
      }

      getPanel();


      /** This function will retrieve the list of disciplines
       * Code is commented out unti4l discipline user story is created
       */
      function getDisciplineList() {
        HttpFactory.getActions(CONSTANTS.URL.GET_DISCIPLINES)
          .then(function (successResponse) {
            vm.disciplineList = successResponse.data;
          }, function () {
            toastr.error(CONSTANTS.TOASTER.disciplines, {
              iconClass: 'toast-danger'
            });
          });
      }

      getDisciplineList();

      /** This function will retrieve the list of sections */
      function getSectionList() {
        HttpFactory.getActions(CONSTANTS.URL.GET_SECTIONS)
          .then(function (successResponse) {
            vm.sectionList = successResponse.data;

          }, function () {
            toastr.error(CONSTANTS.TOASTER.selections, {
              iconClass: 'toast-danger'
            });
          });
      }

      getSectionList();

      /** This function will retrieve a list of judges. On initial load, or if 'all' is selected from dropdown,
       * all judges will be displayed. It will also remove the judges that are on the panel from the judge list
       */
      vm.getJudgeList = function (params) {
        var url = setUrl(params);
        HttpFactory.getActions(url)
          .then(function (successResponse) {
            vm.judgeList = successResponse.data;
            for (var i = 0; i < vm.judgeList.length; i++) {
              angular.forEach(vm.judgesToPanel, function (paneledJudge) {
                if (paneledJudge.assigneeNumberText === vm.judgeList[i].assigneeNumberText) {
                  vm.judgeList.splice(i, 1);
                }
              });
            }
            vm.originalJudgeList = angular.copy(successResponse.data);
            console.log();
          }, function () {
            toastr.error(CONSTANTS.TOASTER.judges, {
              iconClass: 'toast-danger'
            });
            vm.judgeList = [];
          });
      };

      vm.getJudgeList('initialLoad');

      function setUrl(params) {
        // Get all judges on initial load or if "Select a discipline/section" is selected or "all" is selected for both
        if (params === "initialLoad" || (vm.selectedDiscipline === "" &&
            vm.selectedSection === "") ||
          (vm.selectedDiscipline === "all" &&
            vm.selectedSection === "all")) {
          return CONSTANTS.URL.GET_ALL_JUDGES;
        }
        // If both discipline and section are selected
        if (angular.isDefined(vm.selectedDiscipline) && vm.selectedDiscipline !== "" && angular.isDefined(vm.selectedSection) && vm.selectedSection !== "") {
          // If selected discipline is set to all, then all judges for the selected section are returned
          if (vm.selectedDiscipline === "all") {
            return CONSTANTS.URL.GET_JUDGES + "sectionText=" + vm.selectedSection;
            // If selected section is set to all, then all judges for the selected discipline are returned
          } else if (vm.selectedSection === "all") {
            return CONSTANTS.URL.GET_JUDGES + "disciplineCode=" + vm.selectedDiscipline;
            // Return the combined judge list
          } else {
            return CONSTANTS.URL.GET_JUDGES + "sectionText=" + vm.selectedSection + "&disciplineCode=" + vm.selectedDiscipline;
          }
          // Return list of judges based on selected discipline
        } else if (angular.isDefined(vm.selectedDiscipline) && vm.selectedDiscipline !== "" && vm.selectedDiscipline !== "all") {
          return CONSTANTS.URL.GET_JUDGES + "disciplineCode=" + vm.selectedDiscipline;
          // Return list of judges based on selected section
        } else if (angular.isDefined(vm.selectedSection) && vm.selectedSection !== "" && vm.selectedSection !== "all") {
          return CONSTANTS.URL.GET_JUDGES + "sectionText=" + vm.selectedSection;
          // Return all judges if either discipline or section is set to all and the other is set to "Select a ...."
        } else if ((vm.selectedDiscipline === "all" && vm.selectedSection === "") || (vm.selectedDiscipline === "" && vm.selectedSection === "all")) {
          return CONSTANTS.URL.GET_ALL_JUDGES;
        }
      }

      vm.criteriaMatch = function (input) {
        var tempList = [];
        if (angular.isDefined(input) && input.trim() !== "") {
          angular.forEach(vm.originalJudgeList, function (currentJudge) {
            if (currentJudge.assigneeFullNameText.toLowerCase().includes(input.toLowerCase())) {
              tempList.push(currentJudge);
            }
          });
          vm.judgeList = angular.copy(tempList);
        } else {
          tempList = angular.copy(vm.originalJudgeList);
          for (var i = 0; i < vm.updatedPanel.length; i++) {
            for (var j = 0; j < tempList.length; j++) {
              if (tempList[j].assigneeFullNameText === vm.updatedPanel[i].assigneeFullNameText) {
                tempList.splice(j, 1);
              }
            }
          }
          vm.judgeList = angular.copy(tempList);
        }
      };


      /** This function will move the judges from the judge list to the panel */
      vm.moveJudgeToPanel = function () {
        angular.forEach(vm.selectedJudges, function (column) {
          vm.addJudge = true;
          if (vm.updatedPanel.length === 0) {
            var judge = {
              name: vm.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIX)].assigneeFullNameText,
              identifier: vm.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIX)].assigneeNumberText
            };
            vm.updatedPanel.push(judge);
            vm.addJudge = false;
          } else {
            for (var i = 0; i < vm.updatedPanel.length; i++) {

              if (vm.updatedPanel[i].identifier === vm.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIX)].assigneeNumberText) {
                toastr.error(vm.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIX)].assigneeFullNameText + " has already been added to the panel", {
                  iconClass: 'toast-danger'
                });
                vm.addJudge = false;
                break;
              }
            }
          }
          if (vm.addJudge) {
            judge = {
              name: vm.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIX)].assigneeFullNameText,
              identifier: vm.judgeList[parseInt(column, CONSTANTS.GLOBAL.RADIX)].assigneeNumberText
            };
            vm.updatedPanel.push(judge);
          }
        });



        vm.selectedJudges.sort(function (a, b) {
          return b - a;
        });

        angular.forEach(vm.selectedJudges, function (column) {
          vm.judgeList.splice(parseInt(column, CONSTANTS.GLOBAL.RADIX), 1);
        });

        vm.clickedColumn = [];
        vm.panelChanged = true;

        vm.disableMove = true;
        //validateSubmit();
      };

      /** This function will disable the submit panel button until at least 3 judges are paneled */
      function validateSubmit() {
        vm.disableSubmitPanel = false;
        //var ewfElement = angular.element(document.getElementById("ewfUpdated")).scope();

        if (vm.updatedPanel.length < 3 && vm.updatedPanel.length >= 0) {
          vm.disableSubmitPanel = true;
        }


        vm.getAttorneyList();
      }

      /** This function will limit the list of selected judges to 9
       * This is subject to removal once the PO's decide on a maximum number of allowed judges on the panel
       */
      vm.dataSelected = function (judge) {
        vm.disableMove = false;
        vm.selectedJudges = judge;
      };


      /** This function will remove the judge from the panel */
      vm.removeJudgeFromPanel = function (index) {
        var toDelete = {
          "identifier": vm.updatedPanel[index].identifier,
          "panelRank": index + 1
        };
        vm.panelToBeDeleted.push(toDelete);
        vm.updatedPanel.splice(index, 1);
        vm.getAttorneyList();
        validateSubmit();
        if (vm.judgesToPanel.length === 0) {
          vm.noAttorney = true;
        }
        if (index === 0) {
          vm.selectedAttorney = 'default';
        }
        vm.panelChanged = true;
      };

      function setPanelForDisplay(panel) {
        var panelToDisplay = [];
        angular.forEach(panel, function (panelMember) {
          var panelToAdd = {
            panelRank: null,
            name: null
          };
          if (panelMember.panelRank > 0) {
            panelToAdd.panelRank = panelMember.panelRank;
            panelToAdd.name = panelMember.panelName;
            panelToAdd.identifier = panelMember.identifier;
            panelToDisplay.push(panelToAdd);
          }
          if (panelMember.panelRank === 0) {
            vm.originalPatentAttorney.panelRank = panelMember.panelRank;
            vm.originalPatentAttorney.name = panelMember.panelName;
            vm.originalPatentAttorney.identifier = panelMember.identifier;
            vm.patentAttorneyExists = true;
          }
        });
        return panelToDisplay;
      }


      /** This function will move the selected judge in the panel up */
      vm.listUp = function (itemIndex) {
        vm.panelChanged = true;
        vm.updatedPanel = CommonHelperService.moveListItem(vm.updatedPanel, itemIndex, itemIndex - 1);
      };

      /** This function will move the selected judge in the panel down */
      vm.listDown = function (itemIndex) {
        vm.panelChanged = true;
        vm.updatedPanel = CommonHelperService.moveListItem(vm.updatedPanel, itemIndex, itemIndex + 1);
      };


      /** This function will retrieve a list of attorneys based on the first selected judge in the panel (APJ1) */
      /* istanbul ignore next */
      vm.getAttorneyList = function () {
        if (vm.updatedPanel.length > 0) {
          HttpFactory.getActions(CONSTANTS.URL.GET_ATTORNEY_LIST + vm.originalPanel[0].identifier)
            .then(function (successResponse) {
              var assignedList = successResponse.data.assignedAttorneyList;
              assignedList.push({
                assigneeNumberText: "divider",
                assigneeFullNameText: "---------------"
              });
              vm.attorneyList = assignedList.concat(successResponse.data.nonAssignedAttorneyList);

              vm.noAttorney = false;

              if (vm.patentAttorneyExists) {
                vm.selectedAttorney = angular.copy(vm.originalPatentAttorney.identifier);
              } else {
                vm.selectedAttorney = 'default';
              }
            }, function (failureResponse) {
              vm.attorneyList = [];
              console.log(failureResponse);
              vm.selectedAttorney = 'default';
              vm.noAttorney = true;
            });
        }

      };

      function verifyPanelChange() {
        var patentAttorneyChanged;
        var panelChanged;


        if (vm.patentAttorneyExists || vm.selectedAttorney !== 'default') {
          if (vm.selectedAttorney === vm.originalPatentAttorney.identifier) {
            patentAttorneyChanged = false;
          } else {
            patentAttorneyChanged = true;
          }
        } else {
          patentAttorneyChanged = false;
        }


        var panelToCheck = angular.copy(vm.updatedPanel);
        for (var i = 0; i < panelToCheck.length; i++) {
          panelToCheck[i].panelRank = i + 1;
        }
        if (angular.equals(panelToCheck, vm.originalPanel)) {
          panelChanged = false;
          vm.panelChanged = true;
        } else {
          panelChanged = true;
        }


        if (vm.panelChanged || patentAttorneyChanged) {

          // if (!panelChanged && ((vm.patentAttorneyExists && !patentAttorneyChanged) || (!vm.patentAttorneyExists))) {
          if (!panelChanged && !patentAttorneyChanged) {
            var modalInfo = {
              "title": "Panel order has not changed!",
              "message": "The current panel must be reordered in order to update a panel. Please go back and change the order of the judges on the panel or click the Deny request button to deny the panel reordering."
            };
            ngDialog.open({
              template: 'app/circulation/reorderPanel/orderNotChanged.model.html',
              controller: 'OrderNotChangedController',
              controllerAs: 'vm',
              width: '30%',
              showClose: false,
              closeByEscape: false,
              closeByDocument: false,
              resolve: {
                modalInfo: function () {
                  return modalInfo;
                }
              }
            }).closePromise.then(function () {
              return false;
            }, function () {
              // intentional
            });
          } else {
            return true;
          }
        } else {
          return true;
        }
      }



      vm.denyRequest = function () {
        if (!vm.comments) {
          var title = document.getElementById('commentTitle');
          var commentText = document.getElementById('commentText');
          title.classList.add('commentNeededTitle');
          commentText.classList.add('commentNeeded');
        } else {
          submitRequest(preparePanel(false), 'deny');
        }
      };

      vm.approveRequest = function () {
        if (verifyPanelChange()) {
          submitRequest(preparePanel(true), 'approve');
        }
      };

      function preparePanel(panelApproveFlag) {
        var newPanelCopy = angular.copy(vm.updatedPanel);
        for (var i = 0; i < newPanelCopy.length; i++) {
          newPanelCopy[i].panelRank = i + 1;
          if (newPanelCopy[i].panelRank === 1) {
            apj1Name = newPanelCopy[i].name;
          }
          delete newPanelCopy[i].name;
        }
        if (vm.patentAttorneyExists) {
          if (!angular.isObject(vm.selectedAttorney)) {
            var selectedAtt = {
              panelRank: 0,
              identifier: vm.selectedAttorney
            };
            newPanelCopy.unshift(selectedAtt);
          } else {
            if (vm.selectedAttorney.name) {
              delete vm.selectedAttorney.name;
            }
            vm.selectedAttorney.panelRank = 0;
            newPanelCopy.unshift(vm.selectedAttorney);
          }
        }
        var currentTime = Math.floor(new Date().getTime() / 1000);
        var panelObj = {
          "serialNumber": assignmentInfo.serialNumber,
          "appealNumber": assignmentInfo.appealNumber,
          "audit": {
            "lastModifiedTimestamp": currentTime,
            "lastModifiedUserIdentifier": $window.sessionStorage.getItem("workerNumber"),
            "createUserIdentifier": $window.sessionStorage.getItem("workerNumber"),
            "lockControlNumber": 0
          },
          "panelAssignment": {
            "assignmentIdentifier": assignmentInfo.assignmentIdentifier,
            "assignmentType": assignmentInfo.assignmentType,
            "assignee": assignmentInfo.assignee,
            "serialNumber": assignmentInfo.serialNumber,
            "title": assignmentInfo.title,
            "description": assignmentInfo.description,
            "dueDate": assignmentInfo.dueDate,
            "completionDate": Math.floor(new Date().getTime() / 1000),
            "caseType": assignmentInfo.caseType,
            "appealNumber": assignmentInfo.appealNumber,
            "sequenceNumber": assignmentInfo.sequenceNumber,
            "notes": null,
            "completionCode": 'COMPLETE',
            "priorityIndicator": assignmentInfo.priorityIndicator === true ? "Y" : "N",
            "audit": {
              "createUserIdentifier": $window.sessionStorage.getItem("workerNumber"),
              "lastModifiedUserIdentifier": $window.sessionStorage.getItem("workerNumber"),
              "lockControlNumber": 0
            }
          },
          "judgePanel": {
            "panelToBeCreated": newPanelCopy,
            "panelToBeDeleted": null,
            "panelNotes": null,
            "panelDate": 1566353215000,
            "reconsiderSequenceNumber": 0,
            "sequenceNumber": 1
          },
          "panelReorder": {
            "reorderRejectedNotes": vm.comments,
            "panelReorderApproved": panelApproveFlag
          }
        };
        console.log(panelObj);
        return panelObj;
      }


      function submitRequest(requestObj, messageToSet) {
        vm.updating = true;
        HttpFactory.putActions('/circulation/panel-reorder-decision', requestObj)
          .then(function (denySuccess) {
            console.log('denySuccess: ', denySuccess);
            var message;
            if (messageToSet === 'deny') {
              message = "Reorder Panel request has been denied and asssignment closed. A note has been added to the circulation notes and a notification sent to " + apj1Name + " (APJ1).";
            } else if (messageToSet === 'approve') {
              message = 'Panel order has been updated and this assignment has been closed. Circulation assignments have also been updated';
            }
            CommonHelperService.setToastr(message, "success");
            ngDialog.closeAll();
            vm.updating = false;
          }, function (denyFailure) {
            console.log('denyFailure: ', denyFailure);
            vm.updating = false;
          });
      }

      vm.validateComments = function () {
        if (vm.comments) {
          var title = document.getElementById('commentTitle');
          var commentText = document.getElementById('commentText');
          title.classList.remove('commentNeededTitle');
          commentText.classList.remove('commentNeeded');
        }
      };


    });
})();
