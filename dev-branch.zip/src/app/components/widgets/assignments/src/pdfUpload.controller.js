(function () {
  'use strict';
  /**
   * pdfUpload Controller is attached to the confirm pdf upload dialog
   */
  angular
    .module('ptabe2e')
    .controller('pdfUploadController', function (ngDialog, HttpFactory, CONSTANTS, $scope, $rootScope, docketInfo,
      panelData, $http, $sce, genPdfFile, decisionType, decisionDueDate, decisionDate, judgeList, CommonHelperService,
      hearingRoomRosterData, adSequenceNumber, reconsiderSequenceNumber, $log, mailer, $window, dockType, appealDecisionData) {
      var vm = this;
      // $rootScope.responseFail = false;
      var scope = angular.element(document.getElementById('mainTabId')).scope();
      $scope.currentDocketInfo = angular.copy(docketInfo[0]);
      $scope.docInfo = docketInfo[0];
      $scope.mailer = mailer;
      $scope.decisionDate = decisionDate;
      $scope.decisionType = decisionType;
      $scope.decisionDueDate = decisionDueDate;
      $scope.judgeList = judgeList;
      $scope.adSequenceNumber = adSequenceNumber;
      $scope.reconsiderSequenceNumber = reconsiderSequenceNumber;
      $scope.hearingRoomRosterData = hearingRoomRosterData;
      $scope.title = $scope.docInfo.docFlag ? "Upload documents?" : "Update status code?";
      $scope.message = $scope.docInfo.docFlag ? "Are you sure you want to upload the document?" : "Are you sure you want to update the status codes?";
      $scope.dockType = dockType;
      $scope.appealDecisionData = appealDecisionData;
      if (docketInfo[0].assignmentType === 'MDN') {
        $scope.disableAssignmentType = true;
      } else {
        $scope.disableAssignmentType = false;
      }
      if (scope && scope.vm && scope.vm.userInfo) {
        vm.userInfo = scope.vm.userInfo;
      } else if (scope && scope.userInfo) {
        vm.userInfo = scope.userInfo;
      } else {
        vm.userInfo = {
          userId: $window.sessionStorage.getItem("workerNumber")
        };
      }

      $scope.showError = false;
      $scope.closeAnnouncementDialog = function (popupsToClose, pdfData) {
        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose], pdfData);
        } else {
          ngDialog.close();
        }
      };


      /* function to confirm  pdf upload */
      $scope.upload = function () {
         $scope.disableUpload = true;
        $scope.currentDocketInfo.priorityIndicator = $scope.currentDocketInfo.priorityIndicator ? 'Y' : 'N';
        $scope.currentDocketInfo.completionCode = "MAIL";
        docketInfo[0].priorityIndicator = docketInfo[0].priorityIndicator ? 'Y' : 'N';
        docketInfo[0].completionCode = "MAIL";
        if ($scope.hearingRoomRosterData) {
          $scope.currentDocketInfo.completionCode = "MAIL_" + $scope.hearingRoomRosterData.locationStateCd;
          docketInfo[0].completionCode = "MAIL_" + $scope.hearingRoomRosterData.locationStateCd;
        }
        docketInfo[0].audit = {
          "createUserIdentifier": docketInfo[0].audit.createUserIdentifier,
          "lastModifiedUserIdentifier": vm.userInfo.userId,
          "lastModifiedTimestamp": new Date().getTime(),
          "createdUserName": docketInfo[0].audit.creatorUserName,
          "lastModifiedUserName": docketInfo[0].audit.lastModifiedUserName,
          "createTimestamp": docketInfo[0].audit.assignmentCreateTs,
          "lockControlNumber": docketInfo[0].audit.assignmentLockControlNo
        };
        var pdfUploadObject = {
          "serialNumber": docketInfo[0].serialNumber,
          "appealNumber": docketInfo[0].appealNumber,
          "fileName": genPdfFile,
          "docType": $scope.dockType,
          "currentAssignment": $scope.currentDocketInfo,
          "newAssignment": docketInfo[0],
          "audit": {
            "createUserIdentifier": docketInfo[0].audit.createUserIdentifier,
            "lastModifiedUserIdentifier": vm.userInfo.userId,
            "lastModifiedTimestamp": new Date().getTime(),
            "createdUserName": docketInfo[0].audit.creatorUserName,
            "lastModifiedUserName": docketInfo[0].audit.lastModifiedUserName,
            "createTimestamp": docketInfo[0].audit.assignmentCreateTs,
            "lockControlNumber": docketInfo[0].audit.assignmentLockControlNo
          }
        };

        HttpFactory.postActions(CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.UPLOADPTAB_NOTICE, pdfUploadObject)
          .then(function (successResponse) {
            $scope.disableUpload = false;
            $scope.showError = false;
            $scope.PostDataResponse = successResponse.data;
            $scope.closeAnnouncementDialog(1, $scope.PostDataResponse);
          }, function (failureResponse) {
            $scope.disableUpload = false;
            $scope.showError = true;
            $scope.failedResponse = failureResponse.data.message;
          });
      };

      /* function to upload ARP */
      $scope.arpUpload = function () {
        $scope.disableUpload = true;
       $scope.currentDocketInfo.priorityIndicator = $scope.currentDocketInfo.priorityIndicator ? 'Y' : 'N';
       $scope.currentDocketInfo.completionCode = "COMPLETE";
       docketInfo[0].priorityIndicator = docketInfo[0].priorityIndicator ? 'Y' : 'N';
       docketInfo[0].completionCode = "COMPLETE";
       var pdfUploadObject = {
         "serialNumber": docketInfo[0].serialNumber,
         "appealNumber": docketInfo[0].appealNumber,
         "fileName": genPdfFile,
         "docType": $scope.dockType,
         "currentAssignment": $scope.currentDocketInfo,
         "newAssignment": docketInfo[0],
         "audit": {
           "createUserIdentifier": docketInfo[0].audit.createUserIdentifier,
           "lastModifiedUserIdentifier": vm.userInfo.userId,
           "lastModifiedTimestamp": new Date().getTime(),
           "createdUserName": docketInfo[0].audit.creatorUserName,
           "lastModifiedUserName": docketInfo[0].audit.lastModifiedUserName,
           "createTimestamp": docketInfo[0].audit.assignmentCreateTs,
           "lockControlNumber": docketInfo[0].audit.assignmentLockControlNo
         }
       };
       HttpFactory.postActions(CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.UPLOADPTAB_NOTICE, pdfUploadObject)
         .then(function (successResponse) {
           $scope.disableUpload = false;
           $scope.showError = false;
           $scope.PostDataResponse = successResponse.data;
           $scope.closeAnnouncementDialog(1, $scope.PostDataResponse);
         }, function (failureResponse) {
           $scope.disableUpload = false;
           $scope.showError = true;
           $scope.failedResponse = failureResponse.data.message;
         });
     };


      /* function to confirm  pdf upload */
      $scope.uploadPetition = function () {
        $scope.disableUpload = true;
       $scope.currentDocketInfo.priorityIndicator = $scope.currentDocketInfo.priorityIndicator ? 'Y' : 'N';
       $scope.currentDocketInfo.completionCode =  docketInfo[0].completionCode;
       docketInfo[0].priorityIndicator = docketInfo[0].priorityIndicator ? 'Y' : 'N';
    //   docketInfo[0].completionCode = "MAIL";
       if ($scope.hearingRoomRosterData) {
         $scope.currentDocketInfo.completionCode = "MAIL_" + $scope.hearingRoomRosterData.locationStateCd;
         docketInfo[0].completionCode = "MAIL_" + $scope.hearingRoomRosterData.locationStateCd;
       }
       docketInfo[0].audit = {
         "createUserIdentifier": docketInfo[0].audit.createUserIdentifier,
         "lastModifiedUserIdentifier": vm.userInfo.userId,
         "lastModifiedTimestamp": new Date().getTime(),
         "createdUserName": docketInfo[0].audit.creatorUserName,
         "lastModifiedUserName": docketInfo[0].audit.lastModifiedUserName,
         "createTimestamp": docketInfo[0].audit.assignmentCreateTs,
         "lockControlNumber": docketInfo[0].audit.assignmentLockControlNo
       };
       var pdfUploadObject = {
         "serialNumber": docketInfo[0].serialNumber,
         "appealNumber": docketInfo[0].appealNumber,
         "fileName": genPdfFile,
         "docType": $scope.dockType,
         "currentAssignment": $scope.currentDocketInfo,
         "newAssignment": docketInfo[0],
         "audit": {
           "createUserIdentifier": docketInfo[0].audit.createUserIdentifier,
           "lastModifiedUserIdentifier": vm.userInfo.userId,
           "lastModifiedTimestamp": new Date().getTime(),
           "createdUserName": docketInfo[0].audit.creatorUserName,
           "lastModifiedUserName": docketInfo[0].audit.lastModifiedUserName,
           "createTimestamp": docketInfo[0].audit.assignmentCreateTs,
           "lockControlNumber": docketInfo[0].audit.assignmentLockControlNo
         }
       };
       pdfUploadObject.inPetition = true;
       pdfUploadObject.petitionId = $rootScope.sharedItems[0].petitionId;
       pdfUploadObject.petitionTypeCode =  $rootScope.sharedItems[0].petitionTypeCode;
       HttpFactory.postActions(CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.UPLOADPTAB_NOTICE, pdfUploadObject)
         .then(function (successResponse) {
           $scope.disableUpload = false;
           $scope.showError = false;
           $scope.PostDataResponse = successResponse.data;
           $scope.closeAnnouncementDialog(1, $scope.PostDataResponse);
         }, function (failureResponse) {
           $scope.disableUpload = false;
           $scope.showError = true;
           $scope.failedResponse = failureResponse.data.message;
         });
     };



      /* function to confirm miscellaneous pdf upload */
      $scope.uploadMiscDoc = function () {
        $scope.disableUpload = true;
        $scope.currentDocketInfo.priorityIndicator = $scope.currentDocketInfo.priorityIndicator ? 'Y' : 'N';
        $scope.currentDocketInfo.completionCode = "MISC";
        docketInfo[0].priorityIndicator = docketInfo[0].priorityIndicator ? 'Y' : 'N';
        docketInfo[0].completionCode = "MISC";
        docketInfo[0].audit = {
          "createUserIdentifier": docketInfo[0].audit.createUserIdentifier,
          "lastModifiedUserIdentifier": vm.userInfo.userId,
          "lastModifiedTimestamp": new Date().getTime(),
          "createdUserName": docketInfo[0].audit.creatorUserName,
          "lastModifiedUserName": docketInfo[0].audit.lastModifiedUserName,
          "createTimestamp": docketInfo[0].audit.assignmentCreateTs,
          "lockControlNumber": docketInfo[0].audit.assignmentLockControlNo
        };
        var miscDoc = {
          "serialNumber": docketInfo[0].serialNumber,
          "appealNumber": docketInfo[0].appealNumber,
          "fileName": genPdfFile,
          "docType": $scope.dockType,
          "currentAssignment": $scope.currentDocketInfo,
          "newAssignment": docketInfo[0],
          "sequenceNumber": 0,
          "audit": {
            "createUserIdentifier": docketInfo[0].audit.createUserIdentifier,
            "lastModifiedUserIdentifier": vm.userInfo.userId,
            "lastModifiedTimestamp": new Date().getTime(),
            "createdUserName": docketInfo[0].audit.createdUserName,
            "lastModifiedUserName": docketInfo[0].audit.lastModifiedUserName,
            "createTimestamp": docketInfo[0].audit.createTimestamp,
            "lockControlNumber": docketInfo[0].audit.lockControlNumber
          },
        };
        HttpFactory.postActions(CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.UPLOADPTAB_MISC, miscDoc)
          .then(function (successResponse) {
            $scope.disableUpload = false;
            $scope.showError = false;
            $scope.PostDataResponse = successResponse.data;
            $scope.closeAnnouncementDialog(1, $scope.PostDataResponse);
          }, function (failureResponse) {
            $scope.disableUpload = false;
            $scope.showError = true;
            $scope.failedResponse = failureResponse.data.message;
            $scope.closeAnnouncementDialog(1, $scope.failedResponse);
          });
      };

      $scope.uploadMiscDecisionHistory = function () {
        HttpFactory.putActions(CONSTANTS.URL.UPDATE_DECISION_HISTORY, $scope.appealDecisionData)
          .then(function (successResponse) {
            // $scope.disableUpload = false;
            // $scope.loading = false;
            // $scope.hideAdd = false;
            // $scope.pdf = successResponse.data;
            // $scope.closeAnnouncementDialog(1, $scope.pdf);
            $scope.mailDecisionUpload();
          }, function (failureResponse) {
            CommonHelperService.setToastr(failureResponse.data.message, "error");
            $scope.disableUpload = false;
            $scope.showPreview = true;
            $scope.loading = false;
          });
      }


      /* function to confirm  pdf upload */
      $scope.processDismisalupload = function () {
        $scope.disableUpload = true;
        $scope.currentDocketInfo.priorityIndicator = $scope.currentDocketInfo.priorityIndicator ? 'Y' : 'N';
        $scope.currentDocketInfo.completionCode = "Complete";
        $scope.currentDocketInfo.audit.lastModifiedUserIdentifier = vm.userInfo.userId;
        docketInfo[0].priorityIndicator = docketInfo[0].priorityIndicator ? 'Y' : 'N';
        docketInfo[0].completionCode = "Complete";
        // docketInfo[0].audit = {
        //   "createUserIdentifier": docketInfo[0].audit.createUserIdentifier,
        //   "lastModifiedUserIdentifier": vm.userInfo.userId,
        //   "lastModifiedTimestamp": new Date().getTime(),
        //   "createdUserName": docketInfo[0].audit.createdUserName,
        //   "lastModifiedUserName": docketInfo[0].audit.lastModifiedUserName,
        //   "createTimestamp": docketInfo[0].audit.createTimestamp,
        //   "lockControlNumber": docketInfo[0].audit.lockControlNumber
        // }
        var pdfUploadObject = {
          "serialNumber": docketInfo[0].serialNumber,
          "appealNumber": docketInfo[0].appealNumber,
          "fileName": genPdfFile,
          "docType": $scope.dockType,
          "currentAssignment": $scope.currentDocketInfo,
          "newAssignment": docketInfo[0],
          'judgeData': {
            "identifier": panelData.assigneeNumberText
          },
          "audit": {
            "createUserIdentifier": docketInfo[0].audit.createUserIdentifier,
            "lastModifiedUserIdentifier": vm.userInfo.userId,
            "lastModifiedTimestamp": new Date().getTime(),
            "createdUserName": docketInfo[0].audit.createdUserName,
            "lastModifiedUserName": docketInfo[0].audit.lastModifiedUserName,
            "createTimestamp": docketInfo[0].audit.createTimestamp,
            "lockControlNumber": docketInfo[0].audit.lockControlNumber
          },
          "hearingRoomRosterData": $scope.hearingRoomRosterData
        };
        if (docketInfo[0].assignmentType === 'PDAP' || docketInfo[0].assignmentType === 'PARAP') {
          pdfUploadObject.judgeData.identifier = docketInfo.adminIdentifier;

          pdfUploadObject.panelDate = docketInfo.panelingDate;
          $scope.currentDocketInfo.notes = $rootScope.panelNotes;
        }
        HttpFactory.postActions(CONSTANTS.URL.PROCESSREMAND, pdfUploadObject)
          .then(function (successResponse) {

            $scope.disableUpload = false;
            $scope.showError = false;
            $scope.PostDataResponse = successResponse.data;
            $scope.closeAnnouncementDialog(1, $scope.PostDataResponse);
          }, function (failureResponse) {
            $scope.disableUpload = false;
            $scope.showError = true;
            $scope.failedResponse = failureResponse.data.message;
          });
      };



      /* function to close popup */
      $scope.cancel = function () {
        $scope.closeAnnouncementDialog(1);
      };
      /* istanbul ignore next */
      $scope.getPreview = function (contents) {

        $http.get(contents, {
            responseType: 'arraybuffer',
            headers: {
              'Accept': 'application/pdf'
            }
          })
          .success(function (data) {
            var file = new Blob([data], {
              type: 'application/pdf'
            });
            var fileURL = URL.createObjectURL(file);
            // $scope.uploadedPdfContent = $sce.trustAsResourceUrl(fileURL);
            var fileOne = window.URL.createObjectURL(file);
            // document.querySelector("iframe").src = $sce.trustAsResourceUrl(fileOne);
            $scope.pdfContent = $sce.trustAsResourceUrl(fileOne);
            if (fileURL !== '' || angular.isDefined(fileURL)) {
              $scope.show = false;
              $scope.editable = false;
              $scope.pdfStyle = {
                "border": "1px solid grey"
              };
            }

            closeAnnouncementDialog(1, $scope.PostDataResponse);
          }).error(function (res) {
            $log.info('ERROR' + res);
          });
      };

      /*MAIL DECISION*/
      $scope.mailDecisionUpload = function () {
        $scope.loading = true;
        $scope.disableUpload = true;

        $scope.docInfo.priorityIndicator = $scope.docInfo.priorityIndicator ? 'Y' : 'N';
        $scope.docInfo.completionCode = $scope.decisionType;
        $scope.currentAssignment = $scope.docInfo;
        if (angular.isUndefined($scope.decisionDate)) {
          $scope.decisionDate = null;
        }
        if (angular.isUndefined($scope.decisionDueDate)) {
          $scope.decisionDueDate = null;
        }
        if (angular.isUndefined($scope.judgeList)) {
          $scope.judgeList = null;
        }
        $scope.decisionObj = {
          "adReconsiderSequenceNumber": $scope.reconsiderSequenceNumber,
          "assignmentDate": null,
          "adSequenceNumber": $scope.adSequenceNumber,
          "workflowExclusionIndicator": "",
          "ruleComment": "",
          "decisionMailerName": $scope.mailer,
          "typistNote": "",
          "typistWorkflowExclIndicator": "",
          "decisionTypistName": "",
          "typingTypeCode": "",
          "decisionTypeCode": $scope.decisionType,
          "requestorCode": "",
          "decisionCategory": "",
          "palmDecisionMailedDate": null,
          "finalDecisionDate": new Date().getTime(),
          "decisionMailedDate": new Date().getTime(),
          "decisionTypedDate": null,
          "decisionDate": $scope.decisionDate,
          "decisionDueDate": $scope.decisionDueDate,
          "dueDateAssignedDate": null,
          "requestDate": null,
          "lifeCycle": null,
          "audit": {
            "lastModifiedTimestamp": new Date().getTime(),
            "lastModifiedUserIdentifier": vm.userInfo.userId,
            "createUserIdentifier": vm.userInfo.userId,
            "createdUserName": $scope.docInfo.audit.creatorUserName,
            "lastModifiedUserName": $scope.docInfo.audit.lastModifiedUserName,
            "createTimestamp": new Date().getTime(),
            "lockControlNumber": 0
          },
          "judgePanel": $scope.judgeList,
          "serialNumber": $scope.docInfo.serialNumber,
          "appealNumber": $scope.docInfo.appealNumber,
        };
        var data = {
          "decision": $scope.decisionObj,
          "decisionAssignment": $scope.currentAssignment,
          "fileName": genPdfFile,
          "docType": $scope.dockType
        };

        HttpFactory.putActions(CONSTANTS.URL.MAILDECISIONUPLOAD, data)
          .then(function (successResponse) {
            // if (docketInfo[0].assignmentType === 'MISCMD') {
            //   $scope.uploadMiscDecisionHistory();
            // }
            // else{
            $scope.disableUpload = false;
            $scope.loading = false;
            $scope.hideAdd = false;
            $scope.pdf = successResponse.data;
            $scope.closeAnnouncementDialog(1, $scope.pdf);
            //}
          }, function (failureResponse) {
            CommonHelperService.setToastr(failureResponse.data.message, "error");
            // toastr.clear();
            // toastr.error(failureResponse.data.message, {
            //   iconClass: 'toast-danger'
            // });
            $scope.disableUpload = false;
            $scope.showPreview = true;
            $scope.loading = false;
          });
      };



      /** Upload PTAB orders with or without document */
      $scope.uploadOrders = function () {
        $scope.disableUpload = true;
        $scope.currentDocketInfo.priorityIndicator = $scope.currentDocketInfo.priorityIndicator ? 'Y' : 'N';
        $scope.currentDocketInfo.completionCode = docketInfo[0].globalMetaData.panel.length > 0 ? "APJ_MAIL" : "MAIL";
        $scope.currentDocketInfo.completionDate = new Date().getTime();
        docketInfo[0].priorityIndicator = docketInfo[0].priorityIndicator ? 'Y' : 'N';
        docketInfo[0].completionCode = docketInfo[0].globalMetaData.panel.length > 0 ? "APJ_MAIL" : "MAIL";
        if (docketInfo[0].assignmentType == 'VD') {
          docketInfo[0].completionCode = 'MAIL';
          $scope.currentDocketInfo.completionCode = 'MAIL';
        }



        docketInfo[0].audit = {
          "createUserIdentifier": docketInfo[0].audit.createUserIdentifier,
          "lastModifiedUserIdentifier": vm.userInfo.userId,
          "lastModifiedTimestamp": new Date().getTime(),
          "createdUserName": docketInfo[0].audit.creatorUserName,
          "lastModifiedUserName": docketInfo[0].audit.lastModifiedUserName,
          "createTimestamp": docketInfo[0].audit.assignmentCreateTs,
          "lockControlNumber": docketInfo[0].audit.assignmentLockControlNo
        };
        var pdfUploadObject = {
          "serialNumber": docketInfo[0].serialNumber,
          "appealNumber": docketInfo[0].appealNumber,
          "fileName": docketInfo[0].docFlag ? genPdfFile : null,
          "docType": $scope.dockType,
          "currentAssignment": $scope.currentDocketInfo,
          "newAssignment": docketInfo[0],
          "audit": {
            "createUserIdentifier": docketInfo[0].audit.createUserIdentifier,
            "lastModifiedUserIdentifier": vm.userInfo.userId,
            "lastModifiedTimestamp": new Date().getTime(),
            "createdUserName": docketInfo[0].audit.creatorUserName,
            "lastModifiedUserName": docketInfo[0].audit.lastModifiedUserName,
            "createTimestamp": docketInfo[0].audit.assignmentCreateTs,
            "lockControlNumber": docketInfo[0].audit.assignmentLockControlNo
          }
        };

        HttpFactory.postActions(CONSTANTS.URL.UPLOAD_PTAB_ORDERS, pdfUploadObject)
          .then(function (successResponse) {
            $scope.disableUpload = false;
            $scope.showError = false;
            if (successResponse.data === "" && !docketInfo[0].docFlag) {
              $scope.PostDataResponse = 'closeAll';
            } else {
              $scope.PostDataResponse = successResponse.data;
            }
            $scope.closeAnnouncementDialog(1, $scope.PostDataResponse);
          }, function (failureResponse) {
            $scope.disableUpload = false;
            $scope.showError = true;
            $scope.failedResponse = failureResponse.data.message;
          });
      };
    });
})();
