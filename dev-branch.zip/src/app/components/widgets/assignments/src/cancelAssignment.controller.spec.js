(function () {
  'use strict';

  describe('CancelAssignmentController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close']);
    var controller, scope, $rootScope;
    var timeout;
    var originalcurrentAssignee, currentAssignee, originalData, newData;


    beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_) {
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      timeout = _$timeout_;


      controller = $controller('CancelAssignmentController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        originalcurrentAssignee: originalcurrentAssignee,
        currentAssignee: currentAssignee,
        originalData: originalData,
        newData: newData
      });
    }));

    describe('CancelAssignmentController ', function () {


      it('it should call closeDialog ', function () {

        var ngDialogArray = [ngDialog, ngDialog];
        expect(ngDialog.close).toBeDefined();
        expect(controller['closeDialog']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        controller.closeDialog();
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog);

        expect(ngDialog.close).toBeDefined();
        expect(controller['closeDialog']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.closeDialog();
        expect(ngDialog.close).toHaveBeenCalledWith();

      });

      it('it should call revertAllChanges ', function () {

        // expect(ngDialog.closeAll).toBeDefined();
        // expect(controller['revertAllChanges']).toBeDefined();
        // controller.revertAllChanges();
        // expect(ngDialog.closeAll).toHaveBeenCalledWith();

        var ngDialogArray = [ngDialog, ngDialog, ngDialog];
        expect(ngDialog.close).toBeDefined();
        expect(controller['revertAllChanges']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        controller.revertAllChanges();
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog);

        expect(ngDialog.close).toBeDefined();
        expect(controller['revertAllChanges']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.revertAllChanges();
        expect(ngDialog.close).toHaveBeenCalledWith();

      });


    });
  });
})();
