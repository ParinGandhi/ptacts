(function () {
  'use strict';

  describe('pdfUploadController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close']);
    var controller, scope, $rootScope;
    var $CommonHelperService;
    var pdfContent, docketInfo, mailedFrom, genPdfFile, panelData, decisionType, decisionDueDate, decisionDate, judgeList, toastr, hearingRoomRosterData, adSequenceNumber, reconsiderSequenceNumber, mailer, dockType;
    var successResponse, failureResponse, workerNumber;
    var $httpBackend, spy, $q, HttpFactoryDeferred;

    panelData = {
      assigneeNumberText: "5768"
    }
    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              workerNumber: "pgandhi"
            }
          }
        }
      }
    };


    var docketInfo = [{
      "assignmentIdentifier": 1589,
      "assignmentType": "DNMA",
      "assignmentTypeDescription": "0",
      "activeIndicator": "A",
      "assignedDate": "1532530402",
      "completionDate": "1532530402",
      "pendingLocationText": "Pending",
      "assignee": "5768",
      "serialNumber": "14368609",
      "sequenceNumber": "0",
      "reconsiderSequenceNo": "0",
      "palmMailedDate": "1532530402",
      "assignmentNo": "0",
      "title": "Import manager default title",
      "description": "Import manager default description",
      "assignor": "fhan",
      "dueDate": "1532530402",
      "assignmentStatusCode": "C",
      "caseType": "APPEAL",
      "creatorUserId": null,
      "createTs": "1532530402",
      "completerNumber": null,
      "proceedingCoreIdentifier": null,
      "proceedingSupIdentifier": null,
      "notes": "Test Appeal create Note",
      "preExistentIdentifier": null,
      "priorityIndicator": "Y",
      "audit": {
        "lastModifiedUserIdentifier": "465",
        "createUserIdentifier": "465",
        "lastModifiedTimestamp": "1532530402",
        "createdUserName": "fhan",
        "lastModifiedUserName": "fhan",
        "createTimestamp": "1532530402",
        "lockControlNumber": "0"
      }

    }];

    beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_, _$q_, HttpFactory, _CommonHelperService_) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      $CommonHelperService = _CommonHelperService_;
      HttpFactoryDeferred = _$q_.defer();

      spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);

      spyOn($CommonHelperService, 'setToastr').and.callFake(function () {
        return "toastr";
      });


      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      controller = $controller('pdfUploadController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory,
        pdfContent: pdfContent,
        docketInfo: docketInfo,
        mailedFrom: mailedFrom,
        genPdfFile: genPdfFile,
        panelData: panelData,
        decisionType: decisionType,
        decisionDueDate: decisionDueDate,
        decisionDate: decisionDate,
        judgeList: judgeList,
        hearingRoomRosterData: hearingRoomRosterData,
        adSequenceNumber: adSequenceNumber,
        reconsiderSequenceNumber: reconsiderSequenceNumber,
        mailer: mailer,
        dockType:dockType

      });
    }));

    describe('pdfUploadController ', function () {


      it('it should call cancel ', function () {

        var ngDialogArray = [ngDialog, ngDialog];
        var pdfData;
        expect(ngDialog.close).toBeDefined();
        expect(scope['cancel']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        scope.cancel();
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog, pdfData);

        expect(ngDialog.close).toBeDefined();
        expect(scope['cancel']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        scope.cancel();
        expect(ngDialog.close).toHaveBeenCalledWith();

      });

      it('it should call upload', function () {
        controller.userInfo = {
          userId: "pgandhi"
        }
        docketInfo = [{
          "assignmentIdentifier": 1589,
          "assignmentType": "DNMA",
          "assignmentTypeDescription": "0",
          "activeIndicator": "A",
          "assignedDate": "1532530402",
          "completionDate": "1532530402",
          "pendingLocationText": "Pending",
          "assignee": "5768",
          "serialNumber": "14368609",
          "sequenceNumber": "0",
          "reconsiderSequenceNo": "0",
          "palmMailedDate": "1532530402",
          "assignmentNo": "0",
          "title": "Import manager default title",
          "description": "Import manager default description",
          "assignor": "fhan",
          "dueDate": "1532530402",
          "assignmentStatusCode": "C",
          "caseType": "APPEAL",
          "creatorUserId": null,
          "createTs": "1532530402",
          "completerNumber": null,
          "proceedingCoreIdentifier": null,
          "proceedingSupIdentifier": null,
          "notes": "Test Appeal create Note",
          "preExistentIdentifier": null,
          "priorityIndicator": "Y",
          "audit": {
            "lastModifiedUserIdentifier": "465",
            "createUserIdentifier": "465",
            "lastModifiedTimestamp": "1532530402",
            "createdUserName": "fhan",
            "lastModifiedUserName": "fhan",
            "createTimestamp": "1532530402",
            "lockControlNumber": "0"
          }

        }];

        successResponse = {
          data: {
            "applicationDates": {
              "hearingStatus": null,
              "appealStatus": "DECISION",
              "noticeOfAppealDate": 760251600000,
              "appealBriefDate": 930542400000,
              "oralHearingRequestDate": 937281600000,
              "noticeOfHearingMailDate": 930542400000,
              "examinerAnswerDate": 782539200000,
              "replyBriefDate": 788677200000,
              "hearingDate": null,
              "docketingNoticeDate": null,
              "filingDate": 661755600000
            },
            "appealDates": {
              "hearingStatus": null,
              "appealStatus": "DECISION",
              "noticeOfAppealDate": 760251600000,
              "appealBriefDate": 930542400000,
              "oralHearingRequestDate": 937281600000,
              "noticeOfHearingMailDate": 930542400000,
              "examinerAnswerDate": 782539200000,
              "replyBriefDate": 788677200000,
              "hearingDate": null,
              "docketingNoticeDate": null,
              "filingDate": 661755600000
            },
            "trialDates": null
          }


        };

        expect(scope.upload).toBeDefined();
        scope.upload();

        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();

      });

      it('it should call upload', function () {

        controller.userInfo = {
          userId: "pgandhi"
        }
        docketInfo = [{
          "assignmentIdentifier": 1589,
          "assignmentType": "DNMA",
          "assignmentTypeDescription": "0",
          "activeIndicator": "A",
          "assignedDate": "1532530402",
          "completionDate": "1532530402",
          "pendingLocationText": "Pending",
          "assignee": "5768",
          "serialNumber": "14368609",
          "sequenceNumber": "0",
          "reconsiderSequenceNo": "0",
          "palmMailedDate": "1532530402",
          "assignmentNo": "0",
          "title": "Import manager default title",
          "description": "Import manager default description",
          "assignor": "fhan",
          "dueDate": "1532530402",
          "assignmentStatusCode": "C",
          "caseType": "APPEAL",
          "creatorUserId": null,
          "createTs": "1532530402",
          "completerNumber": null,
          "proceedingCoreIdentifier": null,
          "proceedingSupIdentifier": null,
          "notes": "Test Appeal create Note",
          "preExistentIdentifier": null,
          "priorityIndicator": "Y",
          "audit": {
            "lastModifiedUserIdentifier": "465",
            "createUserIdentifier": "465",
            "lastModifiedTimestamp": "1532530402",
            "createdUserName": "fhan",
            "lastModifiedUserName": "fhan",
            "createTimestamp": "1532530402",
            "lockControlNumber": "0"
          }

        }];

        successResponse = {
          data: {
            "applicationDates": {
              "hearingStatus": null,
              "appealStatus": "DECISION",
              "noticeOfAppealDate": 760251600000,
              "appealBriefDate": 930542400000,
              "oralHearingRequestDate": 937281600000,
              "noticeOfHearingMailDate": 930542400000,
              "examinerAnswerDate": 782539200000,
              "replyBriefDate": 788677200000,
              "hearingDate": null,
              "docketingNoticeDate": null,
              "filingDate": 661755600000
            },
            "appealDates": {
              "hearingStatus": null,
              "appealStatus": "DECISION",
              "noticeOfAppealDate": 760251600000,
              "appealBriefDate": 930542400000,
              "oralHearingRequestDate": 937281600000,
              "noticeOfHearingMailDate": 930542400000,
              "examinerAnswerDate": 782539200000,
              "replyBriefDate": 788677200000,
              "hearingDate": null,
              "docketingNoticeDate": null,
              "filingDate": 661755600000
            },
            "trialDates": null
          }


        };

        expect(scope.upload).toBeDefined();
        scope.upload();

        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();

      });

      it('upload failureResponse ', function () {

        var failureResponse = {
          data: {}
        };

        controller.userInfo = {
          userId: "pgandhi"
        }
        expect(scope.upload).toBeDefined();
        scope.upload();

        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });

      it('it should call processDismisalupload', function () {
        controller.userInfo = {
          userId: "pgandhi"
        }
        docketInfo = [{
          "assignmentIdentifier": 1589,
          "assignmentType": "DNMA",
          "assignmentTypeDescription": "0",
          "activeIndicator": "A",
          "assignedDate": "1532530402",
          "completionDate": "1532530402",
          "pendingLocationText": "Pending",
          "assignee": "5768",
          "serialNumber": "14368609",
          "sequenceNumber": "0",
          "reconsiderSequenceNo": "0",
          "palmMailedDate": "1532530402",
          "assignmentNo": "0",
          "title": "Import manager default title",
          "description": "Import manager default description",
          "assignor": "fhan",
          "dueDate": "1532530402",
          "assignmentStatusCode": "C",
          "caseType": "APPEAL",
          "creatorUserId": null,
          "createTs": "1532530402",
          "completerNumber": null,
          "proceedingCoreIdentifier": null,
          "proceedingSupIdentifier": null,
          "notes": "Test Appeal create Note",
          "preExistentIdentifier": null,
          "priorityIndicator": "Y",
          "audit": {
            "lastModifiedUserIdentifier": "465",
            "createUserIdentifier": "465",
            "lastModifiedTimestamp": "1532530402",
            "createdUserName": "fhan",
            "lastModifiedUserName": "fhan",
            "createTimestamp": "1532530402",
            "lockControlNumber": "0"
          }

        }];

        successResponse = {
          data: {
            "applicationDates": {
              "hearingStatus": null,
              "appealStatus": "DECISION",
              "noticeOfAppealDate": 760251600000,
              "appealBriefDate": 930542400000,
              "oralHearingRequestDate": 937281600000,
              "noticeOfHearingMailDate": 930542400000,
              "examinerAnswerDate": 782539200000,
              "replyBriefDate": 788677200000,
              "hearingDate": null,
              "docketingNoticeDate": null,
              "filingDate": 661755600000
            },
            "appealDates": {
              "hearingStatus": null,
              "appealStatus": "DECISION",
              "noticeOfAppealDate": 760251600000,
              "appealBriefDate": 930542400000,
              "oralHearingRequestDate": 937281600000,
              "noticeOfHearingMailDate": 930542400000,
              "examinerAnswerDate": 782539200000,
              "replyBriefDate": 788677200000,
              "hearingDate": null,
              "docketingNoticeDate": null,
              "filingDate": 661755600000
            },
            "trialDates": null
          }


        };

        expect(scope.processDismisalupload).toBeDefined();
        scope.processDismisalupload();

        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();

      });


      it('it should call processDismisalupload with PDAP', function () {
        controller.userInfo = {
          userId: "pgandhi"
        }
        docketInfo = [{
          "assignmentIdentifier": 1589,
          "assignmentType": "PDAP",
          "assignmentTypeDescription": "0",
          "activeIndicator": "A",
          "assignedDate": "1532530402",
          "completionDate": "1532530402",
          "pendingLocationText": "Pending",
          "assignee": "5768",
          "serialNumber": "14368609",
          "sequenceNumber": "0",
          "reconsiderSequenceNo": "0",
          "palmMailedDate": "1532530402",
          "assignmentNo": "0",
          "title": "Import manager default title",
          "description": "Import manager default description",
          "assignor": "fhan",
          "dueDate": "1532530402",
          "assignmentStatusCode": "C",
          "caseType": "APPEAL",
          "creatorUserId": null,
          "createTs": "1532530402",
          "completerNumber": null,
          "proceedingCoreIdentifier": null,
          "proceedingSupIdentifier": null,
          "notes": "Test Appeal create Note",
          "preExistentIdentifier": null,
          "priorityIndicator": "Y",
          "audit": {
            "lastModifiedUserIdentifier": "465",
            "createUserIdentifier": "465",
            "lastModifiedTimestamp": "1532530402",
            "createdUserName": "fhan",
            "lastModifiedUserName": "fhan",
            "createTimestamp": "1532530402",
            "lockControlNumber": "0"
          }

        }];

        successResponse = {
          data: {
            "applicationDates": {
              "hearingStatus": null,
              "appealStatus": "DECISION",
              "noticeOfAppealDate": 760251600000,
              "appealBriefDate": 930542400000,
              "oralHearingRequestDate": 937281600000,
              "noticeOfHearingMailDate": 930542400000,
              "examinerAnswerDate": 782539200000,
              "replyBriefDate": 788677200000,
              "hearingDate": null,
              "docketingNoticeDate": null,
              "filingDate": 661755600000
            },
            "appealDates": {
              "hearingStatus": null,
              "appealStatus": "DECISION",
              "noticeOfAppealDate": 760251600000,
              "appealBriefDate": 930542400000,
              "oralHearingRequestDate": 937281600000,
              "noticeOfHearingMailDate": 930542400000,
              "examinerAnswerDate": 782539200000,
              "replyBriefDate": 788677200000,
              "hearingDate": null,
              "docketingNoticeDate": null,
              "filingDate": 661755600000
            },
            "trialDates": null
          }


        };

        expect(scope.processDismisalupload).toBeDefined();
        scope.processDismisalupload();

        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();

      });



      it('it should call processDismisalupload', function () {

        controller.userInfo = {
          userId: "pgandhi"
        }
        docketInfo = [{
          "assignmentIdentifier": 1589,
          "assignmentType": "DNMA",
          "assignmentTypeDescription": "0",
          "activeIndicator": "A",
          "assignedDate": "1532530402",
          "completionDate": "1532530402",
          "pendingLocationText": "Pending",
          "assignee": "5768",
          "serialNumber": "14368609",
          "sequenceNumber": "0",
          "reconsiderSequenceNo": "0",
          "palmMailedDate": "1532530402",
          "assignmentNo": "0",
          "title": "Import manager default title",
          "description": "Import manager default description",
          "assignor": "fhan",
          "dueDate": "1532530402",
          "assignmentStatusCode": "C",
          "caseType": "APPEAL",
          "creatorUserId": null,
          "createTs": "1532530402",
          "completerNumber": null,
          "proceedingCoreIdentifier": null,
          "proceedingSupIdentifier": null,
          "notes": "Test Appeal create Note",
          "preExistentIdentifier": null,
          "priorityIndicator": "Y",
          "audit": {
            "lastModifiedUserIdentifier": "465",
            "createUserIdentifier": "465",
            "lastModifiedTimestamp": "1532530402",
            "createdUserName": "fhan",
            "lastModifiedUserName": "fhan",
            "createTimestamp": "1532530402",
            "lockControlNumber": "0"
          }

        }];

        successResponse = {
          data: {
            "applicationDates": {
              "hearingStatus": null,
              "appealStatus": "DECISION",
              "noticeOfAppealDate": 760251600000,
              "appealBriefDate": 930542400000,
              "oralHearingRequestDate": 937281600000,
              "noticeOfHearingMailDate": 930542400000,
              "examinerAnswerDate": 782539200000,
              "replyBriefDate": 788677200000,
              "hearingDate": null,
              "docketingNoticeDate": null,
              "filingDate": 661755600000
            },
            "appealDates": {
              "hearingStatus": null,
              "appealStatus": "DECISION",
              "noticeOfAppealDate": 760251600000,
              "appealBriefDate": 930542400000,
              "oralHearingRequestDate": 937281600000,
              "noticeOfHearingMailDate": 930542400000,
              "examinerAnswerDate": 782539200000,
              "replyBriefDate": 788677200000,
              "hearingDate": null,
              "docketingNoticeDate": null,
              "filingDate": 661755600000
            },
            "trialDates": null
          }


        };

        expect(scope.processDismisalupload).toBeDefined();
        scope.processDismisalupload();

        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();

      });

      it('processDismisalupload failureResponse ', function () {

        var failureResponse = {
          data: {}
        };

        controller.userInfo = {
          userId: "pgandhi"
        }
        expect(scope.processDismisalupload).toBeDefined();
        scope.processDismisalupload();

        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });

      it('it should call getPreview ', function () {

        var contents = "https://ptab-q318-services-eap-0.sit.uspto.gov:8443/PTABAppeals/#/#%2F%3E"
        expect(scope['getPreview']).toBeDefined();
        scope.getPreview(contents);

      });

      it('should call $scope.mailDecisionUpload and return successResponse', function () {
        controller.userInfo = {
          userId: "pgandhi"
        };

        successResponse = {
          data: "Success!"
        };

        expect(scope.mailDecisionUpload).toBeDefined();
        scope.mailDecisionUpload();

        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();

      });



      it('should call $scope.mailDecisionUpload and return failureResponse', function () {

        // spyOn($CommonHelperService, 'setToastr').and.callFake(function () {
        //   return "toastr";
        // });

        controller.userInfo = {
          userId: "pgandhi"
        };

        failureResponse = {
          data: {
            "message": "Failed!"
          }
        };

        expect(scope.mailDecisionUpload).toBeDefined();
        scope.mailDecisionUpload();

        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();

      });

    });
  });
})();
