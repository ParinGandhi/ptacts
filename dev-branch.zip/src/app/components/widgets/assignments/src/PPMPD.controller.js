(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .directive('fileModel', ['$parse', function ($parse) {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var model = $parse(attrs.fileModel);
          var modelSetter = model.assign;

          element.bind('change', function () {
            scope.$apply(function () {
              modelSetter(scope, element[0].files[0]);
            });
          });
        }
      };
    }])

    .directive('customOnChange', function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var onChangeFunc = scope.$eval(attrs.customOnChange);
          element.bind('change', onChangeFunc);
        }
      };
    })
    .controller('PPMPDController', function ($timeout, $scope, ngDialog, HttpFactory, $log, CONSTANTS, AssignmentHelperService, $http, toastr, $sce, $rootScope, $filter, CommonHelperService) {

      $scope.infoContent='Click "Submit ready for mail" button to complete this assignment and create the "Petition decision ready for mail" assignment and assign to ';
      $scope.buttonText="Submit ready for mail";
      getDecisionType();
      AssignmentHelperService.getDocument($rootScope.sharedItems[0].serialNumber).then(function(document) {
        if (document) {
          $scope.verifiedDocument2 = document;
        } 
        // else {
        //   toastr.error("Failed to retrieve decision document", {
        //     iconClass: 'toast-danger'
        //   });
        // }
      });
      var clFile;
      var reader = new FileReader();
      var fileByteArray = [];
      $scope.fileExtractContent = [];
      $scope.getFileInfo = function () {
        $scope.pdfNameForDoc =null;
        clFile = document.getElementById("fileVerifyDecision");
        $scope.fileInfo = {};
        $scope.fileInfo.name = clFile.files[0].name;
        $scope.fileExtractContent.push(clFile.files[0]);
        $scope.verifiedDocument = {};
        $scope.verifiedDocument.fileName  = $scope.fileInfo.name;
        $scope.docLink =  $scope.verifiedDocument.fileName;
        $scope.fileInfo.path = clFile.value;
        reader.readAsArrayBuffer(clFile.files[0]);
        reader.onloadend = function (evt) {
          if (evt.target.readyState === FileReader.DONE) {
            var arrayBuffer = evt.target.result,
              array = new Uint8Array(arrayBuffer);
            for (var i = 0; i < array.length; i++) {
              fileByteArray.push(array[i]);
            }
          }
          
        };
        $scope.fileContent = [];
        $scope.fileContent.push(clFile.files[0]);
        $scope.showPreviewPdf();

      };

      $scope.showPreviewPdf = function () {
        $scope.loading = true;
        var pdfDataFile = new FormData();
        angular.forEach($scope.fileContent, function (value) {
          pdfDataFile.append('uploadMultipartFileContents', value);
        });
        HttpFactory.postPdf(CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.USERGEN + 'appealNumber=' + $rootScope.sharedItems[0].appealNumber +
            '&ptabAssignmentId=' + $rootScope.sharedItems[0].assignmentIdentifier, pdfDataFile)
          .then(function (successResponse) {
     //       $scope.dockType= "USER";
     //       $scope.documentType(true);
            $scope.PostDataResponse = successResponse.data.fileContent;
            $scope.genPdfFileName = successResponse.data.fileName;
            $scope.contentsPreview = 'data:application/pdf;base64,' + $scope.PostDataResponse;
            $scope.getPreview($scope.contentsPreview);
            $scope.loading = false;
            $scope.hideAdd = false;
          }, function () {
            // intentional
          });
      };     
  
      $scope.getPreview = function (contents) {
        $http.get(contents, {
            responseType: 'arraybuffer',
            headers: {
              'Accept': 'application/pdf'
            }
          })
          .success(function (data) {
            var file = new Blob([data], {
              type: 'application/pdf'
            });
            var fileURL = URL.createObjectURL(file);
            var fileOne = window.URL.createObjectURL(file);
            $scope.pdfContent = $sce.trustAsResourceUrl(fileOne);
            if (null !== $scope.pdfContent && document.getElementById('sendNoticeOfHearingPreview') !== null) {
              angular.element(document.getElementById('sendNoticeOfHearingPreview')).scope().pdfContent = $sce.trustAsResourceUrl(fileURL);
            } else {
              $scope.pdfContent = $sce.trustAsResourceUrl(fileURL);
            }
            if (fileURL !== '' || angular.isDefined(fileURL)) {
              $scope.show = false;
              $scope.editable = false;
              $scope.pdfStyle = {
                "border": "1px solid grey"
              };
            }
          }).error(function () {
            // intentional
          });
      };

      $scope.clearDocument = function() {
        $scope.verifiedDocument = null;
        $scope.extracted=false;
        $scope.fileExtractContent = [];
        $scope.revalidate =false;
        $scope.editedInformation = false;
      };
  

      $scope.submitReviewDraft = function() {
        $scope.palmUpload();
      }


      getAppealPetitions();
      function getAppealPetitions(){
        HttpFactory.getActions('/petition/get-appeal-petition-info?serialNumber='+$rootScope.sharedItems[0].serialNumber+'&appealNumber='+$rootScope.sharedItems[0].appealNumber+'&assignmentIdentifier='+$rootScope.sharedItems[0].assignmentIdentifier)
        .then(function (successResponse) {
          $scope.petitionTypeCd = successResponse.data.petitionTypeCd;
          $scope.description = successResponse.data.description;
          $scope.petitionFilingDate = successResponse.data.petitionFilingDate;
          $scope.petitionId = successResponse.data.petitionId;
        }, function (failureResponse) {
        });        
    }
    
     function saveAssignment(data) {
        HttpFactory.putActions(CONSTANTS.URL.UPDATE_ASSIGNMENT, data)
        .then(function (successResponse) {

          $scope.updateAssignment.assignmentLockControlNo = successResponse.data.audit.lockControlNumber;
          $scope.isUpdateSaved = true;
          $scope.disablesave = true;

          toastr.clear();

          toastr.error(successResponse.data.message, {
            iconClass: 'toast-success'
          });

          if ($scope.isMergedCase) {
            toastr.success(successResponse.data.title + " assignments for " + $scope.mergedApplListForToastr + " have been closed.", {
              iconClass: 'toast-success'
            });
          }

          // "<Assignment title> assignments for <list of merged applications> have been closed

          $scope.updateAssignment.noteText = "";
          if (angular.isUndefined($scope.updateAssignment.assignmentCompletionDt) || $scope.updateAssignment.assignmentCompletionDt === null) {
            $scope.updateAssignment.toDisable = false;
            $scope.isCompletiondate = false;

          } else {
            $scope.updateAssignment.toDisable = true;
            $scope.isCompletiondate = true;
            $scope.checkCompletiondate = function () {
              return $scope.isCompletiondate;
            };
          }

          $scope.finished=true;
          $scope.disableSaveButton=false;

          createNextAssignment();
        }, function (failureResponse) {
          $scope.saveInProgress=false;
          $scope.disableeWFButton=false;
          toastr.clear();
          toastr.warning(failureResponse.data.message, {
            iconClass: 'toast-warning'
          });
        });
      }

      $scope.getRule = function (value, description) {
        $scope.selectedDecisionDisplay=description;
        $scope.selectedDecisionValue = value;
      };

      function getDecisionType() {
        HttpFactory.getActions("/reference-data/decision-types-petition")
          .then(function (successResponse) {
            $scope.decisionList = successResponse.data;
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      }


        /* istanbul ignore next */
        $scope.palmUpload = function () {
             $scope.dockType="USER";
             $rootScope.sharedItems[0].docFlag=true;
             $rootScope.sharedItems[0].completionCode = $scope.selectedDecisionValue;
             $rootScope.sharedItems[0].petitionId = $scope.petitionId;
             $rootScope.sharedItems[0].petitionTypeCode = $scope.petitionTypeCd;
 
          ngDialog.open({
            template: 'app/components/widgets/assignments/src/confirmPdfUpload.html',
            controller: 'pdfUploadController',
            width: '35%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            ariaLabelledById: 'pdfUploadTitle',
            ariaDescribedById: 'pdfUploadTitle',
            resolve: {
              pdfContent: function () {
                return $scope.contentsPreview;
              },
              docketInfo: function () {
                return $rootScope.sharedItems;
              },
              mailer: function () {
                return $scope.currentAssignee.assigneeFullNameText;
              },
              genPdfFile: function () {
                return $scope.genPdfFileName;
              },
              panelData: function () {
                return $scope.panell;
              },
              decisionType: function () {
                return $scope.selectedDecisionValue;
              },
              decisionDueDate: function () {
                return $scope.responseDueDate;
              },
              decisionDate: function () {
                return $scope.transactionDate;
              },
              judgeList: function () {
                return $scope.judgesToPanel;
              },
              hearingRoomRosterData: function () {
                return $scope.hearingRoomRosterData;
              },
              reconsiderSequenceNumber: function () {
                return "0";
              },
              adSequenceNumber: function () {
                return "1";
              },
              dockType: function(){
                return "USER";
              },
            appealDecisionData: function(){
              return null;
            }
            }
          }).closePromise.then(function (pdfData) {
            if(pdfData.value != undefined){
            $scope.mailStep=true;
            $scope.currentAssignment = pdfData.value.currentAssignment;
            $scope.getPreview('data:application/pdf;base64,'+pdfData.value.fileContent);
            }

            var completionCode = $scope.selectedDecisionValue;
             
          });
        };

              $scope.email = function () {

        /* istanbul ignore next */
        HttpFactory.postActions(CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.UPLOAD_EMAIL + 'fileToEmail=' + $scope.genPdfFileName +
            '&appealNumber=' + $scope.items[0].appealNumber +
            '&serialNumber=' + $scope.items[0].serialNumber +
            '&assignmentType=' + $scope.items[0].assignmentType
          )
          .then(function (successResponse) {
            $scope.emailResponse = successResponse.data;
            toastr.success(CONSTANTS.TOASTER.email, {
              iconClass: 'toast-success'
            });
            if ($rootScope.isMergedCase) {
              toastr.success($scope.items[0].title + " assignments for " + $scope.mergedApplListForToastr + " have been closed.", {
                iconClass: 'toast-success'
              });
            }

          }, function () {
            // intentional
          });
      };

  });
})();
