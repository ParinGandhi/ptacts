(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .directive('fileModel', ['$parse', function ($parse) {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var model = $parse(attrs.fileModel);
          var modelSetter = model.assign;

          element.bind('change', function () {
            scope.$apply(function () {
              modelSetter(scope, element[0].files[0]);
            });
          });
        }
      };
    }])

    .directive('customOnChange', function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var onChangeFunc = scope.$eval(attrs.customOnChange);
          element.bind('change', onChangeFunc);
        }
      };
    })
    .controller('RRCController', function ($timeout, $scope, ngDialog, HttpFactory, $log, CONSTANTS, AssignmentHelperService, $http, toastr, $sce, $rootScope, $filter, CommonHelperService) {
      var vm = this;
      $scope.selectFile=true;
      //getDefaultUser();
      $scope.buttonText = "Add document and create review draft";
      $scope.infoContent='Click "' + $scope.buttonText + '" button to add selected document, close this assignment, create the next paralegal review assignment and assign to ';
      vm.fileAdded1 = false;
      $scope.spinnerShow =false;
      $scope.fileExtractContent = [];
      var scope = angular.element(document.getElementById('mainTabId')).scope();
      vm.userInfo = scope.vm.userInfo;
      if (vm.userInfo.appUserInfo[0]) {
        vm.fullName = vm.userInfo.appUserInfo[0].fullName;
      } else {
        vm.fullName = vm.userInfo.appUserInfo.fullName;
      }
      $scope.listOfFileNames = [];
      $scope.fileContent = [];
      $scope.multiPdf = [];
      $scope.anotherFile = false;
      $scope.anotherFile1 = false;
      $scope.docketFileContent = [];
      $scope.show = true;
      $scope.editable = true;
      $scope.showPreview = true;
      $scope.fileUploadDisable = true;
      $scope.hideAdd = true;
      $scope.shareAssign = $rootScope.sharedItems;
      $scope.serialNumber = $rootScope.sharedItems[0].serialNumber;
      $scope.appealNumber = $rootScope.sharedItems[0].appealNumber;
      $scope.assignmentIdentifier = $rootScope.sharedItems[0].assignmentIdentifier;
      $scope.assignmentTypeForRtf = $rootScope.sharedItems[0].assignmentType;
      $scope.rtfBaseLink = CONSTANTS.URL.BASE;
      $scope.transactionDate = new Date().getTime();
      $scope.enterDays = '';
      vm.hearingStatusIndicator = '';
      $scope.showHearingStatus = false;
      $scope.showUploadButton = false;
      $scope.readyToCreateRemand = false;
      $scope.showFastTrack = false;
      $scope.decisionDocument = "Use system converted PDF";
      $scope.showVerifyDecision = true;
      $scope.anotherFile = false;
      $scope.anotherFile1 = false;
      $scope.revalidate =false;
      $scope.footerEditValue =false;
      $scope.hidePalm =true;
      $scope.dockType=null;
      $scope.enableFlag=true;
    

    $scope.clearDocument = function() {
      $scope.verifiedDocument = null;
      $scope.extracted=false;
      $scope.fileExtractContent = [];
      $scope.revalidate =false;
      $scope.editedInformation = false;
    };

    $scope.submitReviewDraft = function() {
    $scope.saveInProgress=true;
    var updateAssignmntdata = {
      "assignmentType": $scope.updateAssignment.assignmentType,
      "assignee": $scope.updateAssignment.assignee,
      "serialNumber": $scope.updateAssignment.serialNumber,
      "title": $scope.updateAssignment.title,
      "description": $scope.updateAssignment.description,
      "dueDate": $scope.updateAssignment.dueDate,
      "completionDate":  new Date().getTime(),
      "completionCode": "COMPLETE",
      "caseType": $scope.updateAssignment.caseType,
      "appealNumber": $scope.updateAssignment.appealNumber,
      "sequenceNumber": $scope.updateAssignment.sequenceNumber,
      "notes": $scope.updateAssignment.noteText,
      "priorityIndicator": ($scope.updateAssignment.priorityIndicator) ? 'Y' : 'N',
      "assignmentIdentifier": $scope.updateAssignment.assignmentIdentifier,
      "assignor": $scope.updateAssignment.assignor,
      "activeIndicator": $scope.updateAssignment.activeIndicator,
      "pageNumberQuantity":$scope.updateAssignment.pageNumberQuantity,
      "audit": {
        "createUserIdentifier": $scope.updateAssignment.createUserIdentifier,
        "lastModifiedUserIdentifier": $scope.updateAssignment.assignmentLastModifiedUids,
        "lockControlNumber": $scope.updateAssignment.assignmentLockControlNo,
        "createTimestamp": $scope.updateAssignment.assignmentCreateTs,
        "lastModifiedTimestamp": new Date().getTime()
      }
    };
    saveAssignment(updateAssignmntdata);
  };

  function saveAssignment(data) {
      HttpFactory.putActions(CONSTANTS.URL.UPDATE_ASSIGNMENT, data)
        .then(function (successResponse) {
          
          $scope.updateAssignment.assignmentLockControlNo = successResponse.data.audit.lockControlNumber;
          $scope.isUpdateSaved = true;
          $scope.disablesave = true;
          $scope.newAssignmentId = successResponse.data.assignmentIdentifier;
          toastr.clear();

          toastr.error(successResponse.data.message, {
            iconClass: 'toast-success'
          });

          ngDialog.closeAll(true);

        }, function (failureResponse) {
          $scope.saveInProgress=false;
          $scope.disableeWFButton=false;
          toastr.clear();
          toastr.warning(failureResponse.data.message, {
            iconClass: 'toast-warning'
          });
      

        });
  }

  });
})();
