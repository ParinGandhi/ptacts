(function () {
  'use strict';

  describe('whoCompletedController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['open']);
    var controller, scope, $rootScope;

    beforeEach(inject(function (_$controller_, _$rootScope_) {
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;

      controller = $controller('whoCompletedController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_
      });
    }));

    describe('whoCompletedController', function () {


      it('nothing implemented ', function () {


      });


    });
  });
})();
