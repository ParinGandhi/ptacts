(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .controller('reviewPetitionInfoController', function ($timeout, $scope, ngDialog, HttpFactory, $log, CONSTANTS, AssignmentHelperService, $http, toastr, $sce, $rootScope, $filter, CommonHelperService) {
      var vm = this;
      $scope.buttonText ="Complete paralegal review";
      $scope.infoContent='Click "' + $scope.buttonText + '" button to complete the paralegal review and create the next review assignment and assign to ';
      console.log($rootScope);
      var caseNum = $rootScope.sharedItems[0].serialNumber;
      AssignmentHelperService.getDocument($rootScope.sharedItems[0].serialNumber).then(function(document) {
        if (document) {
          $scope.verifiedDocument = document;
        } 
        // else {
        //   toastr.error("Failed to retrieve decision document", {
        //   iconClass: 'toast-danger'
        //   });
        // }
      });
      getDefaultUser();
      getAppealPetitions();
 
  function getDefaultUser() {
    AssignmentHelperService.getDefaultUser(CONSTANTS.URL.DEFAULT_PETITION_USER).then(function(returnValue) {
      $scope.getNextAssignmentInfo(returnValue.descriptionText, returnValue.valueText).then(function(currentAssignee) {
        $scope.setSelectedJudge(currentAssignee);
      });
    });   
  }

  function getAppealPetitions(){
    HttpFactory.getActions('/petition/get-appeal-petition-info?serialNumber='+$rootScope.sharedItems[0].serialNumber+'&appealNumber='+$rootScope.sharedItems[0].appealNumber+'&assignmentIdentifier='+$rootScope.sharedItems[0].assignmentIdentifier)
    .then(function (successResponse) {
      $scope.petitionTypeCd = successResponse.data.petitionTypeCd;
      $scope.description = successResponse.data.description;
      $scope.petitionFilingDate = successResponse.data.petitionFilingDate;
      $scope.petitionId = successResponse.data.petitionId;
    }, function (failureResponse) {
      toastr.clear();
      toastr.error(failureResponse.data.message, {
        iconClass: 'toast-danger'
      });
    });        
}

getLkryza();

function getLkryza() {
  AssignmentHelperService.getDefaultUser(CONSTANTS.URL.DEFAULT_PETITION_FOR_LKRYZA).then(function(returnValue) {
    vm.defaultUserLkryza=returnValue;
  if($scope.petitionTypeCd == vm.defaultUserLkryza.descriptionText){  
    getAssignmentAssignee();
  }
  });   
}

function getAssignmentAssignee(){
  HttpFactory.getActions('/petition/get-assignment-assignee?assignmentIdentifier='+$rootScope.sharedItems[0].assignmentIdentifier+'&petitionTypeCode='+$scope.petitionTypeCd)
  .then(function (successResponse) {
    var obj = {
      "assigneeNumberText":successResponse.data.userIdentiifier,
      "assigneeFullNameText":successResponse.data.fullName
    }
    //$scope.selectedAssignmentType = obj;
    $scope.setSelectedJudge(obj);
  }, function (failureResponse) {
    toastr.clear();
    toastr.error(failureResponse.data.message, {
    iconClass: 'toast-danger'
    });
  });        
}

  $scope.submitReviewDraft = function() {
    $scope.saveInProgress=true;
    var updateAssignmentObject = AssignmentHelperService.getUpdateAssignmentObject($scope.updateAssignment);
    updateAssignmentObject.assignee = $scope.selectedAssignmentType.assigneeNumberText;
    updateAssignmentObject.inPetition = true;
    updateAssignmentObject.petitionTypeCode = $scope.petitionTypeCd;
    updateAssignmentObject.preExistentAssignmentId = $rootScope.sharedItems[0].assignmentIdentifier;
    updateAssignmentObject.petitionId = $scope.petitionId;
    //console.log("test");
    saveAssignment(updateAssignmentObject);
  };
    
  function saveAssignment(data) {
    console.log(data);
    console.log(CONSTANTS.URL.UPDATE_ASSIGNMENT);
    HttpFactory.putActions(CONSTANTS.URL.UPDATE_ASSIGNMENT, data)
      .then(function (successResponse) {

        $scope.updateAssignment.assignmentLockControlNo = successResponse.data.audit.lockControlNumber;
        $scope.isUpdateSaved = true;
        $scope.disablesave = true;
        $scope.newAssignmentId = successResponse.data.assignmentIdentifier;
        toastr.clear();

        toastr.error(successResponse.data.message, {
          iconClass: 'toast-success'
        });

        if ($scope.isMergedCase) {
          toastr.success(successResponse.data.title + " assignments for " + $scope.mergedApplListForToastr + " have been closed.", {
            iconClass: 'toast-success'
          });
        }

        // "<Assignment title> assignments for <list of merged applications> have been closed

        $scope.updateAssignment.noteText = "";
        if (angular.isUndefined($scope.updateAssignment.assignmentCompletionDt) || $scope.updateAssignment.assignmentCompletionDt === null) {
          $scope.updateAssignment.toDisable = false;
          $scope.isCompletiondate = false;

        } else {
          $scope.updateAssignment.toDisable = true;
          $scope.isCompletiondate = true;
          $scope.checkCompletiondate = function () {
            return $scope.isCompletiondate;
          };
        }

        $scope.finished=true;
        $scope.disableSaveButton=false;

        //createAssignment();
        toastr.clear();
        toastr.success("PL Review petition draft completed and Review petition decision for mailing assignment created.", {
          iconClass: 'toast-success'
        });
        $scope.saveInProgress=false;
        callUpdateAppeal();
        callUpdateAppealPetition()
        ngDialog.closeAll(true);
      }, function (failureResponse) {
        $scope.saveInProgress=false;
        $scope.disableeWFButton=false;
        toastr.clear();
        toastr.warning(failureResponse.data.message, {
          iconClass: 'toast-warning'
        });
    

      });
  
  }

  function createAssignment() {
    var nextAssignment ={
      code:"RPDM",
      title:"Review petition decision for mailing",
      assignee:  $scope.selectedAssignmentType.assigneeNumberText
    };

    var newAssignment = AssignmentHelperService.getCreateAssignmentObject($scope.updateAssignment, nextAssignment);
  
    newAssignment.inPetition = true;
    newAssignment.petitionTypeCode = $scope.petitionTypeCd;
    newAssignment.preExistentAssignmentId = $rootScope.sharedItems[0].assignmentIdentifier;

    AssignmentHelperService.createAssignment(newAssignment).then(function(serviceResponse) {
      if (serviceResponse) {
        $scope.newAssignmentId = serviceResponse.data.assignmentIdentifier;
        //updatePopulation(newAssignment);
        toastr.clear();
        toastr.success("PL Review petition draft completed and Review petition decision for mailing assignment created.", {
          iconClass: 'toast-success'
        });
        $scope.saveInProgress=false;
        callUpdateAppeal();
        callUpdateAppealPetition()
        ngDialog.closeAll(true);
      } else {
        $scope.saveInProgress=false;
        toastr.clear();
        toastr.warning(serviceResponse.data.message, {
          iconClass: 'toast-warning'
        });
      }
    });
  }

  function updatePopulation(createAssignment)  {
    AssignmentHelperService.calUpdatePopulation(createAssignment).then(function(response) {

      $scope.saveInProgress=false;
      if (!response) {
        toastr.clear();
        toastr.success("PL Review petition draft completed and Review petition draft after PL review assignment created.", {
          iconClass: 'toast-success'
        });
        $scope.saveInProgress=false;
       
        ngDialog.closeAll(true);
      } else {
         $scope.saveInProgress=false;
        toastr.clear();
        toastr.error(response.data.message, {
          iconClass: 'toast-danger'
        });
      }
    });
  }

  $scope.assignmentListEnterKey = function(event) {
    if (event.keyCode===13) {
      if ( $scope.allUsers.length>0) {
        $scope.setSelectedJudge($scope.allUsers[0]);
        $scope.dontMakeVisible=true;
      }
    }
  }

  $scope.showJudgeList = function () {
    if ($scope.assigneePlaceholders==='Loading assignees...') {
      return;
    }

    if ($scope.dontMakeVisible) {
        $scope.dontMakeVisible=false;
    return;
    }
    if (!$scope.judgeListVisible) {
      $scope.judgeListVisible = !$scope.judgeListVisible;
    }
  };

  $scope.setSelectedJudge = function (judge) {
    if (judge.assigneeFullNameText !== "Select assignee") {
     $scope.selectedAssignmentType = judge;
    } else {
      $scope.selectedAssignmentType={};
    }
    $scope.judgeListVisible=false;
  };

  $scope.selectJudgeEntered = function(event, judge) {
    if (event.keyCode === 13) {
      $scope.setSelectedJudge(judge);
    }
  };

  $scope.searchForJudge = function (input) {
    $scope.judgeListVisible=true;
    var tempList = [];
    if (angular.isDefined(input) && input.assigneeFullNameText.trim() !== "") {
      angular.forEach($scope.backupAllUsers, function (currentJudge) {
        if (currentJudge.assigneeFullNameText.toLowerCase().includes(input.assigneeFullNameText.toLowerCase())) {
          tempList.push(currentJudge);
        }
      });
      $scope.allUsers = angular.copy(tempList);
    } else {
      $scope.allUsers = angular.copy($scope.backupAllUsers);
    }
  };

  function callUpdateAppeal() {
    var updateObject = {
      "serialNumber": $rootScope.sharedItems[0].serialNumber,
      "appealNumber": $rootScope.sharedItems[0].appealNumber,
       "audit": {
          "createUserIdentifier": $rootScope.userInfo.userId,
          "lastModifiedUserIdentifier": $rootScope.userInfo.userId,
          "lastModifiedTimestamp": (new Date()).getTime(),
          "createTimestamp": (new Date()).getTime(),
          "lockControlNumber": 0
        },
        "assignmentType": "ANY" 
    }

    HttpFactory.putActions("/appeals/update_petition_appeal", updateObject)
    .then(function (successResponse) {
      console.log(successResponse);
    }, function (failureResponse) {
      toastr.clear();
      toastr.error(failureResponse.data.message, {
        iconClass: 'toast-danger'
      });
    });
  }

  function callUpdateAppealPetition() {
    HttpFactory.putActions('/petition/update-appeal-petition?serialNumber='+$rootScope.sharedItems[0].serialNumber+'&appealNumber='+$rootScope.sharedItems[0].appealNumber+'&petitionId='+$scope.petitionId+'&assignmentIdentifier='+$scope.newAssignmentId)
    .then(function (successResponse) {
      console.log(successResponse);
    }, function (failureResponse) {
      toastr.clear();
      toastr.error(failureResponse.data.message, {
        iconClass: 'toast-danger'
      });
    });
  }

 });
})();
