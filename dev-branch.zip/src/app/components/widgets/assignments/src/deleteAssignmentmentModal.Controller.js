(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('deleteAssignmentmentModalController', function ($scope, $log, ngDialog, HttpFactory, wrkNumbr, ptabId, activeIndicator, toastr) {
      $scope.ptabId = ptabId;
      $scope.delfailed = false;
      if (activeIndicator === "A") {
        $scope.delfailed = false;
      } else {
        $scope.delfailed = true;
      }
      $scope.closedltdlg = function () {
        ngDialog.closeAll(true);

      };
      $scope.wrkNumbr = wrkNumbr;
      /* istanbul ignore next  */
      $scope.confirmanouncementDelete = function () {
        HttpFactory.deleteActions('/assignments/' + $scope.ptabId + '/' + $scope.wrkNumbr)
          .then(function (successResponse) {

            if (angular.isDefined(successResponse.data.message)) {

              $scope.closedltdlg();
              toastr.clear();
              toastr.success(CONSTANTS.TOASTER.delete, {
                iconClass: 'toast-success'
              });
            } else {
              toastr.clear();
              toastr.success(CONSTANTS.TOASTER.delete, {
                iconClass: 'toast-success'
              });
              $scope.closedltdlg();
            }
          }, function (failureResponse) {
            $log.info(failureResponse);
            if (angular.isDefined(failureResponse.data.message)) {
              toastr.clear();
              toastr.error("Delete failed " + failureResponse.data.message, {
                iconClass: 'toast-danger'
              });
            } else {
              toastr.clear();
              toastr.error("delete failed", {
                iconClass: 'toast-danger'
              });
            }

          });
      };

    });
})();
