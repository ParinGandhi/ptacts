(function () {
  "use strict";
  angular
    .module('ptabe2e')
    .controller('dateVerificationController', function (ngDialog, $timeout, prevDate) {
      var vm = this;
      vm.revertAllChanges = function () {
        closeDialogDt(1);
      };

      function closeChangesDialog(popupsToClose) {
        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose]);
        } else {
          ngDialog.close();
        }
      }

      function closeDialogDt(popupsToClose) {
        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose], prevDate);
        } else {
          ngDialog.close();
        }
      }

      vm.closeDialog = function () {
        closeChangesDialog(1);
      };
    });
})();
