(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .controller('PanelUnsavedChangesController', function (ngDialog, $log, lessThanThreeApjs, completionCode, panelToCreate, CommonHelperService, HttpFactory, CONSTANTS, $window) {
      var vm = this;
      vm.lessThanThreeApjs = lessThanThreeApjs;
      var response = {
        showSaveDialog: false,
        closeAll: true,
        saveAndClose: true
      };

      /**
       * This function will only close the unsaved changed dialog
       */
      vm.cancel = function () {
        ngDialog.close(lastDialog());
      };

      /**
       * This function will discard changes and close all dialogs
       */
      vm.abandonChanges = function () {
        var panelExistsCheck = $window.sessionStorage.getItem("panelExists");
        if (angular.isDefined(panelExistsCheck) && panelExistsCheck === "false") {
          var updateAssignmentElement = angular.element(document.getElementById("updateAssign")).scope();
          console.log(updateAssignmentElement.$parent.originaldata[0]);
          HttpFactory.deletePanel(CONSTANTS.URL.UPDATE_OR_CLEAR_PANEL, updateAssignmentElement.$parent.originaldata[0])
            .then(function (successResponse) {
              console.log(successResponse);
            }, function (failureResponse) {
              console.log(failureResponse);
            });
        }
        $window.sessionStorage.removeItem("panelExists");
        ngDialog.closeAll();
      };

      /**
       * This function will save the changes and close all dialogs
       */
      vm.saveAndClose = function () {
        response.customMessage = true;
        ngDialog.close(lastDialog(), response);
      };

      vm.submitPanelAndClose = function () {
        if (!panelToCreate.judgePanel.panelDate) {
          var dateFlags = {
            "showInitialMessage": true,
            "showNoDateMessage": false,
            "showConfirmSubmitMessage": false
          };
          ngDialog.close(lastDialog());
          ngDialog.open({
            template: "app/components/widgets/assignments/src/panelingMessageModal.html",
            controller: 'PanelingMessageModalController',
            controllerAs: 'vm',
            width: '25%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              createPanelData: function () {
                return panelToCreate;
              },
              flags: function () {
                return dateFlags;
              },
              circulationInProcess: function () {
                return null;
              }
            }
          }).closePromise.then(function (response) {
            if (response.value) {
              $log.info(response.value);
            }
          });
        } else {
          vm.submitPanel();
        }
      };

      vm.submitPanel = function () {
        panelToCreate.panelAssignment.completionCode = completionCode;
        panelToCreate.panelAssignment.completionDate = new Date().getTime();

        HttpFactory.postActions(CONSTANTS.URL.CREATE_JUDGE_PANEL, panelToCreate)
          .then(function (successResponse) {

            CommonHelperService.setToastr(CONSTANTS.TOASTER.updatePanel, "success");
            ngDialog.closeAll(false);
          }, function (failureResponse) {
            // intentional
          });
      };

      function lastDialog() {
        var openDialogs = ngDialog.getOpenDialogs();
        return openDialogs[openDialogs.length - 1];
      }

    });
})();
