(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .directive('fileModel', ['$parse', function ($parse) {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var model = $parse(attrs.fileModel);
          var modelSetter = model.assign;

          element.bind('change', function () {
            scope.$apply(function () {
              modelSetter(scope, element[0].files[0]);
            });
          });
        }
      };
    }])

    .directive('customOnChange', function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var onChangeFunc = scope.$eval(attrs.customOnChange);
          element.bind('change', onChangeFunc);
        }
      };
    })
    .controller('petitionInfoController', function ($timeout, $scope, ngDialog, HttpFactory, $log, CONSTANTS, AssignmentHelperService, $http, toastr, $sce, $rootScope, $filter, CommonHelperService) {
      var vm = this;
      $scope.selectFile=true;
      //getDefaultUser();
      $scope.buttonText = "Create review draft";
      $scope.infoContent='Click "' + $scope.buttonText + '" button to close this assignment, create the next paralegal review assignment and assign to ';
      vm.fileAdded1 = false;
      $scope.spinnerShow =false;
      $scope.fileExtractContent = [];
      var scope = angular.element(document.getElementById('mainTabId')).scope();
      vm.userInfo = scope.vm.userInfo;
      if (vm.userInfo.appUserInfo[0]) {
        vm.fullName = vm.userInfo.appUserInfo[0].fullName;
      } else {
        vm.fullName = vm.userInfo.appUserInfo.fullName;
      }
      $scope.listOfFileNames = [];
      $scope.fileContent = [];
      $scope.multiPdf = [];
      $scope.anotherFile = false;
      $scope.anotherFile1 = false;
      $scope.docketFileContent = [];
      $scope.show = true;
      $scope.editable = true;
      $scope.showPreview = true;
      $scope.fileUploadDisable = true;
      $scope.hideAdd = true;
      $scope.shareAssign = $rootScope.sharedItems;
      $scope.serialNumber = $rootScope.sharedItems[0].serialNumber;
      $scope.appealNumber = $rootScope.sharedItems[0].appealNumber;
      $scope.assignmentIdentifier = $rootScope.sharedItems[0].assignmentIdentifier;
      $scope.assignmentTypeForRtf = $rootScope.sharedItems[0].assignmentType;
      $scope.rtfBaseLink = CONSTANTS.URL.BASE;
      $scope.transactionDate = new Date().getTime();
      $scope.enterDays = '';
      vm.hearingStatusIndicator = '';
      $scope.showHearingStatus = false;
      $scope.showUploadButton = false;
      $scope.readyToCreateRemand = false;
      $scope.showFastTrack = false;
      $scope.decisionDocument = "Use system converted PDF";
      $scope.showVerifyDecision = true;
      $scope.anotherFile = false;
      $scope.anotherFile1 = false;
      $scope.revalidate =false;
      $scope.footerEditValue =false;
      $scope.hidePalm =true;
      $scope.dockType=null;
      $scope.enableFlag=true;
      $scope.petitionTypeCd='';
      vm.defaultUserLkryza='';
      getAppealPetitions();
      // $scope.editedInformation = true;
      var clFile;
      var reader = new FileReader();
      var fileByteArray = [];
      /* istanbul ignore next */
    $scope.getFileInfo = function () {
      $scope.pdfNameForDoc =null;
      clFile = document.getElementById("fileVerifyDecision");
      $scope.fileInfo = {};
      $scope.fileInfo.name = clFile.files[0].name;
      $scope.fileExtractContent.push(clFile.files[0]);
      $scope.verifiedDocument = {};
      $scope.verifiedDocument.fileName  = $scope.fileInfo.name;
      $scope.docLink =  $scope.verifiedDocument.fileName;
      $scope.fileInfo.path = clFile.value;
      reader.readAsArrayBuffer(clFile.files[0]);
      reader.onloadend = function (evt) {
        if (evt.target.readyState === FileReader.DONE) {
          var arrayBuffer = evt.target.result,
            array = new Uint8Array(arrayBuffer);
          for (var i = 0; i < array.length; i++) {
            fileByteArray.push(array[i]);
          }
        }
      };
    };

    $scope.clearDocument = function() {
      $scope.verifiedDocument = null;
      $scope.extracted=false;
      $scope.fileExtractContent = [];
      $scope.revalidate =false;
      $scope.editedInformation = false;
    };

    $scope.submitReviewDraft = function() {
    $scope.saveInProgress=true;
    var updateAssignmentObject = AssignmentHelperService.getUpdateAssignmentObject($scope.updateAssignment)
    updateAssignmentObject.assignee = $scope.selectedAssignmentType.assigneeNumberText;
    updateAssignmentObject.inPetition = true;
    updateAssignmentObject.petitionTypeCode = $scope.petitionTypeCd;
    updateAssignmentObject.preExistentAssignmentId = $scope.assignmentIdentifier;
    updateAssignmentObject.petitionId = $scope.petitionId;
    $scope.updateAssgnmnt(updateAssignmentObject);
  };

  $scope.updateAssgnmnt = function (data) {
    //convertDocToPdf(data);
    saveAssignment(data);
  };

  function createAssignment() {
    var nextAssignment ={
      code:"PPLRPD",
      title:"Paralegal review petition decision draft",
      assignee: $scope.selectedAssignmentType.assigneeNumberText
    };

    var newAssignment = AssignmentHelperService.getCreateAssignmentObject($scope.updateAssignment, nextAssignment);
  
    newAssignment.inPetition = true;
    newAssignment.petitionTypeCode = $scope.petitionTypeCd;
    newAssignment.preExistentAssignmentId = $scope.assignmentIdentifier;

    AssignmentHelperService.createAssignment(newAssignment).then(function(serviceResponse) {
      console.log(serviceResponse);
        $scope.newAssignmentId = serviceResponse.data.assignmentIdentifier;
        //updatePopulation(newAssignment);
        toastr.clear();
        toastr.success("Create petition decision draft completed and Paralegal review petition decision draft assignment created and sent to PTAB AIA trials work queue.", {
          iconClass: 'toast-success'
        });
        $scope.saveInProgress=false;
        callUpdateAppeal();
        callUpdateAppealPetition()
        ngDialog.closeAll(true);
      }, function (failureResponse)  {
        $scope.saveInProgress=false;
        toastr.clear();
        toastr.error(failureResponse.data.message, {
          iconClass: 'toast-danger'
        });
    });

    function updatePopulation(createAssignment)  {
      AssignmentHelperService.calUpdatePopulation(createAssignment).then(function(response) {
        if (!response) {
          toastr.clear();
          toastr.success("Create petition draft completed and Review petition draft assignment created and sent to PTAB AIA trials work queue.", {
            iconClass: 'toast-success'
          });
          $scope.saveInProgress=false;
          callUpdateAppeal();
          ngDialog.closeAll(true);
        } else {
          $scope.saveInProgress=false;
          toastr.clear();
          toastr.error(response.data.message, {
            iconClass: 'toast-danger'
          });
        }
      });
    }
  }
  
  function saveAssignment(data) {
      HttpFactory.putActions(CONSTANTS.URL.UPDATE_ASSIGNMENT, data)
        .then(function (successResponse) {
          
          $scope.updateAssignment.assignmentLockControlNo = successResponse.data.audit.lockControlNumber;
          $scope.isUpdateSaved = true;
          $scope.disablesave = true;
          $scope.newAssignmentId = successResponse.data.assignmentIdentifier;
          toastr.clear();

          toastr.error(successResponse.data.message, {
            iconClass: 'toast-success'
          });

          if ($scope.isMergedCase) {
            toastr.success(successResponse.data.title + " assignments for " + $scope.mergedApplListForToastr + " have been closed.", {
              iconClass: 'toast-success'
            });
          }

          // "<Assignment title> assignments for <list of merged applications> have been closed

          $scope.updateAssignment.noteText = "";
          if (angular.isUndefined($scope.updateAssignment.assignmentCompletionDt) || $scope.updateAssignment.assignmentCompletionDt === null) {
            $scope.updateAssignment.toDisable = false;
            $scope.isCompletiondate = false;

          } else {
            $scope.updateAssignment.toDisable = true;
            $scope.isCompletiondate = true;
            $scope.checkCompletiondate = function () {
              return $scope.isCompletiondate;
            };
          }

          $scope.finished=true;
          $scope.disableSaveButton=false;

          //createAssignment();
          toastr.clear();
          toastr.success("Create petition draft completed and Review petition draft assignment created and sent to PTAB AIA trials work queue.", {
            iconClass: 'toast-success'
          });
          $scope.saveInProgress=false;
          callUpdateAppeal();
          callUpdateAppealPetition()
          ngDialog.closeAll(true);

        }, function (failureResponse) {
          $scope.saveInProgress=false;
          $scope.disableeWFButton=false;
          toastr.clear();
          toastr.warning(failureResponse.data.message, {
            iconClass: 'toast-warning'
          });
      

        });
    
  }

  function convertDocToPdf(data) {
    var pdfDataFileForDoc = new FormData();
    angular.forEach($scope.fileExtractContent, function (value) {
      pdfDataFileForDoc.append('uploadMultipartFileContents', value);
    });
    var url= CONSTANTS.URL.PETITION_DOC_SAVE + $scope.serialNumber;
    HttpFactory.postPdf( url, pdfDataFileForDoc)
    .then(function (successResponse) {
      $scope.documentReady=true;
     // $scope.PostDataResponseForDoc = successResponse.data.fileContent;
     // $scope.genPdfFileNameForDoc = successResponse.data.fileName;
      $scope.wordDocFileName = successResponse.data.wordDocFileName;
     // $scope.contentsPreviewForDoc= 'data:application/pdf;base64,' + $scope.PostDataResponseForDoc;
    //  $scope.getPreview($scope.contentsPreviewForDoc);
    saveAssignment(data);
    }, function (failureResponse) {
      $scope.saveInProgress=false;
    });
  }

  function getDefaultUser() {
    AssignmentHelperService.getDefaultUser(CONSTANTS.URL.DEFAULT_PETITION_USER).then(function(returnValue) {
      $scope.getNextAssignmentInfo(returnValue.descriptionText, returnValue.valueText).then(function(currentAssignee) {
        //$scope.setSelectedJudge(currentAssignee);
        getLkryza();
      });
    });   
  }

  function getDefaultUserNew() {
    AssignmentHelperService.getDefaultUser(CONSTANTS.URL.CREATE_PETITION_DRAFT_ASSIGNEE).then(function(returnValue) {
      getUserIdentifier(returnValue.descriptionText);
    });   
  }

  function get799DefaultUser() {
    AssignmentHelperService.getDefaultUser(CONSTANTS.URL.CREATE_PETITION_ASSIGNEE).then(function(returnValue) {
      getUserIdentifier(returnValue.descriptionText);
    });   
  }

 
  function getAssigneeList(nextAssignee) {
    AssignmentHelperService.getDefaultUser(CONSTANTS.URL.DEFAULT_PETITION_USER).then(function(returnValue) {
      
      $scope.getNextAssignmentInfo(returnValue.descriptionText, returnValue.valueText).then(function(currentAssignee) {
        $scope.setSelectedJudge(currentAssignee);
      });
    });   
  }

  function getUserIdentifier(value){
    HttpFactory.getActions('/user-management/user-data?userIdentiifier='+value)
    .then(function (successResponse) {
      var obj = {
        "assigneeNumberText":successResponse.data.userIdentiifier,
        "assigneeFullNameText":successResponse.data.fullName
      }
      AssignmentHelperService.getDefaultUser(CONSTANTS.URL.DEFAULT_PETITION_USER).then(function(returnValue) {
      $scope.getNextAssignmentInfo(returnValue.descriptionText, successResponse.data.userIdentiifier).then(function(currentAssignee) {
        $scope.setSelectedJudge(obj);
      });
    });
    }, function (failureResponse) {
      toastr.clear();
      toastr.error(failureResponse.data.message, {
      iconClass: 'toast-danger'
      });
    });        
  }

  function getAppealPetitions(){
      HttpFactory.getActions('/petition/get-appeal-petition-info?serialNumber='+$scope.serialNumber+'&appealNumber='+$scope.appealNumber+'&assignmentIdentifier='+$scope.assignmentIdentifier)
      .then(function (successResponse) {
        $scope.petitionTypeCd = successResponse.data.petitionTypeCd;
        $scope.description = successResponse.data.description;
        $scope.petitionFilingDate = successResponse.data.petitionFilingDate;
        $scope.petitionId = successResponse.data.petitionId;
        getLkryza();
      }, function (failureResponse) {
        toastr.clear();
        toastr.error(failureResponse.data.message, {
        iconClass: 'toast-danger'
      });
      });        
  }

  
  
  function getLkryza() {
        AssignmentHelperService.getDefaultUser(CONSTANTS.URL.DEFAULT_PETITION_FOR_LKRYZA).then(function(returnValue) {
          vm.defaultUserLkryza=returnValue;
          console.log(vm.defaultUserLkryza.descriptionText);
          console.log($scope.petitionTypeCd);
        if($scope.petitionTypeCd == vm.defaultUserLkryza.descriptionText){
          console.log("Inside 799");
          $scope.enableFlag=false;
          get799DefaultUser()
        }
        else{
          console.log("Inside 720");
          $scope.enableFlag=true;
          getDefaultUserNew();
        }
        });   
      }


  $scope.assignmentListEnterKey = function(event) {
    if (event.keyCode===13) {
      if ( $scope.allUsers.length>0) {
        $scope.setSelectedJudge($scope.allUsers[0]);
        $scope.dontMakeVisible=true;
      }
    }
  }

  $scope.showJudgeList = function () {
    if ($scope.assigneePlaceholders==='Loading assignees...') {
      return;
    }

    if ($scope.dontMakeVisible) {
        $scope.dontMakeVisible=false;
    return;
    }
    if (!$scope.judgeListVisible) {
      $scope.judgeListVisible = !$scope.judgeListVisible;
    }
  };

  $scope.setSelectedJudge = function (judge) {
    if (judge.assigneeFullNameText !== "Select assignee") {
     $scope.selectedAssignmentType = judge;
    } else {
      $scope.selectedAssignmentType={};
    }
    $scope.judgeListVisible=false;
  };

  $scope.selectJudgeEntered = function(event, judge) {
    if (event.keyCode === 13) {
      $scope.setSelectedJudge(judge);
    }
  };

  $scope.searchForJudge = function (input) {
    $scope.judgeListVisible=true;
    var tempList = [];
    if (angular.isDefined(input) && input.assigneeFullNameText.trim() !== "") {
      angular.forEach($scope.backupAllUsers, function (currentJudge) {
        if (currentJudge.assigneeFullNameText.toLowerCase().includes(input.assigneeFullNameText.toLowerCase())) {
          tempList.push(currentJudge);
        }
      });
      $scope.allUsers = angular.copy(tempList);
    } else {
      $scope.allUsers = angular.copy($scope.backupAllUsers);
    }
  };

  function callUpdateAppeal() {
    var updateObject = {
      "serialNumber": $scope.serialNumber,
      "appealNumber":$scope.appealNumber,
       "audit": {
          "createUserIdentifier": $rootScope.userInfo.userId,
          "lastModifiedUserIdentifier": $rootScope.userInfo.userId,
          "lastModifiedTimestamp": (new Date()).getTime(),
          "createTimestamp": (new Date()).getTime(),
          "lockControlNumber": 0
        },
        "assignmentType": "ANY" 
    }

    HttpFactory.putActions("/appeals/update_petition_appeal", updateObject)
    .then(function (successResponse) {
      console.log(successResponse);
    }, function (failureResponse) {
      toastr.clear();
      toastr.error(failureResponse.data.message, {
        iconClass: 'toast-danger'
      });
    });
  }

  function callUpdateAppealPetition() {
   // http://localhost:8080/petition/update-appeal-petition?serialNumber=13774283&appealNumber=2017011501&petitionId=18747425&assignmentIdentifier=1231263
    HttpFactory.putActions('/petition/update-appeal-petition?serialNumber='+$scope.serialNumber+'&appealNumber='+$scope.appealNumber+'&petitionId='+$scope.petitionId+'&assignmentIdentifier='+$scope.newAssignmentId)
    .then(function (successResponse) {
      console.log(successResponse);
    }, function (failureResponse) {
      toastr.clear();
      toastr.error(failureResponse.data.message, {
        iconClass: 'toast-danger'
      });
    });
  }

  });
})();
