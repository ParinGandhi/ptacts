(function () {
  "use strict";

  angular
    .module('ptabe2e')
    .controller('PanelingMessageModalController', function (ngDialog, createPanelData, flags, circulationInProcess, HttpFactory, CONSTANTS, toastr, $rootScope) {
      var vm = this;
      vm.flags = flags;
      var panelData = createPanelData;
      vm.submittingPanel = false;

      vm.selectOk = function () {
        ngDialog.close(lastDialog());
      };

      vm.selectNo = function () {
        vm.flags.showInitialMessage = false;
        vm.flags.showNoDateMessage = true;
        vm.flags.showConfirmSubmitMessage = false;

      };

      vm.selectYes = function () {
        ngDialog.closeAll(true);
      };

      vm.cancelSubmitPanel = function () {
        ngDialog.close(lastDialog());
      };

      vm.cancel = function () {
        ngDialog.close(lastDialog(), false);
      };

      vm.confirm = function () {
        ngDialog.close(lastDialog(), true);
      };

      /* istanbul ignore next*/
      vm.submitPanel = function () {
        vm.submittingPanel = true;
        panelData.panelAssignment.completionDate = new Date().getTime();
        if (!panelData.judgePanel.panelDate) {
          panelData.judgePanel.panelDate = new Date().getTime();
        }

        if (panelData.rehearingData && (panelData.rehearingData.rehearingDecisionDueDate !== null || panelData.rehearingData.rehearingDecisionDueDate !== "")) {
          var referenceDataQuery = {
            "assignmentType": panelData.panelAssignment.assignmentType,
            "date": panelData.judgePanel.panelDate,
            "caseNumber": panelData.appealNumber
          };
          panelData.panelAssignment.completionCode = 'ORIGINAL_PANEL';
          HttpFactory.postActions("/reference-data/business-date", referenceDataQuery)
            .then(function (successResponse) {
              panelData.rehearingData.rehearingDecisionDueDate = new Date(successResponse.data).getTime();
              if (circulationInProcess) {
                panelData.completionCode = 'COMPLETE';
                panelData.panelReorder = {
                  "panelReorderApproved": true
                };
              }
              var url = circulationInProcess ? '/circulation/panel-reorder-decision' : CONSTANTS.URL.CREATE_JUDGE_PANEL;
              HttpFactory.postActions(url, panelData)
                .then(function (successResponse) {

                  toastr.success(CONSTANTS.TOASTER.updatePanel, {
                    iconClass: 'toast-success'
                  });

                  if ($rootScope.isMergedCase) {
                    toastr.success(successResponse.data.title + " assignments for " + $rootScope.mergedApplListForToastr + " have been closed.", {
                      iconClass: 'toast-success'
                    });
                  }
                  ngDialog.closeAll(true);
                }, function (failureResponse) {
                  // intentional
                })
                .finally(function () {
                  vm.submittingPanel = false;
                });

            }, function (failureResponse) {
              // intentional
            })
            .finally(function () {
              vm.submittingPanel = false;
            });
        } else {
          if (panelData.panelAssignment.assignmentType === "CSDP") {
            panelData.panelAssignment.completionCode = "CREATE_SUBSEQUENT";
          } else {
            panelData.panelAssignment.completionCode = 'COMPLETE';
          }

          if (circulationInProcess) {
            panelData.completionCode = 'COMPLETE';
            panelData.panelReorder = {
              "panelReorderApproved": true
            };

            HttpFactory.putActions('/circulation/panel-reorder-decision', panelData)
              .then(function (successResponse) {

                toastr.success(CONSTANTS.TOASTER.updatePanel, {
                  iconClass: 'toast-success'
                });

                if ($rootScope.isMergedCase) {
                  toastr.success(successResponse.data.title + " assignments for " + $rootScope.mergedApplListForToastr + " have been closed.", {
                    iconClass: 'toast-success'
                  });
                }
                ngDialog.closeAll(true);
              }, function (failureResponse) {
                // intentional
              })
              .finally(function () {
                vm.submittingPanel = false;
              });
          } else {
            HttpFactory.postActions(CONSTANTS.URL.CREATE_JUDGE_PANEL, panelData)
              .then(function (successResponse) {

                toastr.success(CONSTANTS.TOASTER.updatePanel, {
                  iconClass: 'toast-success'
                });

                if ($rootScope.isMergedCase) {
                  toastr.success(successResponse.data.title + " assignments for " + $rootScope.mergedApplListForToastr + " have been closed.", {
                    iconClass: 'toast-success'
                  });
                }
                ngDialog.closeAll(true);
              }, function (failureResponse) {
                // intentional
              })
              .finally(function () {
                vm.submittingPanel = false;
              });
          }
        }
      };

      function lastDialog() {
        var openDialogs = ngDialog.getOpenDialogs();
        return openDialogs[openDialogs.length - 1];
      }

    });
})();
