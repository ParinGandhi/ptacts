'use strict';

angular.module('adf.widget.assignmentBasedDocket', ['adf.provider'])
  .config(function (dashboardProvider) {
    dashboardProvider
      .widget('assignmentBasedDocket', {
        title: 'Assignment Based Docket',
        description: 'View docket information based on assignment',
        templateUrl: '{widgetsPath}/assignmentBasedDocket/src/view.html',
        edit: {
          templateUrl: '{widgetsPath}/assignmentBasedDocket/src/edit.html'
        }
      });
  }).directive('assignmentbaseddocketView', function () {
    return {
      restirct: 'E',
      templateUrl: 'app/components/widgets/assignmentBasedDocket/src/assignmentbaseddocketView.html',
      bindToController: true
    };
  })
  .controller('AssignmentBasedDocketController', function ($log, $scope, $rootScope, uiGridConstants, HttpFactory, $timeout,
    SearchHelperService, ngDialog, CONSTANTS, $filter, CommonHelperService, $window, i18nService) {

    var vm = this;
    var advancedSearchOcurred = false;

    var widgetRandomId = (Math.floor((Math.random() * 1000) + 1)).toString();
    $log.debug("Random Id=" + widgetRandomId);
    $scope.advancedSearchStartDateIdABD = "advancedSearchStartDateABD-" + widgetRandomId;
    $scope.advancedSearchEndDateIdABD = "advancedSearchEndDateABD-" + widgetRandomId;
    $scope.assignmentTypePlaceholder = "Loading types...";
    var currentEditRow;
    var isSPL = $rootScope.userInfo.roleDescription ? $rootScope.userInfo.roleDescription.toUpperCase().indexOf('SUPERVISOR') > -1 ? true : false : false;
    $scope.isSPL = isSPL;
    if ($rootScope.userInfo.roleDescription === "Business Administrator") {
      isSPL = true;
    }

    /* istanbul ignore next */
    $rootScope.$on('broadcastZoneWidth', function (event, param) {
      if ($scope.widgetIdentifier === param.widgetIdentifier) {
        $scope.setWidgetZone(param.zoneWidth);
      }
    });

    i18nService.get('en').gridMenu.exporterAllAsCsv = 'Export filtered data as csv';
    i18nService.get('en').gridMenu.exporterVisibleAsCsv = 'Export this page as csv';
    i18nService.get('en').gridMenu.exporterSelectedAsCsv = 'Export selected as csv';

    var scope = angular.element(document.getElementById('mainTabId')).scope();

    $scope.setWidgetZone = function (zoneWidth) {
      /* istanbul ignore else */
      if (angular.isUndefined(zoneWidth)) {
        scope.vm.getWidgetZone($scope.$parent.$parent.$parent.definition);
        $scope.zoneWidth = $scope.$parent.$parent.$parent.definition.zoneWidth;
      } else {
        $scope.zoneWidth = zoneWidth;
      }
    };
    $scope.setWidgetZone();

    $scope.selectUnselect = true;
    $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
    $scope.lastRefresh = new Date();
    var initialLoad = true;
    var isFilterChanged = false;
    var isColumnVisibilityChanged = false;
    var isColumnPinnedChanged = false;
    var isColumnSizeChanged = false;
    var isSortChanged = false;
    var isColumnPositionChanged = false;
    var isPaginationChanged = false;
    var isAssignmentDocket = true;
    $scope.assignmentDocketPreferencesChanged = false;
    $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
    $scope.gridRefreshMsg = CONSTANTS.MESSAGES.GRID_REFRESH;
    $scope.isGridRefreshed = false;
    $scope.isLoading = false;
    $scope.url;
    var hasFilterFlag;
    $scope.docketListOrderChanged = false;
    $rootScope.assignmentDocketColumnsChanged = false;
    $scope.assignee = {
      "fullName": null
    };
    $scope.showAssignorDDL = false;
    $scope.assignorCount = 0;
    var fullSelectedList = [];


    /* istanbul ignore next */
    function resetUnsavedChangesFlags() {
      isFilterChanged = false;
      isColumnVisibilityChanged = false;
      isColumnPinnedChanged = false;
      isColumnSizeChanged = false;
      isSortChanged = false;
      isColumnPositionChanged = false;
      isPaginationChanged = false;
      $scope.assignmentDocketPreferencesChanged = false;
      $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
    }

    var requiredPageCountAssignments;

    getRequiredAssignmentPageCount();

    /* istanbul ignore next */
    $scope.gridOptions = {
      enableGridMenu: true,
      useExternalFiltering: true,
      exporterCsvFilename: 'Assignment docket ' + CommonHelperService.getCurrentTime() + '.csv',
      exporterOlderExcelCompatibility: true,
      exporterMenuExcel: false,
      exporterMenuPdf: false,
      gridMenuShowHideColumns: true,
      enableFiltering: true,
      multiSelect: true,
      enableCellEditOnFocus: true,
      showGridFooter: true,
      paginationPageSizes: [10, 25, 50, 100],
      enableHorizontalScrollbar: uiGridConstants.scrollbars.WHEN_NEEDED,
      exporterFieldCallback: function (grid, row, col, value) {
        $scope.gridOptions.exporterCsvFilename = 'Assignment docket ' + CommonHelperService.getCurrentTime() + '.csv';
        if (col.colDef.type === 'date') {
          if (col.name === 'assignmentCreateTs' || col.name === "taskCreatedTs" || col.name === "lastModifiedTs" || col.name === "assignmentLastModifiedTs") {
            value = $filter('date')(value, 'MM/dd/yyyy hh:mm:ss a');
          } else {
            value = $filter('date')(value, 'MM/dd/yyyy');
          }
          if (angular.isUndefined(value) || value === null) {
            value = "";
          } else {
            value = " " + value;
          }
        }
        if (col.name === 'alert') {
          if (angular.isDefined(value)) {
            var cleanList = [];
            value = value.split(",");
            angular.forEach(value, function (item) {
              if (item.trim() !== "" && item !== 'end') {
                cleanList.push(item);
              }
            });
            value = cleanList.join();
          }
        }
        if (col.name === "assigneeHistory") {
          value = "";
        }
        if (col.colDef.field === 'FK_ASSIGNMENT_STATUS_CD') {
          return value = value === 'A' ? "Open" : "Closed";
        }
        if (col.name === "ADDITIONAL_APJ_WORKER_ID_TX") {
          value = setPanelColumnForExport(row.entity);
        }
        return value;
      },
      gridMenuCustomItems: [{
        title: 'Save grid preferences',
        action: function () {
          $scope.saveGridPreferences();
        },
        order: 100
      },
      {
        title: 'Show hidden filters',
        action: function () {
          showHiddenFilteredColumns();
        },
        order: 190
      },
      {
        title: 'Export full docket as csv',
        action: function () {
          $scope.download_csv_MxdCaseDkt();
        },
        order: 220
      },
      {
        title: 'Mandatory columns',
        order: 221
      },
      {
        title: 'Assignment due date',
        icon: 'fas fa-check',
        order: 224
      },
      {
        title: 'Assignment title',
        icon: 'fas fa-check',
        order: 225
      },
      {
        title: 'Case #',
        icon: 'fas fa-check',
        order: 226
      }
      ],
      onRegisterApi: function (gridApi) {
        $scope.gridApi = gridApi;




        $scope.gridApi.core.notifyDataChange = function (val) {
          updateEditedRow();
        };
        $scope.gridApi.core.on.filterChanged($scope, function () {
          isFilterChanged = true;
          var grid = this.grid;
          vm.grid = this.grid;
          $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
          /* Change the scope to $scope.$$childHead.$$childHead.searchText after adding loading screen
          If there are no filters and no search text, then set the grid data to original data */
          if ($scope.numberOfFilters === 0 &&
            (angular.isUndefined($scope.$$childTail.$$prevSibling.searchText) ||
              $scope.$$childTail.$$prevSibling.searchText === "" ||
              $scope.$$childTail.$$prevSibling.searchText === null)) {
            $scope.gridOptions.data = $scope.myData;
            /* If search text is defined and there are filters, then set grid data to filtered data before searching for searched text */
          } else if (angular.isDefined($scope.$$childTail.$$prevSibling.searchText) && $scope.numberOfFilters > 0) {
            $scope.gridOptions.data = SearchHelperService.filterGrid(grid, $scope.myData);
            $scope.$parent.$$childHead.simpleSearch($scope.$$childTail.$$prevSibling.searchText);
            /* If search text is defined and there are no filters, then set the grid data to original data before searching for searched text */
          } else if (angular.isDefined($scope.$$childTail.$$prevSibling.searchText) && $scope.numberOfFilters === 0) {
            $scope.gridOptions.data = $scope.myData;
            $scope.$parent.$$childHead.simpleSearch($scope.$$childTail.$$prevSibling.searchText);
          } else {
            /* If there are filters and no search text, then set grid data to filtered data */
            $scope.gridOptions.data = SearchHelperService.filterGrid(grid, $scope.myData);
          }
          checkForUnsavedChanges();
        });

        $scope.gridApi.selection.on.rowSelectionChanged($scope, function (row) {
          $scope.selectedRows = $scope.gridApi.selection.getSelectedRows();
        });

        $scope.gridApi.core.on.columnVisibilityChanged($scope, function () {
          isColumnVisibilityChanged = true;
          updateColumnDefs($scope.gridOptions.columnDefs);
          checkForUnsavedChanges();
        });

        $scope.gridApi.pinning.on.columnPinned($scope, function () {
          isColumnPinnedChanged = true;
          updateColumnDefs($scope.gridOptions.columnDefs);
          checkForUnsavedChanges();
        });

        $scope.gridApi.colResizable.on.columnSizeChanged($scope, function () {
          isColumnSizeChanged = true;
          checkForUnsavedChanges();
        });
        $scope.gridApi.core.on.sortChanged($scope, function () {
          isSortChanged = true;
          checkForUnsavedChanges();
        });
        $scope.gridApi.colMovable.on.columnPositionChanged($scope, function () {
          isColumnPositionChanged = true;
          checkForUnsavedChanges();
        });
        $scope.gridApi.pagination.on.paginationChanged($scope, function () {
          isPaginationChanged = true;
          checkForUnsavedChanges();
        });
      }

    };


    /* istanbul ignore next  */
    function showHiddenFilteredColumns() {
      var hiddenFilteredColumns = SearchHelperService.hasHiddenColumnFilters($scope.gridApi.grid.columns);
      angular.forEach(hiddenFilteredColumns, function (column) {
        column.showColumn();
        $scope.preferencesChanged = true;
      });
      $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
    }


    function setPanelColumnForExport(row) {
      var judgePanel = "";
      if (row.appealPanelJudgeOne) {
        judgePanel += row.appealPanelJudgeOne.trim();
      }
      if (row.ATTORNEY_WORKER_ID) {
        judgePanel += ' (' + row.ATTORNEY_WORKER_ID.trim() + ')';
      }
      if (row.appealPanelJudgeTwo) {
        judgePanel += ' | ' + row.appealPanelJudgeTwo.trim();
      }
      if (row.appealPanelJudgeThree) {
        judgePanel += ' | ' + row.appealPanelJudgeThree.trim();
      }
      return judgePanel;
    }


    /* istanbul ignore next */
    $scope.openAssignmentDialog = function (dataToPass) {
      var initData = {};
      if (dataToPass) {
        initData = dataToPass;
      }
      $scope.data = {};
      ngDialog.open({
        template: "app/components/widgets/assignments/src/createAssignment.html",
        controller: 'CreateAssignmentController',
        scope: $scope,
        width: '60%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,

        resolve: {
          newData: function () {
            return $scope.data;
          },
          initData: function () {
            return initData;
          }
        }
      }).closePromise.then(function (refreshGrid) {
        if (refreshGrid.value) {
          $timeout(function () {
            $scope.refreshGrid();
          }, 400);
          $log.debug("dialog closed from assignment file");
        }

      }, function () {
        // intentional
      });
    };


    /* istanbul ignore if */
    if (angular.isDefined($scope.$parent.model)) {
      $scope.assignmentDocketDataUrlList = $scope.$parent.model.dataUrlText.split(",").reduce(function (map, col) {
        map[col.split(":")[0]] = col.split(":")[1];
        return map;
      }, {});
      $scope.widgetIdentifier = $scope.$parent.model.widgetIdentifier;
    } else {
      /* istanbul ignore if */
      if ($scope.definition.type === "assignmentBasedDocket") {
        $scope.url = $scope.$parent.$parent.$parent.$$childHead.$$childTail.$$childHead.url;
        $scope.assignmentDocketDataUrlList = $scope.definition.dataUrlText.split(",").reduce(function (map, col) {
          map[col.split(":")[0]] = col.split(":")[1];
          return map;
        }, {});
        $scope.widgetIdentifier = $scope.definition.widgetIdentifier;
      }
    }


    $scope.getAssignmentDocketColumns = function () {
      if (isAssignmentDocket || $scope.definition.type === 'assignmentBasedDocket') {
        isAssignmentDocket = false;
        HttpFactory.getActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS + $scope.widgetIdentifier)
          .then(function (successResponse) {
            $scope.selectedColumns = successResponse.data.selectedColumns;
            $scope.selectedCols = [];
            $scope.availableCols = [];
            angular.forEach($scope.selectedColumns, function (thisColumn) {
              if (thisColumn.visible) {
                $scope.selectedCols.push(thisColumn);
              } else {
                $scope.availableCols.push(thisColumn);
              }
            });
            $log.debug('Selected:');
            $log.debug($scope.selectedCols);
            $log.debug('Available: ');
            $log.debug($scope.availableCols);
            $scope.originShowHide = angular.copy($scope.selectedColumns);
            $scope.loadedAssignColumns = true;
            for (var i = 0; i < $scope.selectedColumns.length; i++) {
              if (!$scope.selectedColumns[i].visible) {
                $scope.selectUnselect = false;
                $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
              }
            }
            $log.debug("Assignment docket (" + $scope.widgetIdentifier + ") getAssignmentDocketColumns success response: ");
            $log.debug(successResponse);
          }, function (failureResponse) {
            $log.debug("Assignment docket (" + $scope.widgetIdentifier + ") getAssignmentDocketColumns failure response: ");
            $log.debug(failureResponse);
          });
      }
    };


    $scope.setUrl = function (url, advancedSearchFlag) {
      $scope.setUnSelectAll();
      if (url == "/mixed-case-dockets/my-group/" + $scope.widgetIdentifier ) {
        $scope.showAssignorDDL = true;
        $scope.myGroupFlag = true;
        $scope.myTeamFlag = false;
      }
      else if(url == "/mixed-case-dockets/my-team/" + $scope.widgetIdentifier){
        $scope.showAssignorDDL = true;
        $scope.myTeamFlag = true;
        $scope.myGroupFlag = false;
      }
      else {
        $scope.showAssignorDDL = false;
        $scope.myGroupFlag = false;
        $scope.myTeamFlag = false;
      }
      advancedSearchOcurred = false;
      if (url === 'advanceSearch') {
        $scope.url = '/mixed-case-dockets/advanceSearch/' + $scope.widgetIdentifier;
      } else {
        $scope.url = url;
      }
      $scope.searchData = !advancedSearchFlag;
      $scope.advancedSearchFlag = advancedSearchFlag;
      if (advancedSearchFlag) {
        $scope.advancedSearch();
      } else {
        $scope.getAssignmentBasedDocket();
      }
    };


    $scope.openCaseViewer = function (row) {
      $window.open("#/caseViewer/" + row.entity.FK_AD_FK_AA_SERIAL_NO + "/" + row.entity.FK_AD_FK_APPEAL_NO);
    };


    /* istanbul ignore next: toaster error */
    $scope.getAssignmentBasedDocket = function () {
      $scope.enableloading = true;
      $scope.refreashFaild = false;
      $scope.isLoading = true;
      $scope.gridIsLoading = true;
      HttpFactory.getActions($scope.url)
        .then(function (successResponse) {
          if (advancedSearchOcurred) {
            return;
          }
          $scope.enableloading = false;
          $scope.refreashFaild = false;
          $scope.lastRefresh = new Date();
          $scope.dateValid = false;
          if (angular.isDefined(successResponse.data)) {
            $scope.myData = successResponse.data.assignmentsData;
            $scope.columnsDataMxdDocket = successResponse.data.columnsData;
            $scope.selectedCols = [];
            $scope.availableCols = [];
            angular.forEach($scope.columnsDataMxdDocket, function (thisColumn) {
              if (thisColumn.visible) {
                $scope.selectedCols.push(thisColumn);
              } else {
                $scope.availableCols.push(thisColumn);
              }
            });
            $scope.originalData = angular.copy($scope.myData);
            $scope.updatedDocketColumnList = successResponse.data.columnsData;
            $scope.originalDocketAssignments = angular.copy($scope.updatedDocketColumnList);
            var setColumnsResponse = CommonHelperService.setColumnDefinitions($scope.updatedDocketColumnList);
            $scope.selectUnselect = setColumnsResponse.selectUnselect;
            $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
            hasFilterFlag = setColumnsResponse.filterCount;
            updateColumnDefs(setColumnsResponse.colDefs);
            $scope.gridOptions.paginationPageSize = successResponse.data.paginationSize !== undefined ? successResponse.data.paginationSize : 25;
            if (hasFilterFlag > 0) {
              $scope.numberOfFilters = hasFilterFlag;
              var filteredData = SearchHelperService.filterTable($scope.myData, setColumnsResponse.colDefs);
              $timeout(function () {
                $scope.gridOptions.data = filteredData ? filteredData : [];
                $scope.savedFilteredData = filteredData ? filteredData : [];
              }, 200);
            } else {
              $scope.numberOfFilters = 0;
              if ($scope.myData) {
                $timeout(function () {
                  $scope.gridOptions.data = $scope.myData;
                }, 200);
              } else {
                $scope.gridOptions.data = [];
              }
            }
            $scope.isLoading = false;
            $scope.assignmentDocketPreferencesChanged = false;
            $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
            $timeout($scope.setPaginationManually, 700);
            $scope.noRecordsFound = false;
            $timeout(function () {
              initialLoad = false;
            }, 2000);
            if ($scope.isGridRefreshed) {
              CommonHelperService.setToastr(CONSTANTS.TOASTER.refreshData, "success");
            }
            $scope.gridIsLoading = false;
          }
        }, function (failureResponse) {
          $scope.gridOptions.data = [];
          $scope.myData = [];
          $scope.refreashFaild = true;
          $scope.refreashFailDate = new Date();
          if (angular.isUndefined($scope.lastRefresh) || $scope.lastRefresh === null) {
            $scope.dateValid = true;
          }
          CommonHelperService.setToastr(failureResponse.data.message, "info");
          $scope.isLoading = false;
          $scope.enableloading = false;
          $scope.dateValid = true;
          $scope.gridOptions.data = [];
        });
    };


    $scope.validateTeamLead = function () {
      HttpFactory.getActions(CONSTANTS.URL.VALIDATETEAMLEAD + "userId=" + $rootScope.userInfo.userId)
        .then(function (successResponse) {
          $scope.disableHierarchy = successResponse.data;
        }, function () {
          // intentional
        });
    };
    $scope.validateTeamLead();


    $scope.highlightFilteredHeader = function (row, rowRenderIndex, col) {
      if (col.filters[0].term) {
        return 'header-filtered';
      } else {
        return '';
      }
    };


    $scope.moveItem = function (origin, destination) {
      var temp = $scope.selectedCols[destination];
      $scope.selectedCols[destination] = $scope.selectedCols[origin];
      $scope.selectedCols[origin] = temp;
      $scope.docketListOrderChanged = true;
      $rootScope.assignmentDocketColumnsChanged = true;
    };


    $scope.listItemUp = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex - 1);
    };


    $scope.listItemDown = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex + 1);
    };


    $scope.moveSourcetoDestination = function () {
      angular.forEach($scope.clickedColumn, function (column) {
        column.visible = true;
        $scope.selectedCols.push($scope.availableCols[$scope.availableCols.indexOf(column)]);
        $scope.availableCols.splice($scope.availableCols.indexOf(column), 1);
      });
      $scope.clickedColumn = [];
      $rootScope.assignmentDocketColumnsChanged = true;
    };


    $scope.moveSourcetoDestinationCancel = function (index) {
      $scope.selectedCols[index].visible = false;
      $scope.availableCols.push($scope.selectedCols[index]);
      $scope.selectedCols.splice(index, 1);
      $rootScope.assignmentDocketColumnsChanged = true;
    };


    $scope.toggleSelectAll = function () {
      angular.forEach($scope.availableCols, function (column) {
        column.visible = true;
        $scope.selectedCols.push(column);
      });
      $scope.availableCols = [];
      $rootScope.assignmentDocketColumnsChanged = true;
    };


    $scope.removeAll = function () {
      var tempArray = [];
      $rootScope.assignmentDocketColumnsChanged = true;
      angular.forEach($scope.selectedCols, function (column) {
        if (!column.mandatory) {
          column.visible = false;
          $scope.availableCols.push(column);
        } else {
          tempArray.push(column);
        }
      });
      $scope.selectedCols = tempArray;
    };


    /* istanbul ignore next */
    $scope.saveState = function () {
      $scope.saveGridPreferences();
    };

    $scope.canEdit = function (row) {
      return checkAssignmentTypes(row.entity);
    };

    var oldValue;
    function checkEdit($scope) {
      var isEditable = checkAssignmentTypes($scope.row.entity);
      currentEditRow = $scope.row.entity;
      oldValue = currentEditRow.PAGE_COUNT_QT;
      return isEditable;
    }

    function updateEditedRow() {
      if (currentEditRow) {
        if (!currentEditRow.PAGE_COUNT_QT || currentEditRow.PAGE_COUNT_QT === 0) {
          CommonHelperService.setToastr("A page count of at least 1 is required, reseting value to " + oldValue, "error");
          currentEditRow.PAGE_COUNT_QT = oldValue;
          return;
        }

        if (currentEditRow.PAGE_COUNT_QT === oldValue) {
          return;
        }
        vm.getAssignmentById(currentEditRow.assignmentIdentifier).then(function (item) {
          if (!item && !item[0]) {
            CommonHelperService.setToastr("Error updating page count, reseting value to " + oldValue, "error");
            currentEditRow.PAGE_COUNT_QT = oldValue;
            return;
          }
          var reAssignDataArray = [];
          var theOldValue = angular.copy(oldValue);
          if (!theOldValue) {
            theOldValue = "no value";
          }
          item[0].notes = "Page count changed from " + theOldValue + " to " + currentEditRow.PAGE_COUNT_QT;
          item[0].pageNumberQuantity = currentEditRow.PAGE_COUNT_QT;
          reAssignDataArray.push(item[0]);
          HttpFactory.putActions(CONSTANTS.URL.IMPORT_BULK_REASSIGN, reAssignDataArray)
            .then(function (successResponse) {
              CommonHelperService.setToastr("Successfully updated page count", "success", 3000);
            }, function (failureResponse) {
              CommonHelperService.setToastr("Error updating page count, reseting value to " + oldValue, "error");
              currentEditRow.PAGE_COUNT_QT = oldValue;

            });
        });
      }
    }

    $scope.checkForChanges = function (row) {
      console.log("checking for chagnes");
    }

    function checkAssignmentTypes(row) {
      if (!isSPL) {
        return false;
      }
      try {
        var strTypeId = row.FK_ASSIGNMENT_TYPE_ID.toString();

        if (requiredPageCountAssignments.includes(strTypeId)) {
          return true;
        }

      } catch (error) {

      }
      return false;
    }

    function getRequiredAssignmentPageCount() {
      HttpFactory.getActions("/reference-data/code-reference-types?typeCode=MAND_ASSIGNMENTS")
        .then(function (successResponse) {
          requiredPageCountAssignments = successResponse.data[0].descriptionText.split('~');
        }, function (failureResponse) {
          console.log(failureResponse);
        });
    }

    /* istanbul ignore next */
    function updateColumnDefs(columndefs) {
      var selected = [];
      var unselected = [];
      var selectedCount = 0;
      angular.forEach(columndefs, function (col) {
        if (col.cellEditMethod) {
          col.width = 85;
          col.cellEditableCondition = checkEdit;
          col.cellTemplate = "<div ng-if=\"!grid.appScope.canEdit(row)\" style=\"margin-left:10px; padding-top:5px;\" class=\"truncateTitle\">{{row.entity.PAGE_COUNT_QT}}</div> <div ng-if=\"grid.appScope.canEdit(row)\"  title=\"Click edit button to change value, press Esc to cancel and press enter to save\" style=\"margin-left:10px; padding-top:5px;\" class=\"truncateTitle\" ng-model=\"row.entity.PAGE_COUNT_QT\">{{row.entity.PAGE_COUNT_QT}} <i style=\"padding-right:6px;padding-top:3px;\" class=\"fa fa-edit pull-right\"></i></div>";
        }

        if (col.visible) {
          selected.push(col);
          selectedCount = selectedCount + 1;
        } else {
          unselected.push(col);
        }
      });
      columndefs = [];
      angular.forEach(selected, function (col) {
        if (col.displayName === 'Alerts') {
          col = CommonHelperService.addAlertFilters(col, 'assignment based');
        }
        columndefs.push(col);
      });
      unselected.sort(CommonHelperService.alphabetizeAvailableColumns);
      angular.forEach(unselected, function (col) {
        if (col.displayName === 'Alerts') {
          col = CommonHelperService.addAlertFilters(col, 'assignment based');
        }
        columndefs.push(col);
      });
      $scope.gridOptions.columnDefs = columndefs;
    }


    $scope.showFilteringHelp = function () {
      ngDialog.open({
        template: 'app/components/helperComponents/filterHelp/filteringHelp.html',
        controller: 'CommonDialogController',
        controllerAs: 'vm',
        width: "54%",
        showClose: false
      }).then(function () {
        // intentional
      }, function () {
        // intentional
      });
    };


    $scope.sortableOptions = {
      containment: '#assignDocketColumns',
      scroll: true,
      axis: 'y',
      cursor: 'move',
      scrollSpeed: 2,
      scrollSensitivity: 160,
      update: function () {
        $rootScope.assignmentDocketColumnsChanged = true;
      }
    };


    /* istanbul ignore next */
    $scope.clearSearch = function (clearSearchText) {
      if (clearSearchText) {
        $scope.$$childTail.$$prevSibling.searchText = undefined;
        $scope.$$childTail.searchText = undefined;
      }
      if ($scope.numberOfFilters > 0) {
        $scope.gridOptions.data = SearchHelperService.filterGrid($scope.$$childHead.$$childHead.$$nextSibling.grid, $scope.myData);
      } else {
        $scope.gridOptions.data = $scope.originalData;
      }
    };


    /* istanbul ignore next */
    $scope.simpleSearch = function (textToSearch) {
      if (textToSearch !== $scope.previousTextToSearch) {
        $scope.previousTextToSearch = angular.copy(textToSearch);
        $scope.clearSearch(false);
      }
      var simpleSearchResults = [];
      angular.forEach($scope.gridOptions.data, function (thisRow) {
        for (var key in thisRow) {
          if (thisRow.hasOwnProperty(key)) {
            if (angular.isDefined(thisRow[key]) && thisRow[key] !== null) {
              if (isNaN(parseInt(thisRow[key], CONSTANTS.GLOBAL.RADIX)) || thisRow[key].toString().length !== 13) {
                if (thisRow[key].toString().toLowerCase().includes(textToSearch.trim().toLowerCase())) {
                  simpleSearchResults.push(thisRow);
                  break;
                }
              } else {
                var thisDate = new Date(thisRow[key]);
                var month = thisDate.getMonth() + 1;
                if (month < 10) {
                  month = '0' + month.toString();
                }
                var date = thisDate.getDate();
                if (date < 10) {
                  date = '0' + date.toString();
                }
                var dateToCompare = month + '/' + date + '/' + thisDate.getFullYear();
                if (dateToCompare.includes(textToSearch.trim())) {
                  simpleSearchResults.push(thisRow);
                  break;
                }
              }
            }
          }
        }
      });
      if (simpleSearchResults.length === 0) {
        CommonHelperService.setToastr(CONSTANTS.TOASTER.noRecords, "error");
      }
      $scope.gridOptions.data = simpleSearchResults;
    };


    vm.getAssignmentById = function (ptabID) {
      return HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTBYID + ptabID)
        .then(function (successResponse) {
          $scope.item = successResponse.data;
          $scope.itemsSelected = [];
          $scope.itemsSelected.push($scope.item);
          return $scope.itemsSelected;

        },
          function (failureResponse) {
            $scope.itemsSelected = [];
            $log.debug(failureResponse);
            return failureResponse;

          });
    };

    function checkCirculattion() {
      try {
        return $scope.circulationJudgeAssignments && ($scope.itemsSelected[0].assigneeRoleCode === 'Judge' && $scope.circulationJudgeAssignments.includes($scope.itemsSelected[0].assignmentType)) || $scope.circulationAssignments.includes($scope.itemsSelected[0].assignmentType);
      } catch (error) {
        return false;
      }

    }



    /* istanbul ignore next: toaster error */
    $scope.openupdateAssignmentModal = function (row) {
      if (angular.isDefined(row)) {
        $scope.mySelectedRows = [];
        $scope.mySelectedRows.push(row.entity);
      } else {
        $scope.mySelectedRows = $scope.gridApi.selection.getSelectedRows();
      }
      if ($scope.mySelectedRows.length === 0) {
        toastr.clear();
        toastr.error(CONSTANTS.TOASTER.selectRow, {
          iconClass: 'toast-danger'
        });
      } else {
        //       $scope.clearAssignmentTimeout();
        vm.getAssignmentById($scope.mySelectedRows[0].assignmentIdentifier).then(function () {
          if ($scope.circulationJudgeAssignments && ($scope.itemsSelected[0].assigneeRoleCode === 'Judge' && $scope.circulationJudgeAssignments.includes($scope.itemsSelected[0].assignmentType)) || $scope.circulationAssignments.includes($scope.itemsSelected[0].assignmentType)) {
            window.open("#/circulation/" + $scope.itemsSelected[0].serialNumber + "/" + $scope.itemsSelected[0].appealNumber);
            //window.open("#/circulation/" + row.entity.FK_AD_FK_AA_SERIAL_NO + "/" + row.entity.FK_AD_FK_APPEAL_NO);
          } else if ($scope.itemsSelected[0].assignmentType.indexOf("ATP") === 0) {

            openPromoteToAppealModal(row);
          } else {
            $scope.itemsSelected[0].priorityIndicator = $scope.itemsSelected[0].priorityIndicator === 'Y' ? true : false;
            ngDialog.open({
              template: "app/components/widgets/assignments/src/updateAssignmentModal.html",
              controller: 'updateAssignmentManagementController',
              scope: $scope,
              width: '62%',
              appendClassName: 'ngdialog-content-cust',
              showClose: false,
              closeByEscape: false,
              closeByDocument: false,
              resolve: {
                items: function () {
                  return $scope.itemsSelected;
                },
                readOnly: function () {
                  return false;
                }
              }
            }).closePromise.then(function (refreshGrid) {
              if ($rootScope.ngrOpenCreateAssignment === 0) {
                var data = {
                  appealNumber: $scope.mySelectedRows[0].FK_AD_FK_APPEAL_NO,
                  assignmentTitle: "Create dismissal assignment",
                  assignmentTypeCode: "CDD",
                  assignmentTypeDisplayName: "Create dismissal draft"
                };
                $scope.openAssignmentDialog(data);
              }
              $rootScope.ngrOpenCreateAssignment = null;
              if (refreshGrid.value) {
                $scope.refreshGrid();
                $scope.$$childTail.$$prevSibling.searchText = undefined;
              }
            }, function () {
              // intentional
            });
          }
        });
      }
    };

    function openPromoteToAppealModal(row) {
      ngDialog.open({
        template: "app/components/widgets/assignments/src/promoteToAppealAdminModal.html",
        controller: 'PromoteToAppealAdminModalController',
        scope: $scope,
        width: '80%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,
        resolve: {
          items: function () {
            return $scope.itemsSelected;
          }
        }
      }).closePromise.then(function (refreshGrid) {
        $scope.refreshGrid();
        $scope.$$childTail.$$prevSibling.searchText = undefined;
      }, function () {
        // intentional
      });
    }

    function getCirculationAssignments() {
      HttpFactory.getActions("/reference-data/code-reference-types?typeCode=CIRCULATION_MANAGER")
        .then(function (successResponse) {
          $scope.circulationAssignments = successResponse.data[0].descriptionText.split('~');
        }, function (failureResponse) {
          console.log(failureResponse);
        });
    }
    getCirculationAssignments();


    function getCirculationJudgeAssignments() {
      HttpFactory.getActions("/reference-data/code-reference-types?typeCode=CIRCULATION_JUDGE")
        .then(function (successResponse) {
          $scope.circulationJudgeAssignments = successResponse.data[0].descriptionText.split('~');
        }, function (failureResponse) {
          console.log(failureResponse);
        });
    }
    getCirculationJudgeAssignments();


    /* istanbul ignore next */
    $scope.saveGridPreferences = function () {
      if ($scope.gridApi) {
        $scope.gridState = CommonHelperService.setGridWidthMap($scope.gridApi.saveState.save());
      } else if ($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi) {
        $scope.gridState = CommonHelperService.setGridWidthMap($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi.saveState.save());
      }
      if (angular.isDefined($scope.$$childTail) && $scope.$$childTail !== null) {
        $scope.$$childTail.searchText = "";
      }
      $scope.updateColumns();
    };
    $scope.paginationManual = false;
    $scope.setPaginationManually = function () {
      $scope.paginationManual = false;
    };


    /* istanbul ignore next */
    $rootScope.$on('adfCustomizeWidgetServiceCall', function () {
      if ($rootScope.widgetIdentifier === $scope.widgetIdentifier) {
        switch ($rootScope.widgetHeight) {
          case "widgetHeightSmall":
            $scope.gridOptions.paginationPageSize = $scope.gridOptions.paginationPageSizes[0];
            break;
          case "widgetHeightMedium":
            $scope.gridOptions.paginationPageSize = $scope.gridOptions.paginationPageSizes[1];
            break;
          case "widgetHeightLarge":
            $scope.gridOptions.paginationPageSize = $scope.gridOptions.paginationPageSizes[2];
            break;
          case "widgetHeightXlarge":
            $scope.gridOptions.paginationPageSize = $scope.gridOptions.paginationPageSizes[3];
            break;
          default:
            break;
        }
        $scope.paginationManual = true;
        $timeout($scope.setPaginationManually, 700);
      }
    });


    /* istanbul ignore next */
    $scope.areAllSelected = function () {
      var columnList = angular.element(document.getElementById('assignDocketColumns')).scope();
      for (var i = 0; i < columnList.updatedDocketColumnList.length; i++) {
        if (!columnList.updatedDocketColumnList[i].visible) {
          $scope.selectUnselect = false;
          break;
        } else {
          $scope.selectUnselect = true;
        }
        $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
      }
    };


    /* istanbul ignore next */
    $scope.updateColumns = function () {
      $scope.isLoading = true;
      var docketScopeList = angular.element(document.getElementById('assignDocketColumns')).scope();
      var columnsSelected = [];
      var fromModal = false;
      if (angular.isDefined(docketScopeList)) {
        columnsSelected = angular.copy(docketScopeList.selectedCols);
        angular.forEach(docketScopeList.availableCols, function (available) {
          columnsSelected.push(available);
        });
        fromModal = true;
      } else {
        columnsSelected = $scope.updatedDocketColumnList;
      }
      var updatedColumns = CommonHelperService.setColumnsToUpdate(columnsSelected, fromModal, $scope.gridState, $scope.widgetIdentifier);
      if (angular.isDefined(docketScopeList)) {
        docketScopeList.originalDocketAssignments = angular.copy(updatedColumns.selectedColumns);
      }
      HttpFactory.putActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS, updatedColumns)
        .then(function (successResponse) {
          CommonHelperService.setToastr(CONSTANTS.TOASTER.gridSave, "success");
          resetUnsavedChangesFlags();
          if (fromModal) {
            fromModal = false;
            var colDefs = [];
            angular.forEach(successResponse.config.data.selectedColumns, function (fetchedColumn) {
              var columnToBeAdded = {};
              if (!fetchedColumn.visible) {
                $scope.selectUnselect = false;
                $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
              }
              // Adding the column display name
              columnToBeAdded.displayName = fetchedColumn.columnLabel;
              // Checking if the field mapped to the column as an alias name
              if (fetchedColumn.columnName.length > 1) {
                columnToBeAdded.field = fetchedColumn.columnName[1];
              } else {
                columnToBeAdded.field = fetchedColumn.columnName[0];
              }
              // Setting column type
              columnToBeAdded.type = fetchedColumn.columnType;
              // Setting custom cell filter if one exists
              if (angular.isDefined(fetchedColumn.cellFilter)) {
                columnToBeAdded.cellFilter = fetchedColumn.cellFilter;
              }
              // Setting visibility of the column
              if (fetchedColumn.mandatory) {
                columnToBeAdded.visible = true;
                columnToBeAdded.enableHiding = false;
              } else {
                columnToBeAdded.visible = fetchedColumn.visible;
              }
              // Setting column width
              columnToBeAdded.width = fetchedColumn.width;
              // Setting custom template if one exists
              if (angular.isDefined(fetchedColumn.cellTemplate)) {
                columnToBeAdded.cellTemplate = fetchedColumn.cellTemplate;
              }
              // Setting sort properties on column
              columnToBeAdded.sort = fetchedColumn.sort;
              // Setting column filters
              columnToBeAdded.filters = fetchedColumn.filters;
              // Incrementing the filter flag
              if (columnToBeAdded.filters[0].term) {
                hasFilterFlag = hasFilterFlag + 1;
              }
              colDefs.push(columnToBeAdded);
            });
            $scope.numberOfFilters = hasFilterFlag;
            var allGrids = document.getElementsByClassName('ui-grid');
            for (var j = 0; j < allGrids.length; j++) {
              if (angular.element(allGrids[j]).scope().widgetIdentifier === $scope.widgetIdentifier) {
                updateColumnDefs(colDefs);
                angular.element(allGrids[j]).scope().gridOptions.columnDefs = $scope.gridOptions.columnDefs;
                if ($scope.numberOfFilters > 0) {
                  var filteredData = SearchHelperService.filterTable($scope.myData, colDefs);
                  $scope.gridOptions.data = filteredData ? filteredData : [];
                } else {

                  $scope.gridOptions.data = $scope.myData;
                }
                break;
              }
            }
            $rootScope.assignmentDocketColumnsChanged = false;
          } else {
            $scope.getAssignmentBasedDocket();
          }
        },
          function () {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.gridSaveFail, "error");
          })
        .finally(function () {
          $scope.isLoading = false;
        });
    };


    /* istanbul ignore next */
    $scope.exportData = function () {
      var dataToExport = [];
      if ($scope.gridOptions.data.length !== $scope.myData.length) {
        angular.forEach($scope.gridOptions.data, function (currentRow) {
          dataToExport.push(currentRow.ID);
        });
      }
      HttpFactory.exportFile($scope.VCDdataUrl, dataToExport)
        .then(function () {
          // intentional
        }, function () {
          // intentional
        });
    };


    $scope.pressEnter = function (event, searchText) {
      if (event.keyCode === 13) {
        $scope.simpleSearch(searchText);
      }
    };


    /* istanbul ignore next */
    function checkForUnsavedChanges() {
      if (!initialLoad) {
        if (isFilterChanged || isColumnVisibilityChanged || isColumnSizeChanged || isSortChanged || isColumnPositionChanged || isPaginationChanged || isColumnPinnedChanged) {
          $scope.assignmentDocketPreferencesChanged = true;
          $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_PREFERENCES;
        } else {
          $scope.assignmentDocketPreferencesChanged = false;
          $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
        }
      }
    }


    /* istanbul ignore next */
    $scope.refreshGrid = function () {
      $scope.assignmentDocketPreferencesChanged = false;
      $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
      $scope.isGridRefreshed = true;
      $scope.$$childTail.searchText = "";
      $scope.enableloading = true;
      $scope.refreashFaild = false;
      $scope.lastRefresh === undefined || null;
      if ($scope.advancedSearchFlag && $scope.enableAdvSearch()) {
        $scope.performAdvSearch();
      } else {
        $scope.getAssignmentBasedDocket();
      }

    };


    $scope.openAssignmentHistory = function (row) {
      $scope.assignData = row.entity;
      ngDialog.open({
        template: 'app/components/widgets/assignments/src/assignmnetHistory.html',
        controller: 'AssignmentHistoryController',
        controllerAs: 'vm',
        width: '80%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,
        resolve: {
          assignmentData: function () {
            return $scope.assignData;
          }
        }
      });
    };


    /* istanbul ignore next: toaster error */
    $scope.quickclose = function () {
      $scope.slectedrow = $scope.gridApi.selection.getSelectedRows();
      if ($scope.slectedrow.length === 0) {
        CommonHelperService.setToastr("", "clear");
        CommonHelperService.setToastr(CONSTANTS.TOASTER.selectRow, "error");
      } else {
        vm.getAssignmentById($scope.slectedrow[0].assignmentIdentifier).then(function () {
          $scope.quickupdateAssignmntdata = {
            "assignmentType": $scope.itemsSelected[0].assignmentType,
            "assignee": $scope.itemsSelected[0].assignee,
            "serialNumber": $scope.itemsSelected[0].serialNumber,
            "title": $scope.itemsSelected[0].title,
            "description": $scope.itemsSelected[0].description,
            "dueDate": $scope.itemsSelected[0].dueDate,
            "completionDate": new Date().getTime(),
            "caseType": $scope.itemsSelected[0].caseType,
            "appealNumber": $scope.itemsSelected[0].appealNumber,
            "sequenceNumber": $scope.itemsSelected[0].sequenceNumber,
            "notes": $scope.itemsSelected[0].notes,
            "assigneeRoleDescription": $scope.itemsSelected[0].assigneeRoleDescription,
            "priorityIndicator": $scope.itemsSelected[0].priorityIndicator,
            "assignmentIdentifier": $scope.itemsSelected[0].assignmentIdentifier,
            "assignor": $scope.itemsSelected[0].assignor,
            "activeIndicator": $scope.itemsSelected[0].activeIndicator,
            "audit": {
              "createUserIdentifier": $scope.itemsSelected[0].audit.createUserIdentifier,
              "lastModifiedUserIdentifier": $rootScope.userInfo.userId,
              "lockControlNumber": $scope.itemsSelected[0].audit.lockControlNumber,
              "createTimestamp": $scope.itemsSelected[0].audit.createTimestamp,
              "lastModifiedTimestamp": new Date().getTime()
            }
          };
          $scope.quickupdate($scope.quickupdateAssignmntdata);
        });
      }
    };


    /* istanbul ignore next: toaster error */
    $scope.quickupdate = function (data) {
      HttpFactory.putActions(CONSTANTS.URL.UPDATE_ASSIGNMENT, data)
        .then(function () {
          CommonHelperService.setToastr("", "clear");
          CommonHelperService.setToastr(CONSTANTS.TOASTER.updateSuccess, "success");
          $scope.getAssignmentBasedDocket();
        }, function (failureResponse) {
          if (failureResponse.status === 404) {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(failureResponse.data.message, "warning");
          } else {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.updateFail, "error");
          }
        });
    };


    $scope.searchData = true;
    $scope.advancedSearch = function () {
      $scope.isLoading = true;
      $scope.resetAdvancedSearch();
      $scope.searchData = false;
      $scope.getAssingnmentTypes();
      $scope.getTeamMembers();
      $scope.getAssingnmentStatus();
      $scope.getAssingnmentCaseTypes();
    };
    $scope.buttonData = false;


    /* istanbul ignore next */
    angular.element($window).on('resize', function () {
      if ($window.innerWidth <= 991) {
        $scope.buttonData = true;
      } else {
        $scope.buttonData = false;
      }
    });


    $scope.getAssingnmentTypes = function () {
      HttpFactory.getActions(CONSTANTS.URL.STND_ASSIGNMENT_TYPE)
        .then(function (successResponse) {
          $scope.stndAssignmentTypes = successResponse.data;
          $scope.assignmentTypeList = angular.copy(successResponse.data);
          var noneSelectedObject = {
            value: "",
            displayName: "No type selected"
          };
          $scope.assignmentTypeList.unshift(noneSelectedObject);
          $scope.assignmentTypePlaceholder = "No type selected";
          var noneSelectedObject = {
            value: "",
            displayName: "No type selected"
          };
          $scope.selectedAssignmentType = noneSelectedObject;

        },
          function (failureResponse) {
            $log.debug(failureResponse);
          });
    };


    $scope.getTeamMembers = function () {
      HttpFactory.getActions(CONSTANTS.URL.ASSIGNEEUSERS + $rootScope.userInfo.userId)
        .then(function (successResponse) {
          $scope.teammates = [];
          $scope.role = $rootScope.userInfo.roleDescription;
          if ($scope.role === "Supervisor") {
            $scope.leadRole = "All Paralegal  users";
          } else if ($scope.role === "Patent Attorney") {
            $scope.leadRole = "All Patent Attorney users";
          } else if ($scope.role === "Judge") {
            $scope.leadRole = "All Judge users";
          } else if ($scope.role === "Business Administrator") {
            $scope.leadRole = "All paralegals, all PAs, all judges";
          }
          if (successResponse.data.groupData && successResponse.data.groupData.length > 0) {

            $scope.teammates = successResponse.data.groupData;
          }
          if (successResponse.data.teamData && successResponse.data.teamData.length > 0) {
            angular.forEach(successResponse.data.teamData, function (item) {
              $scope.teammates.push(item);
            });
          }

          var sortedList = $scope.teammates.sort(function (a, b) {
            if (a.assigneeFullNameText < b.assigneeFullNameText) {
              return -1;
            }
            if (a.assigneeFullNameText > b.assigneeFullNameText) {
              return 1;
            }
            return 0;
          });
          $scope.teammates = sortedList;
        },
          function (failureResponse) {
            $log.debug(failureResponse);
          });
    };


    $scope.getAssingnmentCaseTypes = function () {
      HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTS_CASE_TYPES)
        .then(function (successResponse) {
          $scope.casetypes = successResponse.data;
        },
          function (failureResponse) {
            $scope.casetypes = [];
            $log.debug(failureResponse);
          });
    };


    $scope.getAssingnmentStatus = function () {
      HttpFactory.getActions(CONSTANTS.URL.STND_ASSIGNMENT_STATUS)
        .then(function (successResponse) {
          $scope.stndAssignmentStatus = successResponse.data;


        },
          function (failureResponse) {
            $log.debug(failureResponse);
          });
    };
    $scope.advancedSearchObj = {};
    $scope.diasbleAdvancedSearch = true;

    $scope.timedEnableAdvSearch = function () {
      $timeout(function () {
        $scope.enableAdvSearch();
      }, 400);
    };
    $scope.enableAdvSearch = function () {
      $scope.diasbleAdvancedSearch = true;
      if ((angular.isDefined($scope.advancedSearchObj.selectedType) &&
        $scope.advancedSearchObj.selectedType !== "") ||
        (angular.isDefined($scope.advancedSearchObj.selectedStatus) &&
          $scope.advancedSearchObj.selectedStatus !== "") ||
        (angular.isDefined($scope.advancedSearchObj.selectedCaseType) &&
          $scope.advancedSearchObj.selectedCaseType !== "") ||
        angular.isDefined($scope.advancedSearchObj.startDate) &&
        $scope.advancedSearchObj.startDate !== "" ||
        angular.isDefined($scope.advancedSearchObj.endDate) &&
        $scope.advancedSearchObj.endDate !== "" ||
        (angular.isDefined($scope.advancedSearchObj.selectedMember) &&
          $scope.advancedSearchObj.selectedMember !== "") ||
        (angular.isDefined($scope.advancedSearchObj.selectedCaseStatus) &&
          $scope.advancedSearchObj.selectedCaseStatus !== "")) {
        $scope.diasbleAdvancedSearch = false;
      }
      return !$scope.diasbleAdvancedSearch;
    };


    /* istanbul ignore next */
    $scope.download_csv_MxdCaseDkt = function () {
      var headers = [];
      angular.forEach($scope.columnsDataMxdDocket, function (coldata) {
        headers.push(coldata.columnLabel);
      });
      var fields = [];
      angular.forEach($scope.columnsDataMxdDocket, function (coldata) {
        fields.push([coldata.columnName[0], coldata.columnType]);
      });
      var replacer = function (key, value) {
        return value === null ? '' : value;
      };
      var csv = $scope.myData.map(function (row) {
        return fields.map(function (fieldName) {
          if (fieldName[1] === 'date') {
            if (fieldName[0] === 'LAST_MODIFIED_TS') {
              return " " + $filter('date')(row["assignmentLastModifiedTs"], 'MM/dd/yyyy hh:mm:ss a') + " ";
            } else if (row[fieldName[0]]) {
              return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy') + " ";
            } else {
              return "";
            }
          } else if (fieldName[0] === 'assigneeHistory') {
            return "";
          } else if (fieldName[0] === "ADDITIONAL_APJ_WORKER_ID_TX") {
            return JSON.stringify(setPanelColumnForExport(row));
          } else if (fieldName[0] === "APJ1_WORKER_ID") {
            return JSON.stringify(row["appealPanelJudgeOne"], replacer);
          } else if (fieldName[0] === "APJ2_WORKER_ID") {
            return JSON.stringify(row["appealPanelJudgeTwo"], replacer);
          } else if (fieldName[0] === "APJ3_WORKER_ID") {
            return JSON.stringify(row["appealPanelJudgeThree"], replacer);
          } else if (fieldName[0] === 'FK_ASSIGNMENT_STATUS_CD') {
            return row['FK_ASSIGNMENT_STATUS_CD'] === 'A' ? "Open" : "Closed";
          } else {
            return JSON.stringify(row[fieldName[0]], replacer);
          }
        }).join(',');
      });
      csv.unshift(headers.join(','));
      csv = csv.join('\r\n');
      var hiddenElement = document.createElement('a');
      hiddenElement.href = URL.createObjectURL(new Blob([csv], {
        type: 'text/csv'
      }));
      hiddenElement.target = '_blank';
      hiddenElement.download = 'Assignment docket ' + CommonHelperService.getCurrentTime() + '.csv';
      hiddenElement.click();
    };


    $scope.resetAdvancedSearch = function () {
      advancedSearchOcurred = false;
      $scope.advancedSearchObj = {};
      $scope.enableAdvSearch();
      $scope.getAssignmentBasedDocket();
    };


    $scope.onKeyup = function (url, advancedSearchFlag, $event) {
      if ($event.keyCode === 13) {
        $scope.setUrl(url, advancedSearchFlag);
      }
    };

    $scope.enterOnActions = function ($event, functionToInvoke) {
      if ($event.keyCode === 13 && functionToInvoke) {
        $scope[functionToInvoke]();
      }
    };


    /* istanbul ignore next: toaster error*/
    $scope.bulkReassign = function () {
      var userId = $window.sessionStorage.getItem("workerNumber");
      ngDialog.open({
        template: "app/components/widgets/assignments/src/reassignmentModal.html",
        controller: 'ReassignmentModalController',
        controllerAs: 'vm',
        scope: $scope,
        width: '52%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,
        resolve: {
          userId: function () {
            return userId;
          },
          assignmentRows: function () {
            return $scope.selectedRows;
          }
        }
      }).closePromise.then(function (responseData) {
        var successResponse = responseData.value;
        $scope.assignmentsData = successResponse.data;
        var verb = " assignments have ";
        if ($scope.selectedRows.length - $scope.assignmentsData.length === 1) {
          verb = " assignment has ";
        }
        if ($scope.assignmentsData.length === 0) {
          CommonHelperService.setToastr($scope.selectedRows.length + verb + " been successfully reassigned.", "success");
        } else if ($scope.selectedRows.length === $scope.assignmentsData.length) {
          CommonHelperService.setToastr(CONSTANTS.TOASTER.reassignFail, "error");
          return;
        } else {
          CommonHelperService.setToastr($scope.selectedRows.length - $scope.assignmentsData.length + verb +
            "been successfully reassigned.  " + $scope.assignmentsData.length + " assignment(s) failed to be reassigned.", "warning");
        }
        vm.failedReassignments = angular.copy($scope.assignmentsData);
        $scope.refreshGrid();
        $scope.$$childTail.$$prevSibling.searchText = undefined;
      }, function () {
        // intentional
      });
    };

    GET_UPDATE_EWF_id();
    function GET_UPDATE_EWF_id() {
      HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTS_UPDATE_EWF)
      .then(function (successResponse) {
        var assignments = successResponse.data;
        console.log(assignments);
        angular.forEach(assignments, function(valueRow) {
          if (valueRow.valueText==="UPDATE_EWF") {
            vm.assignmentTypeId = valueRow.descriptionText;
          }
          if (valueRow.valueText==="RESET_ASSIGNMENTS") {
            vm.resetAssignmentTypeId = valueRow.descriptionText;
          }
          if (valueRow.valueText==="RESET_CIRC_ASSIGNMENTS") {
            vm.resetCircAssignmentTypeId = valueRow.descriptionText;
          }
        });
      }, function (failureResponse) {

      });
    }

    $scope.checkFileTypes = function () {
      vm.checkFlag = true;
      for(var i=0;i<$scope.selectedRows.length;i++){
        if ($scope.selectedRows[i].FK_ASSIGNMENT_TYPE_ID != vm.assignmentTypeId) {
          vm.checkFlag = false;
          CommonHelperService.setToastr("Please select Update eWF assignments only", "error");
          break;
        }
      }
      if(vm.checkFlag){
        bulkComplete('bulkComplete');
      }
    }

    $scope.resetAssignment = function () {
      vm.restCheckFlag = true;
      vm.resetCircAssigncheckFlag = false;
      vm.resetAssignmentTypeIdList = vm.resetAssignmentTypeId.split('~');
      vm.resetCircAssignmentTypeIdList = vm.resetCircAssignmentTypeId.split('~');
      for (var i = 0; i < $scope.selectedRows.length; i++) {
        if (vm.resetCircAssignmentTypeIdList.indexOf($scope.selectedRows[i].FK_ASSIGNMENT_TYPE_ID.toString()) != -1) {
          vm.resetCircAssigncheckFlag = true;
          break;
        }
        else {
          vm.resetCircAssigncheckFlag = false;
        }
      }
      if(vm.resetCircAssigncheckFlag){
        getCirculationId($scope.selectedRows[i]);
      }
      if(!vm.resetCircAssigncheckFlag) {
        for (var i = 0; i < $scope.selectedRows.length; i++) {
          if (vm.resetAssignmentTypeIdList.indexOf($scope.selectedRows[i].FK_ASSIGNMENT_TYPE_ID.toString()) != -1) {
            vm.restCheckFlag = true;
          }
          else{
            vm.restCheckFlag = false;
            CommonHelperService.setToastr("This function is only available for certain completed assignment types.", "error");
            break;
          }
        }
        if (vm.restCheckFlag) {
          bulkComplete('reset');
        }
      }      
    }

    function getCirculationId(rowData) {
      HttpFactory.getActions(CONSTANTS.URL.GET_CIRCULATION_DETAILS + rowData.FK_AD_FK_APPEAL_NO + '&serialNumber=' + rowData.FK_AD_FK_AA_SERIAL_NO + '&userId=' + $rootScope.userInfo.userId)
        .then(function (successResponse) {
          try {
            vm.circulationIdentifier = successResponse.data.circulationIdentifier;
            var obj = {
              "circulationIdentifier":vm.circulationIdentifier,
              "serialNumber": rowData.FK_AD_FK_AA_SERIAL_NO,
              "appealNumber": rowData.FK_AD_FK_APPEAL_NO,
              "circulationTypeCode": "PANEL",
              "audit":{
                "createUserIdentifier": $rootScope.userInfo.userId,
                "lastModifiedUserIdentifier": $rootScope.userInfo.userId
              }
            }
            HttpFactory.putActions("/circulation/cancelCirculationInitiation", obj)
              .then(function (successResponse) {
              CommonHelperService.setToastr("Successfully reset the assignment(s)", "success");
              $scope.getAssignmentBasedDocket();
              });
          } catch (error) {
            console.error(error);
          }
        });
    }



        /* istanbul ignore next: toaster error*/
        function bulkComplete(val) {
          var reAssignDataArray = [];
          $scope.selectedRows.forEach(function (item) {
            if (vm.useExisting) {
              vm.dueDte = null;
            } else {
              vm.dueDte = new Date(vm.reassignDueDate).getTime();
            }
            var reAssignObject = {
              "assignee": item.FK_ASSIGNEE_BE_NO,
              "serialNumber": item.FK_AD_FK_AA_SERIAL_NO,
              "title": item.TASK_TITLE_TX,
              "description": item.TASK_DESC_TX,
              "dueDate": item.ASSIGNMENT_DUE_DT,
              "assignedDate": item.ASSIGNED_DT,
              "completionDate": val == 'reset' ? null : item.COMPLETION_DT,
              "appealNumber": item.FK_AD_FK_APPEAL_NO,
              "notes": item.COMMENT_TX,
              "priorityIndicator": item.PRIORITY_IN,
              "assignmentIdentifier": item.assignmentIdentifier,
              "assignmentTypeIdentifier": item.FK_ASSIGNMENT_TYPE_ID,
              "pageNumberQuantity": item.PAGE_COUNT_QT,
  
              "assignor": $rootScope.userInfo.userId,
              "activeIndicator": item.FK_ASSIGNMENT_STATUS_CD,
              "reassignDueDate": vm.dueDte,
              "audit": {
                "createUserIdentifier": item.CREATOR_USER_ID,
                "lastModifiedUserIdentifier": $rootScope.userInfo.userId,
                "lockControlNumber": item.LOCK_CONTROL_NO,
                "lastModifiedTimestamp": new Date().getTime()
              }
            };
            reAssignDataArray.push(reAssignObject);
          });
          if(val == 'bulkComplete'){
            HttpFactory.putActions(CONSTANTS.URL.CLOSE_UPDATE_EWF, reAssignDataArray)
            .then(function (successResponse) {
              CommonHelperService.setToastr("Successfully closed the assignment(s)", "success");
              $scope.getAssignmentBasedDocket();
            }, function (failureResponse) {              
              CommonHelperService.setToastr(CONSTANTS.TOASTER.reassign, "error");
            });
          }
          if(val == 'reset'){
            HttpFactory.putActions(CONSTANTS.URL.RESET_ASSIGNMENTS, reAssignDataArray)
            .then(function (successResponse) {
                CommonHelperService.setToastr("Successfully reset the assignment(s)", "success");
              $scope.getAssignmentBasedDocket();
            }, function (failureResponse) {              
              CommonHelperService.setToastr(CONSTANTS.TOASTER.reassign, "error");
            });
          }
        }

    $scope.assignmentListEnterKey = function (event, assignmentDisplayName) {
      if (event.keyCode === 13) {
        if ($scope.assignmentTypeList.length > 0) {
          $scope.setSelectedJudge($scope.assignmentTypeList[0]);
        }
      }
    };

    $scope.showJudgeList = function () {
      if ($scope.assignmentTypePlaceholder === 'Loading types...') {
        return;
      }
      if (!$scope.judgeListVisible) {
        $scope.judgeListVisible = !$scope.judgeListVisible;
      }
    };

    $scope.setSelectedJudge = function (judge) {
      if (judge.displayName !== "No type selected") {
        $scope.selectedAssignmentType = judge;
        $scope.advancedSearchObj.selectedType = judge.assignmentTypeCode;
        $scope.enableAdvSearch();
      } else {
        $scope.selectedAssignmentType = {};
        $scope.advancedSearchObj.selectedType = '';
        $scope.enableAdvSearch();
      }
      $scope.judgeListVisible = false;
    };

    $scope.searchForJudge = function (input) {
      $scope.judgeListVisible = true;
      $scope.enableAdvSearch();
      var tempList = [];
      if (angular.isDefined(input) && input.displayName.trim() !== "") {
        angular.forEach($scope.stndAssignmentTypes, function (currentJudge) {
          if (currentJudge.displayName.toLowerCase().includes(input.displayName.toLowerCase())) {
            tempList.push(currentJudge);
          }
        });
        $scope.assignmentTypeList = angular.copy(tempList);
      } else {
        $scope.assignmentTypeList = angular.copy($scope.stndAssignmentTypes);
        var noneSelectedObject = {
          value: "",
          displayName: "No type selected"
        };
        $scope.assignmentTypeList.unshift(noneSelectedObject);
      }
    };

    $scope.performAdvSearch = function () {
      advancedSearchOcurred = true;
      $scope.judgeListVisible = false;
      $scope.enableloading = true;
      $scope.isLoading = true;
      $log.debug($scope.advancedSearchObj);

      var serachUrl = CONSTANTS.URL.ASSIGNMENT_DOCKET_ADV_SEARCH + $scope.widgetIdentifier;
      if (angular.isDefined($scope.advancedSearchObj.selectedType) && $scope.advancedSearchObj.selectedType !== "") {
        serachUrl = serachUrl + '&assignmentTypeCode=' + $scope.advancedSearchObj.selectedType;
      }
      if (angular.isDefined($scope.advancedSearchObj.selectedStatus) && $scope.advancedSearchObj.selectedStatus !== "" && $scope.advancedSearchObj.selectedStatus !== "DEFAULT") {
        serachUrl = serachUrl + '&assignmentStatusCode=' + $scope.advancedSearchObj.selectedStatus;
      }
      if (angular.isDefined($scope.advancedSearchObj.selectedCaseStatus) && $scope.advancedSearchObj.selectedCaseStatus !== "" && $scope.advancedSearchObj.selectedCaseStatus !== "DEFAULT") {
        var statusCode = $scope.advancedSearchObj.selectedCaseStatus === 'A' ? 'ACTIVE' : 'CLOSED';
        var assignmentStatusCode = $scope.advancedSearchObj.selectedCaseStatus;
        serachUrl = serachUrl + '&caseStatus=' + statusCode + '&assignmentStatusCode=' + assignmentStatusCode;
      }
      if (angular.isDefined($scope.advancedSearchObj.selectedCaseType) && $scope.advancedSearchObj.selectedCaseType !== "") {
        serachUrl = serachUrl + '&caseType=' + $scope.advancedSearchObj.selectedCaseType;
      }
      if (angular.isDefined($scope.advancedSearchObj.selectedMember) && $scope.advancedSearchObj.selectedMember !== "") {
        var memberList = [];
        memberList.push($scope.advancedSearchObj.selectedMember);
        serachUrl = serachUrl + '&assigneeNumbers=' + memberList;
      }
      if (angular.isDefined($scope.advancedSearchObj.startDate) && $scope.advancedSearchObj.startDate !== "") {
        serachUrl = serachUrl + '&startDate=' + new Date($scope.advancedSearchObj.startDate).getTime();
      }
      if (angular.isDefined($scope.advancedSearchObj.endDate) && $scope.advancedSearchObj.endDate !== "") {
        serachUrl = serachUrl + '&endDate=' + new Date($scope.advancedSearchObj.endDate).getTime();
      }
      $log.debug(serachUrl);
      /* istanbul ignore next */
      HttpFactory.getActions(serachUrl)
        .then(function (successResponse) {
          $scope.enableloading = false;
          $scope.$$childTail.$$prevSibling.searchText = undefined;
          $scope.gridApi.grid.clearAllFilters();
          if (!successResponse.data.assignmentsData) {
            setNoResults();
            return;
          }
          $scope.myData = successResponse.data.assignmentsData;
          $scope.originalData = successResponse.data.assignmentsData;
          $scope.gridOptions.data = $scope.myData;
          $scope.isLoading = false;
        },
          function (failureResponse) {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(failureResponse.data.message, "error");
            $scope.gridOptions.data = [];
            $scope.myData = [];
            $scope.originalData = [];
            $log.debug(failureResponse);
            $scope.isLoading = false;
            $scope.enableloading = false;
          });
      $scope.nullvalue = null;
    };

    function setNoResults() {
      CommonHelperService.setToastr("", "clear");
      CommonHelperService.setToastr(CONSTANTS.TOASTER.noResults, "error");
      $scope.gridOptions.data = [];
      $scope.myData = [];
      $scope.originalData = [];

      $scope.isLoading = false;
      $scope.enableloading = false;
    }

    $scope.showPopover = function () {
      $scope.popoverVisible = !$scope.popoverVisible;
      $scope.assignorListVisible = false;
    };

    $scope.showAssignorList = function () {
      if (!$scope.assignorListVisible) {
        $scope.assignorListVisible = !$scope.assignorListVisible;
        $scope.popoverVisible = false;
      }
    };

    $scope.searchForAssignor = function (input) {
      var tempList = [];
      if (angular.isDefined(input) && input.fullName.trim() !== "") {
        angular.forEach($scope.originalAssignorList, function (currentAssignor) {
          if (currentAssignor.assigneeFullNameText.toLowerCase().includes(input.fullName.toLowerCase())) {
            tempList.push(currentAssignor);
          }
        });
        $scope.assignorList = angular.copy(tempList);
      } else {
        $scope.assignorList = angular.copy($scope.originalAssignorList);
      }
    };

    $scope.getAssignorList = function () {
      HttpFactory.getActions("/user-management/users?roleCode=Supervisor")
        .then(function (response) {
          var assignorList = [];
          assignorList = response;
          $scope.assignorList = assignorList;
          var defaultOption = [
            {
              assigneeNumberText: "",
              assigneeFullNameText: "All",
              assigneeStatus: "",
              activeCaseCount: ""
            }
          ];
          $scope.assignorList = defaultOption.concat(assignorList.data);
          $scope.originalAssignorList = angular.copy($scope.assignorList);
          $scope.selectedAssignor = $scope.assignorList[0];
        }, function (judgeListFailure) {
          console.log(judgeListFailure);
        });
    };

    $scope.getAssignorList();

    $scope.setSelectedAssignor = function (assignor) {

      if (fullSelectedList.indexOf(assignor.assigneeFullNameText) == -1) {
        assignor.checked = true;
        if (assignor.assigneeFullNameText == "All") {
          $scope.setSelectAll();
        }
      }
      else {
        assignor.checked = false;
        if (assignor.assigneeFullNameText == "All") {
          $scope.setUnSelectAll();
        }
      }

      if (assignor.assigneeFullNameText != "All") {
        if (assignor.checked) {
          fullSelectedList.push(assignor.assigneeFullNameText);
          $scope.assignorCount = $scope.assignorCount + 1;
        } else {
          var index = fullSelectedList.indexOf(assignor.assigneeFullNameText);
          fullSelectedList.splice(index, 1);
          $scope.assignorCount = $scope.assignorCount - 1;
        }
        $scope.fullSelectedListText = "";
        angular.forEach(fullSelectedList, function (value) {
          if ($scope.fullSelectedListText == "") {
            $scope.fullSelectedListText = value;
          }
          else {
            $scope.fullSelectedListText = $scope.fullSelectedListText + " | " + value;
          }
        });
      }
    };

    $scope.setSelectAll = function () {
      angular.forEach($scope.assignorList, function (value) {
        value.checked = true;
      })
      fullSelectedList.push("All");
      $scope.fullSelectedListText = "All";
      $scope.assignorCount = $scope.assignorList.length - 1;
    }

    $scope.setUnSelectAll = function () {
      angular.forEach($scope.assignorList, function (value) {
        value.checked = false;
      })
      fullSelectedList=[];
      $scope.fullSelectedListText = "";
      $scope.assignorCount = 0;
    }

    $scope.getAssignmentBasedOnAssignors = function () {
      $scope.enableloading = true;
      $scope.refreashFaild = false;
      $scope.isLoading = true;
      $scope.gridIsLoading = true;
      var assigneeNumbers="";
      $scope.assignorListVisible = false;
      angular.forEach(fullSelectedList, function (selectedValue) {
        angular.forEach($scope.assignorList, function (value) {
          if(selectedValue == value.assigneeFullNameText){
            if (assigneeNumbers == "") {
              assigneeNumbers = value.assigneeNumberText;
            }
            else {
              assigneeNumbers = assigneeNumbers + "," + value.assigneeNumberText;
            }
          }
        })
      })
      if(fullSelectedList[0]=="All"){
        angular.forEach($scope.assignorList, function (value) {
            assigneeNumbers = assigneeNumbers + "," + value.assigneeNumberText;
        })
        assigneeNumbers = assigneeNumbers.substring(2);
      }
      if ($scope.myGroupFlag) {
        $scope.url = "/mixed-case-dockets/team-group?assigneeNumbers="+assigneeNumbers+"&widgetId="+ $scope.widgetIdentifier;
      }
      if($scope.myTeamFlag){
        $scope.url = "/mixed-case-dockets/team-group?assigneeNumbers="+assigneeNumbers+"&widgetId="+ $scope.widgetIdentifier+"&hierarchy=TEAM";
      }
      HttpFactory.getActions($scope.url)
        .then(function (successResponse) {
          console.log(successResponse);
          if (advancedSearchOcurred) {
            return;
          }
          $scope.enableloading = false;
          $scope.refreashFaild = false;
          $scope.lastRefresh = new Date();
          $scope.dateValid = false;
          if (angular.isDefined(successResponse.data)) {
            $scope.myData = successResponse.data.assignmentsData;
            $scope.columnsDataMxdDocket = successResponse.data.columnsData;
            $scope.selectedCols = [];
            $scope.availableCols = [];
            angular.forEach($scope.columnsDataMxdDocket, function (thisColumn) {
              if (thisColumn.visible) {
                $scope.selectedCols.push(thisColumn);
              } else {
                $scope.availableCols.push(thisColumn);
              }
            });
            $scope.originalData = angular.copy($scope.myData);
            $scope.updatedDocketColumnList = successResponse.data.columnsData;
            $scope.originalDocketAssignments = angular.copy($scope.updatedDocketColumnList);
            var setColumnsResponse = CommonHelperService.setColumnDefinitions($scope.updatedDocketColumnList);
            $scope.selectUnselect = setColumnsResponse.selectUnselect;
            $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
            hasFilterFlag = setColumnsResponse.filterCount;
            updateColumnDefs(setColumnsResponse.colDefs);
            $scope.gridOptions.paginationPageSize = successResponse.data.paginationSize !== undefined ? successResponse.data.paginationSize : 25;
            if (hasFilterFlag > 0) {
              $scope.numberOfFilters = hasFilterFlag;
              var filteredData = SearchHelperService.filterTable($scope.myData, setColumnsResponse.colDefs);
              $timeout(function () {
                $scope.gridOptions.data = filteredData ? filteredData : [];
                $scope.savedFilteredData = filteredData ? filteredData : [];
              }, 200);
            } else {
              $scope.numberOfFilters = 0;
              if ($scope.myData) {
                $timeout(function () {
                  $scope.gridOptions.data = $scope.myData;
                }, 200);
              } else {
                $scope.gridOptions.data = [];
              }
            }
            $scope.isLoading = false;
            $scope.assignmentDocketPreferencesChanged = false;
            $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
            $timeout($scope.setPaginationManually, 700);
            $scope.noRecordsFound = false;
            $timeout(function () {
              initialLoad = false;
            }, 2000);
            if ($scope.isGridRefreshed) {
              CommonHelperService.setToastr(CONSTANTS.TOASTER.refreshData, "success");
            }
            $scope.gridIsLoading = false;
          }
        }, function (failureResponse) {
          $scope.gridOptions.data = [];
          $scope.myData = [];
          $scope.refreashFaild = true;
          $scope.refreashFailDate = new Date();
          if (angular.isUndefined($scope.lastRefresh) || $scope.lastRefresh === null) {
            $scope.dateValid = true;
          }
          CommonHelperService.setToastr(failureResponse.data.message, "info");
          $scope.isLoading = false;
          $scope.enableloading = false;
          $scope.dateValid = true;
          $scope.gridOptions.data = [];
        });
    };

  window.addEventListener('click', function(e){   
    if (document.getElementById('customDropDown') && document.getElementById('customDropDown').contains(e.target)){
      return;
    } else{
      $scope.assignorListVisible=false;
    }
  });


  });
