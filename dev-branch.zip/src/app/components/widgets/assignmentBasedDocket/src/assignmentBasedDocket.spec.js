(function () {
  'use strict';

  describe('AssignmentBasedDocketController', function () {

    beforeEach(module('ptabe2e'));

    var vm = this;
    var scope;
    var controller, $controller;
    var $http, $interval, $log, $rootScope, spy, row, url, advancedSearchFlag;
    var $q, HttpFactoryDeferred, timeout, row, rowRenderIndex, col;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close', 'open']);
    var successResponse = {
      data: [{
        events: {},
        refreshInterval: 0,
        descriptionText: "CDDD"
      }]
    };

    var failureResponse = '';


    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              getWidgetZone: function () {

              },
              setWidgetContentHeight: function () {

              }
            }
          }
        },

        on: function () {

        }

      }
    };
    var fakeVm = {
      getWidgetZone: function () {

      },
      setWidgetContentHeight: function () {

      }
    };

    var refreshGrid = {
      value: "data"
    }

    beforeEach(inject(function (_$controller_, _$http_, _$rootScope_, _$timeout_, _$interval_, $compile, _$q_, HttpFactory, CONSTANTS) {
      $q = _$q_;
      $http = _$http_;
      scope = _$rootScope_.$new();
      $interval = _$interval_;
      $rootScope = _$rootScope_;
      timeout = _$timeout_;

      $rootScope.userInfo = {
        "userId": "pgandhi"
      }

      // setup the promise
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);

      $controller = _$controller_;

      scope.definition = {
        dataUrlText: 'http://localhost:8080/PTABServices/',
        widgetIdentifier: 12
      }

      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback1, callback2) {
            callback1(refreshGrid);
            callback2();
          }
        },
        then: function (callback3, callback4) {
          callback3();
          callback4();
        }
      });

      spy = spyOn(angular, 'element').and.callFake(fakeElement);


      scope.$parent = {
        $parent: {
          $parent: {
            definition: {
              zoneWidth: 12
            }
          }
        }
      }

      controller = $controller('AssignmentBasedDocketController', {
        $http: $http,
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        $interval: $interval,
        HttpFactory: HttpFactory

      });

      // spyOn($rootScope, '$on').and.callThrough();
    }));


    afterEach(function () {
      spy.and.callThrough();
    });


    describe('check functions', function () {

      it(' should call openAssignmentDialog ', function () {
        scope.data = {
          "beNo": "5768"
        }

        expect(scope['openAssignmentDialog']).toBeDefined();
        // expect(ngDialog.open).toBeDefined();
        scope.openAssignmentDialog();

        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(1);
        var args = ngDialog.open.calls.argsFor(0);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('CreateAssignmentController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.newData();
      });

      it(' should call setUrl', function () {
        url = "https://ptab-q318-services-eap-0.sit.uspto.gov:8443/PTABAppeals/#/", advancedSearchFlag = true;
        expect(scope['setUrl']).toBeDefined();
        scope.setUrl(url, advancedSearchFlag);
      });

      it(' should call setUrl', function () {
        url = "https://ptab-q318-services-eap-0.sit.uspto.gov:8443/PTABAppeals/#/", advancedSearchFlag = false;
        expect(scope['setUrl']).toBeDefined();
        scope.setUrl(url, advancedSearchFlag);
      });

      it(' should call getAssignmentBasedDocket ', function () {

        successResponse = {
          data: [{
            "columnsData": [{
                "columnName": [
                  "alert"
                ],
                "columnLabel": "Alerts",
                "columnType": "string",
                "defaultOrder": "asc",
                "visible": false,
                "mandatory": true,
                "width": 95,
                "sort": {},
                "filters": [{}]
              },
              {
                "columnName": [
                  "assigneeBeName"
                ],
                "tableName": "assigneeBeName",
                "columnLabel": "Assignment due date",
                "columnType": "date",
                "defaultOrder": "asc",
                "visible": true,
                "mandatory": true,
                "width": "200",
                "sort": {},
                "filters": [{}]
              },
              {
                "columnName": [
                  "TASK_TITLE_TX"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Assignment title",
                "columnType": "string",
                "defaultOrder": "asc",
                "visible": true,
                "mandatory": true,
                "width": 200,
                "sort": {},
                "filters": [{}]
              },
              {
                "columnName": [
                  "FK_AD_FK_APPEAL_NO"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Case #",
                "columnType": "number",
                "defaultOrder": "asc",
                "visible": true,
                "mandatory": true,
                "width": 200,
                "sort": {},
                "filters": [{}]
              },
              {
                "columnName": [
                  "FK_AD_FK_AA_SERIAL_NO"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Application #",
                "columnType": "string",
                "defaultOrder": "asc",
                "visible": true,
                "mandatory": false,
                "width": 200,
                "sort": {},
                "filters": [{}]
              },
              {
                "columnName": [
                  "assigneeHistory"
                ],
                "tableName": "assigneeHistory",
                "columnLabel": "Task description",
                "columnType": "string",
                "defaultOrder": "asc",
                "visible": true,
                "mandatory": false,
                "width": 200,
                "sort": {},
                "filters": [{}]
              },
              {
                columnName: [
                  "CREATE_TS"
                ],
                aliasName: "assignmentCreateTs",
                tableName: "PTAB_ASSIGNMENT",
                columnLabel: "Creation time",
                columnType: "date",
                defaultOrder: "asc",
                visible: true,
                mandatory: false,
                width: 200,
                sort: {},
                filters: [{}],
              },
              {
                columnName: [
                  "TASK_CREATED_TS"
                ],
                tableName: "PTAB_ASSIGNMENT",
                columnLabel: "Task creation timestamp",
                columnType: "date",
                defaultOrder: "asc",
                visible: true,
                mandatory: false,
                width: 200,
                sort: {},
                filters: [{}],
              },
              {
                columnName: [
                  "LAST_MODIFIED_TS"
                ],
                aliasName: "assignmentLastModifiedTs",
                tableName: "PTAB_ASSIGNMENT",
                columnLabel: "Last modified time",
                columnType: "date",
                defaultOrder: "asc",
                visible: true,
                mandatory: false,
                width: 200,
                sort: {},
                filters: [{}],
              },
              {
                columnName: [
                  "ASSIGNMENT_DUE_DT"
                ],
                tableName: "PTAB_ASSIGNMENT",
                columnLabel: "Due date",
                columnType: "date",
                defaultOrder: "asc",
                visible: true,
                mandatory: true,
                width: 200,
                sort: {},
                filters: [{}],
              },
            ],
            "assignmentsData": [{
              "FK_ASSIGNOR_BE_NO": "5768",
              "PTAB_ASSIGNMENT_ID": 2226,
              "FK_ASSIGNMENT_TYPE_CD": "AFLC",
              "DECISION_DUE_DT": null,
              "ASSIGNED_DT": 1537545818000,
              "COMMENT_TX": "fgghg",
              "assignmentLockControlNo": 0,
              "FK_ASSIGNEE_BE_NO": "5768",
              "FINAL_DECISION_DT": null,
              "DECISION_DT": null,
              "FK_ASSIGNMENT_STATUS_CD": "A",
              "DUE_DATE_ASSIGNED_DT": null,
              "TASK_CREATED_TS": null,
              "assignmentTypeDescription": "Assigned to File Clerk",
              "FK_AD_FK_APPEAL_NO": 0,
              "assigneeHistory": "test",
              "ADMINISTRATIVE_PATENT_JDG_3_NM": null,
              "COMPLETION_DT": null,
              "HEARINGDATE": null,
              "PROCEEDING_TYPE": null,
              "ATTORNEY_NM": null,
              "SEQUENCE_NO": 0,
              "assignmentIdentifier": 2226,
              "alerts": [
                " ",
                " ",
                " ",
                "OVERDUE",
                " ",
                "END"
              ],
              "SPECIALTYPE": null,
              "ATTYNUMBER": null,
              "PATENT_NO": null,
              "APPLICATIONCLASS": null,
              "ACTIVE_IN": "A",
              "employeeDetails": [{
                "assigneeNumberText": "5768",
                "assigneeFullNameText": "Gandhi, Parin ",
                "activeCaseCount": 71,
                "assigneeStatus": "Active",
                "userRoles": [{
                  "roleCode": "PTABE2E_Administrator",
                  "roleDescription": "Business Admin"
                }]
              }],
              "PRIORITY_IN": "N",
              "ASSIGNMENT_DT": null,
              "TASK_TITLE_TX": "cffffffffff",
              "PROCEEDING_SUB_TYPE": null,
              "PENDING_LOCATION_TX": null,
              "REQUEST_DT": null,
              "FK_PREEXISTENT_ASSIGNMENT_ID": null,
              "creatorUserName": "Gandhi, Parin ",
              "CREATOR_USER_ID": "pgandhi",
              "ADMINISTRATIVE_PATENT_JDG_2_NM": null,
              "FK_AD_RECONSIDER_SEQUENCE_NO": null,
              "assignorName": "Gandhi, Parin ",
              "dueDateStatus": "PASTDUE",
              "ARTUNITNUMBER": null,
              "ASSIGNMENT_DUE_DT": 1537502400000,
              "FK_AD_FK_AA_SERIAL_NO": "13377245",
              "assigneeName": "Gandhi, Parin ",
              "PROCEEDING_TYPE_NM": null,
              "PATENT_OWNER_NM": null,
              "standardAssignmentType": [
                "Assignment info"
              ],
              "assignmentProceedingSuppId": null,
              "DECISION_TYPED_DT": null,
              "assignmentLastModifiedTs": 1537545818000,
              "assignmentStatus": "Active",
              "APPLICATIONSUBCLASS": null,
              "ADMINISTRATIVE_PATENT_JDG_1_NM": null,
              "DECISION_MAILED_DT": null,
              "assignmentCreateTs": 1537545818026,
              "TASK_DESC_TX": "dfghdfgfgf",
              "lastModifiedUserName": "Gandhi, Parin ",
              "PALM_MAILED_DT": null,
              "FK_TASK_ASSIGNMENT_CT": "PRE-APPEAL",
              "PROCEEDING_STATUS_DESC": null,
              "assignmentLastModifiedUids": "pgandhi",
              "FK_TASK_CREATOR_USER_ID": null,
              "DESCRIPTION_TX": "Assigned to File Clerk",
              "PALM_DECISION_MAILED_DT": null,
              "alertText": " , , ,OVERDUE, ,END"
            }],
            "hierarchy": true,
            descriptionText: "CDDD"
          }]

        };
        scope.gridApi = {
          grid: {

          }
        }

        // var textToSearch = 'pgandhi';
        // spyOn(scope, 'simpleSearch')
        // expect(scope['simpleSearch']).toBeDefined();
        expect(scope['getAssignmentBasedDocket']).toBeDefined();
        scope.getAssignmentBasedDocket();


        HttpFactoryDeferred.resolve(successResponse);
        // $rootScope.$apply();
        scope.$digest();
        // $rootScope.$digest();

        // expect(scope['simpleSearch']).toHaveBeenCalledWith(undefined);
      });



      /* toaster errors */


      //   it(' should call getAssignmentBasedDocket  failureResponse', function () {

      //     failureResponse = {
      //       data: {
      //         message: "assignments get failed"
      //       },
      //       status: 404

      //     }
      //     expect(scope['getAssignmentBasedDocket']).toBeDefined();
      //     scope.getAssignmentBasedDocket();

      //     HttpFactoryDeferred.reject(failureResponse);
      //     scope.$digest();

      //   });

      //   it(' should call getAssignmentBasedDocket  failureResponse', function () {

      //     failureResponse = {
      //       data: {
      //         message: "assignments get failed"
      //       },
      //       status: 500

      //     }
      //     expect(scope['getAssignmentBasedDocket']).toBeDefined();
      //     scope.getAssignmentBasedDocket();

      //     HttpFactoryDeferred.reject(failureResponse);
      //     scope.$digest();

      //   });

      it(' should call highlightFilteredHeader ', function () {
        col = {
          filters: [{
            term: true
          }]
        }
        expect(scope['highlightFilteredHeader']).toBeDefined();
        scope.highlightFilteredHeader(row, rowRenderIndex, col);
      });

      it(' should call highlightFilteredHeader ', function () {
        col = {
          filters: [{
            term: false
          }]
        }
        expect(scope['highlightFilteredHeader']).toBeDefined();
        scope.highlightFilteredHeader(row, rowRenderIndex, col);
      });

      // it('moveItem should swap origin and destination', function () {
      //   var origin = 0,
      //     destination = 1;
      //   var updatedDocketColumnList = [{
      //     'userFavoritesName': 'testFavouriteOrigin',
      //     'userFavoritesURL': 'google.com'
      //   }, {
      //     'userFavoritesName': 'testFavouriteDest',
      //     'userFavoritesURL': 'bin.com'
      //   }];
      //   var updatedDocketColumnListCopy = [{
      //     'userFavoritesName': 'testFavouriteOrigin',
      //     'userFavoritesURL': 'google.com'
      //   }, {
      //     'userFavoritesName': 'testFavouriteDest',
      //     'userFavoritesURL': 'bin.com'
      //   }];
      //   scope.updatedDocketColumnList = updatedDocketColumnList;
      //   expect(scope.moveItem).toBeDefined();
      //   scope.moveItem(origin, destination);

      //   expect(scope.updatedDocketColumnList[0].userFavoritesName).not.toBe(updatedDocketColumnListCopy[0].userFavoritesName);
      //   expect(scope.updatedDocketColumnList[0].userFavoritesURL).not.toBe(updatedDocketColumnListCopy[0].userFavoritesURL);

      // });

      it('listItemUp should call move item', function () {

        expect(scope.listItemUp).toBeDefined();
        spyOn(scope, 'moveItem');
        expect(scope['moveItem']).toBeDefined();
        scope.listItemUp(1);
        expect(scope.moveItem).toHaveBeenCalledWith(1, 0);

      });

      it('listItemDown should call move item', function () {
        expect(scope.listItemDown).toBeDefined();
        spyOn(scope, 'moveItem');
        expect(scope['moveItem']).toBeDefined();
        scope.listItemDown(1);
        expect(scope.moveItem).toHaveBeenCalledWith(1, 2);

      });

      it('it should call getAssignmentById ', function () {
        successResponse = {
          data: [{descriptionText: "CDDD"}]
        };
        expect(controller.getAssignmentById).toBeDefined();
        controller.getAssignmentById();

        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
      });

      it('getAssignmentById failureResponse ', function () {
        failureResponse = {
          data: {}
        };

        expect(controller.getAssignmentById).toBeDefined();
        controller.getAssignmentById();

        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });

      it('it should open showFilteringHelp ', function () {

        var existingCount = ngDialog.open.calls.count();
        expect(scope.showFilteringHelp).toBeDefined();
        scope.showFilteringHelp();
        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(existingCount + 1);
        var args = ngDialog.open.calls.argsFor(existingCount);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('CommonDialogController');
      });

      it(' should call openCaseViewer', function () {
        row = {
          entity: {
            fkAdFkAppealNo: '2018005819',
            fkAdFkAaSerialNo: '15007114'
          }
        }
        expect(scope['openCaseViewer']).toBeDefined();
        scope.openCaseViewer(row);
      });

      //   it(' should call openupdateAssignmentModal', function () {
      //     row = {
      //       entity: {

      //       }
      //     }

      //     scope.gridApi = {
      //       saveState: {
      //         save: function () {
      //           columns: {

      //           }
      //         }
      //       }
      //     }
      //     expect(scope['openupdateAssignmentModal']).toBeDefined();
      //     scope.openupdateAssignmentModal(row);
      //   });


      it(' should call setPaginationManually ', function () {
        expect(scope['setPaginationManually']).toBeDefined();
        scope.setPaginationManually();
      });


      it(' should call updateColumns  ', function () {
        scope.gridState = {
          pagination: {
            paginationPageSize: 10
          }
        }

        successResponse = {
          config: {
            data: [{
              selectedColumns: {
                "columnDetails": [{
                    "name": "assigneeName",
                    "label": "Assigned to",
                    "typeDefinition": "String",
                    "defaultOrder": "asc",
                    "selected": true,
                    "mandatory": true,
                    "width": 200,
                    "sort": {},
                    "filters": [{}]
                  },
                  {
                    "name": "fkAdFkAppealNo",
                    "label": "Case #",
                    "typeDefinition": "Number",
                    "defaultOrder": "asc",
                    "selected": true,
                    "mandatory": false,
                    "width": 110,
                    "sort": {},
                    "filters": [{}]
                  },
                  {
                    "name": "fkAdFkAaSerialNo",
                    "label": "Application #",
                    "typeDefinition": "String",
                    "defaultOrder": "asc",
                    "selected": true,
                    "mandatory": true,
                    "width": 95,
                    "sort": {},
                    "filters": [{}]
                  },
                  {
                    "name": "assigneeHistory",
                    "label": "Audit log",
                    "typeDefinition": "String",
                    "defaultOrder": "desc",
                    "selected": true,
                    "mandatory": false,
                    "width": 115,
                    "sort": {},
                    "filters": [{}]
                  },
                  {
                    "name": "fkAssignmentStatusCd",
                    "label": "Assignment status code",
                    "typeDefinition": "String",
                    "defaultOrder": "desc",
                    "selected": false,
                    "mandatory": false,
                    "width": 200,
                    "sort": {},
                    "filters": [{}]
                  },
                  {
                    "name": "assignorName",
                    "label": "Assignor",
                    "typeDefinition": "String",
                    "defaultOrder": "desc",
                    "selected": false,
                    "mandatory": false,
                    "width": undefined,
                    "sort": {},
                    "filters": [{}]
                  },
                  {
                    "name": "taskDescTx",
                    "label": "Description",
                    "typeDefinition": "String",
                    "defaultOrder": "asc",
                    "selected": false,
                    "mandatory": false,
                    "width": 250,
                    "sort": {},
                    "filters": [{}]
                  },
                  {
                    "name": "noteText",
                    "label": "Note text",
                    "typeDefinition": "Date",
                    "defaultOrder": "desc",
                    "selected": false,
                    "mandatory": false,
                    "width": 350,
                    "sort": {},
                    "filters": [{}]
                  },
                  {
                    "name": "taskTitleTx",
                    "label": "Title",
                    "typeDefinition": "String",
                    "defaultOrder": "asc",
                    "selected": false,
                    "mandatory": false,
                    "width": 250,
                    "sort": {},
                    "filters": [{}]
                  }
                ],
                "assignments": [{
                  "ptabAssignmentId": "818806",
                  "sequenceNo": "0",
                  "fkAssignmentTypeCd": "ATP4",
                  "activeIn": "A",
                  "assignedDt": 1535515200000,
                  "completionDt": null,
                  "pendingLocationTx": "PTABE2E_Administrator",
                  "lastModifiedTs": 1536161247000,
                  "lastModifiedUserId": "pgandhi",
                  "fkAssigneeBeNo": "5768",
                  "fkAdFkAppealNo": "0",
                  "fkAdFkAaSerialNo": "90002730",
                  "fkAdSequenceNo": null,
                  "fkAdReconsiderSequenceNo": null,
                  "palmMailedDt": null,
                  "taskTitleTx": "90002730test",
                  "taskDescTx": null,
                  "fkAssignorBeNo": "5768",
                  "creatorUserId": "pgandhi",
                  "createTs": 1535566163320,
                  "assignmentDueDt": 1536292800000,
                  "fkAssignmentStatusCd": "Active",
                  "fkTaskAssignmentCt": "PRE-APPEAL",
                  "fkTaskCreatorUserId": null,
                  "taskCreatedTs": null,
                  "lockControlNo": "1",
                  "fkCompleterBeNo": null,
                  "proceedingCoreId": null,
                  "proceedingSupId": null,
                  "noteText": null,
                  "fkPreExistentId": null,
                  "assigneeRole": null,
                  "assignmentDesc": null,
                  "dueDateInMs": null,
                  "role": null,
                  "priorityIn": "N",
                  "assignmentTypeDescription": "Assignment To POC4",
                  "assigneeHistory": "1",
                  "assignees": [],
                  "preAppealAssigneesData": null,
                  "assigneeName": "Gandhi, Parin ",
                  "assignorName": "Gandhi, Parin ",
                  "lastModifiedUserName": "Gandhi, Parin ",
                  "creatorUserName": "Gandhi, Parin ",
                  "employeeDetails": [{
                    "beNo": "5768",
                    "name": "Gandhi, Parin ",
                    "activeCases": "26",
                    "assigneeStatus": "ACTIVE",
                    "role": "Business Admin",
                    "description": "PTABE2E_Administrator"
                  }],
                  "stndAssignmentType": [
                    "Assignment info"
                  ]
                }],
                "preAppealAssigneesData": null,
                "hierarchy": true,
                descriptionText: "CDDD"
              }
            }]
          }
        };

        expect(scope['updateColumns']).toBeDefined();
        scope.updateColumns();


        // HttpFactoryDeferred.resolve(successResponse);
        // // $rootScope.$apply();
        // scope.$digest();
        // $rootScope.$digest();

      });

      it('Should invoke getWorker', function () {
        var event = {};
        event.keyCode = 13;

        var searchText = 'pgandhi';

        spyOn(scope, 'simpleSearch');
        expect(scope['simpleSearch']).toBeDefined();
        expect(scope['pressEnter']).toBeDefined();
        scope.pressEnter(event, searchText);
        expect(scope.simpleSearch).toHaveBeenCalled();
      });

      it('Should not invoke getWorker', function () {
        var event = {};
        event.keyCode = 14;
        var searchText = 'pgandhi';
        spyOn(scope, 'simpleSearch');
        expect(scope['simpleSearch']).toBeDefined();
        expect(scope['pressEnter']).toBeDefined();
        scope.pressEnter(event, searchText);
        expect(scope.simpleSearch).not.toHaveBeenCalled();
      });

      it(' should call openAssignmentHistory ', function () {
        scope.assignData = {
          "beNo": "5768"
        }
        row = {
          entity: {
            fkAdFkAppealNo: '2018005819',
            fkAdFkAaSerialNo: '15007114'
          }
        }

        expect(scope['openAssignmentHistory']).toBeDefined();
        scope.openAssignmentHistory(row);

        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(3);
        var args = ngDialog.open.calls.argsFor(2);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('AssignmentHistoryController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.assignmentData();
      });

      //   it(' should call quickclose ', function () {
      //     scope.gridApi = {
      //       selection: {
      //         getSelectedRows: function () {}
      //       }
      //     }

      //     scope.slectedrow = [{

      //       },
      //       {

      //       }
      //     ]
      //     expect(scope['quickclose']).toBeDefined();
      //     scope.quickclose();
      //   });

      it(' should call quickupdate ', function () {
        expect(scope['quickupdate']).toBeDefined();
        scope.quickupdate();
      });

      it('it should call getAssingnmentTypes', function () {
        successResponse = {
          data: [{descriptionText: "CDDD"}]
        };
        expect(scope.getAssingnmentTypes).toBeDefined();
        scope.getAssingnmentTypes();

        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
      });

      it('getAssingnmentTypes failureResponse ', function () {
        failureResponse = {
          data: {}
        };

        expect(scope.getAssingnmentTypes).toBeDefined();
        scope.getAssingnmentTypes();

        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });

      it('it should call getTeamMembers', function () {
        successResponse = {
          data: [{descriptionText: "CDDD"}]
        };
        expect(scope.getTeamMembers).toBeDefined();
        scope.getTeamMembers();

        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
      });

      it('getTeamMembers failureResponse ', function () {
        failureResponse = {
          data: {}
        };

        expect(scope.getTeamMembers).toBeDefined();
        scope.getTeamMembers();

        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });

      it('it should call getAssingnmentCaseTypes', function () {
        successResponse = {
          data: [{descriptionText: "CDDD"}]
        };
        expect(scope.getAssingnmentCaseTypes).toBeDefined();
        scope.getAssingnmentCaseTypes();

        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
      });

      it('getAssingnmentCaseTypes failureResponse ', function () {
        failureResponse = {
          data: {}
        };

        expect(scope.getAssingnmentCaseTypes).toBeDefined();
        scope.getAssingnmentCaseTypes();

        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });

      it('it should call getAssingnmentStatus', function () {
        successResponse = {
          data: [{descriptionText: "CDDD"}]
        };
        expect(scope.getAssingnmentStatus).toBeDefined();
        scope.getAssingnmentStatus();

        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
      });

      it('getAssingnmentStatus failureResponse ', function () {
        failureResponse = {
          data: {}
        };

        expect(scope.getAssingnmentStatus).toBeDefined();
        scope.getAssingnmentStatus();

        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });

      it(' should call timedEnableAdvSearch ', function () {
        expect(scope['timedEnableAdvSearch']).toBeDefined();
        scope.timedEnableAdvSearch();
        // timeout.flush();
      });


      it(' should call enableAdvSearch if', function () {
        scope.advancedSearchObj = {
          selectedType: "ATP1",
          selectedStatus: "ACTIVE",
          selectedCaseType: "Appeal",
          selectedMember: "06000006",
          startDate: "07/22/2018",
          endDate: "07/22/2018"
        }
        expect(scope['enableAdvSearch']).toBeDefined();
        scope.enableAdvSearch();
      });

      it(' should call enableAdvSearch else', function () {
        expect(scope['enableAdvSearch']).toBeDefined();
        scope.enableAdvSearch();
      });

      it(' should call resetAdvancedSearch ', function () {
        expect(scope['resetAdvancedSearch']).toBeDefined();
        scope.resetAdvancedSearch();
      });

      it(' should call performAdvSearch ', function () {
        controller.keepSearchedText = true;
        scope.advancedSearchObj = {
          selectedType: "ATP1",
          selectedStatus: "ACTIVE",
          selectedCaseType: "Appeal",
          selectedMember: "06000006",
          startDate: "07/22/2018",
          endDate: "07/22/2018"
        }
        expect(scope['performAdvSearch']).toBeDefined();
        scope.performAdvSearch();
      });

    });


    it('should call getAssignmentDocketColumns', function () {
      successResponse = {
        "data": [{
          "selectedColumns": [{
            "columnType": "string",
            "cellTemplate": "<div style=\"margin-left: 10px; margin-top: 7px;\"><i ng-if=\"row.entity.alerts[0] !== ' '\" uib-tooltip=\"Critical indicator\" tooltip-placement=\"right\" class=\"fas fa-flag\" style=\"color: red; margin-right:4px;\"></i><i ng-if=\"row.entity.alerts[1] !== ' '\" uib-tooltip=\"New assignment\" tooltip-placement=\"right\" class=\"fas fa-plus-circle\" style=\"color: green; margin-right:4px;\"></i><i ng-if=\"row.entity.alerts[2] !== ' '\" uib-tooltip=\"Assignment is due today ({{row.entity.ASSIGNMENT_DUE_DT | date:'MM/dd/yyyy'}})\" tooltip-placement=\"right\" class=\"far fa-clock\" style=\"color:#F2A900; margin-right:4px;\"></i><i ng-if=\"row.entity.alerts[3] !== ' '\" uib-tooltip=\"Assignment is past due ({{row.entity.ASSIGNMENT_DUE_DT | date:'MM/dd/yyyy'}})\" tooltip-placement=\"right\" class=\"fas fa-exclamation\" style=\"color: red; margin-right:4px;\"></i><i ng-if=\"row.entity.alerts[4] !== ' '\" uib-tooltip=\"User is inactive\" tooltip-placement=\"right\" class=\"fas fa-user-times\"></i></div>",
            "pinned": "right",
            "visible": true,
            "columnLabel": "Alerts",
            "defaultOrder": "asc",
            "width": 95,
            "sort": {},
            "filters": [{}],
            "mandatory": true,
            "columnName": ["alert"]
          }, {
            "columnType": "string",
            "pinned": "",
            "visible": true,
            "columnLabel": "Assignment type",
            "defaultOrder": "asc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["FK_ASSIGNMENT_TYPE_ID", "assignmentTypeDescription"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "string",
            "cellTemplate": "<div style=\"cursor: pointer; margin-left: 8px; padding-top:5px; text-decoration: underline;\" class=\"truncateTitle\"><a role=\"button\" href ng-click=\"grid.appScope.openupdateAssignmentModal(row)\" target=\"_blank\" id=\"{{COL_FIELD}}\"><u>{{COL_FIELD}}</u></a></div>;",
            "pinned": "left",
            "visible": true,
            "columnLabel": "Assignment title",
            "defaultOrder": "asc",
            "width": 234,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["TASK_TITLE_TX"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "aliasName": "assignmentLastModifiedTs",
            "pinned": "",
            "visible": true,
            "sort": {
              "priority": 0,
              "direction": "desc"
            },
            "filters": [{}],
            "mandatory": false,
            "cellFilter": "date:'MM/dd/yyyy hh:mm:ss a'",
            "tableName": "PTAB_ASSIGNMENT",
            "columnType": "date",
            "columnLabel": "Last modified timeStamp",
            "defaultOrder": "asc",
            "width": 200,
            "columnName": ["LAST_MODIFIED_TS"]
          }, {
            "aliasName": "assignmentLastModifiedUids",
            "columnType": "string",
            "pinned": "",
            "visible": true,
            "columnLabel": "Last modified user",
            "defaultOrder": "asc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["LAST_MODIFIED_USER_ID", "lastModifiedUserName"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "string",
            "cellTemplate": "<div style=\"cursor: pointer; margin-left: 8px; padding-top:5px\" class=\"truncateTitle\"><i class=\"fas fa-user-times pull-left\" role=\"button\" href id=\"{{COL_FIELD}}\" title=\"InActive indicator\" ng-if=\"row.entity.assigneeStatus==='InActive'\" style=\"margin-top: 2.5px; margin-right: -16px; margin-left: 2px; color:red;\" id=\"{{COL_FIELD}}\" title=\"InActive indicator\"></i><span style=\"margin-left: 22px;\" ng-class=\"{'mrgnTwoPx':row.entity.assigneeStatus==='InActive'}\" >{{COL_FIELD}}</span></div>",
            "pinned": "",
            "visible": true,
            "columnLabel": "Assigned to",
            "defaultOrder": "asc",
            "width": 279,
            "sort": {},
            "filters": [{}],
            "mandatory": true,
            "columnName": ["FK_ASSIGNEE_BE_NO", "assigneeName"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "number",
            "cellTemplate": "<div style=\"cursor: pointer; margin-left: 8px; padding-top:5px; text-decoration: underline;\" class=\"truncateTitle\"><a href ng-click=\"grid.appScope.openCaseViewer(row)\" target=\"_blank\" id=\"{{COL_FIELD}}\">{{COL_FIELD}}</a>",
            "pinned": "",
            "visible": false,
            "columnLabel": "Case #",
            "defaultOrder": "asc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["FK_AD_FK_APPEAL_NO"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "string",
            "cellTemplate": "<div style=\"cursor: pointer; margin-left: 8px; padding-top:5px; text-decoration: underline;\" class=\"truncateTitle\"><a href ng-click=\"grid.appScope.openCaseViewer(row)\" target=\"_blank\"  id=\"{{COL_FIELD}}\">{{COL_FIELD}}</a>",
            "pinned": "",
            "visible": true,
            "columnLabel": "Application #",
            "defaultOrder": "asc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": true,
            "columnName": ["FK_AD_FK_AA_SERIAL_NO"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "String",
            "pinned": "",
            "visible": true,
            "columnLabel": "Assignor",
            "defaultOrder": "desc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["FK_ASSIGNOR_BE_NO", "assignorName"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "String",
            "pinned": "",
            "visible": true,
            "columnLabel": "Created by",
            "defaultOrder": "asc",
            "width": 140,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["CREATOR_USER_ID"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "date",
            "pinned": "",
            "visible": true,
            "columnLabel": "Palm mailed date",
            "defaultOrder": "asc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "cellFilter": "date:'MM/dd/yyyy'",
            "columnName": ["PALM_MAILED_DT"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "cellTemplate": "<div ng-class=\"{'grid-highlight-active': row.entity.dueDateStatus === 'NEW', 'grid-highlight-warning': row.entity.dueDateStatus === 'TODAY', 'grid-highlight-danger':row.entity.dueDateStatus === 'PASTDUE'}\"><div class=\"ui-grid-cell-contents\">{{COL_FIELD | date:'MM/dd/yyyy'}}</div></div>",
            "pinned": "",
            "visible": true,
            "sort": {},
            "filters": [{}],
            "mandatory": true,
            "cellFilter": "date:'MM/dd/yyyy'",
            "tableName": "PTAB_ASSIGNMENT",
            "columnType": "date",
            "columnLabel": "Assignment due date",
            "defaultOrder": "desc",
            "width": 200,
            "columnName": ["ASSIGNMENT_DUE_DT"]
          }, {
            "columnType": "string",
            "cellTemplate": "<div class=\"truncateTitle\" style=\"cursor: pointer; margin-left: 8px; padding-top:5px; text-decoration: underline;\"><a role=\"button\" href ng-click=\"grid.appScope.openAssignmentHistory(row)\" target=\"_blank\" id=\"{{COL_FIELD}}\">Audit log <i class=\"fas fa-external-link-alt\"></i></a></div>",
            "pinned": "",
            "visible": true,
            "columnLabel": "Audit log",
            "defaultOrder": "desc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["assigneeHistory"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "date",
            "pinned": "",
            "visible": true,
            "columnLabel": "Assigned date",
            "defaultOrder": "desc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": true,
            "cellFilter": "date:'MM/dd/yyyy'",
            "columnName": ["ASSIGNED_DT"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "string",
            "pinned": "",
            "visible": true,
            "columnLabel": "Assignment status code",
            "defaultOrder": "desc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["FK_ASSIGNMENT_STATUS_CD"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "date",
            "pinned": "",
            "visible": true,
            "columnLabel": "Completion date",
            "defaultOrder": "asc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "cellFilter": "date:'MM/dd/yyyy'",
            "columnName": ["COMPLETION_DT"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "string",
            "pinned": "",
            "visible": true,
            "columnLabel": "Description",
            "defaultOrder": "asc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["TASK_DESC_TX"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "string",
            "pinned": "",
            "visible": true,
            "columnLabel": "Note text",
            "defaultOrder": "desc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["COMMENT_TX"],
            "tableName": "PTAB_ASSIGNMENT"
          }],
          "allowedResourceObjectList": ["panel_Update"],
          "ptabReadOnlyUser": false,
          "userWorkspaceWidgetIdentifier": 2262,
          "paginationSize": 10,
          descriptionText: "CDDD"
        }],
        "status": 200,
        "config": {
          "method": "GET",
          "transformRequest": [null],
          "transformResponse": [null],
          "url": "https://ptab-services1.sit.uspto.gov/PTABAppealsServices/user-workspace-widgets/columns/2262",
          "withCredentials": true,
          "crossDomain": true,
          "headers": {
            "user-name": "sbartlett",
            "Accept": "application/json, text/plain, */*"
          }
        },
        "statusText": "OK"
      };

      expect(scope.getAssignmentDocketColumns).toBeDefined();
      scope.getAssignmentDocketColumns();
      // HttpFactoryDeferred.resolve(successResponse);
      // scope.$digest();
    });


    it('should call getAssignmentDocketColumns with failureResponse', function () {
      failureResponse = {
        data: "Failed"
      };
      expect(scope.getAssignmentDocketColumns).toBeDefined();
      scope.getAssignmentDocketColumns();
      HttpFactoryDeferred.reject(failureResponse);
      scope.$digest();
    });



    it('moveItem should swap origin and destination', function () {
      var origin = 0,
        destination = 1;
      var selectedCols = [{
        'userFavoritesName': 'testFavouriteOrigin',
        'userFavoritesURL': 'google.com'
      }, {
        'userFavoritesName': 'testFavouriteDest',
        'userFavoritesURL': 'bin.com'
      }];
      var selectedColsCopy = [{
        'userFavoritesName': 'testFavouriteOrigin',
        'userFavoritesURL': 'google.com'
      }, {
        'userFavoritesName': 'testFavouriteDest',
        'userFavoritesURL': 'bin.com'
      }];
      scope.selectedCols = selectedCols;
      expect(scope.moveItem).toBeDefined();
      scope.moveItem(origin, destination);

      expect(scope.selectedCols[0].userFavoritesName).not.toBe(selectedColsCopy[0].userFavoritesName);
      expect(scope.selectedCols[0].userFavoritesURL).not.toBe(selectedColsCopy[0].userFavoritesURL);

    });


    it('should call moveSourcetoDestination', function () {
      scope.clickedColumn = [{
        mandatory: false
      }]
      scope.availableCols = [{
        mandatory: false
      }]
      scope.selectedCols = [];
      expect(scope.moveSourcetoDestination).toBeDefined();
      scope.moveSourcetoDestination();
    });


    it('should call moveSourcetoDestinationCancel', function () {
      var index = 0;
      scope.selectedCols = [{
        visible: true
      }]
      scope.availableCols = [];
      expect(scope.moveSourcetoDestinationCancel).toBeDefined();
      scope.moveSourcetoDestinationCancel(index);
    });


    it('should call toggleSelectAll', function () {
      scope.availableCols = [{
        mandatory: false
      }]
      scope.selectedCols = [];
      expect(scope.toggleSelectAll).toBeDefined();
      scope.toggleSelectAll();
    });


    it('should call removeAll with madatory as false', function () {
      scope.selectedCols = [{
        mandatory: false
      }]
      scope.availableCols = [];
      expect(scope.removeAll).toBeDefined();
      scope.removeAll();
    });


    it('should call removeAll with madatory as true', function () {
      scope.selectedCols = [{
        mandatory: true
      }]
      scope.availableCols = [];
      expect(scope.removeAll).toBeDefined();
      scope.removeAll();
    });

  });
})();
