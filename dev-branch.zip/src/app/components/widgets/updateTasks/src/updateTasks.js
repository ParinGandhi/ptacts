'use strict';

angular.module('adf.widget.updateTasks', ['adf.provider'])
  .config(function(dashboardProvider){
    dashboardProvider
      .widget('updateTasks', {
        title: 'Update Tasks',
        description: 'Update Tasks Widget',
        templateUrl: '{widgetsPath}/updateTasks/src/view.html',
        edit: {
          templateUrl: '{widgetsPath}/updateTasks/src/edit.html'
        }
      });
  });
