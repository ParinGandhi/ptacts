'use strict';

angular.module('adf.widget.reportCenter', ['adf.provider', 'ui.grid'])
  .config(function (dashboardProvider) {
    dashboardProvider
      .widget('reportCenter', {
        title: 'Report Center',
        description: 'Contains report center links',
        templateUrl: '{widgetsPath}/reportCenter/src/view.html',
        edit: {
          templateUrl: '{widgetsPath}/reportCenter/src/edit.html'
        }
      });
  }).directive('reportsView', function () {
    return {
      restirct: 'E',
      templateUrl: 'app/components/widgets/reportCenter/reportsView.html',
      bindToController: true
    };
  })
  .controller('reportCenterController', function ($scope, CommonHelperService, $log, $window, HttpFactory, ngDialog, CONSTANTS) {

    var scope = angular.element(document.getElementById('mainTabId')).scope();
    $scope.cdrOpen = false;
    $scope.cdrprOpen = false;
    $scope.cdrOpen1 = false;
    $scope.cdrprOpen1 = false;
    $scope.mprOpen = false;
    $scope.ptabarrOpen = false;
    $scope.isPanel = false;
    $scope.isCredit = false;
    $scope.isDocket = false;
    $scope.isReport = false;
    $scope.isManage = false;
    $scope.rtfBaseLink = CONSTANTS.URL.BASE;
    $scope.isLoading = false;
    $scope.readOnlyUser = scope.readOnlyUser;

    if (angular.isDefined($scope.$parent.model)) {
      $scope.isLoading = true;
      $scope.RCdataUrl = $scope.$parent.model.dataUrlText;
    } else {
      $scope.isLoading = true;
      $scope.RCdataUrl = $scope.definition.dataUrlText;
    }

    $scope.setWidgetZone = function (zoneWidth) {
      if (angular.isUndefined(zoneWidth)) {
        scope.vm.getWidgetZone($scope.$parent.model);
        $scope.zoneWidth = $scope.$parent.model.zoneWidth;
      } else {
        $scope.zoneWidth = zoneWidth;
      }
    };
    $scope.setWidgetZone();


    HttpFactory.getActions($scope.RCdataUrl)
      .then(function (successResponse) {
        $scope.isLoading = false;
        $scope.myData = successResponse.data;

        angular.forEach($scope.myData, function (url) {

          if (url.reportMenuName === 'Crediting Report') {
            $scope.creditUrl = url.reportDetails;
            $scope.creditName = url.reportDetails[0].displayName;
            $scope.isCredit = true;
          } else if (url.reportMenuName === 'Docket Report') {
            $scope.docketUrl = url.reportDetails;
            $scope.docketName = url.reportDetails[0].displayName;
            $scope.isDocket = true;
          } else if (url.reportMenuName === 'Hearing Report') {
            $scope.hearingUrl = url.reportDetails;
            $scope.hearingName = url.reportDetails[0].displayName;
            $scope.isReport = true;
          } else if (url.reportMenuName === 'Management Report') {
            $scope.managementUrl = url.reportDetails;
            $scope.managementName = url.reportDetails[0].displayName;
            $scope.isManage = true;
          } else if (url.reportMenuName === 'Paneling Report') {
            $scope.panelUrl = url.reportDetails;
            $scope.panelName = url.reportDetails[0].displayName;
            $scope.isPanel = true;
          } else if (url.reportMenuName === 'DAPI Reports') {
            $scope.getDapi();
          }
        });
      }, function (failureResponse) {
        $scope.isLoading = false;
        $log.info(failureResponse);

      });


    $scope.getDapi = function () {
      HttpFactory.getActions("/reports/ptabe2e-reports")
        .then(function (successResponse) {
          $scope.reportsData = successResponse.data;
          $scope.combinedDocketReports = $scope.reportsData.combinedDocketReports;
          $scope.docketAndProdReports = $scope.reportsData.docketAndProdReports;
          $scope.monthlyReports = $scope.reportsData.monthlyProdReports;
          $scope.ptabreport = $scope.reportsData.ptabReceivedDtReports;
        }, function (failureResponse) {
          $log.info(failureResponse);
        });
    };

    $scope.openReportWithEnter = function (event, url, name) {
      if (event.keyCode === 13) {
        $scope.openReport(getURL(name), name);
      }
    };

    function getURL(name) {
      var reportDetailsUrl;
      angular.forEach($scope.myData, function(report) {
        if (report.reportMenuName === 'AIA Report') {
          angular.forEach(report.reportDetails, function(reportType) {
            if (reportType.reportTitle===name) {
              reportDetailsUrl=reportType.reportURL;
            }
          });
        }
      });
      return reportDetailsUrl;
    }

    $scope.openReport = function (url, name) {
      var newWindow = $window.open(url);
      newWindow.addEventListener('load', function () {
        newWindow.document.title = name;

      });
    };

    $scope.palmExpoUrl = "http://expoweb1:8005/mgmt/main.jsp";

    $scope.openPalmExpoModal = function () {
      if (CommonHelperService.isIE()) {
        $window.open($scope.palmExpoUrl, "_blank");
      } else {
        ngDialog.open({
          template: "app/components/widgets/reportCenter/src/palmExpoModal.html",
          scope: $scope,
          width: '30%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false
        });
      }
    };

    $scope.copyToClipBoard = function (value) {
      $scope.copiedNumber = value;
      var input = document.createElement('input');
      input.setAttribute('value', value);
      document.body.appendChild(input);
      input.select();
      var result = document.execCommand('copy');
      document.body.removeChild(input);
      CommonHelperService.setToastr(CONSTANTS.TOASTER.reportCenterClip, "success");
      return result;
    };

  });
