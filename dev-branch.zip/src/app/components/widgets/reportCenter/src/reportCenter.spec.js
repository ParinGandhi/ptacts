(function () {
  'use strict';

  describe('reportCenterController', function () {

    beforeEach(module('ptabe2e'));

    var vm = this;
    var scope, spy;
    var controller, $controller;
    var $window;
    var listeners = [];
    var $q, HttpFactoryDeferred;
    var scope, $rootScope, $http, $interval;
    var $httpBackend, spy;
    var $ngDialog = jasmine.createSpyObj('ngDialog', ['open']);

    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              getWidgetZone: function () {

              },
              setWidgetContentHeight: function () {

              }
            }
          }
        }
      }
    };
    var fakeVm = {
      getWidgetZone: function () {

      },
      setWidgetContentHeight: function () {

      }
    };

    beforeEach(inject(function (_$controller_, _$rootScope_, _$http_, _$httpBackend_, _$interval_, _$q_, HttpFactory) {
      $q = _$q_;
      scope = _$rootScope_.$new();
      $http = _$http_;
      $controller = _$controller_;
      $rootScope = _$rootScope_;
      $httpBackend = _$httpBackend_;
      $ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback) {

          }
        }
      });

      $window = jasmine.createSpyObj("$window", ["open", "addEventListener"]);
      $window.open.and.callFake(function () {
        return $window;
      });
      $window.addEventListener.and.callFake(function (event, listener) {
        listeners[event] = listener;
      });

      scope.$parent = {
        "model": {
          "zoneWidth": 10,
          "widgetIdentifier": 1
        }
      };
      scope.$parent = {
        model: {
          dataUrlText: 'http://localhost:8080/PTABServices/',
          widgetIdentifier: 12
        }
      }

      scope.$parent.model = "";
      scope.definition = {
        dataUrlText: 'http://localhost:8080/PTABServices/'
      }
      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      // setup the promise
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      controller = $controller('reportCenterController', {
        $scope: scope,
        $http: $http,
        ngDialog: $ngDialog,
        $rootScope: _$rootScope_,
        $interval: $interval,
        HttpFactory: HttpFactory

      });

    }));


    afterEach(function () {
      spy.and.callThrough();
      $window.open.and.callThrough();
      $window.addEventListener.and.callThrough();
    });


    describe('check functions', function () {

      it('setWidgetZone should set WidgetZone', function () {
        scope.$parent = {
          "model": {
            "zoneWidth": 10
          }
        };
        var zoneWidth = 10;
        expect(scope.setWidgetZone).toBeDefined();
        scope.setWidgetZone(zoneWidth);
        expect(scope.zoneWidth).toBe(zoneWidth);

        expect(scope.setWidgetZone).toBeDefined();
        scope.setWidgetZone();
        expect(scope.zoneWidth).toBe(zoneWidth);

      });

      it('should return successResponse ', function () {

        var successResponse = {
          data: {
            events: {},
            refreshInterval: 1
          }
        };

        HttpFactoryDeferred.resolve(successResponse);
        // $rootScope.$apply();
        scope.$digest();

      });

      it('should find menu name Crediting Repost', function () {

        var successResponse = {
          data: [{
            reportMenuName: 'Crediting Report',
            reportDetails: [{
              displayName: 'displayName'
            }]
          }]
        };

        HttpFactoryDeferred.resolve(successResponse);
        // $rootScope.$apply();
        scope.$digest();

      });

      it('should find menu name Docket Repost', function () {

        var successResponse = {
          data: [{
            reportMenuName: 'Docket Report',
            reportDetails: [{
              displayName: 'displayName'
            }]
          }]
        };

        HttpFactoryDeferred.resolve(successResponse);
        // $rootScope.$apply();
        scope.$digest();

      });

      it('should find menu name Hearing Repost', function () {

        var successResponse = {
          data: [{
            reportMenuName: 'Hearing Report',
            reportDetails: [{
              displayName: 'displayName'
            }]
          }]
        };

        HttpFactoryDeferred.resolve(successResponse);
        // $rootScope.$apply();
        scope.$digest();

      });

      it('should find menu name DAPI Report', function () {

        var successResponse = {
          data: [{
            reportMenuName: 'DAPI Report',
            reportDetails: [{
              displayName: 'displayName'
            }]
          }]
        };

        HttpFactoryDeferred.resolve(successResponse);
        // $rootScope.$apply();
        scope.$digest();

      });


      it('should find menu name Management Repost', function () {

        var successResponse = {
          data: [{
            reportMenuName: 'Management Report',
            reportDetails: [{
              displayName: 'displayName'
            }]
          }]
        };

        HttpFactoryDeferred.resolve(successResponse);
        // $rootScope.$apply();
        scope.$digest();

      });

      it('should find menu name Paneling Repost', function () {

        var successResponse = {
          data: [{
            reportMenuName: 'Paneling Report',
            reportDetails: [{
              displayName: 'displayName'
            }]
          }]
        };

        HttpFactoryDeferred.resolve(successResponse);
        // $rootScope.$apply();
        scope.$digest();

      });

      it('should return failureResponse  ', function () {

        var failureResponse = {};

        HttpFactoryDeferred.reject(failureResponse);
        // $rootScope.$apply();
        scope.$digest();

      });

      it('it should call openReport', function () {

        var name = "test";
        expect(scope.openReport).toBeDefined();
        scope.openReport();

      });


      it('it should call getDapi failureResponse', function () {
        var failureResponse = {
          data: "FAILED"
        };
        expect(scope.getDapi).toBeDefined();
        scope.getDapi();
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });

      it(' should call openReportWithEnter', function () {
        var event = {
          "keyCode": 1
        }
        var url = "sdkdkf"
        var name = "e"
        expect(scope['openReportWithEnter']).toBeDefined();
        scope.openReportWithEnter(event, url, name);
      });

      it(' should call openReportWithEnter', function () {
        var event = {
          "keyCode": 13
        }
        var url = "sdkdkf"
        var name = "e"
        expect(scope['openReportWithEnter']).toBeDefined();
        scope.openReportWithEnter(event, url, name);
      });

      it('should call getDapi and get successresponse', function () {
        var successResponse = {
          data: [{
            combinedDocketReports: ["1", "2", "3"],
            docketAndProdReports: ["1", "2", "3"],
            monthlyProdReports: ["1", "2", "3"],
            ptabReceivedDtReports: ["1", "2", "3"]
          }]
        };
        expect(scope.getDapi).toBeDefined();
        scope.getDapi();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
      });

      it('should call openPalmExpoModal', function () {
        expect(scope.openPalmExpoModal).toBeDefined();
        scope.openPalmExpoModal();
      });
      it('should call copyToClipBoard ', function () {
        expect(scope.copyToClipBoard).toBeDefined();
        scope.copyToClipBoard();
      });

    });

  });
})();
