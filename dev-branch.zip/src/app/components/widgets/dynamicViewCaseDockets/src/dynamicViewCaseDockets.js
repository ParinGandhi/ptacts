'use strict';

angular.module('adf.widget.dynamicViewCaseDockets', ['adf.provider'])
  .config(function (dashboardProvider) {
    dashboardProvider
      .widget('dynamicViewCaseDockets', {
        title: 'Dynamic view case dockets',
        description: 'Dynamic view case dockets',
        templateUrl: '{widgetsPath}/dynamicViewCaseDockets/src/view.html',
        edit: {
          templateUrl: '{widgetsPath}/dynamicViewCaseDockets/src/edit.html'
        }
      });
  }).directive('dynamicdocketView', function () {
    return {
      restirct: 'E',
      templateUrl: 'app/components/widgets/dynamicViewCaseDockets/src/dynamicViewCaseDockets.html',
      bindToController: true
    };
  }).filter('splitkeydate', function ($sce) {
    return function (input) {
      var htmlString = "";
      angular.forEach(input, function (keyDate) {
        htmlString += keyDate + "\n";
      });
      return $sce.trustAsHtml(htmlString);
    };
  }).controller('DynamicViewCaseDocketController', function (ngDialog, $scope, $timeout, $filter, i18nService, $rootScope,
    uiGridConstants, SearchHelperService, HttpFactory, CONSTANTS, $window, $log, CommonHelperService, $sce) {


    /* istanbul ignore next  */
    $rootScope.$on('broadcastZoneWidth', function (event, param) {
      if ($scope.$parent.model) {
        if ($scope.$parent.model.widgetIdentifier === param.widgetIdentifier) {
          $scope.setWidgetZone(param.zoneWidth);
        }
      }
    });
    $scope.isJudge = $rootScope.userInfo.roleDescription ? $rootScope.userInfo.roleDescription.toUpperCase().indexOf('JUDGE') > -1 ? true : false : false;

    var scope = angular.element(document.getElementById('mainTabId')).scope();
    $scope.setWidgetZone = function (zoneWidth) {
      if (angular.isUndefined(zoneWidth)) {
        scope.vm.getWidgetZone($scope.$parent.$parent.$parent.definition);
        $scope.zoneWidth = $scope.$parent.$parent.$parent.definition.zoneWidth;
      } else {
        $scope.zoneWidth = zoneWidth;
      }
      $log.debug("Dynamic view case docket zone width: " + $scope.zoneWidth);
    };
    $scope.setWidgetZone();
    $scope.customData = [];
    $scope.selectUnselect = true;
    $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
    $scope.loadedColumns = false;
    var isViewCaseDocket = true;
    var isFilterChanged = false;
    var isColumnVisibilityChanged = false;
    var isColumnPinnedChanged = false;
    var isColumnSizeChanged = false;
    var isSortChanged = false;
    var isColumnPositionChanged = false;
    var isPaginationChanged = false;
    var initialLoad = true;
    $scope.preferencesChanged = false;
    $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
    $scope.gridRefreshMsg = CONSTANTS.MESSAGES.GRID_REFRESH;
    $rootScope.viewCaseColumnsChanged = false;
    $scope.showDynamicGrid = true;
    $scope.judgeList = '';
    $scope.selectedJudge = '';
    $scope.popOverPosition = "bottom";
    $scope.popOverDisabled = true;
    $scope.popoverVisible = false;
    $scope.judgeListVisible = false;
    $scope.judge = {
      "fullName": null
    };


    /* istanbul ignore next*/
    function clearMulti() {
      var i;
      var select = document.getElementById('availableColsId');
      for (i = 0; i < select.options.length; i++) {
        select.options[i].selected = false;
      }
    }

    /* istanbul ignore next  */
    function resetUnsavedChangesFlags() {
      isFilterChanged = false;
      isColumnVisibilityChanged = false;
      isColumnPinnedChanged = false;
      isColumnSizeChanged = false;
      isSortChanged = false;
      isColumnPositionChanged = false;
      isPaginationChanged = false;
      $scope.preferencesChanged = false;
      $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
      $scope.vcdListOrderChanged = false;
    }

    $scope.getJudgeList = function () {
      HttpFactory.getActions(CONSTANTS.URL.GET_ALL_JUDGES)
        .then(function (judgeList) {
          var sortedList = judgeList.data.sort(function (a, b) {
            if (a.assigneeFullNameText < b.assigneeFullNameText) {
              return -1;
            }
            if (a.assigneeFullNameText > b.assigneeFullNameText) {
              return 1;
            }
            return 0;
          });
          $scope.judgeList = judgeList.data;
          var defaultOption = [
            // {
            //   assigneeNumberText: "",
            //   assigneeFullNameText: "Select judge...",
            //   workerNumber: "",
            //   rankId: null
            // },
            {
              assigneeNumberText: "",
              assigneeFullNameText: "All judges",
              workerNumber: "",
              rankId: null
            }
          ];
          $scope.judgeList = defaultOption.concat(sortedList);
          $scope.originalJudgeList = angular.copy($scope.judgeList);
          $scope.selectedJudge = $scope.judgeList[0];
          console.log("Judgelist: ");
          console.log($scope.judgeList);
          var popOverTextLineOne = '<table><tr><td class="col-sm-4">APJ1 12</td><td class="col-sm-4">16</td><td class="col-sm-4">20</td></tr>';
          var popOverTextLineTwo = '<tr><td class="col-sm-4">APJ2 2</td><td class="col-sm-4">12</td><td class="col-sm-4">18</td></tr>';
          var popOverTextLineThree = '<tr><td class="col-sm-4">APJ3 7</td><td class="col-sm-4">5</td><td class="col-sm-4">15</td></tr></table>';
          var fullText = popOverTextLineOne + popOverTextLineTwo + popOverTextLineThree;
          $scope.htmlPopover = $sce.trustAsHtml(fullText);
        }, function (judgeListFailure) {
          console.log(judgeListFailure);
        });
    };

    $scope.getJudgeList();

    $scope.setSelectedJudge = function (judge) {
      $scope.closedCasesResponse=null;
      $scope.openCasesResponse=null;
      if (judge.assigneeFullNameText !== "Select judge...") {
        $scope.selectedJudge = judge;
        $scope.showDynamicGrid = true;
        $scope.popOverDisabled = false;
        clearData();
        $scope.judge.fullName = judge.assigneeFullNameText;
        $scope.getDynamicViewCaseDocketData();
        if ($scope.selectedJudge.assigneeFullNameText !== "All judges") {
          getClosedCases();
        }
       
      } else {
        $scope.showDynamicGrid = false;
        $scope.popOverDisabled = true;
        clearData();
      }
    };

    function clearData() {
      $scope.noOfCases = {
        noOfAppealsCases: 0,
        noOfTrialsCases: 0,
        apj1AppealsCases: 0,
        apj1TrialsCases: 0,
        apj2AppealsCases: 0,
        apj2TrialsCases: 0,
        apj3PlusAppealsCases: 0,
        apj3PlusTrialsCases: 0
      };
      $scope.totalCasesByNumber = {
        "totalApj1Cases": [],
        "totalApj1Appeal": [],
        "totalApj1Trials": [],
        "totalApj2Cases": [],
        "totalApj2Appeal": [],
        "totalApj2Trials": [],
        "totalApj3Cases": [],
        "totalApj3Appeal": [],
        "totalApj3Trials": []
      };
    }



    $scope.showPopover = function () {
      $scope.popoverVisible = !$scope.popoverVisible;
      $scope.judgeListVisible = false;
    };

    $scope.showJudgeList = function () {
      if (!$scope.judgeListVisible) {
        $scope.judgeListVisible = !$scope.judgeListVisible;
        $scope.popoverVisible = false;
      }
    };


    /* istanbul ignore if  */
    if (angular.isDefined($scope.$parent.model)) {
      $scope.VCDdataUrl = $scope.$parent.model.dataUrlText;
      $scope.widgetIdentifier = $scope.$parent.model.widgetIdentifier;
    } else {
      $scope.VCDdataUrl = $scope.definition.dataUrlText;
      $scope.widgetIdentifier = $scope.definition.widgetIdentifier;
    }
    $log.debug("View case docket data url: " + $scope.VCDdataUrl);
    $log.debug("View case docket widget identifier: " + $scope.widgetIdentifier);
    /* istanbul ignore next*/
    $scope.getDynamicViewCaseDocketColumns = function () {
      if (isViewCaseDocket || $scope.definition.type === 'viewCaseDockets') {
        isViewCaseDocket = false;
        HttpFactory.getActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS + $scope.widgetIdentifier)
          .then(function (successResponse) {
            $scope.selectedColumns = successResponse.data.selectedColumns;
            $scope.selectedCols = [];
            $scope.availableCols = [];
            angular.forEach($scope.selectedColumns, function (thisColumn) {
              if (thisColumn.visible) {
                $scope.selectedCols.push(thisColumn);
              } else {
                $scope.availableCols.push(thisColumn);
              }
            });
            $log.debug('Selected:');
            $log.debug($scope.selectedCols);
            $log.debug('Available: ');
            $log.debug($scope.availableCols);
            $scope.originShowHide = angular.copy($scope.selectedColumns);
            $scope.viewCaseAvailableCols = angular.copy($scope.selectedCols);
            $scope.loadedColumns = true;
            for (var i = 0; i < $scope.selectedColumns.length; i++) {
              if (!$scope.selectedColumns[i].visible) {
                $scope.selectUnselect = false;
                $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
              }
            }
            $log.debug("Dynamic iew case docket (" + $scope.widgetIdentifier + ") getDynamicViewCaseDocketColumns success response: ");
            $log.debug(successResponse);
          }, function (failureResponse) {
            $log.debug("Dynamic view case docket (" + $scope.widgetIdentifier + ") getDynamicViewCaseDocketColumns failure response: ");
            $log.debug(failureResponse);
          });
      }
    };

    $scope.onKeyup = function (type, $event) {
      if ($event.keyCode === 13) {
        $scope.showCases(type);
      }
    };

    $scope.showCases = function(type) {
      if (type==="closed") {
        if (!$scope.closedCasesResponse) {
          $scope.loadingClosedCases=true;
          getClosedCases();
          return;
        }
        buildDataFromService($scope.closedCasesResponse);
      } else {
        buildDataFromService($scope.openCasesResponse);
      }
    
    };

    $scope.getDynamicViewCaseDocketColumns();
    /* istanbul ignore next*/
    $scope.gridOptions = {
      enableGridMenu: true,
      enableSelectAll: true,
      useExternalFiltering: true,
      exporterCsvFilename: 'DynamicViewCaseDocket_' + CommonHelperService.getCurrentTime() + '.csv',
      exporterOlderExcelCompatibility: true,
      exporterMenuExcel: false,
      exporterMenuPdf: false,
      gridMenuShowHideColumns: true,
      enableFiltering: true,
      paginationPageSizes: [10, 25, 50, 100],
      enableHorizontalScrollbar: uiGridConstants.scrollbars.WHEN_NEEDED,
      gridMenuCustomItems: [{
          title: 'Save grid preferences',
          action: function () {
            $scope.saveGridPreferences();
          },
          order: 100
        }, {
          title: 'Show hidden filters',
          action: function () {
            showHiddenFilteredColumns();
          },
          order: 190
        }, {
          title: 'Export full docket as csv',
          action: function () {
            $scope.exportData();
          },
          order: 210
        },
        {
          title: 'Mandatory columns',
          order: 220
        },
        {
          title: 'Case #',
          icon: 'fas fa-check',
          order: 224
        }
      ],
      onRegisterApi: function (gridApi) {
        $scope.gridApi = gridApi;
        $scope.gridApi.core.on.filterChanged($scope, function () {
          isFilterChanged = true;
          var grid = this.grid;
          $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
          if ($scope.numberOfFilters === 0) {
            $scope.gridOptions.data = $scope.myData.caseDetailsData;
          } else {
            var filteredData = SearchHelperService.filterGrid(grid, $scope.myData);
            $scope.gridOptions.data = filteredData;
            $log.debug("View case docket (" + $scope.widgetIdentifier + ") filtered data: ");
            $log.debug(filteredData);
          }
          checkForUnsavedChanges();
        });
        $scope.gridApi.core.on.columnVisibilityChanged($scope, function () {
          isColumnVisibilityChanged = true;
          updateColumnDefs($scope.gridOptions.columnDefs);
          checkForUnsavedChanges();
        });
        $scope.gridApi.pinning.on.columnPinned($scope, function () {
          isColumnPinnedChanged = true;
          updateColumnDefs($scope.gridOptions.columnDefs);
          checkForUnsavedChanges();
        });
        $scope.gridApi.colResizable.on.columnSizeChanged($scope, function () {
          isColumnSizeChanged = true;
          checkForUnsavedChanges();
        });
        $scope.gridApi.core.on.sortChanged($scope, function () {
          isSortChanged = true;
          checkForUnsavedChanges();
        });
        $scope.gridApi.colMovable.on.columnPositionChanged($scope, function () {
          isColumnPositionChanged = true;
          checkForUnsavedChanges();
        });
        $scope.gridApi.pagination.on.paginationChanged($scope, function () {
          isPaginationChanged = true;
          checkForUnsavedChanges();
        });
        $scope.gridApi.core.on.renderingComplete($scope, function () {
          $scope.gridResize();
          checkForUnsavedChanges();
        });

      }

    };

    /* istanbul ignore next  */
    function showHiddenFilteredColumns() {
      var hiddenFilteredColumns = SearchHelperService.hasHiddenColumnFilters($scope.gridApi.grid.columns);

      angular.forEach(hiddenFilteredColumns, function (column) {
        column.showColumn();
        $scope.preferencesChanged = true;
      });
      $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
    }

    /* istanbul ignore next  */
    function convertArrayToString(value) {
      var arrayString = "";
      angular.forEach(value.slice(0, 3), function (eachItem) {
        arrayString += eachItem + " ";
      });
      return arrayString;
    }
    /* istanbul ignore next*/
    $scope.gridOptions.exporterFieldCallback = function (grid, row, col, value) {
      $scope.gridOptions.exporterCsvFilename = 'DynamicViewCaseDocket_' + CommonHelperService.getCurrentTime() + '.csv';
      if (col.colDef.type === 'string') {
        if (col.colDef.field === 'ALL_DISPOSITION_TX') {
          if (angular.isDefined(value)) {
            if (value[0] === "") {
              value = "";
            } else {
              value = convertArrayToString(value);
            }
          }
        }
      }
      if (col.colDef.type === 'string') {
        if (col.colDef.displayName === 'Panel') {
          return setPanelColumnForExport(row.entity);
        }
      }
      if (col.colDef.type === 'date') {
        if (col.colDef.field === 'LAST_MODIFIED_TS') {
          value = $filter('date')(value, 'MM/dd/yyyy hh:mm:ss a');
        } else {
          value = $filter('date')(value, 'MM/dd/yyyy');
        }
        if (!value) {
          value = "";
        } else {
          value = " " + value;
        }
      }
      if (col.colDef.field === "DECISION_DUE_DAYS") {
        value = "";
      }
      return value;
    };
    /* istanbul ignore next*/
    $scope.gridResize = function () {
      var gridHeight = document.getElementsByClassName('grid');
      for (var i = 0; i < gridHeight.length; i++) {
        if ($scope.$parent.model.widgetIdentifier === $scope.widgetIdentifier) {
          if ($scope.$parent.model.height === 'widgetHeightSmall') {
            gridHeight[i].style.height = '210px';
          } else if ($scope.$parent.model.height === 'widgetHeightMedium') {
            gridHeight[i].style.height = '530px';
          } else if ($scope.$parent.model.height === 'widgetHeightLarge') {
            gridHeight[i].style.height = '915px';
          } else if ($scope.$parent.model.height === 'widgetHeightXlarge') {
            gridHeight[i].style.height = '1615px';
          }
        }
      }
    };

    /* istanbul ignore next  */
    function updateColumnDefs(columndefs) {
      var selected = [];
      var unselected = [];
      var selectedCount = 0;

      angular.forEach(columndefs, function (col) {
        if (col.visible) {
          selected.push(col);
          selectedCount = selectedCount + 1;
        } else {
          unselected.push(col);
        }
      });

      columndefs = [];
      angular.forEach(selected, function (col) {
        columndefs.push(col);
      });
      unselected.sort(CommonHelperService.alphabetizeAvailableColumns);
      angular.forEach(unselected, function (col) {
        columndefs.push(col);
      });

      $scope.gridOptions.rowHeight = 30;

      for (var i = 0; i < columndefs.length; i++) {
        if ((columndefs[i].field === "ALL_DISPOSITION_TX" && columndefs[i].visible === true) ||
          (columndefs[i].field === "ADDITIONAL_APJ_WORKER_ID_TX" && columndefs[i].visible === true)) {
          $scope.gridOptions.rowHeight = 70;
          break;
        }
      }

      $scope.gridOptions.columnDefs = buildCaseAlerts(columndefs);
    }


    function buildCaseAlerts(columndefs) {
      angular.forEach(columndefs, function (col) {
        if (col.displayName === 'Alerts') {
          col = CommonHelperService.addAlertFilters(col, 'View case dockets');
        }
      });
      return columndefs;
    }

    $scope.gridState = {};
    /* istanbul ignore next  */
    $scope.saveState = function () {
      $scope.saveGridPreferences();
    };

    /* istanbul ignore next  */
    $scope.restoreState = function () {
      $scope.gridApi.saveState.restore($scope, $scope.gridState);
      $log.debug("View case docket (" + $scope.widgetIdentifier + ") restore state: ");
      $log.debug(angular.toJson($scope.gridState.columns));
    };


    $scope.showFilters = false;
    $scope.noRecordsFound = false;

    $scope.openCaseViewer = function (row) {
      $window.open("#/caseViewer/" + row.entity.PROCEEDING_CORE_ID + "/" + row.entity.PROCEEDING_SUPPLEMENTARY_ID);
    };

    $scope.openCaseViewerwithAppeal = function (row) {
      $window.open("#/caseViewer/" + row.entity.PROCEEDING_CORE_ID + "/" + row.entity.PROCEEDING_NO);
    };

    $scope.openCaseViewerwithTrials = function (row) {
      if (row.entity.PROCEEDING_NO.match(/[D]/i) && row.entity.REDIRECT_URL != null) {
        CommonHelperService.getRedirectUrl(row.entity.REDIRECT_URL);
      } else {

        if (event.ctrlKey && row.entity.REDIRECT_URL != null) {
          CommonHelperService.getRedirectUrl(row.entity.REDIRECT_URL);
        } else {
          $window.open("#/caseViewer/" + row.entity.PROCEEDING_CORE_ID + "/" + row.entity.PROCEEDING_NO + "/documents");
        }
      }
    };
    /* istanbul ignore next*/
    $scope.getDynamicViewCaseDocketData = function () {

      $scope.judgeListVisible = false;
      $scope.isLoading = true;
      $scope.gearLoading = false;
      var url;
      if ($scope.selectedJudge.assigneeFullNameText === "All judges") {
        url = "/mixed-case-dockets/details?widgetId=" + $scope.widgetIdentifier;
        $scope.popOverDisabled = true;
      } else {
        url = "/mixed-case-dockets/details-user?widgetId=" + $scope.widgetIdentifier + "&userId=" + $scope.selectedJudge.assigneeNumberText;
      }
     
      console.log("Searching for " + $scope.selectedJudge.assigneeFullNameText);
      HttpFactory.getActions(url)
        .then(function (successResponse) {
          $scope.openCasesResponse = successResponse.data[0];
          $scope.openCases =  successResponse.data[0].caseDetailsData;
          buildDataFromService(successResponse.data[0]);
        }, function (failureResponse) {
            $log.debug("Dynamic view case docket (" + $scope.widgetIdentifier + ") getDynamicViewCaseDocketData failure response: ");
            $log.debug(failureResponse);
            /* istanbul ignore if: toaster error  */
            if (failureResponse.status === 404) {
              $scope.enableloading = false;
              $scope.refreshFailed = false;
              $scope.dateValid = false;
              $scope.refreshDate = new Date();
              CommonHelperService.setToastr(failureResponse.data.message, "info");
              $scope.noRecordsFound = true;
            } else {
              $scope.refreshFailed = true;
              $scope.refreshFailedate = new Date();
              $scope.enableloading = false;
              if (angular.isUndefined($scope.refreshDate) || $scope.refreshDate === null) {
                $scope.dateValid = true;
              }
            }
          }).finally(function () {
          $scope.isLoading = false;
          
        });
    };

    function getClosedCases(firstTime) {
      var url;
      
      if ($scope.selectedJudge.assigneeFullNameText === "All judges") {
        url = "/mixed-case-dockets/details/?widgetId=" + $scope.widgetIdentifier;
        $scope.popOverDisabled = true;
      } else {
        url = "/mixed-case-dockets/details-user?widgetId=" + $scope.widgetIdentifier + "&userId=" + $scope.selectedJudge.assigneeNumberText;
      }
     
      url += "&caseStatus=closed";
     
      console.log("Searching for " + $scope.selectedJudge.assigneeFullNameText);
      HttpFactory.getActions(url)
        .then(function (successResponse) {
          $scope.loadingClosedCases=false;
          $scope.closedCasesResponse = successResponse.data[0];  
  
          $scope.closedCases =  successResponse.data[0].caseDetailsData;
          $scope.isloading=false;
          if (firstTime) {
            buildDataFromService(successResponse.data[0]);
          }
   //       buildDataFromService(successResponse.data[0]);
          },
          function (failureResponse) {
            $log.debug("Dynamic view case docket (" + $scope.widgetIdentifier + ") getDynamicViewCaseDocketData failure response: ");
            $log.debug(failureResponse);
            /* istanbul ignore if: toaster error  */
            if (failureResponse.status === 404) {
              $scope.enableloading = false;
              $scope.refreshFailed = false;
              $scope.dateValid = false;
              $scope.refreshDate = new Date();
              CommonHelperService.setToastr(failureResponse.data.message, "info");
              $scope.noRecordsFound = true;
            } else {
              $scope.refreshFailed = true;
              $scope.refreshFailedate = new Date();
              $scope.enableloading = false;
              if (angular.isUndefined($scope.refreshDate) || $scope.refreshDate === null) {
                $scope.dateValid = true;
              }
            }
          }).finally(function () {
          $scope.isLoading = false;
          
        });

    }

    function buildDataFromService(successResponseData) {


      $scope.myData = successResponseData;
      $scope.caseDetailsDataViewCaseDoc = $scope.myData.caseDetailsData;
      $scope.showDynamicGrid = true;
      $scope.laterSelected = [];
      $scope.enableloading = false;
      $scope.refreshFailed = false;
      $scope.dateValid = false;
      $scope.refreshDate = new Date();
      $scope.isInColumnDetails = false;
      
      clearData();
      getNoOfCases(successResponseData);
      if (angular.isDefined(successResponseData)) {
        if ($scope.isJudge) {
          $scope.customData = successResponseData.customData;
          if ($scope.customData.length > 0 && !fromTab) {
            $scope.customData.forEach(function (data) {
              var isColumnDetails = false;
              if (data.columnName) {
                if (data.columnName.length > 0) {
                  successResponseData.columnDetails.forEach(function (element) {
                      if (!isColumnDetails && element.columnName[0] === data.columnName[0]) {
                        element.columnLabel = data.columnLabel;
                        element.columnName = data.columnName;
                        $scope.isInColumnDetails = true;
                        isColumnDetails = true;

                      }
                      //   else {
                      //    $scope.laterSelected.push(element);
                      // }
                    }

                  );
                  $scope.selectedColumns.forEach(function (selctedData) {
                    if (selctedData.columnName) {
                      if (selctedData.columnName.length > 0) {

                        if (data.columnName[0] === selctedData.columnName[0]) {
                          selctedData.columnLabel = data.columnLabel;
                          selctedData.columnName = data.columnName;
                        }

                      }
                    }

                  });
                  if (!isColumnDetails) {
                    $scope.laterSelected.push(data);
                  }

                }
              }

            });

          }
          if ($scope.laterSelected.length > 0) {
            $scope.laterSelected.forEach(function (ele) {
              successResponseData.columnDetails.push(ele);
              $scope.selectedColumns.push(ele);
            });
          }


        }
        $scope.myData = successResponseData;
        $scope.caseDetailsDataViewCaseDoc = $scope.myData.caseDetailsData;
        $scope.updatedColumnList = successResponseData.columnDetails;
        var setColumnsResponse = CommonHelperService.setColumnDefinitions($scope.myData.columnDetails);
        var hasFilterFlag = setColumnsResponse.filterCount;

        updateColumnDefs(setColumnsResponse.colDefs);
        $scope.gridOptions.paginationPageSize = $scope.myData.paginationSize;
        $scope.gridOptions.data = CommonHelperService.setGridData(hasFilterFlag, $scope.myData.caseDetailsData, setColumnsResponse.colDefs);
        if (hasFilterFlag > 0) {

          $scope.numberOfFilters = hasFilterFlag;

          var filteredData = SearchHelperService.filterTable($scope.myData, setColumnsResponse.colDefs);
          $scope.gridOptions.data = filteredData;
        } else {
          $scope.numberOfFilters = 0;
          $scope.gridOptions.data = $scope.myData.caseDetailsData;
        }

        $timeout($scope.setPaginationManually, 700);
        $scope.noRecordsFound = true;
        $timeout(function () {
          initialLoad = false;
        }, 2000);
        // Get APJ#
        angular.forEach($scope.gridOptions.data, function (row) {
          console.log('row: ', row);
          row.LAST_MOD_TS = setApjNumber(row);
        });
        console.log("Added ajp number: ", $scope.gridOptions.data);
      }
      $log.debug("Dynamic view case docket (" + $scope.widgetIdentifier + ") getDynamicViewCaseDocketData success response: ");
     
    }

    function setApjNumber(row) {
      if (row.APJ1_WORKER_ID === $scope.selectedJudge.assigneeFullNameText) {
        return 1;
      } else if (row.APJ2_WORKER_ID === $scope.selectedJudge.assigneeFullNameText) {
        return 2;
      } else if (row.APJ3_WORKER_ID === $scope.selectedJudge.assigneeFullNameText) {
        return 3;
      } else if (row.APJ4_WORKER_ID === $scope.selectedJudge.assigneeFullNameText) {
        return 4;
      } else if (row.APJ5_WORKER_ID === $scope.selectedJudge.assigneeFullNameText) {
        return 5;
      } else if (row.APJ16WORKER_ID === $scope.selectedJudge.assigneeFullNameText) {
        return 6;
      } else if (row.APJ7_WORKER_ID === $scope.selectedJudge.assigneeFullNameText) {
        return 7;
      } else if (row.APJ8_WORKER_ID === $scope.selectedJudge.assigneeFullNameText) {
        return 8;
      } else if (row.APJ9_WORKER_ID === $scope.selectedJudge.assigneeFullNameText) {
        return 9;
      } else {
        return "";
      }
    }

    function getNoOfCases(totalCases) {
      console.log('totalCases: ', totalCases);
      angular.forEach(totalCases.caseDetailsData, function (eachCase) {
        if (eachCase.APJ1_WORKER_ID && eachCase.APJ1_WORKER_ID.trim() === $scope.selectedJudge.assigneeFullNameText.trim()) {
          checkProceedingType(eachCase.PROCEEDING_TYPE_CT, 1, eachCase);
        } else if (eachCase.APJ2_WORKER_ID && eachCase.APJ2_WORKER_ID.trim() === $scope.selectedJudge.assigneeFullNameText.trim()) {
          checkProceedingType(eachCase.PROCEEDING_TYPE_CT, 2, eachCase);
        } else if (eachCase.APJ3_WORKER_ID && eachCase.APJ3_WORKER_ID.trim() === $scope.selectedJudge.assigneeFullNameText.trim()) {
          checkProceedingType(eachCase.PROCEEDING_TYPE_CT, 3, eachCase);
        } else if (eachCase.APJ4_WORKER_ID && eachCase.APJ4_WORKER_ID.trim() === $scope.selectedJudge.assigneeFullNameText.trim()) {
          checkProceedingType(eachCase.PROCEEDING_TYPE_CT, 4, eachCase);
        } else if (eachCase.APJ5_WORKER_ID && eachCase.APJ5_WORKER_ID.trim() === $scope.selectedJudge.assigneeFullNameText.trim()) {
          checkProceedingType(eachCase.PROCEEDING_TYPE_CT, 5, eachCase);
        } else if (eachCase.APJ6_WORKER_ID && eachCase.APJ6_WORKER_ID.trim() === $scope.selectedJudge.assigneeFullNameText.trim()) {
          checkProceedingType(eachCase.PROCEEDING_TYPE_CT, 6, eachCase);
        } else if (eachCase.APJ7_WORKER_ID && eachCase.APJ7_WORKER_ID.trim() === $scope.selectedJudge.assigneeFullNameText.trim()) {
          checkProceedingType(eachCase.PROCEEDING_TYPE_CT, 7, eachCase);
        } else if (eachCase.APJ8_WORKER_ID && eachCase.APJ8_WORKER_ID.trim() === $scope.selectedJudge.assigneeFullNameText.trim()) {
          checkProceedingType(eachCase.PROCEEDING_TYPE_CT, 8, eachCase);
        } else if (eachCase.APJ9_WORKER_ID && eachCase.APJ9_WORKER_ID.trim() === $scope.selectedJudge.assigneeFullNameText.trim()) {
          checkProceedingType(eachCase.PROCEEDING_TYPE_CT, 9, eachCase);
        }
      });
      $scope.noOfCases.noOfAppealsCases = $scope.noOfCases.apj1AppealsCases + $scope.noOfCases.apj2AppealsCases + $scope.noOfCases.apj3PlusAppealsCases;
      $scope.noOfCases.noOfTrialsCases = $scope.noOfCases.apj1TrialsCases + $scope.noOfCases.apj2TrialsCases + $scope.noOfCases.apj3PlusTrialsCases;
    }

    function checkProceedingType(proceedingType, judgeRank, eachCase) {
      if (proceedingType) {
        if (proceedingType.toLowerCase() === 'appeal') {
          addToCounter('appeals', judgeRank, eachCase);
        }
        if (proceedingType.toLowerCase() === 'trial') {
          addToCounter('trials', judgeRank, eachCase);
        }
      }
    }

    function addToCounter(proceedingType, judgeRank, eachCase) {
      if (judgeRank === 1) {
        if (proceedingType === 'appeals') {
          $scope.noOfCases.apj1AppealsCases++;
          $scope.totalCasesByNumber.totalApj1Appeal.push(eachCase);
        } else if (proceedingType === 'trials') {
          $scope.noOfCases.apj1TrialsCases++;
          $scope.totalCasesByNumber.totalApj1Trials.push(eachCase);
        }
        $scope.totalCasesByNumber.totalApj1Cases.push(eachCase);
      } else if (judgeRank === 2) {
        if (proceedingType === 'appeals') {
          $scope.noOfCases.apj2AppealsCases++;
          $scope.totalCasesByNumber.totalApj2Appeal.push(eachCase);
        } else if (proceedingType === 'trials') {
          $scope.noOfCases.apj2TrialsCases++;
          $scope.totalCasesByNumber.totalApj2Trials.push(eachCase);
        }
        $scope.totalCasesByNumber.totalApj2Cases.push(eachCase);
      } else if (judgeRank >= 3) {
        if (proceedingType === 'appeals') {
          $scope.noOfCases.apj3PlusAppealsCases++;
          $scope.totalCasesByNumber.totalApj3Appeal.push(eachCase);
        } else if (proceedingType === 'trials') {
          $scope.noOfCases.apj3PlusTrialsCases++;
          $scope.totalCasesByNumber.totalApj3Trials.push(eachCase);
        }
        $scope.totalCasesByNumber.totalApj3Cases.push(eachCase);
      }
    }

    $scope.showFilteredList = function (apjValue) {
      $scope.popoverVisible = false;
      switch (apjValue) {
        case 'apj1Total':
          $scope.gridOptions.data = $scope.totalCasesByNumber.totalApj1Cases;
          break;
        case 'apj1Appeals':
          $scope.gridOptions.data = $scope.totalCasesByNumber.totalApj1Appeal;
          break;
        case 'apj1Trials':
          $scope.gridOptions.data = $scope.totalCasesByNumber.totalApj1Trials;
          break;
        case 'apj2Total':
          $scope.gridOptions.data = $scope.totalCasesByNumber.totalApj2Cases;
          break;
        case 'apj2Appeals':
          $scope.gridOptions.data = $scope.totalCasesByNumber.totalApj2Appeal;
          break;
        case 'apj2Trials':
          $scope.gridOptions.data = $scope.totalCasesByNumber.totalApj2Trials;
          break;
        case 'apj3Total':
          $scope.gridOptions.data = $scope.totalCasesByNumber.totalApj3Cases;
          break;
        case 'apj3Appeals':
          $scope.gridOptions.data = $scope.totalCasesByNumber.totalApj3Appeal;
          break;
        case 'apj3Trials':
          $scope.gridOptions.data = $scope.totalCasesByNumber.totalApj3Trials;
          break;
        default:
          break;
      }
    };

    // $scope.getDynamicViewCaseDocketData();

    $scope.toggleFiltering = function () {

      if (angular.isDefined($scope.gridApi)) {
        $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
      }

      $scope.gridApi.grid.clearAllFilters();
      $scope.gridOptions.data = $scope.myData.caseDetailsData;
      $scope.numberOfFilters = 0;
    };

    $scope.showFilteringHelp = function () {
      ngDialog.open({
        template: 'app/components/helperComponents/filterHelp/filteringHelp.html',
        controller: 'CommonDialogController',
        controllerAs: 'vm',
        showClose: false
      });
    };

    $scope.sortableOptions = {
      containment: '#docketColums',
      scroll: true,
      axis: 'y',
      cursor: 'move',
      scrollSpeed: 2,
      scrollSensitivity: 160,
      update: function () {
        $rootScope.viewCaseColumnsChanged = true;
      }
    };

    /* istanbul ignore next  */
    $scope.updateColumns = function () {
      var loadingWidget = document.getElementById($scope.widgetIdentifier);
      loadingWidget.style.display = "inline-block";
      var docketScopeList = angular.element(document.getElementById('docketColums')).scope();
      var columnsSelected = [];
      var fromModal = false;
      if (angular.isDefined(docketScopeList)) {
        columnsSelected = angular.copy(docketScopeList.selectedCols);
        angular.forEach(docketScopeList.availableCols, function (available) {
          columnsSelected.push(available);
        });
        fromModal = true;
      } else {
        columnsSelected = $scope.selectedColumns;
      }

      var updatedColumns = CommonHelperService.setColumnsToUpdate(columnsSelected, fromModal, $scope.gridState, $scope.widgetIdentifier);

      if (angular.isDefined(docketScopeList)) {
        docketScopeList.originShowHide = angular.copy(updatedColumns.selectedColumns);
      }

      HttpFactory.putActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS, updatedColumns)
        .then(function (successResponse) {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.gridSave, "success");
            resetUnsavedChangesFlags();
            var newData = successResponse.data[0];
            $scope.updatedColumnList = newData.columnDetails;

            var setColumnsResponse = CommonHelperService.setColumnDefinitions($scope.updatedColumnList);
            var hasFilterFlag = setColumnsResponse.filterCount;

            $scope.numberOfFilters = hasFilterFlag;
            if (fromModal) {
              var allGrids = document.getElementsByClassName('ui-grid');
              for (var j = 0; j < allGrids.length; j++) {
                if (angular.element(allGrids[j]).scope().widgetIdentifier === $scope.widgetIdentifier) {
                  updateColumnDefs(setColumnsResponse.colDefs);

                  angular.element(allGrids[j]).scope().gridOptions.rowHeight = $scope.gridOptions.rowHeight;
                  angular.element(allGrids[j]).scope().gridOptions.columnDefs = $scope.gridOptions.columnDefs;
                  if ($scope.numberOfFilters > 0) {
                    var filteredData = SearchHelperService.filterTable($scope.myData, setColumnsResponse.colDefs);
                    angular.element(allGrids[j]).scope().gridOptions.data = filteredData;
                  } else {
                    angular.element(allGrids[j]).scope().gridOptions.data = successResponse.data[0].caseDetailsData;
                  }
                  break;
                }
              }
              $rootScope.viewCaseColumnsChanged = false;
            } else {
              updateColumnDefs(setColumnsResponse.colDefs);

              $scope.gridOptions.data = CommonHelperService.setGridData(hasFilterFlag, newData.caseDetailsData, setColumnsResponse.colDefs);
            }
            // }

            $scope.noRecordsFound = true;
          },
          function () {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.gridSaveFail, "error");
          }).finally(function () {

          loadingWidget.style.display = "none";
          // loadingWidget

          console.dir($scope);
          $scope.gearLoading = false;
          $scope.isLoading = false;
          $scope.$$prevSibling.isLoading = false;
          $scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.isLoading = false;
        });
    };

    $scope.moveItem = function (origin, destination) {
      var temp = $scope.selectedCols[destination];
      $log.debug("Initial");
      $log.debug($scope.selectedCols);
      $scope.selectedCols[destination] = $scope.selectedCols[origin];
      $log.debug("Origin moved to destination");
      $log.debug($scope.selectedCols);
      $scope.selectedCols[origin] = temp;
      $log.debug("Final");
      $log.debug($scope.selectedCols);
      $scope.vcdListOrderChanged = true;
      $rootScope.viewCaseColumnsChanged = true;
    };

    $scope.listItemUp = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex - 1);
    };

    $scope.listItemDown = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex + 1);
    };
    /* istanbul ignore next*/
    $scope.moveSourcetoDestination = function () {

      angular.forEach($scope.clickedColumn, function (column) {
        column.visible = true;
        $scope.selectedCols.push($scope.availableCols[$scope.availableCols.indexOf(column)]);
        $scope.availableCols.splice($scope.availableCols.indexOf(column), 1);
      });

      $scope.clickedColumn = [];
      $rootScope.viewCaseColumnsChanged = true;
      clearMulti();
    };
    $scope.ext = [];
    $scope.enableMoveButton = false;

    $scope.clickedColumn = [];
    /* istanbul ignore next*/
    $scope.requestData = function (event, Selected) {
      $scope.enableMoveButton = true;
      if (event.ctrlKey || event.shiftKey) {
        $scope.clickedColumn.push(Selected);
      } else {
        $scope.clickedColumn = [];
        $scope.clickedColumn.push(Selected);
      }
    };
    $scope.moveSourcetoDestinationData = function (source, destination) {
      if ($scope.ext.length !== 0) {

        for (var i = 0; i < $scope.ext.length; i++) {

          source.splice(source.indexOf($scope.ext[i]), 1);
          if (!$scope.ext[i].visible) {
            $scope.ext[i].visible = true;
            destination.push($scope.ext[i]);
          }
        }

      } else {
        source.splice(source.indexOf($scope.newColumn), 1);
        if (!$scope.newColumn.visible) {
          $scope.newColumn.visible = true;
          destination.push($scope.newColumn);
        }
      }
      $scope.enableMoveButton = false;
      $scope.ext = [];
    };

    $scope.moveSourcetoDestinationCancel = function (index) {
      $scope.selectedCols[index].visible = false;
      $scope.availableCols.push($scope.selectedCols[index]);
      $scope.selectedCols.splice(index, 1);
      $rootScope.viewCaseColumnsChanged = true;
    };

    /* istanbul ignore next  */
    $scope.exportData = function () {
      var headers = [];
      angular.forEach($scope.updatedColumnList, function (coldata) {
        headers.push(coldata.columnLabel);
      });
      var fields = [];
      angular.forEach($scope.updatedColumnList, function (coldata) {

        if (coldata.columnName[0] === 'FK_ASSIGNEE_BE_NO') {
          fields.push([coldata.columnName[1], coldata.columnType]);
        } else {
          fields.push([coldata.columnName[0], coldata.columnType]);
        }
      });
      var replacer = function (key, value) {
        return value === null ? '' : value;
      };
      var csv = $scope.caseDetailsDataViewCaseDoc.map(function (row) {
        return fields.map(function (fieldName) {
          if (fieldName[1] === 'date') {
            if (row[fieldName[0]] === null) {
              return "";
            }
            if (fieldName[0] === 'LAST_MODIFIED_TS') {
              return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy hh:mm:ss a') + " ";
            } else {
              return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy') + " ";
            }
          } else if (fieldName[1] === 'string') {
            if (fieldName[0] === 'ALL_DISPOSITION_TX') {
              if (row.hasOwnProperty('ALL_DISPOSITION_TX')) {
                if (row[fieldName[0]] === "") {
                  return "";
                } else {
                  return JSON.stringify(convertArrayToString(row[fieldName[0]]), replacer);
                }
              } else {
                return "";
              }

            } else if (fieldName[0] === "ADDITIONAL_APJ_WORKER_ID_TX") {
              return JSON.stringify(setPanelColumnForExport(row));
            } else if (fieldName[0] === "DECISION_DUE_DAYS") {
              return "";
            } else {
              return JSON.stringify(row[fieldName[0]], replacer);
            }
          } else {
            return JSON.stringify(row[fieldName[0]], replacer);
          }
        }).join(',');
      });
      csv.unshift(headers.join(','));
      csv = csv.join('\r\n');
      var hiddenElement = document.createElement('a');
      hiddenElement.href = URL.createObjectURL(new Blob([csv], {
        type: 'text/csv'
      }));
      hiddenElement.target = '_blank';
      hiddenElement.download = 'ViewCaseDocket_FullDocket_' + CommonHelperService.getCurrentTime() + '.csv';
      hiddenElement.click();
    };

    function setPanelColumnForExport(row) {
      var judgePanel = "";
      if (row.APJ1_WORKER_ID.trim() !== "") {
        judgePanel += row.APJ1_WORKER_ID.trim();
      }
      if (row.ATTORNEY_WORKER_ID.trim() !== "") {
        judgePanel += ' (' + row.ATTORNEY_WORKER_ID.trim() + ')';
      }
      if (row.APJ2_WORKER_ID.trim() !== "") {
        judgePanel += ' | ' + row.APJ2_WORKER_ID.trim();
      }
      if (row.APJ3_WORKER_ID.trim() !== "") {
        judgePanel += ' | ' + row.APJ3_WORKER_ID.trim();
      }
      if (row.APJ4_WORKER_ID.trim() !== "") {
        judgePanel += ' | ' + row.APJ4_WORKER_ID.trim();
      }
      if (row.APJ5_WORKER_ID.trim() !== "") {
        judgePanel += ' | ' + row.APJ5_WORKER_ID.trim();
      }
      if (row.APJ6_WORKER_ID.trim() !== "") {
        judgePanel += ' | ' + row.APJ6_WORKER_ID.trim();
      }
      if (row.APJ7_WORKER_ID.trim() !== "") {
        judgePanel += ' | ' + row.APJ7_WORKER_ID.trim();
      }
      if (row.APJ8_WORKER_ID.trim() !== "") {
        judgePanel += ' | ' + row.APJ8_WORKER_ID.trim();
      }
      if (row.APJ9_WORKER_ID.trim() !== "") {
        judgePanel += ' | ' + row.APJ9_WORKER_ID.trim();
      }
      return judgePanel;
    }


    i18nService.get('en').gridMenu.exporterAllAsCsv = 'Export filtered data as csv';
    i18nService.get('en').gridMenu.exporterVisibleAsCsv = 'Export this page as csv';
    i18nService.get('en').gridMenu.exporterSelectedAsCsv = 'Export selected as csv';
    /* istanbul ignore next  */
    $scope.saveGridPreferences = function () {
      if ($scope.gridApi) {
        $scope.gridState = CommonHelperService.setGridWidthMap($scope.gridApi.saveState.save());
        $scope.isLoading = true;
      } else if ($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi) {
        $scope.gridState = CommonHelperService.setGridWidthMap($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi.saveState.save());
        $scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gearLoading = true;
        $scope.gearLoading = true;
      }

      $scope.updateColumns();
    };

    $scope.paginationManual = false;
    $scope.setPaginationManually = function () {
      $scope.paginationManual = false;
    };
    /* istanbul ignore next  */
    $rootScope.$on('adfCustomizeWidgetServiceCall', function () {
      if ($rootScope.widgetIdentifier === $scope.widgetIdentifier) {
        switch ($rootScope.widgetHeight) {
          case "widgetHeightSmall":
            $scope.gridOptions.paginationPageSize = $scope.gridOptions.paginationPageSizes[0];
            break;
          case "widgetHeightMedium":
            $scope.gridOptions.paginationPageSize = $scope.gridOptions.paginationPageSizes[1];
            break;
          case "widgetHeightLarge":
            $scope.gridOptions.paginationPageSize = $scope.gridOptions.paginationPageSizes[2];
            break;
          case "widgetHeightXlarge":
            $scope.gridOptions.paginationPageSize = $scope.gridOptions.paginationPageSizes[3];
            break;
          default:
            break;
        }
        $scope.paginationManual = true;
        $log.debug("Executed after save widget size for View case docket (" + $scope.widgetIdentifier + ")");
        $timeout($scope.setPaginationManually, 500);
      }
    });

    $scope.toggleSelectAll = function () {
      angular.forEach($scope.availableCols, function (column) {
        column.visible = true;
        $scope.selectedCols.push(column);
      });
      $scope.availableCols = [];
      $rootScope.viewCaseColumnsChanged = true;

    };

    $scope.removeAll = function () {
      var tempArray = [];
      $rootScope.viewCaseColumnsChanged = true;
      angular.forEach($scope.selectedCols, function (column) {
        if (!column.mandatory) {
          column.visible = false;
          $scope.availableCols.push(column);
        } else {
          tempArray.push(column);
        }
      });
      $scope.selectedCols = tempArray;
    };

    /* istanbul ignore next  */
    $scope.areAllSelected = function () {
      var columnList = angular.element(document.getElementById('docketColums')).scope();
      for (var i = 0; i < columnList.selectedColumns.length; i++) {
        if (!columnList.selectedColumns[i].visible) {
          $scope.selectUnselect = false;
          break;
        } else {
          $scope.selectUnselect = true;
        }
        $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
      }
    };
    /* istanbul ignore next  */
    function checkForUnsavedChanges() {
      if (!initialLoad) {
        if (isFilterChanged || isColumnVisibilityChanged || isColumnSizeChanged || isSortChanged || isColumnPositionChanged || isPaginationChanged || isColumnPinnedChanged) {
          $scope.preferencesChanged = true;
          $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_PREFERENCES;
        } else {
          $scope.preferencesChanged = false;
          $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
        }
      }

    }

    $scope.refreshDynamicViewCaseDocketData = function () {
      $scope.isLoading = true;
      $scope.enableloading = true;
      $scope.refreshFailed = false;
      $scope.refreshDate === undefined || null;
      $scope.preferencesChanged = false;
      $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
      $scope.getDynamicViewCaseDocketData();
      if ($scope.selectedJudge.assigneeFullNameText !== "All judges") {
        getClosedCases();
      }
      
    };

    $scope.getKeyDates = function (row) {
      ngDialog.open({
        template: 'app/components/widgets/viewCaseDockets/src/keyDatesModal.html',
        controller: 'KeyDatesModalController',
        width: '20%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,
        resolve: {
          row: function () {
            return row;
          }
        }
      }).closePromise.then(function () {
        // No need to handle return.
      }, function () {
        // Cancel from modal
      });
    };
    $scope.panelData = function (row) {
      $scope.panelMembers = [];
      if (angular.isDefined(row.entity.APJ1_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ1_WORKER_ID);
      }
      if (angular.isDefined(row.entity.APJ2_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ2_WORKER_ID);
      }
      if (angular.isDefined(row.entity.APJ3_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ3_WORKER_ID);
      }
      if (angular.isDefined(row.entity.APJ4_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ4_WORKER_ID);
      }
      if (angular.isDefined(row.entity.APJ5_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ5_WORKER_ID);
      }
      if (angular.isDefined(row.entity.APJ6_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ6_WORKER_ID);
      }
      if (angular.isDefined(row.entity.APJ7_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ7_WORKER_ID);
      }
      if (angular.isDefined(row.entity.APJ8_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ8_WORKER_ID);
      }
      if (angular.isDefined(row.entity.APJ9_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ9_WORKER_ID);
      }
    };

    $scope.getTechCenter = function (artUnit) {
      return artUnit.substring(2, 0) + "00";
    };

    $scope.searchForJudge = function (input) {
      var tempList = [];
      if (angular.isDefined(input) && input.fullName.trim() !== "") {
        angular.forEach($scope.originalJudgeList, function (currentJudge) {
          if (currentJudge.assigneeFullNameText.toLowerCase().includes(input.fullName.toLowerCase())) {
            tempList.push(currentJudge);
          }
        });
        $scope.judgeList = angular.copy(tempList);
      } else {
        $scope.judgeList = angular.copy($scope.originalJudgeList);
      }
    };

  });
