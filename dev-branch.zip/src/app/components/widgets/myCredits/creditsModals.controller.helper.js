'use strict';
angular.module('ptabe2e').factory('CreditsModalControllerHelper', function($q) {
    var creditsModalControllerHelper = {
            getAssignmentTypeObject : getAssignmentTypeObject
    };

    /**
     * This method read the spreadsheet rows creates valid and invalid row information
     */
    function getAssignmentTypeObject(assignmentTypeValue, stndAssignmentTypes) {
        var foundObject=null;
        angular.forEach(stndAssignmentTypes, function(assignmentType) {
          if (assignmentType.assignmentTypeId == assignmentTypeValue) {
            foundObject = assignmentType;
          }
        });
        return foundObject;
    }
    /**
     * This is object for Credits Modal controller helper.
     */
    return creditsModalControllerHelper;
});