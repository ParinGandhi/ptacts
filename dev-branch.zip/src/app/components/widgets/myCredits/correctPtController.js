(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .directive('ptFileModel', ['$parse', /* istanbul ignore next */ function ($parse) {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {

          element.bind('change', function () {
            scope.$apply(function () {
              // intentional
            });
          });
        }
      };
    }])

    .directive('ptChange', /* istanbul ignore next */ function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var onChangeFunc = scope.$eval(attrs.ptChange);
          element.bind('change', onChangeFunc);
        }
      };
    })
    .controller('correctPtController', function ($scope, ngDialog, rowData, widgetIdentifier, HttpFactory, CONSTANTS, toastr, $log) {
        var vm = this;
        var scope = angular.element(document.getElementById('mainTabId')).scope();
        vm.userInfo = scope.vm.userInfo;
        vm.caseNumber = rowData.entity.appealNumber;
        vm.currentPa = rowData.entity.patentTimeliness;
        vm.newPt = "";
        vm.sendRequestEmailId = "";
        vm.completionDateLabel = "Decision mail date";
        vm.title = rowData.entity.type + " patent attorney timeliness (PT)";
        vm.correctPtReason = "";
        vm.assignmentId = rowData.entity.ptabAssignmentId;
        vm.assignmentTitle = rowData.entity.assignmentTitle;
        vm.appealNumber = rowData.entity.appealNumber;
        vm.assignmentType = rowData.entity.assignmentType;
        vm.decisionalUnitsAwarded = rowData.entity.decisionalUnitsAwarded;
        vm.lockControlNumber = rowData.entity.lockControlNumber;
        vm.caseType = rowData.entity.caseType;
        vm.serialNumber = rowData.entity.serialNumber;
        vm.completionDate = rowData.entity.completionDate;
        vm.qualifier = rowData.entity.qualifier;
        vm.specialTypeTooltip = CONSTANTS.SPECIAL_TYPE_REQUEST.tooltip;
        vm.specialType = rowData.entity.specialType;
        vm.appealDueDate = rowData.entity.appealDueDate,
          vm.creditAwardId = rowData.entity.creditAwardId;
        vm.originalcorrectPtReason = angular.copy(vm.correctPtReason);
        vm.originalnewPt = angular.copy(vm.newPt);
        vm.originalsendRequestEmailId = angular.copy(vm.sendRequestEmailId);
        var ptFile;
        var reader = new FileReader();
        var fileByteArray = [];

        vm.checkReason = function () {
          if (vm.correctPtReason === null || vm.correctPtReason === "" || angular.isUndefined(vm.correctPtReason)) {
            vm.errorMessageForReason = "Reason is mandatory";
            vm.showErrorMessageReason = true;
            vm.readyToSaveReason = false;
          } else {
            vm.showErrorMessageReason = false;
            vm.readyToSaveReason = true;
          }
        };
        if (vm.title.indexOf('Correct') >= 0) {
          vm.readyToSavesendRequestEmailId = true;
        }
        vm.checkSendReqEmailid = function () {
          if (vm.title.indexOf('Correct') < 0) {
            if (vm.sendRequestEmailId === null || vm.sendRequestEmailId === "" || angular.isUndefined(vm.sendRequestEmailId)) {
              vm.errorMessageForsendRequestEmailId = " Email address is mandatory";
              vm.showErrorMessagesendRequestEmailId = true;
              vm.readyToSavesendRequestEmailId = false;
            } else {
              vm.showErrorMessagesendRequestEmailId = false;
              vm.readyToSavesendRequestEmailId = true;
            }
          }
        };

        vm.checkPt = function () {
          if (vm.newPt === null || vm.newPt === "" || angular.isUndefined(vm.newPt)) {
            vm.errorMessageForPt = "Requested due date points is mandatory";
            vm.showErrorMessagePt = true;
            vm.readyToSavePt = false;
          } else {
            vm.showErrorMessagePt = false;
            vm.readyToSavePt = true;
          }
        };


        vm.checkMandatoryFields = function () {
          vm.checkReason();
          vm.checkSendReqEmailid();
          vm.checkPt();
        };

        vm.abandonChanges = function () {
          if (!angular.equals(vm.newPt, vm.originalnewPt) ||
            !angular.equals(vm.originalcorrectPtReason, vm.correctPtReason) ||
            !angular.equals(vm.originalsendRequestEmailId, vm.sendRequestEmailId)) {
            ngDialog.open({
              template: 'app/components/widgets/myCredits/cancelChanges.html',
              controller: 'CancelChangesController',
              controllerAs: 'vm',
              width: '25%',
              showClose: false,
              closeByEscape: false,
              closeByDocument: false
            }).closePromise.then(function () {
              $log.info("Changes abandoned");
            });
          } else {
            ngDialog.closeAll();
          }
        };

        /* istanbul ignore next */
        $scope.getFileInfo = function (file) {
          ptFile = document.getElementById("fileP");
          $scope.fileInfo = {};
          $scope.fileInfo.name = ptFile.files[0].name;
          $scope.fileInfo.path = ptFile.value;
          reader.readAsArrayBuffer(ptFile.files[0]);
          reader.onloadend = function (evt) {
            if (evt.target.readyState == FileReader.DONE) {
              var arrayBuffer = evt.target.result,
                array = new Uint8Array(arrayBuffer);
              for (var i = 0; i < array.length; i++) {
                fileByteArray.push(array[i]);
              }
            }
          };
        };

        vm.clearFile = function () {
          $scope.fileInfo = {};
        };


        /* istanbul ignore next */
        vm.correctPt = function () {
          vm.checkMandatoryFields();
          if (vm.readyToSavePt && vm.readyToSaveReason && vm.readyToSavesendRequestEmailId) {
            vm.checkMandatoryFields();
            var data = {
              "currentPatentTimeliness": (vm.currentPa != null || vm.currentPa != undefined) ? vm.currentPa : null,
              "requestedPatentTimeliness": vm.newPt,
              "reason": vm.correctPtReason,
              "completionDate": vm.completionDate,
              "appealNumber": (vm.appealNumber != null || vm.appealNumber != undefined) ? vm.appealNumber : null,
              "serialNumber": vm.serialNumber,
              "caseType": vm.caseType,
              "specialType": rowData.entity.specialType ? rowData.entity.specialType.trim() != "" ? rowData.entity.specialType : '' : '',
              "appealDueDate": (vm.appealDueDate != null || vm.appealDueDate != undefined) ? vm.appealDueDate : null,
              "sendRequestEmailAddress": vm.sendRequestEmailId,
              "audit": {
                "createUserIdentifier": vm.userInfo.userId,
                "lastModifiedUserIdentifier": vm.userInfo.userId
              },
              "patentTimelinessAwardedTo": vm.decisionalUnitsAwarded,
              "assignmentType": vm.assignmentType,
              "qualifier": vm.qualifier,
              "assignmentTitle": vm.assignmentTitle,
              "dateOfRequest": new Date().getTime(),
              "widgetIdentifier": widgetIdentifier,
              "fileName": ($scope.fileInfo != null || $scope.fileInfo != undefined) ? $scope.fileInfo.name : null,
              "attachmentInBytes": fileByteArray
            };
            vm.disableSubmit = true;
            HttpFactory.putActions("/credits/correct-patent-attorney-timeliness?requestType=PATENTATTORNEYTIMELINESS", data)
              .then(function () {
                vm.disableSubmit = true;
                toastr.success(CONSTANTS.TOASTER.PATSuccess);
                ngDialog.closeAll(true);

              }, function (failureResponse) {
                vm.disableSubmit = true;
                toastr.error(CONSTANTS.TOASTER.PATFail, {
                  iconClass: 'toast-danger'
                });
                vm.disableSubmit = false;
              });
          }
        };
      }

    );
})();
