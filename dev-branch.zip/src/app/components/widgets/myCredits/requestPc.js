(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .directive('aduFileModel', ['$parse', /* istanbul ignore next */ function ($parse) {
      return {
        restrict: 'A',
        link: function (scope, element) {
          element.bind('change', function () {
            scope.$apply(function () {
              // Implementaion not needed
            });
          });
        }
      };
    }])

    .directive('aduOnChange', /* istanbul ignore next */ function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var onChangeFunc = scope.$eval(attrs.aduOnChange);
          element.bind('change', onChangeFunc);
        }
      };
    })
    .controller('requestPcController', function ($scope, ngDialog, $timeout, items, userId, displayName, metaData, rowData, widgetIdentifier, HttpFactory, CONSTANTS, CommonHelperService) {
        var vm = this;
        vm.metaData = metaData;
        vm.metaData.caseTypes = [vm.metaData.caseType];
        vm.userId = userId;
        vm.displayName = displayName;
        vm.items = items;
        if (vm.items.entity.supervisorsData && vm.items.entity.supervisorsData.length > 0) {
          vm.currentSupervisor = vm.items.entity.supervisorsData[0].assigneeFullNameText;
          vm.originalsendRequestEmailId = vm.items.entity.supervisorsData[0].assigneeFullNameText;
        } else {
          vm.currentSupervisor = "";
        }


        // if (vm.items.entity.supervisorsData === null || vm.items.entity.supervisorsData === undefined) {
        //   vm.currentSupervisor = "Select supervisor";
        // } else {
        //   vm.currentSupervisor = vm.items.entity.supervisorsData[0].assigneeFullNameText;
        // }
        vm.ptabAssignmentIdentifier = vm.items.entity.ptabAssignmentIdentifier;
        vm.superviorResponse1;
        vm.supervisorList1 = [];
        vm.supervisorName = [];
        vm.isTrials = false;
        // vm.userInfo = scope.vm.userInfo;
        vm.role = vm.items.entity.roleName;
        vm.caseNumber = rowData.entity.appealNumber;
        vm.currentDU = rowData.entity.decisionalUnits;
        vm.currentADU = rowData.entity.additionalDecisionalUnits;
        vm.newADU = "";
        vm.decisionalUnitsAwarded = rowData.entity.decisionalUnitsAwarded;
        vm.decisionalUnitsAwardedIdentifier = rowData.entity.decisionalUnitsAwardedIdentifier;
        vm.totalDraftDecisionTimeMin = "00";
        if (vm.items.entity.isEdit) {
          // vm.totalDraftDecisionTime = vm.items.entity.recordHour;
          if (vm.items.entity.recordHour != null || vm.items.entity.recordHour !== undefined) {
            var x = vm.items.entity.recordHour;
            var tooString = x.toString();
            $scope.splitNum = tooString.split(".");
            var text = $scope.splitNum[0];
            var pointNum = parseFloat(text);
            vm.totalDraftDecisionTime = pointNum;
            if ($scope.splitNum.length == 1) {
              vm.totalDraftDecisionTimeMin = "00";
            } else if ($scope.splitNum.length > 1) {
              if ($scope.splitNum[1] === "3") {
                vm.totalDraftDecisionTimeMin = "30";
              } else {
                vm.totalDraftDecisionTimeMin = $scope.splitNum[1];
              }
            }
          }
          vm.newDU = vm.items.entity.creditQuantities;
          vm.correctDuReason = vm.items.entity.reason;
          vm.appealNumber = vm.items.entity.caseNumber;
          vm.decisionalUnitsAwarded = rowData.entity.apjOneName;
          $scope.fileInfo = {};
          if (items.entity.workProductUrl && items.entity.workProductUrl.trim() != "") {
            $scope.fileInfo.name = items.entity.workProductUrl.split(items.entity.serialNumber + "_").pop();
            vm.fullFileName = items.entity.workProductUrl;
          }
        } else {
          vm.totalDraftDecisionTime = "";
          vm.newDU = "";
          vm.correctDuReason = "";
          vm.appealNumber = rowData.entity.appealNumber;
        }
        vm.sendRequestEmailId = "";
        vm.todaysDate = new Date().getTime();
        vm.completionDateLabel = "Decision mail date";
        vm.assignmentId = rowData.entity.ptabAssignmentId;
        vm.assignmentTitle = rowData.entity.assignmentTitle;
        vm.assignmentType = rowData.entity.assignmentType;
        vm.lockControlNumber = rowData.entity.lockControlNumber;
        vm.caseType = rowData.entity.caseType;
        vm.serialNumber = rowData.entity.serialNumber;
        vm.completionDate = rowData.entity.completionDate;
        vm.qualifier = rowData.entity.qualifier;
        vm.specialType = vm.items.entity.specialType;
        vm.specialTypeTooltip = CONSTANTS.SPECIAL_TYPE_REQUEST.tooltip;
        vm.creditAwardId = rowData.entity.creditAwardId;
        // vm.requestType = requestType;
        vm.originalcorrectDuReason = angular.copy(vm.correctDuReason);
        vm.originalnewDU = angular.copy(vm.newDU);
        vm.originalDraftDecisionTime = angular.copy(vm.totalDraftDecisionTime);

        // vm.originalsendRequestEmailId = angular.copy(vm.sendRequestEmailId);
        vm.originalsendRequestEmailId = vm.currentSupervisor;
        vm.title = rowData.entity.type;
        var aduFile;
        var reader = new FileReader();
        var fileByteArray = [];
        vm.disableSubmit = false;

        $timeout(function () {
          vm.zIndex();
          vm.getSupervisor();
        }, 200);

        vm.zIndex = function () {
          if (document.getElementById('globalHeaderDiv')) {
            document.getElementById('globalHeaderDiv').style.zIndex = '9';
          }
        };

        vm.getSupervisor = function () {
          vm.supervisorList1 = [];
          HttpFactory.getActions("/user-management/supervisors/" + vm.userId)
            .then(function (successResponse) {
              vm.superviorResponse1 = successResponse.data;
              vm.superviorResponse1.forEach(function (element) {
                if (vm.currentSupervisor === element.assigneeFullNameText)
                  vm.supervisorList1.push(element);
              });
              if (vm.supervisorList1.length === 0 && vm.currentSupervisor !== "") {
                vm.supervisorList1.push(vm.items.entity.supervisorsData[0]);

              }
              vm.superviorResponse1.forEach(function (element) {
                if (vm.displayName !== element.assigneeFullNameText && vm.supervisorList1.length === 0 && vm.currentSupervisor === "") {
                  vm.supervisorList1.push(element);
                } else if (vm.displayName !== element.assigneeFullNameText && vm.currentSupervisor !== element.assigneeFullNameText && vm.supervisorList1[vm.supervisorList1.length - 1].assigneeFullNameText !== element.assigneeFullNameText) {
                  vm.supervisorList1.push(element);
                }
              });

              vm.sendRequestEmailId = vm.supervisorList1[0];

            }, function () {
              // Empty response is ok
            });
        };

        vm.checkReason = function () {
          if (vm.correctDuReason === null || vm.correctDuReason === "" || angular.isUndefined(vm.correctDuReason)) {
            vm.errorMessageForReason = "Reason is mandatory";
            vm.showErrorMessageReason = true;
            vm.readyToSaveReason = false;
          } else {
            vm.showErrorMessageReason = false;
            vm.readyToSaveReason = true;
          }
        };

        vm.checkSendReqEmailid = function () {

          if (vm.sendRequestEmailId.assigneeFullNameText === null || vm.sendRequestEmailId.assigneeFullNameText === "" || vm.sendRequestEmailId.assigneeFullNameText === "Select supervisor" || angular.isUndefined(vm.sendRequestEmailId)) {
            vm.errorMessageForsendRequestEmailId = " Supervisor is mandatory";
            vm.showErrorMessagesendRequestEmailId = true;
            vm.readyToSavesendRequestEmailId = false;
          } else {
            vm.showErrorMessagesendRequestEmailId = false;
            vm.readyToSavesendRequestEmailId = true;
          }
        };
        vm.checkDu = function () {
          if (vm.newDU === null || vm.newDU === "" || angular.isUndefined(vm.newDU)) {
            vm.errorMessageForDU = "Additional production credits are mandatory";
            vm.showErrorMessageDU = true;
            vm.readyToSaveDU = false;
          } else {
            vm.showErrorMessageDU = false;
            vm.readyToSaveDU = true;
          }
        };
        vm.checkDraftDecisionTime = function () {
          if ((vm.totalDraftDecisionTime === null || vm.totalDraftDecisionTime === "" || angular.isUndefined(vm.totalDraftDecisionTime) || vm.totalDraftDecisionTime === 0) && (vm.totalDraftDecisionTimeMin === "00" || vm.totalDraftDecisionTimeMin === undefined)) {
            vm.errorMessageFortotalDraftDecisionTime = "Time spent on assignment is mandatory";
            vm.showErrorMessagetotalDraftDecisionTime = true;
            vm.readyToSavetotalDraftDecisionTime = false;
          } else {
            vm.showErrorMessagetotalDraftDecisionTime = false;
            vm.readyToSaveDutotalDraftDecisionTime = true;
          }
        };
        vm.checkMandatoryFields = function () {
          vm.checkReason();
          vm.checkSendReqEmailid();
          vm.checkDu();
          vm.checkDraftDecisionTime();

        };
        vm.abandonChanges = function () {
          if (vm.originalsendRequestEmailId === undefined || vm.originalsendRequestEmailId === null || vm.originalsendRequestEmailId === "") {
            vm.originalsendRequestEmailId = vm.sendRequestEmailId.assigneeFullNameText;
          }

          if (!angular.equals(vm.newDU, vm.originalnewDU) ||
            !angular.equals(vm.originalcorrectDuReason, vm.correctDuReason) ||
            !angular.equals(vm.totalDraftDecisionTime, vm.originalDraftDecisionTime) ||
            !angular.equals(vm.originalsendRequestEmailId, vm.sendRequestEmailId.assigneeFullNameText)) {
            ngDialog.open({
              template: 'app/components/widgets/myCredits/cancelChanges.html',
              controller: 'CancelChangesController',
              controllerAs: 'vm',
              width: '25%',
              showClose: false,
              closeByEscape: false,
              closeByDocument: false


            }).closePromise.then(function () {
              // Modal handles services actions
            });
          } else {
            ngDialog.closeAll();
          }
        };

        /* istanbul ignore next */
        $scope.getFileInfo = function (file) {
          aduFile = document.getElementById("file1");
          $scope.fileInfo = {};
          $scope.fileInfo.name = aduFile.files[0].name;
          $scope.fileInfo.path = aduFile.value;
          reader.readAsArrayBuffer(aduFile.files[0]);
          reader.onloadend = function (evt) {
            if (evt.target.readyState == FileReader.DONE) {
              var arrayBuffer = evt.target.result,
                array = new Uint8Array(arrayBuffer);
              for (var i = 0; i < array.length; i++) {
                fileByteArray.push(array[i]);
              }
            }
          };
        };

        vm.clearFile = function () {
          $scope.fileInfo = {};
        };


        /* istanbul ignore next */
        vm.correctCredits = function (isSave) {
          vm.checkMandatoryFields();
          if (vm.totalDraftDecisionTime === null || vm.totalDraftDecisionTime === "" || angular.isUndefined(vm.totalDraftDecisionTime)) {
            vm.totalDraftDecisionTime = 0;
          }
          vm.totalDraftDecisionTimeTot = vm.totalDraftDecisionTime + "." + vm.totalDraftDecisionTimeMin;

          if (vm.readyToSaveDU && vm.readyToSaveReason && vm.readyToSaveDutotalDraftDecisionTime && vm.readyToSavesendRequestEmailId) {
            vm.checkMandatoryFields();

            var data = {
              "decisionalUnits": vm.currentDU,
              "requestedDecisionalUnits": vm.newDU,
              "ptabAssignmentIdentifier": vm.ptabAssignmentIdentifier,
              "reason": vm.correctDuReason,
              "supervisorId": vm.sendRequestEmailId.assigneeNumberText,
              // "assigneeToBe": vm.sendRequestEmailId.assigneeNumberText,
              "completionDate": vm.completionDate,
              "appealNumber": vm.appealNumber,
              "serialNumber": vm.serialNumber,
              "caseType": vm.caseType,
              "totalDraftDecisionTime": vm.totalDraftDecisionTimeTot,
              "personToReceiveCredits": vm.userId,
              "audit": {
                "createUserIdentifier": vm.userId,
                "lastModifiedUserIdentifier": vm.userId
              },
              "decisionalUnitsAwarded": vm.decisionalUnitsAwarded,
              "decisionalUnitsAwardedIdentifier": vm.decisionalUnitsAwardedIdentifier,
              "assignmentType": vm.assignmentType,
              "qualifier": vm.qualifier,
              "specialType": rowData.entity.specialType ? rowData.entity.specialType.trim() != "" ? rowData.entity.specialType : '' : '',
              "assignmentTitle": vm.assignmentTitle,
              "dateOfRequest": new Date().getTime(),
              "widgetIdentifier": widgetIdentifier,
              // "sendRequestEmailAddress": vm .sendRequestEmailId,
              "fileName": ($scope.fileInfo != null || $scope.fileInfo != undefined) ? $scope.fileInfo.name : null,
              "attachmentInBytes": fileByteArray,
              "creditTypeCode": "RAPC",
              "requestStatus": "Submitted"
            };
            if (isSave) {
              data.requestStatus = "Draft";
            }
            if ($scope.fileInfo && $scope.fileInfo.name && $scope.fileInfo.name.trim != "" && fileByteArray.length == 0) {
              data.previousWorkProductUrl = vm.fullFileName;
            }
            vm.disableSubmit = true;
            HttpFactory.putActions(CONSTANTS.URL.MY_CREDITS_REQUESTDU, data)
              .then(function () {
                  vm.disableSubmit = false;
                  CommonHelperService.setToastr("", "clear");
                  if (isSave) {
                    CommonHelperService.setToastr(CONSTANTS.TOASTER.APC, "success");
                  } else {
                    CommonHelperService.setToastr("An assignment to request additional production credits (APC) has been created and assigned to " + vm.sendRequestEmailId.assigneeFullNameText + ".", "success");
                  }
                  ngDialog.closeAll(true);
                },
                function () {
                  vm.disableSubmit = false;
                  CommonHelperService.setToastr("", "clear");
                  CommonHelperService.setToastr(CONSTANTS.TOASTER.APCFail, "error");

                });
          }
        };
      }

    );
})();
