(function () {
  'use strict';

  describe('reallocateDuController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open']);
    var controller, scope, $rootScope;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse, userId, displayName, metaData;
    var rowData, widgetIdentifier;

    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              userInfo: {
                "userId": "pgandhi"
              }
            }
          }
        }
      }
    };

    rowData = {
      entity: {
        reason: {

        }
      }
    };
    widgetIdentifier = 'test';

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback3) {
          callback3();
          }
        }
      });

      metaData = {
        caseType: "APPEAL"
      };

      controller = $controller('reallocateDuController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        rowData: rowData,
        userId:userId,
        displayName:displayName,
        metaData:metaData,
        widgetIdentifier: widgetIdentifier,
        HttpFactory: HttpFactory

      });
    }));

    afterEach(function () {
      spy.and.callThrough();
    });

    describe('reallocateDuController ', function () {

      // it('it should call checkReason ', function () {

      //   expect(controller.checkReason).toBeDefined();
      //   controller.checkReason();
      // });

      it('it should call checkReason else', function () {
        controller.correctDuReason = "AP";
        expect(controller.checkReason).toBeDefined();
        controller.checkReason();
      });

      it('it should call checkPersonname ', function () {
        controller.personToReceiveCredits = "AP";
        expect(controller.checkPersonname).toBeDefined();
        controller.checkPersonname();
      });

      it('it should call checkDu ', function () {
        controller.newDU = "AP";
        expect(controller.checkDu).toBeDefined();
        controller.checkDu();
      });

      it('it should call abandonChanges ', function () {
        controller.originialCorrectDu = "AP";
        controller.correctDuReason = "BJ";
        expect(controller.abandonChanges).toBeDefined();
        controller.abandonChanges();
  
        expect(ngDialog.open).toHaveBeenCalled();
  
        expect(ngDialog.open.calls.count()).toBe(1);
        var args = ngDialog.open.calls.argsFor(0);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);
  
        // expect(args[0].controller).toBe('CancelChangesController');
        // expect(typeof args[0].resolve).toBe('object');
        // args[0].resolve.rowData();
      });

      it('it should call abandonChanges ', function () {
        expect(ngDialog.closeAll).toBeDefined();
        expect(controller.abandonChanges).toBeDefined();
        controller.abandonChanges();
        expect(ngDialog.closeAll).toHaveBeenCalled();
      });

      it('it should call correctCredits ', function () {

        expect(controller.correctCredits).toBeDefined();
        controller.correctCredits();
      });

    });
  });
})();
