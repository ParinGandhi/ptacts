(function () {
  'use strict';

  describe('BulkUpdateCreditsController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open']);
    var controller, scope, $rootScope;
    var spy, $q, HttpFactoryDeferred;
    var type, userId, gridData, number;
    var row = [{
      "decisionalUnits": "2",
      "additionalDecisionalUnits": "2",
      "additionalProdcutionCredits": "2",
      "productivityCredit": "2",
      "patentTimeliness": "2",
      "audit": {
        "lastModifiedTimestamp": 1579107732259,
        "lastModifiedUserIdentifier": "sbartlett",
        "createUserIdentifier": "sbartlett",
        "createdUserName": null,
        "lastModifiedUserName": null,
        "createTimestamp": 1579107732259,
        "lockControlNumber": null
      },
      "requestedHours": 192,
      "supervisorId": 5932,
      "payPeriodId": 202025,
      "payPeriodIdSubStr": "2020-25",
      "adjustmentRequestId": 1380,
      "adjustmentRequestCategory": "Leave",
      "requestDate": 1579107732000,
      "lastModifiedUserFullName": "Bartlett, Steven ",
      "requestorUserId": 826,
      "requestStatusCategory": "Approved",
      "leaveTypeCategory": "Annual"
    }];
    var failureResponse = '';
    var successResponse = '';
    // var successResponse = {
    //   data: [{
    //     "assigneeNumberText": "1810",
    //     "assigneeFullNameText": "Bartlett, Steven ",
    //     "activeCaseCount": 675,
    //     "assigneeStatus": "Active",
    //     "userRoles": [{
    //       "roleCode": "Supervisor",
    //       "roleDescription": "Supervisor"
    //     }]
    //   }, {
    //     "assigneeNumberText": "5904",
    //     "assigneeFullNameText": "Swift, Erica ",
    //     "activeCaseCount": 69,
    //     "assigneeStatus": "Active",
    //     "userRoles": [{
    //       "roleCode": "Supervisor",
    //       "roleDescription": "Supervisor"
    //     }]
    //   }, {
    //     "assigneeNumberText": "28",
    //     "assigneeFullNameText": "Vignone, Maria ",
    //     "activeCaseCount": 408,
    //     "assigneeStatus": "Active",
    //     "userRoles": [{
    //       "roleCode": "Supervisor",
    //       "roleDescription": "Supervisor"
    //     }]
    //   }]
    // };
    // rowData = {
    //   entity: {
    //     reason: {

    //     },
    //     type: "Review Request"
    //   }
    // };


    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      //   spy = spyOn(angular, 'element').and.callFake(fakeElement);
      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback3) {
            callback3();
          }
        }
      });

      controller = $controller('BulkUpdateCreditsController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        userId: userId,
        gridData: gridData,
        HttpFactory: HttpFactory,
        type: type
      });
    }));

    describe('BulkUpdateCreditsController', function () {

      it('should check documentsGridOptions', function () {
        expect(controller.documentsGridOptions).toBeDefined();
      });

      it('should check documentsGridOptions.columnDefs', function () {
        expect(controller.documentsGridOptions.columnDefs).toBeDefined();
      });

      it('Should invoke dismiss on ngDialog', function () {
        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['cancelUpdate']).toBeDefined();
        controller.cancelUpdate();
        expect(ngDialog.closeAll).toHaveBeenCalledWith(false);
      });

      it(' should call getTwoDecimalRoundUp ', function () {
        row = {
          "entity": {
            "fkAdFkAppealNo": '2018005819',
            "fkAdFkAaSerialNo": '15007114',
            "read": true
          },
          "audit": {
            "lastModifiedTimestamp": 1579107732259,
            "lastModifiedUserIdentifier": "sbartlett",
            "createUserIdentifier": "sbartlett",
            "createdUserName": null,
            "lastModifiedUserName": null,
            "createTimestamp": 1579107732259,
            "lockControlNumber": null
          },
          "requestedHours": 192,
          "supervisorId": 5932,
          "payPeriodId": 202025,
          "payPeriodIdSubStr": "2020-25",
          "adjustmentRequestId": 1380,
          "adjustmentRequestCategory": "Leave",
          "requestDate": 1579107732000,
          "lastModifiedUserFullName": "Bartlett, Steven ",
          "requestorUserId": 826,
          "requestStatusCategory": "Approved",
          "leaveTypeCategory": "Annual"
        };
        expect(scope['getTwoDecimalRoundUp']).toBeDefined();
        scope.getTwoDecimalRoundUp(row);
      });

      it(' should call checkIsNumber ', function () {
        number = "2";
        expect(scope['checkIsNumber']).toBeDefined();
        scope.checkIsNumber(number);
      });

      it(' should call checkIsNumber ', function () {
        number = "Q";
        expect(scope['checkIsNumber']).toBeDefined();
        scope.checkIsNumber(number);
      });

      it(' should call updateCredits ', function () {
        expect(controller.updateCredits).toBeDefined();
        controller.updateCredits();
      });

      //   it('it should call getSupervisor failureResponse', function () {
      //     failureResponse = {
      //       data: []
      //     };
      //     expect(controller.getSupervisor).toBeDefined();
      //     controller.getSupervisor();
      //     HttpFactoryDeferred.reject(failureResponse);
      //     scope.$digest();
      //   });

      //   it('it should call mandatoryCheckWebTaPP', function () {
      //     controller.webTaPP = "AP";
      //     expect(controller.mandatoryCheckWebTaPP).toBeDefined();
      //     controller.mandatoryCheckWebTaPP();
      //   });

      //   it('it should call mandatoryCheckWebTaPP', function () {
      //     controller.webTaPP = "";
      //     expect(controller.mandatoryCheckWebTaPP).toBeDefined();
      //     controller.mandatoryCheckWebTaPP();
      //   });

      //   it('it should call mandatoryCheckProjectName else', function () {
      //     controller.projectName = "";
      //     expect(controller.mandatoryCheckProjectName).toBeDefined();
      //     controller.mandatoryCheckProjectName();
      //   });

      //   it('it should call mandatoryCheckProjectName else', function () {
      //     controller.projectName = "added";
      //     expect(controller.mandatoryCheckProjectName).toBeDefined();
      //     controller.mandatoryCheckProjectName();
      //   });

      //   it('it should call mandatoryCheckProjectHours  ', function () {
      //     controller.projectHours = "";
      //     expect(controller.mandatoryCheckProjectHours).toBeDefined();
      //     controller.mandatoryCheckProjectHours();
      //   });

      //   it('it should call mandatoryCheckProjectHours  ', function () {
      //     controller.projectHours = "7";
      //     expect(controller.mandatoryCheckProjectHours).toBeDefined();
      //     controller.mandatoryCheckProjectHours();
      //   });

      //   it('it should call requestPga  ', function () {
      //     expect(controller.requestPga).toBeDefined();
      //     controller.requestPga();
      //   });

      //   it('it should call requestPga  ', function () {
      //     controller.displayErrorWebTa = "";
      //     controller.displayErrorName = "";
      //     controller.displayErrorhours = "";
      //     expect(controller.requestPga).toBeDefined();
      //     controller.requestPga();
      //   });


      //   it('Should invoke dismiss on ngDialog', function () {
      //     expect(ngDialog.closeAll).toBeDefined();
      //     expect(controller['cancelRequestPga']).toBeDefined();
      //     controller.cancelRequestPga();
      //     expect(ngDialog.closeAll).toHaveBeenCalledWith();
      //   });
    });
  });
})();
