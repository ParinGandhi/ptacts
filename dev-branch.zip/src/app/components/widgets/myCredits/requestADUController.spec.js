(function () {
  'use strict';

  describe('requestADUController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open']);
    var controller, scope, $rootScope;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;
    var rowData, widgetIdentifier, requestType, items, userId, metaData, displayName;
    var supervisorResponse1 = [{
      "assigneeNumberText": "1810",
      "assigneeFullNameText": "Bartlett, Steven ",
      "activeCaseCount": 675,
      "assigneeStatus": "Active",
      "userRoles": [{
        "roleCode": "Supervisor",
        "roleDescription": "Supervisor"
      }]
    }, {
      "assigneeNumberText": "5904",
      "assigneeFullNameText": "Swift, Erica ",
      "activeCaseCount": 69,
      "assigneeStatus": "Active",
      "userRoles": [{
        "roleCode": "Supervisor",
        "roleDescription": "Supervisor"
      }]
    }, {
      "assigneeNumberText": "28",
      "assigneeFullNameText": "Vignone, Maria ",
      "activeCaseCount": 408,
      "assigneeStatus": "Active",
      "userRoles": [{
        "roleCode": "Supervisor",
        "roleDescription": "Supervisor"
      }]
    }];
    var failureResponse = '';
    var successResponse = {
      data: [{
        "assigneeNumberText": "1810",
        "assigneeFullNameText": "Bartlett, Steven ",
        "activeCaseCount": 675,
        "assigneeStatus": "Active",
        "userRoles": [{
          "roleCode": "Supervisor",
          "roleDescription": "Supervisor"
        }]
      }, {
        "assigneeNumberText": "5904",
        "assigneeFullNameText": "Swift, Erica ",
        "activeCaseCount": 69,
        "assigneeStatus": "Active",
        "userRoles": [{
          "roleCode": "Supervisor",
          "roleDescription": "Supervisor"
        }]
      }, {
        "assigneeNumberText": "28",
        "assigneeFullNameText": "Vignone, Maria ",
        "activeCaseCount": 408,
        "assigneeStatus": "Active",
        "userRoles": [{
          "roleCode": "Supervisor",
          "roleDescription": "Supervisor"
        }]
      }]
    };
    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              userInfo: {
                "userId": "pgandhi"
              }
            }
          }
        }
      }
    };

    rowData = {
      entity: {
        reason: {

        },
        type: "Review Request"
      }
    };
    widgetIdentifier = 'test';
    requestType = 'String';

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spy = spyOn(angular, 'element').and.callFake(fakeElement);
      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback3) {
            callback3();
          }
        }
      });
      metaData = {
        caseType: "APPEAL"
      };
      items = {
        entity: {
          isEdit: true,
          creditQuantities: "2",
          reason: "sss",
          recordHour: 0,
          // requestorId: "12",
          ptabAssignmentIdentifier: 1850,
          supervisoryName: "name",
          supervisorsData: [{
            assigneeFullNameText: "1810"
          }]
        }
      }
      controller = $controller('requestADUController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        rowData: rowData,
        widgetIdentifier: widgetIdentifier,
        requestType: requestType,
        items: items,
        userId: userId,
        metaData: metaData,
        displayName: displayName,
        HttpFactory: HttpFactory,
        supervisorResponse1: supervisorResponse1
      });
    }));

    afterEach(function () {
      spy.and.callThrough();
    });

    describe('requestADUController ', function () {

      it('it should call checkReason else', function () {
        controller.correctDuReason = "AP";
        expect(controller.checkReason).toBeDefined();
        controller.checkReason();
      });

      it('it should call checkSendReqEmailid ', function () {
        controller.title = "Request";
        expect(controller.checkSendReqEmailid).toBeDefined();
        controller.checkSendReqEmailid();
      });

      it('it should call checkSendReqEmailid ', function () {
        controller.title = "Request";
        controller.sendRequestEmailId = "EricaSwift@gmail.com";
        expect(controller.checkSendReqEmailid).toBeDefined();
        controller.checkSendReqEmailid();
      });

      it('it should call checkSendReqEmailid ', function () {
        controller.title = "qqq";
        expect(controller.checkSendReqEmailid).toBeDefined();
        controller.checkSendReqEmailid();
      });

      it('it should call getSupervisor successResponse', function () {
        successResponse = {
          data: [{
            "assigneeNumberText": "1810",
            "assigneeFullNameText": "Bartlett, Steven ",
            "activeCaseCount": 675,
            "assigneeStatus": "Active",
            "userRoles": [{
              "roleCode": "Supervisor",
              "roleDescription": "Supervisor"
            }]
          }, {
            "assigneeNumberText": "5904",
            "assigneeFullNameText": "Swift, Erica ",
            "activeCaseCount": 69,
            "assigneeStatus": "Active",
            "userRoles": [{
              "roleCode": "Supervisor",
              "roleDescription": "Supervisor"
            }]
          }, {
            "assigneeNumberText": "28",
            "assigneeFullNameText": "Vignone, Maria ",
            "activeCaseCount": 408,
            "assigneeStatus": "Active",
            "userRoles": [{
              "roleCode": "Supervisor",
              "roleDescription": "Supervisor"
            }]
          }]
        };
        expect(controller.getSupervisor).toBeDefined();
        controller.getSupervisor();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
      });

      it('it should call getSupervisor failureResponse', function () {
        failureResponse = {
          data: []
        };
        expect(controller.getSupervisor).toBeDefined();
        controller.getSupervisor();
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });

      it('it should call callDatamap ', function () {
        controller.supervisorResponse1 = [{
          "assigneeNumberText": "1810",
          "assigneeFullNameText": "Bartlett, Steven ",
          "activeCaseCount": 675,
          "assigneeStatus": "Active",
          "userRoles": [{
            "roleCode": "Supervisor",
            "roleDescription": "Supervisor"
          }]
        }, {
          "assigneeNumberText": "5904",
          "assigneeFullNameText": "Swift, Erica ",
          "activeCaseCount": 69,
          "assigneeStatus": "Active",
          "userRoles": [{
            "roleCode": "Supervisor",
            "roleDescription": "Supervisor"
          }]
        }, {
          "assigneeNumberText": "28",
          "assigneeFullNameText": "Vignone, Maria ",
          "activeCaseCount": 408,
          "assigneeStatus": "Active",
          "userRoles": [{
            "roleCode": "Supervisor",
            "roleDescription": "Supervisor"
          }]
        }];
        expect(controller.callDatamap).toBeDefined();
        controller.callDatamap();
      });

      it('it should call checkDu ', function () {
        controller.newDU = "AP";
        expect(controller.checkDu).toBeDefined();
        controller.checkDu();
      });

      it('it should call checkDraftDecisionTime ', function () {
        controller.totalDraftDecisionTime = "AP";
        expect(controller.checkDraftDecisionTime).toBeDefined();
        controller.checkDraftDecisionTime();
      });


      it('it should call abandonChanges ', function () {
        controller.originalnewDU = "2";
        controller.newDU = "2";
        expect(controller.abandonChanges).toBeDefined();
        controller.abandonChanges();
      });

      it('it should call abandonChanges ', function () {
        controller.originialCorrectDu = "AP";
        controller.correctDuReason = "BJ";
        expect(controller.abandonChanges).toBeDefined();
        controller.abandonChanges();
        // expect(ngDialog.open).toHaveBeenCalled();

        // expect(ngDialog.open.calls.count()).toBe(1);
        // var args = ngDialog.open.calls.argsFor(0);
        // expect(args).not.toBe(null);
        // expect(args.length).toBe(1);

        // expect(args[0].controller).toBe('CancelChangesController');
        // expect(typeof args[0].resolve).toBe('object');
        // args[0].resolve.rowData();
      });

      it('it should call abandonChanges ', function () {
        expect(ngDialog.closeAll).toBeDefined();
        // expect(controller.abandonChanges).toBeDefined();
        controller.abandonChanges();
        // expect(ngDialog.closeAll).toHaveBeenCalled();
      });

      it('it should call correctCredits ', function () {
        expect(controller.correctCredits).toBeDefined();
        controller.correctCredits();
      });

      it('it should call clearFile ', function () {
        expect(controller.clearFile).toBeDefined();
        controller.clearFile();
      });

    });
  });
})();
