(function () {
  "use strict";
  angular
    .module('ptabe2e').controller('EditCreditsController', function ( CONSTANTS,  $rootScope, HttpFactory,$scope,CommonHelperService, ngDialog) {
      var vm = this;
      vm.changeCaseMode = true;
      vm.editEnabled = false;
      vm.caseChangeMode=true;
      vm.newCaseMode=false;
      vm.showNoRecords = false;
      vm.creditRows = [];
      $scope.orderByField ='completionDate';
      $scope.reverseSort = false;
      var row = {};
      var row2 = {};

      $scope.userInfo = $rootScope.userInfo;
      if (!$scope.userInfo) {
        $scope.userInfo = {
          "userId": $window.sessionStorage.getItem("workerNumber")
        };
      }
     
        
    //     var employee = {
    //       fullName: "Ancer, Julius"
    //     };
    //     row.employee = employee;
    //     row.caseType = "APPEAL";
    //     row.assignmentType = {
    //       displayName: "Create draft circulation"
    //     };
    //     row.pageCount = 5;
    //     row.pc = .3;
    //     row.apc = 5;
    //     row.note = "A note that will have an ellipse";
    //     row.completionDate = 1617249599000;
    //     row.lastModifiedDate = new Date();
    //     row.lastModifiedUser = "Bartlett, Steven";
    //     row.edit = false;
    //     vm.editMode = false;
       
      
    //   //vm.testData();
    //   vm.creditRows.push(row);
    //  row2.completionDate = new Date();

    //   vm.creditRows.push(row2);
    //   vm.creditRows.push(row);

      vm.cancelEdit = function (row) {
        vm.editEnabled = false;
        row.edit = false;
        vm.editMode = false;
        vm.changes = false;
        vm.judgeInvalidEdit = false;
        vm.caseNumberInvalidEdit = false;
        vm.caseTypeInvalidEdit = false;
        vm.assignmentTypeInvalidEdit = false;
        vm.pcInvalidEdit = false;
        vm.completionDateInvalidEdit = false;
        vm.assignedDateInvalidEdit = false;
      };

      function invalidateEditForm() {
        // vm.judgeInvalidEdit = checkFormModel(vm.judge2.awardeeName);
        //vm.pageCountInvalidEdit = checkFormModel(vm.editedPageCount);
        vm.apcInvalidEdit = checkFormModel(vm.editedAPC);
        //   vm.NoteInvalidEdit = checkFormModel(vm.editedNote);
        vm.pcInvalidEdit = checkFormModel(vm.editedPC);
        vm.errorFound = false;
        return vm.apcInvalidEdit || vm.pcInvalidEdit;
      }

      function checkFormModel(formModel) {
        if (!formModel) {
          vm.errorFound = true;
          return true;
        }
        return false;
      }
      vm.changeCaseNumber= function(){
        
        HttpFactory.getActions(CONSTANTS.URL.GET_EXISITNG_CREDITS+vm.newCaseNumber)
        .then(function (success) {
          vm.caseChangeMode =false;
          vm.creditRows = success.data;
          if(vm.creditRows.length > 0){
            vm.showNoRecords = false;
          }else {
            vm.showNoRecords = true;
          }
          
          vm.appealNumber=vm.newCaseNumber;
          vm.newCaseNumber="";
        }, function (failureResponse) {
          vm.caseChangeMode =true;
          CommonHelperService.setToastr("", "clear");
          CommonHelperService.setToastr(failureResponse.data.message, "warning");
          });
      }
      vm.saveEditRow = function (row) {
        // var errorFound = invalidateEditForm();
        // if (errorFound) {
        //   return;
        // }
        // row.employee = vm.judge2;
        row.pageCount = vm.editedPageCount;
        row.productionCredits = vm.editedPC;
        row.additonalProductivityCredits = vm.editedAPC;
        row.noteText = vm.editedNote;
        var currentTime = Math.floor(new Date().getTime() / 1000);
        row.audit = {
          "createUserIdentifier": $scope.userInfo.userId,
          "lastModifiedUserIdentifier": $scope.userInfo.userId,
          "lastModifiedTimestamp": currentTime,
          "createdUserName": $scope.userInfo.userId,
          "createTimestamp": currentTime,
          "lockControlNumber": 0
      }
        HttpFactory.putActions(CONSTANTS.URL.UPDATE_EXISITNG_CREDITS,row)
        .then(function (success) {
          row.edit = false;
          vm.editMode = false;
          vm.newCaseNumber=row.appealNumber;
          vm.changeCaseNumber();
        }, function (failureResponse) {
          // vm.caseChangeMode =true;
          CommonHelperService.setToastr("", "clear");
          CommonHelperService.setToastr(failureResponse.data.message, "warning");
          });


      }

      

      vm.getJudgeList = function () {
        HttpFactory.getActions(CONSTANTS.URL.GET_ALL_JUDGES)
          .then(function (judgeList) {
            var sortedList = judgeList.data.sort(function (a, b) {
              if (a.assigneeFullNameText < b.assigneeFullNameText) {
                return -1;
              }
              if (a.assigneeFullNameText > b.assigneeFullNameText) {
                return 1;
              }
              return 0;
            });
            vm.judgeList = judgeList.data;
            var defaultOption = [{
              assigneeNumberText: "",
              assigneeFullNameText: "All judges",
              workerNumber: "",
              rankId: null
            }];
            vm.judgeList = defaultOption.concat(sortedList);
            vm.judgeList2 = angular.copy(vm.judgeList);
            vm.originalJudgeList = angular.copy(vm.judgeList);
            vm.selectedJudge = vm.judgeList[0];
            console.log("Judgelist: ");
            console.log(vm.judgeList);

          }, function (judgeListFailure) {
            console.log(judgeListFailure);
          });
      };

      vm.getJudgeList();

      vm.showJudgeList2 = function () {
        if (!vm.judgeListVisible2) {
          vm.judgeListVisible2 = !vm.judgeListVisible2;
        }
      };

      vm.searchForJudge2 = function (input) {
        var tempList = [];
        if (angular.isDefined(input) && input.awardeeName.trim() !== "") {
          angular.forEach(vm.originalJudgeList, function (currentJudge) {
            if (currentJudge.assigneeFullNameText.toLowerCase().includes(input.awardeeName.toLowerCase())) {
              tempList.push(currentJudge);
            }
          });
          vm.judgeList2 = angular.copy(tempList);
        } else {
          vm.judgeList2 = angular.copy(vm.originalJudgeList);
        }
      };

      vm.setSelectedJudge2 = function (judge) {
        if (judge.assigneeFullNameText !== "Select judge...") {
          vm.selectedJudge2 = judge;
          vm.judge2.awardeeName = judge.assigneeFullNameText;
          vm.judgeListVisible2 = false;
        }
      };

      vm.editRow = function (row) {
        vm.changes=false;
        vm.editEnabled = true;
        row.edit = true;
        vm.editMode = true;

        vm.editedRow = angular.copy(row);
        vm.editedPageCount = row.pageCount;
        vm.editedPC = row.productionCredits;
        vm.editedAPC = row.additonalProductivityCredits;
        vm.editedCompletionDate = row.completionDate;
         vm.editedNote = row.noteText;
//         vm.editedAwardeeName = [];
//         vm.editedAwardeeName.push(row.awardeeName);
//         vm.editedAwardeeName.push("None");
      };

      vm.pageCountChanged = function (caseType, count) {
        HttpFactory.getActions(CONSTANTS.URL.OTHERCREDITS_PAGE_COUNT +caseType + "&pageCnt=" +count)
        .then(function (successResponse) {
           vm.editedPC = successResponse.data.workCreditQuantity;
         
          },
          function () {
             // intentional
          });
      };

      vm.cancelModal = function(){
        if (!vm.changes || !vm.editMode) {
          ngDialog.close();
       return;
        }      
       /* istanbul ignore next */
        ngDialog.openConfirm({ 
         template: "app/components/widgets/myCredits/enterOtherCreditsCloseModal.html",
         scope: $scope,
         width: '30%',
         showClose: false,
         closeByEscape: false,
         closeByDocument: false
           })
         .then(function () {
          ngDialog.close();
         }, function () {
          // Stay on modal
         });
        };

        vm.changedValue = function(valueType) {
          
          if (valueType==='pc') {
            vm.changes = vm.changes || vm.editedPageCount !== vm.editedRow.pageCount;
            
          } else if (valueType==='apc') {
            vm.changes = vm.changes || vm.editedAPC !== vm.editedRow.additonalProductivityCredits;
          } else if (valueType==='note') {
            vm.changes = vm.changes || vm.editedNote !== vm.editedRow.noteText;
          }
     //     changes = vm.editedRow.pageCount != vm.editedPageCount;
 //         vm.editedPageCount = row.pageCount;
  //        vm.editedPC = row.productionCredits;
   //       vm.editedAPC = row.additonalProductivityCredits;
    //      vm.editedCompletionDate = row.completionDate;
     //      vm.editedNote = row.noteText;
  
        };
        
    });
})();
