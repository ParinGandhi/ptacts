(function () {
  'use strict';

  describe('correctPtController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open']);
    var controller, scope, $rootScope;
    var spy, $q, HttpFactoryDeferred;
    var rowData, widgetIdentifier, requestType, userId, metaData, displayName;
    var supervisorResponse1 = [{
      "assigneeNumberText": "1810",
      "assigneeFullNameText": "Bartlett, Steven ",
      "activeCaseCount": 675,
      "assigneeStatus": "Active",
      "userRoles": [{
        "roleCode": "Supervisor",
        "roleDescription": "Supervisor"
      }]
    }, {
      "assigneeNumberText": "5904",
      "assigneeFullNameText": "Swift, Erica ",
      "activeCaseCount": 69,
      "assigneeStatus": "Active",
      "userRoles": [{
        "roleCode": "Supervisor",
        "roleDescription": "Supervisor"
      }]
    }, {
      "assigneeNumberText": "28",
      "assigneeFullNameText": "Vignone, Maria ",
      "activeCaseCount": 408,
      "assigneeStatus": "Active",
      "userRoles": [{
        "roleCode": "Supervisor",
        "roleDescription": "Supervisor"
      }]
    }];
    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              userInfo: {
                "userId": "pgandhi"
              }
            }
          }
        }
      }
    };

    rowData = {
      entity: {
        reason: {

        },
        type: "Review Request"
      }
    };
    widgetIdentifier = 'test';
    requestType = 'String';

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spy = spyOn(angular, 'element').and.callFake(fakeElement);
      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback3) {
            callback3();
          }
        }
      });
      metaData = {
        caseType: "APPEAL"
      };
      controller = $controller('correctPtController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        rowData: rowData,
        widgetIdentifier: widgetIdentifier,
        requestType: requestType,
        userId: userId,
        metaData: metaData,
        displayName: displayName,
        HttpFactory: HttpFactory,
        supervisorResponse1: supervisorResponse1
      });
    }));

    afterEach(function () {
      spy.and.callThrough();
    });

    describe('correctPtController', function () {

      it('it should call checkReason else', function () {
        controller.correctPtReason = "AP";
        expect(controller.checkReason).toBeDefined();
        controller.checkReason();
      });

      it('it should call checkReason else', function () {
        controller.correctPtReason = "";
        expect(controller.checkReason).toBeDefined();
        controller.checkReason();
      });

      it('it should call checkSendReqEmailid ', function () {
        controller.title = "Request";
        expect(controller.checkSendReqEmailid).toBeDefined();
        controller.checkSendReqEmailid();
      });

      it('it should call checkSendReqEmailid ', function () {
        controller.title = "Correct";
        controller.sendRequestEmailId = "EricaSwift@gmail.com";
        expect(controller.checkSendReqEmailid).toBeDefined();
        controller.checkSendReqEmailid();
      });

      it('it should call checkSendReqEmailid ', function () {
        controller.title = "qqq";
        expect(controller.checkSendReqEmailid).toBeDefined();
        controller.checkSendReqEmailid();
      });

      it('it should call checkPt ', function () {
        controller.newPt = "AP";
        expect(controller.checkPt).toBeDefined();
        controller.checkPt();
      });

      it('it should call checkPt ', function () {
        controller.newPt = "";
        expect(controller.checkPt).toBeDefined();
        controller.checkPt();
      });

      it('it should call checkMandatoryFields ', function () {
        expect(controller.checkMandatoryFields).toBeDefined();
        controller.checkMandatoryFields();
      });

      it('it should call abandonChanges ', function () {
        controller.originalnewPt = "2";
        controller.newPt = "2";
        expect(controller.abandonChanges).toBeDefined();
        controller.abandonChanges();
      });

      it('it should call abandonChanges ', function () {
        controller.originalcorrectPtReason = "AP";
        controller.correctPtReason = "BJ";
        expect(controller.abandonChanges).toBeDefined();
        controller.abandonChanges();
      });

      it('it should call abandonChanges ', function () {
        expect(ngDialog.closeAll).toBeDefined();
        controller.abandonChanges();
      });

      it('it should call clearFile ', function () {
        expect(controller.clearFile).toBeDefined();
        controller.clearFile();
      });

    });
  });
})();
