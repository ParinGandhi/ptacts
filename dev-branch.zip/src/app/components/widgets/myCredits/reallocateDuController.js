(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .directive('rduFileModel', ['$parse', /* istanbul ignore next */ function ($parse) {
      return {
        restrict: 'A',
        link: function (scope, element) {
          //  var modelSetter = model.assign;
          element.bind('change', function () {
            scope.$apply(function () {
              // modelSetter(scope, element[0].files[0]);
            });
          });
        }
      };
    }])

    .directive('rduOnChange', /* istanbul ignore next */ function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var onChangeFunc = scope.$eval(attrs.rduOnChange);
          element.bind('change', onChangeFunc);
        }
      };
    })
    .controller('reallocateDuController', function ($scope, ngDialog, $timeout, userId, displayName, metaData, rowData, widgetIdentifier, HttpFactory, CONSTANTS, CommonHelperService) {
        var vm = this;
        var scope = angular.element(document.getElementById('mainTabId')).scope();

        //added
        vm.metaData = metaData;
        vm.metaData.caseTypes = [vm.metaData.caseType];
        vm.userId = userId;
        vm.displayName = displayName;
        //  vm.items = items;
        if (rowData.entity.supervisorsData && rowData.entity.supervisorsData.length > 0) {
          vm.currentSupervisor = rowData.entity.supervisorsData[0].assigneeFullNameText;
          vm.originalsendRequestEmailId = rowData.entity.supervisorsData[0].assigneeFullNameText;
        } else {
          vm.currentSupervisor = "";
        }
        vm.ptabAssignmentIdentifier = rowData.entity.ptabAssignmentIdentifier;
        vm.superviorResponse1;
        vm.supervisorList1 = [];
        vm.supervisorName = [];
        vm.isTrials = false;
        vm.role = rowData.entity.roleName;
        //end

        vm.userInfo = scope.vm.userInfo;
        vm.currentDU = rowData.entity.decisionalUnits;
        vm.currentADU = rowData.entity.additionalDecisionalUnits;
        vm.newDU = "";
        vm.newADU = "";
        vm.sendRequestEmailId = "";
        vm.completionDateLabel = "Completion date";
        vm.todaysDate = new Date().getTime();
        vm.correctDuReason = "";
        vm.personToReceiveCredits = "";
        vm.assignmentId = rowData.entity.ptabAssignmentId;
        vm.assignmentTitle = rowData.entity.assignmentTitle;
        vm.appealNumber = rowData.entity.appealNumber;
        vm.assignmentType = rowData.entity.assignmentType;
        vm.decisionalUnitsAwarded = rowData.entity.decisionalUnitsAwarded;
        vm.decisionalUnitsAwardedIdentifier = rowData.entity.decisionalUnitsAwardedIdentifier;
        vm.specialTypeTooltip = CONSTANTS.SPECIAL_TYPE_REQUEST.tooltip;
        vm.specialType = rowData.entity.specialType;
        vm.lockControlNumber = rowData.entity.lockControlNumber;
        vm.caseType = rowData.entity.caseType;
        vm.serialNumber = rowData.entity.serialNumber;
        vm.completionDate = rowData.entity.completionDate;
        vm.qualifier = rowData.entity.qualifier;
        vm.creditAwardId = rowData.entity.creditAwardId;
        vm.originialCorrectDu = angular.copy(vm.correctDuReason);
        vm.originalPersonToreceive = angular.copy(vm.personToReceiveCredits);
        vm.originalAdu = angular.copy(vm.newDU);
        var rduFile;
        var reader = new FileReader();
        var fileByteArray = [];
        vm.disableSubmit = false;


        $timeout(function () {
          vm.zIndex();
          vm.getSupervisor();
        }, 200);

        vm.zIndex = function () {
          document.getElementById('globalHeaderDiv').style.zIndex = '9';
        };

        vm.getSupervisor = function () {
          vm.supervisorList1 = [];
          HttpFactory.getActions("/user-management/supervisors/" + vm.userId)
            .then(function (successResponse) {
              vm.superviorResponse1 = successResponse.data;
              vm.superviorResponse1.forEach(function (element) {
                if (vm.currentSupervisor === element.assigneeFullNameText)
                  vm.supervisorList1.push(element);
              });
              if (vm.supervisorList1.length === 0 && vm.currentSupervisor !== "") {
                vm.supervisorList1.push(rowData.entity.supervisorsData[0]);

              }
              vm.superviorResponse1.forEach(function (element) {
                if (vm.displayName !== element.assigneeFullNameText && vm.supervisorList1.length === 0 && vm.currentSupervisor === "") {
                  vm.supervisorList1.push(element);
                } else if (vm.displayName !== element.assigneeFullNameText && vm.currentSupervisor !== element.assigneeFullNameText && vm.supervisorList1[vm.supervisorList1.length - 1].assigneeFullNameText !== element.assigneeFullNameText) {
                  vm.supervisorList1.push(element);
                }
              });

              vm.sendRequestEmailId = vm.supervisorList1[0];

            }, function () {
              // Empty response ok
            });
        };


        vm.checkReason = function () {
          if (vm.correctDuReason === null || vm.correctDuReason === "" || angular.isUndefined(vm.correctDuReason)) {
            vm.errorMessageForReason = "Reason is mandatory";
            vm.showErrorMessageReason = true;
            vm.readyToSaveReason = false;
          } else {
            vm.showErrorMessageReason = false;
            vm.readyToSaveReason = true;
          }
        };

        vm.checkSendReqEmailid = function () {
          if (vm.sendRequestEmailId.assigneeFullNameText === null || vm.sendRequestEmailId.assigneeFullNameText === "" || vm.sendRequestEmailId.assigneeFullNameText === "Select supervisor" || angular.isUndefined(vm.sendRequestEmailId)) {
            vm.errorMessageForsendRequestEmailId = " Supervisor is mandatory";
            vm.showErrorMessagesendRequestEmailId = true;
            vm.readyToSavesendRequestEmailId = false;
          } else {
            vm.showErrorMessagesendRequestEmailId = false;
            vm.readyToSavesendRequestEmailId = true;
          }
        };


        vm.checkPersonname = function () {
          if (vm.personToReceiveCredits === null || vm.personToReceiveCredits === "" || angular.isUndefined(vm.personToReceiveCredits)) {
            vm.errorMessageForpersonToReceiveCredits = "Person to receive DU(s) is mandatory";
            vm.showErrorMessagepersonToReceiveCredits = true;
            vm.readyToSavepersonToReceiveCredits = false;
          } else {
            vm.showErrorMessagepersonToReceiveCredits = false;
            vm.readyToSavepersonToReceiveCredits = true;
          }
        };
        vm.checkDu = function () {
          if (vm.newDU === null || vm.newDU === "" || angular.isUndefined(vm.newDU)) {
            vm.errorMessageForDU = "Decisional units are mandatory";
            vm.showErrorMessageDU = true;
            vm.readyToSaveDU = false;
          } else {
            vm.showErrorMessageDU = false;
            vm.readyToSaveDU = true;
          }
        };
        vm.checkMandatoryFields = function () {
          vm.checkReason();
          vm.checkPersonname();
          vm.checkDu();
        };
        vm.abandonChanges = function () {
          if (vm.originalsendRequestEmailId === undefined || vm.originalsendRequestEmailId === null || vm.originalsendRequestEmailId === "") {
            vm.originalsendRequestEmailId = vm.sendRequestEmailId.assigneeFullNameText;
          }

          if (!angular.equals(vm.originialCorrectDu, vm.correctDuReason) ||
            !angular.equals(vm.personToReceiveCredits, vm.originalPersonToreceive) ||
            !angular.equals(vm.originalAdu, vm.newDU) ||
            !angular.equals(vm.originalsendRequestEmailId, vm.sendRequestEmailId.assigneeFullNameText)) {
            ngDialog.open({
              template: 'app/components/widgets/myCredits/cancelChanges.html',
              controller: 'CancelChangesController',
              controllerAs: 'vm',
              width: '25%',
              showClose: false,
              closeByEscape: false,
              closeByDocument: false


            }).closePromise.then(function () {
              // processing handled in modal controller.
            });
          } else {
            ngDialog.closeAll();
          }
        };

        /* istanbul ignore next */
        $scope.getFileInfo = function (file) {
          rduFile = document.getElementById("file1");
          $scope.fileInfo = {};
          $scope.fileInfo.name = rduFile.files[0].name;
          $scope.fileInfo.path = rduFile.value;
          reader.readAsArrayBuffer(rduFile.files[0]);
          reader.onloadend = function (evt) {
            if (evt.target.readyState == FileReader.DONE) {
              var arrayBuffer = evt.target.result,
                array = new Uint8Array(arrayBuffer);
              for (var i = 0; i < array.length; i++) {
                fileByteArray.push(array[i]);
              }
            }
          };
        };

        vm.clearFile = function () {
          $scope.fileInfo = {};
        };


        /* istanbul ignore next: toaster error */
        vm.correctCredits = function () {
          vm.checkMandatoryFields();
          if (vm.readyToSaveDU && vm.readyToSaveReason && vm.readyToSavepersonToReceiveCredits) {
            var data = {
              "decisionalUnits": vm.currentDU,
              "requestedDecisionalUnits": vm.newDU,
              "ptabAssignmentIdentifier": vm.ptabAssignmentIdentifier,
              "reason": vm.correctDuReason,
              "supervisorId": vm.sendRequestEmailId.assigneeNumberText,
              "supervisorName": vm.sendRequestEmailId.assigneeFullNameText,
              "completionDate": vm.completionDate,
              "appealNumber": vm.appealNumber,
              "serialNumber": vm.serialNumber,
              "caseType": vm.caseType,
              "personToReceiveCredits": vm.personToReceiveCredits,
              "audit": {
                "createUserIdentifier": vm.userInfo.userId,
                "lastModifiedUserIdentifier": vm.userInfo.userId
              },
              "decisionalUnitsAwarded": vm.decisionalUnitsAwarded,
              "decisionalUnitsAwardedIdentifier": vm.decisionalUnitsAwardedIdentifier,
              "assignmentType": vm.assignmentType,
              "qualifier": vm.qualifier,
              "specialType": rowData.entity.specialType ? rowData.entity.specialType.trim() != "" ? rowData.entity.specialType : '' : '',
              "assignmentTitle": vm.assignmentTitle,
              "dateOfRequest": new Date().getTime(),
              "widgetIdentifier": widgetIdentifier,
              //"sendRequestEmailAddress": vm.sendRequestEmailId,
              "fileName": ($scope.fileInfo != null || $scope.fileInfo != undefined) ? $scope.fileInfo.name : null,
              "attachmentInBytes": fileByteArray,
              // "creditTypeCode": ""
            };
            vm.disableSubmit = true;
            HttpFactory.putActions(CONSTANTS.URL.MY_CREDITS_REQUESTDU + "?requestType=RELLOCATEDECISIONALUNITS", data)
              .then(function () {
                vm.disableSubmit = false;
                CommonHelperService.setToastr("", "clear");
                CommonHelperService.setToastr(CONSTANTS.TOASTER.RDU, "success");
                ngDialog.closeAll(true);

              }, function () {
                vm.disableSubmit = false;
                CommonHelperService.setToastr("", "clear");
                CommonHelperService.setToastr(CONSTANTS.TOASTER.RDUFail, "error");
              });
          }
        };
      }

    );
})();
