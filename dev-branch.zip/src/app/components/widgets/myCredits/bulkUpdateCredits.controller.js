(function () {
  "use strict";

  angular
    .module("ptabe2e")
    .controller("BulkUpdateCreditsController", function ($scope, type, gridData, userId, CONSTANTS, CommonHelperService, HttpFactory, uiGridConstants, ngDialog) {
      var vm = this;
      vm.numberOfFilters = 0;
      vm.userId = userId;
      vm.originalData = angular.copy(gridData);
      vm.dialogTitle = "Update credits";
      $scope.getTwoDecimalRoundUp = function (row) {
        // var currentTotals;
        vm.existingNumber = $scope.checkIsNumber(row.entity.decisionalUnits) + $scope.checkIsNumber(row.entity.additionalDecisionalUnits) + $scope.checkIsNumber(row.entity.productivityCredit) +
          $scope.checkIsNumber(row.entity.additionalProdCredits);
        return vm.existingNumber.toFixed(2);
        // if (angular.isNumber(row.entity.decisionalUnits) && angular.isNumber(row.entity.additionalDecisionalUnits)) {
        //   currentTotals = row.entity.decisionalUnits + row.entity.additionalDecisionalUnits;
        //   vm.existingTotals = currentTotals.toFixed(2);
        //   return vm.existingTotals;
        // } else if ((angular.isNumber(row.entity.decisionalUnits)) && !(angular.isNumber(row.entity.additionalDecisionalUnits))) {
        //   currentTotals = row.entity.decisionalUnits;
        //   vm.existingTotals = currentTotals.toFixed(2);
        //   return vm.existingTotals;
        // } else if (!(angular.isNumber(row.entity.decisionalUnits)) && (angular.isNumber(row.entity.additionalDecisionalUnits))) {
        //   currentTotals = row.entity.additionalDecisionalUnits;
        //   vm.existingTotals = currentTotals.toFixed(2);
        //   return vm.existingTotals;
        // } else {
        //   vm.existingTotals = null;
        //   return vm.existingTotals;
        // }
      };
      $scope.checkIsNumber = function (number) {
        // if(vm.existingNumber && vm.existingNumber.trim() == ""){
        //   return;
        // }

        if (number && angular.isNumber(number)) {
          return number;
        } else if (number && angular.isString(number) && number.trim() !== "") {
          return parseInt(number, CONSTANTS.GLOBAL.RADIX);
        }
        return 0;
      };

      vm.documentsGridOptions = {
        enableFiltering: true,
        enableGridMenu: false,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.WHEN_NEEDED,
        exporterMenuCsv: false,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        enableRowSelection: true,
        treeRowHeaderAlwaysVisible: false,
        useExternalFiltering: true,
        enableCellEditOnFocus: true
      };


      vm.documentsGridOptions.columnDefs = [{
          displayName: "Case #",
          cellTooltip: true,
          headerTooltip: 'Case #',
          enableHiding: false,
          field: "appealNumber",
          sort: {},
          visible: true,
          width: 95
        },
        {
          displayName: "Application #",
          headerTooltip: 'Application #',
          cellTooltip: true,
          enableHiding: false,
          field: "serialNumber",
          cellEditableCondition: false,
          width: 120
        },
        {
          displayName: "Assignment title",
          headerTooltip: 'Assignment title',
          cellTooltip: true,
          enableHiding: false,
          field: "assignmentTitle",
          cellEditableCondition: false,
          width: 200
        },
        {
          displayName: "Credits awarded to",
          headerTooltip: 'Credits awarded to',
          cellTooltip: true,
          enableHiding: false,
          field: "decisionalUnitsAwarded",
          cellEditableCondition: false,
          type: "string",
          width: 140
        },
        {
          displayName: "Assigned date",
          headerTooltip: 'Assigned date',
          cellTooltip: true,
          enableHiding: false,
          field: "assignedDate",
          type: "date",
          cellFilter: "date:'MM/dd/yyyy'",
          cellEditableCondition: false,
          width: 130
        },
        {
          displayName: "Completed date",
          headerTooltip: 'Completed date',
          cellTooltip: true,
          enableHiding: false,
          field: "completionDate",
          cellEditableCondition: false,
          type: "date",
          cellFilter: "date:'MM/dd/yyyy'",
          width: 135
        },
        {
          displayName: "DU",
          headerTooltip: 'Decisional units (DU)',
          cellTooltip: true,
          field: "decisionalUnits",
          type: "number",
          enableHiding: false,
          cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
            return vm.userId !== row.entity.decisionalUnitsAwardedIdentifier ? 'editableDecision' : '';
          },
          headerCellClass: 'editableDecision',
          cellFilter: "number: 2",
          cellEditableCondition: function ($scope) {
            return vm.userId !== $scope.row.entity.decisionalUnitsAwardedIdentifier;
          },
          width: 70
        },
        {
          displayName: "ADU",
          headerTooltip: 'Additional DUs (ADU)',
          cellTooltip: true,
          enableHiding: false,
          field: "additionalDecisionalUnits",
          headerCellClass: 'editableDecision',
          cellEditableCondition: function ($scope) {
            return vm.userId !== $scope.row.entity.decisionalUnitsAwardedIdentifier;
          },
          type: "number",
          cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
            return vm.userId !== row.entity.decisionalUnitsAwardedIdentifier ? 'editableDecision' : '';
          },
          cellFilter: "number: 2",
          width: 70
        },
        {
          displayName: "PC",
          headerTooltip: 'Production credit (PC)',
          cellTooltip: true,
          enableHiding: false,
          field: "productivityCredit",
          headerCellClass: 'editableDecision',
          type: "number",
          cellEditableCondition: function ($scope) {
            return vm.userId !== $scope.row.entity.decisionalUnitsAwardedIdentifier;
          },
          cellFilter: "number: 2",
          cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
            return vm.userId !== row.entity.decisionalUnitsAwardedIdentifier ? 'editableDecision' : '';
          },
          width: 70
        },
        {
          displayName: "APC",
          headerTooltip: 'Additional production credits (APC)',
          cellTooltip: true,
          field: "additionalProdCredits",
          type: "number",
          enableHiding: false,
          headerCellClass: 'editableDecision',
          //cellEditableCondition: true,
          cellEditableCondition: function ($scope) {
            return vm.userId !== $scope.row.entity.decisionalUnitsAwardedIdentifier;
          },
          cellFilter: "number: 2",
          cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
            return vm.userId !== row.entity.decisionalUnitsAwardedIdentifier ? 'editableDecision' : '';
          },

          width: 70
        },
        {
          displayName: "PT",
          headerTooltip: 'Due date points',
          cellTooltip: true,
          field: "patentTimeliness",
          type: "number",
          enableHiding: false,
          headerCellClass: 'editableDecision',
          cellEditableCondition: function ($scope) {
            return vm.userId !== $scope.row.entity.decisionalUnitsAwardedIdentifier;
          },
          cellFilter: "number: 2",
          cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
            return vm.userId !== row.entity.decisionalUnitsAwardedIdentifier ? 'editableDecision' : '';
          },
          width: 70
        },
        {
          displayName: "Reason for update *",
          headerTooltip: 'Reason for update *',
          cellTooltip: true,
          headerCellClass: 'editableDecision',
          cellEditableCondition: function ($scope) {
            return vm.userId !== $scope.row.entity.decisionalUnitsAwardedIdentifier;
          },
          field: "aReason",
          enableHiding: false,
          cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
            return vm.userId !== row.entity.decisionalUnitsAwardedIdentifier ? 'editableDecision' : '';
          }
        },
        {
          displayName: "Modified?",
          headerTooltip: 'Modified?',
          cellTooltip: true,
          field: "isModified",
          enableHiding: false,
          cellEditableCondition: false,
          width: 130
        }
      ];

      vm.documentsGridOptions.data = gridData;
      vm.editedRows = 0;
      angular.forEach(vm.documentsGridOptions.data, function (row) {
        if (row.decisionalUnitsAwardedIdentifier === vm.userId) {
          row.isModified = "N/A";
        } else {
          row.isModified = "No";
        }
      });
      $scope.myData1 = angular.copy(vm.documentsGridOptions.data);
      vm.documentsGridOptions.onRegisterApi = function (gridApi) {
        vm.documentsGridApi = gridApi;

        vm.documentsGridApi.edit.on.afterCellEdit($scope, function (rowEntity, colDef, newValue, oldValue) {
          if (colDef.field !== 'aReason' && (newValue !== oldValue)) {
            vm.valueChanged = true;
            rowEntity.isModified = "Yes";
            setNumberOfRowsChanged();
          }
        });

        //vm.documentsGridApi.core.notifyDataChange( uiGridConstants.dataChange.COLUMN );
        vm.documentsGridApi.core.on.filterChanged($scope, function () {
          var grid = this.grid;
          $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
          if ($scope.numberOfFilters === 0) {
            vm.documentsGridOptions.data = $scope.myData1;
          } else {
            var filteredData = SearchHelperService.filterGrid(grid, $scope.myData1);
            vm.documentsGridOptions.data = filteredData;
          }
        });
      };

      function getModifiedRows() {
        var validRows = [];
        angular.forEach(vm.documentsGridOptions.data, function (row) {
          if (row.isModified === 'Yes') {
            validRows.push(row);
          }
        });
        return validRows;

      }

      function validateUpdatedRows(updatedRows) {
        var invalidRows = [];
        angular.forEach(updatedRows, function (row) {
          if (!row.aReason || row.aReason.length === 0) {
            invalidRows.push(row);
          }
        });
        return invalidRows;
      }

      vm.cancelUpdate = function () {
        ngDialog.closeAll(false);
      };


      vm.updateCredits = function () {
        var updatedRows = getModifiedRows();
        var invalidRows = validateUpdatedRows(updatedRows);
        if (invalidRows.length > 0) {
          CommonHelperService.setToastr("Reason is required for all modified values. " + invalidRows.length + " row(s) missing Reason", "error");
          return;
        }

        var rowsToSave = [];
        var item = 0;
        angular.forEach(updatedRows, function (row) {
          var valueChanged = false;
          var origRow = vm.originalData[item];
          var data = {
            ptabAssignmentIdentifier: row.ptabAssignmentIdentifier,
            decisionalUnitsAwardedIdentifier: row.decisionalUnitsAwardedIdentifier,
            appealNumber: row.appealNumber,
            serialNumber: row.serialNumber,
            audit: {
              lastModifiedTimestamp: new Date().getTime(),
              lastModifiedUserIdentifier: vm.userId,
              createUserIdentifier: vm.userId,
              lockControlNumber: row.lockControlNumber
            },
            reason: row.aReason
          };
          if (row.decisionalUnits !== origRow.decisionalUnits) {
            data.decisionalUnits = row.decisionalUnits;
            valueChanged = true;
          }

          if (row.additionalDecisionalUnits !== origRow.additionalDecisionalUnits) {
            data.additionalDecisionalUnits = row.additionalDecisionalUnits;
            valueChanged = true;
          }
          if (row.additionalProdcutionCredits !== origRow.additionalProdcutionCredits) {
            data.additionalProdcutionCredits = row.additionalProdcutionCredits;
            valueChanged = true;
          }

          if (row.productivityCredit !== origRow.productivityCredit) {
            data.productivityCredit = row.productivityCredit;
            valueChanged = true;
          }
          if (row.patentTimeliness !== origRow.patentTimeliness) {
            data.patentTimeliness = row.patentTimeliness;
            valueChanged = true;
          }

          if (valueChanged) {
            rowsToSave.push(data);
          }

        });

        if (rowsToSave.length === 0) {
          CommonHelperService.setToastr(CONSTANTS.TOASTER.noChanges, "error");
          return;
        }
        HttpFactory.putActions(CONSTANTS.URL.UPDATE_CREDITS, rowsToSave)
          .then(function () {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.creditsSuccess, "success");
            ngDialog.closeAll(true);

          }, function (failureResponse) {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(failureResponse.data.message, "warning");
          });
      };

      function setNumberOfRowsChanged() {
        var editedRows = 0;
        angular.forEach(vm.documentsGridOptions.data, function (row) {
          if (row.isModified === 'Yes') {
            editedRows++;
          }
        });
        vm.editedRows = editedRows;
      }
    });
})();
