(function () {
  'use strict';

  describe('MyCreditsController', function () {

    beforeEach(module('ptabe2e'));

    var vm = this;
    var scope;
    var controller, $controller;
    var $http, $interval, $log, $rootScope, spy, row, url, advancedSearchFlag;
    var $q, HttpFactoryDeferred, timeout, row, rowRenderIndex, col;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close', 'open']);
    var successResponse = {
      data: {
        events: {},
        refreshInterval: 0
      }
    };

    var failureResponse = '';


    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              getWidgetZone: function () {

              },
              setWidgetContentHeight: function () {

              },
              userInfo: {
                "userId": "pgandhi"
              }
            }
          }
        },

        on: function () {

        }

      }
    };
    var fakeVm = {
      getWidgetZone: function () {

      },
      setWidgetContentHeight: function () {

      }
    };

    var refreshGrid = {
      value: "data"
    }

    beforeEach(inject(function (_$controller_, _$http_, _$rootScope_, _$timeout_, _$interval_, $compile, _$q_, HttpFactory, CONSTANTS) {
      $q = _$q_;
      $http = _$http_;
      scope = _$rootScope_.$new();
      $interval = _$interval_;
      $rootScope = _$rootScope_;
      timeout = _$timeout_;

      $rootScope.userInfo = {
        "userId": "pgandhi"
      }

      // setup the promise
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);

      $controller = _$controller_;

      scope.definition = {
        dataUrlText: 'http://localhost:8080/PTABServices/',
        widgetIdentifier: 12
      }

      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback1, callback2) {
            callback1(refreshGrid);
          }
        },
        then: function (callback3, callback4) {
          callback3();
        }
      });

      spy = spyOn(angular, 'element').and.callFake(fakeElement);


      scope.$parent = {
        $parent: {
          $parent: {
            definition: {
              zoneWidth: 12
            }
          }
        }
      }

      controller = $controller('MyCreditsController', {
        $http: $http,
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        $interval: $interval,
        HttpFactory: HttpFactory

      });

      // spyOn($rootScope, '$on').and.callThrough();
    }));


    afterEach(function () {
      spy.and.callThrough();
    });


    describe('check functions', function () {
      it('it should call getDistinctAssignmentTypes ', function () {
        var data = {

        }
        expect(controller.getDistinctAssignmentTypes).toBeDefined();
        controller.getDistinctAssignmentTypes(data);
      });

      it('it should call getMyCredits ', function () {
        var widgetId = "581";
        expect(controller.getMyCredits).toBeDefined();
        controller.getMyCredits(widgetId);
      });

      it('it should call getMyCredits ', function () {
        var refreshGridByMonth = "5";
        expect(controller.getMyCredits).toBeDefined();
        controller.getMyCredits();
      });

      it('it should call myCreditsGridOptions ', function () {
        expect(scope.myCreditsGridOptions.gridMenuCustomItems).toBeDefined();
        scope.myCreditsGridOptions.gridMenuCustomItems;
      });

      it('it should call setColumnDefs ', function () {
        expect(scope.setColumnDefs).toBeDefined();
        scope.setColumnDefs();
      });

      // it('it should call onRegisterApi ', function () {
      //   expect(scope.myCreditsGridOptions.onRegisterApi).toBeDefined();
      //   scope.myCreditsGridOptions.onRegisterApi();
      // });
      it('listItemUp should call move item', function () {
        expect(scope.listItemUp).toBeDefined();
        spyOn(scope, 'moveItem');
        expect(scope['moveItem']).toBeDefined();
        scope.listItemUp(1);
        expect(scope.moveItem).toHaveBeenCalledWith(1, 0);
      });

      it('it should call getData ', function () {
        var data = {"assigneeFullNameText": "assigneeFullNameText", "assigneeNumberText": "assigneeNumberText"};
        expect(scope.getData).toBeDefined();
        scope.getData(data);
      });

      it('Should invoke enterOnActions', function () {
        var event = {};
        event.keyCode = 1;
        var functionToInvoke = 'pgandhi';
        expect(scope['enterOnActions']).toBeDefined();
        scope.enterOnActions(event, functionToInvoke);
      });

      // it('moveItem should swap origin and destination', function () {
      //   var origin = 0,
      //     destination = 1;
      //   var updatedMyCreditsColumnList = [{
      //     'userFavoritesName': 'testFavouriteOrigin',
      //     'userFavoritesURL': 'google.com'
      //   }, {
      //     'userFavoritesName': 'testFavouriteDest',
      //     'userFavoritesURL': 'bin.com'
      //   }];
      //   var updatedMyCreditsColumnListCopy = [{
      //     'userFavoritesName': 'testFavouriteOrigin',
      //     'userFavoritesURL': 'google.com'
      //   }, {
      //     'userFavoritesName': 'testFavouriteDest',
      //     'userFavoritesURL': 'bin.com'
      //   }];
      //   scope.updatedMyCreditsColumnList = updatedMyCreditsColumnList;
      //   expect(scope.moveItem).toBeDefined();
      //   scope.moveItem(origin, destination);

      //   expect(scope.updatedMyCreditsColumnList[0].userFavoritesName).not.toBe(updatedMyCreditsColumnListCopy[0].userFavoritesName);
      //   expect(scope.updatedMyCreditsColumnList[0].userFavoritesURL).not.toBe(updatedMyCreditsColumnListCopy[0].userFavoritesURL);

      // });

      it('listItemUp should call move item', function () {
        expect(scope.listItemUp).toBeDefined();
        spyOn(scope, 'moveItem');
        expect(scope['moveItem']).toBeDefined();
        scope.listItemUp(1);
        expect(scope.moveItem).toHaveBeenCalledWith(1, 0);
      });

      it('it should call getMyCredits ', function () {
        expect(controller.getMyCredits).toBeDefined();
        controller.getMyCredits();
      });

      it('it should call getPayPeriodAsString ', function () {
        var input = null;
        expect(scope.getPayPeriodAsString).toBeDefined();
        scope.getPayPeriodAsString(input);
      });

      it('it should call settPayPeriodId ', function () {
        var data = {"null": "null"};
        expect(scope.settPayPeriodId).toBeDefined();
        scope.settPayPeriodId(data);
      });

      it('listItemDown should call move item', function () {
        expect(scope.listItemDown).toBeDefined();
        spyOn(scope, 'moveItem');
        expect(scope['moveItem']).toBeDefined();
        scope.listItemDown(1);
        expect(scope.moveItem).toHaveBeenCalledWith(1, 2);
      });

      it('it should call getAssignmentById ', function () {
        var ptabID = '1561';
        expect(controller.getAssignmentById).toBeDefined();
        controller.getAssignmentById(ptabID);
      });

      it('it should call openAssignmentInfo ', function () {
        var row = {
          entity: {
            ptabAssignmentIdentifier: "1561"
          }
        }
        expect(scope.openAssignmentInfo).toBeDefined();
        scope.openAssignmentInfo(row);
      });

      // it('it should call ngdialogConfig ', function () {
      //   expect(controller.ngdialogConfig).toBeDefined();
      //   controller.ngdialogConfig();
      // });

      // it('it should call enterDate ', function () {
      //   expect(scope.enterDate).toBeDefined();
      //   scope.enterDate();
      // });

      it('Should invoke getWorker', function () {
        var event = {};
        event.keyCode = 13;

        var searchText = 'pgandhi';

        spyOn(scope, 'simpleSearch');
        expect(scope['simpleSearch']).toBeDefined();
        expect(scope['pressEnter']).toBeDefined();
        scope.pressEnter(event, searchText);
        expect(scope.simpleSearch).toHaveBeenCalled();
      });

      it(' should call openCaseViewer', function () {
        row = {
          entity: {
            caseNumber: '2018005819',
            applicationNumber: '15007114'
          }
        }
        expect(scope['openCaseViewer']).toBeDefined();
        scope.openCaseViewer(row);
      });

      it(' should get MyCreditsColumns ', function () {

        expect(scope.getMyCreditsColumns).toBeDefined();
        scope.getMyCreditsColumns();
      });


      it('Should invoke simpleSearch', function () {
        var textToSearch = "pgandhi"
        scope.gridOptions = {
          data: [{}]
        }
        expect(scope['simpleSearch']).toBeDefined();
        scope.simpleSearch(textToSearch);
      });

      // it('it should call ngdialogConfig ', function () {
      //   var template, controller, row, width= false;
      //   expect(controller.ngdialogConfig).toBeDefined();
      //   controller.ngdialogConfig(template, controller, row, width);


      //   expect(ngDialog.open).toHaveBeenCalled();

      //   expect(ngDialog.open.calls.count()).toBe(1);
      //   var args = ngDialog.open.calls.argsFor(0);
      //   expect(args).not.toBe(null);
      //   expect(args.length).toBe(1);

      //   expect(args[0].controller).toBe('correctDuController');
      //   expect(typeof args[0].resolve).toBe('object');
      //   args[0].resolve.items();
      //   args[0].resolve.readOnly();
      //   args[0].resolve.rowData();
      // });

      it('it should call correctDu ', function () {
        var row = {

        }
        expect(scope['correctDu']).toBeDefined();
        scope.correctDu();


        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(1);
        var args = ngDialog.open.calls.argsFor(0);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('correctDuController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.items();
        args[0].resolve.widgetIdentifier();
      });


      it('it should call rellocateDu ', function () {

        expect(scope['rellocateDu']).toBeDefined();
        scope.rellocateDu();


        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(2);
        var args = ngDialog.open.calls.argsFor(1);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('reallocateDuController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.rowData();
        args[0].resolve.widgetIdentifier();

      });


      it('it should call requestADU ', function () {
        var row = {
          entity: {
            type: "Request"
          }
        }
        expect(scope['requestADU']).toBeDefined();
        scope.requestADU(row);


        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(3);
        var args = ngDialog.open.calls.argsFor(2);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('requestADUController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.rowData();
        args[0].resolve.requestType();
        args[0].resolve.widgetIdentifier();

      });

      it('it should call reconsiderAdu ', function () {
        var row = {
          entity: {
            type: "Reconsideration"
          }
        }
        expect(scope['reconsiderAdu']).toBeDefined();
        scope.reconsiderAdu(row);


        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(4);
        var args = ngDialog.open.calls.argsFor(3);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('requestADUController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.rowData();
        args[0].resolve.requestType();
        args[0].resolve.widgetIdentifier();

      });

      it(' should get updateColumns ', function () {
        scope.gridState = {
          paginationSize: 10
        }
        expect(scope.updateColumns).toBeDefined();
        scope.updateColumns();
      });


      it('it should call updateCredits ', function () {
        var row = {
          entity: {
            type: "Reconsideration"
          }
        }
        expect(scope['updateCredits']).toBeDefined();
        scope.updateCredits(row);


        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(5);
        var args = ngDialog.open.calls.argsFor(4);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('updateCreditsController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.items();

      });

      it(' should get callMyTeam ', function () {
        expect(scope.callMyTeam).toBeDefined();
        scope.callMyTeam();
      });

      it(' should get callMyGroup ', function () {
        expect(scope.callMyGroup).toBeDefined();
        scope.callMyGroup();
      });

      it(' should get getMyTeamCredits ', function () {
        expect(scope.getMyTeamCredits).toBeDefined();
        scope.getMyTeamCredits();
      });

      it(' should get getMyGroupCredits ', function () {
        expect(scope.getMyGroupCredits).toBeDefined();
        scope.getMyGroupCredits();
      });

      it(' should get getTimeFrames ', function () {
        var value = "PREVIOUSMONTH";
        expect(scope.checkTimeFrame).toBeDefined();
        scope.checkTimeFrame(value);
      });

      it(' should get getTimeFrames ', function () {
        var value = "PREVIOUSMONTH";
        expect(scope.getTimeFrames).toBeDefined();
        scope.getTimeFrames(value);
      });

    });

  });
})();
