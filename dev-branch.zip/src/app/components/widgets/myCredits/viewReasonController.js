(function () {
  "use strict";

  angular
    .module("ptabe2e")
    .controller("viewReasonController", function (rowData) {
      var vm = this;
      vm.reasonInFullView = rowData.entity.reason;
    });
})();
