(function () {
  "use strict";
  angular
    .module('ptabe2e').directive('tooltip', function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          element.hover(function () {
            // on mouseenter
            element.tooltip('show');
          }, function () {
            // on mouseleave
            element.tooltip('hide');
          });
        }
      };
    })
    .controller('EnterOtherCreditsController', function ($scope, $rootScope,  $timeout, ngDialog, CONSTANTS, HttpFactory, CommonHelperService, CreditsModalControllerHelper) { //userInfo
      var vm = this;
      vm.judge = {
        "fullName": null
      };
      vm.judge2 = {
        "fullName": null
      };

      $scope.userInfo = $rootScope.userInfo;
      if (!$scope.userInfo) {
        $scope.userInfo = {
          "userId": $window.sessionStorage.getItem("workerNumber")
        };
      }
      vm.caseTypes = [];
      vm.stndAssignmentTypes = [];
      vm.showDefaultText = false;
      vm.creditRows = [];
      vm.judgeList = [];
      vm.showList = false;
      vm.focusMoved = false;
      vm.noCaseType = true;
      vm.assignmentTypeSelected = null;
      vm.disablePageCt = true;
      vm.selectedCaseTypeCode = null;
      vm.disableSave = true;
      var row = {};
      row.edit = false;
      vm.editModeCaseType = true;
      vm.editModeCaseNum = true;
      vm.editModeAssignType = true;
      vm.disableClose = false;
      vm.enableRowEdit = true;
      getAssignnmentCaseTypesInitial();
      vm.saveCreditInfo = function () {
        if (invalidateForm()) {
          return;
        }
        var creditRow = {
          awardeeName: vm.judge,
          caseType: vm.selectedCaseTypeCode,
          appealNumber: vm.caseNumber,
          assignmentType: CreditsModalControllerHelper.getAssignmentTypeObject(vm.assignmentType, vm.stndAssignmentTypes),
          pageCount: vm.pageCount,
          productionCredits: vm.pc,
          additonalProductivityCredits: vm.additonalProductivityCredits,
          noteText: (vm.noteText != null && vm.noteText != undefined) ? vm.noteText : "",
          completionDate: vm.completionDate.getTime(),
          assignedDate: vm.assignedDate.getTime()
        };

        var currentTime = Math.floor(new Date().getTime() / 1000);
        var saveCreditData = {
          appealNumber: creditRow.appealNumber,
          caseNumber: creditRow.appealNumber,
          caseType: creditRow.caseType,
          assignedDate: creditRow.assignedDate,
          completionDate: creditRow.completionDate,
          pageCount: creditRow.pageCount,
          additonalProductivityCredits: creditRow.additonalProductivityCredits,
          productionCredits: creditRow.productionCredits,
          noteText: creditRow.noteText,
          // creditAwardId:parseInt(creditRow.awardeeName.assigneeNumberText),
          applicationUserId: creditRow.awardeeName.assigneeNumberText,
          assignmentTypeId: vm.assignmentType,
          audit: {
            "createUserIdentifier": $scope.userInfo.userId,
            "lastModifiedUserIdentifier": $scope.userInfo.userId,
            "lastModifiedTimestamp": currentTime,
            "createdUserName": $scope.userInfo.userId,
            "createTimestamp": currentTime,
            "lockControlNumber": 0
          }
        }

        HttpFactory.postActions(CONSTANTS.URL.OTHER_CREDITS_SAVE, saveCreditData)
          .then(function (success) {
            vm.savedData = success.data;
            creditRow.ptabAssignmentId = vm.savedData.ptabAssignmentId;
            vm.creditRows.push(creditRow);
            vm.clearForm();
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr("Other credits have been saved.", "success");
          }, function (failureResponse) {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(failureResponse.data.message, "warning");
          });
          vm.assignmentTypeSelected =null;
          vm.enableRowEdit =false;
          vm.selectedCaseTypeCode =null;
        vm.disableClose = false;
        vm.saveOtherCreditsClicked = true;
      };

      vm.getSavedOtherCredits = function (selectedUser) {
        HttpFactory.getActions(CONSTANTS.URL.GET_OTHER_CREDITS + selectedUser)
          .then(function (successResponse) {
            vm.creditRows = successResponse.data;

          },
            function () {
              // intentional
            });
      }

      function invalidateForm() {
        vm.errorFound = false;
        vm.judgeInvalid = checkFormModel(vm.judge.fullName)
        vm.caseNumberInvalid = checkFormModel(vm.caseNumber);
        vm.caseTypeInvalid = checkFormModel(vm.caseType);
        vm.assignmentTypeInvalid = checkFormModel(vm.assignmentType);
        vm.pcInvalid = checkFormModel(vm.pc);
        vm.completionDateInvalid = checkFormModel(vm.completionDate);
        vm.assignedDateInvalid = checkFormModel(vm.assignedDate);
        return vm.errorFound;
      }

      function checkFormModel(formModel) {
        if (!formModel) {
          vm.errorFound = true;
          return true;
        }
        return false;
      }

      var pageCountValues = [];
      var values = "0-10";
      pageCountValues.push(values);
      values = "11-20";
      pageCountValues.push(values);

      vm.changedValue = function(){
        var originalPgCt = angular.copy(vm.originalRowInfor.pageCount);
        var originalApc = angular.copy(vm.originalRowInfor.additonalProductivityCredits);
        var originalNote = angular.copy(vm.originalRowInfor.noteText);
        if (originalPgCt != vm.editedPageCount ||originalApc != vm.editedAPC||originalNote !=vm.editedNote)
        {
          vm.enableRowEdit = true;
        } else{ 
          vm.enableRowEdit = false;
        }
      }

      vm.pageCountChanged = function (caseType, count,row) {
        HttpFactory.getActions(CONSTANTS.URL.OTHERCREDITS_PAGE_COUNT + caseType + "&pageCnt=" + count)
          .then(function (successResponse) {
            if(row){
              vm.editedPC = successResponse.data.workCreditQuantity;
            }else {
              vm.pc = successResponse.data.workCreditQuantity;
            }
          },
            function () {
              // intentional
            });
      }

      vm.selectAssignType = function (value) {
        vm.assignmentTypeSelected = value.vm.assignmentType;
        if (vm.assignmentTypeSelected != 'null' && vm.assignmentTypeSelected != '') {
          vm.disablePageCt = false;
          HttpFactory.getActions(CONSTANTS.URL.OTHER_CREDITS_VALIDATION + vm.caseNumber + "&caseType=" + vm.selectedCaseTypeCode + "&assignmentTypeId=" + vm.assignmentTypeSelected + "&applicationUserId=" + vm.selectedJudge.assigneeNumberText)
            .then(function (successResponse) {
              if (successResponse.data.strMessage == 'Enter Other credits' || successResponse.data.strMessage == null) {
                vm.disableSave = false;
                vm.pageCount = successResponse.data.pageCount;
                vm.productionCredits = successResponse.data.productionCredits;
                if (vm.productionCredits) {
                  vm.disablePageCt = true;
                  vm.pageCount = "N/A";
                }
              }
            },
              function (error) {
                if (error.status == "400") {
                  CommonHelperService.setToastr(error.data.message, "error");
                } else {
                  CommonHelperService.setToastr(error.data.strMessage, "error");
                }

                vm.disableSave = true;
              });
        } else {
          vm.disablePageCt = true;
          vm.pageCount = null;
        }


      };

      vm.editRow = function (row) {
        vm.enableRowEdit = false;
        vm.originalRowInfor = row;
        vm.disableClose = true;
        vm.editMode = true;
        vm.editModeCaseType = true;
        vm.editModeCaseNum = true;
        vm.editModeAssignType = true;
        row.edit = true;
        vm.editedPageCount = parseInt(row.pageCount);
        vm.editedPC = row.productionCredits;
        vm.editedAPC = row.additonalProductivityCredits;
        vm.editedNote = row.noteText;
      };

    vm.closeModalOtherCredits = function(){
      if (vm.pc == ""|| vm.pc == undefined || vm.pc == null ) {
        vm.pc = "";
      }
      if  (vm.additonalProductivityCredits == undefined || vm.additonalProductivityCredits == "" || vm.additonalProductivityCredits ==null){
        vm.additonalProductivityCredits = "";
      }
      if(vm.additonalProductivityCredits == "" || vm.additonalProductivityCredits ==null) {
        vm.additonalProductivityCredits = "";
      }
      if (vm.judge.fullName ==null || vm.judge.fullName == "") {
        vm.judge.fullName = "";
      }
       if (vm.caseNumber == "" ||  vm.caseNumber == null || vm.caseNumber == undefined){
        vm.caseNumber = "";
       }
       if(vm.caseType == "" || vm.caseType == undefined)  {
        vm.caseType = "";
       }
       if (vm.assignmentTypeSelected =="" ||vm.assignmentTypeSelected ==null ) {
        vm.assignmentTypeSelected = "";
       }
       if (vm.completionDate == null || vm.completionDate == "" || vm.completionDate == undefined)  {
        vm.completionDate = "";
       }
       if (vm.assignedDate == undefined|| vm.assignedDate == "" ||vm.assignedDate== null) {
        vm.assignedDate ="";
       }

       if( (vm.additonalProductivityCredits ===""&& vm.judge.fullName === "" && vm.caseNumber === "" && vm.caseType === ""  &&  vm.assignmentTypeSelected === ""&& vm.completionDate === "" && vm.assignedDate ==="" &&!vm.saveOtherCreditsClicked) || (vm.additonalProductivityCredits ===""&& vm.judge.fullName === "" && vm.caseNumber === "" && vm.caseType === ""  &&  vm.assignmentTypeSelected === ""&& vm.completionDate === "" && vm.assignedDate ==="" && vm.saveOtherCreditsClicked && !vm.disableClose) || ( (vm.disableClose && vm.saveOtherCreditsClicked && !vm.enableRowEdit))){
        $timeout(function () {
          document.getElementById('closeTheModal').click();
       }, 200);
      }
     else if((vm.pc != ""|| vm.pc !== undefined || vm.pc != null || vm.additonalProductivityCredits != "" || vm.additonalProductivityCredits !=null) ||( (vm.additonalProductivityCredits != "" || vm.additonalProductivityCredits !=null) && (vm.judge.fullName !=null || vm.judge.fullName !== "") &&  (vm.caseNumber !== "" ||  vm.caseNumber !== null) && (vm.caseType == "1" || vm.caseType == "2" || vm.caseType == "3"||vm.caseType == "4")  && (vm.assignmentTypeSelected !=="" ||vm.assignmentTypeSelected !==null ) && (vm.completionDate !== null || vm.completionDate !== "" || vm.completionDate !== undefined) && (vm.assignedDate !== undefined|| vm.assignedDate !== "" ||vm.assignedDate!== null)) && (vm.saveOtherCreditsClicked)){
        ngDialog.openConfirm({ 
          template: "app/components/widgets/myCredits/enterOtherCreditsCloseModal.html",
          scope: $scope,
          width: '30%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false
            })
          .then(function () {
            console.log("Yes");
    $timeout(function () {
             document.getElementById('closeTheModal').click();
          }, 500);
          }, function () {  //may implement later
          });
      } else if( (vm.judge.fullName !== null) && vm.saveOtherCreditsClicked ){
      ngDialog.openConfirm({ 
        template: "app/components/widgets/myCredits/enterOtherCreditsCloseModal.html",
        scope: $scope,
        width: '30%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false
          })
        .then(function () {
          console.log("Yes");
  $timeout(function () {
           document.getElementById('closeTheModal').click();
        }, 500);
        }, function () {//may implement later
        });
    }
     else if( (vm.caseNumber !== null || vm.caseType !== "" || vm.assignmentTypeSelected !=null || vm.assignmentTypeSelected !=null ||  vm.completionDate !== "" || vm.assignedDate !== "") && vm.saveOtherCreditsClicked ){ 
        ngDialog.openConfirm({ 
          template: "app/components/widgets/myCredits/enterOtherCreditsCloseModal.html",
          scope: $scope,
          width: '30%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false
            })
          .then(function () {
            console.log("Yes");
    $timeout(function () {
             document.getElementById('closeTheModal').click();
          }, 500);
          }, function () { //may implement later
          });
      }
      else if( (!vm.enableRowEdit) && (!vm.editMode || vm.editMode == undefined) && (vm.judge.fullName == null ||vm.judge.fullName == "") && (vm.caseNumber == undefined || vm.caseNumber == "") && (vm.caseType == null || vm.caseType == "" || vm.caseType == undefined) && (vm.assignmentTypeSelected ==null || vm.assignmentTypeSelected =="") && (vm.completionDate == undefined || vm.completionDate == "") && (vm.assignedDate == undefined || vm.assignedDate == "")){
        $timeout(function () {
          document.getElementById('closeTheModal').click();
       }, 200);
      } else{       
     /* istanbul ignore next */
      ngDialog.openConfirm({ 
       template: "app/components/widgets/myCredits/enterOtherCreditsCloseModal.html",
       scope: $scope,
       width: '30%',
       showClose: false,
       closeByEscape: false,
       closeByDocument: false
         })
       .then(function () {
         console.log("Yes");
 $timeout(function () {
          document.getElementById('closeTheModal').click();
       }, 500);
       }, function () {
         //may implement later
       });
      }
      }

      vm.addAssignmentCredit = function () {
        vm.editMode = false;
        vm.warningMessage = "";
        vm.saveCreditInfo();
      };

      vm.discardAssignmentCredit = function () {
        vm.editMode = false;
        vm.warningMessage = "";
      };

      vm.clearForm = function () {
        vm.assignmentTypeSelected = null;
        vm.enableRowEdit =false;
        vm.pageRange = null;
        vm.judge = {
          "fullName": null
        };
        vm.noCaseType = true;
        vm.caseType = "";
        vm.caseNumber = null,
          vm.assignmentType = "";
        vm.pageCount = null;
        vm.pc = null;
        vm.additonalProductivityCredits = null;
        vm.noteText = "";
        vm.completionDate = "";
        vm.assignedDate = "";

        vm.judgeInvalid = false;
        vm.errorFound = false;
        vm.caseNumberInvalid = false;
        vm.caseTypeInvalid = false;
        vm.assignmentTypeInvalid = false;
        vm.pcInvalid = false;
        vm.completionDateInvalid = false;
        vm.assignedDateInvalid = false;
        vm.selectedCaseTypeCode = null;
      };

      // Still need to save row to database calling a service.
      vm.saveEditRow = function (row) {
        vm.disableClose = false;
        var currentTime = Math.floor(new Date().getTime() / 1000);
        var updateCreditData = {
          appealNumber: row.appealNumber,
          caseType: row.caseType,
          assignedDate: row.assignedDate,
          completionDate: row.completionDate,
          pageCount: vm.editedPageCount,
          additonalProductivityCredits: vm.editedAPC,
          productionCredits: vm.editedPC,
          noteText: vm.editedNote,
          awardeeUserId: row.awardeeName.assigneeNumberText,
          ptabAssignmentId: row.ptabAssignmentId,
          audit: {
            "createUserIdentifier": $scope.userInfo.userId,
            "lastModifiedUserIdentifier": $scope.userInfo.userId,
            "lastModifiedTimestamp": currentTime,
            "createdUserName": $scope.userInfo.userId,
            "createTimestamp": currentTime,
            "lockControlNumber": 0
          }
        }
        HttpFactory.putActions(CONSTANTS.URL.UPDATE_EXISITNG_CREDITS, updateCreditData)
          .then(function (success) {
            row.edit = false;
            vm.editMode = false;
            row.noteText = updateCreditData.noteText;
            row.productionCredits = updateCreditData.productionCredits;
            row.additonalProductivityCredits = updateCreditData.additonalProductivityCredits;
            row.pageCount = updateCreditData.pageCount;
            CommonHelperService.setToastr("Edited information has been saved successfully.", "success");
          }, function (failureResponse) {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(failureResponse.data.message, "warning");
          });
      }

      function invalidateEditForm() {
        vm.editedAssignmentType = vm.editedAssignmentType.trim();
        vm.judgeInvalidEdit = checkFormModel(vm.judge2.fullName);
        vm.caseNumberInvalidEdit = checkFormModel(vm.editedCaseNumber);
        vm.caseTypeInvalidEdit = checkFormModel(vm.editedCaseType);
        vm.assignmentTypeInvalidEdit = checkFormModel(vm.editedAssignmentType);
        vm.pcInvalidEdit = checkFormModel(vm.editedPC);
        vm.completionDateInvalidEdit = checkFormModel(vm.editedCompletionDate);
        vm.assignedDateInvalidEdit = checkFormModel(vm.editedAssignedDate);
        vm.errorFound = false;

        return vm.judgeInvalidEdit || vm.caseNumberInvalidEdit || vm.caseTypeInvalidEdit || vm.assignmentTypeInvalidEdit ||
          vm.pcInvalidEdit || vm.completionDateInvalidEdit || vm.assignedDateInvalid;
      }

      vm.cancelEdit = function (row) {
        vm.disableClose = false;
        row.edit = false;
        vm.editMode = false;
        vm.judgeInvalidEdit = false;
        vm.caseNumberInvalidEdit = false;
        vm.caseTypeInvalidEdit = false;
        vm.assignmentTypeInvalidEdit = false;
        vm.pcInvalidEdit = false;
        vm.completionDateInvalidEdit = false;
        vm.assignedDateInvalidEdit = false;
      };

      vm.changedValuePC = function () {
        if (vm.productionCredits === null || vm.productionCredits === "" || angular.isUndefined(vm.productionCredits) || vm.productionCredits == "0.3" || vm.productionCredits == ".3") {
          vm.showDefaultText = true;
        } else {
          vm.showDefaultText = false;
        }
      };


      function getAssignnmentCaseTypesForEdit() {
        vm.caseTypes = [];
        HttpFactory.getActions(CONSTANTS.URL.OTHERCREDITS_CASE_TYPE)
          .then(function (successResponse) {
            for (var i = 0; i < successResponse.data.length; i++) {
              vm.caseTypes.push(successResponse.data[i].description); //descriptionText);
            }
            vm.noCaseType = false;
            vm.editMode = false;
            vm.caseTypeInvalidEdit = false;
          },
            function () {
              // intentional
            });
      }

      function getAssignnmentCaseTypesInitial() {
        vm.caseTypes = [];
        // $http.get('assets/caseTypes.json')
        HttpFactory.getActions(CONSTANTS.URL.OTHERCREDITS_CASE_TYPE)
          .then(function (successResponse) {
            for (var i = 0; i < successResponse.data.length; i++) {
              vm.caseTypes.push(successResponse.data[i]);
            }
          }, function (failureResponse) {
            for (var i = 0; i < 1; i++) {
              vm.caseTypes.push("AIA trials");
              vm.caseTypes.push("Appeals");
              vm.caseTypes.push("Interference");
              vm.caseTypes.push("Other");
            }
            console.info(failureResponse);
            // toastr.clear();
          });
      };


      vm.getAssignmentTypeBasesonCase = function (id) {
        for (var i = 0; i < id.vm.caseTypes.length; i++) {
          if (id.vm.caseType == id.vm.caseTypes[i].identifier) {
            vm.selectedCaseTypeCode = id.vm.caseTypes[i].code
          }
        }
        HttpFactory.getActions(CONSTANTS.URL.OTHERCREDITS_ASSIGNMENT_TYPE + id.vm.caseType)
          .then(function (successResponse) {

            vm.stndAssignmentTypes = successResponse.data;
            vm.editModeCaseNum = false;

          },
            function () {
              // intentional
            });
      };
      vm.getJudgeList = function () {
        HttpFactory.getActions(CONSTANTS.URL.GET_ALL_EMPLOYEES)
          .then(function (judgeList) {
            vm.judgeList = judgeList.data;
            vm.judgeList2 = angular.copy(vm.judgeList);
            vm.originalJudgeList = angular.copy(vm.judgeList);
            vm.selectedJudge = vm.judgeList[0];
          }, function (judgeListFailure) {
            console.info(judgeListFailure);
          });
      };

      vm.getJudgeList();

      vm.checkandClose = function () {
        if ((vm.judge.fullName !== "Select an employee..." || vm.judge.fullName != undefined) && (!vm.showList) && vm.judge.fullName != null) {
          vm.judgeListVisible = false;
          vm.showList = true;
          vm.focusOut();
        } else if (vm.judge.fullName == null && !vm.showList) {
          vm.judgeListVisible = true;
          vm.showList = false;
        } else if (vm.showList && vm.judge.fullName != null && !vm.focusMoved) {
          vm.judgeListVisible = true;
        } else if (vm.focusMoved) {
          vm.judgeListVisible = false;
          vm.focusMoved = false;
        }
      }


      vm.showJudgeList = function () {
        if (!vm.judgeListVisible) {
          vm.judgeListVisible = !vm.judgeListVisible;
          vm.checkandClose();
        }
      };

      vm.getDropdownValues = function () {
        if (vm.caseNumber != null || vm.caseNumber != undefined) {
          vm.editModeAssignType = false;
        }
      }
      vm.focusOut = function () {
        vm.focusMoved = true;
        if (vm.judgeListVisible != false) {
          vm.judgeListVisible = false;
        }
      };

      vm.setSelectedJudge = function (judge) {
        if (judge.assigneeFullNameText !== "Select an employee...") {
          vm.selectedJudge = judge;
          vm.judge.fullName = judge.assigneeFullNameText;
          vm.judge.assigneeNumberText = judge.assigneeNumberText;
          vm.judgeListVisible = false;
          vm.showList = false;
          vm.editModeCaseType = false;
        }
      };

      vm.searchForJudge = function (input) {
        if (input.fullName == ""){
          vm.judge = {
            "fullName": null
          };
        }
        var tempList = [];
        if (angular.isDefined(input) && input.fullName.trim() !== "") {
          angular.forEach(vm.originalJudgeList, function (currentJudge) {
            if (currentJudge.assigneeFullNameText.toLowerCase().includes(input.fullName.toLowerCase())) {
              tempList.push(currentJudge);
            }
          });
          vm.judgeList = angular.copy(tempList);
        } else {
          vm.judgeList = angular.copy(vm.originalJudgeList);
        }
      };

      vm.searchForJudge2 = function (input) {
        var tempList = [];
        if (angular.isDefined(input) && input.fullName.trim() !== "") {
          angular.forEach(vm.originalJudgeList, function (currentJudge) {
            if (currentJudge.assigneeFullNameText.toLowerCase().includes(input.fullName.toLowerCase())) {
              tempList.push(currentJudge);
            }
          });
          vm.judgeList2 = angular.copy(tempList);
        } else {
          vm.judgeList2 = angular.copy(vm.originalJudgeList);
        }
      };

      vm.showJudgeList2 = function () {
        if (!vm.judgeListVisible2) {
          vm.judgeListVisible2 = !vm.judgeListVisible2;
        }
      };

      vm.setSelectedJudge2 = function (judge) {
        if (judge.assigneeFullNameText !== "Select an employee...") {
          vm.selectedJudge2 = judge;
          vm.judge2.fullName = judge.assigneeFullNameText;
          vm.judgeListVisible2 = false;
        }
      };
    });
})();
