(function () {
  "use strict";

  angular
    .module("ptabe2e")
    .controller("creditsHistoryController", function ($scope, ngDialog, CONSTANTS, CommonHelperService, rowData, HttpFactory, uiGridConstants) {
      var vm = this;
      vm.numberOfFilters = 0;
      vm.smaple = "sampleeeeeeeee";
      vm.assignedTo = ["Collings, Karil", "Scurman, Steward", "Descroix, Barret", "Rollo, Jarvis", "Eberts, Mathias"];
      vm.currentDU = rowData.entity.decisionalUnits;
      vm.currentADU = rowData.entity.additionalDecisionalUnits;
      vm.newDU = "";
      vm.newADU = "";
      vm.correctDuReason = "";
      vm.assignmentId = rowData.entity.ptabAssignmentId;
      vm.assignmentTitle = rowData.entity.assignmentTitle;
      vm.appealNumber = rowData.entity.appealNumber;
      vm.assignmentType = rowData.entity.assignmentType;
      vm.decisionalUnitsAwarded = rowData.entity.decisionalUnitsAwarded;
      vm.lockControlNumber = rowData.entity.lockControlNumber;
      vm.caseType = rowData.entity.caseType;
      vm.serialNumber = rowData.entity.serialNumber;
      vm.completionDate = rowData.entity.completionDate;
      vm.qualifier = rowData.entity.qualifier;
      vm.creditAwardId = rowData.entity.creditAwardId;
      vm.specialTypeTooltip = CONSTANTS.SPECIAL_TYPE_REQUEST.tooltip;



      // vm.gridOptionsforCreditsHistory.onRegisterApi = function (gridApi) {
      //     vm.gridApi = gridApi;
      //   }

      $scope.gridOptionsforCreditsHistory = CommonHelperService.setCommonGridOptions();
      $scope.gridOptionsforCreditsHistory.multiSelect = true;
      $scope.gridOptionsforCreditsHistory.enableSelectAll = true;
      $scope.gridOptionsforCreditsHistory.useExternalFiltering = false;
      $scope.gridOptionsforCreditsHistory.showColumnFooter = true;
      $scope.gridOptionsforCreditsHistory.columnDefs = [{
          displayName: "When updated",
          cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.audit.lastModifiedTimestamp | date: \'MM/dd/yyyy hh:mm:ss a\' : \'UTC-05\' }} ET  </div>',
          cellTooltip: true,
          headerTooltip: 'When updated',
          field: "audit.lastModifiedTimestamp",
          sort: {
            direction: uiGridConstants.DESC,
            priority: 0
          },
          type: "date",
          visible: true,
          width: 185
        },
        {
          displayName: "Who changed",
          headerTooltip: 'Who changed',
          cellTooltip: true,
          field: "audit.lastModifiedUserName",
          width: 200
        },
        {
          displayName: "Credits awarded to",
          headerTooltip: 'Credits awarded to',
          cellTooltip: true,
          field: "decisionalUnitsAwarded",
          type: "string",
          width: 200
        },
        {
          displayName: "Decisional units (DU)",
          headerTooltip: 'Decisional units (DU)',
          cellTooltip: true,
          field: "decisionalUnits",
          type: "number",
          cellFilter: "number: 2",
          width: 150
        },
        {
          displayName: "Additional DUs (ADU)",
          headerTooltip: 'Additional DUs (ADU)',
          cellTooltip: true,
          field: "additionalDecisionalUnits",
          type: "number",
          cellFilter: "number: 2",
          width: 170
        },
        {
          displayName: "Production credit (PC)",
          headerTooltip: 'Production credit (PC)',
          cellTooltip: true,
          field: "productivityCredit",
          type: "number",
          cellFilter: "number: 2",
          width: 170
        },
        {
          displayName: "Additional production credits (APC)",
          headerTooltip: 'Additional production credits (APC)',
          cellTooltip: true,
          field: "additionalProdCredits",
          type: "number",
          cellFilter: "number: 2",
          width: 170
        },
        {
          displayName: "Due date points",
          headerTooltip: 'Due date points',
          cellTooltip: true,
          field: "patentTimeliness",
          type: "number",
          cellFilter: "number: 2",
          width: 170
        },
        {
          displayName: "Total credits",
          headerTooltip: 'Total credits',
          cellTooltip: true,
          field: "decisionalUnits",
          type: "number",
          cellFilter: "number: 2",
          width: 180,
          cellTemplate: "<div  class='ui-grid-cell-contents'>{{grid.appScope.getTwoDecimalRoundUp(row)}}</div>"
        },
        {
          displayName: "Reason",
          headerTooltip: 'Reason',
          cellTooltip: true,
          field: "reason",
          width: 200,
          cellTemplate: "<div title='{{row.entity.reason}}' class='ui-grid-cell-contents' ng-click='grid.appScope.openCreditReason(row)'><span>{{row.entity.reason}}</span></div>"
        }
      ];
      $scope.gridOptionsforCreditsHistory.onRegisterApi = function (gridApi) {
        $scope.gridApi = gridApi;
      };
      $scope.getTwoDecimalRoundUp = function (row) {
        // var currentTotals;
        vm.existingNumber = $scope.checkIsNumber(row.entity.decisionalUnits) + $scope.checkIsNumber(row.entity.additionalDecisionalUnits) + $scope.checkIsNumber(row.entity.productivityCredit) +
          $scope.checkIsNumber(row.entity.additionalProdCredits);
        return vm.existingNumber.toFixed(2);
        // if (angular.isNumber(row.entity.decisionalUnits) && angular.isNumber(row.entity.additionalDecisionalUnits)) {
        //   currentTotals = row.entity.decisionalUnits + row.entity.additionalDecisionalUnits;
        //   vm.existingTotals = currentTotals.toFixed(2);
        //   return vm.existingTotals;
        // } else if ((angular.isNumber(row.entity.decisionalUnits)) && !(angular.isNumber(row.entity.additionalDecisionalUnits))) {
        //   currentTotals = row.entity.decisionalUnits;
        //   vm.existingTotals = currentTotals.toFixed(2);
        //   return vm.existingTotals;
        // } else if (!(angular.isNumber(row.entity.decisionalUnits)) && (angular.isNumber(row.entity.additionalDecisionalUnits))) {
        //   currentTotals = row.entity.additionalDecisionalUnits;
        //   vm.existingTotals = currentTotals.toFixed(2);
        //   return vm.existingTotals;
        // } else {
        //   vm.existingTotals = null;
        //   return vm.existingTotals;
        // }
      };
      $scope.checkIsNumber = function (number) {
        // if(vm.existingNumber && vm.existingNumber.trim() == ""){
        //   return;
        // }

        if (number && angular.isNumber(number)) {
          return number;
        } else if (number && angular.isString(number) && number.trim() !== "") {
          return parseInt(number, CONSTANTS.GLOBAL.RADIX);
        }
        return 0;
      };
      HttpFactory.getActions(CONSTANTS.URL.MY_CREDITS_HISTORY + "/?ptabAssignmentId=" + rowData.entity.ptabAssignmentIdentifier)
        .then(function (successResponse) {
          $scope.gridOptionsforCreditsHistory.data = successResponse.data;
        }, function () {
          // intentional
        });
      $scope.openCreditReason = function (row) {

        ngDialog.open({
          template: 'app/components/widgets/myCredits/viewReason.html',
          controller: 'viewReasonController',
          controllerAs: 'vm',
          width: '17%',
          showClose: false,
          resolve: {
            rowData: function () {
              return row;
            }
          }
        }).closePromise.then(function () {
          // intentional
        });
      };

    });
})();
