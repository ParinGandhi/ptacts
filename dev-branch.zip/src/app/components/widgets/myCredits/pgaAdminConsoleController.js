(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .directive('pgaFileModel', ['$parse', /* istanbul ignore next */ function ($parse) {
      return {
        restrict: 'A',
        link: function (scope, element) {

          element.bind('change', function () {
            scope.q$apply(function () {
              // Implementation not needed
            });
          });
        }
      };
    }])

    .directive('pgaOnChange', /* istanbul ignore next */ function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var onChangeFunc = scope.$eval(attrs.pgaOnChange);
          element.bind('change', onChangeFunc);
        }
      };
    })
    .controller('PGAAdminController', function ($scope, ngDialog, userId, $timeout, HttpFactory, CommonHelperService, CONSTANTS) {
        var vm = this;

        var webTAFile;
        $scope.importingFile = false;
        $scope.enableImport = true;
        vm.clearFile = function () {
          $scope.fileInfo = {};
          $scope.enableImport = true;
        };

        /* istanbul ignore next */
        $scope.getSheets = function () {
          $scope.importingFile = true;
          var fd = new FormData();
          fd.append('file', webTAFile.files[0]);
          HttpFactory.postPdf("/prodn-goal-adjust/read-PGA?userIdentifier=" + userId, fd)
            .then(function (successResponse) {
              $scope.importingFile = false;
              CommonHelperService.setToastr(CONSTANTS.TOASTER.import, "success");
            }, function () {
              CommonHelperService.setToastr(CONSTANTS.TOASTER.importFail, "error");
              $scope.importingFile = false;
            }).finally(function () {
              // No processing needed
            });
        };


        /* istanbul ignore next */
        $scope.getFileInfo = function (file) {
          webTAFile = document.getElementById("webTAfile");
          var fileExtension = webTAFile.files[0].name.split('.').pop();
          $scope.fileInfo = {};
          if (fileExtension === "xls" || fileExtension === "xlsx") {
            $scope.fileInfo.name = webTAFile.files[0].name;
            $scope.fileInfo.path = webTAFile.value;
            $scope.enableImport = false;
          } else {
            $scope.fileInfo = {};
            $scope.disableGetSheetsBtn = true;
            $scope.enableImport = true;
            CommonHelperService.setToastr(CONSTANTS.TOASTER.correctFormat, "error");
          }
        };




        vm.closePGAadmin = function () {
          ngDialog.closeAll();
        };


      }

    );
})();
