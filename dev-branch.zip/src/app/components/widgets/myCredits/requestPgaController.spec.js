(function () {
  'use strict';

  describe('requestPgaController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open']);
    var controller, scope, $rootScope;
    var spy, $q, HttpFactoryDeferred;
    var userData, widgetIdentifier, requestType, userId, metaData, displayName;
    var supervisorResponse1 = [{
      "assigneeNumberText": "1810",
      "assigneeFullNameText": "Bartlett, Steven ",
      "activeCaseCount": 675,
      "assigneeStatus": "Active",
      "userRoles": [{
        "roleCode": "Supervisor",
        "roleDescription": "Supervisor"
      }]
    }, {
      "assigneeNumberText": "5904",
      "assigneeFullNameText": "Swift, Erica ",
      "activeCaseCount": 69,
      "assigneeStatus": "Active",
      "userRoles": [{
        "roleCode": "Supervisor",
        "roleDescription": "Supervisor"
      }]
    }, {
      "assigneeNumberText": "28",
      "assigneeFullNameText": "Vignone, Maria ",
      "activeCaseCount": 408,
      "assigneeStatus": "Active",
      "userRoles": [{
        "roleCode": "Supervisor",
        "roleDescription": "Supervisor"
      }]
    }];
    var row = {
      "audit": {
        "lastModifiedTimestamp": "1579107732259",
        "lastModifiedUserIdentifier": "sbartlett",
        "createUserIdentifier": "sbartlett",
        "createdUserName": null,
        "lastModifiedUserName": null,
        "createTimestamp": "1579107732259",
        "lockControlNumber": null
      },
      "requestedHours": 192,
      "supervisorId": 5932,
      "payPeriodId": 202025,
      "payPeriodIdSubStr": "2020-25",
      "adjustmentRequestId": 1380,
      "adjustmentRequestCategory": "Leave",
      "requestDate": 1579107732000,
      "lastModifiedUserFullName": "Bartlett, Steven ",
      "requestorUserId": 826,
      "requestStatusCategory": "Approved",
      "leaveTypeCategory": "Annual"
    };
    var failureResponse = '';
    var successResponse = '';

    // rowData = {
    //   entity: {
    //     reason: {

    //     },
    //     type: "Review Request"
    //   }
    // };
    widgetIdentifier = 'test';
    requestType = 'String';

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      //   spy = spyOn(angular, 'element').and.callFake(fakeElement);
      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback3) {
            callback3();
          }
        }
      });
      metaData = {
        caseType: "APPEAL"
      };
      controller = $controller('requestPgaController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        row: row,
        widgetIdentifier: widgetIdentifier,
        requestType: requestType,
        userId: userId,
        metaData: metaData,
        displayName: displayName,
        HttpFactory: HttpFactory,
        supervisorResponse1: supervisorResponse1,
        userData: userData
      });
    }));

    describe('requestPgaController', function () {

      it('it should call getSupervisor failureResponse', function () {
        failureResponse = {
          data: []
        };
        expect(controller.getSupervisor).toBeDefined();
        controller.getSupervisor();
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });

      it('it should call mandatoryCheckWebTaPP', function () {
        controller.webTaPP = "AP";
        expect(controller.mandatoryCheckWebTaPP).toBeDefined();
        controller.mandatoryCheckWebTaPP();
      });

      it('it should call mandatoryCheckWebTaPP', function () {
        controller.webTaPP = "";
        expect(controller.mandatoryCheckWebTaPP).toBeDefined();
        controller.mandatoryCheckWebTaPP();
      });

      it('it should call mandatoryCheckProjectName else', function () {
        controller.projectName = "";
        expect(controller.mandatoryCheckProjectName).toBeDefined();
        controller.mandatoryCheckProjectName();
      });

      it('it should call mandatoryCheckProjectName else', function () {
        controller.projectName = "added";
        expect(controller.mandatoryCheckProjectName).toBeDefined();
        controller.mandatoryCheckProjectName();
      });

      it('it should call mandatoryCheckProjectHours  ', function () {
        controller.projectHours = "";
        expect(controller.mandatoryCheckProjectHours).toBeDefined();
        controller.mandatoryCheckProjectHours();
      });

      it('it should call mandatoryCheckProjectHours  ', function () {
        controller.projectHours = "7";
        expect(controller.mandatoryCheckProjectHours).toBeDefined();
        controller.mandatoryCheckProjectHours();
      });

      it('it should call requestPga  ', function () {
        expect(controller.requestPga).toBeDefined();
        controller.requestPga();
      });

      it('it should call requestPga  ', function () {
        controller.displayErrorWebTa = "";
        controller.displayErrorName = "";
        controller.displayErrorhours = "";
        expect(controller.requestPga).toBeDefined();
        controller.requestPga();
      });


      it('Should invoke dismiss on ngDialog', function () {
        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['cancelRequestPga']).toBeDefined();
        controller.cancelRequestPga();
        expect(ngDialog.closeAll).toHaveBeenCalledWith();
      });

      //   it('it should call getSupervisor successResponse', function () {
      //     row = {
      //       "audit": {
      //         "lastModifiedTimestamp": "1579107732259",
      //         "lastModifiedUserIdentifier": "sbartlett",
      //         "createUserIdentifier": "sbartlett",
      //         "createdUserName": null,
      //         "lastModifiedUserName": null,
      //         "createTimestamp": "1579107732259",
      //         "lockControlNumber": null
      //       },
      //       "requestedHours": 192,
      //       "supervisorId": 5932,
      //       "payPeriodId": 202025,
      //       "payPeriodIdSubStr": "2020-25",
      //       "adjustmentRequestId": 1380,
      //       "adjustmentRequestCategory": "Leave",
      //       "requestDate": 1579107732000,
      //       "lastModifiedUserFullName": "Bartlett, Steven ",
      //       "requestorUserId": 826,
      //       "requestStatusCategory": "Approved",
      //       "leaveTypeCategory": "Annual"
      //     };
      //     successResponse = {
      //       data: [{
      //         "assigneeNumberText": "1810",
      //         "assigneeFullNameText": "Bartlett, Steven ",
      //         "activeCaseCount": 675,
      //         "assigneeStatus": "Active",
      //         "userRoles": [{
      //           "roleCode": "Supervisor",
      //           "roleDescription": "Supervisor"
      //         }]
      //       }, {
      //         "assigneeNumberText": "5904",
      //         "assigneeFullNameText": "Swift, Erica ",
      //         "activeCaseCount": 69,
      //         "assigneeStatus": "Active",
      //         "userRoles": [{
      //           "roleCode": "Supervisor",
      //           "roleDescription": "Supervisor"
      //         }]
      //       }, {
      //         "assigneeNumberText": "28",
      //         "assigneeFullNameText": "Vignone, Maria ",
      //         "activeCaseCount": 408,
      //         "assigneeStatus": "Active",
      //         "userRoles": [{
      //           "roleCode": "Supervisor",
      //           "roleDescription": "Supervisor"
      //         }]
      //       }]
      //     };
      //     expect(controller.getSupervisor).toBeDefined();
      //     controller.getSupervisor();
      //     HttpFactoryDeferred.resolve(successResponse);
      //     scope.$digest();
      //   });


      it('it should call getPGAHistory successResponse', function () {
        successResponse = {
          data: [{
            "audit": {
              "lastModifiedTimestamp": 1579107732259,
              "lastModifiedUserIdentifier": "sbartlett",
              "createUserIdentifier": "sbartlett",
              "createdUserName": null,
              "lastModifiedUserName": null,
              "createTimestamp": 1579107732259,
              "lockControlNumber": null
            },
            "requestedHours": 192,
            "supervisorId": 5932,
            "payPeriodId": 202025,
            "payPeriodIdSubStr": "2020-25",
            "adjustmentRequestId": 1380,
            "adjustmentRequestCategory": "Leave",
            "requestDate": 1579107732000,
            "lastModifiedUserFullName": "Bartlett, Steven ",
            "requestorUserId": 826,
            "requestStatusCategory": "Approved",
            "leaveTypeCategory": "Annual"
          }, {
            "audit": {
              "lastModifiedTimestamp": 1579107732495,
              "lastModifiedUserIdentifier": "sbartlett",
              "createUserIdentifier": "sbartlett",
              "createdUserName": null,
              "lastModifiedUserName": null,
              "createTimestamp": 1579107732495,
              "lockControlNumber": null
            },
            "requestedHours": 3,
            "supervisorId": 5932,
            "payPeriodId": 202025,
            "payPeriodIdSubStr": "2020-25",
            "adjustmentRequestId": 1381,
            "adjustmentRequestCategory": "Leave",
            "requestDate": 1579107732000,
            "lastModifiedUserFullName": "Bartlett, Steven ",
            "requestorUserId": 826,
            "requestStatusCategory": "Approved",
            "leaveTypeCategory": "Other"
          }, {
            "audit": {
              "lastModifiedTimestamp": 1579107732722,
              "lastModifiedUserIdentifier": "sbartlett",
              "createUserIdentifier": "sbartlett",
              "createdUserName": null,
              "lastModifiedUserName": null,
              "createTimestamp": 1579107732722,
              "lockControlNumber": null
            },
            "productionGoalDuQuantity": 0.3,
            "requestedHours": 6,
            "supervisorId": 5932,
            "payPeriodId": 202025,
            "payPeriodIdSubStr": "2020-25",
            "adjustmentRequestId": 1382,
            "adjustmentRequestCategory": "Leave",
            "requestDate": 1579107732000,
            "lastModifiedUserFullName": "Bartlett, Steven ",
            "requestorUserId": 826,
            "requestStatusCategory": "Approved",
            "leaveTypeCategory": "Other"
          }, {
            "audit": {
              "lastModifiedTimestamp": 1579108190302,
              "lastModifiedUserIdentifier": "sbartlett",
              "createUserIdentifier": "sbartlett",
              "createdUserName": null,
              "lastModifiedUserName": null,
              "createTimestamp": 1579108190302,
              "lockControlNumber": null
            },
            "requestedHours": 192,
            "supervisorId": 5932,
            "payPeriodId": 202025,
            "payPeriodIdSubStr": "2020-25",
            "adjustmentRequestId": 1574,
            "adjustmentRequestCategory": "Leave",
            "requestDate": 1579108190000,
            "lastModifiedUserFullName": "Bartlett, Steven ",
            "requestorUserId": 826,
            "requestStatusCategory": "Approved",
            "leaveTypeCategory": "Annual"
          }, {
            "audit": {
              "lastModifiedTimestamp": 1579108190505,
              "lastModifiedUserIdentifier": "sbartlett",
              "createUserIdentifier": "sbartlett",
              "createdUserName": null,
              "lastModifiedUserName": null,
              "createTimestamp": 1579108190505,
              "lockControlNumber": null
            },
            "requestedHours": 3,
            "supervisorId": 5932,
            "payPeriodId": 202025,
            "payPeriodIdSubStr": "2020-25",
            "adjustmentRequestId": 1575,
            "adjustmentRequestCategory": "Leave",
            "requestDate": 1579108190000,
            "lastModifiedUserFullName": "Bartlett, Steven ",
            "requestorUserId": 826,
            "requestStatusCategory": "Approved",
            "leaveTypeCategory": "Other"
          }, {
            "audit": {
              "lastModifiedTimestamp": 1579108190696,
              "lastModifiedUserIdentifier": "sbartlett",
              "createUserIdentifier": "sbartlett",
              "createdUserName": null,
              "lastModifiedUserName": null,
              "createTimestamp": 1579108190696,
              "lockControlNumber": null
            },
            "productionGoalDuQuantity": 0.3,
            "requestedHours": 6,
            "supervisorId": 5932,
            "payPeriodId": 202025,
            "payPeriodIdSubStr": "2020-25",
            "adjustmentRequestId": 1576,
            "adjustmentRequestCategory": "Leave",
            "requestDate": 1579108190000,
            "lastModifiedUserFullName": "Bartlett, Steven ",
            "requestorUserId": 826,
            "requestStatusCategory": "Approved",
            "leaveTypeCategory": "Other"
          }, {
            "audit": {
              "lastModifiedTimestamp": 1579108583386,
              "lastModifiedUserIdentifier": "sbartlett",
              "createUserIdentifier": "sbartlett",
              "createdUserName": null,
              "lastModifiedUserName": null,
              "createTimestamp": 1579108583386,
              "lockControlNumber": null
            },
            "productionGoalDuQuantity": 1.6,
            "requestedHours": 192,
            "supervisorId": 5932,
            "payPeriodId": 202025,
            "payPeriodIdSubStr": "2020-25",
            "adjustmentRequestId": 1587,
            "adjustmentRequestCategory": "Leave",
            "requestDate": 1579108583000,
            "lastModifiedUserFullName": "Bartlett, Steven ",
            "requestorUserId": 826,
            "requestStatusCategory": "Approved",
            "leaveTypeCategory": "Sick"
          }]
        };
        // expect(controller.getPGAHistory).toBeDefined();
        //   controller.getPGAHistory();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
        // HttpFactoryDeferred.reject(failureResponse);
        // scope.$digest();
      });

      it('it should call getPGAHistory failureResponse', function () {
        failureResponse = {
          data: []
        };
        // expect(scope['getPGAHistory']).toBeDefined();
        // scope.getPGAHistory();
        // expect(controller.getPGAHistory).toBeDefined();
        // controller.getPGAHistory();
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });

    });
  });
})();
