(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('requestPgaController', function ($scope, $filter, ngDialog, userId, userData, displayName, $timeout, HttpFactory, CommonHelperService, SearchHelperService, uiGridConstants, CONSTANTS) {
      var vm = this;
      var isFilterChanged = false;
      vm.currentTab = "history";
      vm.currentSubtab = 'request';
      vm.userData = userData;
      vm.pgaColor = "tcDanger";
      vm.userId = userId;
      vm.displayName = displayName;
      vm.currentSupervisor = "";
      vm.superviorResponse1;
      vm.supervisorList1 = [];
      vm.supervisorName = [];
      vm.todaysDate = new Date().getTime();
      vm.sendRequestEmailId = "";
      vm.displayError = false;
      vm.displayErrorWebTa = false;
      vm.displayErrorhours = false;

      $timeout(function () {
        vm.getSupervisor();
      }, 200);



      vm.getSupervisor = function () {
        vm.supervisorList1 = [];
        HttpFactory.getActions("/user-management/supervisors/" + vm.userId)
          .then(function (successResponse) {
            vm.superviorResponse1 = successResponse.data;
            vm.superviorResponse1.forEach(function (element) {
              if (vm.currentSupervisor === element.assigneeFullNameText)
                vm.supervisorList1.push(element);
            });
            vm.superviorResponse1.forEach(function (element) {
              if (vm.displayName !== element.assigneeFullNameText && vm.supervisorList1.length === 0 && vm.currentSupervisor === "") {
                vm.supervisorList1.push(element);
              } else if (vm.displayName !== element.assigneeFullNameText && vm.currentSupervisor !== element.assigneeFullNameText && vm.supervisorList1[vm.supervisorList1.length - 1].assigneeFullNameText !== element.assigneeFullNameText) {
                vm.supervisorList1.push(element);
              }
            });
            vm.sendRequestEmailId = vm.supervisorList1[0];
          }, function () {
            // Empty response is  ok
          });
      };

      vm.mandatoryCheckWebTaPP = function () {
        if (vm.webTaPP === null || vm.webTaPP === "" || angular.isUndefined(vm.webTaPP)) {
          vm.displayErrorWebTa = true;
        } else {
          vm.displayErrorWebTa = false;
        }
      };

      vm.mandatoryCheckProjectName = function () {
        if (vm.projectName === null || vm.projectName === "" || angular.isUndefined(vm.projectName)) {
          vm.displayErrorName = true;
        } else {
          vm.displayErrorName = false;
        }
      };
      vm.mandatoryCheckProjectHours = function () {
        if (vm.projectHours === null || vm.projectHours === "" || angular.isUndefined(vm.projectHours)) {
          vm.displayErrorhours = true;
        } else {
          vm.displayErrorhours = false;
        }
      };


      vm.cancelRequestPga = function () {
        ngDialog.closeAll();
      };

      vm.requestPga = function () {
        vm.mandatoryCheckProjectHours();
        vm.mandatoryCheckProjectName();
        vm.mandatoryCheckWebTaPP();
        if (!vm.displayErrorWebTa && !vm.displayErrorName && !vm.displayErrorhours) {
          var data = {
            "webTAPayPeriod": vm.webTaPP && vm.webTaPP < 10 ? "0" + vm.webTaPP : vm.webTaPP,
            "requestedHours": vm.projectHours,
            "projectId": vm.projectId,
            "projectName": vm.projectName,
            "audit": {
              "lastModifiedUserIdentifier": vm.userId,
              "createUserIdentifier": vm.userId,
              "lockControlNumber": 0,
              "lastModifiedTimestamp": new Date().getTime(),
              "createTimestamp": new Date().getTime()
            },
            "supervisorId": vm.sendRequestEmailId.assigneeNumberText,
            "requestorUserId": vm.userData.userNumber,
            "requestStatusCt": "Project"

          };

          HttpFactory.postActions('/prodn-goal-adjust/', data)
            .then(function () {
              CommonHelperService.setToastr(CONSTANTS.TOASTER.request, "success");
              ngDialog.closeAll(true);
            }, function (failureResponse) {
              CommonHelperService.setToastr(failureResponse.data.message, "error");
            });
        }
      };



      vm.pgaHistoryGridOptions = {
        enableFiltering: true,
        enableGridMenu: true,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.WHEN_NEEDED,
        exporterMenuCsv: true,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        exporterCsvFilename: 'ProductionGoalAdjustment(PGA)' + CommonHelperService.getCurrentTime() + '.csv',
        exporterOlderExcelCompatibility: true,
        exporterFieldCallback: function (grid, row, col, value) {
          if (col.colDef.type === 'date') {
            if (col.field === 'lastModifiedTimestamp') {
              value = $filter('date')(value, 'MM/dd/yyyy hh:mm:ss a');
            } else {
              value = $filter('date')(value, 'MM/dd/yyyy');
            }
            if (angular.isUndefined(value) || value === null) {
              value = "";
            } else {
              value = " " + value;
            }
          }
          return value;
        },
        treeRowHeaderAlwaysVisible: false,
        useExternalFiltering: true,
        rowHeight: 45,
        columnDefs: [{
            displayName: 'When updated',
            field: 'lastModifiedTimestamp',
            headerTooltip: 'When updated',
            cellTooltip: true,
            type: 'date',
            cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'",
            sort: {
              direction: uiGridConstants.DESC,
              priority: 0
            }
          },
          {
            displayName: 'Who updated',
            field: 'lastModifiedUserFullName',
            headerTooltip: 'Who updated',
            cellTooltip: true
          },
          // {
          //   displayName: 'Production goal',
          //   field: 'productionGoalDuQuantity',
          //   headerTooltip: 'Production goal',
          //   cellTooltip: true,
          //   type: 'number'
          // },
          {
            displayName: 'WebTA PP',
            field: 'payPeriodIdSubStr',
            headerTooltip: 'WebTA PP',
            cellTooltip: true
          },
          {
            displayName: 'PGA request type',
            type: 'string',
            field: 'together',
            headerTooltip: 'PGA request type',
            cellTemplate: '<div  title=\"{{row.entity.leaveTypeCategory}} {{row.entity.adjustmentRequestCategory}}\" class=\"ui-grid-cell-contents\" \"><span ng-if=\"row.entity.leaveTypeCategory != \'null\' \">{{row.entity.leaveTypeCategory}}</span> {{row.entity.adjustmentRequestCategory}}</div>',
            cellTooltip: true
          },
          {
            displayName: 'Number of hours',
            field: 'requestedHours',
            headerTooltip: 'Number of hours',
            cellTooltip: true
          },
          {
            displayName: 'Project ID',
            field: 'projectId',
            headerTooltip: 'Project ID',
            cellTooltip: true
          }
        ]
      };


      getPGAHistory();

      /* istanbul ignore next*/
      vm.pgaHistoryGridOptions.onRegisterApi = function (gridApi) {
        vm.documentsGridApi = gridApi;

        $scope.gridApi = gridApi;
        $scope.gridApi.core.on.filterChanged($scope, function () {
          isFilterChanged = true;
          var grid = this.grid;
          $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
          if ($scope.numberOfFilters === 0) {
            vm.pgaHistoryGridOptions.data = $scope.myData2;
          } else {
            var filteredData = SearchHelperService.filterGrid(grid, $scope.myData2);
            vm.pgaHistoryGridOptions.data = filteredData;
          }
        });
      };

      function getPGAHistory() {
        HttpFactory.getActions(CONSTANTS.URL.PGA_USER_GET + vm.userId)
          .then(function (successResponse) {
            vm.pgaHistoryGridOptions.data = successResponse.data;
            vm.sikc = 0;
            vm.ann = 0;
            vm.other = 0;
            angular.forEach(vm.pgaHistoryGridOptions.data, function (row) {
              row.lastModifiedTimestamp = row.audit.lastModifiedTimestamp;
              row.lastModifiedUserIdentifier = row.audit.lastModifiedUserIdentifier;
              row.together = (row.leaveTypeCategory + ' ' + row.adjustmentRequestCategory);
              if (row.leaveTypeCategory == 'Sick') {
                vm.sikc = vm.sikc + row.requestedHours;
              }
              if (row.leaveTypeCategory == 'Annual') {
                vm.ann = vm.ann + row.requestedHours;
              }
              if (row.leaveTypeCategory == 'Other') {
                vm.other = vm.other + row.requestedHours;
              }
            });
            console.log("ann" + vm.ann);
            console.log("sick" + vm.sikc);
            console.log("othr" + vm.other);

            $scope.myData2 = angular.copy(vm.pgaHistoryGridOptions.data);
          }, function () {
            // Empty response is  ok
          });
      }
    });
})();
