(function () {
  'use strict';

  describe('updateCreditsController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open','openConfirm']);
    var controller, scope, $rootScope,myProductioncontroller,editCreditsController;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;
    var items, totalsOfDu;
    var item;


    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
          
              
                  
        
            
            vm: {
              userInfo: {
                "userId": "pgandhi"
              },
              getWidgetZone: function () {
    
              },
              setWidgetContentHeight: function () {

              }
            },
            $parent:{
              $parent:{
                $parent:{
                  definition:{
                    zoneWidth:12
                  }
                }
              
            }
          }
          }
        }
      }
    };

    items = {
      entity: {
        decisionalUnits: {

        }
      }
    }

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory,CONSTANTS) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      $rootScope.userInfo={
        roleDescription:"SUPERVISOR"
      }
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback3) {
          callback3();
          }
        }
      });
      ngDialog.openConfirm.and.returnValue({
        then: function (callback1, callback2) {
          callback1();
          callback2();
        }
      });

      item = {
        entity: {
          decisionalUnits: 1,
          additionalDecisionalUnits: 2
        }
      }

      controller = $controller('updateCreditsController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        items: items,
        HttpFactory: HttpFactory,
        totalsOfDu: totalsOfDu

      });
      scope.$parent = {
        $parent: {
          $parent: {
            definition: {
              zoneWidth: 12
            }
          }
        }
      }
      scope.definition = {
        dataUrlText: 'http://localhost:8080/PTABServices/',
        widgetIdentifier: 12
      }
      myProductioncontroller = $controller('MyProductionController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        items: items,
        HttpFactory: HttpFactory,
        totalsOfDu: totalsOfDu

      });
      editCreditsController = $controller('EditCreditsController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        items: items,
        HttpFactory: HttpFactory,
        CONSTANTS:CONSTANTS,
        totalsOfDu: totalsOfDu

      });
   
      controller.currentADU


    }));

    afterEach(function () {
      spy.and.callThrough();
    });
    describe('MyProductionController ', function ()
     {
      it('it should call editcredits', function () {
        var ngDialogArray = [ngDialog];
        var userInfo=
        {
          "userId": "pgandhi"
        }
        expect(ngDialog.openConfirm).toBeDefined();
        // scope.myProductionActions('editCredits');
        // expect(ngDialog.openConfirm).toHaveBeenCalled();
       
        //ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
      
       
      });

     });
     describe('EditCreditsController ', function ()
     {
      it('it should call cancelEdit', function () {
       
        editCreditsController.cancelEdit({edit:false})
        
       
        //ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
      
       
      });

     });

    describe('updateCreditsController ', function ()
     {

      it('it should call currentDU 1', function () {
        var item = {
          entity: {
            decisionalUnits: 1,
            additionalDecisionalUnits: 2
          }
        }
        controller.updateCredits();
      });
  
      it('it should call currentDU 2', function () {
        var item = {
          entity: {
            decisionalUnits: 1,
            additionalDecisionalUnits: "2"
          }
        }
        controller.updateCredits();
      });
  
      it('it should call currentDU 3', function () {
        var item = {
          entity: {
            decisionalUnits: "1",
            additionalDecisionalUnits: 2
          }
        }
        controller.updateCredits();
      });

      
      it('it should call updateCredits ', function () {

        // expect(controller.updateCredits).toBeDefined();
        controller.updateCredits();
      });

      it('it should call checkMandatory ', function () {
        controller.checkMandatory();
      });

      it('it should call abandonChanges ', function () {
        controller.abandonChanges();
      });

      it('it should call totalDu with newDU as number', function () {
        controller.newADU = "";
        controller.newDU = 5;
        controller.totalDu();
      });

      it('it should call totalDu with newADU as number', function () {
        controller.newADU = 5;
        controller.newDU = "";
        controller.totalDu();
      });

      it('it should call totalDu with newDU and newADU as string', function () {
        controller.newADU = "something";
        controller.newDU = "something";
        controller.totalDu();
      });

      it('it should call totalDu with newDU and newADU as string', function () {
        controller.newADU = 5;
        controller.newDU = 5;
        controller.totalDu();
      });

      it('it should call checkMandatory ', function () {
        controller.reason = "AP";
        expect(controller.checkMandatory).toBeDefined();
        controller.checkMandatory();
      });

      it('it should call abandonChanges ', function () {
        controller.newDU = "AP";
        controller.originalnewDU = "BJ";
        expect(controller.abandonChanges).toBeDefined();
        controller.abandonChanges();
  
        expect(ngDialog.open).toHaveBeenCalled();
  
        expect(ngDialog.open.calls.count()).toBe(1);
        var args = ngDialog.open.calls.argsFor(0);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);
  
        // expect(args[0].controller).toBe('CancelChangesController');
        // expect(typeof args[0].resolve).toBe('object');
        // args[0].resolve.rowData();
      });

      it('it should call abandonChanges ', function () {
        expect(ngDialog.closeAll).toBeDefined();
        expect(controller.abandonChanges).toBeDefined();
        controller.abandonChanges();
        expect(ngDialog.closeAll).toHaveBeenCalled();
      });


    });
  });


})();
