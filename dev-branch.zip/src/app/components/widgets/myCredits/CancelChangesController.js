(function () {
  "use strict";
  angular
    .module('ptabe2e')
    .controller('CancelChangesController', function (ngDialog, $timeout) {
      var vm = this;
      vm.revertAllChanges = function () {
        revertChangesDialog();
      };

      function revertChangesDialog(popupsToClose) {
        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 2) {
          ngDialog.close(openDialogs[2]);
          ngDialog.close(openDialogs[1]);
        } else {
          ngDialog.close();
        }
      }

      function closeChangesDialog(popupsToClose) {
        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose]);
        } else {
          ngDialog.close();
        }
      }

      vm.closeDialog = function () {
        closeChangesDialog(1);
      };
    });
})();
