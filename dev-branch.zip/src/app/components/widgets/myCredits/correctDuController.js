(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .directive('duFileModel', ['$parse', /* istanbul ignore next */ function ($parse) {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          // var modelSetter = model.assign;

          element.bind('change', function () {
            scope.$apply(function () {
              // modelSetter(scope, element[0].files[0]);
            });
          });
        }
      };
    }])

    .directive('duOnChange', /* istanbul ignore next */ function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var onChangeFunc = scope.$eval(attrs.duOnChange);
          element.bind('change', onChangeFunc);
        }
      };
    })
    .controller('correctDuController', function ($scope, ngDialog, items, userId, displayName, metaData, $timeout, type, widgetIdentifier, HttpFactory, CONSTANTS, CommonHelperService, $log) {
        var vm = this;
        var scope = angular.element(document.getElementById('mainTabId')).scope();
        vm.metaData = metaData;
        vm.metaData.caseTypes = [vm.metaData.caseType];
        vm.userId = userId;
        vm.displayName = displayName;
        vm.items = items;
        if (vm.items.entity.supervisorsData && vm.items.entity.supervisorsData.length > 0) {
          vm.currentSupervisor = vm.items.entity.supervisorsData[0].assigneeFullNameText;
          vm.originalsendRequestEmailId = vm.items.entity.supervisorsData[0].assigneeFullNameText;
        } else if (vm.items.entity.supervisoryName) {
          vm.currentSupervisor = vm.items.entity.supervisoryName;
        } else {
          vm.currentSupervisor = "";
        }
        vm.ptabAssignmentIdentifier = vm.items.entity.ptabAssignmentIdentifier;
        vm.superviorResponse1;
        vm.supervisorList1 = [];
        vm.supervisorName = [];
        vm.type = type;
        vm.currentLabel = 'Current decisional units';
        vm.requestedLabel = 'Requested decisional units';
        vm.panelTitle = 'Correct decisional units (DU)';
        vm.creditTypeCode = "CDU";
        if (type === 'CPT') {
          vm.currentLabel = 'Current due date points';
          vm.requestedLabel = 'Requested due date points';
          vm.panelTitle = 'Correct due date points';
          vm.creditTypeCode = "CPT";
        } else if (type === 'CPC') {
          vm.currentLabel = 'Current production credits';
          vm.requestedLabel = 'Requested production credits';
          vm.panelTitle = 'Correct production credits (PC)';
          vm.creditTypeCode = "CPC";
        }
        vm.requestedLabel += " *";
        vm.userInfo = scope.vm.userInfo;
        buildCaseData(items.entity);

        if (type === 'RAPC') {
          vm.currentDU = items.entity.additionalDecisionalUnits;
        } else if (type === 'CPC') {
          vm.currentDU = items.entity.decisionalUnits;
        } else if (type === 'CPT') {
          vm.currentDU = items.entity.patentTimeliness;
        } else {
          vm.currentDU = items.entity.creditQuantities;
        }
        vm.completionDateLabel = "Decision mail date";
        vm.currentADU = items.entity.additionalDecisionalUnits;
        vm.newADU = "";
        vm.todaysDate = new Date().getTime();
        vm.role = items.entity.roleName;
        vm.assignmentId = items.entity.ptabAssignmentId;
        vm.assignmentTitle = items.entity.assignmentTitle;
        vm.specialType = items.entity.specialType;
        vm.specialTypeTooltip = CONSTANTS.SPECIAL_TYPE_REQUEST.tooltip;
        vm.serialNumber = items.entity.serialNumber;
        vm.decisionalUnitsAwarded = items.entity.decisionalUnitsAwarded;
        vm.decisionalUnitsAwardedIdentifier = items.entity.decisionalUnitsAwardedIdentifier;
        if (vm.items.entity.isEdit) {
          vm.correctDuReason = vm.items.entity.reason ? vm.items.entity.reason : "";
          vm.newDU = vm.items.entity.creditQuantities;
          $scope.fileInfo = {};
          if (items.entity.workProductUrl && items.entity.workProductUrl.trim() != "") {
            $scope.fileInfo.name = items.entity.workProductUrl.split(vm.serialNumber + "_").pop();
            vm.fullFileName = items.entity.workProductUrl;
          }
          vm.appealNumber = items.entity.caseNumber;
          vm.decisionalUnitsAwarded = items.entity.apjOneName;
        } else {
          vm.correctDuReason = "";
          vm.newDU = "";
          vm.appealNumber = items.entity.appealNumber;
        }
        vm.assignmentType = items.entity.assignmentType;
        vm.role = items.entity.roleName;
        vm.lockControlNumber = items.entity.lockControlNumber;
        vm.caseType = items.entity.caseType;
        vm.completionDate = items.entity.completionDate;
        vm.qualifier = items.entity.qualifier;
        vm.showErrorMessageReason = false;
        vm.showErrorMessageDU = false;
        vm.readyToSave = false;
        var duFile;
        var reader = new FileReader();
        var fileByteArray = [];
        vm.disableSubmit = false;
        vm.sendRequestEmailId = "";

        vm.originalReqId = angular.copy(vm.sendRequestEmailId);
        vm.originalnewDU = angular.copy(vm.newDU);
        vm.originalcorrectDuReason = angular.copy(vm.correctDuReason);
        $scope.cancelupdateAssignDialog = function () {
          // intentional
        };

        $timeout(function () {
          vm.zIndex();
          vm.getSupervisor();
        }, 200);

        vm.zIndex = function () {
          if(document.getElementById('globalHeaderDiv'))
          {
          document.getElementById('globalHeaderDiv').style.zIndex = '9';
        }
        };

        $scope.getExternalUrls = function () {
          HttpFactory.getActions(CONSTANTS.URL.EXTERNALURLS)
            .then(function (successResponse) {
              $scope.externalUrls = [];
              $scope.externalUrlsForAssignment = [];
              for (var key in successResponse.data) {
                var url;
                if (key !== "Open in PTOZone" && key !== "ptabReadOnlyUser" && key !== "allowedResourceObjectList" && key !== "ptabDueDateNonEditableUser" && key !== "ptabDefaultRefreshTime") {
                  url = {
                    description: key,
                    url: successResponse.data[key]
                  };
                  $scope.externalUrls.push(url);
                }
                if (key === "Open in PTOZone") {
                  url = {
                    description: key,
                    url: successResponse.data[key]
                  };
                  $scope.externalUrlsForAssignment.push(url);
                }
              }

            }, function () {
              // intentional
            });
        };
        $scope.getExternalUrls();


        vm.getSupervisor = function () {
          vm.supervisorList1 = [];
          HttpFactory.getActions("/user-management/supervisors/" + vm.userId)
            .then(function (successResponse) {
              vm.superviorResponse1 = successResponse.data;
              vm.superviorResponse1.forEach(function (element) {
                if (vm.currentSupervisor === element.assigneeFullNameText)
                  vm.supervisorList1.push(element);
              });
              if (vm.supervisorList1.length === 0 && vm.currentSupervisor !== "") {
                if (vm.items.entity.supervisorsData) {
                  vm.supervisorList1.push(vm.items.entity.supervisorsData[0]);
                } else if (vm.items.entity.supervisoryName) {
                  vm.supervisorList1.push({
                    "assigneeFullNameText": vm.items.entity.supervisoryName,
                    "assigneeNumberText": vm.items.entity.requestorId
                  });
                }

              }
              vm.superviorResponse1.forEach(function (element) {
                if (vm.displayName !== element.assigneeFullNameText && vm.supervisorList1.length === 0 && vm.currentSupervisor === "") {
                  vm.supervisorList1.push(element);
                } else if (vm.displayName !== element.assigneeFullNameText && vm.currentSupervisor !== element.assigneeFullNameText && vm.supervisorList1[vm.supervisorList1.length - 1].assigneeFullNameText !== element.assigneeFullNameText) {
                  vm.supervisorList1.push(element);
                }
              });

              vm.sendRequestEmailId = vm.supervisorList1[0];

            });
        };

        vm.checkreason = function () {
          if (vm.correctDuReason === null || vm.correctDuReason === "" || angular.isUndefined(vm.correctDuReason)) {
            vm.errorMessageForReason = "Reason is mandatory";
            vm.showErrorMessageReason = true;
            vm.readyToSaveReason = false;
          } else {
            vm.showErrorMessageReason = false;
            vm.readyToSaveReason = true;
          }
        };

        vm.checkDu = function () {
          if (vm.newDU === null || vm.newDU === "" || angular.isUndefined(vm.newDU)) {
            if (type === 'CPC') {
              vm.errorMessageForDU = "Production credits are mandatory";
            } else if (type === 'CPT') {
              vm.errorMessageForDU = "Due date points is mandatory";

            } else {
              vm.errorMessageForDU = "Decisional units are mandatory";
            }

            vm.showErrorMessageDU = true;
            vm.readyToSaveDU = false;
          } else {
            vm.showErrorMessageDU = false;
            vm.readyToSaveDU = true;
          }
        };
        vm.checkMandatoryFields = function () {
          vm.checkDu();
          vm.checkreason();

        };

        function buildCaseData(data) {
          vm.caseData = {
            caseNumber: data.appealNumber,
            applicationNumber: data.serialNumber,
            caseType: data.caseType
          };

          vm.caseData.caseTypes = [];
          vm.caseData.caseTypes.push(data.caseType);

        }

        /*istanbul ignore next: toaster error */
        vm.correctCredits = function (isSave) {
          vm.checkMandatoryFields();
          if (vm.readyToSaveDU && vm.readyToSaveReason) {
            var data = {
              "decisionalUnits": vm.currentDU,
              "requestedDecisionalUnits": vm.newDU,
              "ptabAssignmentIdentifier": vm.ptabAssignmentIdentifier,
              "reason": vm.correctDuReason,
              "supervisorId": vm.sendRequestEmailId.assigneeNumberText,
              // "assigneeToBe": vm.sendRequestEmailId.assigneeNumberText,
              "completionDate": (vm.completionDate != null || vm.completionDate != undefined) ? vm.completionDate : null,
              "appealNumber": vm.appealNumber,
              "serialNumber": vm.serialNumber,
              "caseType": vm.caseType,
              "audit": {
                "createUserIdentifier": vm.userInfo.userId,
                "lastModifiedUserIdentifier": vm.userInfo.userId
              },
              "decisionalUnitsAwarded": vm.decisionalUnitsAwarded,
              "decisionalUnitsAwardedIdentifier": vm.decisionalUnitsAwardedIdentifier,
              "assignmentType": vm.assignmentType,
              "qualifier": vm.qualifier,
              "assignmentTitle": vm.assignmentTitle,
              "dateOfRequest": new Date().getTime(),
              "widgetIdentifier": widgetIdentifier,
              "specialType": items.entity.specialType ? items.entity.specialType.trim() != "" ? items.entity.specialType : '' : '',
              // "sendRequestEmailAddress": vm.sendRequestEmailId,
              "fileName": ($scope.fileInfo != null || $scope.fileInfo != undefined) ? $scope.fileInfo.name : null,
              "attachmentInBytes": fileByteArray,
              "creditTypeCode": vm.creditTypeCode,
              "requestStatus": "Submitted"
            };
            if (isSave) {
              data.requestStatus = "Draft";
            }
            if ($scope.fileInfo && $scope.fileInfo.name && $scope.fileInfo.name.trim != "" && fileByteArray.length == 0) {
              data.previousWorkProductUrl = vm.fullFileName;
            }
            vm.disableSubmit = true;
            HttpFactory.putActions(CONSTANTS.URL.MY_CREDITS_REQUESTDU, data)
              .then(function () {
                vm.disableSubmit = false;
                CommonHelperService.setToastr("", "clear");

                if (!isSave) {
                  if (type === 'CPC') {
                    CommonHelperService.setToastr("An assignment to correct production credits (PC) has been created and assigned to " + vm.sendRequestEmailId.assigneeFullNameText + ".", "success");
                  } else if (type === 'CPT') {
                    CommonHelperService.setToastr("An assignment to correct due date points has been created and assigned to " + vm.sendRequestEmailId.assigneeFullNameText + ".", "success");
                  } else {
                    CommonHelperService.setToastr("An assignment to correct decisional units (DU) has been created and assigned to " + vm.sendRequestEmailId.assigneeFullNameText + ".", "success");
                  }
                } else {
                  CommonHelperService.setToastr(CONSTANTS.TOASTER.recordSaved, "success");
                }

                ngDialog.closeAll(true);
              }, function () {
                vm.disableSubmit = false;
                CommonHelperService.setToastr("", "clear");
                if (type === 'CPC') {
                  CommonHelperService.setToastr(CONSTANTS.TOASTER.PC, "error");
                } else if (type === 'CPT') {
                  CommonHelperService.setToastr(CONSTANTS.TOASTER.PAT, "error");
                } else {
                  CommonHelperService.setToastr(CONSTANTS.TOASTER.DU, "error");
                }
              });
          }
        };


        vm.abandonChanges = function () {
          if (vm.originalsendRequestEmailId === undefined || vm.originalsendRequestEmailId === null || vm.originalsendRequestEmailId === "") {
            vm.originalsendRequestEmailId = vm.sendRequestEmailId.assigneeFullNameText;
          }


          if (!angular.equals(vm.originalnewDU, vm.newDU) ||
            !angular.equals(vm.originalsendRequestEmailId, vm.sendRequestEmailId.assigneeFullNameText) ||
            !angular.equals(vm.originalcorrectDuReason, vm.correctDuReason)) {
            ngDialog.open({
              template: 'app/components/widgets/myCredits/cancelChanges.html',
              controller: 'CancelChangesController',
              controllerAs: 'vm',
              width: '25%',
              showClose: false,
              closeByEscape: false,
              closeByDocument: false


            }).closePromise.then(function () {
              $log.info("Changes abandoned");
            });
          } else {
            ngDialog.closeAll();
          }
        };

        /* istanbul ignore next */
        $scope.getFileInfo = function (file) {
          duFile = document.getElementById("file1");
          $scope.fileInfo = {};
          $scope.fileInfo.name = duFile.files[0].name;
          $scope.fileInfo.path = duFile.value;
          reader.readAsArrayBuffer(duFile.files[0]);
          reader.onloadend = function (evt) {
            if (evt.target.readyState == FileReader.DONE) {
              var arrayBuffer = evt.target.result,
                array = new Uint8Array(arrayBuffer);
              for (var i = 0; i < array.length; i++) {
                fileByteArray.push(array[i]);
              }
            }
          };
        };


        vm.clearFile = function () {
          $scope.fileInfo = {};
        };

        /*istanbul ignore next: toaster error */
        vm.updateCredits = function () {
          var data = {
            "ptabAssignmentId": vm.assignmentId,
            "decisionalUnits": vm.newDU,
            "additionalDecisionalUnits": vm.newADU,
            "reason": vm.reason,
            "lockControlNo": vm.lockControlNumber,
            "lastModifiedUserIdentifier": vm.userInfo.userId,
            "createUserIdentifier": vm.userInfo.userId

          };
          HttpFactory.putActions(CONSTANTS.URL.UPDATE_CREDITS, data)
            .then(function () {
              CommonHelperService.setToastr("", "clear");
              CommonHelperService.setToastr(CONSTANTS.TOASTER.creditsSuccess, "success");
              ngDialog.closeAll(true);

            }, function (failureResponse) {
              CommonHelperService.setToastr("", "clear");
              CommonHelperService.setToastr(failureResponse.data.message, "error");
            });
        };
      }

    );
})();
