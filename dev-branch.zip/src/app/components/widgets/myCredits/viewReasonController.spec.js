(function () {
    'use strict';
  
    describe('viewReasonController', function () {
  
      beforeEach(module('ptabe2e'));
      var $controller;
      var vm = this;
      
      var controller, scope, $rootScope;
     
      var rowData;
  
      var fakeElement = function (params) {
        return {
          scope: function () {
            return {
              vm: {
                userInfo: {
                  "userId": "pgandhi"
                }
              }
            }
          }
        }
      };
  
      rowData = {
        entity: {
          reason: {
  
          }
        }
      }
  
      beforeEach(inject(function (_$controller_,_$rootScope_) {
      
        $controller = _$controller_;
        scope = _$rootScope_.$new();
         $rootScope = _$rootScope_;
        controller = $controller('viewReasonController', {
        $rootScope: _$rootScope_,
        rowData: rowData,
  
        });
      }));
  
  
      describe('viewReasonController ', function () {
  
        it('it should get reason full view ', function () {
  
            scope.rowData = [{
                assignmentCompletionDtdefined: "test"
              }]
        });
  
      });
    });
  })();
  