(function () {
  'use strict';

  describe('correctDuController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open']);
    var controller, scope, $rootScope;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;
    var items, widgetIdentifier, type, metaData, userId, displayName;
    type = "CPT";
    var failureResponse = '';
    var successResponse = {
      data: [{
        "assigneeNumberText": "1810",
        "assigneeFullNameText": "Bartlett, Steven ",
        "activeCaseCount": 675,
        "assigneeStatus": "Active",
        "userRoles": [{
          "roleCode": "Supervisor",
          "roleDescription": "Supervisor"
        }]
      }, {
        "assigneeNumberText": "5904",
        "assigneeFullNameText": "Swift, Erica ",
        "activeCaseCount": 69,
        "assigneeStatus": "Active",
        "userRoles": [{
          "roleCode": "Supervisor",
          "roleDescription": "Supervisor"
        }]
      }, {
        "assigneeNumberText": "28",
        "assigneeFullNameText": "Vignone, Maria ",
        "activeCaseCount": 408,
        "assigneeStatus": "Active",
        "userRoles": [{
          "roleCode": "Supervisor",
          "roleDescription": "Supervisor"
        }]
      }]
    };
    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              userInfo: {
                "userId": "pgandhi"
              }
            }
          }
        }
      }
    };

    items = {
      entity: {
        appealNumber: "123",
        additionalDecisionalUnits: "2",
        decisionalUnits: "2",
        patentTimeliness: "2",
        isEdit: true,
        creditQuantities: "2",
        reason: "sss",
        recordHour: 0,
        ptabAssignmentIdentifier: 1850,
        supervisoryName: "name, N",
        supervisorsData: [{
          assigneeFullNameText: "1810"
        }]
      }
    }

    widgetIdentifier = "1234";

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spy = spyOn(angular, 'element').and.callFake(fakeElement);
      metaData = {
        caseType: "APPEAL"
      };
      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback3) {
            callback3();
          }
        }

      });

      controller = $controller('correctDuController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        items: items,
        HttpFactory: HttpFactory,
        widgetIdentifier: widgetIdentifier,
        type: type,
        userId: userId,
        displayName: displayName,
        metaData: metaData

      });
    }));

    afterEach(function () {
      spy.and.callThrough();
    });

    describe('correctDuController ', function () {

      it('it should call updateCredits ', function () {
        expect(controller.updateCredits).toBeDefined();
        controller.updateCredits();
      });

      it('it should call cancelupdateAssignDialog ', function () {
        var value = "";
        expect(scope.cancelupdateAssignDialog).toBeDefined();
        scope.cancelupdateAssignDialog(value);
      });

      it('it should call correctCredits ', function () {
        controller.readyToSaveDU = true;
        controller.readyToSaveReason = true;
        expect(controller.correctCredits).toBeDefined();
        controller.correctCredits();
      });

      it('it should call checkreason', function () {
        controller.correctDuReason = "something";
        controller.checkreason();
      });

      it('it should call checkreason', function () {
        controller.correctDuReason = "";
        controller.checkreason();
      });

      it('it should call checkDu', function () {
        controller.newDU = "something";
        controller.checkDu();
      });

      it('it should call checkDu', function () {
        controller.newDU = "";
        controller.checkDu();
      });
      it('it should call checkDu', function () {
        controller.newDU = "";
        type = "CPC";
        controller.checkDu();
      });

      it('it should call abandonChanges ', function () {
        controller.originalReqId = "123";
        controller.sendRequestEmailId = "456";
        controller.originalnewDU = "123";
        controller.newDU = "456";
        controller.originalcorrectDuReason = "123";
        controller.correctDuReason = "456";
        expect(controller.abandonChanges).toBeDefined();
        controller.abandonChanges();

        // expect(ngDialog.open.calls.count()).toBe(1);
        // var args = ngDialog.open.calls.argsFor(0);
        // expect(args).not.toBe(null);
        // expect(args.length).toBe(1);
      });

      it('it should call abandonChanges ', function () {
        controller.originalReqId = "123";
        controller.sendRequestEmailId = "123";
        controller.originalnewDU = "123";
        controller.newDU = "123";
        controller.originalcorrectDuReason = "123";
        controller.correctDuReason = "123";
        expect(controller.abandonChanges).toBeDefined();
        // expect(ngDialog.closeAll).toBeDefined();
        controller.abandonChanges();
        // expect(ngDialog.closeAll).toHaveBeenCalled();
      });

      it('it should call clearFile ', function () {
        expect(controller.clearFile).toBeDefined();
        controller.clearFile();
      });

      it('it should call getSupervisor successResponse', function () {
        successResponse = {
          data: [{
            "assigneeNumberText": "1810",
            "assigneeFullNameText": "Bartlett, Steven ",
            "activeCaseCount": 675,
            "assigneeStatus": "Active",
            "userRoles": [{
              "roleCode": "Supervisor",
              "roleDescription": "Supervisor"
            }]
          }, {
            "assigneeNumberText": "5904",
            "assigneeFullNameText": "Swift, Erica ",
            "activeCaseCount": 69,
            "assigneeStatus": "Active",
            "userRoles": [{
              "roleCode": "Supervisor",
              "roleDescription": "Supervisor"
            }]
          }, {
            "assigneeNumberText": "28",
            "assigneeFullNameText": "Vignone, Maria ",
            "activeCaseCount": 408,
            "assigneeStatus": "Active",
            "userRoles": [{
              "roleCode": "Supervisor",
              "roleDescription": "Supervisor"
            }]
          }]
        };
        expect(controller.getSupervisor).toBeDefined();
        controller.getSupervisor();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
      });

      it('it should call getSupervisor failureResponse', function () {
        failureResponse = {
          data: []
        };
        expect(controller.getSupervisor).toBeDefined();
        controller.getSupervisor();
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });

    });
  });
})();
