(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('updateCreditsController', function (ngDialog, items, HttpFactory, CONSTANTS, CommonHelperService) {
        var vm = this;
        var currentTotals;
        var scope = angular.element(document.getElementById('mainTabId')).scope();
        vm.userInfo = scope.vm.userInfo;
        vm.completionDateLabel = "Completion date";
        vm.currentDU = items.entity.decisionalUnits;
        vm.currentADU = items.entity.additionalDecisionalUnits;
        if (angular.isNumber(vm.currentDU) && angular.isNumber(vm.currentADU)) {
          currentTotals = vm.currentDU + vm.currentADU;
          vm.existingTotals = currentTotals.toFixed(2);
        } else if (!(angular.isNumber(vm.currentADU)) && (angular.isNumber(vm.currentDU))) {
          currentTotals = vm.currentDU;
          vm.existingTotals = currentTotals.toFixed(2);
        } else if (!(angular.isNumber(vm.currentDU)) && (angular.isNumber(vm.currentADU))) {
          currentTotals = vm.currentADU;
          vm.existingTotals = currentTotals.toFixed(2);
        } else {
          vm.existingTotals = null;
        }

        vm.newDU = "";
        vm.originalnewDU = angular.copy(vm.newDU);
        vm.newADU = "";
        vm.reason = "";
        vm.originalADU = angular.copy(vm.newADU);
        vm.originalReason = "";
        vm.assignmentId = items.entity.ptabAssignmentIdentifier;
        vm.assignmentTitle = items.entity.assignmentTitle;
        vm.appealNumber = items.entity.appealNumber;
        vm.assignmentType = items.entity.assignmentType;
        vm.decisionalUnitsAwarded = items.entity.decisionalUnitsAwarded;
        vm.specialTypeTooltip = CONSTANTS.SPECIAL_TYPE_REQUEST.tooltip;
        vm.lockControlNumber = items.entity.lockControlNumber;
        vm.caseType = items.entity.caseType;
        vm.serialNumber = items.entity.serialNumber;
        vm.completionDate = items.entity.completionDate;
        vm.qualifier = items.entity.qualifier;
        vm.totalDu = function () {
          if ((vm.newADU === null || angular.isUndefined(vm.newADU) || vm.newADU === "") && (angular.isNumber(vm.newDU))) {
            vm.totalDU = vm.newDU.toFixed(2);
          } else if ((vm.newDU === null || angular.isUndefined(vm.newDU) || vm.newDU === "") && (angular.isNumber(vm.newADU))) {
            vm.totalDU = vm.newADU.toFixed(2);
          } else {
            if (!(angular.isNumber(vm.newDU)) && !(angular.isNumber(vm.newADU))) {
              vm.totalDU = null;
            } else {
              var totalsOfDu = vm.newDU + vm.newADU;
              vm.totalDU = totalsOfDu.toFixed(2);
            }
          }
        };
        /* istanbul ignore next: toaster error  */
        vm.updateCredits = function () {
          vm.checkMandatory();
          var data = {
            "ptabAssignmentIdentifier": vm.assignmentId,
            "decisionalUnits": vm.newDU,
            "decisionalUnitsAwardedIdentifier": items.entity.decisionalUnitsAwardedIdentifier,
            "audit": {
              "lastModifiedTimestamp": new Date().getTime(),
              "lastModifiedUserIdentifier": vm.userInfo.userId,
              "createUserIdentifier": vm.userInfo.userId,
              "lockControlNumber": vm.lockControlNumber
            },
            "additionalDecisionalUnits": vm.newADU,
            "reason": vm.reason

          };
          if (vm.readyToSaveReason) {
            HttpFactory.putActions(CONSTANTS.URL.UPDATE_CREDITS, [data])
              .then(function () {
                CommonHelperService.setToastr("", "clear");
                CommonHelperService.setToastr(CONSTANTS.TOASTER.creditsSuccess, "success");
                ngDialog.closeAll(true);

              }, function (failureResponse) {
                CommonHelperService.setToastr("", "clear");
                CommonHelperService.setToastr(failureResponse.data.message, "warning");
              });
          }
        };
        vm.checkMandatory = function () {
          if (vm.reason === null || vm.reason === "" || angular.isUndefined(vm.reason)) {
            vm.errorMessageForReason = "Reason is mandatory";
            vm.showErrorMessageReason = true;
            vm.readyToSaveReason = false;
          } else {
            vm.showErrorMessageReason = false;
            vm.readyToSaveReason = true;
          }
        };
        vm.abandonChanges = function () {
          if (!angular.equals(vm.newDU, vm.originalnewDU) || !angular.equals(vm.originalReason, vm.reason) || !angular.equals(vm.newADU, vm.originalADU)) {
            ngDialog.open({
              template: 'app/components/widgets/myCredits/cancelChanges.html',
              controller: 'CancelChangesController',
              controllerAs: 'vm',
              width: '25%',
              showClose: false,
              closeByEscape: false,
              closeByDocument: false


            }).closePromise.then(function () {
              // Modal handles data
            });
          } else {
            ngDialog.closeAll();
          }
        };
      }

    );
})();
