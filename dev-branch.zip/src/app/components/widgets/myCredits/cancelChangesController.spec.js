(function () {
    'use strict';
  
    describe('CancelChangesController', function () {
  
      beforeEach(module('ptabe2e'));
      var $controller;
      var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close']);
      var controller, scope;
  
    
  
      beforeEach(inject(function (_$controller_, _$rootScope_) {
        $controller = _$controller_;
        scope = _$rootScope_.$new();
  
  
        controller = $controller('CancelChangesController', {
          $scope: scope,
          ngDialog: ngDialog,
          $rootScope: _$rootScope_
        });
      }));
  
      describe('CancelChangesController ', function () {
  
  
        it('it should call closeDialog ', function () {
          var ngDialogArray = [ngDialog, ngDialog];
          expect(ngDialog.close).toBeDefined();
          expect(controller['closeDialog']).toBeDefined();
          ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
          controller.closeDialog();
          expect(ngDialog.close).toHaveBeenCalledWith(ngDialog);
  
          expect(ngDialog.close).toBeDefined();
          expect(controller['closeDialog']).toBeDefined();
          ngDialog.getOpenDialogs.and.returnValue(ngDialog);
          controller.closeDialog();
          expect(ngDialog.close).toHaveBeenCalledWith();

  
        });
  
        it('it should call revertAllChanges ', function () {
  
          var ngDialogArray = [ngDialog, ngDialog, ngDialog];
          expect(ngDialog.close).toBeDefined();
          expect(controller['revertAllChanges']).toBeDefined();
          ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
          controller.revertAllChanges();
          expect(ngDialog.close).toHaveBeenCalledWith(ngDialog);
  
          expect(ngDialog.close).toBeDefined();
          expect(controller['revertAllChanges']).toBeDefined();
          ngDialog.getOpenDialogs.and.returnValue(ngDialog);
          controller.revertAllChanges();
          expect(ngDialog.close).toHaveBeenCalledWith();
        });
  


      });
    });
  })();
  