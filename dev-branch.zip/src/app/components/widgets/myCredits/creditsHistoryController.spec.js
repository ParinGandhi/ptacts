(function () {
  'use strict';

  describe('creditsHistoryController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open']);
    var controller, scope, $rootScope;
    var timeout, rowData;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;
    rowData = {
      entity: {

      }
    }

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback3) {
          callback3();
          }
        }
      });

      controller = $controller('creditsHistoryController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory,
        rowData: rowData

      });
    }));

    describe('creditsHistoryController ', function () {

      it('it should call gridOptionsforCreditsHistory', function () {

        var gridApi = {
          core: {
            on: {

            }
          }
        };
        expect(scope.gridOptionsforCreditsHistory).toBeDefined();
        expect(scope.gridOptionsforCreditsHistory.onRegisterApi).toBeDefined();
        scope.gridOptionsforCreditsHistory.onRegisterApi(gridApi);
        expect(scope.gridApi).toBe(gridApi);
      });

    });

    it(' it should get credit hoistory ', function () {

      successResponse = {
        data: {
          audit: {
            lastModifiedTimestamp: 1542407438824,
            lastModifiedUserIdentifier: null,
            createUserIdentifier: null,
            createdUserName: null,
            lastModifiedUserName: " ",
            createTimestamp: null,
            lockControlNumber: null
          },
          completionDate: 0,
          decisionalUnitsAwarded: "Koduru, Sasidhar ",
          decisionalUnits: 45
        }
      };
      HttpFactoryDeferred.resolve(successResponse);
      $rootScope.$apply();
    });

    it(' credit history failureResponse ', function () {
      var failureResponse = {
        data: {}
      };
      HttpFactoryDeferred.reject(failureResponse);
      $rootScope.$apply();
    });

    it('it should call getTwoDecimalRoundUp 1', function () {
      var row = {
        entity: {
          decisionalUnits: 1,
          additionalDecisionalUnits: 2
        }
      }
      expect(scope.getTwoDecimalRoundUp).toBeDefined();
      scope.getTwoDecimalRoundUp(row);
    });

    it('it should call getTwoDecimalRoundUp 2', function () {
      var row = {
        entity: {
          decisionalUnits: 1,
          additionalDecisionalUnits: "2"
        }
      }
      expect(scope.getTwoDecimalRoundUp).toBeDefined();
      scope.getTwoDecimalRoundUp(row);
    });

    it('it should call getTwoDecimalRoundUp 3', function () {
      var row = {
        entity: {
          decisionalUnits: "1",
          additionalDecisionalUnits: 2
        }
      }
      expect(scope.getTwoDecimalRoundUp).toBeDefined();
      scope.getTwoDecimalRoundUp(row);
    });

    it('it should call getTwoDecimalRoundUp 4', function () {
      var row = {
        entity: {
          decisionalUnits: "1",
          additionalDecisionalUnits: "2"
        }
      }
      expect(scope.getTwoDecimalRoundUp).toBeDefined();
      scope.getTwoDecimalRoundUp(row);
    });

    it('it should call openCreditReason ', function () {
      var row = {}
      expect(scope.openCreditReason).toBeDefined();
      scope.openCreditReason(row);

      expect(ngDialog.open).toHaveBeenCalled();

      expect(ngDialog.open.calls.count()).toBe(1);
      var args = ngDialog.open.calls.argsFor(0);
      expect(args).not.toBe(null);
      expect(args.length).toBe(1);

      expect(args[0].controller).toBe('viewReasonController');
      expect(typeof args[0].resolve).toBe('object');
      args[0].resolve.rowData();
    });

  });
})();
