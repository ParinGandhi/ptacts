(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('SelectTrialsPathController', function ($scope) {
      var vm = this;
      vm.modalTitle = "Select application to view " + $scope.ngDialogData;
    });
})();
