(function () {
  'use strict';

  describe('ViewCaseDocketController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var controller;
    var scope, $rootScope, $http, $interval;
    var successResponse, failureResponse;
    var $httpBackend, spy, $q, HttpFactoryDeferred;
    var $ngDialog = jasmine.createSpyObj('ngDialog', ['open']);
    var columnList, gridState;
    var columndefs
    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              getWidgetZone: function () {

              },
              setWidgetContentHeight: function () {

              }
            },
            gridApi: {
              selection: {
                getSelectedRows: function () {}
              },
              saveState: {
                save: function () {

                }
              }
            }
          }
        }
      }
    };


    beforeEach(inject(function (_$controller_, _$rootScope_, _$http_, _$httpBackend_, _$interval_, _$q_, HttpFactory) {
      $q = _$q_;
      scope = _$rootScope_.$new();
      $http = _$http_;
      $controller = _$controller_;
      $rootScope = _$rootScope_;
      $httpBackend = _$httpBackend_;
      $ngDialog.open.and.returnValue({
        then: function (callback1, callback2) {
          callback1();
          callback2();
        },
        closePromise: {
          then: function (callback3, callback4) {
            callback3();
            callback4();
          }
        }
      });

      $rootScope.userInfo = {
        "userId": "pgandhi"
      }
      $rootScope.viewCaseColumnsChanged = true;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      //   scope.$parent = {
      //     model: {
      //       dataUrlText: 'http://localhost:8080/PTABServices/',
      //       widgetIdentifier: 12
      //     }
      //   }

      scope.gridState = {
        "pagination": {
          "paginationPageSize": 10
        }
      }
      scope.definition = {
        dataUrlText: 'http://localhost:8080/PTABServices/',
        widgetIdentifier: 12
      }
      scope.$parent = {
        $parent: {
          $parent: {
            definition: {
              zoneWidth: 12
            }
          }
        }
      }

      controller = $controller('ViewCaseDocketController', {
        $scope: scope,
        $http: $http,
        ngDialog: $ngDialog,
        $rootScope: _$rootScope_,
        $interval: $interval,
        HttpFactory: HttpFactory
      });
    }));

    afterEach(function () {
      spy.and.callThrough();
    });

    describe('ViewCaseDocketController ', function () {
      it('should call openCaseViewer', function () {

        var row = {
          entity: {
            PROCEEDING_CORE_ID: "06000006",
            PROCEEDING_NO: "2010001025",
            PROCEEDING_SUPPLEMENTARY_ID: "2010001025"
          }
        }
        expect(scope.openCaseViewer).toBeDefined();
        scope.openCaseViewer(row);
      })

      it('should call openCaseViewerwithAppeal', function () {

        var row = {
          entity: {
            PROCEEDING_CORE_ID: "06000006",
            PROCEEDING_NO: "2019002010"
          }
        }
        expect(scope.openCaseViewerwithAppeal).toBeDefined();
        scope.openCaseViewerwithAppeal(row);
      });

      it('should call openCaseViewerwithTrials', function () {

        var row = {
          entity: {
            PROCEEDING_CORE_ID: "06000006",
            PROCEEDING_NO: "DER",
            REDIRECT_URL: "url"
          }
        }
        expect(scope.openCaseViewerwithTrials).toBeDefined();
        scope.openCaseViewerwithTrials(row);
      });

      it('should call openCaseViewerwithTrials', function () {
        event.ctrlKey = "13";
        var row = {
          entity: {
            PROCEEDING_CORE_ID: "06000006",
            PROCEEDING_NO: "IPR",
            REDIRECT_URL: "url"
          }
        }
        expect(scope.openCaseViewerwithTrials).toBeDefined();
        scope.openCaseViewerwithTrials(row);
      });

      it('should call openCaseViewerwithTrials', function () {

        var row = {
          entity: {
            PROCEEDING_CORE_ID: "06000006",
            PROCEEDING_NO: "IPR",

          }
        }
        expect(scope.openCaseViewerwithTrials).toBeDefined();
        scope.openCaseViewerwithTrials(row);
      });


      // it('should call validateTeamLead', function () {
      //   successResponse = {
      //     data: {}
      //   }
      //   expect(scope.validateTeamLead).toBeDefined();
      //   scope.validateTeamLead();
      //   HttpFactoryDeferred.resolve(successResponse);
      //   scope.$digest();
      //   // $rootScope.$apply();
      // });

      it('should call getTechCenter', function () {

        var artUnit = "1234455"
        expect(scope.getTechCenter).toBeDefined();
        scope.getTechCenter(artUnit);
      });

      it('get Actions success response getViewCaseDocketColumns', function () {

        successResponse = {
          data: {
            selectedColumns: [{
                "caseDetailsData": [{
                  "ADMINISTRATIVE_PATENT_JDG_3_NM": "Murriel, Crawford",
                  "PROCEEDING_NO": "2012002432",
                  "APPLICATIONSUBCLASS": "040000",
                  "ADMINISTRATIVE_PATENT_JDG_1_NM": "Nina, Medlock",
                  "HEARINGDATE": null,
                  "APPLICATIONTYPE": "PRO",
                  "ADMINISTRATIVE_PATENT_JDG_2_NM": "Joseph, Fischetti",
                  "PROCEEDING_TYPE": "APP",
                  "ATTORNEY_NM": "David, Wood",
                  "HEARINGSTATUS": null,
                  "ASSIGNMENTDATE": 1400731200000,
                  "NEXT_DISPOSITION_DT": null,
                  "ARTUNITNUMBER": 3694,
                  "PROCEEDING_STATUS_DESC": "Panel Assigned - Appeal Awaiting Decision (selected by Paralegal)",
                  "SPECIALTYPE": null,
                  "ATTYNUMBER": "84788",
                  "PATENT_NO": " ",
                  "APPLICATIONCLASS": "705",
                  "PROCEEDING_TYPE_NM": "On Brief",
                  "ID": 61,
                  "PROCEEDING_SUPPLEMENTARY_ID": 1,
                  "PROCEEDING_SUB_TYPE": "EX",
                  "PROCEEDING_CORE_ID": "11962511"
                }],
                "columnDetails": [{
                    "columnName": [
                      "PROCEEDING_CORE_ID"
                    ],
                    "columnLabel": "Application/Reexam #",
                    "columnType": "string",
                    "defaultOrder": "desc",
                    "visible": true,
                    "mandatory": true,
                    "width": 140,
                    "sort": {},
                    "filters": [{}],
                    "pinned": ""
                  },
                  {
                    "columnName": [
                      "PATENT_NO"
                    ],
                    "columnLabel": "Patent #",
                    "columnType": "string",
                    "defaultOrder": "desc",
                    "visible": false,
                    "mandatory": false,
                    "width": 110,
                    "sort": {},
                    "filters": [{}],
                    "pinned": ""
                  }
                ]
              }

            ]
          }

        };

        // expect(scope['getViewCaseDocketColumns']).toBeDefined();
        // scope.getViewCaseDocketColumns();

        // HttpFactoryDeferred.resolve(successResponse);
        // scope.$digest();
      });


      // it('get Actions success response getViewCaseDocketData', function () {

      //   scope.gridState = {
      //     "pagination": {
      //       "paginationPageSize": 10
      //     }
      //   }
      //   successResponse = {
      //     data: [{
      //       columnDetails: [{
      //           columnName: [
      //             "PROCEEDING_CORE_ID"
      //           ],
      //           columnLabel: "Application/Reexam #",
      //           columnType: "string",
      //           defaultOrder: "desc",
      //           visible: true,
      //           mandatory: true,
      //           width: 140,
      //           sort: {},
      //           filters: [{}],
      //           pinned: "",
      //         },
      //         {
      //           columnName: [
      //             "PATENT_NO"
      //           ],
      //           columnLabel: "Patent #",
      //           columnType: "number",
      //           defaultOrder: "desc",
      //           visible: false,
      //           mandatory: false,
      //           width: 110,
      //           sort: {},
      //           filters: [{}],
      //           pinned: "",
      //         },
      //         {
      //           columnName: [
      //             "PATENT_NO"
      //           ],
      //           columnLabel: "PROCEEDING_NO",
      //           columnType: "date",
      //           defaultOrder: "desc",
      //           visible: false,
      //           mandatory: false,
      //           width: "110",
      //           sort: {},
      //           filters: [{}],
      //           pinned: "",
      //         }
      //       ],

      //       caseDetailsData: [{
      //         ADMINISTRATIVE_PATENT_JDG_3_NM: "Murriel, Crawford",
      //         PROCEEDING_NO: "2012002432",
      //         APPLICATIONSUBCLASS: "040000",
      //         ADMINISTRATIVE_PATENT_JDG_1_NM: "Nina, Medlock",
      //         HEARINGDATE: null,
      //         APPLICATIONTYPE: "PRO",
      //         ADMINISTRATIVE_PATENT_JDG_2_NM: "Joseph, Fischetti",
      //         PROCEEDING_TYPE: "APP",
      //         ATTORNEY_NM: "David, Wood",
      //         HEARINGSTATUS: null,
      //         ASSIGNMENTDATE: 1400731200000,
      //         NEXT_DISPOSITION_DT: null,
      //         ARTUNITNUMBER: 3694,
      //         PROCEEDING_STATUS_DESC: "Panel Assigned - Appeal Awaiting Decision (selected by Paralegal)",
      //         SPECIALTYPE: null,
      //         ATTYNUMBER: "84788",
      //         PATENT_NO: " ",
      //         APPLICATIONCLASS: "705",
      //         PROCEEDING_TYPE_NM: "On Brief",
      //         ID: 61,
      //         PROCEEDING_SUPPLEMENTARY_ID: 1,
      //         PROCEEDING_SUB_TYPE: "EX",
      //         PROCEEDING_CORE_ID: "11962511",
      //       }]

      //     }]

      //   };

      //   expect(scope['getViewCaseDocketData']).toBeDefined();
      //   scope.getViewCaseDocketData();

      //   HttpFactoryDeferred.resolve(successResponse);
      //   scope.$digest();
      // });

      it('get Actions failureResponse getViewCaseDocketData', function () {

        failureResponse = {
          data: {
            "message": "Widget Id does not exist in the system"
          }
        };

        expect(scope['getViewCaseDocketColumns']).toBeDefined();
        scope.getViewCaseDocketColumns();

        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });


      // it('it should call gridOPtions', function () {

      //   var gridApi = {
      //     core: {
      //       on: {
      //         // filterChanged: function () {},
      //         columnVisibilityChanged: function () {}
      //       },
      //     },
      //   };
      //   expect(scope.gridOptions).toBeDefined();
      //   expect(scope.gridOptions.onRegisterApi).toBeDefined();
      //   scope.gridOptions.onRegisterApi(gridApi);
      //   expect(scope.gridApi).toBe(gridApi);
      //   scope.gridApi.core.on.filterChanged();
      //   scope.gridApi.core.on.columnVisibilityChanged();
      //   // scope.gridApi.core.on.filterChanged();
      //   // scope.gridApi.core.on.filterChanged();

      // });


      it('setWidgetZone should set WidgetZone', function () {
        scope.$parent = {
          $parent: {
            $parent: {
              "definition": {
                "zoneWidth": 10
              }
            }
          }

        };
        var zoneWidth = 10;
        expect(scope.setWidgetZone).toBeDefined();
        scope.setWidgetZone(zoneWidth);
        expect(scope.zoneWidth).toBe(zoneWidth);

        expect(scope.setWidgetZone).toBeDefined();
        scope.setWidgetZone();
        expect(scope.zoneWidth).toBe(zoneWidth);

      });

      it('get Actions success response getViewCaseDocketData', function () {

        successResponse = {
          data: {
            "userWorkspaceWidgetIdentifier": 8879,
            "selectedColumns": [{
                "name": "PROCEEDING_CORE_ID",
                "label": "Application #",
                "typeDefinition": "String",
                "defaultOrder": "desc",
                "selected": true,
                "mandatory": true,
                "width": 250,
                "sort": "desc",
                "filters": "<"
              },
              {
                "name": "PROCEEDING_SUPPLEMENTARY_ID",
                "label": "Appeal Sequence #",
                "typeDefinition": "Number",
                "defaultOrder": "desc",
                "selected": true,
                "mandatory": true
              },
              {
                "name": "NEXT_DISPOSITION_DT",
                "label": "Next Upcoming Due Date",
                "typeDefinition": "Date",
                "defaultOrder": "desc",
                "selected": true,
                "mandatory": true
              },
              {
                "name": "HEARINGDATE",
                "label": "Hearing Date",
                "typeDefinition": "Date",
                "defaultOrder": "desc",
                "selected": false,
                "mandatory": true
              }
            ],
            "columnDetails": [{
                "name": "PROCEEDING_NO",
                "label": "Patent #",
                "typeDefinition": "String",
                "defaultOrder": "desc",
                "selected": true,
                "mandatory": false
              },
              {
                "name": "PROCEEDING_SUPPLEMENTARY_ID",
                "label": "Appeal Sequence #",
                "typeDefinition": "String",
                "defaultOrder": "desc",
                "selected": true,
                "mandatory": false
              },
              {
                "name": "NEXT_DISPOSITION_DT",
                "label": "Next Upcoming Due Date",
                "typeDefinition": "Date",
                "defaultOrder": "desc",
                "selected": true,
                "mandatory": false
              },
              {
                "name": "PROCEEDING_CORE_ID",
                "label": "Application #",
                "typeDefinition": "String",
                "defaultOrder": "desc",
                "selected": true,
                "mandatory": true,
                "width": 250,
                "sort": "desc",
                "filters": "<"
              },
              {
                "name": "PROCEEDING_SUPPLEMENTARY_ID",
                "label": "Appeal Sequence #",
                "typeDefinition": "Number",
                "defaultOrder": "desc",
                "selected": true,
                "mandatory": true
              },
              {
                "name": "NEXT_DISPOSITION_DT",
                "label": "Next Upcoming Due Date",
                "typeDefinition": "Date",
                "defaultOrder": "desc",
                "selected": true,
                "mandatory": true
              },
              {
                "name": "HEARINGDATE",
                "label": "Hearing Date",
                "typeDefinition": "Date",
                "defaultOrder": "desc",
                "selected": false,
                "mandatory": true
              }
            ]
          }

        };

        // expect(scope['getViewCaseDocketData']).toBeDefined();
        // scope.getViewCaseDocketData();

        // HttpFactoryDeferred.resolve(successResponse);
        // scope.$digest();
      });

      // getting toaster error

      // it('get Actions failureResponse getViewCaseDocketData', function () {

      //   failureResponse = {
      //     data: {
      //       "message": "Widget Id does not exist in the system"
      //     },
      //     status: 404
      //   };

      //   expect(scope['getViewCaseDocketData']).toBeDefined();
      //   scope.getViewCaseDocketData();

      //   HttpFactoryDeferred.reject(failureResponse);
      //   scope.$digest();
      // });

      it('get Actions failureResponse getViewCaseDocketData', function () {

        failureResponse = {
          data: {
            "message": "Widget Id does not exist in the system"
          }
        };

        expect(scope['getViewCaseDocketData']).toBeDefined();
        scope.getViewCaseDocketData();

        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });

      it('it should call toggle filtering', function () {

        scope.gridOptions = {
          enableFiltering: true,
          data: "test"
        };

        scope.myData = {
          caseDetailsData: {

          }
        }
        // scope.showFilters = true;
        scope.gridApi = {
          core: {
            notifyDataChange: function (val) {

            }
          },
          grid: {
            clearAllFilters: function (val) {

            }
          }
        };

        expect(scope.toggleFiltering).toBeDefined();
        scope.toggleFiltering();
        // scope.showFilters = false;
      });

      it('it should open showFilteringHelp ', function () {

        var existingCount = $ngDialog.open.calls.count();
        expect(scope.showFilteringHelp).toBeDefined();
        scope.showFilteringHelp();
        expect($ngDialog.open).toHaveBeenCalled();

        expect($ngDialog.open.calls.count()).toBe(existingCount + 1);
        var args = $ngDialog.open.calls.argsFor(existingCount);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('CommonDialogController');
      });

      it('moveItem should swap origin and destination', function () {
        var origin = 0,
          destination = 1;
        var selectedCols = [{
          'userFavoritesName': 'testFavouriteOrigin',
          'userFavoritesURL': 'google.com'
        }, {
          'userFavoritesName': 'testFavouriteDest',
          'userFavoritesURL': 'bin.com'
        }];
        var selectedColsCopy = [{
          'userFavoritesName': 'testFavouriteOrigin',
          'userFavoritesURL': 'google.com'
        }, {
          'userFavoritesName': 'testFavouriteDest',
          'userFavoritesURL': 'bin.com'
        }];
        scope.selectedCols = selectedCols;
        expect(scope.moveItem).toBeDefined();
        scope.moveItem(origin, destination);

        expect(scope.selectedCols[0].userFavoritesName).not.toBe(selectedColsCopy[0].userFavoritesName);
        expect(scope.selectedCols[0].userFavoritesURL).not.toBe(selectedColsCopy[0].userFavoritesURL);

      });

      it('listItemUp should call move item', function () {

        expect(scope.listItemUp).toBeDefined();
        spyOn(scope, 'moveItem');
        expect(scope['moveItem']).toBeDefined();
        scope.listItemUp(1);
        expect(scope.moveItem).toHaveBeenCalledWith(1, 0);

      });

      it('listItemDown should call move item', function () {
        expect(scope.listItemDown).toBeDefined();
        spyOn(scope, 'moveItem');
        expect(scope['moveItem']).toBeDefined();
        scope.listItemDown(1);
        expect(scope.moveItem).toHaveBeenCalledWith(1, 2);

      });

      // it('get Actions success response updateColumns', function () {

      //   successResponse = {
      //     data: {
      //       "userWorkspaceWidgetIdentifier": 8879,
      //       "selectedColumns": [{
      //           "name": "PROCEEDING_CORE_ID",
      //           "label": "Application #",
      //           "typeDefinition": "String",
      //           "defaultOrder": "desc",
      //           "selected": true,
      //           "mandatory": true
      //         },
      //         {
      //           "name": "PROCEEDING_SUPPLEMENTARY_ID",
      //           "label": "Appeal Sequence #",
      //           "typeDefinition": "String",
      //           "defaultOrder": "desc",
      //           "selected": true,
      //           "mandatory": false
      //         },
      //         {
      //           "name": "NEXT_DISPOSITION_DT",
      //           "label": "Next Upcoming Due Date",
      //           "typeDefinition": "Date",
      //           "defaultOrder": "desc",
      //           "selected": true,
      //           "mandatory": false
      //         },
      //         {
      //           "name": "HEARINGDATE",
      //           "label": "Hearing Date",
      //           "typeDefinition": "Date",
      //           "defaultOrder": "desc",
      //           "selected": false,
      //           "mandatory": false
      //         }
      //       ],

      //       "mixedDocketsData": [{
      //           "caseDetailsData": [],
      //           "columnDetails": [{
      //               "name": "PATENT_NO",
      //               "label": "Patent #",
      //               "typeDefinition": "String",
      //               "defaultOrder": "desc",
      //               "selected": true,
      //               "mandatory": false
      //             },
      //             {
      //               "name": "PROCEEDING_SUPPLEMENTARY_ID",
      //               "label": "Appeal Sequence #",
      //               "typeDefinition": "String",
      //               "defaultOrder": "desc",
      //               "selected": true,
      //               "mandatory": false
      //             },
      //             {
      //               "name": "NEXT_DISPOSITION_DT",
      //               "label": "Next Upcoming Due Date",
      //               "typeDefinition": "Date",
      //               "defaultOrder": "desc",
      //               "selected": true,
      //               "mandatory": false
      //             }
      //           ]
      //         }

      //       ]
      //     }

      //   };

      //   expect(scope['updateColumns']).toBeDefined();
      //   scope.updateColumns();

      //   HttpFactoryDeferred.resolve(successResponse);
      //   // $rootScope.$apply();
      //   scope.$digest();
      // });

      // it('get Actions failureResponse updateColumns', function () {

      //   failureResponse = {
      //     data: {
      //       "status": 404,
      //       "message": "Widget Id does not exist in the system"
      //     }
      //   };

      //   expect(scope['updateColumns']).toBeDefined();
      //   scope.updateColumns();

      //   HttpFactoryDeferred.reject(failureResponse);
      //   // $rootScope.$apply();
      //   scope.$digest();
      // });

      // it('should call saveGridPreferences', function () {
      //   expect(scope.saveGridPreferences).toBeDefined();
      //   scope.saveGridPreferences();
      // });

      it('should call setPaginationManually', function () {
        expect(scope.setPaginationManually).toBeDefined();
        scope.setPaginationManually();
      });

      // it('should call toggleSelectAll', function () {
      //   expect(scope.toggleSelectAll).toBeDefined();
      //   scope.toggleSelectAll();
      // });

      // it('should call areAllSelected', function () {
      //   expect(scope.areAllSelected).toBeDefined();
      //   scope.areAllSelected();
      // });;

      it('should call refreshViewCaseDocketData', function () {
        expect(scope.refreshViewCaseDocketData).toBeDefined();
        scope.refreshViewCaseDocketData();
      });

      it('should call getKeyDates', function () {
        var row = {

        }
        expect(scope.getKeyDates).toBeDefined();
        scope.getKeyDates(row);

        expect($ngDialog.open).toHaveBeenCalled();

        expect($ngDialog.open.calls.count()).toBe(2);
        var args = $ngDialog.open.calls.argsFor(1);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('KeyDatesModalController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.row();

      });


      // it('should call createDecisionDocument', function () {

      //   scope.mySelectedRows = "";
      //   expect(scope.createDecisionDocument).toBeDefined();
      //   scope.createDecisionDocument();

      //   expect($ngDialog.open).toHaveBeenCalled();

      //   expect($ngDialog.open.calls.count()).toBe(2);
      //   var args = $ngDialog.open.calls.argsFor(1);
      //   expect(args).not.toBe(null);
      //   expect(args.length).toBe(1);

      //   expect(args[0].controller).toBe('createDecisionDocument');
      //   expect(typeof args[0].resolve).toBe('object');
      //   args[0].resolve.selectedRows();
      //   args[0].resolve.userName();

      // });


      it('should call panelData', function () {
        scope.panelMembers = [];
        var row = {
          entity: {
            APJ1_WORKER_ID: "sbartlett",
            APJ2_WORKER_ID: "sbartlett",
            APJ3_WORKER_ID: "sbartlett",
            APJ4_WORKER_ID: "sbartlett",
            APJ5_WORKER_ID: "sbartlett",
            APJ6_WORKER_ID: "sbartlett",
            APJ7_WORKER_ID: "sbartlett",
            APJ8_WORKER_ID: "sbartlett",
            APJ9_WORKER_ID: "sbartlett"
          }
        }
        expect(scope.panelData).toBeDefined();
        scope.panelData(row);
      });

      it('should call moveSourcetoDestination', function () {
        scope.clickedColumn = [{
          mandatory: false
        }]
        scope.availableCols = [{
          mandatory: false
        }]
        scope.selectedCols = [];
        expect(scope.moveSourcetoDestination).toBeDefined();
        //scope.moveSourcetoDestination();
      });

      // it('should call requestData', function () {

      //   var Selected={
      //     mandatory: false
      //   }
      //   scope.clickedColumn = [];
      //   expect(scope.requestData).toBeDefined();
      //   scope.requestData(event, Selected);
      // });

      it('should call moveSourcetoDestinationData', function () {
        var source = [{
          mandatory: false
        }]
        var destination = [];
        scope.ext = [];
        scope.newColumn = {
          visible: false
        }
        expect(scope.moveSourcetoDestinationData).toBeDefined();
        scope.moveSourcetoDestinationData(source, destination);
      });

      it('should call moveSourcetoDestinationData', function () {
        var source = [{
          mandatory: false
        }]
        var destination = [];
        scope.ext = [{
          visible: false
        }];
        scope.newColumn = {
          visible: false
        }
        expect(scope.moveSourcetoDestinationData).toBeDefined();
        scope.moveSourcetoDestinationData(source, destination);
      });

      it('should call moveSourcetoDestinationCancel', function () {
        var index = 0;
        scope.selectedCols = [{
          visible: true
        }]
        scope.availableCols = [];
        expect(scope.moveSourcetoDestinationCancel).toBeDefined();
        scope.moveSourcetoDestinationCancel(index);
      });

      it('should call toggleSelectAll', function () {
        scope.availableCols = [{
          mandatory: false
        }]
        scope.selectedCols = [];
        expect(scope.toggleSelectAll).toBeDefined();
        scope.toggleSelectAll();
      });

      it('should call removeAll', function () {
        scope.selectedCols = [{
          mandatory: false
        }]
        scope.availableCols = [];
        expect(scope.removeAll).toBeDefined();
        scope.removeAll();
      });


      // it('should call buildCaseAlerts', function () {
      //   columndefs = [{
      //     displayName: "false"
      //   }]
      //   // expect(scope.buildCaseAlerts).toBeDefined();
      //   // scope.buildCaseAlerts();
      // });


      it('should call removeAll', function () {
        scope.selectedCols = [{
          mandatory: true
        }]
        scope.availableCols = [];
        expect(scope.removeAll).toBeDefined();
        scope.removeAll();
      });
    });


  });
})();
