(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('CreateDecisionDocController', function (toastr, CONSTANTS, $scope, selectedRows, HttpFactory, userName, $http) {
      var vm = this;
      $scope.template = "select template";
      vm.startDate = new Date();
      vm.selectedRows = selectedRows[0];
      vm.caseNumber = vm.selectedRows.PROCEEDING_NO;
      vm.applicationNumber = vm.selectedRows.PROCEEDING_CORE_ID;
      $scope.showError = false;
      $scope.userName = userName;
      $scope.rtfBaseLink = CONSTANTS.URL.BASE;
      $scope.disableGen = true;
      vm.gettemplateDetails = function () {
        HttpFactory.getActions("/word-document-reader/allAppealData?appealNumber=" + vm.selectedRows.PROCEEDING_NO + "&serialNumber=" + vm.applicationNumber)
          .then(function (successResponse) {
            $scope.templateData = successResponse.data;
            $scope.disableGen = false;
            $scope.documentCategory = $scope.templateData[0].documentCategory;
            $scope.applicant = $scope.templateData[0].applicant;
            $scope.patentOwners = $scope.templateData[0].patentOwners;
            $scope.partysInformation = $scope.templateData[0].partysInformation;
            $scope.realParties = $scope.templateData[0].realParties;
            if ($scope.templateData[0].descriptiveInfo == null) {
              $scope.inventorsList = "";
              $scope.techCenter = "";
              $scope.applicationType = "";
            } else {
              $scope.inventorsList = $scope.templateData[0].descriptiveInfo.inventors;
              $scope.techCenter = $scope.templateData[0].descriptiveInfo.techCenterNumber;
              $scope.applicationType = $scope.templateData[0].descriptiveInfo.applicationType;
            }

            if ($scope.templateData[0].parentInfo == null) {
              $scope.inventionTitle = "";
            } else {
              $scope.inventionTitle = $scope.templateData[0].parentInfo.inventionTitleText;
            }

            if ($scope.templateData[0].corrAddress == null) {
              $scope.customerNumberText = "",
                $scope.nameLineOneText = "",
                $scope.nameLineTwoText = "",
                $scope.lineOneText = "";
              $scope.lineTextTwo = "";
              $scope.cityName = "";
              $scope.regionName = "";
              $scope.postalCode = "";
            } else {
              $scope.customerNumberText = $scope.templateData[0].corrAddress.customerNumberText,
                $scope.nameLineOneText = $scope.templateData[0].corrAddress.nameLineOneText,
                $scope.nameLineTwoText = $scope.templateData[0].corrAddress.nameLineTwoText,
                $scope.lineOneText = $scope.templateData[0].corrAddress.streetAddressLineOneText;
              $scope.cityName = $scope.templateData[0].corrAddress.cityName;
              $scope.regionName = $scope.templateData[0].corrAddress.geographicRegionName;
              $scope.postalCode = $scope.templateData[0].corrAddress.postalCode;
              if ($scope.templateData[0].corrAddress.streetAddressLineTwoText == null) {
                $scope.lineTextTwo = "";
              } else {
                $scope.lineTextTwo = $scope.templateData[0].corrAddress.streetAddressLineTwoText;
              }
            }
            $scope.addressLineOne = $scope.lineOneText + ' ' + $scope.lineTextTwo;
            $scope.addressLineTwo = $scope.cityName + ', ' + $scope.regionName + ' ' + $scope.postalCode;
            $scope.formattedPanel = $scope.templateData[0].formattedPanel;
            $scope.assignedPanel = $scope.templateData[0].assignedPanel;
            $scope.apj1Name = $scope.templateData[0].lastNameOfApj1;
            $scope.patentAttorney = $scope.templateData[0].patentAttorney;
            $scope.realPartiesInInterest = $scope.templateData[0].realPartiesInInterest;
            $scope.firstInventorToFileIndicator = $scope.templateData[0].firstInventorToFileIndicator;
            $scope.palmStatus = $scope.templateData[0].palmStatusDescription;
            $scope.formattedInventors = $scope.templateData[0].formattedInventors;
            $scope.assignee = $scope.templateData[0].assignee;
            $scope.appellants = $scope.templateData[0].appellants;
            $scope.serialNumberText = $scope.templateData[0].serialNumberText;
            $scope.appealNumberText = $scope.templateData[0].appealNumberText;
            if ($scope.firstInventorToFileIndicator == "N") {
              $scope.aiaYesNo = "No";
            } else if ($scope.firstInventorToFileIndicator == "Y") {
              $scope.aiaYesNo = "Yes";
            }
          }, function (failureResponse) {
            $scope.disableGen = true;
            toastr.error(failureResponse.data.message, {
              iconClass: 'toast-danger',
              timeOut: 8000
            });
          });
      };
      vm.gettemplateDetails();

      $scope.templateFunc = function () {
        if ($scope.template == "select template") {
          $scope.showError = true;
        } else {
          $scope.showError = false;
        }
      };
      /* istanbul ignore next */
      $scope.getDocument = function (contents) {
        $http.get(contents, {
            responseType: 'arraybuffer',
            headers: {
              'Accept': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            }
          })
          .success(function (data) {
            var file = new Blob([data], {
              type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            });
            var a = document.createElement('a');
            a.href = URL.createObjectURL(file);
           // previous download setting a.download = "fd" + $scope.appealNumberText + " draft" + ".docx";
           a.download = $scope.fileName;
            a.click();
            $scope.disableGen = false;

          }).error(function () { // intentional
          });
      };
      $scope.documentDownload = function () {
        if ($scope.template == "select template") {
          $scope.showError = true;
        } else {
          $scope.disableGen = true;
          $scope.isLoading = true;
          $scope.downloadDocInfo = {
            "fileType": $scope.template,
            "formattedInventors": $scope.formattedInventors,
            "palmStatus": $scope.palmStatus,
            "assignee": $scope.assignee,
            "assignedPanel": $scope.assignedPanel,
            "lastNameOfApj1": $scope.apj1Name,
            "realPartiesInInterest": $scope.realPartiesInInterest,
            "firstInventorToFileIndicator": $scope.firstInventorToFileIndicator,
            "formattedPanel": $scope.formattedPanel,
            "patentAttorney": $scope.patentAttorney,
            "serialNumber": vm.applicationNumber,
            "appealNumber": vm.caseNumber,
            "documentCategory": "DECISION_TEMPLATES",
            "descriptiveInfo": {
              "techCenterNumber": $scope.techCenter,
            },
            "parentInfo": {
              "techCenterNumber": $scope.techCenter,
              "inventionTitleText": $scope.inventionTitle
            },
            "corrAddress": {
              "customerNumberText": $scope.customerNumberText,
              "nameLineOneText": $scope.nameLineOneText,
              "nameLineTwoText": $scope.nameLineTwoText,
              "streetAddressLineOneText": $scope.lineOneText,
              "streetAddressLineTwoText": $scope.lineTextTwo,
              "cityName": $scope.cityName,
              "geographicRegionName": $scope.regionName,
              "postalCode": $scope.postalCode
            },

            "partysInformation": $scope.partysInformation,
            "appellants": $scope.appellants,
            "applicant": $scope.applicant,
            "realParties": $scope.realParties,
            "patentOwners": $scope.patentOwners,
          };
          HttpFactory.postActions("/word-document-reader", $scope.downloadDocInfo)
            .then(function (successResponse) {
              $scope.isLoading = false;
              $scope.postDataResponse = successResponse.data.fileContent;
              $scope.fileName = successResponse.data.fileName;
              $scope.getDocument('data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,' + $scope.postDataResponse);
            }, function (failureResponse) {
              $scope.isLoading = false;
              $scope.disableGen = false;
              toastr.error(failureResponse.data.message, {
                iconClass: 'toast-danger',
                timeOut: 8000
              });
            });
        }
      };
    });
})();
