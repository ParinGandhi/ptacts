(function () {
  'use strict';

  describe('SelectTrialsPathController', function () {

    beforeEach(module('ptabe2e'))
    var $controller;
    var vm = this;
    var controller, scope, $rootScope;
    var $httpBackend, spy, HttpFactoryDeferred;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'close', 'closeAll']);
    var $q, $http, $interval;

    var failureResponse = '';
    var successResponse = '';

    beforeEach(inject(function (_$controller_, _$http_, _$rootScope_, _$interval_, _$q_, HttpFactory, CONSTANTS) {
      $q = _$q_;
      $http = _$http_;
      scope = _$rootScope_.$new();
      $interval = _$interval_;
      $rootScope = _$rootScope_;
      scope.ngDialogData = {};

      // setup the promise
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      $controller = _$controller_;

      controller = $controller('SelectTrialsPathController', {
        $http: $http,
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        $interval: $interval,
        HttpFactory: HttpFactory,
      });
    }));


    describe('check the controller', function () {


      it(' should call the controller', function () {
        expect(controller.modalTitle).toBeDefined();

      });

      // it(' should call openCaseViewer', function () {
      //   row = {
      //     "entity": {
      //       "serialNumber": "90008169",
      //       "appealNumber": "2020000030",
      //       "patentNumber": "RE34783",
      //       "trialsNumber": "2020000030"
      //     }
      //   }
      //   expect(scope['openCaseViewer']).toBeDefined();
      //   scope.openCaseViewer(row);
      // });
      // it(' should call openCaseViewer', function () {
      //   row = {
      //     "entity": {
      //       "serialNumber": "DER",
      //       "appealNumber": "DER",
      //       "patentNumber": "DER",
      //       "trialsNumber": "DER"
      //     }
      //   }
      //   expect(scope['openCaseViewer']).toBeDefined();
      //   scope.openCaseViewer(row);
      // });

      // it(' should call openCirculationManager', function () {
      //   row = {
      //     "entity": {
      //       "serialNumber": "90008169",
      //       "appealNumber": "2020000030",
      //       "patentNumber": "RE34783",
      //       "trialsNumber": "2020000030"
      //     }
      //   }
      //   controller.circulationViewable = true;
      //   expect(scope['openCirculationManager']).toBeDefined();
      //   scope.openCirculationManager(row);
      // });

      // it(' should call pressEnter', function () {
      //   event = {
      //     "keyCode": 1
      //   }
      //   expect(controller.pressEnter).toBeDefined();
      //   controller.pressEnter(event);
      // });
      // it(' should call pressEnter', function () {
      //   event = {
      //     "keyCode": 13
      //   }
      //   expect(controller.pressEnter).toBeDefined();
      //   controller.pressEnter(event);
      // });

      // it('it should call getCaseInfo failureResponse', function () {
      //   row = {
      //     "entity": {
      //       "serialNumber": "90008169",
      //       "appealNumber": "545666",
      //       "patentNumber": "RE34783",
      //       "trialsNumber": "2020000030"
      //     }
      //   }
      //   failureResponse = {
      //     data: "FAILED"
      //   };
      //   expect(scope.getCaseInfo).toBeDefined();
      //   scope.getCaseInfo(row);
      //   HttpFactoryDeferred.reject(failureResponse);
      //   scope.$digest();
      // });

      // it('it should call getCaseInfo', function () {
      //   row = {
      //     "entity": {
      //       "serialNumber": "der",
      //       "appealNumber": "der",
      //       "patentNumber": "der",
      //       "trialsNumber": "der"
      //     }
      //   }
      //   expect(scope.getCaseInfo).toBeDefined();
      //   scope.getCaseInfo(row);
      // });

      // it('it should call getCaseInfo success', function () {
      //   row = {
      //     "entity": {
      //       "serialNumber": "90008169",
      //       "appealNumber": "545666",
      //       "patentNumber": "RE34783",
      //       "trialsNumber": "2020000030"
      //     }
      //   }
      //   successResponse = {
      //     data: [{
      //       "circulationReorderExists": false,
      //       "casetransactionDetails": [],
      //       "briefHearingTypeCode": "On brief",
      //       "casePhase": "Pending Decision",
      //       "inventionTitle": "CONFOCAL WAFER-INSPECTION SYSTEM",
      //       "interruptInProcess": false,
      //       "patentNumberText": "6934019",
      //       "proceedingNumber": "2019004454",
      //       "ptabDefaultRefreshTime": 300000,
      //       "ptabReadOnlyUser": false,
      //       "mileStoneDates": null,
      //       "parties": "6,934,019  et al.",
      //       "attorneys": [{
      //         employeeName: "Squire, Monte T.",
      //         rank: 1
      //       }, {
      //         employeeName: "Lebovitz, Richard M.",
      //         rank: 2
      //       }],
      //       "ptabDueDateNonEditableUser": false,
      //       "circulationViewable": true,
      //       "appealNumberText": "2019004454",
      //       "applicationTypeCategory": "REEXAM"
      //     }]
      //   };
      //   expect(scope.getCaseInfo).toBeDefined();
      //   scope.getCaseInfo(row);
      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();
      // });

      // it('it should call advancedSearch failureResponse', function () {
      //   scope.searchTotalLength = 0;
      //   scope.failureResponse = false;
      //   controller.displayNone = true;
      //   controller.gridOptions.data = [];
      //   scope.failureResponse = true;
      //   scope.searchLength = 0;
      //   scope.searchThis = "12345"
      //   failureResponse = {
      //     data: "FAILED"
      //   };
      //   expect(controller.advancedSearch).toBeDefined();
      //   controller.advancedSearch();
      //   HttpFactoryDeferred.reject(failureResponse);
      //   scope.$digest();
      // });

      // it(' should call optionCase', function () {
      //   scope.searchThis = ""
      //   scope.searchTerm = "CASE_NUMBER";
      //   scope.searchOption = "Case #";
      //   controller.showResults = false;
      //   scope.failureResponse = false;
      //   expect(controller.optionCase).toBeDefined();
      //   controller.optionCase();
      // });


      // it(' should call optionTrials', function () {
      //   scope.searchThis = ""
      //   scope.searchTerm = "TRIAL_NUMBER";
      //   scope.searchOption = "AIA Trails #";
      //   controller.showResults = false;
      //   scope.failureResponse = false;
      //   expect(controller.optionTrials).toBeDefined();
      //   controller.optionTrials();
      // });

      // it(' should call optionApplication', function () {
      //   scope.searchThis = ""
      //   scope.searchTerm = "APPLICATION_NUMBER";
      //   scope.searchOption = "Application #";
      //   controller.showResults = false;
      //   scope.failureResponse = false;
      //   expect(controller.optionApplication).toBeDefined();
      //   controller.optionApplication();
      // });

      // it(' should call optionPatent', function () {
      //   scope.searchThis = ""
      //   scope.searchTerm = "PATENt_NUMBER";
      //   scope.searchOption = "Patent #";
      //   controller.showResults = false;
      //   scope.failureResponse = false;
      //   expect(controller.optionPatent).toBeDefined();
      //   controller.optionPatent();
      // });

      // it(' should call numberLook', function () {
      //   controller.showResults = false;
      //   controller.noNumberSelected = false;
      //   scope.failureResponse = false;
      //   expect(controller.numberLook).toBeDefined();
      //   controller.numberLook();
      // });

      // it(' should call advancedSearch', function () {
      //   scope.searchTotalLength = 0;
      //   scope.failureResponse = false;
      //   controller.displayNone = true;
      //   controller.gridOptions.data = [];
      //   scope.searchThis = ""
      //   controller.showResults = false;
      //   controller.noNumberSelected = true;
      //   expect(controller.advancedSearch).toBeDefined();
      //   controller.advancedSearch();
      // });



    });
  });
})();
