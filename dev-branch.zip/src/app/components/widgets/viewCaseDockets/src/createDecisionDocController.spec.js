(function () {
  'use strict';

  describe('CreateDecisionDocController', function () {

    beforeEach(module('ptabe2e'))
    var $controller;
    var vm = this;
    var controller, scope, $rootScope;
    var successResponse, userName;
    var selectedRows, HttpFactoryDeferred;
    var $q, $http, $interval;
    selectedRows = [{
      "CASE_DISCIPLINE_NM": "Mechanical",
      "hearingDueDays": -298,
      "PROCEEDING_TYPE_CT": "APPEAL",
      "APJ8_WORKER_ID": " ",
      "panelingDiscipline": "Mechanical",
      "INVENTION_SUBJECT_MATTER_CD": "UTL",
      "PROCEDDING_NO": 122234,
      "PROCEEDING_CORE_ID": 12,
      "PANELING_DT": 1558363866000,
      "DECISION_DUE_DAYS": null,
      "ID": "14615993:APPEAL:2019005026",
      "APPEAL_DECISION_DUE_DT": 1567137600000,
      " APJ5_DISCIPLINE_NM": null,
      " ART_CLS_NO": "600",
      "APJ1_WORKER_ID": "Warner, Brandon J.",
      "PROCEEDING_STATE_NM": "Pending Hearing",
      "PROCEEDING_FILING_DT": 1558040206000,
      "APJ2_WORKER_ID": "Abraham, Jeffrey W.",
      "INSTITUTION_DECISION_DT": null,
      "APJ9_WORKER_ID": " ",
      "APJ8_SECTION_NM": null,
      "INVENTOR_NAME_TX": "YUAN, Baohong  et al.",
      "ART_UNIT_NO": "3793",
      "APJ2_DISCIPLINE_NM": "Chemical",
      "ATTORNEY_WORKER_ID": " ",
      "LATEST_PALM_STATUS_NO": 124,
      "APJ7_DISCIPLINE_NM": null,
      "INTERESTED_PARTY_NAME_TX": "Board of Regents, The University of Texas System",
      "LATEST_PALM_DESCRIPTION_TX": "Finished Initial Data Capture",
      "APJ7_SECTION_NM": null,
      "ART_SUBCLS_NO": "431000",
      "APJ3_WORKER_ID": "Astorino, Michael C.",
      "APJ1_SECTION_NM": "Section 07",
      "statutoryDateMinusYear": null,
      "APJ6_WORKER_ID": " ",
      "APJ2_SECTION_NM": "Section 04",
      "APPEAL_FORWARDING_FEE_PAID_DT": null,
      "PROCEEDING_STATUTORY_DT": null,
      "APJ5_SECTION_NM": null,
      "APJ8_DISCIPLINE_NM": null,
      "decisionDueDays": null,
      "institutionDueDays": null,
      "APPLICATION_TYPE_NM": "REGULAR",
      "techCenter": "3700",
      "APJ3_SECTION_NM": "Section 08",
      "APJ9_DISCIPLINE_NM": null,
      "CONTINUITY_TYPE_CD": "CIP",
      "APJ4_SECTION_NM": null,
      "SPECIAL_PROCEEDING_TYPE_NM": null,
      "LATEST_PAPER_FILED_DT": 1557720000000,
      "PROCEEDING_NO": "2019005026",
      "APPLICANT_NAME_TX": "Board of Regents, The University of Texas System",
      "COMBINED_INDICATOR": null,
      "REDIRECT_URL": null,
      "HEARING_DT": 1558324800000,
      "APJ6_SECTION_NM": null,
      "LATEST_PALM_STATUS_CD": "FIDC",
      "ALL_DISPOSITION_TX": (2)["05/20/2019- Hearing Date", "08/30/2019 - Decision Due Date "],
      "APPEAL_DECISION_DUE_DAYS": -196,
      "APJ1_DISCIPLINE_NM": "Electrical",
      "PROCEEDING_NAME_TX": "TEST",
      "APJ9_SECTION_NM": null,
      "APJ6_DISCIPLINE_NM": null,
      "ADDITIONAL_APJ_WORKER_ID_TX": null,
      "PATENT_NO": null,
      "APJ5_WORKER_ID": " ",
      "PROCEEDING_COMMENT_TX": "<p>Test notes added for purpose of defect test</p>",
      "CPC_SYMBOL_TX": "G01N33/5091",
      "DOCKET_NOTICE_MAILED_DT": 1558536397000,
      "INITIATOR_NAME_TX": "Board of Regents, The University of Texas System",
      "RESPONDENT_NAME_TX": null,
      "HEARING_STATUS_CD": "Appearance made",
      "PROCEEDING_TYPE_NM": "Heard",
      "APPEAL_DUE_DATE_ASSIGNED_DT": null,
      "NEXT_DISPOSITION_NM": "Decision due date",
      "APJ3_DISCIPLINE_NM": "Mechanical",
      "ADDITIONAL_JUDGE_IN": "N",
      "ASSIGNEE_NAME_TX": null,
      "APJ4_WORKER_ID": " ",
      "NEXT_DISPOSITION_DT": 1567137600000,
      "APJ7_WORKER_ID": " ",
      "NOFDA_DT": null,
      "HEARING_NOTICE_MAILED_DT": 1558364104000,
      "TERMINATION_TYPE_NM": null,
      "PROCEEDING_STATUS_NM": "Awaiting appellant(s) response",
      "INVENTION_TITLE_TX": "SYSTEMS AND METHODS FOR HIGH-RESOLUTION IMAGING",
      "APJ4_DISCIPLINE_NM": null
    }]

    var failureResponse = '';
    userName = "edkj"

    beforeEach(inject(function (_$controller_, _$http_, _$rootScope_, _$interval_, _$q_, HttpFactory, CONSTANTS) {
      $q = _$q_;
      $http = _$http_;
      scope = _$rootScope_.$new();
      $interval = _$interval_;
      $rootScope = _$rootScope_;

      // setup the promise
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);
      $controller = _$controller_;

      controller = $controller('CreateDecisionDocController', {
        $http: $http,
        $scope: scope,
        $rootScope: _$rootScope_,
        $interval: $interval,
        HttpFactory: HttpFactory,
        selectedRows: selectedRows,
        userName: userName
      });
    }));


    describe('check functions', function () {

      it(' should call templateFunc', function () {
        scope.template = "x"
        expect(scope['templateFunc']).toBeDefined();
        scope.templateFunc();
      });
      it(' should call templateFunc', function () {
        scope.template = "select template"
        expect(scope['templateFunc']).toBeDefined();
        scope.templateFunc();
      });

      it('it should call gettemplateDetails and get data', function () {
        successResponse = {
          data: [{

            "serialNumber": "95000068",
            "sequenceNumber": null,
            "appealNumber": "2009001927",
            "proceedingType": null,
            "lifeCycle": null,
            "audit": null,
            "serialNumberText": "95/000,068",
            "appealNumberText": "2009-001927",
            "patentNumberText": "6,531,537",
            "documentCategory": null,
            "descriptiveInfo": {
              "appealNumberText": "2009001927",
              "appealType": null,
              "caseDiscipline": null,
              "inventors": [{
                "lifeCycle": {
                  "beginDate": 1105043661
                },
                "audit": {
                  "lastModifiedUser": "msaldana",
                  "lastModifiedTime": 1105043661
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 1,
                  "authorityType": "INV",
                  "partyIdentifier": "33443250",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "lastName": "6531537",
                  "identifier": "33443250",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "6531537",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 1105043718
                },
                "audit": {
                  "lastModifiedUser": "msaldana",
                  "lastModifiedTime": 1105043718
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 2,
                  "authorityType": "INV",
                  "partyIdentifier": "33443252",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "Rohm",
                  "middleName": "and Haas",
                  "lastName": "Company(Owner)",
                  "identifier": "33443252",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "Rohm and Haas  Company(Owner)",
                      "cityName": "Philadelphia",
                      "geographicRegionCode": "PA",
                      "geographicRegionName": "PENNSYLVANIA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 1105043786
                },
                "audit": {
                  "lastModifiedUser": "msaldana",
                  "lastModifiedTime": 1105043786
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 3,
                  "authorityType": "INV",
                  "partyIdentifier": "33443262",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "MicroBlend",
                  "middleName": "Technologies",
                  "lastName": "Inc.(3rd. Pty. Req.)",
                  "identifier": "33443262",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "MicroBlend Technologies  Inc.(3rd. Pty. Req.)",
                      "cityName": "Gilbert",
                      "geographicRegionCode": "AZ",
                      "geographicRegionName": "ARIZONA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 1105043955
                },
                "audit": {
                  "lastModifiedUser": "mtwitty",
                  "lastModifiedTime": 1119965303
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 4,
                  "authorityType": "RXR",
                  "partyIdentifier": "33443265",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "Albert",
                  "middleName": "L.",
                  "lastName": "Schmeiser",
                  "identifier": "33443265",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "Albert L. Schmeiser",
                      "cityName": "Mesa",
                      "geographicRegionCode": "AZ",
                      "geographicRegionName": "ARIZONA",
                      "addressCategory": "residence"
                    }, {
                      "nameLineOneText": "Albert L. Schmeiser",
                      "addressLineOneText": "Schmeiser Olsen & Watts, LLP",
                      "addressLineTwoText": "18 E. University Dr. # 101",
                      "cityName": "Mesa",
                      "geographicRegionCode": "AZ",
                      "geographicRegionName": "ARIZONA",
                      "countryCode": "US",
                      "countryName": "UNITED STATES",
                      "postalCode": "85201",
                      "addressCategory": "postal"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 1105743288
                },
                "audit": {
                  "lastModifiedUser": "mtwitty",
                  "lastModifiedTime": 1105743288
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 5,
                  "authorityType": "INV",
                  "partyIdentifier": "33489241",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "MicroBlend",
                  "lastName": "Technologies, Inc.(Real Pty. In Interest)",
                  "identifier": "33489241",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "MicroBlend  Technologies, Inc.(Real Pty. In Intere",
                      "cityName": "Gilbert",
                      "geographicRegionCode": "AZ",
                      "geographicRegionName": "ARIZONA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }],
              "applicationType": "REEXAM",
              "artClassNumber": "524",
              "artSubClassNumber": "497000",
              "cpcCodeFirst": null,
              "techCenterNumber": "3900",
              "artUnit": "3991",
              "specialType": "",
              "ptabReceivedDate": null,
              "worker": {
                "workerNumber": "70817",
                "activeIndicator": false,
                "fullName": ""
              },
              "realPartiesDetails": null,
              "appellantsDetails": null,
              "proceedingNumber": "2009001927",
              "proceedingType": null,
              "panelingDisciplineCode": null,
              "panellingDisciplineDescriptionText": null,
              "caseDisciplineCode": null
            },
            "parentInfo": {
              "applicationNumberText": "09785152         ",
              "artClassNumber": "524",
              "artSubClassNumber": "497000",
              "techCenterNumber": "1700",
              "artUnit": "1714",
              "inventors": [{
                "lifeCycle": {
                  "beginDate": 985111169
                },
                "audit": {
                  "lastModifiedUser": "hchristian",
                  "lastModifiedTime": 991828055
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 1,
                  "authorityType": "INV",
                  "partyIdentifier": "26283269",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "John",
                  "middleName": "Michael",
                  "lastName": "Friel",
                  "identifier": "26283269",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "John Michael Friel",
                      "cityName": "Warminister",
                      "geographicRegionCode": "PA",
                      "geographicRegionName": "PENNSYLVANIA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 985111210
                },
                "audit": {
                  "lastModifiedUser": "hchristian",
                  "lastModifiedTime": 991828082
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 2,
                  "authorityType": "INV",
                  "partyIdentifier": "26283275",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "John",
                  "middleName": "William",
                  "lastName": "Hook",
                  "nameSuffix": "III",
                  "identifier": "26283275",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "John William Hook III",
                      "cityName": "Warminister",
                      "geographicRegionCode": "PA",
                      "geographicRegionName": "PENNSYLVANIA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 985111261
                },
                "audit": {
                  "lastModifiedUser": "thaile",
                  "lastModifiedTime": 985111261
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 3,
                  "authorityType": "INV",
                  "partyIdentifier": "26283283",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "Bernhard",
                  "middleName": "Helmut",
                  "lastName": "Lieser",
                  "identifier": "26283283",
                  "citizenship": "DE",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "Bernhard Helmut Lieser",
                      "cityName": "San Pedro",
                      "geographicRegionCode": "CA",
                      "geographicRegionName": "CALIFORNIA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 985111308
                },
                "audit": {
                  "lastModifiedUser": "thaile",
                  "lastModifiedTime": 985111308
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 4,
                  "authorityType": "INV",
                  "partyIdentifier": "26283290",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "Jerry",
                  "middleName": "William",
                  "lastName": "Washel",
                  "identifier": "26283290",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "Jerry William Washel",
                      "cityName": "Harleysville",
                      "geographicRegionCode": "PA",
                      "geographicRegionName": "PENNSYLVANIA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 985111355
                },
                "audit": {
                  "lastModifiedUser": "thaile",
                  "lastModifiedTime": 985111355
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 5,
                  "authorityType": "INV",
                  "partyIdentifier": "26283300",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "Dennis",
                  "middleName": "Paul",
                  "lastName": "Lorah",
                  "identifier": "26283300",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "Dennis Paul Lorah",
                      "cityName": "Lansdale",
                      "geographicRegionCode": "PA",
                      "geographicRegionName": "PENNSYLVANIA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 985111405
                },
                "audit": {
                  "lastModifiedUser": "thaile",
                  "lastModifiedTime": 985111405
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 6,
                  "authorityType": "INV",
                  "partyIdentifier": "26283305",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "Joseph",
                  "middleName": "Michael",
                  "lastName": "Beno",
                  "nameSuffix": "JR.",
                  "identifier": "26283305",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "Joseph Michael Beno JR.",
                      "cityName": "New Hope",
                      "geographicRegionCode": "PA",
                      "geographicRegionName": "PENNSYLVANIA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 985111455
                },
                "audit": {
                  "lastModifiedUser": "thaile",
                  "lastModifiedTime": 985111455
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 7,
                  "authorityType": "INV",
                  "partyIdentifier": "26283309",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "Irene",
                  "middleName": "May",
                  "lastName": "Melly",
                  "identifier": "26283309",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "Irene May Melly",
                      "cityName": "Oreland",
                      "geographicRegionCode": "PA",
                      "geographicRegionName": "PENNSYLVANIA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }],
              "inventionTitleText": "PREPAINTS AND METHODS OF PREPARING PAINTS FROM THE PREPAINTS"
            },
            "corrAddress": {
              "customerNumberText": "23416",
              "nameLineOneText": "POLSINELLI PC",
              "nameLineTwoText": "(DE OFFICE)",
              "streetAddressLineOneText": "1000 Louisiana Street",
              "streetAddressLineTwoText": "Fifty-Third Floor",
              "cityName": "HOUSTON",
              "geographicRegionName": "TX",
              "postalCode": "77002"
            },
            "thirdPartyInfo": {
              "customerNumber": "23416",
              "nameLineOneText": "Albert L. Schmeiser",
              "nameLineTwoText": "",
              "addressLineOneText": "Schmeiser Olsen & Watts, LLP",
              "addressLineTwoText": "18 E. University Dr. # 101",
              "cityName": "Mesa",
              "geographicRegionCode": "AZ",
              "geographicRegionName": null,
              "postalCode": "85201",
              "worker": {
                "workerNumber": "36715",
                "activeIndicator": false,
                "fullName": "WATKINS, SCOTT"
              }
            },
            "partysInformation": {
              "petitionCounsel": null,
              "petitionRealParty": null,
              "poCounsel": null,
              "poRealParty": null
            },
            "briefHearingTypeCode": "B",
            "caseDisciplineCode": "C",
            "currentStatusCode": "D1R0",
            "receivedDate": 1218513600000,
            "applicationActivityRequest": null,
            "noticeOfAppealDate": null,
            "appealSpecialTypes": null,
            "palmEntryDate": null,
            "palmRecordedDate": null,
            "appellants": [],
            "realParties": [],
            "patentOwners": [],
            "thirdPartyRequestor": [],
            "panelingDisciplineCode": "C",
            "decisions": [],
            "decisionAssignment": null,
            "fileName": null,
            "activeJudges": [{
              "identifier": "91374",
              "panelRank": 1,
              "assignedDate": 1587645214000,
              "panelName": "Abraham, Jeffrey W.",
              "panelSequenceNumber": 2,
              "reConsiderSeqNumber": 0
            }, {
              "identifier": "62756",
              "panelRank": 2,
              "assignedDate": 1587645214000,
              "panelName": "Macdonald, Allen ",
              "panelSequenceNumber": 2,
              "reConsiderSeqNumber": 0
            }, {
              "identifier": "88548",
              "panelRank": 3,
              "assignedDate": 1587645214000,
              "panelName": "Bisk, Jennifer S.",
              "panelSequenceNumber": 2,
              "reConsiderSeqNumber": 0
            }],
            "opsgMetadataList": null,
            "applicationStatus": null,
            "palmStatus": "440",
            "palmStatusDescription": "PTAB Decision - Affirmance",
            "palmStatusCode": "RXBDAF",
            "patentNumber": "6531537",
            "firstInventorToFileIndicator": "Y",
            "initials": null,
            "realPartiesInInterest": null,
            "assignedPanel": "Abraham, Jeffrey W., Macdonald, Allen, and Bisk, Jennifer S.",
            "formattedPanel": "JEFFREY W. ABRAHAM, JENNIFER S. BISK, and ALLEN MACDONALD",
            "apj1Name": "JEFFREY W. ABRAHAM",
            "patentAttorney": null,
            "formattedInventors": " 6531537, ROHM AND HAAS COMPANY(OWNER), MICROBLEND TECHNOLOGIES INC.(3RD. PTY. REQ.), ALBERT L. SCHMEISER, and MICROBLEND TECHNOLOGIES, INC.(REAL PTY. IN INTEREST)",
            "applicant": "",
            "assignee": "Rohm and Hass Company",
            "requester": null,
            "patentOwner": null,
            "seniorPartyName": null,
            "juniorPartyName": null,
            "lastNameOfApj1": "ABRAHAM",
            "correspondenceAddress": null,
            "partyAddress": null,
            "fileType": null,
            "rulingCategoryAPj1": "",
            "otherApjs": "ALLEN MACDONALD, JENNIFER S. BISK",
            "result": null,
            "decisionTypeCode": null

          }]
        };
        expect(controller.gettemplateDetails).toBeDefined();
        controller.gettemplateDetails();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
      });

      it('it should call gettemplateDetails and check if statements', function () {
        successResponse = {
          data: [{

            "serialNumber": "95000068",
            "sequenceNumber": null,
            "appealNumber": "2009001927",
            "proceedingType": null,
            "lifeCycle": null,
            "audit": null,
            "serialNumberText": "95/000,068",
            "appealNumberText": "2009-001927",
            "patentNumberText": "6,531,537",
            "documentCategory": null,
            "descriptiveInfo": {
              "appealNumberText": "2009001927",
              "appealType": null,
              "caseDiscipline": null,
              "inventors": [{
                "lifeCycle": {
                  "beginDate": 1105043661
                },
                "audit": {
                  "lastModifiedUser": "msaldana",
                  "lastModifiedTime": 1105043661
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 1,
                  "authorityType": "INV",
                  "partyIdentifier": "33443250",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "lastName": "6531537",
                  "identifier": "33443250",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "6531537",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 1105043718
                },
                "audit": {
                  "lastModifiedUser": "msaldana",
                  "lastModifiedTime": 1105043718
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 2,
                  "authorityType": "INV",
                  "partyIdentifier": "33443252",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "Rohm",
                  "middleName": "and Haas",
                  "lastName": "Company(Owner)",
                  "identifier": "33443252",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "Rohm and Haas  Company(Owner)",
                      "cityName": "Philadelphia",
                      "geographicRegionCode": "PA",
                      "geographicRegionName": "PENNSYLVANIA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 1105043786
                },
                "audit": {
                  "lastModifiedUser": "msaldana",
                  "lastModifiedTime": 1105043786
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 3,
                  "authorityType": "INV",
                  "partyIdentifier": "33443262",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "MicroBlend",
                  "middleName": "Technologies",
                  "lastName": "Inc.(3rd. Pty. Req.)",
                  "identifier": "33443262",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "MicroBlend Technologies  Inc.(3rd. Pty. Req.)",
                      "cityName": "Gilbert",
                      "geographicRegionCode": "AZ",
                      "geographicRegionName": "ARIZONA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 1105043955
                },
                "audit": {
                  "lastModifiedUser": "mtwitty",
                  "lastModifiedTime": 1119965303
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 4,
                  "authorityType": "RXR",
                  "partyIdentifier": "33443265",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "Albert",
                  "middleName": "L.",
                  "lastName": "Schmeiser",
                  "identifier": "33443265",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "Albert L. Schmeiser",
                      "cityName": "Mesa",
                      "geographicRegionCode": "AZ",
                      "geographicRegionName": "ARIZONA",
                      "addressCategory": "residence"
                    }, {
                      "nameLineOneText": "Albert L. Schmeiser",
                      "addressLineOneText": "Schmeiser Olsen & Watts, LLP",
                      "addressLineTwoText": "18 E. University Dr. # 101",
                      "cityName": "Mesa",
                      "geographicRegionCode": "AZ",
                      "geographicRegionName": "ARIZONA",
                      "countryCode": "US",
                      "countryName": "UNITED STATES",
                      "postalCode": "85201",
                      "addressCategory": "postal"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 1105743288
                },
                "audit": {
                  "lastModifiedUser": "mtwitty",
                  "lastModifiedTime": 1105743288
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 5,
                  "authorityType": "INV",
                  "partyIdentifier": "33489241",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "MicroBlend",
                  "lastName": "Technologies, Inc.(Real Pty. In Interest)",
                  "identifier": "33489241",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "MicroBlend  Technologies, Inc.(Real Pty. In Intere",
                      "cityName": "Gilbert",
                      "geographicRegionCode": "AZ",
                      "geographicRegionName": "ARIZONA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }],
              "applicationType": "REEXAM",
              "artClassNumber": "524",
              "artSubClassNumber": "497000",
              "cpcCodeFirst": null,
              "techCenterNumber": "3900",
              "artUnit": "3991",
              "specialType": "",
              "ptabReceivedDate": null,
              "worker": {
                "workerNumber": "70817",
                "activeIndicator": false,
                "fullName": ""
              },
              "realPartiesDetails": null,
              "appellantsDetails": null,
              "proceedingNumber": "2009001927",
              "proceedingType": null,
              "panelingDisciplineCode": null,
              "panellingDisciplineDescriptionText": null,
              "caseDisciplineCode": null
            },
            "parentInfo": {
              "applicationNumberText": "09785152         ",
              "artClassNumber": "524",
              "artSubClassNumber": "497000",
              "techCenterNumber": "1700",
              "artUnit": "1714",
              "inventors": [{
                "lifeCycle": {
                  "beginDate": 985111169
                },
                "audit": {
                  "lastModifiedUser": "hchristian",
                  "lastModifiedTime": 991828055
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 1,
                  "authorityType": "INV",
                  "partyIdentifier": "26283269",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "John",
                  "middleName": "Michael",
                  "lastName": "Friel",
                  "identifier": "26283269",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "John Michael Friel",
                      "cityName": "Warminister",
                      "geographicRegionCode": "PA",
                      "geographicRegionName": "PENNSYLVANIA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 985111210
                },
                "audit": {
                  "lastModifiedUser": "hchristian",
                  "lastModifiedTime": 991828082
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 2,
                  "authorityType": "INV",
                  "partyIdentifier": "26283275",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "John",
                  "middleName": "William",
                  "lastName": "Hook",
                  "nameSuffix": "III",
                  "identifier": "26283275",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "John William Hook III",
                      "cityName": "Warminister",
                      "geographicRegionCode": "PA",
                      "geographicRegionName": "PENNSYLVANIA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 985111261
                },
                "audit": {
                  "lastModifiedUser": "thaile",
                  "lastModifiedTime": 985111261
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 3,
                  "authorityType": "INV",
                  "partyIdentifier": "26283283",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "Bernhard",
                  "middleName": "Helmut",
                  "lastName": "Lieser",
                  "identifier": "26283283",
                  "citizenship": "DE",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "Bernhard Helmut Lieser",
                      "cityName": "San Pedro",
                      "geographicRegionCode": "CA",
                      "geographicRegionName": "CALIFORNIA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 985111308
                },
                "audit": {
                  "lastModifiedUser": "thaile",
                  "lastModifiedTime": 985111308
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 4,
                  "authorityType": "INV",
                  "partyIdentifier": "26283290",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "Jerry",
                  "middleName": "William",
                  "lastName": "Washel",
                  "identifier": "26283290",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "Jerry William Washel",
                      "cityName": "Harleysville",
                      "geographicRegionCode": "PA",
                      "geographicRegionName": "PENNSYLVANIA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 985111355
                },
                "audit": {
                  "lastModifiedUser": "thaile",
                  "lastModifiedTime": 985111355
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 5,
                  "authorityType": "INV",
                  "partyIdentifier": "26283300",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "Dennis",
                  "middleName": "Paul",
                  "lastName": "Lorah",
                  "identifier": "26283300",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "Dennis Paul Lorah",
                      "cityName": "Lansdale",
                      "geographicRegionCode": "PA",
                      "geographicRegionName": "PENNSYLVANIA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 985111405
                },
                "audit": {
                  "lastModifiedUser": "thaile",
                  "lastModifiedTime": 985111405
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 6,
                  "authorityType": "INV",
                  "partyIdentifier": "26283305",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "Joseph",
                  "middleName": "Michael",
                  "lastName": "Beno",
                  "nameSuffix": "JR.",
                  "identifier": "26283305",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "Joseph Michael Beno JR.",
                      "cityName": "New Hope",
                      "geographicRegionCode": "PA",
                      "geographicRegionName": "PENNSYLVANIA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }, {
                "lifeCycle": {
                  "beginDate": 985111455
                },
                "audit": {
                  "lastModifiedUser": "thaile",
                  "lastModifiedTime": 985111455
                },
                "interestedParty": {
                  "status": "F",
                  "referenceType": "AP",
                  "sequenceNumber": 7,
                  "authorityType": "INV",
                  "partyIdentifier": "26283309",
                  "interestedPartyType": "IND"
                },
                "persons": {
                  "firstName": "Irene",
                  "middleName": "May",
                  "lastName": "Melly",
                  "identifier": "26283309",
                  "citizenship": "US",
                  "address": {
                    "physicalAddress": [{
                      "nameLineOneText": "Irene May Melly",
                      "cityName": "Oreland",
                      "geographicRegionCode": "PA",
                      "geographicRegionName": "PENNSYLVANIA",
                      "addressCategory": "residence"
                    }],
                    "telecommunication": [],
                    "emails": []
                  }
                }
              }],
              "inventionTitleText": "PREPAINTS AND METHODS OF PREPARING PAINTS FROM THE PREPAINTS"
            },
            "corrAddress": {
              "customerNumberText": "23416",
              "nameLineOneText": "POLSINELLI PC",
              "nameLineTwoText": "(DE OFFICE)",
              "streetAddressLineOneText": "1000 Louisiana Street",
              // "streetAddressLineTwoText": "Fifty-Third Floor",
              "cityName": "HOUSTON",
              "geographicRegionName": "TX",
              "postalCode": "77002"
            },
            "thirdPartyInfo": {
              "customerNumber": "23416",
              "nameLineOneText": "Albert L. Schmeiser",
              "nameLineTwoText": "",
              "addressLineOneText": "Schmeiser Olsen & Watts, LLP",
              "addressLineTwoText": "18 E. University Dr. # 101",
              "cityName": "Mesa",
              "geographicRegionCode": "AZ",
              "geographicRegionName": null,
              "postalCode": "85201",
              "worker": {
                "workerNumber": "36715",
                "activeIndicator": false,
                "fullName": "WATKINS, SCOTT"
              }
            },
            "partysInformation": {
              "petitionCounsel": null,
              "petitionRealParty": null,
              "poCounsel": null,
              "poRealParty": null
            },
            "briefHearingTypeCode": "B",
            "caseDisciplineCode": "C",
            "currentStatusCode": "D1R0",
            "receivedDate": 1218513600000,
            "applicationActivityRequest": null,
            "noticeOfAppealDate": null,
            "appealSpecialTypes": null,
            "palmEntryDate": null,
            "palmRecordedDate": null,
            "appellants": [],
            "realParties": [],
            "patentOwners": [],
            "thirdPartyRequestor": [],
            "panelingDisciplineCode": "C",
            "decisions": [],
            "decisionAssignment": null,
            "fileName": null,
            "activeJudges": [{
              "identifier": "91374",
              "panelRank": 1,
              "assignedDate": 1587645214000,
              "panelName": "Abraham, Jeffrey W.",
              "panelSequenceNumber": 2,
              "reConsiderSeqNumber": 0
            }, {
              "identifier": "62756",
              "panelRank": 2,
              "assignedDate": 1587645214000,
              "panelName": "Macdonald, Allen ",
              "panelSequenceNumber": 2,
              "reConsiderSeqNumber": 0
            }, {
              "identifier": "88548",
              "panelRank": 3,
              "assignedDate": 1587645214000,
              "panelName": "Bisk, Jennifer S.",
              "panelSequenceNumber": 2,
              "reConsiderSeqNumber": 0
            }],
            "opsgMetadataList": null,
            "applicationStatus": null,
            "palmStatus": "440",
            "palmStatusDescription": "PTAB Decision - Affirmance",
            "palmStatusCode": "RXBDAF",
            "patentNumber": "6531537",
            "firstInventorToFileIndicator": "N",
            "initials": null,
            "realPartiesInInterest": null,
            "assignedPanel": "Abraham, Jeffrey W., Macdonald, Allen, and Bisk, Jennifer S.",
            "formattedPanel": "JEFFREY W. ABRAHAM, JENNIFER S. BISK, and ALLEN MACDONALD",
            "apj1Name": "JEFFREY W. ABRAHAM",
            "patentAttorney": null,
            "formattedInventors": " 6531537, ROHM AND HAAS COMPANY(OWNER), MICROBLEND TECHNOLOGIES INC.(3RD. PTY. REQ.), ALBERT L. SCHMEISER, and MICROBLEND TECHNOLOGIES, INC.(REAL PTY. IN INTEREST)",
            "applicant": "",
            "assignee": "Rohm and Hass Company",
            "requester": null,
            "patentOwner": null,
            "seniorPartyName": null,
            "juniorPartyName": null,
            "lastNameOfApj1": "ABRAHAM",
            "correspondenceAddress": null,
            "partyAddress": null,
            "fileType": null,
            "rulingCategoryAPj1": "",
            "otherApjs": "ALLEN MACDONALD, JENNIFER S. BISK",
            "result": null,
            "decisionTypeCode": null

          }]
        };
        expect(controller.gettemplateDetails).toBeDefined();
        controller.gettemplateDetails();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
      });


      it('it should call gettemplateDetails and get successResponse', function () {
        successResponse = {
          data: [{
            "descriptionText": ""
          }]
        };
        expect(controller.gettemplateDetails).toBeDefined();
        controller.gettemplateDetails();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
      });


      it('it should call gettemplateDetails failureResponse', function () {
        failureResponse = {
          data: "FAILED"
        };
        expect(controller.gettemplateDetails).toBeDefined();
        controller.gettemplateDetails();
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });


      it('should call documentDownload and get successResponse', function () {
        successResponse = {
          data: [{
            "fileName": "Ex_Parte_Reexam_Template.docx",
            "ptabDefaultRefreshTime": 300000,
            "ptabReadOnlyUser": false,
            "ptabDueDateNonEditableUser": false,
            "fileContent": ""
          }]
        }
        scope.postDataResponse = "";
        scope.template = "add";
        scope.disableGen = true;
        scope.isLoading = true;
        var downloadDocInfo = {
          "fileType": "",
          "formattedInventors": "formattedInventors",
          "palmStatus": "palmStatus",
          "assignee": "assignee",
          "assignedPanel": "assignedPanel",
          "lastNameOfApj1": "apj1Name",
          "realPartiesInInterest": "realPartiesInInterest",
          "firstInventorToFileIndicator": "firstInventorToFileIndicator",
          "formattedPanel": "formattedPanel",
          "patentAttorney": "patentAttorney",
          "serialNumber": "applicationNumber",
          "appealNumber": "caseNumber",
          "documentCategory": "DECISION_TEMPLATES",
          "descriptiveInfo": {
            "techCenterNumber": 12
          },
          "parentInfo": {
            "techCenterNumber": 123,
            "inventionTitleText": ""
          },
          "corrAddress": {
            "customerNumberText": "customerNumberText",
            "nameLineOneText": "nameLineOneText",
            "nameLineTwoText": "nameLineTwoText",
            "streetAddressLineOneText": "lineOneText",
            "streetAddressLineTwoText": "lineTextTwo",
            "cityName": "cityName",
            "geographicRegionName": "regionName",
            "postalCode": "postalCode"
          },

          "partysInformation": "partysInformation",
          "appellants": "appellants",
          "applicant": "applicant",
          "realParties": "realParties",
          "patentOwners": "patentOwners"
        };
        expect(scope.documentDownload).toBeDefined();
        // scope.getDocument('data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,' + scope.postDataResponse)
        // expect(scope.getDocument).toBeDefined();
        scope.documentDownload(downloadDocInfo);
        // HttpFactoryDeferred.resolve(successResponse);
        // scope.$digest();
      });



      it('should call documentDownload and get failure response', function () {
        failureResponse = {
          data: [{}]
        };
        scope.template = "reg";
        scope.disableGen = false;
        scope.isLoading = false;
        var downloadDocInfo = {
          "fileType": "a",
          "formattedInventors": "formattedInventors",
          "palmStatus": "palmStatus",
          "assignee": "assignee",
          "assignedPanel": "assignedPanel",
          "lastNameOfApj1": "apj1Name",
          "realPartiesInInterest": "realPartiesInInterest",
          "firstInventorToFileIndicator": "firstInventorToFileIndicator",
          "formattedPanel": "formattedPanel",
          "patentAttorney": "patentAttorney",
          "serialNumber": "applicationNumber",
          "appealNumber": "caseNumber",
          "documentCategory": "DECISION_TEMPLATES",
          "descriptiveInfo": {
            "techCenterNumber": 12,
            "inventors": "ssddd",
            "applicationType": "A"
          },
          "parentInfo": {
            "techCenterNumber": 123,
            "inventionTitleText": ""
          },
          "corrAddress": {
            "customerNumberText": "customerNumberText",
            "nameLineOneText": "nameLineOneText",
            "nameLineTwoText": "nameLineTwoText",
            "streetAddressLineOneText": "lineOneText",
            "streetAddressLineTwoText": "lineTextTwo",
            "cityName": "cityName",
            "geographicRegionName": "regionName",
            "postalCode": "postalCode"
          },

          "partysInformation": "partysInformation",
          "appellants": "appellants",
          "applicant": "applicant",
          "realParties": "realParties",
          "patentOwners": "patentOwners"
        };

        expect(scope.documentDownload).toBeDefined();
        scope.documentDownload(downloadDocInfo);
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });

      it('should call documentDownload, test if and get failure response', function () {
        failureResponse = {
          data: [{}]
        };
        scope.template = "select template";
        scope.disableGen = false;
        scope.isLoading = false;
        var downloadDocInfo = {
          "fileType": "a",
          "formattedInventors": "formattedInventors",
          "palmStatus": "palmStatus",
          "assignee": "assignee",
          "assignedPanel": "assignedPanel",
          "lastNameOfApj1": "apj1Name",
          "realPartiesInInterest": "realPartiesInInterest",
          "firstInventorToFileIndicator": "firstInventorToFileIndicator",
          "formattedPanel": "formattedPanel",
          "patentAttorney": "patentAttorney",
          "serialNumber": "applicationNumber",
          "appealNumber": "caseNumber",
          "documentCategory": "DECISION_TEMPLATES",
          "descriptiveInfo": {
            "techCenterNumber": 12,
            "inventors": "ssddd",
            "applicationType": "A"
          },
          "parentInfo": {
            "techCenterNumber": 123,
            "inventionTitleText": ""
          },
          "corrAddress": {
            "customerNumberText": "customerNumberText",
            "nameLineOneText": "nameLineOneText",
            "nameLineTwoText": "nameLineTwoText",
            "streetAddressLineOneText": "lineOneText",
            "streetAddressLineTwoText": "lineTextTwo",
            "cityName": "cityName",
            "geographicRegionName": "regionName",
            "postalCode": "postalCode"
          },

          "partysInformation": "partysInformation",
          "appellants": "appellants",
          "applicant": "applicant",
          "realParties": "realParties",
          "patentOwners": "patentOwners"
        };

        expect(scope.documentDownload).toBeDefined();
        scope.documentDownload(downloadDocInfo);
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });


    });
  });
})();
