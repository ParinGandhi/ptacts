'use strict';

angular.module('adf.widget.viewCaseDockets', ['adf.provider', 'ui.grid', 'ngSanitize'])
  .config(function (dashboardProvider) {
    dashboardProvider
      .widget('viewCaseDockets', {
        title: 'View Case Dockets',
        description: 'Abaility to view case dockets',
        templateUrl: '{widgetsPath}/viewCaseDockets/src/view.html',
        edit: {
          templateUrl: '{widgetsPath}/viewCaseDockets/src/edit.html'
        }
      });
  }).directive('viewcasedocketsView', function () {
    return {
      restirct: 'E',
      templateUrl: 'app/components/widgets/viewCaseDockets/src/viewcasedocketsView.html',
      bindToController: true
    };
  }).filter('splitkeydate', function ($sce) {
    return function (input) {
      var htmlString = "";
      angular.forEach(input, function (keyDate) {
        htmlString += keyDate + "\n";
      });
      return $sce.trustAsHtml(htmlString);
    };
  }).controller('ViewCaseDocketController', function (ngDialog, $scope, $timeout, $filter, i18nService, $rootScope,
    uiGridConstants, SearchHelperService, HttpFactory, CONSTANTS, $window, $log, CommonHelperService) {


    /* istanbul ignore next  */
    $rootScope.$on('broadcastZoneWidth', function (event, param) {
      if ($scope.$parent.model) {
        if ($scope.$parent.model.widgetIdentifier === param.widgetIdentifier) {
          $scope.setWidgetZone(param.zoneWidth);
        }
      }
    });
    $scope.isJudge = $rootScope.userInfo.roleDescription ? $rootScope.userInfo.roleDescription.toUpperCase().indexOf('JUDGE') > -1 ? true : false : false;
    getAIATrialsURL();
    var scope = angular.element(document.getElementById('mainTabId')).scope();
    $scope.setWidgetZone = function (zoneWidth) {
      if (angular.isUndefined(zoneWidth)) {
        scope.vm.getWidgetZone($scope.$parent.$parent.$parent.definition);
        $scope.zoneWidth = $scope.$parent.$parent.$parent.definition.zoneWidth;
      } else {
        $scope.zoneWidth = zoneWidth;
      }
      $log.debug("View case docket zone width: " + $scope.zoneWidth);
    };
    $scope.setWidgetZone();
    $scope.customData = [];
    $scope.selectUnselect = true;
    $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
    $scope.loadedColumns = false;
    var isViewCaseDocket = true;
    var isFilterChanged = false;
    var isColumnVisibilityChanged = false;
    var isColumnPinnedChanged = false;
    var isColumnSizeChanged = false;
    var isSortChanged = false;
    var isColumnPositionChanged = false;
    var isPaginationChanged = false;
    var initialLoad = true;
    // var heightMultiplier = 73;
    $scope.preferencesChanged = false;
    $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
    $scope.gridRefreshMsg = CONSTANTS.MESSAGES.GRID_REFRESH;
    $rootScope.viewCaseColumnsChanged = false;
    $scope.userName = $rootScope.userInfo.userId;
    $scope.isTrials = true;
    $scope.disableHierarchy = false;
    /* istanbul ignore next*/
    function clearMulti() {
      var i;
      var select = document.getElementById('availableColsId');
      for (i = 0; i < select.options.length; i++) {
        select.options[i].selected = false;
      }
    }

    var aiaTrialsLink;
    function getAIATrialsURL() {
      HttpFactory.getActions(CONSTANTS.URL.AIA_URLS)
      .then(function (successResponse) {
        angular.forEach(successResponse.data, function(row) {
          if (row.valueText==="CASE_VIEWER") {
            aiaTrialsLink = row.descriptionText;
          }
        });
      }, function (failureResponse) {

      });
    }

    /* istanbul ignore next  */
    function resetUnsavedChangesFlags() {
      isFilterChanged = false;
      isColumnVisibilityChanged = false;
      isColumnPinnedChanged = false;
      isColumnSizeChanged = false;
      isSortChanged = false;
      isColumnPositionChanged = false;
      isPaginationChanged = false;
      $scope.preferencesChanged = false;
      $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
      $scope.vcdListOrderChanged = false;
    }
    /* istanbul ignore if  */
    if (angular.isDefined($scope.$parent.model)) {
      $scope.VCDdataUrl = $scope.$parent.model.dataUrlText;
      $scope.widgetIdentifier = $scope.$parent.model.widgetIdentifier;
    } else {
      $scope.VCDdataUrl = $scope.definition.dataUrlText;
      $scope.widgetIdentifier = $scope.definition.widgetIdentifier;
    }
    $log.debug("View case docket data url: " + $scope.VCDdataUrl);
    $log.debug("View case docket widget identifier: " + $scope.widgetIdentifier);
    /* istanbul ignore next*/
    $scope.getViewCaseDocketColumns = function () {
      if (isViewCaseDocket || $scope.definition.type === 'viewCaseDockets') {
        isViewCaseDocket = false;
        HttpFactory.getActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS + $scope.widgetIdentifier)
          .then(function (successResponse) {
            $scope.selectedColumns = successResponse.data.selectedColumns;
            $scope.selectedCols = [];
            $scope.availableCols = [];
            angular.forEach($scope.selectedColumns, function (thisColumn) {
              if (thisColumn.visible) {
                $scope.selectedCols.push(thisColumn);
              } else {
                $scope.availableCols.push(thisColumn);
              }
            });
            $log.debug('Selected:');
            $log.debug($scope.selectedCols);
            $log.debug('Available: ');
            $log.debug($scope.availableCols);
            $scope.originShowHide = angular.copy($scope.selectedColumns);
            $scope.viewCaseAvailableCols = angular.copy($scope.selectedCols);
            $scope.loadedColumns = true;
            for (var i = 0; i < $scope.selectedColumns.length; i++) {
              if (!$scope.selectedColumns[i].visible) {
                $scope.selectUnselect = false;
                $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
              }
            }
            $log.debug("View case docket (" + $scope.widgetIdentifier + ") getViewCaseDocketColumns success response: ");
            $log.debug(successResponse);
          }, function (failureResponse) {
            $log.debug("View case docket (" + $scope.widgetIdentifier + ") getViewCaseDocketColumns failure response: ");
            $log.debug(failureResponse);
          });
      }
    };

    $scope.getViewCaseDocketColumns();
    /* istanbul ignore next*/
    $scope.gridOptions = {
      enableGridMenu: true,
      enableSelectAll: true,
      useExternalFiltering: true,
      exporterCsvFilename: 'ViewCaseDocket_' + CommonHelperService.getCurrentTime() + '.csv',
      exporterOlderExcelCompatibility: true,
      exporterMenuExcel: false,
      exporterMenuPdf: false,
      gridMenuShowHideColumns: true,
      enableFiltering: true,
      paginationPageSizes: [10, 25, 50, 100],
      enableHorizontalScrollbar: uiGridConstants.scrollbars.WHEN_NEEDED,
      gridMenuCustomItems: [{
          title: 'Save grid preferences',
          action: function () {
            $scope.saveGridPreferences();
          },
          order: 100
        }, {
          title: 'Show hidden filters',
          action: function () {
            showHiddenFilteredColumns();
          },
          order: 190
        }, {
          title: 'Export full docket as csv',
          action: function () {
            $scope.exportData();
          },
          order: 210
        },
        {
          title: 'Mandatory columns',
          order: 220
        },
        {
          title: 'Case #',
          icon: 'fas fa-check',
          order: 224
        }
      ],
      onRegisterApi: function (gridApi) {
        $scope.gridApi = gridApi;
        $scope.gridApi.core.on.filterChanged($scope, function () {
          isFilterChanged = true;
          var grid = this.grid;
          $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
          if ($scope.numberOfFilters === 0) {
            $scope.gridOptions.data = $scope.myData.caseDetailsData;
          } else {
            var filteredData = SearchHelperService.filterGrid(grid, $scope.myData);
            $scope.gridOptions.data = filteredData;
            $log.debug("View case docket (" + $scope.widgetIdentifier + ") filtered data: ");
            $log.debug(filteredData);
          }
          checkForUnsavedChanges();
        });
        $scope.gridApi.core.on.columnVisibilityChanged($scope, function () {
          isColumnVisibilityChanged = true;
          updateColumnDefs($scope.gridOptions.columnDefs);
          checkForUnsavedChanges();
        });
        $scope.gridApi.pinning.on.columnPinned($scope, function () {
          isColumnPinnedChanged = true;
          updateColumnDefs($scope.gridOptions.columnDefs);
          checkForUnsavedChanges();
        });
        $scope.gridApi.colResizable.on.columnSizeChanged($scope, function () {
          isColumnSizeChanged = true;
          checkForUnsavedChanges();
        });
        $scope.gridApi.core.on.sortChanged($scope, function () {
          isSortChanged = true;
          checkForUnsavedChanges();
        });
        $scope.gridApi.colMovable.on.columnPositionChanged($scope, function () {
          isColumnPositionChanged = true;
          checkForUnsavedChanges();
        });
        $scope.gridApi.pagination.on.paginationChanged($scope, function () {
          isPaginationChanged = true;
          checkForUnsavedChanges();
        });
        $scope.gridApi.core.on.renderingComplete($scope, function () {
          $scope.gridResize();
          checkForUnsavedChanges();
        });
        $scope.gridApi.selection.on.rowSelectionChanged($scope, function (row) {
          $scope.selectedRows = $scope.gridApi.selection.getSelectedRows();
          if ($scope.selectedRows[0].PROCEEDING_NO.match(/[a-z]/i)) {
            $scope.isTrials = true;
          } else {
            $scope.isTrials = false;
          }
        });
      }

    };


    $scope.validateTeamLead = function () {
      HttpFactory.getActions(CONSTANTS.URL.VALIDATETEAMLEAD + "userId=" + $rootScope.userInfo.userId)
        .then(function (successResponse) {
          $scope.disableHierarchy = successResponse.data;
        }, function (failureResponse) {
          console.info(failureResponse);
        });
    };
    $scope.validateTeamLead();

    /* istanbul ignore next  */
    function showHiddenFilteredColumns() {
      var hiddenFilteredColumns = SearchHelperService.hasHiddenColumnFilters($scope.gridApi.grid.columns);

      angular.forEach(hiddenFilteredColumns, function (column) {
        column.showColumn();
        $scope.preferencesChanged = true;
      });
      $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
    }

    /* istanbul ignore next  */
    function convertArrayToString(value) {
      var arrayString = "";
      angular.forEach(value.slice(0, 3), function (eachItem) {
        arrayString += eachItem + " ";
      });
      return arrayString;
    }
    /* istanbul ignore next*/
    $scope.gridOptions.exporterFieldCallback = function (grid, row, col, value) {
      $scope.gridOptions.exporterCsvFilename = 'ViewCaseDocket_' + CommonHelperService.getCurrentTime() + '.csv';
      if (col.colDef.type === 'string') {
        if (col.colDef.field === 'ALL_DISPOSITION_TX') {
          if (angular.isDefined(value)) {
            if (value[0] === "") {
              value = "";
            } else {
              value = convertArrayToString(value);
            }
          }
        }
      }
      if (col.colDef.type === 'string') {
        if (col.colDef.displayName === 'Panel') {
          return setPanelColumnForExport(row.entity);
        }
      }
      if (col.colDef.type === 'date') {
        if (col.colDef.field === 'LAST_MODIFIED_TS') {
          value = $filter('date')(value, 'MM/dd/yyyy hh:mm:ss a');
        } else {
          value = $filter('date')(value, 'MM/dd/yyyy');
        }
        if (!value) {
          value = "";
        } else {
          value = " " + value;
        }
      }
      if (col.colDef.field === "DECISION_DUE_DAYS") {
        value = "";
      }
      return value;
    };
    /* istanbul ignore next*/
    $scope.gridResize = function () {
      var gridHeight = document.getElementsByClassName('grid');
      for (var i = 0; i < gridHeight.length; i++) {
        if ($scope.$parent.model) {
          if ($scope.$parent.model.widgetIdentifier === $scope.widgetIdentifier) {
            if ($scope.$parent.model.height === 'widgetHeightSmall') {
              gridHeight[i].style.height = '223px';
            } else if ($scope.$parent.model.height === 'widgetHeightMedium') {
              gridHeight[i].style.height = '565px';
            } else if ($scope.$parent.model.height === 'widgetHeightLarge') {
              gridHeight[i].style.height = '915px';
            } else if ($scope.$parent.model.height === 'widgetHeightXlarge') {
              gridHeight[i].style.height = '1615px';
            }
          }
        }
      }
    };

    var originalColumnDefs;
    /* istanbul ignore next  */
    function updateColumnDefs(columndefs) {
      var selected = [];
      var unselected = [];
      var selectedCount = 0;

      angular.forEach(columndefs, function (col) {
        if (col.visible) {
          selected.push(col);
          selectedCount = selectedCount + 1;
        } else {
          unselected.push(col);
        }
      });

      columndefs = [];
      angular.forEach(selected, function (col) {
        columndefs.push(col);
      });
      unselected.sort(CommonHelperService.alphabetizeAvailableColumns);
      angular.forEach(unselected, function (col) {
        columndefs.push(col);
      });

      $scope.gridOptions.rowHeight = 70;

      for (var i = 0; i < columndefs.length; i++) {
        if (columndefs[i].field === "ALL_DISPOSITION_TX" && columndefs[i].visible === true) {
          $scope.gridOptions.rowHeight = 70;
          break;
        }
      }

      originalColumnDefs = angular.copy(columndefs);

      $scope.gridOptions.columnDefs = buildCaseAlerts(columndefs);
    }


    function buildCaseAlerts(columndefs) {
      angular.forEach(columndefs, function (col) {
        if (col.displayName === 'Alerts') {
          col = CommonHelperService.addAlertFilters(col, 'View case dockets');
        }
      });
      return columndefs;
    }


    $scope.gridState = {};
    /* istanbul ignore next  */
    $scope.saveState = function () {
      $scope.saveGridPreferences();
    };

    /* istanbul ignore next  */
    $scope.restoreState = function () {
      $scope.gridApi.saveState.restore($scope, $scope.gridState);
      $log.debug("View case docket (" + $scope.widgetIdentifier + ") restore state: ");
      $log.debug(angular.toJson($scope.gridState.columns));
    };


    $scope.showFilters = false;
    $scope.noRecordsFound = false;

    $scope.openCaseViewer = function (row) {
      $window.open("#/caseViewer/" + row.entity.PROCEEDING_CORE_ID + "/" + row.entity.PROCEEDING_SUPPLEMENTARY_ID);
    };

    $scope.openCaseViewerwithAppeal = function (row) {
      $window.open("#/caseViewer/" + row.entity.PROCEEDING_CORE_ID + "/" + row.entity.PROCEEDING_NO);
    };

    $scope.openCaseViewerwithTrials = function (row) {

      if (aiaTrialsLink) {
        if (aiaTrialsLink.indexOf('caseViewer')>0 && row.entity.PROCEEDING_NO.match(/[D]/i) && row.entity.REDIRECT_URL != null) {
          CommonHelperService.getRedirectUrl(row.entity.REDIRECT_URL);
        } else {
          if (aiaTrialsLink.indexOf('caseViewer')>0 && event.ctrlKey && row.entity.REDIRECT_URL != null) {
            CommonHelperService.getRedirectUrl(row.entity.REDIRECT_URL);
          } else {
            $window.open(aiaTrialsLink.trim() + row.entity.PROCEEDING_CORE_ID + "/" + row.entity.PROCEEDING_NO + "/documents");
          }
        }
      }
    };

    $scope.setUrl = function (selectedView) {
      $scope.currentView = selectedView;
      var url;
      switch (selectedView) {
        case 'myDocket':
          url = CONSTANTS.URL.VIEWCASE_MY_DOCKET  + $scope.widgetIdentifier + "&userName=" + $scope.userName;
          break;
        case 'teamDocket':
          url = CONSTANTS.URL.VIEWCASE_MY_TEAM + $scope.widgetIdentifier;
          break;
          case 'groupDocket':
              url = CONSTANTS.URL.VIEWCASE_MY_GROUP + $scope.widgetIdentifier;
            break;
        default:
          break;
      }
      $timeout(function () {
        $scope.preferencesChanged = false;
      }, 4000);
   
      $scope.getViewCaseDocketData(url);
    };


    /* istanbul ignore next*/
    $scope.getViewCaseDocketData = function (url) {
      $scope.isLoading = true;
      $scope.gearLoading = false;
      HttpFactory.getActions(url)
        // $http.get('assets/vcd.json')
        .then(function (successResponse) {
            $scope.laterSelected = [];
            $scope.enableloading = false;
            $scope.refreshFailed = false;
            $scope.dateValid = false;
            $scope.refreshDate = new Date();
            $scope.isInColumnDetails = false;
            if (angular.isDefined(successResponse.data[0])) {
              if ($scope.isJudge) {
                $scope.customData = successResponse.data[0].customData;
                if ($scope.customData.length > 0) {
                  $scope.customData.forEach(function (data) {
                    var isColumnDetails = false;
                    if (data.columnName) {
                      if (data.columnName.length > 0) {
                        successResponse.data[0].columnDetails.forEach(function (element) {
                            if (!isColumnDetails && element.columnName[0] == data.columnName[0]) {
                              element.columnLabel = data.columnLabel;
                              element.columnName = data.columnName;
                              $scope.isInColumnDetails = true;
                              isColumnDetails = true;

                            }
                            //   else {
                            //    $scope.laterSelected.push(element);
                            // }
                          }

                        );
                        $scope.selectedColumns.forEach(function (selctedData) {
                          if (selctedData.columnName) {
                            if (selctedData.columnName.length > 0) {

                              if (data.columnName[0] == selctedData.columnName[0]) {
                                selctedData.columnLabel = data.columnLabel;
                                selctedData.columnName = data.columnName;
                                //  $scope.isInColumnDetails = true;
                              }

                            }
                          }

                        });
                        if (!isColumnDetails) {
                          $scope.laterSelected.push(data);
                        }

                      }
                    }

                  });

                }
                if ($scope.laterSelected.length > 0) {
                  $scope.laterSelected.forEach(function (ele) {
                    successResponse.data[0].columnDetails.push(ele);
                    $scope.selectedColumns.push(ele);
                  });
                }


              }
              // if ($scope.customData.length > 0 && !$scope.isInColumnDetails && $scope.isJudge) {
              //   $scope.customData.forEach(function (element, i) {
              //     successResponse.data[0].columnDetails.push(element);
              //           $scope.selectedColumns.push(element);



              //   })
              // }
              $scope.myData = successResponse.data[0];
              $scope.caseDetailsDataViewCaseDoc = $scope.myData.caseDetailsData;
              $scope.updatedColumnList = successResponse.data[0].columnDetails;
              var setColumnsResponse = CommonHelperService.setColumnDefinitions($scope.myData.columnDetails);
              //setColumnsResponse.colDefs[3].cellTemplate =  "app/components/widgets/viewCaseDockets/src/panel.html";

              var hasFilterFlag = setColumnsResponse.filterCount;

              updateColumnDefs(setColumnsResponse.colDefs);
              $scope.gridOptions.paginationPageSize = $scope.myData.paginationSize;
              $scope.gridOptions.data = CommonHelperService.setGridData(hasFilterFlag, $scope.myData.caseDetailsData, setColumnsResponse.colDefs);
              if (hasFilterFlag > 0) {

                $scope.numberOfFilters = hasFilterFlag;

                var filteredData = SearchHelperService.filterTable($scope.myData, setColumnsResponse.colDefs);
                $scope.gridOptions.data = filteredData;
              } else {
                $scope.numberOfFilters = 0;
                $scope.gridOptions.data = $scope.myData.caseDetailsData;
              }

              $timeout($scope.setPaginationManually, 700);
              $scope.noRecordsFound = true;
              $timeout(function () {
                initialLoad = false;
              }, 2000);


            }
            $log.debug("View case docket (" + $scope.widgetIdentifier + ") getViewCaseDocketData success response: ");
            $log.debug(successResponse);

            $scope.gridOptions.paginationPageSize = $scope.gridOptions.data.length;
            $scope.gridResize();
          },
          function (failureResponse) {
            $log.debug("View case docket (" + $scope.widgetIdentifier + ") getViewCaseDocketData failure response: ");
            $log.debug(failureResponse);
            /* istanbul ignore if: toaster error  */
            if (failureResponse.status === 404) {
              $scope.enableloading = false;
              $scope.refreshFailed = false;
              $scope.dateValid = false;
              $scope.refreshDate = new Date();
              CommonHelperService.setToastr(failureResponse.data.message, "info");
              $scope.noRecordsFound = true;
            } else {
              $scope.refreshFailed = true;
              $scope.refreshFailedate = new Date();
              $scope.enableloading = false;
              if (angular.isUndefined($scope.refreshDate) || $scope.refreshDate === null) {
                $scope.dateValid = true;
              }
            }
          }).finally(function () {
          $scope.isLoading = false;
        });
    };

    $scope.setUrl('myDocket');

    $scope.toggleFiltering = function () {

      if (angular.isDefined($scope.gridApi)) {
        $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
      }

      $scope.gridApi.grid.clearAllFilters();
      $scope.gridOptions.data = $scope.myData.caseDetailsData;
      $scope.numberOfFilters = 0;
    };

    $scope.showFilteringHelp = function () {
      ngDialog.open({
        template: 'app/components/helperComponents/filterHelp/filteringHelp.html',
        controller: 'CommonDialogController',
        controllerAs: 'vm',
        width: "54%",
        showClose: false
      });
    };

    $scope.sortableOptions = {
      containment: '#docketColums',
      scroll: true,
      axis: 'y',
      cursor: 'move',
      scrollSpeed: 2,
      scrollSensitivity: 160,
      update: function () {
        $rootScope.viewCaseColumnsChanged = true;
      }
    };

    /* istanbul ignore next  */
    $scope.updateColumns = function () {
      var loadingWidget = document.getElementById($scope.widgetIdentifier);
      loadingWidget.style.display = "inline-block";
      var docketScopeList = angular.element(document.getElementById('docketColums')).scope();
      var columnsSelected = [];
      var fromModal = false;
      if (angular.isDefined(docketScopeList)) {
        columnsSelected = angular.copy(docketScopeList.selectedCols);
        angular.forEach(docketScopeList.availableCols, function (available) {
          columnsSelected.push(available);
        });
        fromModal = true;
      } else {
        columnsSelected = $scope.selectedColumns;
      }

      var updatedColumns = CommonHelperService.setColumnsToUpdate(columnsSelected, fromModal, $scope.gridState, $scope.widgetIdentifier);

      if (angular.isDefined(docketScopeList)) {
        docketScopeList.originShowHide = angular.copy(updatedColumns.selectedColumns);
      }

      HttpFactory.putActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS, updatedColumns)
        .then(function (successResponse) {
            // CommonHelperService.setToastr("Grid preferences saved successfully", "success");
            // resetUnsavedChangesFlags();
            // var newData = successResponse.data[0];
            // $scope.updatedColumnList = newData.columnDetails;

            // var setColumnsResponse = CommonHelperService.setColumnDefinitions($scope.updatedColumnList);
            // var hasFilterFlag = setColumnsResponse.filterCount;

            // $scope.numberOfFilters = hasFilterFlag;
            // if (fromModal) {
            //   var allGrids = document.getElementsByClassName('ui-grid');
            //   for (var j = 0; j < allGrids.length; j++) {
            //     if (angular.element(allGrids[j]).scope().widgetIdentifier === $scope.widgetIdentifier) {
            //       updateColumnDefs(setColumnsResponse.colDefs);

            //       angular.element(allGrids[j]).scope().gridOptions.rowHeight = $scope.gridOptions.rowHeight;
            //       angular.element(allGrids[j]).scope().gridOptions.columnDefs = $scope.gridOptions.columnDefs;
            //       if ($scope.numberOfFilters > 0) {
            //         var filteredData = SearchHelperService.filterTable($scope.myData, setColumnsResponse.colDefs);
            //         angular.element(allGrids[j]).scope().gridOptions.data = filteredData;
            //       } else {
            //         angular.element(allGrids[j]).scope().gridOptions.data = successResponse.data[0].caseDetailsData;
            //       }
            //       break;
            //     }
            //   }
            //   $rootScope.viewCaseColumnsChanged = false;
            // } else {
            //   updateColumnDefs(setColumnsResponse.colDefs);

            //   $scope.gridOptions.data = CommonHelperService.setGridData(hasFilterFlag, newData.caseDetailsData, setColumnsResponse.colDefs);
            // }

            // $scope.noRecordsFound = true;
            resetUnsavedChangesFlags();
            $scope.noRecordsFound = true;
            $scope.setUrl($scope.currentView);
          },
          function () {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.gridSaveFail, "error");
          }).finally(function () {

          // console.log($scope.widgetIdentifier);
          // var gridLoaders = document.getElementsByTagName("grid-loader");
          // for (var i = 0; i < gridLoaders.length; i++) {
          //   gridLoaders[i].style.display = "none";
          // }

          // var vcdScope = angular.element(document.getElementById('customid')).scope();


          loadingWidget.style.display = "none";
          // loadingWidget

          console.dir($scope);
          $scope.gearLoading = false;
          $scope.isLoading = false;
          $scope.$$prevSibling.isLoading = false;
          $scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.isLoading = false;
        });
    };

    $scope.moveItem = function (origin, destination) {
      var temp = $scope.selectedCols[destination];
      $log.debug("Initial");
      $log.debug($scope.selectedCols);
      $scope.selectedCols[destination] = $scope.selectedCols[origin];
      $log.debug("Origin moved to destination");
      $log.debug($scope.selectedCols);
      $scope.selectedCols[origin] = temp;
      $log.debug("Final");
      $log.debug($scope.selectedCols);
      $scope.vcdListOrderChanged = true;
      $rootScope.viewCaseColumnsChanged = true;
    };

    $scope.listItemUp = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex - 1);
    };

    $scope.listItemDown = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex + 1);
    };
    /* istanbul ignore next*/
    $scope.moveSourcetoDestination = function () {

      angular.forEach($scope.clickedColumn, function (column) {
        column.visible = true;
        $scope.selectedCols.push($scope.availableCols[$scope.availableCols.indexOf(column)]);
        $scope.availableCols.splice($scope.availableCols.indexOf(column), 1);
      });

      $scope.clickedColumn = [];
      $rootScope.viewCaseColumnsChanged = true;
      clearMulti();
    };
    $scope.ext = [];
    $scope.enableMoveButton = false;

    $scope.clickedColumn = [];
    /* istanbul ignore next*/
    $scope.requestData = function (event, Selected) {
      $scope.enableMoveButton = true;
      if (event.ctrlKey || event.shiftKey) {
        $scope.clickedColumn.push(Selected);
      } else {
        $scope.clickedColumn = [];
        $scope.clickedColumn.push(Selected);
      }
    };
    $scope.moveSourcetoDestinationData = function (source, destination) {
      if ($scope.ext.length !== 0) {

        for (var i = 0; i < $scope.ext.length; i++) {

          source.splice(source.indexOf($scope.ext[i]), 1);
          if (!$scope.ext[i].visible) {
            $scope.ext[i].visible = true;
            destination.push($scope.ext[i]);
          }
        }

      } else {
        source.splice(source.indexOf($scope.newColumn), 1);
        if (!$scope.newColumn.visible) {
          $scope.newColumn.visible = true;
          destination.push($scope.newColumn);
        }
      }
      $scope.enableMoveButton = false;
      $scope.ext = [];
    };

    $scope.moveSourcetoDestinationCancel = function (index) {
      $scope.selectedCols[index].visible = false;
      $scope.availableCols.push($scope.selectedCols[index]);
      $scope.selectedCols.splice(index, 1);
      $rootScope.viewCaseColumnsChanged = true;
    };

    /* istanbul ignore next  */
    $scope.exportData = function () {
      var headers = [];
      angular.forEach($scope.updatedColumnList, function (coldata) {
        headers.push(coldata.columnLabel);
      });
      var fields = [];
      angular.forEach($scope.updatedColumnList, function (coldata) {

        if (coldata.columnName[0] === 'FK_ASSIGNEE_BE_NO') {
          fields.push([coldata.columnName[1], coldata.columnType]);
        } else {
          fields.push([coldata.columnName[0], coldata.columnType]);
        }
      });
      var replacer = function (key, value) {
        return value === null ? '' : value;
      };
      var csv = $scope.caseDetailsDataViewCaseDoc.map(function (row) {
        return fields.map(function (fieldName) {
          if (fieldName[1] === 'date') {
            if (row[fieldName[0]] === null) {
              return "";
            }
            if (fieldName[0] === 'LAST_MODIFIED_TS') {
              return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy hh:mm:ss a') + " ";
            } else {
              return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy') + " ";
            }
          } else if (fieldName[1] === 'string') {
            if (fieldName[0] === 'ALL_DISPOSITION_TX') {
              if (row.hasOwnProperty('ALL_DISPOSITION_TX')) {
                if (row[fieldName[0]] === "") {
                  return "";
                } else {
                  return JSON.stringify(convertArrayToString(row[fieldName[0]]), replacer);
                }
              } else {
                return "";
              }

            } else if (fieldName[0] === "ADDITIONAL_APJ_WORKER_ID_TX") {
              return JSON.stringify(setPanelColumnForExport(row));
            } else if (fieldName[0] === "DECISION_DUE_DAYS") {
              return "";
            } else {
              return JSON.stringify(row[fieldName[0]], replacer);
            }
          } else {
            return JSON.stringify(row[fieldName[0]], replacer);
          }
        }).join(',');
      });
      csv.unshift(headers.join(','));
      csv = csv.join('\r\n');
      var hiddenElement = document.createElement('a');
      hiddenElement.href = URL.createObjectURL(new Blob([csv], {
        type: 'text/csv'
      }));
      hiddenElement.target = '_blank';
      hiddenElement.download = 'ViewCaseDocket_FullDocket_' + CommonHelperService.getCurrentTime() + '.csv';
      hiddenElement.click();
    };

    function setPanelColumnForExport(row) {
      var judgePanel = "";
      if (row.APJ1_WORKER_ID.trim() !== "") {
        judgePanel += row.APJ1_WORKER_ID.trim();
      }
      if (row.ATTORNEY_WORKER_ID.trim() !== "") {
        judgePanel += ' (' + row.ATTORNEY_WORKER_ID.trim() + ')';
      }
      if (row.APJ2_WORKER_ID.trim() !== "") {
        judgePanel += ' | ' + row.APJ2_WORKER_ID.trim();
      }
      if (row.APJ3_WORKER_ID.trim() !== "") {
        judgePanel += ' | ' + row.APJ3_WORKER_ID.trim();
      }
      if (row.APJ4_WORKER_ID.trim() !== "") {
        judgePanel += ' | ' + row.APJ4_WORKER_ID.trim();
      }
      if (row.APJ5_WORKER_ID.trim() !== "") {
        judgePanel += ' | ' + row.APJ5_WORKER_ID.trim();
      }
      if (row.APJ6_WORKER_ID.trim() !== "") {
        judgePanel += ' | ' + row.APJ6_WORKER_ID.trim();
      }
      if (row.APJ7_WORKER_ID.trim() !== "") {
        judgePanel += ' | ' + row.APJ7_WORKER_ID.trim();
      }
      if (row.APJ8_WORKER_ID.trim() !== "") {
        judgePanel += ' | ' + row.APJ8_WORKER_ID.trim();
      }
      if (row.APJ9_WORKER_ID.trim() !== "") {
        judgePanel += ' | ' + row.APJ9_WORKER_ID.trim();
      }
      return judgePanel;
    }


    i18nService.get('en').gridMenu.exporterAllAsCsv = 'Export filtered data as csv';
    i18nService.get('en').gridMenu.exporterVisibleAsCsv = 'Export this page as csv';
    i18nService.get('en').gridMenu.exporterSelectedAsCsv = 'Export selected as csv';
    /* istanbul ignore next  */
    $scope.saveGridPreferences = function () {
      // $scope.gridState = $scope.gridApi.saveState.save();
      // var widthMap = $scope.gridState.columns.reduce(function (map, col) {

      //   map[col.name] = col;
      //   return map;
      // }, {});
      // $scope.widthMap = widthMap;
      if ($scope.gridApi) {
        $scope.gridState = CommonHelperService.setGridWidthMap($scope.gridApi.saveState.save());
        $scope.isLoading = true;
      } else if ($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi) {
        $scope.gridState = CommonHelperService.setGridWidthMap($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi.saveState.save());
        $scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gearLoading = true;
        $scope.gearLoading = true;
        // $scope.isLoading = true;
      }

      $scope.updateColumns();
    };

    $scope.paginationManual = false;
    $scope.setPaginationManually = function () {
      $scope.paginationManual = false;
    };
    /* istanbul ignore next  */
    $rootScope.$on('adfCustomizeWidgetServiceCall', function () {
      if ($rootScope.widgetIdentifier === $scope.widgetIdentifier) {
        switch ($rootScope.widgetHeight) {
          case "widgetHeightSmall":
            $scope.gridOptions.paginationPageSize = $scope.gridOptions.paginationPageSizes[0];
            // currentGrid.style.height = '223px';
            break;
          case "widgetHeightMedium":
            $scope.gridOptions.paginationPageSize = $scope.gridOptions.paginationPageSizes[1];
            // currentGrid.style.height = '565px';
            break;
          case "widgetHeightLarge":
            $scope.gridOptions.paginationPageSize = $scope.gridOptions.paginationPageSizes[2];
            // currentGrid.style.height = '915px';
            break;
          case "widgetHeightXlarge":
            $scope.gridOptions.paginationPageSize = $scope.gridOptions.paginationPageSizes[3];
            // currentGrid.style.height = '1615px';
            break;
          default:
            break;
        }
        // $timeout($scope.gridResize(), 200);

        // var pageSize = CommonHelperService.setPagination();
        // if (pageSize) {
        //   $scope.gridOptions.paginationPageSize = pageSize;
        // }
        $scope.paginationManual = true;
        $log.debug("Executed after save widget size for View case docket (" + $scope.widgetIdentifier + ")");
        $timeout($scope.setPaginationManually, 500);
      }
    });

    $scope.toggleSelectAll = function () {
      angular.forEach($scope.availableCols, function (column) {
        column.visible = true;
        $scope.selectedCols.push(column);
      });
      $scope.availableCols = [];
      $rootScope.viewCaseColumnsChanged = true;

    };

    $scope.removeAll = function () {
      var tempArray = [];
      $rootScope.viewCaseColumnsChanged = true;
      angular.forEach($scope.selectedCols, function (column) {
        if (!column.mandatory) {
          column.visible = false;
          $scope.availableCols.push(column);
        } else {
          tempArray.push(column);
        }
      });
      $scope.selectedCols = tempArray;
    };

    /* istanbul ignore next  */
    $scope.areAllSelected = function () {
      var columnList = angular.element(document.getElementById('docketColums')).scope();
      for (var i = 0; i < columnList.selectedColumns.length; i++) {
        if (!columnList.selectedColumns[i].visible) {
          $scope.selectUnselect = false;
          break;
        } else {
          $scope.selectUnselect = true;
        }
        $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
      }
    };
    /* istanbul ignore next  */
    function checkForUnsavedChanges() {
      if (!initialLoad) {
        if (isFilterChanged || isColumnVisibilityChanged || isColumnSizeChanged || isSortChanged || isColumnPositionChanged || isPaginationChanged || isColumnPinnedChanged) {
          $scope.preferencesChanged = true;
          $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_PREFERENCES;
        } else {
          $scope.preferencesChanged = false;
          $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
        }
      }

    }

    $scope.refreshViewCaseDocketData = function () {
      $scope.isLoading = true;
      $scope.enableloading = true;
      $scope.refreshFailed = false;
      $scope.refreshDate === undefined || null;
      $scope.preferencesChanged = false;
      $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
      $scope.setUrl($scope.currentView);
    };

    $scope.getKeyDates = function (row) {
      ngDialog.open({
        template: 'app/components/widgets/viewCaseDockets/src/keyDatesModal.html',
        controller: 'KeyDatesModalController',
        width: '20%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,
        resolve: {
          row: function () {
            return row;
          }
        }
      }).closePromise.then(function () {
        // Modal handles services interaction
      }, function () {
        // Empty response is ok
      });
    };
    $scope.panelData = function (row) {
      $scope.panelMembers = [];
      if (angular.isDefined(row.entity.APJ1_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ1_WORKER_ID);
      }
      if (angular.isDefined(row.entity.APJ2_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ2_WORKER_ID);
      }
      if (angular.isDefined(row.entity.APJ3_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ3_WORKER_ID);
      }
      if (angular.isDefined(row.entity.APJ4_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ4_WORKER_ID);
      }
      if (angular.isDefined(row.entity.APJ5_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ5_WORKER_ID);
      }
      if (angular.isDefined(row.entity.APJ6_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ6_WORKER_ID);
      }
      if (angular.isDefined(row.entity.APJ7_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ7_WORKER_ID);
      }
      if (angular.isDefined(row.entity.APJ8_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ8_WORKER_ID);
      }
      if (angular.isDefined(row.entity.APJ9_WORKER_ID)) {
        $scope.panelMembers.push(row.entity.APJ9_WORKER_ID);
      }
    };

    $scope.getTechCenter = function (artUnit) {
      return artUnit.substring(2, 0) + "00";
    };


    $scope.createDecisionDocument = function () {
      $scope.mySelectedRows = angular.copy($scope.gridApi.selection.getSelectedRows());
      ngDialog.open({
        template: 'app/components/widgets/viewCaseDockets/src/createDecisionDoc.html',
        controller: 'CreateDecisionDocController',
        width: '50%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,
        resolve: {
          selectedRows: function () {
            return $scope.mySelectedRows;
          },
          userName: function () {
            return $scope.userName;
          }
        }
      }).closePromise.then(function () {
        // Modal handles services interaction
      }, function () {
        // Empty response is ok
      });
    };

  });
