'use strict';

angular
  .module('adf.widget.announcements', ['adf.provider'])
  .config(
    function (dashboardProvider) {
      dashboardProvider
        .widget(
          'announcements', {
            title: 'Announcements',
            description: 'Read the latest news about your uspto.gov account and get updates on new features as we release them.',
            controller: "announcementController",
            controllerAs: 'vm',
            templateUrl: '{widgetsPath}/announcements/src/view.html',
            edit: {
              templateUrl: '{widgetsPath}/announcements/src/edit.html'
            }
          });
    })
  .controller(
    'announcementController', ['$log', '$http', '$scope', '$timeout', 'HttpFactory', 'CONSTANTS', 'ngDialog',
      function ($log, $http, $scope, $timeout, HttpFactory, CONSTANTS, ngDialog) {

        var vm = this;
        vm.showDetails = false;


        var scope = angular.element(document.getElementById('mainTabId')).scope();
        vm.userInfo = scope.vm.userInfo;
        $log.debug("UserID: " + vm.userInfo.userId);

        vm.addNewWidgets = function () {
          $scope.$emit('openWidgetLibrary', true);
        };

        vm.toggleDetails = function (evt) {
          $log.debug(evt);
          vm.showDetails = !vm.showDetails;
        };
        $scope.selectedAnnouns = null;

        $scope.getAnnouncement = function () {
          $scope.refreshDate === undefined || null;
          HttpFactory.getActions(CONSTANTS.URL.ANNOUNCEMENTS + "userLoginIdentifier=" + vm.userInfo.userId)
            .then(function (successResponse) {
                $scope.announcements = successResponse.data;
                $scope.enableloading = false;
                $scope.refreashFaild = false;
                $scope.dateValid = false;
                $scope.refreshDate = new Date();
              },
              function (failureResponse) {
                $log.debug(failureResponse);
                if (failureResponse.status === 404) {
                  $scope.enableloading = false;
                  $scope.refreashFaild = false;
                  $scope.dateValid = false;
                  $scope.refreshDate = new Date();
                } else {
                  $scope.refreashFaild = true;
                  $scope.refreashFailDate = new Date();
                  $scope.enableloading = false;
                  if (angular.isUndefined($scope.refreshDate) || $scope.refreshDate === null) {
                    $scope.dateValid = true;
                  }
                }
              });
        };

        $scope.getAnnouncement();
        $scope.openDialog = function (announcementIdentifier) {
          for (var i = 0; i < $scope.announcements.length; i++) {
            if ($scope.announcements[i].announcementIdentifier === parseInt(announcementIdentifier, CONSTANTS.GLOBAL.RADIX)) {
              $scope.selectedAnnouns = $scope.announcements[i];
            }
          }
          ngDialog.open({
            template: "app/components/widgets/announcements/src/edit.html",
            scope: $scope,
            width: '50%',
            showClose: false,
            resolve: {}
          });
        };
        vm.closeAnnouncement = function () {
          ngDialog.closeAll();
        };
        $scope.criteriaMatch = function (input) {
          /* istanbul ignore next  */
          return function (announs) {
            if (input === undefined || input === '') {
              return true;
            } else {
              return (announs.announcementTitleText.toLowerCase().indexOf(input.toLowerCase()) > -1 || announs.announcementRawText.toLowerCase().indexOf(input.toLowerCase()) > -1);
            }
          };
        };
        $scope.refreshAnnouncementsData = function () {
          $scope.enableloading = true;
          $scope.refreashFaild = false;
          $scope.getAnnouncement();
        };
      }
    ]).directive('resize', function ($window) {
    /* istanbul ignore next  */
    return function (scope, element) {
      var w = angular.element($window);
      scope.getWindowDimensions = function () {
        return {
          'h': element[0].clientHeight,
          'w': element[0].clientWidth
        };
      };
      scope.$watch(scope.getWindowDimensions, function (
        newValue) {
        scope.divHeight = newValue.h;
        scope.divWidth = newValue.w;

        scope.style = function () {
          return {
            'height': (newValue.h - 100) + 'px',
            'width': (newValue.w - 100) + 'px'
          };
        };

      }, true);

      w.bind('resize', function () {
        scope.$apply();
      });
    };
  });
