(function () {
  'use strict';

  describe('announcementController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var controller;
    var scope, $rootScope, $http, $interval;
    var $compile;
    var successResponse, failureResponse;
    var $httpBackend, spy, $q, HttpFactoryDeferred;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open']);

    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              getWidgetZone: function () {

              },
              setWidgetContentHeight: function () {

              },
              userInfo: {
                "userId": "pgandhi"
              }
            }
          }
        }
      }
    };


    // vm.userInfo = {
    //   "userId": "pgandhi"
    // }

    beforeEach(inject(function (_$controller_, _$rootScope_, _$http_, _$compile_, _$httpBackend_, _$interval_, _$q_, HttpFactory) {
      $q = _$q_;
      scope = _$rootScope_.$new();
      $http = _$http_;
      $controller = _$controller_;
      $rootScope = _$rootScope_;
      $compile = _$compile_;
      $httpBackend = _$httpBackend_;


      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      controller = $controller('announcementController', {
        $scope: scope,
        $http: $http,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        $interval: $interval,
        HttpFactory: HttpFactory
      });
    }));


    afterEach(function () {
      spy.and.callThrough();
    });

    describe('announcementController ', function () {

      it('broadcast should broadcast event', function () {

        $controller('announcementController', {
          $scope: scope
        });

        spyOn(scope, '$emit');

        expect(controller.addNewWidgets).toBeDefined();
        // expect(scope.$emit).toHaveBeenCalled();
        controller.addNewWidgets();
        expect(scope.$emit).toHaveBeenCalledWith('openWidgetLibrary', true);

      });

      it("should call toggleDetails ", function () {

        expect(controller.toggleDetails).toBeDefined();
        controller.toggleDetails();

      });


      it('getAnnouncement   should return successResponse ', function () {

        successResponse = {
          data: [{
            lifeCycle: {
              endEffectiveDate: true,
              beginEffectiveDate: true,
              audienceStr: "test"
            },
            listRoleDisplaySequence: [{
              userRoleName: "testing"
            }]
          }]
        };
        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();

        scope.getAnnouncement();
      });


      it('getAnnouncement  should return failureResponse ', function () {

        failureResponse = {
          status: 404
        };
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();

        scope.getAnnouncement();
      });

      it('getAnnouncement  should return failureResponse ', function () {

        failureResponse = {};
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();

        scope.getAnnouncement();
      });

      it('it should call openDialog ', function () {
        scope.announcements = [{
          "announcementIdentifier": 958,
          "announcementTitleText": "TEST55",
          "announcementTextRaw": "&nbsp;TEST55&nbsp;",
          "announcementText": "<p>TEST55</p>",
          "announcementStatusCategory": "ARCHIVE",
          "publishIndicator": "ARCHIVE",
          "announcementTypeData": {
            "announcementTypeName": "announcementBlue",
            "backgroundConfigurationText": "announcementGreen",
            "displayOrderSequenceNumber": 1
          },
          "listRoleDisplaySequence": [{
            "userRoleIdentifier": 18,
            "userRoleName": "Petitioner_ApprovedMN_LeadCounsel",
            "announcementIdentifier": null,
            "displayOrderSequenceNumber": null,
            "lifeCyle": null,
            "audit": null
          }],
          "lifeCycle": {
            "beginEffectiveDate": 1528171200,
            "endEffectiveDate": 1528383616
          },
          "audit": {
            "createUserName": "fhan",
            "lastModifiedUserName": "fhan",
            "createDateTime": 1528237411,
            "createUserIdentifier": "465",
            "lastModifiedDateTime": 1528383616,
            "lastModifiedUserIdentifier": "465"
          },
          "actions": [
            "Copy",
            "View"
          ]
        }];

        var announcementIdentifier = 958;
        expect(scope.openDialog).toBeDefined();

        scope.openDialog(announcementIdentifier);
        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(1);
        var args = ngDialog.open.calls.argsFor(0);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(typeof args[0].resolve).toBe('object');

      });

      it("Should invoke close on ngDialog", function () {
        expect(ngDialog.closeAll).toBeDefined();
        expect(controller.closeAnnouncement).toBeDefined();
        controller.closeAnnouncement();
        expect(ngDialog.closeAll).toHaveBeenCalledWith();
      });

      it("Should invoke criteriaMatch", function () {
        expect(scope.criteriaMatch).toBeDefined();
        scope.criteriaMatch();
      });

      it("Should invoke refreshAnnouncementsData", function () {
        expect(scope.refreshAnnouncementsData).toBeDefined();
        scope.refreshAnnouncementsData();
      });

    });


  });
})();
