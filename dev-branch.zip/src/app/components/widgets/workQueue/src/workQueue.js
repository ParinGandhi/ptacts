'use strict';

angular.module('adf.widget.workQueue', ['adf.provider'])
  .config(function (dashboardProvider) {
    dashboardProvider
      .widget('workQueue', {
        title: 'Work Queue',
        description: 'Manage work queues',
        templateUrl: '{widgetsPath}/workQueue/src/view.html',
        edit: {
          templateUrl: '{widgetsPath}/workQueue/src/edit.html'
        }
      });
  }).directive('workView', function () {
    return {
      restirct: 'E',
      templateUrl: 'app/components/widgets/workQueue/workView.html',
      bindToController: true
    };
  })
  .controller('workQueueController', function ($log, $scope, $rootScope, uiGridConstants,
    HttpFactory, $timeout, SearchHelperService, ngDialog, CONSTANTS, $filter, CommonHelperService, $window, i18nService) {

    var vm = this;
    var widgetRandomId = (Math.floor((Math.random() * 1000) + 1)).toString();
    $scope.advancedSearchStartDateId = "advancedSearchStartDate-" + widgetRandomId;
    $scope.advancedSearchEndDateId = "advancedSearchEndDate-" + widgetRandomId;
    /* istanbul ignore next */
    $rootScope.$on('broadcastZoneWidth', function (event, param) {
      if ($scope.$parent.model) {
        if ($scope.$parent.model.widgetIdentifier === param.widgetIdentifier) {
          $scope.setWidgetZone(param.zoneWidth);
        }
      }
    });

    i18nService.get('en').gridMenu.exporterAllAsCsv = 'Export filtered data as csv';
    i18nService.get('en').gridMenu.exporterVisibleAsCsv = 'Export this page as csv';
    i18nService.get('en').gridMenu.exporterSelectedAsCsv = 'Export selected as csv';

    var scope = angular.element(document.getElementById('mainTabId')).scope();
    var currentEditRow;
    var isSPL = $rootScope.userInfo.roleDescription ? $rootScope.userInfo.roleDescription.toUpperCase().indexOf('SUPERVISOR')> -1 ? true : false : false;
    $scope.isSPL = isSPL;
    if($rootScope.userInfo.roleDescription === "Business Administrator"){
      isSPL =true; 
    }

    var requiredPageCountAssignments;

    if (isSPL) {
      getRequiredAssignmentPageCount();
    }

    $scope.setWidgetZone = function (zoneWidth) {
      /* istanbul ignore else */
      if (angular.isUndefined(zoneWidth)) {
        scope.vm.getWidgetZone($scope.$parent.$parent.$parent.definition);
        $scope.zoneWidth = $scope.$parent.$parent.$parent.definition.zoneWidth;
        $timeout(scope.vm.setWidgetContentHeight, 200, true, $scope.$parent.model);
      } else {
        scope.vm.setWidgetContentHeight($scope.$parent.model);
        $scope.zoneWidth = zoneWidth;
      }
    };
    $scope.setWidgetZone();

    $scope.selectUnselect = true;
    $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);


    var initialLoad = true;
    var isFilterChanged = false;
    var isColumnVisibilityChanged = false;
    var isColumnPinnedChanged = false;
    var isColumnSizeChanged = false;
    var isSortChanged = false;
    var isColumnPositionChanged = false;
    var isPaginationChanged = false;
    var hasFilterFlag = 0;
    $scope.loadedAssignColumns = false;
    var isAssignments = true;
    $scope.preferencesChanged = false;
    $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
    $scope.gridRefreshMsg = CONSTANTS.MESSAGES.GRID_REFRESH;
    var isGridRefreshed = false;
    $scope.isLoading = false;
    $scope.url;
    $scope.assignmentListOrderChanged = false;
    $rootScope.workqueueColumnsChanged = false;

    /* istanbul ignore next */
    function resetUnsavedChangesFlags() {
      isFilterChanged = false;
      isColumnVisibilityChanged = false;
      isColumnPinnedChanged = false;
      isColumnSizeChanged = false;
      isSortChanged = false;
      isColumnPositionChanged = false;
      isPaginationChanged = false;
      $scope.preferencesChanged = false;
      $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
    }

    $scope.assignmentGridOptions = CommonHelperService.setCommonGridOptions();
    $scope.assignmentGridOptions.enableSelectAll = true;
    $scope.assignmentGridOptions.showGridFooter = true;
    $scope.assignmentGridOptions.enableHorizontalScrollbar = uiGridConstants.scrollbars.WHEN_NEEDED;

    /* istanbul ignore next */
    $scope.assignmentGridOptions.exporterFieldCallback = function (grid, row, col, value) {
      $scope.assignmentGridOptions.exporterCsvFilename = "Work queue_" + CommonHelperService.getCurrentTime() + '.csv';
      if (col.colDef.type === 'date') {
        if (col.colDef.field === 'LAST_MODIFIED_TS') {
          value = $filter('date')(value, 'MM/dd/yyyy hh:mm:ss a');
        } else {
          value = $filter('date')(value, 'MM/dd/yyyy');
        }
        if (!value) {
          value = "";
        } else {
          value = " " + value;
        }
      }
      value = checkColumnName(col, value);
      return value;
    };

    /* istanbul ignore next */
    function checkColumnName(col, value) {
      if (col.name === "assigneeHistory") {
        value = "Audit log";
      }
      if (col.name === 'alert') {
        if (angular.isDefined(value)) {

          var cleanList = [];
          value = value.split(",");
          angular.forEach(value, function (item) {
            if (item.trim() !== "" && item !== 'end') {
              cleanList.push(item);
            }
          });
          value = cleanList.join();
        }
      }
      return value;

    }
    /* istanbul ignore next*/
    $scope.assignmentGridOptions.gridMenuCustomItems = [{
        title: 'Save grid preferences',
        action: function () {
          $scope.saveGridPreferences();
        },
        order: 100
      }, {
        title: 'Show hidden filters',
        action: function () {
          showHiddenFilteredColumns();
        },
        order: 190
      },
      {
        title: 'Export full docket as csv',
        action: function () {
          $scope.download_csv();
        },
        order: 220
      },
      {
        title: 'Mandatory columns',
        order: 221
      },
      {
        title: 'Alerts',
        icon: 'fas fa-check',
        order: 222
      },
      {
        title: 'Application #',
        icon: 'fas fa-check',
        order: 223
      },
      {
        title: 'Assigned to',
        icon: 'fas fa-check',
        order: 224
      },
      {
        title: 'Assigned date',
        icon: 'fas fa-check',
        order: 225
      },
      {
        title: 'Due date',
        icon: 'fas fa-check',
        order: 226
      }
    ];

    /* istanbul ignore next  */
    function showHiddenFilteredColumns() {
      var hiddenFilteredColumns = SearchHelperService.hasHiddenColumnFilters($scope.gridApi.grid.columns);

      angular.forEach(hiddenFilteredColumns, function (column) {
        column.showColumn();
        $scope.preferencesChanged = true;
      });
      $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
    }

    /* istanbul ignore next*/
    $scope.assignmentGridOptions.onRegisterApi = function (gridApi) {
      $scope.gridApi = gridApi;
      $scope.gridApi.selection.setMultiSelect(true);
      $scope.gridApi.core.notifyDataChange = function (val) {
        updateEditedRow();
      };

      $scope.gridApi.core.on.filterChanged($scope, function () {
        isFilterChanged = true;
        var grid = this.grid;
        vm.grid = this.grid;
        $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
        /* Change the scope to $scope.$$childHead.$$childHead.searchText after adding loading screen
         If there are no filters and no search text, then set the grid data to original data */
        if ($scope.numberOfFilters === 0 &&
          (angular.isUndefined($scope.$$childTail.$$prevSibling.searchText) ||
            $scope.$$childTail.$$prevSibling.searchText === "" ||
            $scope.$$childTail.$$prevSibling.searchText === null)) {
          $scope.assignmentGridOptions.data = $scope.myData;
          /* If search text is defined and there are filters, then set grid data to filtered data before searching for searched text */
        } else if (angular.isDefined($scope.$$childTail.$$prevSibling.searchText) && $scope.numberOfFilters > 0) {
          $scope.assignmentGridOptions.data = SearchHelperService.filterGrid(grid, $scope.myData);
          $scope.$parent.$$childHead.simpleSearch($scope.$$childTail.$$prevSibling.searchText);
          /* If search text is defined and there are no filters, then set the grid data to original data before searching for searched text */
        } else if (angular.isDefined($scope.$$childTail.$$prevSibling.searchText) && $scope.numberOfFilters === 0) {
          $scope.assignmentGridOptions.data = $scope.myData;
          $scope.$parent.$$childHead.simpleSearch($scope.$$childTail.$$prevSibling.searchText);
        } else {
          /* If there are filters and no search text, then set grid data to filtered data */
          $scope.assignmentGridOptions.data = SearchHelperService.filterGrid(grid, $scope.myData);
        }
        checkForUnsavedChanges();
      });
      $scope.gridApi.core.on.columnVisibilityChanged($scope, function () {
        isColumnVisibilityChanged = true;
        updateColumnDefs($scope.assignmentGridOptions.columnDefs);
        checkForUnsavedChanges();
      });
      $scope.gridApi.pinning.on.columnPinned($scope, function () {
        isColumnPinnedChanged = true;
        updateColumnDefs($scope.assignmentGridOptions.columnDefs);
        checkForUnsavedChanges();
      });
      $scope.gridApi.colResizable.on.columnSizeChanged($scope, function () {
        isColumnSizeChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.core.on.sortChanged($scope, function () {
        isSortChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.selection.on.rowSelectionChanged($scope, function (row) {
        $scope.quickCompleteIndicator = row.entity.quickComplete;
        $scope.selectedRows = $scope.gridApi.selection.getSelectedRows();
      });

      $scope.gridApi.selection.on.rowSelectionChangedBatch($scope, function () {
        $scope.selectedRows = $scope.gridApi.selection.getSelectedRows();
      });

      $scope.gridApi.colMovable.on.columnPositionChanged($scope, function () {
        isColumnPositionChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.pagination.on.paginationChanged($scope, function () {
        isPaginationChanged = true;
        checkForUnsavedChanges();
      });

    };

    /* istanbul ignore next*/
    $scope.download_csv = function () {
      var headers = [];
      angular.forEach($scope.columnsData, function (coldata) {
        headers.push(coldata.columnLabel);

      });
      var fields = [];
      angular.forEach($scope.columnsData, function (coldata) {

        if (coldata.columnName[0] === 'FK_ASSIGNEE_BE_NO') {
          fields.push([coldata.columnName[1], coldata.columnType]);
        } else {
          fields.push([coldata.columnName[0], coldata.columnType]);
        }
      });
      var replacer = function (key, value) {
        // return value === null ? '' : value
        if (value === null || angular.isUndefined(value)) {
          value = '';
        }
        return value;
      };
      var csv = $scope.myData.map(function (row) {
        return fields.map(function (fieldName) {
          if (fieldName[1] === 'date') {
            if (row[fieldName[0]]) {
              if (fieldName[0] === 'LAST_MODIFIED_TS') {
                return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy hh:mm:ss a') + " ";
              } else {
                return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy') + " ";
              }
            } else {
              return "";
            }
          } else if (fieldName[0] === 'FK_ASSIGNMENT_TYPE_ID') {
            return JSON.stringify(row['assignmentTypeDescription'], replacer);
          } else if (fieldName[0] === 'LAST_MODIFIED_USER_ID') {
            return JSON.stringify(row['lastModifiedUserName'], replacer);
          } else if (fieldName[0] === 'assigneeHistory') {
            return "";
          } else {
            return JSON.stringify(row[fieldName[0]], replacer);
          }
        }).join(',');
      });
      csv.unshift(headers.join(','));
      csv = csv.join('\r\n');
      var hiddenElement = document.createElement('a');
      hiddenElement.href = URL.createObjectURL(new Blob([csv], {
        type: 'text/csv'
      }));
      hiddenElement.target = '_blank';
      hiddenElement.download = 'Work queue ' + CommonHelperService.getCurrentTime() + '.csv';
      hiddenElement.click();
    };


    /* istanbul ignore if*/
    if (angular.isDefined($scope.$parent.model)) {
      $scope.assignmentDataUrlList = $scope.$parent.model.dataUrlText.split(",").reduce(function (map, col) {
        map[col.split(":")[0]] = col.split(":")[1];
        return map;
      }, {});
      $scope.widgetIdentifier = $scope.$parent.model.widgetIdentifier;
    } else {
      /* istanbul ignore if*/
      if ($scope.definition.type === "workQueue") {
        $scope.url = $scope.$parent.$parent.$parent.$$childHead.$$childTail.$$childHead.url;
        $scope.assignmentDataUrlList = $scope.definition.dataUrlText.split(",").reduce(function (map, col) {
          map[col.split(":")[0]] = col.split(":")[1];
          return map;
        }, {});
        $scope.widgetIdentifier = $scope.definition.widgetIdentifier;
      }
    }

    $scope.getAssignmentColumns = function () {
      if (isAssignments || $scope.definition.type === 'workQueue') {
        isAssignments = false;
        HttpFactory.getActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS + $scope.widgetIdentifier)
          .then(function (successResponse) {
            $scope.selectedColumns = successResponse.data.selectedColumns;
            $scope.selectedCols = [];
            $scope.availableCols = [];
            angular.forEach($scope.selectedColumns, function (thisColumn) {
              if (thisColumn.visible) {
                $scope.selectedCols.push(thisColumn);
              } else {
                $scope.availableCols.push(thisColumn);
              }
            });
            $log.debug('Selected:');
            $log.debug($scope.selectedCols);
            $log.debug('Available: ');
            $log.debug($scope.availableCols);
            $scope.originShowHide = angular.copy($scope.selectedColumns);
            $scope.assignmentsAvailableCols = angular.copy($scope.selectedCols);
            $scope.loadedAssignColumns = true;
            for (var i = 0; i < $scope.selectedColumns.length; i++) {
              if (!$scope.selectedColumns[i].visible) {
                $scope.selectUnselect = false;
                $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
              }
            }
            $log.debug("Assignment (" + $scope.widgetIdentifier + ") getAssignmentColumns success response: ");
            $log.debug(successResponse);
          }, function (failureResponse) {
            $log.debug("Assignment (" + $scope.widgetIdentifier + ") getAssignmentColumns failure response: ");
            $log.debug(failureResponse);
          });
      }
    };

    $scope.onKeyup = function (url, advancedSearchFlag, $event) {
      if ($event.keyCode === 13) {
        $scope.setUrl(url, advancedSearchFlag);
      }
    };

    $scope.setUrl = function (url, advancedSearchFlag) {
      $scope.url = url;
      $scope.searchData = !advancedSearchFlag;
      $scope.advancedSearchFlag = advancedSearchFlag;
      $scope.getAssignments();
    };


    /* istanbul ignore next*/
    function setGridData(colDefs) {
      if (hasFilterFlag > 0) {

        $scope.numberOfFilters = hasFilterFlag;
        var filteredData = SearchHelperService.filterTable($scope.myData, colDefs);
        $timeout(function () {
          $scope.assignmentGridOptions.data = filteredData;
          $scope.savedFilteredData = filteredData;
          selectAssignmentRows();
        }, 200);

      } else {
        $scope.numberOfFilters = 0;
        $timeout(function () {
          $scope.assignmentGridOptions.data = $scope.myData;
          selectAssignmentRows();
        }, 200);

      }
    }
    /* istanbul ignore next: toaster error*/
    $scope.getAssignments = function () {
      $scope.enableloading = true;
      $scope.refreashFaild = false;
      $scope.isLoading = true;
      HttpFactory.getActions($scope.url)
        .then(function (successResponse) {
          $scope.enableloading = false;
          $scope.refreashFaild = false;
          $scope.lastRefresh = new Date();
          $scope.dateValid = false;
          if (angular.isDefined(successResponse.data.assignmentsData)) {
            $scope.myData = successResponse.data.assignmentsData;
            $scope.columnsData = successResponse.data.columnDetails;
            $scope.selectedCols = [];
            $scope.availableCols = [];
            angular.forEach($scope.columnsData, function (thisColumn) {
              if (thisColumn.visible) {
                $scope.selectedCols.push(thisColumn);
              } else {
                $scope.availableCols.push(thisColumn);
              }
            });
            $scope.originalData = angular.copy(successResponse.data.assignmentsData);
            $scope.updatedColumnList = successResponse.data.columnDetails;
            $scope.originalAssignments = angular.copy($scope.updatedColumnList);

            var setColumnsResponse = CommonHelperService.setColumnDefinitions($scope.updatedColumnList);
            $scope.selectUnselect = setColumnsResponse.selectUnselect;
            $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
            hasFilterFlag = setColumnsResponse.filterCount;
            updateColumnDefs(setColumnsResponse.colDefs);
            setGridData(setColumnsResponse.colDefs);

            $scope.assignmentGridOptions.paginationPageSize = successResponse.data.paginationSize !== undefined ? successResponse.data.paginationSize : 25;

            $scope.preferencesChanged = false;
            $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
            $timeout($scope.setPaginationManually, 700);
            $scope.noRecordsFound = false;
            $timeout(function () {
              initialLoad = false;
            }, 2000);
            if (isGridRefreshed) {
              CommonHelperService.setToastr(CONSTANTS.TOASTER.refreshData, "success");
            }
          }
        }, function (failureResponse) {
          $scope.assignmentGridOptions.data = [];
          if (failureResponse.status === 404) {
            $scope.enableloading = false;
            $scope.refreashFaild = false;
            $scope.lastRefresh = new Date();
            $scope.dateValid = false;
            CommonHelperService.setToastr(CONSTANTS.TOASTER.refreshFailure, "info");
          } else {
            $scope.refreashFaild = true;
            $scope.refreashFailDate = new Date();
            $scope.enableloading = false;
            if (angular.isUndefined($scope.lastRefresh) || $scope.lastRefresh === null) {
              $scope.dateValid = true;
            }
            CommonHelperService.setToastr(failureResponse.data.message, "info");
          }
        })
        .finally(function () {
          $scope.isLoading = false;
        });
    };


    $scope.moveItem = function (origin, destination) {
      var temp = $scope.selectedCols[destination];
      $log.debug("Initial");
      $log.debug($scope.selectedCols);
      $scope.selectedCols[destination] = $scope.selectedCols[origin];
      $log.debug("Origin moved to destination");
      $log.debug($scope.selectedCols);
      $scope.selectedCols[origin] = temp;
      $log.debug("Final");
      $log.debug($scope.selectedCols);
      $scope.assignmentListOrderChanged = true;
      $rootScope.workqueueColumnsChanged = true;
      var adfScope = angular.element(document.getElementById('assignmentsEdit')).scope();
      adfScope.showErrorMsg = true;
    };

    $scope.listItemUp = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex - 1);
    };

    $scope.listItemDown = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex + 1);
    };

    $scope.moveSourcetoDestination = function () {
      angular.forEach($scope.clickedColumn, function (column) {
        column.visible = true;
        $scope.selectedCols.push($scope.availableCols[$scope.availableCols.indexOf(column)]);
        $scope.availableCols.splice($scope.availableCols.indexOf(column), 1);
      });
      $scope.clickedColumn = [];
      $rootScope.workqueueColumnsChanged = true;
    };

    $scope.moveSourcetoDestinationCancel = function (index) {
      $scope.selectedCols[index].visible = false;
      $scope.availableCols.push($scope.selectedCols[index]);
      $scope.selectedCols.splice(index, 1);
      $rootScope.workqueueColumnsChanged = true;
    };

    $scope.toggleSelectAll = function () {
      angular.forEach($scope.availableCols, function (column) {
        column.visible = true;
        $scope.selectedCols.push(column);
      });
      $scope.availableCols = [];
      $rootScope.workqueueColumnsChanged = true;
    };

    $scope.removeAll = function () {
      var tempArray = [];
      $rootScope.workqueueColumnsChanged = true;
      angular.forEach($scope.selectedCols, function (column) {
        if (!column.mandatory) {
          column.visible = false;
          $scope.availableCols.push(column);
        } else {
          tempArray.push(column);
        }
      });
      $scope.selectedCols = tempArray;
    };

    /* istanbul ignore next*/
    $scope.saveState = function () {
      $scope.saveGridPreferences();
    };

    $scope.canEdit = function(row) {
      return checkAssignmentTypes(row.entity);
    };

    var oldValue;
    function checkEdit($scope) {
      var isEditable = checkAssignmentTypes($scope.row.entity);
      currentEditRow = $scope.row.entity;
      oldValue = currentEditRow.PAGE_COUNT_QT;
      return isEditable;
    }

    function updateEditedRow() {
      if (currentEditRow) {
        
        if (!currentEditRow.PAGE_COUNT_QT || currentEditRow.PAGE_COUNT_QT===0 ) {
          CommonHelperService.setToastr("A page count of at least 1 is required, reseting value to " + oldValue, "error");
          currentEditRow.PAGE_COUNT_QT=oldValue;
          return;
        }

        if (currentEditRow.PAGE_COUNT_QT === oldValue) {
          return;
        }
        vm.getAssignmentById(currentEditRow.assignmentIdentifier).then(function (item) {
          if (!item || !item[0]) {
            CommonHelperService.setToastr("Error updating page count, reseting value to " + oldValue, "error");
            currentEditRow.PAGE_COUNT_QT=oldValue;
            return;
          }
          var reAssignDataArray = [];
          var theOldValue = angular.copy(oldValue);
          if (!theOldValue) {
            theOldValue = "no value";
          }
          item[0].notes="Page count changed from " + theOldValue + " to " + currentEditRow.PAGE_COUNT_QT;
       
          item[0].pageNumberQuantity=currentEditRow.PAGE_COUNT_QT;
          reAssignDataArray.push(item[0]);
          HttpFactory.putActions(CONSTANTS.URL.IMPORT_BULK_REASSIGN, reAssignDataArray)
          .then(function (successResponse) {
            CommonHelperService.setToastr("Successfully updated page count", "success");
          }, function (failureResponse) {
            CommonHelperService.setToastr("Error updating page count, reseting value to " + oldValue, "error");
            currentEditRow.PAGE_COUNT_QT=oldValue;
          }); 
        });
      }        
    }

    $scope.checkForChanges = function(row) {
      console.log("checking for chagnes");
    }

    function checkAssignmentTypes(row) {    
      if (!isSPL) {
        return false;
      }
      try {
        var strTypeId = row.FK_ASSIGNMENT_TYPE_ID.toString();
   
        if (requiredPageCountAssignments.includes(strTypeId) ) {
          return true;
        }
    
      } catch(error) {

      }
      return false;
    }

    function getRequiredAssignmentPageCount() {
      HttpFactory.getActions("/reference-data/code-reference-types?typeCode=MAND_ASSIGNMENTS")
      .then(function (successResponse) {
        requiredPageCountAssignments = successResponse.data[0].descriptionText.split('~');
      }, function (failureResponse) {
        console.log(failureResponse);
      });
    }

    function updateColumnDefs(columndefs) {
      var selected = [];
      var unselected = [];
      var selectedCount = 0;
      angular.forEach(columndefs, function (col) {
        if (col.cellEditMethod) {
          col.width=85;
          col.cellEditableCondition=checkEdit;
          col.cellTemplate ="<div ng-if=\"!grid.appScope.canEdit(row)\" style=\"margin-left:10px; padding-top:5px;\" class=\"truncateTitle\">{{row.entity.PAGE_COUNT_QT}}</div> <div ng-if=\"grid.appScope.canEdit(row)\"  title=\"Click edit button to change value, press Esc to cancel and press enter to save\" style=\"margin-left:10px; padding-top:5px;\" class=\"truncateTitle\" ng-model=\"row.entity.PAGE_COUNT_QT\">{{row.entity.PAGE_COUNT_QT}} <i style=\"padding-right:6px;padding-top:3px;\" class=\"fa fa-edit pull-right\"></i></div>";
        }

        if (col.visible) {
          selected.push(col);
          selectedCount = selectedCount + 1;

        } else {
          unselected.push(col);
        }
      });

      columndefs = [];
      angular.forEach(selected, function (col) {
        if (col.displayName === 'Alerts') {
          col = CommonHelperService.addAlertFilters(col, 'work queue');
        }
        columndefs.push(col);
      });

      unselected.sort(CommonHelperService.alphabetizeAvailableColumns);

      angular.forEach(unselected, function (col) {
        if (col.displayName === 'Alerts') {
          col = CommonHelperService.addAlertFilters(col, 'work queue');
        }
        columndefs.push(col);
      });
      $scope.assignmentGridOptions.columnDefs = columndefs;
    }

    $scope.showFilteringHelp = function () {
      ngDialog.open({
        template: 'app/components/helperComponents/filterHelp/filteringHelp.html',
        controller: 'CommonDialogController',
        controllerAs: 'vm',
        showClose: false
      }).then(function () {
        // No action needed.  User closed modal.
      }, function () {
        // X button clicked
      });
    };

    $scope.sortableOptions = {
      containment: '#workQueueColumns',
      scroll: true,
      axis: 'y',
      cursor: 'move',
      scrollSpeed: 2,
      scrollSensitivity: 160,
      update: function () {
        $rootScope.workqueueColumnsChanged = true;
      }
    };
    /* istanbul ignore next*/
    $scope.clearSearch = function (clearSearchText) {
      if (clearSearchText) {
        $scope.$$childTail.$$prevSibling.searchText = undefined;
        $scope.$$childTail.searchText = undefined;
      }
      if ($scope.numberOfFilters > 0) {
        $scope.assignmentGridOptions.data = SearchHelperService.filterGrid($scope.$$childHead.$$childHead.$$nextSibling.grid, $scope.myData);
      } else {
        $scope.assignmentGridOptions.data = $scope.originalData;
      }
    };
    /* istanbul ignore next*/
    $scope.simpleSearch = function (textToSearch) {
      if (textToSearch !== $scope.previousTextToSearch) {
        $scope.previousTextToSearch = angular.copy(textToSearch);
        $scope.clearSearch(false);
      }

      var simpleSearchResults = [];
      angular.forEach($scope.assignmentGridOptions.data, function (thisRow) {
        for (var key in thisRow) {
          if (rowContainsValue(thisRow, key)) {
            if (thisRow[key].toString().toLowerCase().includes(textToSearch.trim().toLowerCase())) {
              simpleSearchResults.push(thisRow);
              break;
            }
          } else {
            var thisDate = new Date(thisRow[key]);
            var dateToCompare = getDateRow(thisDate);
            if (dateToCompare.includes(textToSearch.trim())) {
              simpleSearchResults.push(thisRow);
              break;
            }
          }
        }
      });
      displayNoResults(simpleSearchResults);
      $scope.assignmentGridOptions.data = simpleSearchResults;
    };

    /* istanbul ignore next */
    function getDateRow(thisDate) {
      var month = thisDate.getMonth() + 1;
      if (month < 10) {
        month = '0' + month.toString();
      }
      var date = thisDate.getDate();
      if (date < 10) {
        date = '0' + date.toString();
      }
      return month + '/' + date + '/' + thisDate.getFullYear();

    }

    function displayNoResults(simpleSearchResults) {
      if (simpleSearchResults.length === 0) {
        CommonHelperService.setToastr(CONSTANTS.TOASTER.noRecords, "error");
      }
    }

    /* istanbul ignore next */
    function rowContainsValue(thisRow, key) {
      var validKey = thisRow.hasOwnProperty(key) && thisRow[key];
      return validKey && (isNaN(parseInt(thisRow[key], CONSTANTS.GLOBAL.RADIX)) || thisRow[key].toString().length !== 13);
    }

    $scope.openCaseViewer = function (row) {
      $window.sessionStorage.setItem("id", row.entity.assignmentIdentifier);
      $window.open("#/caseViewer/" + row.entity.FK_AD_FK_AA_SERIAL_NO + "/" + row.entity.FK_AD_FK_APPEAL_NO);
    };

    $scope.unSelectAll = function(){
      $scope.gridApi.selection.clearSelectedRows();
  }

    /* istanbul ignore next: toaster error*/
    $scope.bulkReassign = function () {
      var userId = $window.sessionStorage.getItem("workerNumber");
      ngDialog.open({
        template: "app/components/widgets/assignments/src/reassignmentModal.html",
        controller: 'ReassignmentModalController',
        controllerAs: 'vm',
        scope: $scope,
        width: '52%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,
        resolve: {
          userId: function () {
            return userId;
          },
          assignmentRows: function () {
            return $scope.selectedRows;
          }
        }
      }).closePromise.then(function (responseData) {
        var successResponse = responseData.value;
  if (successResponse != undefined){
$scope.assignmentsData = successResponse.data;
} 
        var verb = " assignments have ";
        if ( $scope.assignmentsData == undefined) {
          console.log("canceled");
           }
       else if ($scope.selectedRows.length - $scope.assignmentsData.length === 1) {
          verb = " assignment has ";
        }
 if ( $scope.assignmentsData == undefined) {
console.log("canceled");
 }
       else if ($scope.assignmentsData.length === 0) {
          CommonHelperService.setToastr($scope.selectedRows.length + verb + " been successfully reassigned.", "success");
        } else if ($scope.selectedRows.length === $scope.assignmentsData.length) {
          CommonHelperService.setToastr(CONSTANTS.TOASTER.reassignFail, "error");
          return;
        } else {
          CommonHelperService.setToastr($scope.selectedRows.length - $scope.assignmentsData.length + verb +
          "been successfully reassigned.  " + $scope.assignmentsData.length + " assignment(s) failed to be reassigned.", "warning");
        }
        vm.failedReassignments = angular.copy($scope.assignmentsData);
        $scope.$$childTail.$$prevSibling.searchText = undefined;
        if (successResponse!= undefined)
        {   
          $scope.assignmentsData =  $scope.selectedRows;
          angular.forEach($scope.gridApi.selection.getSelectedRows(), function(data){
            angular.forEach($scope.gridApi.selection.getSelectedRows(), function (entity, index) {
                if (entity.$$hashKey == data.$$hashKey) {
                    $scope.gridApi.selection.unSelectRow(entity);
                    //timeout needed to give time to the previous call to unselect the row,then delete it
                    $timeout(function () {
                        $scope.assignmentGridOptions.data.splice($scope.assignmentGridOptions.data.indexOf(entity), 1);
                    }, 0,1);
                }
            });
        }) 
        }
      }, function () {
        // Cancel from Modal
      });
    };

    GET_UPDATE_EWF_id();
    function GET_UPDATE_EWF_id() {
      HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTS_UPDATE_EWF)
      .then(function (successResponse) {
        var assignments = successResponse.data;
        console.log(assignments);
        angular.forEach(assignments, function(valueRow) {
          if (valueRow.valueText==="UPDATE_EWF") {
            vm.assignmentTypeId = valueRow.descriptionText;
          }
        });
      }, function (failureResponse) {

      });
    }

    $scope.checkFileTypes = function () {
      vm.checkFlag = true;
      for(var i=0;i<$scope.selectedRows.length;i++){
        if ($scope.selectedRows[i].FK_ASSIGNMENT_TYPE_ID != vm.assignmentTypeId) {
          vm.checkFlag = false;
          CommonHelperService.setToastr("Please select Update eWF assignments only", "error");
          break;
        }
      }
      if(vm.checkFlag){
        bulkComplete();
      }
    }



        /* istanbul ignore next: toaster error*/
        function bulkComplete() {
          var reAssignDataArray = [];
          $scope.selectedRows.forEach(function (item) {
            if (vm.useExisting) {
              vm.dueDte = null;
            } else {
              vm.dueDte = new Date(vm.reassignDueDate).getTime();
            }
            var reAssignObject = {
              "assignee": item.FK_ASSIGNEE_BE_NO,
              "serialNumber": item.FK_AD_FK_AA_SERIAL_NO,
              "title": item.TASK_TITLE_TX,
              "description": item.TASK_DESC_TX,
              "dueDate": item.ASSIGNMENT_DUE_DT,
              "assignedDate": item.ASSIGNED_DT,
              "completionDate": item.COMPLETION_DT,
              "appealNumber": item.FK_AD_FK_APPEAL_NO,
              "notes": item.COMMENT_TX,
              "priorityIndicator": item.PRIORITY_IN,
              "assignmentIdentifier": item.assignmentIdentifier,
              "assignmentTypeIdentifier": item.FK_ASSIGNMENT_TYPE_ID,
              "pageNumberQuantity": item.PAGE_COUNT_QT,
  
              "assignor": $rootScope.userInfo.userId,
              "activeIndicator": item.FK_ASSIGNMENT_STATUS_CD,
              "reassignDueDate": vm.dueDte,
              "audit": {
                "createUserIdentifier": item.CREATOR_USER_ID,
                "lastModifiedUserIdentifier": $rootScope.userInfo.userId,
                "lockControlNumber": item.LOCK_CONTROL_NO,
                "lastModifiedTimestamp": new Date().getTime()
              }
            };
            reAssignDataArray.push(reAssignObject);
          });
  
          HttpFactory.putActions(CONSTANTS.URL.CLOSE_UPDATE_EWF, reAssignDataArray)
            .then(function (successResponse) {
              CommonHelperService.setToastr("Successfully closed the assignment(s)", "success");
              $scope.refreshGrid();
            }, function (failureResponse) {              
              CommonHelperService.setToastr(CONSTANTS.TOASTER.reassign, "error");
            });
        }

    /* istanbul ignore next*/
    $scope.saveGridPreferences = function () {
      if ($scope.gridApi) {
        $scope.gridState = CommonHelperService.setGridWidthMap($scope.gridApi.saveState.save());
      } else if ($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi) {
        $scope.gridState = CommonHelperService.setGridWidthMap($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi.saveState.save());
      }
      $scope.updateColumns();
    };


    $scope.paginationManual = false;
    $scope.setPaginationManually = function () {
      $scope.paginationManual = false;
    };
    /* istanbul ignore next*/
    $rootScope.$on('adfCustomizeWidgetServiceCall', function () {
      if ($rootScope.widgetIdentifier === $scope.widgetIdentifier) {
        switch ($rootScope.widgetHeight) {
          case "widgetHeightSmall":
            $scope.assignmentGridOptions.paginationPageSize = $scope.assignmentGridOptions.paginationPageSizes[0];
            break;
          case "widgetHeightMedium":
            $scope.assignmentGridOptions.paginationPageSize = $scope.assignmentGridOptions.paginationPageSizes[1];
            break;
          case "widgetHeightLarge":
            $scope.assignmentGridOptions.paginationPageSize = $scope.assignmentGridOptions.paginationPageSizes[2];
            break;
          case "widgetHeightXlarge":
            $scope.assignmentGridOptions.paginationPageSize = $scope.assignmentGridOptions.paginationPageSizes[3];
            break;
          default:
            break;
        }

        // var pageSize = CommonHelperService.setPagination();
        // if (pageSize) {
        //   $scope.assignmentGridOptions.paginationPageSize = pageSize;
        // }
        $scope.paginationManual = true;
        $timeout($scope.setPaginationManually, 700);
      }
    });

    /* istanbul ignore next*/
    $scope.areAllSelected = function () {
      var columnList = angular.element(document.getElementById('workQueueColumns')).scope();
      for (var i = 0; i < columnList.updatedColumnList.length; i++) {
        if (!columnList.updatedColumnList[i].visible) {
          $scope.selectUnselect = false;
          break;
        } else {
          $scope.selectUnselect = true;
        }
        $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
      }
    };
    /* istanbul ignore next*/
    $scope.updateColumns = function () {
      $scope.isLoading = true;
      var docketScopeList = angular.element(document.getElementById('workQueueColumns')).scope();
      var columnsSelected = [];
      var fromModal = false;
      if (angular.isDefined(docketScopeList)) {
        columnsSelected = docketScopeList.selectedCols;
        columnsSelected = angular.copy(docketScopeList.selectedCols);
        angular.forEach(docketScopeList.availableCols, function (available) {
          columnsSelected.push(available);
        });
        fromModal = true;
      } else {
        columnsSelected = $scope.updatedColumnList;
      }
      var updatedColumns = CommonHelperService.setColumnsToUpdate(columnsSelected, fromModal, $scope.gridState, $scope.widgetIdentifier, false);

      if (angular.isDefined(docketScopeList)) {
        docketScopeList.originalAssignments = angular.copy(updatedColumns.selectedColumns);
      }
      updateAssignmentColumnsService(updatedColumns, fromModal);
    };
    /* istanbul ignore next */
    function updateAssignmentColumnsService(updatedColumns, fromModal) {
      HttpFactory.putActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS, updatedColumns)
        .then(function (successResponse) {

            CommonHelperService.setToastr(CONSTANTS.TOASTER.gridSave, "success");

            resetUnsavedChangesFlags();

            if (fromModal) {
              fromModal = false;
              var colDefs = [];
              angular.forEach(successResponse.config.data.selectedColumns, function (fetchedColumn) {
                var columnToBeAdded = {};

                if (!fetchedColumn.visible) {
                  $scope.selectUnselect = false;
                  $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
                }

                // Adding the column display name
                columnToBeAdded.displayName = fetchedColumn.columnLabel;

                // Checking if the field mapped to the column as an alias name
                if (fetchedColumn.columnName.length > 1) {
                  columnToBeAdded.field = fetchedColumn.columnName[1];
                } else {
                  columnToBeAdded.field = fetchedColumn.columnName[0];
                }
                if (columnToBeAdded.field === "alert") {
                  columnToBeAdded.cellTemplate = 'app/components/widgets/assignmentBasedDocket/src/assignmentBasedDocketFlags.html';
                }
                if (columnToBeAdded.field === 'ASSIGNMENT_DUE_DT') {
                  columnToBeAdded.cellTemplate = 'app/components/widgets/assignmentBasedDocket/src/assignmentBasedDocketRowTemplate.html';
                }

                // Setting column type
                columnToBeAdded.type = fetchedColumn.columnType;

                // Setting custom cell filter if one exists
                if (angular.isDefined(fetchedColumn.cellFilter)) {
                  columnToBeAdded.cellFilter = fetchedColumn.cellFilter;
                }

                // Setting visibility of the column
                if (fetchedColumn.mandatory) {
                  columnToBeAdded.visible = true;
                  columnToBeAdded.enableHiding = false;
                } else {
                  columnToBeAdded.visible = fetchedColumn.visible;
                }

                // Setting column width
                columnToBeAdded.width = fetchedColumn.width;

                // Setting custom template if one exists
                if (angular.isDefined(fetchedColumn.cellTemplate)) {
                  columnToBeAdded.cellTemplate = fetchedColumn.cellTemplate;
                }

                // Setting sort properties on column
                columnToBeAdded.sort = fetchedColumn.sort;

                // Setting column filters
                columnToBeAdded.filters = fetchedColumn.filters;

                // Incrementing the filter flag
                if (columnToBeAdded.filters[0].term) {
                  hasFilterFlag = hasFilterFlag + 1;
                }

                colDefs.push(columnToBeAdded);

              });

              $scope.numberOfFilters = hasFilterFlag;
              var allGrids = document.getElementsByClassName('ui-grid');
              for (var j = 0; j < allGrids.length; j++) {
                if (angular.element(allGrids[j]).scope().widgetIdentifier === $scope.widgetIdentifier) {
                  updateColumnDefs(colDefs);
                  angular.element(allGrids[j]).scope().assignmentGridOptions.columnDefs = $scope.assignmentGridOptions.columnDefs;
                  if ($scope.numberOfFilters > 0) {
                    var filteredData = SearchHelperService.filterTable($scope.myData, colDefs);
                    $scope.assignmentGridOptions.data = filteredData;
                  } else {

                    $scope.assignmentGridOptions.data = $scope.myData;
                  }
                  break;
                }
              }
              $rootScope.workqueueColumnsChanged = false;
            } else {
              $scope.getAssignments();
            }


          },
          function () {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.gridSaveFail, "error");
          })
        .finally(function () {
          $scope.isLoading = false;
        });
    }

    /* istanbul ignore next*/
    $scope.exportData = function () {
      var dataToExport = [];
      if ($scope.assignmentGridOptions.data.length !== $scope.myData.length) {
        angular.forEach($scope.assignmentGridOptions.data, function (currentRow) {
          dataToExport.push(currentRow.ID);
        });
      }
      HttpFactory.exportFile($scope.VCDdataUrl, dataToExport)
        .then(function () {
          // Implementation not needed
        }, function () {
          // Intentionally empty method
        });
    };


    $scope.pressEnter = function (event, searchText) {
      if (event.keyCode === 13) {
        $scope.simpleSearch(searchText);
      }
    };
    /* istanbul ignore next*/
    function checkForUnsavedChanges() {
      if (!initialLoad) {
        if (isFilterChanged || isColumnVisibilityChanged || isColumnSizeChanged || isSortChanged || isColumnPositionChanged || isPaginationChanged || isColumnPinnedChanged) {
          $scope.preferencesChanged = true;
          $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_PREFERENCES;
        } else {
          $scope.preferencesChanged = false;
          $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
        }
      }
    }
    /* istanbul ignore next*/
    $scope.refreshGrid = function () {
      $scope.preferencesChanged = false;
      $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
      isGridRefreshed = true;
      $scope.$$childTail.searchText = "";
      $scope.enableloading = true;
      $scope.refreashFaild = false;
      $scope.lastRefresh === undefined || null;
      if ($scope.advancedSearchFlag && $scope.enableAdvSearch()) {
        $scope.performAdvSearch();
      } else {
        $scope.getAssignments();
      }
    };
    $scope.openAssignmentHistory = function (row) {

      $scope.assignData = row.entity;
      ngDialog.open({
        template: 'app/components/widgets/assignments/src/assignmnetHistory.html',
        controller: 'AssignmentHistoryController',
        controllerAs: 'vm',
        width: '80%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,
        resolve: {
          assignmentData: function () {
            return $scope.assignData;
          }
        }
      });
    };

    vm.getAssignmentById = function (ptabID) {
      return HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTBYID + ptabID)
        .then(function (successResponse) {
            $scope.item = successResponse.data;
            $scope.itemsSelected = [];
            $scope.itemsSelected.push($scope.item);
            return $scope.itemsSelected;
          },
          function (failureResponse) {
            $scope.itemsSelected = [];
            $log.debug(failureResponse);
            return failureResponse;
          });
    };

    function openPromoteToAppealModal(row) {
      ngDialog.open({
              template: "app/components/widgets/assignments/src/promoteToAppealAdminModal.html",
              controller: 'PromoteToAppealAdminModalController',
              scope: $scope,
              width: '80%',
              showClose: false,
              closeByEscape: false,
              closeByDocument: false,
              resolve: {
                items: function () {
                  return $scope.itemsSelected;
                }
              }
            }).closePromise.then(function (refreshGrid) {
                $scope.refreshGrid();
               $scope.$$childTail.$$prevSibling.searchText = undefined;
            }, function () {
              // intentional
            });
    }

    /* istanbul ignore next: toaster error*/
    $scope.openupdateAssignmentModal = function (row) {
      if (angular.isDefined(row)) {
        $scope.mySelectedRows = [];
        $scope.mySelectedRows.push(row.entity);
      } else {
        $scope.mySelectedRows = $scope.gridApi.selection.getSelectedRows();
      }

      if ($scope.mySelectedRows.length === 0) {
        CommonHelperService.setToastr("", "clear");
        CommonHelperService.setToastr(CONSTANTS.TOASTER.selectRow, "error");
      } else {
        vm.getAssignmentById($scope.mySelectedRows[0].assignmentIdentifier).then(function () {
          if (($scope.itemsSelected[0].assigneeRoleCode === 'Judge' && $scope.circulationJudgeAssignments.includes($scope.itemsSelected[0].assignmentType)) || $scope.circulationAssignments.includes($scope.itemsSelected[0].assignmentType)) {
            window.open("#/circulation/" + row.entity.FK_AD_FK_AA_SERIAL_NO + "/" + row.entity.FK_AD_FK_APPEAL_NO);
          } else if ($scope.itemsSelected[0].assignmentType.indexOf("ATP") === 0){
              openPromoteToAppealModal(row);
          } else {
            $scope.itemsSelected[0].priorityIndicator = $scope.itemsSelected[0].priorityIndicator === 'Y' ? true : false;
            ngDialog.open({
              template: "app/components/widgets/assignments/src/updateAssignmentModal.html",
              controller: 'updateAssignmentManagementController',
              scope: $scope,
              width: '62%',
              appendClassName: 'ngdialog-content-cust',
              showClose: false,
              closeByEscape: false,
              closeByDocument: false,
              resolve: {
                items: function () {
                  return $scope.itemsSelected;
                },
                readOnly: function () {
                  return false;
                }
              }


            }).closePromise.then(function (refreshGrid) {
              if ($rootScope.ngrOpenCreateAssignment===0) {
                var data = {
                  appealNumber:$scope.mySelectedRows[0].FK_AD_FK_APPEAL_NO,
                  assignmentTitle:"Create dismissal assignment",
                  assignmentTypeCode : "CDD",
                  assignmentTypeDisplayName : "Create dismissal draft"
                 };
                 $scope.openAssignmentDialog(data);
              }
              $rootScope.ngrOpenCreateAssignment=null;

              if (refreshGrid.value) {
                $scope.refreshGrid();
                $scope.$$childTail.$$prevSibling.searchText = undefined;
              }
              delete $rootScope.sharedItems;
            }, function () {
              // Cancel button from modal
            });
          }
        });
      }
    };

       /* istanbul ignore next */
       $scope.openAssignmentDialog = function (dataToPass) {
        var initData={};
        if (dataToPass) {
          initData=dataToPass;
        }
        $scope.data = {};
        ngDialog.open({
          template: "app/components/widgets/assignments/src/createAssignment.html",
          controller: 'CreateAssignmentController',
          scope: $scope,
          width: '60%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
  
          resolve: {
            newData: function () {
              return $scope.data;
            },
            initData: function() {
              return initData;
            }
          }
        }).closePromise.then(function (refreshGrid) {
          if (refreshGrid.value) {
            $timeout(function () {
              $scope.refreshGrid();
            }, 400);
            $log.debug("dialog closed from assignment file");
          }
  
        }, function () {
          // intentional
        });
      };

    function getCirculationAssignments() {
      HttpFactory.getActions("/reference-data/code-reference-types?typeCode=CIRCULATION_MANAGER")
        .then(function (successResponse) {
          $scope.circulationAssignments = successResponse.data[0].descriptionText.split('~');
        }, function (failureResponse) {
          console.log(failureResponse);
        });
    }

    getCirculationAssignments();

    function getCirculationJudgeAssignments() {
      HttpFactory.getActions("/reference-data/code-reference-types?typeCode=CIRCULATION_JUDGE")
        .then(function (successResponse) {
          $scope.circulationJudgeAssignments = successResponse.data[0].descriptionText.split('~');
        }, function (failureResponse) {
          console.log(failureResponse);
        });
    }

    getCirculationJudgeAssignments();

    function selectAssignmentRows() {

      if ($scope.gridApi) {
        $scope.gridApi.selection.clearSelectedRows();
      }
      $scope.selectedRows = [];
      angular.forEach(vm.failedReassignments, function (assignment) {
        angular.forEach($scope.assignmentGridOptions.data, function (dataAssignment) {
          if (assignment.assignmentIdentifier === dataAssignment.assignmentIdentifier) {
            $scope.gridApi.grid.modifyRows($scope.assignmentGridOptions.data);
            $scope.gridApi.selection.selectRow(dataAssignment);
          }
        });
      });
    }

    $scope.searchData = true;
    $scope.buttonData = false;
    /* istanbul ignore next*/
    angular.element($window).on('resize', function () {
      if ($window.innerWidth <= 991) {
        $scope.buttonData = true;
      } else {
        $scope.buttonData = false;
      }
    });
  });
