(function () {
  'use strict';

  describe('workQueueController', function () {

    beforeEach(module('ptabe2e'));

    var vm = this;
    var scope;
    var controller, $controller, row;
    var $http, $interval, $log, $rootScope, spy, timeout, url, advancedSearchFlag, row, rowRenderIndex, col;
    var $q, HttpFactoryDeferred;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'getOpenDialogs', 'close', 'open']);

    var successResponse = {
      data: {
        events: {},
        refreshInterval: 0
      }
    };

    var failureResponse = '';

    var refreshGrid = {
      value: "data"
    }
    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              getWidgetZone: function () {

              },
              setWidgetContentHeight: function () {

              }
            }
          }
        },

        on: function () {

        }

      }
    };
    var fakeVm = {
      getWidgetZone: function () {

      },
      setWidgetContentHeight: function () {

      }
    };

    beforeEach(inject(function (_$controller_, _$http_, _$rootScope_, _$interval_, $compile, _$q_, HttpFactory, CONSTANTS) {
      $q = _$q_;
      $http = _$http_;
      scope = _$rootScope_.$new();
      $interval = _$interval_;
      $rootScope = _$rootScope_;


      $rootScope.userInfo = {
        "userId": "pgandhi"
      }


      // setup the promise
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      $controller = _$controller_;

      scope.definition = {
        dataUrlText: 'http://localhost:8080/PTABServices/',
        widgetIdentifier: 12
      }


      spy = spyOn(angular, 'element').and.callFake(fakeElement);


      scope.$parent = {
        $parent: {
          $parent: {
            definition: {
              zoneWidth: 12
            }
          }
        }
      }

      ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback1) {
            callback1(refreshGrid);
            // callback2();
          }
        },
        then: function (callback3, callback4) {
          callback3();
          callback4();
        }
      });
      controller = $controller('workQueueController', {
        $http: $http,
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        $interval: $interval,
        HttpFactory: HttpFactory

      });

      // spyOn($rootScope, '$on').and.callThrough();
    }));


    afterEach(function () {
      spy.and.callThrough();
    });


    describe('check functions', function () {

      it('Should invoke getWorker', function () {
        var $event = {};
        $event.keyCode = 13;
        url = "https://ptab-q318-services-eap-0.sit.uspto.gov:8443/PTABAppeals/#/", advancedSearchFlag = true;
        spyOn(scope, 'setUrl');
        expect(scope['setUrl']).toBeDefined();
        expect(scope['onKeyup']).toBeDefined();
        scope.onKeyup(url, advancedSearchFlag, $event);
        expect(scope.setUrl).toHaveBeenCalledWith(url, advancedSearchFlag);
      });


      it(' should call setUrl', function () {
        url = "https://ptab-q318-services-eap-0.sit.uspto.gov:8443/PTABAppeals/#/", advancedSearchFlag = true;
        expect(scope['setUrl']).toBeDefined();
        scope.setUrl(url, advancedSearchFlag);
      });

      it(' should call setUrl', function () {
        url = "https://ptab-q318-services-eap-0.sit.uspto.gov:8443/PTABAppeals/#/", advancedSearchFlag = false;
        expect(scope['setUrl']).toBeDefined();
        scope.setUrl(url, advancedSearchFlag);
      });

      it(' should call getAssignments ', function () {

        successResponse = {
          data: [{
            "columnDetails": [{
                "columnName": [
                  "alert"
                ],
                "columnLabel": "Alerts",
                "columnType": "string",
                "defaultOrder": "asc",
                "visible": true,
                "mandatory": true,
                "width": 95,
                "sort": {},
                "filters": [{}],
                "cellTemplate": "<div style=\"margin-left: 10px; margin-top: 7px;\"><i ng-if=\"row.entity.alerts[0] !== ' '\" uib-tooltip=\"Critical indicator\" tooltip-placement=\"right\" class=\"fas fa-flag\" style=\"color: red\"></i><i ng-if=\"row.entity.alerts[1] !== ' '\" uib-tooltip=\"New assignment\" tooltip-placement=\"right\" class=\"fas fa-plus-circle\" style=\"color: green\"></i><i ng-if=\"row.entity.alerts[2] !== ' '\" uib-tooltip=\"Assignment is due today ({{row.entity.ASSIGNMENT_DUE_DT | date:'MM/dd/yyyy'}})\" tooltip-placement=\"right\" class=\"far fa-clock\" style=\"color:#F2A900\"></i><i ng-if=\"row.entity.alerts[3] !== ' '\" uib-tooltip=\"Assignment is past due ({{row.entity.ASSIGNMENT_DUE_DT | date:'MM/dd/yyyy'}})\" tooltip-placement=\"right\" class=\"fas fa-exclamation\" style=\"color: red\"></i><i ng-if=\"row.entity.alerts[4] !== ' '\" uib-tooltip=\"User is inactive\" tooltip-placement=\"right\" class=\"fas fa-user-times\"></i></div>"
              },
              {
                "columnName": [
                  "FK_ASSIGNMENT_TYPE_CD",
                  "assignmentTypeDescription"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Assignment type",
                "columnType": "string",
                "defaultOrder": "asc",
                "visible": true,
                "mandatory": false,
                "width": 200,
                "sort": {},
                "filters": [{}]
              },
              {
                "columnName": [
                  "COMPLETION_DT"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Completion date",
                "columnType": "date",
                "defaultOrder": "asc",
                "visible": true,
                "mandatory": false,
                "width": 200,
                "sort": {},
                "filters": [{}],
                "cellFilter": "date:'MM/dd/yyyy'"
              },
              {
                "columnName": [
                  "LAST_MODIFIED_TS"
                ],
                "aliasName": "assignmentLastModifiedTs",
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Last modified timeStamp",
                "columnType": "date",
                "defaultOrder": "asc",
                "visible": true,
                "mandatory": false,
                "width": 200,
                "sort": {},
                "filters": [{}],
                "cellFilter": "date:'MM/dd/yyyy hh:mm:ss a'"
              },
              {
                "columnName": [
                  "LAST_MODIFIED_USER_ID",
                  "lastModifiedUserName"
                ],
                "aliasName": "assignmentLastModifiedUids",
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Last modified user",
                "columnType": "string",
                "defaultOrder": "asc",
                "visible": true,
                "mandatory": false,
                "width": 200,
                "sort": {},
                "filters": [{}]
              },
              {
                "columnName": [
                  "FK_ASSIGNEE_BE_NO",
                  "assigneeName"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Assigned to",
                "columnType": "string",
                "defaultOrder": "asc",
                "visible": true,
                "mandatory": true,
                "width": 200,
                "sort": {},
                "filters": [{}],
                "cellTemplate": "<div style=\"cursor: pointer; margin-left: 8px; padding-top:5px\" class=\"truncateTitle\"><i class=\"fas fa-user-times pull-left\" role=\"button\" tabindex=\"0\" id=\"{{COL_FIELD}}\" title=\"InActive indicator\" ng-if=\"row.entity.employeeDetails[0].assigneeStatus==='InActive'\" style=\"margin-top: 2.5px; margin-right: -16px; margin-left: 2px; color:red;\" id=\"{{COL_FIELD}}\" title=\"InActive indicator\"></i><span style=\"margin-left: 22px;\" ng-class=\"{'mrgnTwoPx':row.entity.employeeDetails[0].assigneeStatus==='InActive'}\" >{{COL_FIELD}}</span></div>"
              },
              {
                "columnName": [
                  "FK_AD_FK_APPEAL_NO"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Case #",
                "columnType": "number",
                "defaultOrder": "asc",
                "visible": true,
                "mandatory": false,
                "width": 200,
                "sort": {},
                "filters": [{}],
                "cellTemplate": "<div style=\"cursor: pointer; margin-left: 8px; padding-top:5px; text-decoration: underline;\" class=\"truncateTitle\"><a ng-click=\"grid.appScope.openCaseViewer(row)\" target=\"_blank\" id=\"{{COL_FIELD}}\">{{COL_FIELD}}</a>"
              },
              {
                "columnName": [
                  "FK_AD_FK_AA_SERIAL_NO"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Application #",
                "columnType": "string",
                "defaultOrder": "asc",
                "visible": true,
                "mandatory": true,
                "width": 200,
                "sort": {},
                "filters": [{}],
                "cellTemplate": "<div style=\"cursor: pointer; margin-left: 8px; padding-top:5px; text-decoration: underline;\" class=\"truncateTitle\"><a ng-click=\"grid.appScope.openCaseViewer(row)\" target=\"_blank\"  id=\"{{COL_FIELD}}\">{{COL_FIELD}}</a>"
              },
              {
                "columnName": [
                  "PALM_MAILED_DT"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Palm mailed date",
                "columnType": "date",
                "defaultOrder": "asc",
                "visible": true,
                "mandatory": false,
                "width": 200,
                "sort": {},
                "filters": [{}],
                "cellFilter": "date:'MM/dd/yyyy'"
              },
              {
                "columnName": [
                  "ASSIGNMENT_DUE_DT"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Due date",
                "columnType": "date",
                "defaultOrder": "desc",
                "visible": true,
                "mandatory": true,
                "width": 200,
                "sort": {},
                "filters": [{}],
                "cellFilter": "date:'MM/dd/yyyy'",
                "cellTemplate": "<div ng-class=\"{'grid-highlight-active': row.entity.dueDateStatus === 'NEW', 'grid-highlight-warning': row.entity.dueDateStatus === 'TODAY', 'grid-highlight-danger':row.entity.dueDateStatus === 'PASTDUE'}\"><div class=\"ui-grid-cell-contents\">{{COL_FIELD | date:'MM/dd/yyyy'}}</div></div>"
              },
              {
                "columnName": [
                  "assigneeHistory"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Audit log",
                "columnType": "string",
                "defaultOrder": "desc",
                "visible": true,
                "mandatory": false,
                "width": 200,
                "sort": {},
                "filters": [{}],
                "cellTemplate": "<div class=\"truncateTitle\" style=\"cursor: pointer; margin-left: 8px; padding-top:5px; text-decoration: underline;\"><a role=\"button\" tabindex=\"0\" ng-click=\"grid.appScope.openAssignmentHistory(row)\" target=\"_blank\" id=\"{{COL_FIELD}}\">Audit log <i class=\"fas fa-external-link-alt\"></i></a></div>"
              },
              {
                "columnName": [
                  "ASSIGNED_DT"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Assigned date",
                "columnType": "date",
                "defaultOrder": "desc",
                "visible": true,
                "mandatory": true,
                "width": 200,
                "sort": {},
                "filters": [{}],
                "cellFilter": "date:'MM/dd/yyyy'"
              },
              {
                "columnName": [
                  "FK_ASSIGNMENT_STATUS_CD"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Assignment status code",
                "columnType": "string",
                "defaultOrder": "desc",
                "visible": false,
                "mandatory": false,
                "width": 200,
                "sort": {},
                "filters": [{}]
              },
              {
                "columnName": [
                  "FK_ASSIGNOR_BE_NO",
                  "assignorName"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Assignor",
                "columnType": "String",
                "defaultOrder": "desc",
                "visible": false,
                "mandatory": false,
                "width": 200,
                "sort": {},
                "filters": [{}]
              },
              {
                "columnName": [
                  "CREATOR_USER_ID"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Created by",
                "columnType": "String",
                "defaultOrder": "asc",
                "visible": false,
                "mandatory": false,
                "width": 140,
                "sort": {},
                "filters": [{}]
              },
              {
                "columnName": [
                  "TASK_DESC_TX"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Description",
                "columnType": "string",
                "defaultOrder": "asc",
                "visible": false,
                "mandatory": false,
                "width": 200,
                "sort": {},
                "filters": [{}]
              },
              {
                "columnName": [
                  "COMMENT_TX"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Note text",
                "columnType": "string",
                "defaultOrder": "desc",
                "visible": false,
                "mandatory": false,
                "width": 200,
                "sort": {},
                "filters": [{}]
              },
              {
                "columnName": [
                  "TASK_TITLE_TX"
                ],
                "tableName": "PTAB_ASSIGNMENT",
                "columnLabel": "Title",
                "columnType": "string",
                "defaultOrder": "asc",
                "visible": false,
                "mandatory": false,
                "width": 200,
                "sort": {},
                "filters": [{}],
                "cellTemplate": "<div style=\"cursor: pointer; margin-left: 8px; padding-top:5px; text-decoration: underline;\" class=\"truncateTitle\"><a role=\"button\" tabindex=\"0\" ng-click=\"grid.appScope.openupdateAssignmentModal(row)\" target=\"_blank\" id=\"{{COL_FIELD}}\"><u>{{COL_FIELD}}</u></a></div>;"
              }
            ],
            "assignmentsData": [{
                "FK_ASSIGNOR_BE_NO": "5768",
                "FK_ASSIGNMENT_TYPE_CD": "ATP2",
                "creatorUserName": "Gandhi, Parin ",
                "CREATOR_USER_ID": "pgandhi",
                "ASSIGNED_DT": 1537819989000,
                "COMMENT_TX": null,
                "assignorName": "Gandhi, Parin ",
                "FK_ASSIGNEE_BE_NO": "5768",
                "dueDateStatus": "TODAY",
                "FK_ASSIGNMENT_STATUS_CD": "A",
                "ASSIGNMENT_DUE_DT": 1537848000000,
                "FK_AD_FK_AA_SERIAL_NO": "14009317",
                "assignmentTypeDescription": "Review Checklist Assignment To POC2",
                "assigneeName": "Gandhi, Parin ",
                "standardAssignmentType": [
                  "Assignment info"
                ],
                "FK_AD_FK_APPEAL_NO": 0,
                "assigneeHistory": "test",
                "assignmentStatus": "Active",
                "COMPLETION_DT": null,
                "TASK_DESC_TX": "assigned to div",
                "lastModifiedUserName": "Korem, Divesh Reddy",
                "LAST_MODIFIED_TS": 1537819989000,
                "PALM_MAILED_DT": null,
                "assignmentIdentifier": 2396,
                "alerts": [
                  "PRIORITY",
                  " ",
                  "DUEDAY",
                  " ",
                  " ",
                  "END"
                ],
                "employeeDetails": [{
                  "assigneeNumberText": "5768",
                  "assigneeFullNameText": "Gandhi, Parin ",
                  "activeCaseCount": 70,
                  "assigneeStatus": "Active",
                  "userRoles": [{
                    "roleCode": "PTABE2E_Administrator",
                    "roleDescription": "Business Admin"
                  }]
                }],
                "LAST_MODIFIED_USER_ID": "dkorem",
                "alertText": "PRIORITY, ,DUEDAY, , ,END",
                "TASK_TITLE_TX": "dfsds check divesh"
              },
              {
                "FK_ASSIGNOR_BE_NO": "5768",
                "FK_ASSIGNMENT_TYPE_CD": "ATP1",
                "creatorUserName": "Gandhi, Parin ",
                "CREATOR_USER_ID": "pgandhi",
                "ASSIGNED_DT": 1537565749000,
                "COMMENT_TX": "14057456",
                "assignorName": "Gandhi, Parin ",
                "FK_ASSIGNEE_BE_NO": "5768",
                "dueDateStatus": " ",
                "FK_ASSIGNMENT_STATUS_CD": "A",
                "ASSIGNMENT_DUE_DT": 1538409597000,
                "FK_AD_FK_AA_SERIAL_NO": "14057456",
                "assignmentTypeDescription": "Review Checklist Assignment To POC1",
                "assigneeName": "Gandhi, Parin ",
                "standardAssignmentType": [
                  "Assignment info"
                ],
                "FK_AD_FK_APPEAL_NO": 0,
                "assigneeHistory": "test",
                "assignmentStatus": "Active",
                "COMPLETION_DT": null,
                "TASK_DESC_TX": "Import manager default description",
                "lastModifiedUserName": "Gandhi, Parin ",
                "LAST_MODIFIED_TS": 1537565749000,
                "PALM_MAILED_DT": null,
                "assignmentIdentifier": 2277,
                "alerts": [
                  " ",
                  " ",
                  " ",
                  " ",
                  " ",
                  "END"
                ],
                "employeeDetails": [{
                  "assigneeNumberText": "5768",
                  "assigneeFullNameText": "Gandhi, Parin ",
                  "activeCaseCount": 70,
                  "assigneeStatus": "Active",
                  "userRoles": [{
                    "roleCode": "PTABE2E_Administrator",
                    "roleDescription": "Business Admin"
                  }]
                }],
                "LAST_MODIFIED_USER_ID": "pgandhi",
                "alertText": " , , , , ,END",
                "TASK_TITLE_TX": "Import manager default title"
              }
            ],
            "hierarchy": true,
            descriptionText: "CDDD"
          }]

        };
        scope.gridApi = {
          grid: {

          }
        }

        var textToSearch = 'pgandhi';
        // spyOn(scope, 'simpleSearch')
        // expect(scope['simpleSearch']).toBeDefined();
        expect(scope['getAssignments']).toBeDefined();
        scope.getAssignments();


        HttpFactoryDeferred.resolve(successResponse);
        // $rootScope.$apply();
        scope.$digest();
        // $rootScope.$digest();

        // expect(scope['simpleSearch']).toHaveBeenCalledWith(undefined);
      });

      it('listItemUp should call move item', function () {

        expect(scope.listItemUp).toBeDefined();
        spyOn(scope, 'moveItem');
        expect(scope['moveItem']).toBeDefined();
        scope.listItemUp(1);
        expect(scope.moveItem).toHaveBeenCalledWith(1, 0);

      });

      it('listItemDown should call move item', function () {
        expect(scope.listItemDown).toBeDefined();
        spyOn(scope, 'moveItem');
        expect(scope['moveItem']).toBeDefined();
        scope.listItemDown(1);
        expect(scope.moveItem).toHaveBeenCalledWith(1, 2);

      });

      it('it should open showFilteringHelp ', function () {

        var existingCount = ngDialog.open.calls.count();
        expect(scope.showFilteringHelp).toBeDefined();
        scope.showFilteringHelp();
        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(existingCount + 1);
        var args = ngDialog.open.calls.argsFor(existingCount);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('CommonDialogController');
      });

      it('Should invoke simpleSearch', function () {
        var textToSearch = "pgandhi"
        scope.gridOptions = {
          data: [{}]
        }
        expect(scope['simpleSearch']).toBeDefined();
        scope.simpleSearch(textToSearch);
      });

      it(' should call openCaseViewer', function () {
        row = {
          entity: {
            fkAdFkAppealNo: '2018005819',
            fkAdFkAaSerialNo: '15007114'
          }
        }
        expect(scope['openCaseViewer']).toBeDefined();
        scope.openCaseViewer(row);
      });


      it(' should call setPaginationManually ', function () {
        expect(scope['setPaginationManually']).toBeDefined();
        scope.setPaginationManually();
      });

      it('Should invoke getWorker', function () {
        var event = {};
        event.keyCode = 13;

        var searchText = 'pgandhi';

        spyOn(scope, 'simpleSearch');
        expect(scope['simpleSearch']).toBeDefined();
        expect(scope['pressEnter']).toBeDefined();
        scope.pressEnter(event, searchText);
        expect(scope.simpleSearch).toHaveBeenCalled();
      });

      it('Should not invoke getWorker', function () {
        var event = {};
        event.keyCode = 14;
        var searchText = 'pgandhi';
        spyOn(scope, 'simpleSearch');
        expect(scope['simpleSearch']).toBeDefined();
        expect(scope['pressEnter']).toBeDefined();
        scope.pressEnter(event, searchText);
        expect(scope.simpleSearch).not.toHaveBeenCalled();
      });

      it(' should call openAssignmentHistory ', function () {
        scope.assignData = {
          "beNo": "5768"
        }
        row = {
          entity: {
            fkAdFkAppealNo: '2018005819',
            fkAdFkAaSerialNo: '15007114'
          }
        }

        expect(scope['openAssignmentHistory']).toBeDefined();
        scope.openAssignmentHistory(row);

        expect(ngDialog.open).toHaveBeenCalled();

        expect(ngDialog.open.calls.count()).toBe(2);
        var args = ngDialog.open.calls.argsFor(1);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('AssignmentHistoryController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.assignmentData();
      });

    });

    it('should call getAssignmentColumns', function () {
      successResponse = {
        "data": [{
          "selectedColumns": [{
            "columnType": "string",
            "cellTemplate": "<div style=\"margin-left: 10px; margin-top: 7px;\"><i ng-if=\"row.entity.alerts[0] !== ' '\" uib-tooltip=\"Critical indicator\" tooltip-placement=\"right\" class=\"fas fa-flag\" style=\"color: red; margin-right:4px;\"></i><i ng-if=\"row.entity.alerts[1] !== ' '\" uib-tooltip=\"New assignment\" tooltip-placement=\"right\" class=\"fas fa-plus-circle\" style=\"color: green; margin-right:4px;\"></i><i ng-if=\"row.entity.alerts[2] !== ' '\" uib-tooltip=\"Assignment is due today ({{row.entity.ASSIGNMENT_DUE_DT | date:'MM/dd/yyyy'}})\" tooltip-placement=\"right\" class=\"far fa-clock\" style=\"color:#F2A900; margin-right:4px;\"></i><i ng-if=\"row.entity.alerts[3] !== ' '\" uib-tooltip=\"Assignment is past due ({{row.entity.ASSIGNMENT_DUE_DT | date:'MM/dd/yyyy'}})\" tooltip-placement=\"right\" class=\"fas fa-exclamation\" style=\"color: red; margin-right:4px;\"></i><i ng-if=\"row.entity.alerts[4] !== ' '\" uib-tooltip=\"User is inactive\" tooltip-placement=\"right\" class=\"fas fa-user-times\"></i></div>",
            "pinned": "right",
            "visible": true,
            "columnLabel": "Alerts",
            "defaultOrder": "asc",
            "width": 95,
            "sort": {},
            "filters": [{}],
            "mandatory": true,
            "columnName": ["alert"]
          }, {
            "columnType": "string",
            "pinned": "",
            "visible": true,
            "columnLabel": "Assignment type",
            "defaultOrder": "asc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["FK_ASSIGNMENT_TYPE_ID", "assignmentTypeDescription"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "string",
            "cellTemplate": "<div style=\"cursor: pointer; margin-left: 8px; padding-top:5px; text-decoration: underline;\" class=\"truncateTitle\"><a role=\"button\" href ng-click=\"grid.appScope.openupdateAssignmentModal(row)\" target=\"_blank\" id=\"{{COL_FIELD}}\"><u>{{COL_FIELD}}</u></a></div>;",
            "pinned": "left",
            "visible": true,
            "columnLabel": "Title",
            "defaultOrder": "asc",
            "width": 234,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["TASK_TITLE_TX"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "aliasName": "assignmentLastModifiedTs",
            "pinned": "",
            "visible": true,
            "sort": {
              "priority": 0,
              "direction": "desc"
            },
            "filters": [{}],
            "mandatory": false,
            "cellFilter": "date:'MM/dd/yyyy hh:mm:ss a'",
            "tableName": "PTAB_ASSIGNMENT",
            "columnType": "date",
            "columnLabel": "Last modified timeStamp",
            "defaultOrder": "asc",
            "width": 200,
            "columnName": ["LAST_MODIFIED_TS"]
          }, {
            "aliasName": "assignmentLastModifiedUids",
            "columnType": "string",
            "pinned": "",
            "visible": true,
            "columnLabel": "Last modified user",
            "defaultOrder": "asc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["LAST_MODIFIED_USER_ID", "lastModifiedUserName"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "string",
            "cellTemplate": "<div style=\"cursor: pointer; margin-left: 8px; padding-top:5px\" class=\"truncateTitle\"><i class=\"fas fa-user-times pull-left\" role=\"button\" href id=\"{{COL_FIELD}}\" title=\"InActive indicator\" ng-if=\"row.entity.assigneeStatus==='InActive'\" style=\"margin-top: 2.5px; margin-right: -16px; margin-left: 2px; color:red;\" id=\"{{COL_FIELD}}\" title=\"InActive indicator\"></i><span style=\"margin-left: 22px;\" ng-class=\"{'mrgnTwoPx':row.entity.assigneeStatus==='InActive'}\" >{{COL_FIELD}}</span></div>",
            "pinned": "",
            "visible": true,
            "columnLabel": "Assigned to",
            "defaultOrder": "asc",
            "width": 279,
            "sort": {},
            "filters": [{}],
            "mandatory": true,
            "columnName": ["FK_ASSIGNEE_BE_NO", "assigneeName"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "number",
            "cellTemplate": "<div style=\"cursor: pointer; margin-left: 8px; padding-top:5px; text-decoration: underline;\" class=\"truncateTitle\"><a href ng-click=\"grid.appScope.openCaseViewer(row)\" target=\"_blank\" id=\"{{COL_FIELD}}\">{{COL_FIELD}}</a>",
            "pinned": "",
            "visible": false,
            "columnLabel": "Case #",
            "defaultOrder": "asc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["FK_AD_FK_APPEAL_NO"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "string",
            "cellTemplate": "<div style=\"cursor: pointer; margin-left: 8px; padding-top:5px; text-decoration: underline;\" class=\"truncateTitle\"><a href ng-click=\"grid.appScope.openCaseViewer(row)\" target=\"_blank\"  id=\"{{COL_FIELD}}\">{{COL_FIELD}}</a>",
            "pinned": "",
            "visible": true,
            "columnLabel": "Application #",
            "defaultOrder": "asc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": true,
            "columnName": ["FK_AD_FK_AA_SERIAL_NO"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "String",
            "pinned": "",
            "visible": true,
            "columnLabel": "Assignor",
            "defaultOrder": "desc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["FK_ASSIGNOR_BE_NO", "assignorName"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "String",
            "pinned": "",
            "visible": true,
            "columnLabel": "Created by",
            "defaultOrder": "asc",
            "width": 140,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["CREATOR_USER_ID"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "date",
            "pinned": "",
            "visible": true,
            "columnLabel": "Palm mailed date",
            "defaultOrder": "asc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "cellFilter": "date:'MM/dd/yyyy'",
            "columnName": ["PALM_MAILED_DT"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "cellTemplate": "<div ng-class=\"{'grid-highlight-active': row.entity.dueDateStatus === 'NEW', 'grid-highlight-warning': row.entity.dueDateStatus === 'TODAY', 'grid-highlight-danger':row.entity.dueDateStatus === 'PASTDUE'}\"><div class=\"ui-grid-cell-contents\">{{COL_FIELD | date:'MM/dd/yyyy'}}</div></div>",
            "pinned": "",
            "visible": true,
            "sort": {},
            "filters": [{}],
            "mandatory": true,
            "cellFilter": "date:'MM/dd/yyyy'",
            "tableName": "PTAB_ASSIGNMENT",
            "columnType": "date",
            "columnLabel": "Due date",
            "defaultOrder": "desc",
            "width": 200,
            "columnName": ["ASSIGNMENT_DUE_DT"]
          }, {
            "columnType": "string",
            "cellTemplate": "<div class=\"truncateTitle\" style=\"cursor: pointer; margin-left: 8px; padding-top:5px; text-decoration: underline;\"><a role=\"button\" href ng-click=\"grid.appScope.openAssignmentHistory(row)\" target=\"_blank\" id=\"{{COL_FIELD}}\">Audit log <i class=\"fas fa-external-link-alt\"></i></a></div>",
            "pinned": "",
            "visible": true,
            "columnLabel": "Audit log",
            "defaultOrder": "desc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["assigneeHistory"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "date",
            "pinned": "",
            "visible": true,
            "columnLabel": "Assigned date",
            "defaultOrder": "desc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": true,
            "cellFilter": "date:'MM/dd/yyyy'",
            "columnName": ["ASSIGNED_DT"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "string",
            "pinned": "",
            "visible": true,
            "columnLabel": "Assignment status code",
            "defaultOrder": "desc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["FK_ASSIGNMENT_STATUS_CD"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "date",
            "pinned": "",
            "visible": true,
            "columnLabel": "Completion date",
            "defaultOrder": "asc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "cellFilter": "date:'MM/dd/yyyy'",
            "columnName": ["COMPLETION_DT"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "string",
            "pinned": "",
            "visible": true,
            "columnLabel": "Description",
            "defaultOrder": "asc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["TASK_DESC_TX"],
            "tableName": "PTAB_ASSIGNMENT"
          }, {
            "columnType": "string",
            "pinned": "",
            "visible": true,
            "columnLabel": "Note text",
            "defaultOrder": "desc",
            "width": 200,
            "sort": {},
            "filters": [{}],
            "mandatory": false,
            "columnName": ["COMMENT_TX"],
            "tableName": "PTAB_ASSIGNMENT"
          }],
          "allowedResourceObjectList": ["panel_Update"],
          "ptabReadOnlyUser": false,
          "userWorkspaceWidgetIdentifier": 2262,
          "paginationSize": 10,
          descriptionText: "CDDD"
        }],
        "status": 200,
        "config": {
          "method": "GET",
          "transformRequest": [null],
          "transformResponse": [null],
          "url": "https://ptab-services1.sit.uspto.gov/PTABAppealsServices/user-workspace-widgets/columns/2262",
          "withCredentials": true,
          "crossDomain": true,
          "headers": {
            "user-name": "sbartlett",
            "Accept": "application/json, text/plain, */*"
          }
        },
        "statusText": "OK"
      };

      expect(scope.getAssignmentColumns).toBeDefined();
      scope.getAssignmentColumns();
      // HttpFactoryDeferred.resolve(successResponse);
      // scope.$digest();
    });

    it('should call getAssignmentColumns with failureResponse', function () {
      failureResponse = {
        data: "Failed"
      };
      expect(scope.getAssignmentColumns).toBeDefined();
      scope.getAssignmentColumns();
      HttpFactoryDeferred.reject(failureResponse);
      scope.$digest();
    });

    it('moveItem should swap origin and destination', function () {
      var origin = 0,
        destination = 1;
      var selectedCols = [{
        'userFavoritesName': 'testFavouriteOrigin',
        'userFavoritesURL': 'google.com'
      }, {
        'userFavoritesName': 'testFavouriteDest',
        'userFavoritesURL': 'bin.com'
      }];
      var selectedColsCopy = [{
        'userFavoritesName': 'testFavouriteOrigin',
        'userFavoritesURL': 'google.com'
      }, {
        'userFavoritesName': 'testFavouriteDest',
        'userFavoritesURL': 'bin.com'
      }];
      scope.selectedCols = selectedCols;
      expect(scope.moveItem).toBeDefined();
      scope.moveItem(origin, destination);

      expect(scope.selectedCols[0].userFavoritesName).not.toBe(selectedColsCopy[0].userFavoritesName);
      expect(scope.selectedCols[0].userFavoritesURL).not.toBe(selectedColsCopy[0].userFavoritesURL);

    });


    it('should call moveSourcetoDestination', function () {
      scope.clickedColumn = [{
        mandatory: false
      }]
      scope.availableCols = [{
        mandatory: false
      }]
      scope.selectedCols = [];
      expect(scope.moveSourcetoDestination).toBeDefined();
      //scope.moveSourcetoDestination();
    });


    it('should call moveSourcetoDestinationCancel', function () {
      var index = 0;
      scope.selectedCols = [{
        visible: true
      }]
      scope.availableCols = [];
      expect(scope.moveSourcetoDestinationCancel).toBeDefined();
      scope.moveSourcetoDestinationCancel(index);
    });


    it('should call toggleSelectAll', function () {
      scope.availableCols = [{
        mandatory: false
      }]
      scope.selectedCols = [];
      expect(scope.toggleSelectAll).toBeDefined();
      scope.toggleSelectAll();
    });


    it('should call removeAll with madatory as false', function () {
      scope.selectedCols = [{
        mandatory: false
      }]
      scope.availableCols = [];
      expect(scope.removeAll).toBeDefined();
      scope.removeAll();
    });


    it('should call removeAll with madatory as true', function () {
      scope.selectedCols = [{
        mandatory: true
      }]
      scope.availableCols = [];
      expect(scope.removeAll).toBeDefined();
      scope.removeAll();
    });


  });
})();
