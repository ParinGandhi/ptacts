'use strict';

angular.module('adf.widget.exportCaseDockets', ['adf.provider'])
  .config(function (dashboardProvider) {
    dashboardProvider
      .widget('exportCaseDockets', {
        title: 'Export Case Dockets',
        description: 'Export Case Dockets Widget',
        templateUrl: '{widgetsPath}/exportCaseDockets/src/view.html',
        controller: 'ExportCaseDocketController',
        controllerAs: 'vm',
        edit: {
          templateUrl: '{widgetsPath}/exportCaseDockets/src/edit.html'
        }
      });
  })
  .controller('ExportCaseDocketController', ['$log', '$http', '$scope', function ($log, $http, $scope) {
    //Pause the carousel when the indicators are clicked

    var vm = this;
    vm.message = "Hello world";
    vm.tableData = [{
      "id": 1,
      "first_name": "Marianna",
      "last_name": "Trewman",
      "email": "mtrewman0@a8.net",
      "gender": "Female",
      "ip_address": "114.106.121.188"
    }, {
      "id": 2,
      "first_name": "Garfield",
      "last_name": "Fontelles",
      "email": "gfontelles1@topsy.com",
      "gender": "Male",
      "ip_address": "139.54.6.201"
    }, {
      "id": 3,
      "first_name": "Nehemiah",
      "last_name": "Kubek",
      "email": "nkubek2@diigo.com",
      "gender": "Male",
      "ip_address": "120.247.40.88"
    }, {
      "id": 4,
      "first_name": "Cristy",
      "last_name": "Pargeter",
      "email": "cpargeter3@macromedia.com",
      "gender": "Female",
      "ip_address": "208.59.108.149"
    }, {
      "id": 5,
      "first_name": "Kenna",
      "last_name": "Whipple",
      "email": "kwhipple4@miibeian.gov.cn",
      "gender": "Female",
      "ip_address": "139.97.223.116"
    }];

    this.addNewWidgets = function () {
      $scope.$emit('openWidgetLibrary', true);
    };
  }]);
