(function () {
    'use strict';
  
    describe('ExportCaseDocketController', function () {
  
      beforeEach(module('ptabe2e'));
  
      var $controller;
      var vm = this;
      var scope, $rootScope;
      var controller;
      var $http;

      beforeEach(inject(function (_$controller_, _$http_, _$rootScope_) {
    
        $http = _$http_;
        scope = _$rootScope_.$new();
        $rootScope = _$rootScope_;
        $controller = _$controller_;
        
        controller = $controller('ExportCaseDocketController', {
          $http: $http,
          $scope: scope,
          $rootScope: _$rootScope_,

        });
      }));
  
      describe('checking functions', function () {
  
        it('broadcast should broadcast event', function () {

            $controller('ExportCaseDocketController', { $scope: scope });
    
            spyOn(scope, '$emit');      
            expect(controller.addNewWidgets).toBeDefined();
            controller.addNewWidgets();
            expect(scope.$emit).toHaveBeenCalledWith('openWidgetLibrary', true);
    
          });
      
      });
  
    });
  })();
  