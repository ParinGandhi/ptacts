(function () {
  'use strict';

  describe('ImportHeardCaseController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll']);
    var controller, scope, $rootScope;
    var timeout;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;



    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'postPdf').and.returnValue(HttpFactoryDeferred.promise);
      // var createController = function (hearingFile) {
      //   return $controller('ImportHeardCaseController', {
      //     hearingFile: {
      //       files: [{
      //         file: {
      //           name: "fy2018_hearing_schedule_excel+-+sample.xlsx"
      //         }
      //       }],
      //       value: "C:\\fakepath\\fy2018_hearing_schedule_excel+-+sample.xlsx"
      //     }
      //   });
      // }




      controller = $controller('ImportHeardCaseController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory

      });
    }));

    describe('ImportHeardCaseController ', function () {

      it('it should select a valid sheet ', function () {
        var sheet = "June";
        expect(scope['selectedSheet']).toBeDefined();
        scope.selectedSheet(sheet);
      });

      it('it should cancel import hearing ', function () {
        expect(scope['cancelImportHearing']).toBeDefined();
        scope.cancelImportHearing();
      });

      // it('it should call getFileInfo ', function () {
      //   var file1Element = document.createElement('input')
      //   document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(file1Element);
      //   spyOn(document, "getElementById").and.callFake(function () {
      //     var hearingFile = {
      //       files: [{
      //         file: {
      //           name: "fy2018_hearing_schedule_excel+-+sample.xlsx"
      //         }
      //       }],
      //       value: "C:\\fakepath\\fy2018_hearing_schedule_excel+-+sample.xlsx"
      //     };
      //     return hearingFile;
      //   });
      //   expect(scope['getFileInfo']).toBeDefined();
      //   scope.getFileInfo();
      // });

      // it('it should call importHearing ', function () {
      //   scope.selectedSheetFromxl = "June";

      //   successResponse = {
      //     data: {
      //       message: "Successfully imported sheet"
      //     }
      //   };

      //   expect(scope['importHearing']).toBeDefined();
      //   scope.importHearing();

      //   HttpFactoryDeferred.resolve(successResponse);

      // });

    });
  });
})();
