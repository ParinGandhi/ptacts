(function () {
  'use strict';

  describe('MasterDocketController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var controller;
    var scope, $rootScope, $http, $interval;
    var successResponse, failureResponse, isMasterDocket;
    var $httpBackend, spy, $q, HttpFactoryDeferred;
    var $ngDialog = jasmine.createSpyObj('ngDialog', ['open']);
    var columnList, gridState;
    var refreshGrid = {
      value: true
    }
    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              getWidgetZone: function () {

              },
              setWidgetContentHeight: function () {

              }
            },
            gridApi: {
              saveState: {
                save: function () {

                }
              }
            }
          }
        }
      }
    };

    beforeEach(inject(function (_$controller_, _$rootScope_, _$http_, _$httpBackend_, _$interval_, _$q_, HttpFactory) {
      $q = _$q_;
      scope = _$rootScope_.$new();
      $http = _$http_;
      $controller = _$controller_;
      $rootScope = _$rootScope_;
      $httpBackend = _$httpBackend_;
      $ngDialog.open.and.returnValue({
        then: function (callback1, callback2) {
          callback1();
          callback2();
        },
        closePromise: {
          then: function (callback3) {
            callback3(refreshGrid);
          }
        }

      });

      scope.$parent = {
        model: {
          dataUrlText: "masterDocket",
          widgetIdentifier: "4-4"
        }
      }
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      //   scope.$parent = {
      //     model: {
      //       dataUrlText: 'http://localhost:8080/PTABServices/',
      //       widgetIdentifier: 12
      //     }
      //   }

      scope.gridState = {
        "pagination": {
          "paginationPageSize": 10
        },
        "columns": [{
          "columnName": [
            "PROCEEDING_CORE_ID"
          ],
          "columnLabel": "Application/Reexam #",
          "columnType": "string",
          "defaultOrder": "desc",
          "visible": true,
          "mandatory": true,
          "width": 140,
          "sort": {},
          "filters": [{}],
          "pinned": ""
        }]
      }
      scope.definition = {
        dataUrlText: 'http://localhost:8080/PTABServices/',
        widgetIdentifier: 12
      }
      scope.$parent = {
        $parent: {
          $parent: {
            definition: {
              zoneWidth: 12
            }
          }
        }
      }



      controller = $controller('MasterDocketController', {
        $scope: scope,
        $http: $http,
        ngDialog: $ngDialog,
        $rootScope: _$rootScope_,
        $interval: $interval,
        HttpFactory: HttpFactory
      });
    }));

    afterEach(function () {
      spy.and.callThrough();
    });

    describe('MasterDocketController ', function () {
      it('should call openCaseViewer', function () {

        var row = {
          entity: {
            PROCEEDING_CORE_ID: "06000006"
          }
        }
        expect(scope.openCaseViewer).toBeDefined();
        scope.openCaseViewer(row);
      });


      it('get Actions success response getMasterDocketInfo', function () {

        successResponse = {
          data: {
            docketData: [{
              "ADMINISTRATIVE_PATENT_JDG_3_NM": "Murriel, Crawford",
              "PROCEEDING_NO": "2012002432",
              "APPLICATIONSUBCLASS": "040000",
              "ADMINISTRATIVE_PATENT_JDG_1_NM": "Nina, Medlock",
              "HEARINGDATE": null,
              "APPLICATIONTYPE": "PRO",
              "ADMINISTRATIVE_PATENT_JDG_2_NM": "Joseph, Fischetti",
              "PROCEEDING_TYPE": "APP",
              "ATTORNEY_NM": "David, Wood",
              "HEARINGSTATUS": null,
              "ASSIGNMENTDATE": 1400731200000,
              "NEXT_DISPOSITION_DT": null,
              "ARTUNITNUMBER": 3694,
              "PROCEEDING_STATUS_DESC": "Panel Assigned - Appeal Awaiting Decision (selected by Paralegal)",
              "SPECIALTYPE": null,
              "ATTYNUMBER": "84788",
              "PATENT_NO": " ",
              "APPLICATIONCLASS": "705",
              "PROCEEDING_TYPE_NM": "On Brief",
              "ID": 61,
              "PROCEEDING_SUPPLEMENTARY_ID": 1,
              "PROCEEDING_SUB_TYPE": "EX",
              "PROCEEDING_CORE_ID": "11962511"
            }],
            columnDetails: [{
                "columnName": [
                  "PROCEEDING_CORE_ID"
                ],
                "columnLabel": "Application/Reexam #",
                "columnType": "string",
                "defaultOrder": "desc",
                "visible": true,
                "mandatory": true,
                "width": 140,
                "sort": {},
                "filters": [{}],
                "pinned": ""
              },
              {
                "columnName": [
                  "PATENT_NO"
                ],
                "columnLabel": "Patent #",
                "columnType": "string",
                "defaultOrder": "desc",
                "visible": false,
                "mandatory": false,
                "width": 110,
                "sort": {},
                "filters": [{}],
                "pinned": ""
              }


            ]
          }

        };

        expect(scope['getMasterDocketInfo']).toBeDefined();
        scope.getMasterDocketInfo();

        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
      });

      it('failureResponse getMasterDocketInfo', function () {
        var failureResponse = {
          data: {}
        };

        expect(scope.getMasterDocketInfo).toBeDefined();
        scope.getMasterDocketInfo();

        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });


      it('get Actions success response getMasterDocketColumns', function () {

        isMasterDocket = true;

        successResponse = {
          data: {
            selectedColumns: [{
                "columnName": [
                  "PROCEEDING_CORE_ID"
                ],
                "columnLabel": "Application/Reexam #",
                "columnType": "string",
                "defaultOrder": "desc",
                "visible": true,
                "mandatory": true,
                "width": 140,
                "sort": {},
                "filters": [{}],
                "pinned": ""
              },
              {
                "columnName": [
                  "PATENT_NO"
                ],
                "columnLabel": "Patent #",
                "columnType": "string",
                "defaultOrder": "desc",
                "visible": false,
                "mandatory": false,
                "width": 110,
                "sort": {},
                "filters": [{}],
                "pinned": ""
              }


            ]
          }

        };

        expect(scope['getMasterDocketColumns']).toBeDefined();
        scope.getMasterDocketColumns();

        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
      });

      it('failureResponse getMasterDocketColumns', function () {
        var failureResponse = {
          data: {}
        };

        expect(scope.getMasterDocketColumns).toBeDefined();
        scope.getMasterDocketColumns();

        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });

      // it('should invoke saveGridPreferences', function () {

      //   successResponse = {
      //     data: {
      //       selectedColumns: [{
      //           "columnName": [
      //             "PROCEEDING_CORE_ID"
      //           ],
      //           "columnLabel": "Application/Reexam #",
      //           "columnType": "string",
      //           "defaultOrder": "desc",
      //           "visible": true,
      //           "mandatory": true,
      //           "width": 140,
      //           "sort": {},
      //           "filters": [{}],
      //           "pinned": ""
      //         },
      //         {
      //           "columnName": [
      //             "PATENT_NO"
      //           ],
      //           "columnLabel": "Patent #",
      //           "columnType": "string",
      //           "defaultOrder": "desc",
      //           "visible": false,
      //           "mandatory": false,
      //           "width": 110,
      //           "sort": {},
      //           "filters": [{}],
      //           "pinned": ""
      //         }


      //       ]
      //     }

      //   };

      //   expect(scope['saveGridPreferences']).toBeDefined();
      //   scope.saveGridPreferences();

      // });



      // it('should invoke download_csv', function () {

      //   scope.myData = {
      //     docketData: [{
      //       "ADMINISTRATIVE_PATENT_JDG_3_NM": "Murriel, Crawford",
      //       "PROCEEDING_NO": "2012002432",
      //       "APPLICATIONSUBCLASS": "040000",
      //       "ADMINISTRATIVE_PATENT_JDG_1_NM": "Nina, Medlock",
      //       "HEARINGDATE": null,
      //       "APPLICATIONTYPE": "PRO",
      //       "ADMINISTRATIVE_PATENT_JDG_2_NM": "Joseph, Fischetti",
      //       "PROCEEDING_TYPE": "APP",
      //       "ATTORNEY_NM": "David, Wood",
      //       "HEARINGSTATUS": null,
      //       "ASSIGNMENTDATE": 1400731200000,
      //       "NEXT_DISPOSITION_DT": null,
      //       "ARTUNITNUMBER": 3694,
      //       "PROCEEDING_STATUS_DESC": "Panel Assigned - Appeal Awaiting Decision (selected by Paralegal)",
      //       "SPECIALTYPE": null,
      //       "ATTYNUMBER": "84788",
      //       "PATENT_NO": " ",
      //       "APPLICATIONCLASS": "705",
      //       "PROCEEDING_TYPE_NM": "On Brief",
      //       "ID": 61,
      //       "PROCEEDING_SUPPLEMENTARY_ID": 1,
      //       "PROCEEDING_SUB_TYPE": "EX",
      //       "PROCEEDING_CORE_ID": "11962511"
      //     }]
      //   };

      //   scope.selectedColumns = [{
      //       "columnName": [
      //         "PROCEEDING_CORE_ID"
      //       ],
      //       "columnLabel": "Application/Reexam #",
      //       "columnType": "string",
      //       "defaultOrder": "desc",
      //       "visible": true,
      //       "mandatory": true,
      //       "width": 140,
      //       "sort": {},
      //       "filters": [{}],
      //       "pinned": ""
      //     },
      //     {
      //       "columnName": [
      //         "FK_ASSIGNEE_BE_NO"
      //       ],
      //       "columnLabel": "Patent #",
      //       "columnType": "string",
      //       "defaultOrder": "desc",
      //       "visible": false,
      //       "mandatory": false,
      //       "width": 110,
      //       "sort": {},
      //       "filters": [{}],
      //       "pinned": ""
      //     }
      //   ];

      //   expect(scope['download_csv']).toBeDefined();
      //   scope.download_csv();

      // });


      //     it('get Actions success response getViewCaseDocketData', function () {

      //       scope.gridState = {
      //         "pagination": {
      //           "paginationPageSize": 10
      //         }
      //       }
      //       successResponse = {
      //         data: [{
      //           columnDetails: [{
      //               columnName: [
      //                 "PROCEEDING_CORE_ID"
      //               ],
      //               columnLabel: "Application/Reexam #",
      //               columnType: "string",
      //               defaultOrder: "desc",
      //               visible: true,
      //               mandatory: true,
      //               width: 140,
      //               sort: {},
      //               filters: [{}],
      //               pinned: "",
      //             },
      //             {
      //               columnName: [
      //                 "PATENT_NO"
      //               ],
      //               columnLabel: "Patent #",
      //               columnType: "number",
      //               defaultOrder: "desc",
      //               visible: false,
      //               mandatory: false,
      //               width: 110,
      //               sort: {},
      //               filters: [{}],
      //               pinned: "",
      //             },
      //             {
      //               columnName: [
      //                 "PATENT_NO"
      //               ],
      //               columnLabel: "PROCEEDING_NO",
      //               columnType: "date",
      //               defaultOrder: "desc",
      //               visible: false,
      //               mandatory: false,
      //               width: "110",
      //               sort: {},
      //               filters: [{}],
      //               pinned: "",
      //             }
      //           ],

      //           caseDetailsData: [{
      //             ADMINISTRATIVE_PATENT_JDG_3_NM: "Murriel, Crawford",
      //             PROCEEDING_NO: "2012002432",
      //             APPLICATIONSUBCLASS: "040000",
      //             ADMINISTRATIVE_PATENT_JDG_1_NM: "Nina, Medlock",
      //             HEARINGDATE: null,
      //             APPLICATIONTYPE: "PRO",
      //             ADMINISTRATIVE_PATENT_JDG_2_NM: "Joseph, Fischetti",
      //             PROCEEDING_TYPE: "APP",
      //             ATTORNEY_NM: "David, Wood",
      //             HEARINGSTATUS: null,
      //             ASSIGNMENTDATE: 1400731200000,
      //             NEXT_DISPOSITION_DT: null,
      //             ARTUNITNUMBER: 3694,
      //             PROCEEDING_STATUS_DESC: "Panel Assigned - Appeal Awaiting Decision (selected by Paralegal)",
      //             SPECIALTYPE: null,
      //             ATTYNUMBER: "84788",
      //             PATENT_NO: " ",
      //             APPLICATIONCLASS: "705",
      //             PROCEEDING_TYPE_NM: "On Brief",
      //             ID: 61,
      //             PROCEEDING_SUPPLEMENTARY_ID: 1,
      //             PROCEEDING_SUB_TYPE: "EX",
      //             PROCEEDING_CORE_ID: "11962511",
      //           }]

      //         }]

      //       };

      //       expect(scope['getViewCaseDocketData']).toBeDefined();
      //       scope.getViewCaseDocketData();

      //       HttpFactoryDeferred.resolve(successResponse);
      //       scope.$digest();
      //     });

      //     it('get Actions failureResponse getViewCaseDocketData', function () {

      //       failureResponse = {
      //         data: {
      //           "message": "Widget Id does not exist in the system"
      //         }
      //       };

      //       expect(scope['getViewCaseDocketColumns']).toBeDefined();
      //       scope.getViewCaseDocketColumns();

      //       HttpFactoryDeferred.reject(failureResponse);
      //       scope.$digest();
      //     });


      //     // it('it should call gridOPtions', function () {

      //     //   var gridApi = {
      //     //     core: {
      //     //       on: {
      //     //         // filterChanged: function () {},
      //     //         columnVisibilityChanged: function () {}
      //     //       },
      //     //     },
      //     //   };
      //     //   expect(scope.gridOptions).toBeDefined();
      //     //   expect(scope.gridOptions.onRegisterApi).toBeDefined();
      //     //   scope.gridOptions.onRegisterApi(gridApi);
      //     //   expect(scope.gridApi).toBe(gridApi);
      //     //   scope.gridApi.core.on.filterChanged();
      //     //   scope.gridApi.core.on.columnVisibilityChanged();
      //     //   // scope.gridApi.core.on.filterChanged();
      //     //   // scope.gridApi.core.on.filterChanged();

      //     // });


      //     it('setWidgetZone should set WidgetZone', function () {
      //       scope.$parent = {
      //         $parent: {
      //           $parent: {
      //             "definition": {
      //               "zoneWidth": 10
      //             }
      //           }
      //         }

      //       };
      //       var zoneWidth = 10;
      //       expect(scope.setWidgetZone).toBeDefined();
      //       scope.setWidgetZone(zoneWidth);
      //       expect(scope.zoneWidth).toBe(zoneWidth);

      //       expect(scope.setWidgetZone).toBeDefined();
      //       scope.setWidgetZone();
      //       expect(scope.zoneWidth).toBe(zoneWidth);

      //     });

      //     it('get Actions success response getViewCaseDocketData', function () {

      //       successResponse = {
      //         data: {
      //           "userWorkspaceWidgetIdentifier": 8879,
      //           "selectedColumns": [{
      //               "name": "PROCEEDING_CORE_ID",
      //               "label": "Application #",
      //               "typeDefinition": "String",
      //               "defaultOrder": "desc",
      //               "selected": true,
      //               "mandatory": true,
      //               "width": 250,
      //               "sort": "desc",
      //               "filters": "<"
      //             },
      //             {
      //               "name": "PROCEEDING_SUPPLEMENTARY_ID",
      //               "label": "Appeal Sequence #",
      //               "typeDefinition": "Number",
      //               "defaultOrder": "desc",
      //               "selected": true,
      //               "mandatory": true
      //             },
      //             {
      //               "name": "NEXT_DISPOSITION_DT",
      //               "label": "Next Upcoming Due Date",
      //               "typeDefinition": "Date",
      //               "defaultOrder": "desc",
      //               "selected": true,
      //               "mandatory": true
      //             },
      //             {
      //               "name": "HEARINGDATE",
      //               "label": "Hearing Date",
      //               "typeDefinition": "Date",
      //               "defaultOrder": "desc",
      //               "selected": false,
      //               "mandatory": true
      //             }
      //           ],
      //           "columnDetails": [{
      //               "name": "PROCEEDING_NO",
      //               "label": "Patent #",
      //               "typeDefinition": "String",
      //               "defaultOrder": "desc",
      //               "selected": true,
      //               "mandatory": false
      //             },
      //             {
      //               "name": "PROCEEDING_SUPPLEMENTARY_ID",
      //               "label": "Appeal Sequence #",
      //               "typeDefinition": "String",
      //               "defaultOrder": "desc",
      //               "selected": true,
      //               "mandatory": false
      //             },
      //             {
      //               "name": "NEXT_DISPOSITION_DT",
      //               "label": "Next Upcoming Due Date",
      //               "typeDefinition": "Date",
      //               "defaultOrder": "desc",
      //               "selected": true,
      //               "mandatory": false
      //             },
      //             {
      //               "name": "PROCEEDING_CORE_ID",
      //               "label": "Application #",
      //               "typeDefinition": "String",
      //               "defaultOrder": "desc",
      //               "selected": true,
      //               "mandatory": true,
      //               "width": 250,
      //               "sort": "desc",
      //               "filters": "<"
      //             },
      //             {
      //               "name": "PROCEEDING_SUPPLEMENTARY_ID",
      //               "label": "Appeal Sequence #",
      //               "typeDefinition": "Number",
      //               "defaultOrder": "desc",
      //               "selected": true,
      //               "mandatory": true
      //             },
      //             {
      //               "name": "NEXT_DISPOSITION_DT",
      //               "label": "Next Upcoming Due Date",
      //               "typeDefinition": "Date",
      //               "defaultOrder": "desc",
      //               "selected": true,
      //               "mandatory": true
      //             },
      //             {
      //               "name": "HEARINGDATE",
      //               "label": "Hearing Date",
      //               "typeDefinition": "Date",
      //               "defaultOrder": "desc",
      //               "selected": false,
      //               "mandatory": true
      //             }
      //           ]
      //         }

      //       };

      //       expect(scope['getViewCaseDocketData']).toBeDefined();
      //       scope.getViewCaseDocketData();

      //       HttpFactoryDeferred.resolve(successResponse);
      //       scope.$digest();
      //     });

      //     // getting toaster error

      //     // it('get Actions failureResponse getViewCaseDocketData', function () {

      //     //   failureResponse = {
      //     //     data: {
      //     //       "message": "Widget Id does not exist in the system"
      //     //     },
      //     //     status: 404
      //     //   };

      //     //   expect(scope['getViewCaseDocketData']).toBeDefined();
      //     //   scope.getViewCaseDocketData();

      //     //   HttpFactoryDeferred.reject(failureResponse);
      //     //   scope.$digest();
      //     // });

      //     it('get Actions failureResponse getViewCaseDocketData', function () {

      //       failureResponse = {
      //         data: {
      //           "message": "Widget Id does not exist in the system"
      //         }
      //       };

      //       expect(scope['getViewCaseDocketData']).toBeDefined();
      //       scope.getViewCaseDocketData();

      //       HttpFactoryDeferred.reject(failureResponse);
      //       scope.$digest();
      //     });

      it('it should call toggle filtering', function () {

        scope.gridOptions = {
          enableFiltering: true,
          data: "test"
        };

        scope.myData = {
          caseDetailsData: {

          }
        }
        // scope.showFilters = true;
        scope.gridApi = {
          core: {
            notifyDataChange: function (val) {

            }
          },
          grid: {
            clearAllFilters: function (val) {

            }
          }
        };

        expect(scope.toggleFiltering).toBeDefined();
        scope.toggleFiltering();
        // scope.showFilters = false;
      });

      it('it should open showFilteringHelp ', function () {

        var existingCount = $ngDialog.open.calls.count();
        expect(scope.showFilteringHelp).toBeDefined();
        scope.showFilteringHelp();
        expect($ngDialog.open).toHaveBeenCalled();

        expect($ngDialog.open.calls.count()).toBe(existingCount + 1);
        var args = $ngDialog.open.calls.argsFor(existingCount);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('CommonDialogController');
      });

      it('moveItem should swap origin and destination', function () {
        scope.selectedCols = [{
          "columnType": "number",
          "visible": true,
          "columnLabel": "Case #",
          "defaultOrder": "desc",
          "width": 105,
          "sort": {},
          "filters": [{}],
          "mandatory": true,
          "columnName": ["caseNumber"]
        }, {
          "columnType": "number",
          "cellTemplate": "app/components/widgets/viewCaseDropDown.html",
          "visible": true,
          "columnLabel": "Application #",
          "defaultOrder": "desc",
          "width": 140,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["applicationNumberText"]
        }, {
          "columnType": "string",
          "visible": true,
          "columnLabel": "Publication",
          "defaultOrder": "desc",
          "width": 130,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["publication"]
        }, {
          "columnType": "string",
          "visible": true,
          "columnLabel": "Applicant",
          "defaultOrder": "desc",
          "width": 200,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["applicantFullName"]
        }, {
          "columnType": "string",
          "visible": true,
          "columnLabel": "Inventor",
          "defaultOrder": "desc",
          "width": 200,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["inventorFullName"]
        }, {
          "columnType": "string",
          "visible": true,
          "columnLabel": "Assignee",
          "defaultOrder": "desc",
          "width": 200,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["organizationStandardName"]
        }, {
          "columnType": "date",
          "visible": true,
          "columnLabel": "Assigned date",
          "defaultOrder": "desc",
          "width": 145,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "cellFilter": "date:'MM/dd/yyyy'",
          "columnName": ["assignedDate"]
        }, {
          "columnType": "string",
          "visible": true,
          "columnLabel": "Discipline",
          "defaultOrder": "desc",
          "width": 165,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["caseDisciplineText"]
        }, {
          "columnType": "string",
          "visible": true,
          "columnLabel": "B/H",
          "defaultOrder": "desc",
          "width": 85,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["briefHearingTypeCode"]
        }, {
          "columnType": "string",
          "visible": true,
          "columnLabel": "Special type",
          "defaultOrder": "desc",
          "width": 135,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["appealSpecialTypes"]
        }, {
          "columnType": "number",
          "visible": true,
          "columnLabel": "Tech center",
          "defaultOrder": "desc",
          "width": 135,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["techCenterNumber"]
        }, {
          "columnType": "number",
          "visible": true,
          "columnLabel": "Art unit",
          "defaultOrder": "desc",
          "width": 105,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["groupArtUnitNumber"]
        }, {
          "columnType": "string",
          "visible": true,
          "columnLabel": "Master docket",
          "defaultOrder": "desc",
          "width": 150,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["masterDocketText"]
        }, {
          "columnType": "date",
          "visible": true,
          "columnLabel": "PTAB received date",
          "defaultOrder": "desc",
          "width": 175,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "cellFilter": "date:'MM/dd/yyyy'",
          "columnName": ["receivedDate"]
        }, {
          "columnType": "string",
          "visible": true,
          "columnLabel": "Correspondence name line 1",
          "defaultOrder": "desc",
          "width": 335,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["nameLineOneText"]
        }, {
          "columnType": "string",
          "visible": true,
          "columnLabel": "Correspondence name line 2",
          "defaultOrder": "desc",
          "width": 240,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["nameLineTwoText"]
        }, {
          "columnType": "string",
          "visible": true,
          "columnLabel": "Correspondence address line 1",
          "defaultOrder": "desc",
          "width": 335,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["addressLineOneText"]
        }, {
          "columnType": "string",
          "visible": true,
          "columnLabel": "Correspondence address line 2",
          "defaultOrder": "desc",
          "width": 240,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["addressLineTwoText"]
        }, {
          "columnType": "string",
          "visible": true,
          "columnLabel": "State",
          "defaultOrder": "desc",
          "width": 90,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["geographicRegionName"]
        }, {
          "columnType": "string",
          "visible": true,
          "columnLabel": "Application type",
          "defaultOrder": "desc",
          "width": 160,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["applicationType"]
        }, {
          "columnType": "string",
          "visible": true,
          "columnLabel": "Continuity type",
          "defaultOrder": "desc",
          "width": 155,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["continuityType"]
        }, {
          "columnType": "string",
          "visible": true,
          "columnLabel": "Invention subject matter type",
          "defaultOrder": "desc",
          "width": 250,
          "sort": {},
          "filters": [{}],
          "mandatory": false,
          "columnName": ["inventionSubjectMatterCategory"]
        }];

        // var origin = 0;
        // var destination = 1;

        // var selectedColumnsCopy = [{
        //   'userFavoritesName': 'testFavouriteOrigin',
        //   'userFavoritesURL': 'google.com'
        // }, {
        //   'userFavoritesName': 'testFavouriteDest',
        //   'userFavoritesURL': 'bin.com'
        // }];
        expect(scope.moveItem).toBeDefined();
        scope.moveItem(6, 5);

        // expect(scope.selectedColumns[0].userFavoritesName).not.toBe(selectedColumnsCopy[0].userFavoritesName);
        // expect(scope.selectedColumns[0].userFavoritesURL).not.toBe(selectedColumnsCopy[0].userFavoritesURL);

      });

      it('listItemUp should call move item', function () {

        expect(scope.listItemUp).toBeDefined();
        spyOn(scope, 'moveItem');
        expect(scope['moveItem']).toBeDefined();
        scope.listItemUp(1);
        expect(scope.moveItem).toHaveBeenCalledWith(1, 0);

      });

      it('listItemDown should call move item', function () {
        expect(scope.listItemDown).toBeDefined();
        spyOn(scope, 'moveItem');
        expect(scope['moveItem']).toBeDefined();
        scope.listItemDown(1);
        expect(scope.moveItem).toHaveBeenCalledWith(1, 2);

      });

      // it('get Actions success response updateColumns', function () {

      //   successResponse = {
      //     data: {
      //       "userWorkspaceWidgetIdentifier": 8879,
      //       "selectedColumns": [{
      //           "name": "PROCEEDING_CORE_ID",
      //           "label": "Application #",
      //           "typeDefinition": "String",
      //           "defaultOrder": "desc",
      //           "selected": true,
      //           "mandatory": true
      //         },
      //         {
      //           "name": "PROCEEDING_SUPPLEMENTARY_ID",
      //           "label": "Appeal Sequence #",
      //           "typeDefinition": "String",
      //           "defaultOrder": "desc",
      //           "selected": true,
      //           "mandatory": false
      //         },
      //         {
      //           "name": "NEXT_DISPOSITION_DT",
      //           "label": "Next Upcoming Due Date",
      //           "typeDefinition": "Date",
      //           "defaultOrder": "desc",
      //           "selected": true,
      //           "mandatory": false
      //         },
      //         {
      //           "name": "HEARINGDATE",
      //           "label": "Hearing Date",
      //           "typeDefinition": "Date",
      //           "defaultOrder": "desc",
      //           "selected": false,
      //           "mandatory": false
      //         }
      //       ],

      //       "mixedDocketsData": [{
      //           "caseDetailsData": [],
      //           "columnDetails": [{
      //               "name": "PATENT_NO",
      //               "label": "Patent #",
      //               "typeDefinition": "String",
      //               "defaultOrder": "desc",
      //               "selected": true,
      //               "mandatory": false
      //             },
      //             {
      //               "name": "PROCEEDING_SUPPLEMENTARY_ID",
      //               "label": "Appeal Sequence #",
      //               "typeDefinition": "String",
      //               "defaultOrder": "desc",
      //               "selected": true,
      //               "mandatory": false
      //             },
      //             {
      //               "name": "NEXT_DISPOSITION_DT",
      //               "label": "Next Upcoming Due Date",
      //               "typeDefinition": "Date",
      //               "defaultOrder": "desc",
      //               "selected": true,
      //               "mandatory": false
      //             }
      //           ]
      //         }

      //       ]
      //     }

      //   };

      //   expect(scope['updateColumns']).toBeDefined();
      //   scope.updateColumns();

      //   HttpFactoryDeferred.resolve(successResponse);
      //   // $rootScope.$apply();
      //   scope.$digest();
      // });

      // it('get Actions failureResponse updateColumns', function () {

      //   failureResponse = {
      //     data: {
      //       "status": 404,
      //       "message": "Widget Id does not exist in the system"
      //     }
      //   };

      //   expect(scope['updateColumns']).toBeDefined();
      //   scope.updateColumns();

      //   HttpFactoryDeferred.reject(failureResponse);
      //   // $rootScope.$apply();
      //   scope.$digest();
      // });

      // it('should call saveGridPreferences', function () {
      //   expect(scope.saveGridPreferences).toBeDefined();
      //   scope.saveGridPreferences();
      // });



      it('should call setPaginationManually', function () {
        expect(scope.setPaginationManually).toBeDefined();
        scope.setPaginationManually();
      });


      //     // it('should call toggleSelectAll', function () {
      //     //   expect(scope.toggleSelectAll).toBeDefined();
      //     //   scope.toggleSelectAll();
      //     // });

      //     // it('should call areAllSelected', function () {
      //     //   expect(scope.areAllSelected).toBeDefined();
      //     //   scope.areAllSelected();
      //     // });

      //     it('should call getRedirectUrl', function () {
      //       expect(scope.getRedirectUrl).toBeDefined();
      //       scope.getRedirectUrl();
      //     });

      //     it('should call refreshViewCaseDocketData', function () {
      //       expect(scope.refreshViewCaseDocketData).toBeDefined();
      //       scope.refreshViewCaseDocketData();
      //     });

      it(' it should call openImportHearingModal ', function () {

        expect(scope.openImportHearingModal).toBeDefined();
        scope.openImportHearingModal();

        expect($ngDialog.open.calls.count()).toBe(2);
        var args = $ngDialog.open.calls.argsFor(1);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('ImportHeardCaseController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.newData();
      });

      it(' it should call showDateSelection ', function () {

        expect(scope.showDateSelection).toBeDefined();
        scope.showDateSelection();
      });

      it(' it should call showRoomPicker ', function () {
        expect(scope.showRoomPicker).toBeDefined();
        scope.showRoomPicker();

        expect($ngDialog.open.calls.count()).toBe(3);
        var args = $ngDialog.open.calls.argsFor(2);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('HearingRoomPickerController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.items();

      });


      it('should call moveSourcetoDestination', function () {
        scope.clickedColumn = [{
          mandatory: false
        }]
        scope.availableCols = [{
          mandatory: false
        }]
        scope.selectedCols = [];
        expect(scope.moveSourcetoDestination).toBeDefined();
        scope.moveSourcetoDestination();
      });



      it('should call moveSourcetoDestinationCancel', function () {
        var index = 0;
        scope.selectedCols = [{
          visible: true
        }]
        scope.availableCols = [];
        expect(scope.moveSourcetoDestinationCancel).toBeDefined();
        scope.moveSourcetoDestinationCancel(index);
      });


      it('should call toggleSelectAll', function () {
        scope.availableCols = [{
          mandatory: false
        }]
        scope.selectedCols = [];
        expect(scope.toggleSelectAll).toBeDefined();
        scope.toggleSelectAll();
      });



      it('should call removeAll with madatory as false', function () {
        scope.selectedCols = [{
          mandatory: false
        }]
        scope.availableCols = [];
        expect(scope.removeAll).toBeDefined();
        scope.removeAll();
      });


      it('should call removeAll with madatory as true', function () {
        scope.selectedCols = [{
          mandatory: true
        }]
        scope.availableCols = [];
        expect(scope.removeAll).toBeDefined();
        scope.removeAll();
      });



    });


  });
})();
