'use strict';

angular.module('adf.widget.masterDocket', ['adf.provider', 'ui.grid'])
  .config(function (dashboardProvider) {
    dashboardProvider
      .widget('masterDocket', {
        title: 'Master Docket',
        description: 'Master Docket widget',
        templateUrl: '{widgetsPath}/masterDocket/src/view.html',
        edit: {
          templateUrl: '{widgetsPath}/masterDocket/src/edit.html'
        }
      });
  }).controller('MasterDocketController', function ($timeout, $rootScope, $scope, $log, CommonHelperService, ngDialog, SearchHelperService,
    HttpFactory, uiGridConstants, CONSTANTS, $window, $filter, i18nService) {


    /* istanbul ignore next  */
    $rootScope.$on('broadcastZoneWidth', function (event, param) {
      if ($scope.$parent.model) {
        if ($scope.$parent.model.widgetIdentifier === param.widgetIdentifier) {
          setWidgetZone(param.zoneWidth);
        }
      }
    });

    i18nService.get('en').gridMenu.exporterAllAsCsv = 'Export filtered data as csv';
    i18nService.get('en').gridMenu.exporterVisibleAsCsv = 'Export this page as csv';
    i18nService.get('en').gridMenu.exporterSelectedAsCsv = 'Export selected as csv';

    var scope = angular.element(document.getElementById('mainTabId')).scope();

    function setWidgetZone(zoneWidth) {
      if (angular.isUndefined(zoneWidth)) {
        scope.vm.getWidgetZone($scope.$parent.$parent.$parent.definition);
        $scope.zoneWidth = $scope.$parent.$parent.$parent.definition.zoneWidth;
      } else {
        $scope.zoneWidth = zoneWidth;
      }
      $log.debug("Master docket zone width: " + $scope.zoneWidth);
    }
    setWidgetZone();

    $scope.selectUnselect = true;
    $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
    $scope.loadedColumns = false;
    var isFilterChanged = false;
    var isColumnVisibilityChanged = false;
    var isColumnPinnedChanged = false;
    var isColumnSizeChanged = false;
    var isSortChanged = false;
    var isColumnPositionChanged = false;
    var isPaginationChanged = false;
    var initialLoad = true;
    $scope.preferencesChanged = false;
    $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
    $scope.gridRefreshMsg = CONSTANTS.MESSAGES.GRID_REFRESH;
    $scope.showRefreshFailed = false;
    $scope.refreshFailed = true;
    $scope.numberOfFilters = 0;
    var isMasterDocket = true;
    var hasFilterFlag;
    $rootScope.masterDocketColumnsChanged = false;

    /* istanbul ignore next  */
    function resetUnsavedChangesFlags() {
      isFilterChanged = false;
      isColumnVisibilityChanged = false;
      isColumnPinnedChanged = false;
      isColumnSizeChanged = false;
      isSortChanged = false;
      isColumnPositionChanged = false;
      isPaginationChanged = false;
      $scope.preferencesChanged = false;
      $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
    }

    if (angular.isDefined($scope.$parent.model)) {
      $scope.masterDocketDataUrl = $scope.$parent.model.dataUrlText;
      $scope.widgetIdentifier = $scope.$parent.model.widgetIdentifier;
    } else {
      $scope.masterDocketDataUrl = $scope.definition.dataUrlText;
      $scope.widgetIdentifier = $scope.definition.widgetIdentifier;
    }
    $log.debug("Master docket data url: " + $scope.masterDocketDataUrl);
    $log.debug("Master docket widget identifier: " + $scope.widgetIdentifier);

    $scope.masterDocketGridOptions = CommonHelperService.setCommonGridOptions();
    $scope.masterDocketGridOptions.multiSelect = true;
    $scope.masterDocketGridOptions.enableSelectAll = true;
    /* istanbul ignore next */
    $scope.masterDocketGridOptions.exporterFieldCallback = function (grid, row, col, value) {
      $scope.masterDocketGridOptions.exporterCsvFilename = "Master docket_" + CommonHelperService.getCurrentTime() + '.csv';
      if (col.colDef.type === 'date') {
        value = $filter('date')(value, 'MM/dd/yyyy');
      }
      return value;
    };
    /* istanbul ignore next  */
    $scope.masterDocketGridOptions.gridMenuCustomItems = [{
        title: 'Save grid preferences',
        action: function () {
          $scope.saveGridPreferences();
        },
        order: 100
      }, {
        title: 'Show hidden filters',
        action: function () {
          showHiddenFilteredColumns();
        },
        order: 190
      },
      {
        title: 'Export full docket as csv',
        action: function () {
          $scope.download_csv();
        },
        order: 220
      },
      {
        title: 'Mandatory columns',
        order: 221
      },
      {
        title: 'Case #',
        icon: 'fas fa-check',
        order: 222
      }
      // {
      //   title: 'Selected',
      //   order: 301
      // },
      // {
      //   title: 'Available',
      //   order: 401
      // }
    ];

    /* istanbul ignore next  */
    function showHiddenFilteredColumns() {
      var hiddenFilteredColumns = SearchHelperService.hasHiddenColumnFilters($scope.gridApi.grid.columns);

      angular.forEach(hiddenFilteredColumns, function (column) {
        column.showColumn();
        $scope.preferencesChanged = true;
      });
      $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
    }

    /* istanbul ignore next  */
    $scope.masterDocketGridOptions.onRegisterApi = function (gridApi) {

      $scope.gridApi = gridApi;
      $scope.gridApi.core.on.filterChanged($scope, function () {
        isFilterChanged = true;
        var grid = this.grid;
        $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
        if ($scope.numberOfFilters === 0) {
          $scope.masterDocketGridOptions.data = $scope.masterDocketData;
          $log.debug("Master docket (" + $scope.widgetIdentifier + ") original data: ");
          $log.debug($scope.masterDocketGridOptions.data);
        } else {
          $scope.masterDocketGridOptions.data = SearchHelperService.filterGrid(grid, $scope.masterDocketData);

          $log.debug("Master docket (" + $scope.widgetIdentifier + ") filtered data: ");
          $log.debug($scope.masterDocketGridOptions.data);
        }
        checkForUnsavedChanges();
      });
      $scope.gridApi.core.on.columnVisibilityChanged($scope, function () {
        isColumnVisibilityChanged = true;
        updateColumnDefs($scope.masterDocketGridOptions.columnDefs);
        checkForUnsavedChanges();
      });
      $scope.gridApi.pinning.on.columnPinned($scope, function () {
        isColumnPinnedChanged = true;
        updateColumnDefs($scope.masterDocketGridOptions.columnDefs);
        checkForUnsavedChanges();
      });
      $scope.gridApi.colResizable.on.columnSizeChanged($scope, function () {
        isColumnSizeChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.core.on.sortChanged($scope, function () {
        isSortChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.colMovable.on.columnPositionChanged($scope, function () {
        isColumnPositionChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.pagination.on.paginationChanged($scope, function () {
        isPaginationChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.core.on.renderingComplete($scope, function () {
        $scope.gridResize();
        checkForUnsavedChanges();
      });


    };

    function updateColumnDefs(columndefs) {
      var selected = [];
      var unselected = [];
      var selectedCount = 0;
      angular.forEach(columndefs, function (col) {
        if (col.visible) {
          selected.push(col);
          selectedCount = selectedCount + 1;

        } else {
          unselected.push(col);
        }
      });

      columndefs = [];
      angular.forEach(selected, function (col) {

        columndefs.push(col);

      });

      unselected.sort(CommonHelperService.alphabetizeAvailableColumns);

      angular.forEach(unselected, function (col) {
        columndefs.push(col);

      });
      $scope.masterDocketGridOptions.columnDefs = columndefs;
    }


    $scope.gridState = {};
    /* istanbul ignore next  */
    $scope.saveState = function () {
      $scope.saveGridPreferences();
    };


    $scope.getMasterDocketInfo = function () {
      $scope.isLoading = true;
      HttpFactory.getActions($scope.masterDocketDataUrl)
        .then(function (successResponse) {

          $scope.selectedColumns = successResponse.data.columnDetails;
          $scope.myData = successResponse.data.docketData;

          $scope.selectedCols = [];
          $scope.availableCols = [];
          angular.forEach($scope.selectedColumns, function (thisColumn) {
            if (thisColumn.visible) {
              $scope.selectedCols.push(thisColumn);
            } else {
              $scope.availableCols.push(thisColumn);
            }
          });

          var setColumnsResponse = CommonHelperService.setColumnDefinitions(successResponse.data.columnDetails);
          $scope.masterDocketGridOptions.paginationPageSize = successResponse.data.paginationSize;
          $scope.selectUnselect = setColumnsResponse.selectUnselect;
          $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
          $scope.numberOfFilters = setColumnsResponse.filterCount;
          $scope.updatedDocketColumnList = setColumnsResponse.colDefs;
          updateColumnDefs(setColumnsResponse.colDefs);
          $scope.masterDocketGridOptions.data = CommonHelperService.setGridData($scope.numberOfFilters, successResponse.data.docketData, $scope.masterDocketGridOptions.columnDefs);
          $scope.savedFilteredData = angular.copy($scope.masterDocketGridOptions.data);
          $scope.masterDocketData = angular.copy(successResponse.data.docketData);


          $scope.refreshFailed = false;


        }, function () {
          $scope.refreshFailed = true;
        })
        .finally(function () {
          $scope.refreshDate = new Date();
          $scope.isLoading = false;
          $scope.showRefreshFailed = true;
          $scope.preferencesChanged = false;
          $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
          $timeout(function () {
            initialLoad = false;
          }, 2000);
        });
    };

    $scope.getMasterDocketColumns = function () {
      if (isMasterDocket || $scope.definition.type === 'masterDocket') {
        isMasterDocket = false;
        HttpFactory.getActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS + $scope.widgetIdentifier)
          .then(function (successResponse) {
            $scope.selectedColumns = successResponse.data.selectedColumns;
            $scope.selectedCols = [];
            $scope.availableCols = [];
            angular.forEach($scope.selectedColumns, function (thisColumn) {
              if (thisColumn.visible) {
                $scope.selectedCols.push(thisColumn);
              } else {
                $scope.availableCols.push(thisColumn);
              }
            });
            $scope.originShowHide = angular.copy($scope.selectedColumns);
            $scope.masterDocketAvailableCols = angular.copy($scope.selectedCols);
            $scope.loadedColumns = true;
            for (var i = 0; i < $scope.selectedColumns.length; i++) {
              if (!$scope.selectedColumns[i].visible) {
                $scope.selectUnselect = false;
                $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
              }
            }
          }, function (failureResponse) {
            $log.debug("Master docket (" + $scope.widgetIdentifier + ") getMasterDocketColumns failure response: ");
            $log.debug(failureResponse);
          });
      }
    };



    $scope.toggleFiltering = function () {

      if (angular.isDefined($scope.gridApi)) {
        $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
      }

      $scope.gridApi.grid.clearAllFilters();
      $scope.masterDocketGridOptions.data = $scope.myData.masterDocketData;
      $scope.numberOfFilters = 0;
    };

    $scope.showFilteringHelp = function () {
      ngDialog.open({
        template: 'app/components/helperComponents/filterHelp/filteringHelp.html',
        controller: 'CommonDialogController',
        controllerAs: 'vm',
        width:'54%',
        showClose: false
      }).then(function () {
        // intentional
      }, function () {
        // intentional
      });
    };

    $scope.masterDocketSortableOptions = {
      containment: '#masterDocketColumns',
      scroll: true,
      axis: 'y',
      cursor: 'move',
      scrollSpeed: 2,
      scrollSensitivity: 160,
      update: function () {
        $rootScope.masterDocketColumnsChanged = true;
      }
    };

    $scope.importBriefHearing = function () {
      ngDialog.open({
        template: "app/components/widgets/masterDocket/src/importBriefCase.html",
        controller: 'ImportHeardCaseController',
        scope: $scope,
        width: '40%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,

        resolve: {
          newData: function () {
            // intentional
          }
        }
      }).closePromise.then(function (refreshGrid) {
        if (refreshGrid.value) {
          $timeout(function () {
            // intentional
          }, 400);
        }

      }, function () {
        // intentional
      });
    };

    $scope.openImportHearingModal = function () {
      ngDialog.open({
        template: "app/components/widgets/masterDocket/src/importHeardCase.html",
        controller: 'ImportHeardCaseController',
        scope: $scope,
        width: '40%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,

        resolve: {
          newData: function () {
            // intentional
          }
        }
      }).closePromise.then(function (refreshGrid) {
        if (refreshGrid.value) {
          $timeout(function () {
            $scope.refreshGrid();
          }, 400);
        }

      }, function () {
        // intentional
      });
    };
    /*istanbul ignore next */
    $scope.updateColumns = function () {
      $scope.isLoading = true;
      var masterDocketScopeList = angular.element(document.getElementById('masterDocketColumns')).scope();
      var columnsSelected = [];
      var fromModal = false;
      if (angular.isDefined(masterDocketScopeList)) {
        columnsSelected = masterDocketScopeList.selectedCols;
        columnsSelected = angular.copy(masterDocketScopeList.selectedCols);
        angular.forEach(masterDocketScopeList.availableCols, function (available) {
          columnsSelected.push(available);
        });
        fromModal = true;
      } else {
        columnsSelected = $scope.selectedColumns;
      }

      var columnListForUpdate = CommonHelperService.setColumnsToUpdate(columnsSelected, fromModal, $scope.gridState, $scope.widgetIdentifier, false);

      if (angular.isDefined(masterDocketScopeList)) {
        masterDocketScopeList.originShowHide = angular.copy(columnListForUpdate.selectedColumns);
      }
      HttpFactory.putActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS, columnListForUpdate)
        .then(function (successResponse) {

            CommonHelperService.setToastr(CONSTANTS.TOASTER.gridSave, "success");

            resetUnsavedChangesFlags();
            if (fromModal) {
              fromModal = false;
              var colDefs = [];
              angular.forEach(successResponse.config.data.selectedColumns, function (fetchedColumn) {
                var columnToBeAdded = {};

                if (!fetchedColumn.visible) {
                  $scope.selectUnselect = false;
                  $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
                }

                // Adding the column display name
                columnToBeAdded.displayName = fetchedColumn.columnLabel;

                // Checking if the field mapped to the column as an alias name
                if (fetchedColumn.columnName.length > 1) {
                  columnToBeAdded.field = fetchedColumn.columnName[1];
                } else {
                  columnToBeAdded.field = fetchedColumn.columnName[0];
                }


                // Setting column type
                columnToBeAdded.type = fetchedColumn.columnType;

                // Setting custom cell filter if one exists
                if (angular.isDefined(fetchedColumn.cellFilter)) {
                  columnToBeAdded.cellFilter = fetchedColumn.cellFilter;
                }

                // Setting visibility of the column
                if (fetchedColumn.mandatory) {
                  columnToBeAdded.visible = true;
                  columnToBeAdded.enableHiding = false;
                } else {
                  columnToBeAdded.visible = fetchedColumn.visible;
                }

                // Setting column width
                columnToBeAdded.width = fetchedColumn.width;

                // Setting custom template if one exists
                if (angular.isDefined(fetchedColumn.cellTemplate)) {
                  columnToBeAdded.cellTemplate = fetchedColumn.cellTemplate;
                }

                // Setting sort properties on column
                columnToBeAdded.sort = fetchedColumn.sort;

                // Setting column filters
                columnToBeAdded.filters = fetchedColumn.filters;

                // Incrementing the filter flag
                if (columnToBeAdded.filters[0].term) {
                  hasFilterFlag = hasFilterFlag + 1;
                }

                colDefs.push(columnToBeAdded);

              });

              $scope.numberOfFilters = hasFilterFlag;
              var allGrids = document.getElementsByClassName('ui-grid');
              for (var j = 0; j < allGrids.length; j++) {
                if (angular.element(allGrids[j]).scope().widgetIdentifier === $scope.widgetIdentifier) {
                  updateColumnDefs(colDefs);

                  angular.element(allGrids[j]).scope().masterDocketGridOptions.columnDefs = $scope.masterDocketGridOptions.columnDefs;
                  if ($scope.numberOfFilters > 0) {
                    var filteredData = SearchHelperService.filterTable($scope.masterDocketData, colDefs);
                    $scope.masterDocketGridOptions.data = filteredData;
                  } else {


                    $scope.masterDocketGridOptions.data = $scope.masterDocketData;
                  }
                  break;
                }
              }
              $rootScope.masterDocketColumnsChanged = false;
            }
            $scope.noRecordsFound = true;
          },
          function () {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.gridSaveFail, "error");
          })
        .finally(function () {
          $scope.isLoading = false;
          $scope.preferencesChanged = false;
          $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
        });
    };


    $scope.moveItem = function (origin, destination) {
      var temp = $scope.selectedCols[destination];
      $log.debug("Initial");
      $log.debug($scope.selectedCols);
      $scope.selectedCols[destination] = $scope.selectedCols[origin];
      $log.debug("Origin moved to destination");
      $log.debug($scope.selectedCols);
      $scope.selectedCols[origin] = temp;
      $log.debug("Final");
      $log.debug($scope.selectedCols);
      $rootScope.masterDocketColumnsChanged = true;
    };

    $scope.listItemUp = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex - 1);
    };

    $scope.listItemDown = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex + 1);
    };

    $scope.moveSourcetoDestination = function () {
      angular.forEach($scope.clickedColumn, function (column) {
        column.visible = true;
        $scope.selectedCols.push($scope.availableCols[$scope.availableCols.indexOf(column)]);
        $scope.availableCols.splice($scope.availableCols.indexOf(column), 1);
      });
      $scope.clickedColumn = [];
      $rootScope.masterDocketColumnsChanged = true;
    };

    $scope.moveSourcetoDestinationCancel = function (index) {
      $scope.selectedCols[index].visible = false;
      $scope.availableCols.push($scope.selectedCols[index]);
      $scope.selectedCols.splice(index, 1);
      $rootScope.masterDocketColumnsChanged = true;
    };

    $scope.toggleSelectAll = function () {
      angular.forEach($scope.availableCols, function (column) {
        column.visible = true;
        $scope.selectedCols.push(column);
      });
      $scope.availableCols = [];
      $rootScope.masterDocketColumnsChanged = true;
    };

    $scope.removeAll = function () {
      var tempArray = [];
      $rootScope.masterDocketColumnsChanged = true;
      angular.forEach($scope.selectedCols, function (column) {
        if (!column.mandatory) {
          column.visible = false;
          $scope.availableCols.push(column);
        } else {
          tempArray.push(column);
        }
      });
      $scope.selectedCols = tempArray;
    };

    /* istanbul ignore next */
    $scope.saveGridPreferences = function () {
      if ($scope.gridApi) {
        $scope.gridState = CommonHelperService.setGridWidthMap($scope.gridApi.saveState.save());
      } else if ($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi) {
        $scope.gridState = CommonHelperService.setGridWidthMap($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi.saveState.save());
      }

      $scope.updateColumns();
    };

    $scope.paginationManual = false;
    $scope.setPaginationManually = function () {
      $scope.paginationManual = false;
    };
    /* istanbul ignore next */
    $rootScope.$on('adfCustomizeWidgetServiceCall', function () {
      if ($rootScope.widgetIdentifier === $scope.widgetIdentifier) {
        switch ($rootScope.widgetHeight) {
          case "widgetHeightSmall":
            $scope.masterDocketGridOptions.paginationPageSize = $scope.masterDocketGridOptions.paginationPageSizes[0];
            break;
          case "widgetHeightMedium":
            $scope.masterDocketGridOptions.paginationPageSize = $scope.masterDocketGridOptions.paginationPageSizes[1];
            break;
          case "widgetHeightLarge":
            $scope.masterDocketGridOptions.paginationPageSize = $scope.masterDocketGridOptions.paginationPageSizes[2];
            break;
          case "widgetHeightXlarge":
            $scope.masterDocketGridOptions.paginationPageSize = $scope.masterDocketGridOptions.paginationPageSizes[3];
            break;
          default:
            break;
        }
        // var pageSize = CommonHelperService.setPagination();
        // if (pageSize) {
        //   $scope.masterDocketGridOptions.paginationPageSize = pageSize;
        // }
        $scope.paginationManual = true;
        $log.debug("Executed after save widget size for Master docket (" + $scope.widgetIdentifier + ")");
        $timeout($scope.setPaginationManually, 500);
      }
    });

    /* istanbul ignore next  */
    $scope.areAllSelected = function () {
      var columnList = angular.element(document.getElementById('masterDocketColumns')).scope();
      for (var i = 0; i < columnList.updatedDocketColumnList.length; i++) {
        if (!columnList.updatedDocketColumnList[i].visible) {
          $scope.selectUnselect = false;
          break;
        } else {
          $scope.selectUnselect = true;
        }
        $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
      }
    };

    /* istanbul ignore next */
    function checkForUnsavedChanges() {
      if (!initialLoad) {
        if (isFilterChanged || isColumnVisibilityChanged || isColumnSizeChanged || isSortChanged || isColumnPositionChanged || isPaginationChanged || isColumnPinnedChanged) {
          $scope.preferencesChanged = true;
          $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_PREFERENCES;
        } else {
          $scope.preferencesChanged = false;
          $scope.saveGridTooltip = CONSTANTS.MESSAGES.SAVE_GRID_DISABLED;
        }
      }
    }

    $scope.openCaseViewer = function (row) {
      $window.open("#/caseViewer/" + row.entity.applicationNumberText + '/' + row.entity.caseNumber);
    };

    /* istanbul ignore next  */
    $scope.gridResize = function () {
      var gridHeight = document.getElementsByClassName('grid');
      for (var i = 0; i < gridHeight.length; i++) {
        if ($scope.$parent.model.widgetIdentifier === $scope.widgetIdentifier) {
          if ($scope.$parent.model.height === 'widgetHeightSmall') {
            gridHeight[i].style.height = '223px';
          } else if ($scope.$parent.model.height === 'widgetHeightMedium') {
            gridHeight[i].style.height = '585px';
          } else if ($scope.$parent.model.height === 'widgetHeightLarge') {
            gridHeight[i].style.height = '915px';
          } else if ($scope.$parent.model.height === 'widgetHeightXlarge') {
            gridHeight[i].style.height = '1615px';
          }
        }
      }
    };

    /* istanbul ignore next */
    $scope.download_csv = function () {
      var headers = [];
      angular.forEach($scope.selectedColumns, function (coldata) {
        headers.push(coldata.columnLabel);

      });
      var fields = [];
      angular.forEach($scope.selectedColumns, function (coldata) {

        if (coldata.columnName[0] === 'FK_ASSIGNEE_BE_NO') {
          fields.push([coldata.columnName[1], coldata.columnType]);
        } else {
          fields.push([coldata.columnName[0], coldata.columnType]);
        }
      });
      var replacer = function (key, value) {
        return value === null ? '' : value;
      };
      var csv = $scope.myData.map(function (row) {
        return fields.map(function (fieldName) {
          if (fieldName[1] === 'date') {
            if (fieldName[0] === 'LAST_MODIFIED_TS') {
              return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy hh:mm:ss a') + " ";
            } else {
              return " " + $filter('date')(row[fieldName[0]], 'MM/dd/yyyy') + " ";
            }
          } else {
            return JSON.stringify(row[fieldName[0]], replacer);
          }
        }).join(',');
      });
      csv.unshift(headers.join(','));
      csv = csv.join('\r\n');
      var hiddenElement = document.createElement('a');
      hiddenElement.href = URL.createObjectURL(new Blob([csv], {
        type: 'text/csv'
      }));
      hiddenElement.target = '_blank';
      hiddenElement.download = 'Master docket_' + CommonHelperService.getCurrentTime() + '.csv';
      hiddenElement.click();
    };

    $scope.showDateSelection = function () {
      $window.open("#/hearingSchedule/" + new Date(new Date().setHours(0, 0, 0, 0)).getTime() / 1000);

    };

    $scope.showRoomPicker = function () {
      ngDialog.open({
        template: 'app/components/helperComponents/hearingSchedule/hearingRoomPicker.html',
        controller: 'HearingRoomPickerController',
        controllerAs: 'vm',
        width: '20%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,
        resolve: {
          items: function () {
            return;
          }
        }
      }).closePromise.then(function () {
        // intentional
      });

    };

  });
