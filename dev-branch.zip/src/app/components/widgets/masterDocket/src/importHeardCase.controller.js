(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .directive('hearingFileModel', ['$parse', /* istanbul ignore next */ function ($parse) {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var model = $parse(attrs.hearingFileModel);
          var modelSetter = model.assign;

          element.bind('change', function () {
            scope.$apply(function () {
              modelSetter(scope, element[0].files[0]);
            });
          });
        }
      };
    }])

    .directive('hearingOnChange', /* istanbul ignore next */ function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var onChangeFunc = scope.$eval(attrs.hearingOnChange);
          element.bind('change', onChangeFunc);
        }
      };
    })
    .controller('ImportHeardCaseController', function ($scope, CommonHelperService, ngDialog, HttpFactory, $rootScope, $timeout, CONSTANTS) {

      $scope.disableGetSheetsBtn = true;
      $scope.hideSheetsList = true;
      $scope.importingFile = false;
      $scope.disableImportBtn = true;
      $scope.loadingSheets = false;
      $scope.status = {
        isopen: false
      };
      var SELECT_A_SHEET_MESSAGE = "Select a sheet...";
      var hearingFile;

      $timeout(function () {
        document.getElementById('selectFileBtn').focus();
      }, 500);


      /* istanbul ignore next */
      $scope.getFileInfo = function (file) {
        hearingFile = document.getElementById("file1");
        var fileExtension = hearingFile.files[0].name.split('.').pop();
        $scope.fileInfo = {};
        if (fileExtension === "xls" || fileExtension === "xlsx") {
          $scope.disableGetSheetsBtn = false;
          $scope.fileInfo.name = hearingFile.files[0].name;
          $scope.fileInfo.path = hearingFile.value;
          $scope.getSheets();
        } else {
          $scope.fileInfo = {};
          $scope.disableGetSheetsBtn = true;
          CommonHelperService.setToastr(CONSTANTS.TOASTER.correctFormat, "error");
        }
      };

      $scope.selectedSheet = function (sheet) {
        $scope.selectedSheetFromxl = sheet;
        if ($scope.selectedSheetFromxl !== SELECT_A_SHEET_MESSAGE) {
          $scope.disableImportBtn = false;
        }
      };

      /* istanbul ignore next */
      $scope.getSheets = function () {
        $scope.loadingSheets = true;
        var fd = new FormData();
        fd.append('file', hearingFile.files[0]);
        HttpFactory.postPdf("/hearing-room-rosters/get-sheet-names", fd)
          .then(function (successResponse) {
            $scope.selectedSheetFromxl = SELECT_A_SHEET_MESSAGE;
            $scope.sheets = successResponse.data.sheetNames;
            $scope.status.isopen = true;
          }, function () {
            // intentional
          }).finally(function () {
            $scope.hideSheetsList = false;
            $scope.loadingSheets = false;
          });

      };

      /* istanbul ignore next */
      $scope.importHearing = function () {
        $scope.importingFile = true;
        var fd = new FormData();
        fd.append('file', hearingFile.files[0]);
        HttpFactory.postPdf("/hearing-room-rosters/upload-batch?sheetName=" + $scope.selectedSheetFromxl + "&userIdentifier=" + $rootScope.userInfo.userId, fd)
          .then(function (successResponse) {
            CommonHelperService.setToastr(successResponse.data.message, "success");
          }, function (failureResponse) {
            CommonHelperService.setToastr(failureResponse.data.message, "error");
          }).finally(function () {
            $scope.importingFile = false;
          });

      };

      $scope.importBrief = function () {
        $scope.importingFile = true;
        var fd = new FormData();
        fd.append('file', hearingFile.files[0]);
        HttpFactory.postPdf("/hearing-room-rosters/brief-upload-batch?sheetName=" + $scope.selectedSheetFromxl + "&userIdentifier=" + $rootScope.userInfo.userId, fd)
          .then(function (successResponse) {
            CommonHelperService.setToastr(successResponse.data.message, "success");
          }, function (failureResponse) {
            CommonHelperService.setToastr(failureResponse.data.message, "error");
          }).finally(function () {
            $scope.importingFile = false;
          });
      };

      $scope.cancelImportHearing = function () {
        ngDialog.closeAll();
      };
    });
})();
