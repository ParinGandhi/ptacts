'use strict';

angular.module('adf.widget.myCreditsPl', ['adf.provider'])
  .config(function (dashboardProvider) {
    dashboardProvider
      .widget('myCreditsPl', {
        title: 'My credits for paralegals',
        description: 'My credits widget for paralegals',
        templateUrl: '{widgetsPath}/myCreditsPl/src/view.html',
        edit: {
          templateUrl: '{widgetsPath}/myCreditsPl/src/edit.html'
        }
      });
  })
  .controller('MyCreditsPlController', function ($scope, $rootScope, $log, HttpFactory, $timeout, SearchHelperService, ngDialog, CONSTANTS, CommonHelperService, $window, uiGridConstants, $filter) {

    var vm = this;
    var date = new Date();
    $scope.startDate = new Date(date.getFullYear(), date.getMonth(), 1);
    $scope.endDate = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    $scope.currentModal = "myCredits";
    var isFilterChanged = false;
    var isColumnVisibilityChanged = false;
    var isColumnPinnedChanged = false;
    var isColumnSizeChanged = false;
    var isSortChanged = false;
    var isMyCredits = true;
    var isColumnPositionChanged = false;
    var isPaginationChanged = false;
    var initialLoad = true;
    var hasFilterFlag = 0;
    vm.superviorResponse;
    vm.supervisorList = [];
    $scope.isPL = false;
    $scope.hideSave = false;
    $scope.preferencesChanged = false;
    $scope.isSupervisor = false;
    $rootScope.myCreditsPlColumnsChanged = false;
    /* istanbul ignore next */
    $rootScope.$on('broadcastZoneWidth', function (event, param) {
      if ($scope.widgetIdentifier === param.widgetIdentifier) {
        $scope.setWidgetZone(param.zoneWidth);
      }
    });

    /* istanbul ignore next  */
    $scope.gridResize = function () {
      var gridHeight = document.getElementsByClassName('grid');
      for (var i = 0; i < gridHeight.length; i++) {
        if ($scope.$parent.model.widgetIdentifier === $scope.widgetIdentifier) {
          if ($scope.$parent.model.height === 'widgetHeightSmall') {
            gridHeight[i].style.height = '223px';
          } else if ($scope.$parent.model.height === 'widgetHeightMedium') {
            gridHeight[i].style.height = '565px';
          } else if ($scope.$parent.model.height === 'widgetHeightLarge') {
            gridHeight[i].style.height = '915px';
          } else if ($scope.$parent.model.height === 'widgetHeightXlarge') {
            gridHeight[i].style.height = '1615px';
          }
        }
      }
    };
    /*istanbul ignore next*/
    function setGridData(colDefs) {
      if (hasFilterFlag > 0) {

        $scope.numberOfFilters = hasFilterFlag;
        var filteredData = SearchHelperService.filterTable($scope.myData, colDefs);
        $timeout(function () {
          $scope.myCreditsGridOptions.data = filteredData;
          $scope.savedFilteredData = filteredData;
        }, 200);

      } else {
        $scope.numberOfFilters = 0;
        $timeout(function () {
          $scope.myCreditsGridOptions.data = $scope.myData;
        }, 200);

      }
    }
    var scope = angular.element(document.getElementById('mainTabId')).scope();
    $scope.userId = scope.vm.userInfo.userId;
    $scope.userNumber = scope.vm.userInfo.assigneeNumber;
    $scope.displayName = scope.vm.userInfo.displayName;
    $scope.setWidgetZone = function (zoneWidth) {
      if (angular.isUndefined(zoneWidth)) {
        scope.vm.getWidgetZone($scope.$parent.$parent.$parent.definition);
        $scope.zoneWidth = $scope.$parent.$parent.$parent.definition.zoneWidth;
      } else {
        $scope.zoneWidth = zoneWidth;
      }
    };
    $scope.setWidgetZone();
    $scope.dateTypes = ["Current month", "Previous month", "Fiscal mid-year", "Fiscal year", "Date range"];

    $scope.dateType = $scope.dateTypes[0];
    $scope.numberOfFilters = 0;
    $scope.selectUnselect = true;
    $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
    $scope.lastRefresh = new Date();
    $scope.loadedAssignColumns = false;
    $scope.isGridRefreshed = false;
    $scope.isLoading = false;

    $scope.assignedTo = [];
    /*istanbul ignore next*/
    function createGridFilterSelect(arrayData) {
      var nameItem;
      var selectArray = [];
      angular.forEach(arrayData, function (name) {
        nameItem = {
          value: name,
          label: name
        };
        selectArray.push(nameItem);
      });
      return selectArray;
    }
    /*istanbul ignore next*/
    vm.getDistinctAssignmentTypes = function (data) {
      var lookup = {};
      var caseLokkup = {};
      var awardedToLookup = {};
      var items = data;

      $scope.assignmentTypes = [];
      $scope.caseTypes = [];
      $scope.awardedTo = [];
      for (var item, i = 0; item = items[i++];) {
        var assignmentType = item.assignmentType;
        var caseType = item.caseType;
        var awardedType = item.decisionalUnitsAwarded;
        if (!(assignmentType in lookup)) {
          lookup[assignmentType] = 1;
          $scope.assignmentTypes.push(assignmentType);

        }
        if (!(caseType in caseLokkup)) {
          caseLokkup[caseType] = 1;
          $scope.caseTypes.push(caseType);

        }
        if (!(awardedType in awardedToLookup)) {
          awardedToLookup[awardedType] = 1;
          $scope.awardedTo.push(awardedType);

        }
        $scope.assignmentTypesArray = createGridFilterSelect($scope.assignmentTypes);
        $scope.caseTypesArray = createGridFilterSelect($scope.caseTypes);
        $scope.awardedToArray = createGridFilterSelect($scope.awardedTo);
      }
      if (data) {
        if (data.length == 0) {
          $scope.assignmentTypesArray = [];
          $scope.caseTypesArray = [];
          $scope.awardedToArray = [];
        }
      }
    };
    vm.getMyCreditsPl = function () {
      $scope.currentModal = "myCredits";
      $scope.checkTimeFrame($scope.refreshGridByMonth);

    };

    $scope.myCreditsGridOptions = CommonHelperService.setCommonGridOptions();
    $scope.myCreditsGridOptions.multiSelect = true;
    $scope.myCreditsGridOptions.enableSelectAll = true;
    $scope.myCreditsGridOptions.exporterCsvFilename = 'MyCredits' + CommonHelperService.getCurrentTime() + '.csv';
    $scope.myCreditsGridOptions.showColumnFooter = true;
    $scope.myCreditsSortableOptions = {
      containment: '#myCreditsColums',
      scroll: true,
      axis: 'y',
      cursor: 'move',
      scrollSpeed: 2,
      scrollSensitivity: 160,
      update: function () {
        $rootScope.myCreditsPlColumnsChanged = true;
      }
    };
    /* istanbul ignore next */
    $scope.myCreditsGridOptions.gridMenuCustomItems = [{
        title: 'Save grid preferences',
        action: function () {
          $scope.saveGridPreferences();
        },
        order: 100
      },
      {
        title: 'Show hidden filters',
        action: function () {
          showHiddenFilteredColumns();
        },
        order: 190
      },
      {
        title: 'Export full docket as csv',
        action: function () {
          $scope.exportData();
        },
        order: 210
      }

    ];

    /* istanbul ignore next  */
    function showHiddenFilteredColumns() {
      var hiddenFilteredColumns = SearchHelperService.hasHiddenColumnFilters($scope.gridApi.grid.columns);

      angular.forEach(hiddenFilteredColumns, function (column) {
        column.showColumn();
        $scope.preferencesChanged = true;
      });
      $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
    }

    $scope.setColumnDefs = function (columnDef) {
      $scope.getTimeFrames('CURRENTMONTH');
      $scope.originalMyCreditData = angular.copy($scope.myCreditsGridOptions.data);
      updateColumnDefs(columnDef);
      setGridData(columnDef);

    };
    /*istanbul ignore next*/
    function updateColumnDefs(columndefs) {
      var selected = [];
      var unselected = [];
      var selectedCount = 0;

      angular.forEach(columndefs, function (col) {
        if (col.visible) {
          selected.push(col);
          selectedCount = selectedCount + 1;
        } else {
          unselected.push(col);
        }
      });
      columndefs = [];
      angular.forEach(selected, function (col) {
        columndefs.push(col);
      });
      unselected.sort(CommonHelperService.alphabetizeAvailableColumns);
      angular.forEach(unselected, function (col) {
        columndefs.push(col);

      });
      $scope.myCreditsGridOptions.columnDefs = columndefs;
    }
    $scope.count = true;
    
    $scope.myCreditsGridOptions.exporterFieldCallback = function (grid, row, col, value) {
      if (col.colDef.type === 'date') {
        if (col.colDef.field === 'LAST_MODIFIED_TS') {
          value = $filter('date')(value, 'MM/dd/yyyy hh:mm:ss a');
        } else {
          value = $filter('date')(value, 'MM/dd/yyyy');
        }
        if (!value) {
          value = "";
        } else {
          value = " " + value;
        }
      }
      $scope.myCreditsGridOptions.exporterCsvFilename = 'MyCredits ' + CommonHelperService.getCurrentTime() + '.csv';
      return value;
    };
    
    /*istanbul ignore next*/
    $scope.myCreditsGridOptions.onRegisterApi = function (gridApi) {
      $scope.gridApi = gridApi;
      $scope.gridApi.core.on.filterChanged($scope, function () {
        isFilterChanged = true;
        var grid = this.grid;
        $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
        //If there are no filters and no search text, then set the grid data to original data */
        if ($scope.numberOfFilters === 0 && (angular.isUndefined($scope.$$childTail.$$prevSibling.searchText) ||
            $scope.$$childTail.$$prevSibling.searchText === "" ||
            $scope.$$childTail.$$prevSibling.searchText === null)) {
          $scope.myCreditsGridOptions.data = $scope.originalMyCreditData;
          /* If search text is defined and there are filters, then set grid data to filtered data before searching for searched text */
        } else if (angular.isDefined($scope.$$childTail.$$prevSibling.searchText) && $scope.numberOfFilters > 0) {
          $scope.myCreditsGridOptions.data = SearchHelperService.filterGrid(grid, $scope.originalMyCreditData);
          $scope.$parent.$$childHead.simpleSearch($scope.$$childTail.$$prevSibling.searchText);
          /* If search text is defined and there are no filters, then set the grid data to original data before searching for searched text */
        } else if (angular.isDefined($scope.$$childTail.$$prevSibling.searchText) && $scope.numberOfFilters === 0) {
          $scope.myCreditsGridOptions.data = $scope.originalMyCreditData;
          $scope.$parent.$$childHead.simpleSearch($scope.$$childTail.$$prevSibling.searchText);
        } else {
          /* If there are filters and no search text, then set grid data to filtered data */
          $scope.myCreditsGridOptions.data = SearchHelperService.filterGrid(grid, $scope.myData);
        }

        checkForUnsavedChanges();
      });
      $scope.gridApi.core.on.columnVisibilityChanged($scope, function () {
        isColumnVisibilityChanged = true;
        updateColumnDefs($scope.myCreditsGridOptions.columnDefs);
        checkForUnsavedChanges();
      });
      $scope.gridApi.colResizable.on.columnSizeChanged($scope, function () {
        isColumnSizeChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.pinning.on.columnPinned($scope, function () {
        isColumnPinnedChanged = true;
        updateColumnDefs($scope.myCreditsGridOptions.columnDefs);
        checkForUnsavedChanges();
      });

      $scope.gridApi.core.on.sortChanged($scope, function () {
        isSortChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.colMovable.on.columnPositionChanged($scope, function () {
        isColumnPositionChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.pagination.on.paginationChanged($scope, function () {
        isPaginationChanged = true;
        checkForUnsavedChanges();
      });
      $scope.gridApi.core.on.renderingComplete($scope, function () {
        $scope.gridResize();
        checkForUnsavedChanges();
      });

    };
    /* istanbul ignore next */
    $scope.opencreditsHistory = function (row) {
      var template = "app/components/widgets/myCredits/creditsHistory.html";
      var controller = "creditsHistoryController";
      var data = row;
      vm.ngdialogConfig(template, controller, data, '66%');
    };
    $scope.moveItem = function (origin, destination) {
      var temp = $scope.selectedCols[destination];
      $scope.selectedCols[destination] = $scope.selectedCols[origin];
      $scope.selectedCols[origin] = temp;
      $rootScope.myCreditsPlColumnsChanged = true;
    };

    $scope.listItemUp = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex - 1);
    };

    $scope.listItemDown = function (itemIndex) {
      $scope.moveItem(itemIndex, itemIndex + 1);
    };


    $scope.moveSourcetoDestination = function () {
      angular.forEach($scope.clickedColumn, function (column) {
        column.visible = true;
        $scope.selectedCols.push($scope.availableCols[$scope.availableCols.indexOf(column)]);
        $scope.availableCols.splice($scope.availableCols.indexOf(column), 1);
      });
      $scope.clickedColumn = [];
      $rootScope.myCreditsPlColumnsChanged = true;
    };

    $scope.moveSourcetoDestinationCancel = function (index) {
      $scope.selectedCols[index].visible = false;
      $scope.availableCols.push($scope.selectedCols[index]);
      $scope.selectedCols.splice(index, 1);
      $rootScope.myCreditsPlColumnsChanged = true;
    };

    $scope.toggleSelectAll = function () {
      angular.forEach($scope.availableCols, function (column) {
        column.visible = true;
        $scope.selectedCols.push(column);
      });
      $scope.availableCols = [];
      $rootScope.myCreditsPlColumnsChanged = true;
    };

    $scope.removeAll = function () {
      var tempArray = [];
      $rootScope.myCreditsPlColumnsChanged = true;
      angular.forEach($scope.selectedCols, function (column) {
        if (!column.mandatory) {
          column.visible = false;
          $scope.availableCols.push(column);
        } else {
          tempArray.push(column);
        }
      });
      $scope.selectedCols = tempArray;
    };

    $scope.caseNumber = ["12345678", "87654321", "14785236", "96325874", "15948712"];
    $scope.assignmentType = ["Assigned to APJ", "Assigned to APJ1", "Assigned to APJ2", "Assigned to APJ3", "Assigned to Administrator"];
    $scope.assignmentStatus = ["Open & Closed", "Open", "Closed"];
    /*istanbul ignore next*/
    vm.getAssignmentById = function (ptabID) {
      return HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTBYID + ptabID)
        .then(function (successResponse) {
            $scope.item = successResponse.data;
            $scope.item.standardAssignmentType = {
              ASSIGNMENTINFO: "Assignment info"
            };
            $scope.itemsSelected = [];
            $scope.itemsSelected.push($scope.item);
            return $scope.itemsSelected;
          },
          function (failureResponse) {
            $scope.itemsSelected = [];
            $log.debug(failureResponse);
            return failureResponse;
          });
    };

    vm.getSupervisor = function () {
      HttpFactory.getActions("/user-management/supervisors/" + $scope.userId)
        .then(function (successResponse) {
          vm.superviorResponse = successResponse.data;
          vm.superviorResponse.forEach(function (element) {
            vm.supervisorList.push(element.assigneeFullNameText);
          });
        }, function () {
          // Empty response is ok
        });
    };
    vm.getSupervisor();


    /*istanbul ignore next*/
    $scope.openAssignmentInfo = function (row) {
      vm.getAssignmentById(row.entity.ptabAssignmentIdentifier).then(function () {
        $scope.itemsSelected[0].priorityIndicator = $scope.itemsSelected[0].priorityIndicator === 'Y' ? true : false;
        var template = "app/components/widgets/assignments/src/updateAssignmentModal.html";
        var controller = "updateAssignmentManagementController";
        var data = row;
        vm.ngdialogConfig(template, controller, data);
      });
    };
    /* istanbul ignore next */
    vm.ngdialogConfig = function (template, controller, row, width) {
      if (!width) {
        width = '62%';
      }
      ngDialog.open({
        template: template,
        controller: controller,
        controllerAs: 'vm',
        scope: $scope,
        width: width,
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,
        resolve: {
          items: function () {
            return $scope.itemsSelected;
          },
          readOnly: function () {
            return true;
          },
          rowData: function () {
            return row;
          }
        }


      }).closePromise.then(function (refreshGrid) {
        if (refreshGrid.value) {
          $scope.refreshGrid();
          $scope.$$childTail.$$prevSibling.searchText = undefined;
        }
        delete $rootScope.sharedItems;
      }, function () {
        // Empty response is ok
      });
    };
    /* istanbul ignore next */
    $scope.enterDate = function (type) {
      ngDialog.open({
        template: 'app/components/helperComponents/datepicker/dateRangeDialog.html',
        controller: 'DateRangeController',
        controllerAs: 'vm',
        width: '17%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,
        resolve: {
          items: function () {
            return type;
          }
        }
      }).closePromise.then(function (dates) {
        if (dates.value) {
          if (type == 'PAYPERIOD') {
            $scope.payperiod = dates.value;
            $scope.checkTimeFrame(type);
          } else {
            $scope.startDate = new Date(dates.value.startDate).getTime();
            $scope.endDate = new Date(dates.value.endDate).getTime();
            if ($scope.startDate != null && $scope.endDate != null) {
              $scope.checkTimeFrame("DATERANGE");
              $scope.dateType = $scope.dateTypes[4];
            }
          }

        }

      });

    };


    $scope.pressEnter = function (event, searchText) {
      if (event.keyCode === 13) {
        $scope.simpleSearch(searchText);
      }
    };

    /* istanbul ignore next*/
    $scope.simpleSearch = function (textToSearch) {
      if (textToSearch !== $scope.previousTextToSearch) {
        $scope.previousTextToSearch = angular.copy(textToSearch);
        $scope.clearSearch(false);
      }

      var simpleSearchResults = [];
      angular.forEach($scope.myCreditsGridOptions.data, function (thisRow) {
        for (var key in thisRow) {
          if (thisRow.hasOwnProperty(key)) {
            if (angular.isDefined(thisRow[key]) && thisRow[key] !== null) {
              if (isNaN(parseInt(thisRow[key], CONSTANTS.GLOBAL.RADIX)) || thisRow[key].toString().length !== 13) {
                if (thisRow[key].toString().toLowerCase().includes(textToSearch.trim().toLowerCase())) {
                  simpleSearchResults.push(thisRow);
                  break;
                }
              } else {
                var thisDate = new Date(thisRow[key]);
                var month = thisDate.getMonth() + 1;
                if (month < 10) {
                  month = '0' + month.toString();
                }
                var date = thisDate.getDate();
                if (date < 10) {
                  date = '0' + date.toString();
                }
                var dateToCompare = month + '/' + date + '/' + thisDate.getFullYear();
                if (dateToCompare.includes(textToSearch.trim())) {
                  simpleSearchResults.push(thisRow);
                  break;
                }
              }
            }
          }
        }
      });
      if (simpleSearchResults.length === 0) {
        CommonHelperService.setToastr(CONSTANTS.TOASTERS.noRecords, "error");
      }
      $scope.myCreditsGridOptions.data = simpleSearchResults;
    };
    /* istanbul ignore next*/
    $scope.clearSearch = function (clearSearchText) {
      if (clearSearchText) {
        $scope.$$childTail.$$prevSibling.searchText = undefined;
      }
      if ($scope.numberOfFilters > 0) {
        $scope.myCreditsGridOptions.data = SearchHelperService.filterGrid($scope.$$childHead.$$childHead.$$nextSibling.grid, $scope.originalMyCreditData);
      } else {
        $scope.myCreditsGridOptions.data = $scope.originalMyCreditData;
        $scope.myData = $scope.myCreditsGridOptions.data;
      }
    };
    $scope.openCaseViewer = function (row) {
      $window.open("#/caseViewer/" + row.entity.serialNumber + "/" + row.entity.appealNumber);
    };
    $scope.callCreditsModel = function (row, modal) {

      HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTBYID + row.entity.ptabAssignmentIdentifier)
        .then(function (successResponse) {
            if (successResponse.data.globalMetaData) {
              $scope.metaData = successResponse.data.globalMetaData;
            }
            $scope[modal](row);
          },
          function () {
            // Empty response is ok
          });


    };
    $scope.updateCredits = function (row) {
      ngDialog.open({
        template: 'app/components/widgets/myCredits/updateCredits.html',
        controller: 'updateCreditsController',
        controllerAs: 'vm',
        width: '55%',
        showClose: false,
        resolve: {
          items: function () {
            return row;
          }
        }
      }).closePromise.then(function (refresh) {
        if (refresh.value) {
          $scope.refreshGrid();
        }
      });
    };

    $scope.refreshGrid = function () {
      vm.refreshProcess = true;
      $scope.checkTimeFrame($scope.refreshGridByMonth);
    };

    /*istanbul ignore next*/
    $scope.saveGridPreferences = function () {
      if ($scope.gridApi) {
        $scope.gridState = setGridState($scope.gridApi.saveState.save());
      } else if ($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi) {
        $scope.gridState = setGridState($scope.$parent.$parent.$parent.$$childHead.$$childHead.$$childHead.gridApi.saveState.save());
      }

      $scope.updateColumns();
    };
    /*istanbul ignore next*/
    $scope.getMyCreditsColumns = function () {
      if (isMyCredits || $scope.definition.type === 'myCreditsPl') {
        isMyCredits = false;
        HttpFactory.getActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS + $scope.widgetIdentifier)
          .then(function (successResponse) {
            $scope.updatedMyCreditsColumnList = successResponse.data.selectedColumns;
            $scope.selectedCols = [];
            $scope.availableCols = [];
            angular.forEach($scope.updatedMyCreditsColumnList, function (thisColumn) {
              if (thisColumn.visible) {
                $scope.selectedCols.push(thisColumn);
              } else {
                $scope.availableCols.push(thisColumn);
              }
            });
            $scope.originShowHide = angular.copy($scope.updatedMyCreditsColumnList);
            $scope.loadedColumns = true;
            for (var i = 0; i < $scope.updatedMyCreditsColumnList.length; i++) {
              if (!$scope.updatedMyCreditsColumnList[i].visible) {
                $scope.selectUnselect = false;
                $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
              }
            }
          }, function () {
            // Empty response is ok
          });
      }
    };


    $scope.getCreditOptions = function () {
      var role = "CREDIT_OPTIONS" + getRole();

      HttpFactory.getActions("/reference-data/code-reference-types?typeCode=" + role)
        .then(function (successResponse) {
          $scope.creditOptions = successResponse.data;
        }, function () {
          // Empty response is ok
        });
    };

    $scope.onKeyup = function (url, advancedSearchFlag, $event) {
      if ($event.keyCode === 13) {
        $scope.setUrl(url, advancedSearchFlag);
      }
    };
    $scope.enterOnActions = function ($event, functionToInvoke) {
      if ($event.keyCode === 13 && functionToInvoke) {
        $scope[functionToInvoke]();
      }
    };


    function getRole() {
      if ($rootScope.userInfo.roleDescription) {
        if ($rootScope.userInfo.roleDescription.toUpperCase().indexOf('JUDGE') > -1) {
          $scope.isPL = false;
          $scope.isJudge = true;
          return "_JUDGE";
        } else if ($rootScope.userInfo.roleDescription.toUpperCase().indexOf('ATTORNEY') > -1) {
          $scope.isPL = false;
          return "_PA";
        } else if ($rootScope.userInfo.roleDescription.toUpperCase().indexOf('PARALEGAL') > -1) {
          $scope.isPL = true;
          return "_PL";
        } else {
          return "";
        }
      }
    }
    $scope.getCreditOptions();
    $scope.correctDu = function (row, type) {
      if (!type) {
        type = "CDU";
      }
      ngDialog.open({
        template: 'app/components/widgets/myCredits/correctDu.html',
        controller: 'correctDuController',
        controllerAs: 'vm',
        width: '60%',
        showClose: false,
        resolve: {
          items: function () {
            return row;
          },
          type: function () {
            return type;
          },
          userId: function () {
            return $scope.userId;
          },
          displayName: function () {
            return $scope.displayName;
          },
          metaData: function () {
            return $scope.metaData;
          },
          widgetIdentifier: function () {
            return $scope.widgetIdentifier;
          }
        }
      }).closePromise.then(function (refresh) {
        if (refresh.value) {
          $scope.refreshGrid();
        }
      });
    };



    $scope.rellocateDu = function (rowData) {
      ngDialog.open({
        template: 'app/components/widgets/myCredits/reallocateDu.html',
        controller: 'reallocateDuController',
        controllerAs: 'vm',
        width: '60%',
        showClose: false,
        resolve: {
          metaData: function () {
            return $scope.metaData;
          },
          // items: function () {
          //   return row;
          // },
          userId: function () {
            return $scope.userId;
          },
          displayName: function () {
            return $scope.displayName;
          },
          rowData: function () {
            return rowData;
          },
          widgetIdentifier: function () {
            return $scope.widgetIdentifier;
          }
        }
      }).closePromise.then(function (refresh) {
        if (refresh.value) {
          $scope.refreshGrid();
        }
      });
    };

    $scope.correctPc = function (row, type) {
      if (!type) {
        type = "CPC";
      }
      ngDialog.open({
        template: 'app/components/widgets/myCredits/correctDu.html',
        controller: 'correctDuController',
        controllerAs: 'vm',
        width: '60%',
        showClose: false,
        resolve: {
          items: function () {
            return row;
          },
          type: function () {
            return type;
          },
          userId: function () {
            return $scope.userId;
          },
          displayName: function () {
            return $scope.displayName;
          },
          metaData: function () {
            return $scope.metaData;
          },
          widgetIdentifier: function () {
            return $scope.widgetIdentifier;
          }
        }
      }).closePromise.then(function (refresh) {
        if (refresh.value) {
          $scope.refreshGrid();
        }
      });
    };



    $scope.requestADU = function (row) {
      row.entity.type = "Request";
      ngDialog.open({
        template: 'app/components/widgets/myCredits/requestADU.html',
        controller: 'requestADUController',
        controllerAs: 'vm',
        width: '60%',
        showClose: false,
        resolve: {
          metaData: function () {
            return $scope.metaData;
          },
          items: function () {
            return row;
          },
          userId: function () {
            return $scope.userId;
          },
          displayName: function () {
            return $scope.displayName;
          },
          rowData: function () {
            return row;
          },
          requestType: function () {
            return "REQUESTADU";
          },
          widgetIdentifier: function () {
            return $scope.widgetIdentifier;
          }
        }
      }).closePromise.then(function (refresh) {
        if (refresh.value) {
          $scope.refreshGrid();
        }
      });
    };


    $scope.reconsiderAdu = function (row) {
      row.entity.type = "Reconsideration";
      ngDialog.open({
        template: 'app/components/widgets/myCredits/requestADU.html',
        controller: 'requestADUController',
        controllerAs: 'vm',
        width: '60%',
        showClose: false,
        resolve: {
          items: function () {
            return row;
          },
          userId: function () {
            return $scope.userId;
          },
          displayName: function () {
            return $scope.displayName;
          },
          rowData: function () {
            return row;
          },
          requestType: function () {
            return "RECONSIDERATIONADU";
          },
          metaData: function () {
            return $scope.metaData;
          },
          widgetIdentifier: function () {
            return $scope.widgetIdentifier;
          }
        }
      }).closePromise.then(function (refresh) {
        if (refresh.value) {
          $scope.refreshGrid();
        }
      });
    };

    $scope.requestPc = function (row) {
      ngDialog.open({
        template: 'app/components/widgets/myCredits/requestPc.html',
        controller: 'requestPcController',
        controllerAs: 'vm',
        width: '60%',
        showClose: false,
        resolve: {
          metaData: function () {
            return $scope.metaData;
          },
          items: function () {
            return row;
          },
          userId: function () {
            return $scope.userId;
          },
          displayName: function () {
            return $scope.displayName;
          },
          rowData: function () {
            return row;
          },
          widgetIdentifier: function () {
            return $scope.widgetIdentifier;
          }
        }
      }).closePromise.then(function (refresh) {
        if (refresh.value) {
          $scope.refreshGrid();
        }
      });
    };



    $scope.correctPaTimeliness = function (row) {

      $scope.correctDu(row, "CPT");
    };


    $scope.requestPGA = function () {
      var userData = {
        fiscalYear: $scope.fiscalYear,
        currentPGA: $scope.currentPGA,
        totalCreditsFY: $scope.totalCreditsFY,
        pgaGoalColor: $scope.pgaGoalColor,
        section: $scope.userSection,
        division: $scope.userDivision,
        userNumber: $scope.userNumber
      };


      ngDialog.open({
        template: 'app/components/widgets/myCredits/requestPga.html',
        controller: 'requestPgaController',
        controllerAs: 'vm',
        width: '50%',
        showClose: false,
        resolve: {
          userData: function () {
            return userData;
          },
          userId: function () {
            return $scope.userId;
          },
          displayName: function () {
            return $scope.displayName;
          },
          // rowData: function () {
          //   return row;
          // },
        }

      }).closePromise.then(function (refresh) {
        if (refresh.value) {
          $scope.refreshGrid();
        }
      });
    };


    /* istanbul ignore next: toaster errors*/
    $scope.updateColumns = function () {
      $scope.isLoading = true;
      var mycreditScopeList = angular.element(document.getElementById('myCreditsColums')).scope();
      var columnsSelected = [];
      var fromModal = false;
      if (angular.isDefined(mycreditScopeList)) {
        columnsSelected = angular.copy(mycreditScopeList.selectedCols);
        angular.forEach(mycreditScopeList.availableCols, function (available) {
          columnsSelected.push(available);
        });

        fromModal = true;
      } else {
        columnsSelected = $scope.columnDetails;
      }

      var updatedColumns = CommonHelperService.setColumnsToUpdate(columnsSelected, fromModal, $scope.gridState, $scope.widgetIdentifier);

      if (angular.isDefined(mycreditScopeList)) {
        mycreditScopeList.originShowHide = angular.copy(updatedColumns.selectedColumns);
      }

      HttpFactory.putActions(CONSTANTS.URL.SHOW_HIDE_COLUMNS, updatedColumns)
        .then(function (successResponse) {
            CommonHelperService.setToastr(CONSTANTS.TOASTERS.gridSave, "success");
            $scope.preferencesChanged = false;

            if (fromModal) {
              var newData = successResponse.config.data.selectedColumns;
              $scope.updatedColumnList = newData;

              var setColumnsResponse = CommonHelperService.setColumnDefinitions($scope.updatedColumnList);
              $scope.updatedMyCreditsColumnList = setColumnsResponse.colDefs;
              hasFilterFlag = setColumnsResponse.filterCount;

              updateColumnDefs(setColumnsResponse.colDefs);

              $scope.myCreditsGridOptions.data = CommonHelperService.setGridData(hasFilterFlag, newData, setColumnsResponse.colDefs);

              $scope.numberOfFilters = hasFilterFlag;
              var allGrids = document.getElementsByClassName('ui-grid');
              for (var j = 0; j < allGrids.length; j++) {
                if (angular.element(allGrids[j]).scope().widgetIdentifier === $scope.widgetIdentifier) {
                  updateColumnDefs(setColumnsResponse.colDefs);

                  angular.element(allGrids[j]).scope().myCreditsGridOptions.columnDefs = $scope.myCreditsGridOptions.columnDefs;
                  if ($scope.numberOfFilters > 0) {
                    var filteredData = SearchHelperService.filterTable($scope.myData, setColumnsResponse.colDefs);
                    $scope.myCreditsGridOptions.data = filteredData;
                  } else {


                    $scope.myCreditsGridOptions.data = successResponse.config.data.selectedColumns;
                  }
                  break;
                }
              }
              $rootScope.myCreditsPlColumnsChanged = false;
            }

            $scope.noRecordsFound = true;
          },
          function () {
            CommonHelperService.setToastr(CONSTANTS.TOASTERS.gridSaveFail, "error");

          }).finally(function () {
          $scope.isLoading = false;
          //  $scope.refreshGrid();
        });
    };

    /* istanbul ignore next  */
    // $scope.toggleSelectAll = function (flag) {
    //   var columnList = angular.element(document.getElementById('myCreditsColums')).scope();
    //   var allSelectedColumns = [];
    //   for (var i = 0; i < columnList.updatedMyCreditsColumnList.length; i++) {
    //     var currentColumn = {};
    //     if (!flag && !columnList.updatedMyCreditsColumnList[i].mandatory) {
    //       columnList.updatedMyCreditsColumnList[i].visible = false;
    //     } else {
    //       columnList.updatedMyCreditsColumnList[i].visible = true;
    //     }
    //     currentColumn = columnList.updatedMyCreditsColumnList[i];
    //     allSelectedColumns.push(currentColumn);
    //   }
    //   $scope.selectedColumns = allSelectedColumns;
    // };
    /* istanbul ignore next  */
    $scope.areAllSelected = function () {
      var columnList = angular.element(document.getElementById('myCreditsColums')).scope();
      for (var i = 0; i < columnList.updatedMyCreditsColumnList.length; i++) {
        if (!columnList.updatedMyCreditsColumnList[i].visible) {
          $scope.selectUnselect = false;
          break;
        } else {
          $scope.selectUnselect = true;
        }
        $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
      }
    };
    /* istanbul ignore next  */
    function checkForUnsavedChanges() {
      if (!initialLoad) {
        if (isFilterChanged || isColumnVisibilityChanged || isColumnSizeChanged || isSortChanged || isColumnPositionChanged || isPaginationChanged || isColumnPinnedChanged) {
          $scope.preferencesChanged = true;
        } else {
          $scope.preferencesChanged = false;
        }
      }

    }

    function setGridState(gridApiSaveState) {
      return CommonHelperService.setGridWidthMap(gridApiSaveState);
    }
    /* istanbul ignore next*/
    $scope.exportData = function () {
      var csv = CommonHelperService.download_csv($scope.columnDetails, $scope.myData);
      var hiddenElement = document.createElement('a');
      hiddenElement.href = URL.createObjectURL(new Blob([csv], {
        type: 'text/csv'
      }));
      hiddenElement.target = '_blank';
      hiddenElement.download = 'MyCredits ' + CommonHelperService.getCurrentTime() + '.csv';
      hiddenElement.click();
    };
    $scope.callMyTeam = function () {
      var url = $scope.constructedurl + "&listBy=TEAM";
      $scope.getCreditsBasedOnParam(url);
    };
    $scope.callMyGroup = function () {
      var url = $scope.constructedurl + "&listBy=GROUP";
      $scope.getCreditsBasedOnParam(url);
    };
    $scope.callMyCredits = function () {
      var url = $scope.constructedurl;
      $scope.getCreditsBasedOnParam(url);
    };
    $scope.callMyRequests = function () {
      // var url = $scope.constructedurl;
      //  var url = '/get-pc?widgetId='+ $scope.widgetIdentifier
      $scope.myCreditsGridOptions.columnDefs = [{
          displayName: "Case#",
          headerTooltip: 'Case#',
          cellTooltip: true,
          field: "caseNumber",
          width: 145
        },
        {
          displayName: "Application#",
          headerTooltip: 'Application#',
          cellTooltip: true,
          field: "serialNumber",
          width: 145
        },
        {
          displayName: "Production credit",
          headerTooltip: 'Production credit',
          cellTooltip: true,
          field: "creditQuantities",
          width: 145
        },
        {
          displayName: "Additional production credit",
          headerTooltip: 'Additional production credit',
          cellTooltip: true,
          field: "creditQuantities",
          width: 145
        },
        {
          displayName: "Total credit",
          headerTooltip: 'Total credit',
          cellTooltip: true,
          field: "creditQuantities",
          width: 145
        },
        {
          displayName: "Date of request",
          cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.awardedDate | date: \'MM/dd/yyyy hh:mm:ss a\' : \'UTC-05\' }} ET  </div>',
          headerTooltip: 'Date of request',
          cellTooltip: true,
          field: "awardedDate",
          type: "date",
          width: 185
        },
        {
          displayName: "Status",
          headerTooltip: 'Status',
          cellTooltip: true,
          field: "creditActions",
          type: "string",
          width: 120
        },
        {
          displayName: "Credits requested/corrected",
          cellTemplate: '<div class="ui-grid-cell-contents"><span ng-if=\"row.entity.creditTypeCode === \'RADU\'\">requested for {{row.entity.creditQuantities}} additional decisional units</span><span ng-if=\"row.entity.creditTypeCode === \'CDU\'\">requested for {{row.entity.creditQuantities}} decisional units</span><span ng-if=\"row.entity.creditTypeCode === \'RFADU\'\">requested for {{row.entity.creditQuantities}} additional decisional units</span><span ng-if=\"row.entity.creditTypeCode === \'CPT\'\">requested for {{row.entity.creditQuantities}} correct  patent timeliness</span><span ng-if=\"row.entity.creditTypeCode === \'RAPC\'\">requested for {{row.entity.creditQuantities}} additional production units</span><span ng-if=\"row.entity.creditTypeCode === \'CPC\'\">requested for {{row.entity.creditQuantities}} production units</span></div>',
          headerTooltip: 'Credits requested/corrected',
          cellTooltip: true,
          field: "creditQuantities",
          type: "number",
          width: 285
        },
        {
          displayName: "Supervisor",
          headerTooltip: 'Supervisor',
          cellTooltip: true,
          field: "supervisoryName",
          width: 185,
        },
        {
          displayName: "Assignment title",
          headerTooltip: 'Assignment  title',
          cellTooltip: true,
          field: "assignmentTitle",
          type: "string",
          width: 260
        },
        {
          displayName: "Date assigned",
          cellTemplate: '<div class="ui-grid-cell-contents"><span ng-if=\"row.entity.creditActions === \'Submitted\'\">{{row.entity.awardedDate | date: \'MM/dd/yyyy hh:mm:ss a\' : \'UTC-05\' }} ET </span></div>',
          headerTooltip: 'Date assigned',
          cellTooltip: true,
          field: "awardedDate",
          type: "date",
          width: 185
        },
        {
          displayName: "Completion date",
          cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.completionDate | date: \'MM/dd/yyyy hh:mm:ss a\' : \'UTC-05\' }} ET  </div>',
          headerTooltip: 'Completion date',
          cellTooltip: true,
          field: "completionDate",
          type: "date",
          sort: {},
          width: 185
        },
        {
          name: 'Actions',
          headerTooltip: 'Actions',
          enableFiltering: false,
          enableSorting: false,
          width: 90,
          pinnedRight: true,
          enableColumnMenu: false,
          cellClass: 'action-drop-down-grid',
          cellTemplate: 'app/components/widgets/myCredits/creditsActionsDropdown.html'
        }
      ];
      $scope.creditsRequests();
      // $scope.getCreditsBasedOnParam(url);
    };

    $scope.creditsRequests = function () {
      $scope.isLoading = true;
      HttpFactory.getActions("/credits-views/get-pc?creditsWidget=" + $scope.widgetIdentifier + "&" + $scope.constructedurl)
        .then(function (successResponse) {
          $scope.isLoading = false;
          if (successResponse.data.startDate && successResponse.data.endDate) {
            $scope.startDate = new Date(successResponse.data.startDate);
            $scope.endDate = new Date(successResponse.data.endDate);
          }
          $scope.myCreditsGridOptions.data = successResponse.data.mycreditsData;
          $scope.myCreditsGridOptions.paginationPageSizes = [10, 25, 50, 100];
          $scope.myCreditsGridOptions.paginationPageSize = 25;

        }, function () {
          $scope.isLoading = false;
          CommonHelperService.setToastr("", "clear");
          CommonHelperService.setToastr(CONSTANTS.TOASTERS.refreshFail, "error");
        });
    };
    $scope.submitCredit = function (row) {
      vm.isPreviouslyRejected = true;
      $scope.fileInfo = {};
      if (row.entity.workProductUrl && row.entity.workProductUrl.trim() != "") {
        $scope.fileInfo.name = row.entity.workProductUrl.split(vm.serialNumber + "_").pop();
        vm.fullFileName = row.entity.workProductUrl;
      }
      var data = {
        "decisionalUnits": row.entity.decisionalUnits,
        "requestedDecisionalUnits": row.entity.creditQuantities,
        "ptabAssignmentIdentifier": row.entity.ptabAssignmentIdentifier,
        "reason": row.entity.reason,
        "supervisorId": row.entity.requestorId,
        "completionDate": vm.completionDate,
        "appealNumber": row.entity.caseNumber,
        "serialNumber": row.entity.serialNumber,
        "caseType": vm.caseType,
        "totalDraftDecisionTime": row.entity.recordHour,
        "personToReceiveCredits": $scope.userId,
        "audit": {
          "createUserIdentifier": $scope.userId,
          "lastModifiedUserIdentifier": $scope.userId
        },
        "decisionalUnitsAwarded": vm.decisionalUnitsAwarded,
        "assignmentType": vm.assignmentType,
        "qualifier": vm.qualifier,
        "specialType": row.entity.specialType ? row.entity.specialType.trim() != "" ? row.entity.specialType : '' : '',
        "assignmentTitle": row.entity.assignmentTitle,
        "dateOfRequest": new Date().getTime(),
        "widgetIdentifier": $scope.widgetIdentifier,
        "fileName": ($scope.fileInfo != null || $scope.fileInfo != undefined) ? $scope.fileInfo.name : null,
        "attachmentInBytes": null,
        "creditTypeCode": row.entity.creditTypeCode,
        "requestStatus": "Submitted"
      };
      if (vm.isPreviouslyRejected) {
        data.approverCommentText = vm.rejectedReason;
        data.isPreviouslyRejected = true;
        if ($scope.fileInfo && $scope.fileInfo.name && $scope.fileInfo.name.trim != "") {
          data.previousWorkProductUrl = vm.fullFileName;
        }
      }

      HttpFactory.putActions(CONSTANTS.URL.MY_CREDITS_REQUESTDU, data)
        .then(function () {
          vm.disableSubmit = false;
          CommonHelperService.setToastr("", "clear");
          CommonHelperService.setToastr(CONSTANTS.TOASTERS.submissionSuccess, "success");
          ngDialog.closeAll(true);
          $scope.creditsRequests();
        }, function () {
          vm.disableSubmit = false;
          CommonHelperService.setToastr("", "clear");
          CommonHelperService.setToastr(CONSTANTS.TOASTERS.submissionFail, "error");
        });
    };
    $scope.deleteCredit = function (row) {
      HttpFactory.deleteActions("/credits-request/delete?creditAwardId=" + row.entity.creditAwardId + "&creditAdjustmentRequestId=" + row.entity.creditAdjustmentRequestId)
        .then(function () {
          CommonHelperService.setToastr("", "clear");
          CommonHelperService.setToastr(CONSTANTS.TOASTERS.creditSuccess, "success");
          $scope.creditsRequests();
        }, function () {
          CommonHelperService.setToastr("", "clear");
          CommonHelperService.setToastr(CONSTANTS.TOASTERS.creditFail, "error");
        });
    };
    $scope.editCredit = function (row, type) {
      row.entity.isEdit = true;
      if (type === 'RADU') {
        $scope.callCreditsModel(row, "requestADU");
      }
      if (type === 'CDU') {
        $scope.callCreditsModel(row, "correctDu");
      }
      if (type === 'RFADU') {
        $scope.callCreditsModel(row, "reconsiderAdu");
      }
      if (type === 'CPT') {
        $scope.callCreditsModel(row, "correctPaTimeliness");
      }
      if (type === 'RAPC') {
        $scope.callCreditsModel(row, "requestPc");
      }
      if (type === 'CPC') {
        $scope.callCreditsModel(row, "correctPc");
      }
    };
    /*istanbul ignore next*/
    $scope.getCreditsBasedOnParam = function (url) {
      $scope.isLoading = true;
      HttpFactory.getActions($scope.mycreditsDataUrlList + url)
        .then(function (successResponse) {
          $scope.isLoading = false;
          // if (successResponse.data.columnDetails && $rootScope.userInfo.roleDescription.toUpperCase().indexOf('PARALEGAL') > -1) {
          //   successResponse.data.columnDetails.forEach(function (element) {
          //     if (element.columnName[0] == "additionalDecisionalUnits") {
          //       element.columnLabel = "Additional production credits (APC)";
          //       element.aggregationLabel = "Total APC"
          //     }
          //   })
          // }
          $scope.columnDetails = successResponse.data.columnDetails;
          $scope.selectedColmns = successResponse.data.columnDetails;
          $scope.userSection = successResponse.data.section;
          $scope.userDivision = successResponse.data.division;

          getPGAAndTotalCredits(successResponse.data);

          if (successResponse.data.startDate && successResponse.data.endDate) {
            $scope.startDate = new Date(successResponse.data.startDate);
            $scope.endDate = new Date(successResponse.data.endDate);
          }

          $scope.myData = successResponse.data.mycreditsData;

          $scope.isSupervisor = successResponse.data.hierarchy;
          if (successResponse.data.mycreditsData) {
            vm.getDistinctAssignmentTypes(successResponse.data.mycreditsData);
          }


          $scope.filterCount = 0;

          initialLoad = false;
          $scope.myCreditsGridOptions.data = successResponse.data.mycreditsData;
          if (successResponse.data.mycreditsData && successResponse.data.mycreditsData.length > 100) {
            if ($scope.myCreditsGridOptions.paginationPageSizes && $scope.myCreditsGridOptions.paginationPageSizes.length > 4) {
              $scope.myCreditsGridOptions.paginationPageSizes[4] = successResponse.data.mycreditsData.length;
            } else {
              $scope.myCreditsGridOptions.paginationPageSizes.push(successResponse.data.mycreditsData.length);
            }

          }
          $scope.myCreditsGridOptions.paginationPageSize = successResponse.data.paginationSize ? successResponse.data.paginationSize : 25;

          $scope.lastRefresh = new Date();
          $scope.originalMyCreditData = angular.copy($scope.myCreditsGridOptions.data);
          $scope.myData = $scope.myCreditsGridOptions.data;
          $rootScope.assignmentTypesArray = $scope.assignmentTypesArray;
          $rootScope.caseTypesArray = $scope.caseTypesArray;
          $rootScope.awardedToArray = $scope.awardedToArray;
          var setColumnsResponse = CommonHelperService.setColumnDefinitions($scope.columnDetails);
          $scope.selectUnselect = setColumnsResponse.selectUnselect;
          $scope.originalSelectUnselect = angular.copy($scope.selectUnselect);
          hasFilterFlag = setColumnsResponse.filterCount;
          updateColumnDefs(setColumnsResponse.colDefs);
          setGridData(setColumnsResponse.colDefs);
          if (vm.refreshProcess) {
            CommonHelperService.setToastr(CONSTANTS.TOASTERS.refreshData, "success");
            vm.refreshProcess = false;
          }
        }, function (failureResponse) {
          $scope.isLoading = false;
          if (vm.refreshProcess) {
            CommonHelperService.setToastr(CONSTANTS.TOASTERS.refreshFail, "warning");
            vm.refreshProcess = false;
          }
        });
    };

    function getPGAAndTotalCredits(data) {


      $scope.currentPGA = data.requestHourQt;
      $scope.totalCreditsFY = data.totalCredits;
      if (!$scope.fiscalYear) {
        var now = new Date();
        var year = now.getYear();
        var month = now.getMonth();
        $scope.fiscalYear = year - 100;
        if (month > 9) {
          $scope.fiscalYear++;
        }
      }
      if (!$scope.totalCreditsFY) {
        $scope.totalCreditsFY = 0;
      }
      $scope.pgaGoalColor = getPGAColor();

    }

    function getPGAColor() {
      var date1Value = "10/01/20" + ($scope.fiscalYear - 1);
      var date1 = new Date(date1Value);
      var date2Value = "09/30/20" + ($scope.fiscalYear);
      var date2 = new Date(date2Value);
      // To calculate the time difference of two dates
      var Difference_In_Time = date2.getTime() - date1.getTime();
      // To calculate the no. of days between two dates
      var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
      var now = new Date();
      var current_difference_In_Time = now.getTime() - date1.getTime();
      // To calculate the no. of days between two dates
      var current_difference_In_Days = current_difference_In_Time / (1000 * 3600 * 24);

      var x = $scope.currentPGA * current_difference_In_Days / Difference_In_Days;
      var percentageOfPGA = $scope.totalCreditsFY / x * 100;

      if (percentageOfPGA > 110) {
        return 'tcExcellent';
      }

      if (percentageOfPGA > 90) {
        return 'tcSuccess';
      }

      if (percentageOfPGA > 70) {
        return 'tcWarning';
      }

      if (percentageOfPGA > 50) {
        return 'tcSerious';
      }

      if (percentageOfPGA <= 50) {
        return 'tcDanger';
      }
    }


    $scope.getMyTeamCreditsPl = function () {
      $scope.hideSave = false;
      $scope.currentModal = "myTeam";
      $scope.checkTimeFrame($scope.refreshGridByMonth);
    };
    $scope.getMyGroupCreditsPl = function () {
      $scope.hideSave = false;
      $scope.currentModal = "myGroup";
      $scope.checkTimeFrame($scope.refreshGridByMonth);
    };
    $scope.getMyRequestsPl = function () {
      $scope.hideSave = true;
      $scope.currentModal = "myRequest";
      $scope.checkTimeFrame($scope.refreshGridByMonth);
    };
    /* istanbul ignore next */
    $scope.getMyCreditsPl = function () {
      $scope.hideSave = false;
      vm.getMyCreditsPl(vm.globalWidgetId);
    };

    /*istanbul ignore next*/
    $scope.changeDate = function (filterType) {
      HttpFactory.getActions(CONSTANTS.URL.MY_CREDITS + $scope.widgetIdentifier + '/' + firstDay.getTime() / 1000 + '/' + lastDay.getTime() / 1000)
        .then(function (successResponse) {
          $scope.myCreditsGridOptions.data = successResponse.data.mycreditsData;
        }, function () {
          // Empty response is ok
        });
    };
    /*istanbul ignore next*/
    vm.getTimeFramesOptions = function () {
      var notInTimeFrames = ['ptabReadOnlyUser', 'ptabDueDateNonEditableUser', 'allowedResourceObjectList', 'ptabDefaultRefreshTime'];
      HttpFactory.getActions(CONSTANTS.URL.MY_CREDITS_TIMEFRAME + "?role=" + getRole())
        .then(function (successResponse) {
          $scope.timeframesResponse = successResponse.data;
          $scope.timeframes = [];
          angular.forEach($scope.timeframesResponse, function (value, key) {
            if (notInTimeFrames.indexOf(key) == -1) {
              $scope.timeframes.push({
                key: key,
                value: value
              });
            }
          });
          $scope.timeframes.sort(function (a, b) {
            return a.value - b.value;
          });
        }, function () {
          // Empty response is ok
        });
    };
    /* istanbul ignore next */
    $scope.checkTimeFrame = function (value) {
      $scope.refreshGridByMonth = value;
      if (value === "2") {
        $scope.constructedurl = "timeFrame=2";
      } else if (value === "1" || value === "CURRENTMONTH") {
        $scope.constructedurl = "timeFrame=1";
      } else if (value === "DATERANGE") {
        $scope.newEndDate = $scope.endDate;
        if (angular.isNumber($scope.endDate)) {
          $scope.newEndDate = ($scope.endDate + 86400000) / 1000;
        } else if ($scope.endDate) {
          $scope.newEndDate = ($scope.endDate.getTime() + 86400000) / 1000;
        }

        $scope.constructedurl = "startDate=" + $scope.startDate / 1000 + "&endDate=" + $scope.newEndDate;
      } else if (value === "PAYPERIOD") {
        $scope.newEndDate = $scope.endDate;
        if (angular.isNumber($scope.endDate)) {
          $scope.newEndDate = ($scope.endDate + 86400000) / 1000;
        } else if ($scope.endDate) {
          $scope.newEndDate = ($scope.endDate.getTime() + 86400000) / 1000;
        }
        $scope.constructedurl = "payPeriod=" + $scope.payperiod;
      } else {
        var ul = "1";
        if (value) {
          ul = value;
        } else {
          ul = "1";
        }
        $scope.constructedurl = "timeFrame=" + ul;
      }
      if ($scope.currentModal === "myTeam") {
        $scope.callMyTeam();
      }
      if ($scope.currentModal === "myGroup") {
        $scope.callMyGroup();
      }
      if ($scope.currentModal === "myCredits") {
        $scope.callMyCredits();
      }
      if ($scope.currentModal === "myRequest") {
        $scope.callMyRequests();
      }
    };

    $scope.enterOnActions = function ($event, functionToInvoke) {
      if ($event.keyCode === 13 && functionToInvoke) {
        $scope[functionToInvoke]();
      }
    };

    $scope.bulkUpdateCredits = function () {
      var selectedRows = angular.copy($scope.gridApi.selection.getSelectedRows());
      if (selectedRows.length === 0) {
        CommonHelperService.setToastr(CONSTANTS.TOASTERS.selectCredits, "error", 4000);
        return;
      }

      var template = "app/components/widgets/myCredits/bulkUpdateCredits.html";
      ngDialog.open({
        template: template,
        controller: 'BulkUpdateCreditsController',
        controllerAs: 'vm',
        width: "90%",
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,
        resolve: {
          gridData: function () {
            return selectedRows;
          },
          type: function () {
            return $scope.currentModal;
          },
          userId: function () {
            return $scope.userId;
          }
        }
      }).closePromise.then(function (response) {
        if (response.value) {
          if ($scope.currentModal === 'myTeam') {
            $scope.getMyTeamCreditsPl();
          } else {
            $scope.getMyGroupCreditsPl();
          }
        }


      });

    };


    $scope.openPGAAdminConsole = function () {
      var template = "app/components/widgets/myCredits/pgaAdminConsole.html";
      ngDialog.open({
        template: template,
        controller: 'PGAAdminController',
        controllerAs: 'vm',
        width: "50%",
        showClose: false,
        closeByEscape: false,
        closeByDocument: false,
        resolve: {
          userId: function () {
            return $scope.userId;
          }
        }
      }).closePromise.then(function (response) {
        if (response.value) {
          if ($scope.currentModal === 'myTeam') {
            $scope.getMyTeamCreditsPl();
          } else {
            $scope.getMyGroupCreditsPl();
          }
        }


      });

    };

    /*istanbul ignore next*/
    $scope.getTimeFrames = function (value) {
      $scope.checkTimeFrame(value);
      if (value === "PREVIOUSMONTH") {
        var now = new Date();
        var prevMonthLastDate = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 0);
        var prevMonthFirstDate = new Date(now.getFullYear() - (now.getMonth() > 0 ? 0 : 1), (now.getMonth() - 1 + 12) % 12, 1);
        $scope.dateType = $scope.dateTypes[1];
        var formatDateComponent = function (dateComponent) {
          return (dateComponent < 10 ? '0' : '') + dateComponent;
        };

        var formatDate = function (date) {
          return formatDateComponent(date.getMonth() + 1) + '/' + formatDateComponent(date.getDate()) + '/' + date.getFullYear();
        };

        $scope.startDate = formatDate(prevMonthFirstDate);
        $scope.endDate = formatDate(prevMonthLastDate);
      } else {
        if (value == "1") {
          $scope.dateType = $scope.dateTypes[0];
        } else if (value == "2") {
          $scope.dateType = $scope.dateTypes[1];
        } else {
          $scope.dateType = $scope.dateTypes[4];
        }

        var date = new Date();
        $scope.startDate = new Date(date.getFullYear(), date.getMonth(), 1);
        $scope.endDate = new Date(date.getFullYear(), date.getMonth() + 1, 0, 23, 59, 59, 0);
      }
    };
    /* istanbul ignore if */
    if (angular.isDefined($scope.$parent.model)) {
      $scope.mycreditsDataUrlList = $scope.$parent.model.dataUrlText;

      $scope.widgetIdentifier = $scope.$parent.model.widgetIdentifier;
      vm.getTimeFramesOptions();
      vm.getMyCreditsPl($scope.widgetIdentifier);
    } else {
      /* istanbul ignore if */
      if ($scope.definition.type === "myCredits") {
        if (angular.isDefined($scope.$parent.model)) {
          $scope.mycreditsDataUrlList = $scope.$parent.model.dataUrlText;
          vm.getTimeFramesOptions();
          $scope.widgetIdentifier = $scope.definition.widgetIdentifier;
        } else {
          $scope.mycreditsDataUrlList = $scope.definition.dataUrlText;
          vm.getTimeFramesOptions();
          $scope.widgetIdentifier = $scope.definition.widgetIdentifier;
        }
      }

    }

  });
