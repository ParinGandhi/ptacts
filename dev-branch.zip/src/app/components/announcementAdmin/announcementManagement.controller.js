(function () {
  'use strict';
  /**
   *    AnnouncementManagementController is called when Creating an Annoucement
   */
  angular
    .module('ptabe2e')
    .controller('AnnouncementManagementController', function (ngDialog, items, $log, $rootScope, CONSTANTS, HttpFactory, CommonHelperService, $timeout) {
      var vm = this;
      /* istanbul ignore else */
      if (angular.isDefined(items.flag)) {
        vm.announcement = items;


      } else {
        vm.announcement = {};
      }
      if (angular.isDefined(vm.announcement.announcementTypeData)) {
        vm.announcement.selectedType = vm.announcement.announcementTypeData.announcementTypeNameText;
      }
      if (angular.isUndefined(vm.announcement.flag) || vm.announcement.flag === null || vm.announcement.flag === "new") {

        clearModels();
      }
      vm.announcement.openNew = false;
      vm.announcement.toClose = false;
      vm.announcement.toContinue = false;
      vm.announcement.confirmClicked = false;
      vm.focus = function () {
        $timeout(function () {
          var title = document.getElementById("addEditAnnouncementModalButton");
          if (angular.isDefined(title) && title != null) {
            title.blur();
          }
        }, 300);

      };

      $timeout(function () {
        setAriaAttribute('mceu_0', 'Undo');
        setAriaAttribute('mceu_1', 'Redo');
        setAriaAttribute('mceu_2', 'Bold');
        setAriaAttribute('mceu_3', "Italic");
        setAriaAttribute('mceu_4', "insert link");
      }, 2000);

      function setAriaAttribute(timeMcButtonId, text) {
        try {
          var tinyMcButton = document.getElementById(timeMcButtonId);
          var tinyMcButtonHTML = tinyMcButton.childNodes[0];
          tinyMcButtonHTML.setAttribute("aria-label", text);
        } catch (error) {
          $log.info("Error finding TinyMCE button");
        }
      }


      vm.focus();
      vm.announcement.constants = {};
      vm.announcement.constants.published = CONSTANTS.ANNOUNCEMENTS.STATUS_PUBLISHED;
      vm.announcement.constants.draft = CONSTANTS.ANNOUNCEMENTS.STATUS_DRAFT;
      vm.announcement.constants.archived = CONSTANTS.ANNOUNCEMENTS.STATUS_ARCHIVED;

      function clearModels() {
        vm.announcement.announcementTitleText = '';
        vm.announcement.announcementText = '';
        vm.announcement.selectedRoles = [];
        vm.announcement.selectedType = '';
        vm.announcement.lifeCycle = {};
        vm.announcement.lifeCycle.beginEffectiveDate = '';
        vm.announcement.lifeCycle.endEffectiveDate = '';
        vm.announcement.openNew = false;
        vm.announcement.toClose = false;
        vm.announcement.toContinue = false;
        vm.announcement.confirmClicked = false;
      }
      vm.changedForm = false;
      vm.changedContent = function (changed) {
        vm.changedForm = (vm.changedForm || changed);
      };





      vm.getTypesForAnnouncements = function () {
        vm.announcementTypes = [];
        HttpFactory.getActions(CONSTANTS.URL.ANNOUNCEMENT_TYPES)
          .then(function (successResponse) {
            angular.forEach(successResponse.data, function (type) {
              vm.announcementTypes.push(type.announcementTypeNameText);
            });
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };

      vm.getTypesForAnnouncements();


      vm.getRolesForAnnouncements = function () {
        vm.announcementRoles = [];
        HttpFactory.getActions(CONSTANTS.URL.ANNOUNCEMENT_USER_ROLE)
          .then(function (successResponse) {
            angular.forEach(successResponse.data, function (role) {
              var data = {
                'id': role.userRoleIdentifier,
                'label': role.descriptionText
              };
              vm.announcementRoles.push(data);


            });


          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };

      vm.multiSelectSettings = {
        scrollableHeight: '200px',
        scrollable: true,
        externalIdProp: ''
      };
      /* istanbul ignore next */
      vm.dropdownEvents = {
        onInitDone: function (item) {
          $log.info(item);
        },
        onItemSelect: function (item) {
          vm.checkLengthRoles();
        },
        onSelectAll: function (item) {
          vm.showErrorMsgRoles = false;
        },
        onItemDeselect: function () {
          vm.checkLengthRoles();
        }
      };

      vm.announcement.selectedRoles = [];
      if (angular.isDefined(vm.announcement.flag) || vm.announcement.flag !== null) {
        angular.forEach(vm.announcement.roleAnnouncements, function (role) {
          var data = {
            'id': role.userRoleIdentifier,
            'label': role.userRoleDescription
          };
          vm.announcement.selectedRoles.push(data);
        });
      }

      vm.getRolesForAnnouncements();

      vm.cancelAddEditAnnouncement = function () {
        if (vm.changedForm) {
          ngDialog.open({
            template: 'app/components/announcementAdmin/cancelAnnouncementConfirmationModal.html',
            controller: 'cancelAnnouncementPopupController',
            controllerAs: 'vm',
            width: '25%',

            showClose: false,
            resolve: {
              item: function () {
                return false;
              }
            }

          });
        } else {
          vm.announcement.flag = null;
          closeAnnouncementDialog(1);

        }
      };

      vm.saveAnnouncementDraftAndClose = function () {
        vm.announcement.toClose = true;
        vm.saveAnnouncementDraft();
        vm.announcement.openNew = false;

        vm.announcement.toContinue = false;
      };

      vm.saveAnnouncementDraftAndOpenNew = function () {
        vm.saveAnnouncementDraft();
        vm.announcement.openNew = true;

        vm.announcement.toClose = false;
        vm.announcement.toContinue = false;


      };

      vm.saveAnnouncementDraft = function () {
        vm.changedForm = false;
        vm.readyTOSave = true;
        vm.checkLengthTitle();
        vm.checkLengthContent();

        vm.announcement.statusToSave = CONSTANTS.ANNOUNCEMENTS.STATUS_DRAFT;

        vm.saveAnnoucementPostCall(vm.readyTOSave);
      };

      vm.saveAnnouncement = function () {
        vm.readyTOSave = true;
        vm.checkLengthTitle();
        vm.checkLengthContent();
        vm.announcement.statusToSave = CONSTANTS.ANNOUNCEMENTS.STATUS_DRAFT;

        vm.saveAnnoucementPostCall(vm.readyTOSave);
      };

      vm.saveAnnouncementDraftAndContinue = function () {
        vm.saveAnnouncement();

        vm.announcement.toContinue = true;
        vm.announcement.openNew = false;
        vm.announcement.toClose = false;

      };
      /* istanbul ignore next */
      function setFlagsForContinueDRAFT() {
        vm.announcement.announcementIdentifier = vm.publishAnnouncementInfo.announcementIdentifier;
        vm.announcement.announcementStatusCategory = CONSTANTS.ANNOUNCEMENTS.STATUS_DRAFT;
        vm.announcement.flag = 'Edit';
      }




      vm.saveAnnoucementPostCall = function (confirmFlag) {
        if (confirmFlag) {
          var roleName = [];
          if (vm.announcement.selectedRoles.length > 0) {

            angular.forEach(vm.announcement.selectedRoles, function (selectedRole) {
              /* istanbul ignore next */
              angular.forEach(vm.announcementRoles, function (givenRole) {
                if (selectedRole.id === givenRole.id) {
                  roleName.push(givenRole.label);
                }
              });
            });


          }
          vm.announcement.selectedRoleNames = roleName;
          vm.publishAnnouncementInfo = vm.announcement;
          ngDialog.open({
            template: 'app/components/announcementAdmin/publishAnnouncementConfirmation.html',
            controller: 'cancelAnnouncementPopupController',
            controllerAs: 'vm',
            width: '44%',
            showClose: false,
            resolve: {
              item: function () {
                return vm.publishAnnouncementInfo;
              }
            }

          }).closePromise.then(function () {
            $log.info('closed publish confirmation');
            validateConfirmClickedAndSetFlags();
          });
        }
      };


      function validateConfirmClickedAndSetFlags() {
        /* istanbul ignore if */
        if (vm.announcement.toContinue && vm.announcement.confirmClicked) {
          setFlagsForContinueDRAFT();
        }
        /* istanbul ignore if */
        if (vm.announcement.openNew && vm.announcement.confirmClicked) {
          vm.announcement.flag = null;
          clearModels();
        }
      }

      /* istanbul ignore next */
      vm.archiveAnnouncement = function () {

        var data = {};
        data.announcementIdentifier = vm.announcement.announcementIdentifier;
        data.audit = {};
        data.audit.createUserIdentifier = vm.announcement.audit.createUserIdentifier;
        data.audit.lastModifiedUserIdentifier = $rootScope.userInfo.userId;
        data.announcementStatusCategory = CONSTANTS.ANNOUNCEMENTS.STATUS_ARCHIVED;
        HttpFactory.putActions(CONSTANTS.URL.ARCHIVE_ANNOUNCEMENT + vm.announcement.announcementIdentifier, data)
          .then(function (successResponse) {
            $log.info(successResponse);
            $log.info("success put");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.annoucementArchived, "success");
            vm.announcement.flag = null;
          }, function (failureResponse) {
            $log.info(failureResponse);
            if (angular.isDefined(failureResponse.message)) {
              CommonHelperService.setToastr(failureResponse.message, "error");
            } else {
              CommonHelperService.setToastr(failureResponse.data.message, "error");
            }
            vm.announcement.flag = null;
          });
        closeAnnouncementDialog(1);
      };

      vm.confirmArchive = function (choice) {
        /* istanbul ignore if */
        if (choice) {
          vm.archiveAnnouncement();
        } else {

          closeAnnouncementDialog(1);
        }
      };

      vm.deleteAnnouncement = function () {

        /* istanbul ignore next */
        HttpFactory.deleteActions(CONSTANTS.URL.DELETE_ANNOUNCEMENT + vm.announcement.announcementIdentifier)
          .then(function (successResponse) {
            $log.info("success delete=" + successResponse);
            CommonHelperService.setToastr(CONSTANTS.TOASTER.annoucementDelete, "success");
            vm.announcement.flag = null;
          }, function (failureResponse) {
            $log.info(failureResponse);
            CommonHelperService.setToastr(CONSTANTS.TOASTER.annoucementFailed, "error");
            vm.announcement.flag = null;
          });
        closeAnnouncementDialog(1);
      };

      vm.confirmDelete = function (choice) {
        if (choice) {
          vm.deleteAnnouncement();
        } else {

          closeAnnouncementDialog(1);
        }
      };

      vm.publishAnnouncement = function () {

        vm.readyTOSave = true;
        vm.checkLengthTitle();
        vm.checkLengthContent();
        vm.checkLengthRoles();
        vm.checkLengthType();
        vm.checkStartDate();
        vm.checkEndDate();
        vm.announcement.statusToSave = CONSTANTS.ANNOUNCEMENTS.STATUS_PUBLISHED;
        vm.saveAnnoucementPostCall(vm.readyTOSave);
      };
      /* istanbul ignore next */
      vm.tinymceOptions = {
        plugins: 'link image',
        toolbar: "undo redo  bold italic  link media",
        menu: {},
        browser_spellcheck: true,
        contextmenu: false,
        elementpath: false,

        init_instance_callback: function (editor) {
          var textContentTrigger = function () {
            vm.textContent = editor.getBody().textContent;
          };

          editor.on('KeyUp', textContentTrigger);
          editor.on('ExecCommand', textContentTrigger);
          editor.on('SetContent', function (e) {
            if (!e.initial) {
              textContentTrigger();
            }

          });
        }
      };




      function closeAnnouncementDialog(popupsToClose) {

        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose]);
        } else {
          ngDialog.close();
        }
      }

      vm.checkLengthTitle = function () {
        if (angular.isUndefined(vm.announcement.announcementTitleText) || vm.announcement.announcementTitleText.length < 1) {

          vm.showErrorMsgTitle = true;
          vm.errorMessageTitle = "The announcement subject cannot be empty.";
          vm.readyTOSave = false;

        } else {
          vm.showErrorMsgTitle = false;

        }

      };


      vm.checkLengthContent = function () {
        if (angular.isUndefined(vm.announcement.announcementText) || vm.announcement.announcementText.length < 1) {

          vm.showErrorMsgContent = true;
          vm.errorMessageContent = "The announcement content cannot be empty.";
          vm.readyTOSave = false;
        } else {
          if (vm.announcement.announcementText.length > 4000) {
            vm.showErrorMsgContentOver = true;
            vm.errorMessageContentOver = "The announcement content cannot be greater than 4000.";
            vm.readyTOSave = false;
          } else {
            vm.showErrorMsgContentOver = false;
          }
          vm.showErrorMsgContent = false;
        }

      };



      vm.checkLengthRoles = function () {
        if (vm.announcement.selectedRoles.length < 1) {

          vm.showErrorMsgRoles = true;
          vm.errorMessageRoles = "The audience cannot be empty.";
          vm.readyTOSave = false;
        } else {
          vm.showErrorMsgRoles = false;
        }
      };

      vm.checkLengthType = function () {
        if (angular.isUndefined(vm.announcement.selectedType) || vm.announcement.selectedType.length < 1) {

          vm.showErrorMsgType = true;
          vm.errorMessageType = "The type of announcement cannot be empty.";
          vm.readyTOSave = false;
        } else {
          vm.showErrorMsgType = false;
        }

      };

      vm.datePickerChangedCheckStartedDate = function (compareDate) {
        vm.announcement.lifeCycle.beginEffectiveDate = compareDate;
      };

      vm.datePickerChangedCheckEndDate = function (compareDate) {
        vm.announcement.lifeCycle.endEffectiveDate = compareDate;
      };


      vm.checkStartDate = function (compareDate) {
        if (angular.isDefined(compareDate)) {
          vm.announcement.lifeCycle.beginEffectiveDate = compareDate;
        }
        /* istanbul ignore if */
        if (angular.isDefined(vm.announcement.lifeCycle) &&
          angular.isDefined(vm.announcement.lifeCycle.beginEffectiveDate) &&
          vm.announcement.lifeCycle.beginEffectiveDate >= new Date().setHours(0, 0, 0, 0)) {
          vm.showErrorMsgStartDate = false;

        } else {
          vm.showErrorMsgStartDate = true;
          vm.errorMessageStartDate = "The start date cannot be empty or before current date";
          vm.readyTOSave = false;
        }

      };

      vm.checkEndDate = function (compareDate) {
        if (angular.isDefined(compareDate)) {
          vm.announcement.lifeCycle.endEffectiveDate = compareDate;
        }
        /* istanbul ignore if */
        if (angular.isDefined(vm.announcement.lifeCycle) &&
          angular.isDefined(vm.announcement.lifeCycle.endEffectiveDate) &&
          vm.announcement.lifeCycle.endEffectiveDate >= new Date().setHours(0, 0, 0, 0)) {
          if (vm.announcement.lifeCycle.endEffectiveDate >= vm.announcement.lifeCycle.beginEffectiveDate) {
            vm.showErrorMsgEndDate = false;
          } else {
            vm.showErrorMsgEndDate = true;
            vm.errorMessageEndDate = "The end date cannot be before start date.";
            vm.readyTOSave = false;
          }
        } else {
          vm.showErrorMsgEndDate = true;
          vm.errorMessageEndDate = "The end date cannot be empty or before start date";
          vm.readyTOSave = false;
        }

      };
    });
})();
