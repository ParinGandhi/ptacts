(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('AdminController', function ($rootScope, ngDialog, $log) {
      var vm = this;

      vm.openAdminConsole = function () {
        $rootScope.worker = vm.workerNumber;

        ngDialog.open({
          template: 'app/components/announcementAdmin/announcementAdminModal.html',
          controller: 'AnnouncementAdminController',
          controllerAs: 'vm',
          width: '70%',


          showClose: false,
          closeByDocument: false,
          resolve: {
            userInfo: function () {
              return vm.userInfo;
            }
          }
        }).closePromise.then(function () {
          $log.info("Success");
        });
      };

    });
})();
