(function () {
  'use strict';

  describe('AnnouncementManagementController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var controller;
    var $rootScope, timeout;
    var $q, HttpFactoryDeferred, spy;
    var announcement;
    var $ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'close', 'getOpenDialogs']);
    var items = {
      flag: true,
      announcementStatusCategory: "PREVIEW",
      statusToSave: "PREVIEW",
      toClose: true,
      lifeCycle: {
        endEffectiveDate: 2018,
        beginEffectiveDate: 2017,
        audienceStr: "test"
      },
      selectedRoles: [{

      }],
      listRoleDisplaySequence: [{
        userRoleIdentifier: "test",
        userRoleName: "Admin"
      }],
      announcementTypeData: {

      }
    };

    var successResponse = {
      data: {
        events: {},
        refreshInterval: 0
      }
    };

    var failureResponse = {};

    beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_, _$q_, HttpFactory) {
      $q = _$q_;
      timeout = _$timeout_;
      $controller = _$controller_;
      $rootScope = _$rootScope_;
      $ngDialog.open.and.returnValue({
        closePromise: {
          then: function (callback) {
            callback({
              value: 1
            });

          }
        }
      });

      // setup the promise
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'deleteActions').and.returnValue(HttpFactoryDeferred.promise);

      controller = $controller('AnnouncementManagementController', {
        ngDialog: $ngDialog,
        items: items
      });
    }));

    describe('Initializations', function () {
      it('should initialize workspace', function () {

        expect(vm.announcement).toBeDefined;


      });
    });

    describe('AnnouncementManagementController ', function () {

      it('it should call focus', function () {

        var dummyElement = document.createElement('div');
        document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(dummyElement);
        spyOn(document.getElementById("dialogClose"), 'blur');
        expect(document.getElementById("dialogClose").blur).toBeDefined();
        expect(controller['focus']).toBeDefined();
        controller.focus();
        timeout.flush();
        expect(dummyElement.blur).toHaveBeenCalled();

      });

      it('Should invoke focus', function () {

        spyOn(controller, 'focus');
        expect(controller['focus']).toBeDefined();

      });

      it('it should call change Content', function () {

        var changed = true;
        expect(controller.changedContent).toBeDefined();
        controller.changedContent();

      });


      it('getTypesForAnnouncements should return successResponse ', function () {

        var announcementTypes = [];
        successResponse = {
          data: [{
            'announcementTypeName': 'test'
          }]
        };
        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();

        controller.getTypesForAnnouncements();
      });

      it('getTypesForAnnouncements should return failureresponse ', function () {

        var announcementTypes = [];
        successResponse = {
          data: {}
        };
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();

        controller.getTypesForAnnouncements();
      });

      it('getRolesForAnnouncements should return successResponse ', function () {

        var announcementTypes = [];
        var data = {};
        successResponse = {
          data: {}
        };
        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();

        controller.getRolesForAnnouncements();
      });

      it('getRolesForAnnouncements should return failureresponse ', function () {

        var announcementTypes = [];
        var data = {};
        failureResponse = {
          data: {}
        };
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();

        controller.getRolesForAnnouncements();
      });

      it('it should open cancelAddEditAnnouncement', function () {

        controller.changedForm = true;
        var existingCount = $ngDialog.open.calls.count();

        expect(controller.cancelAddEditAnnouncement).toBeDefined();

        controller.cancelAddEditAnnouncement();
        expect($ngDialog.open).toHaveBeenCalled();
        expect($ngDialog.open.calls.count()).toBe(existingCount + 1);
        var args = $ngDialog.open.calls.argsFor(existingCount);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('cancelAnnouncementPopupController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.item();
        $ngDialog.getOpenDialogs.and.returnValue($ngDialog);

        controller.changedForm = false;
        controller.cancelAddEditAnnouncement();
      });

      it('it should saveAnnouncementDraftAndClose ', function () {
        expect(controller.saveAnnouncementDraftAndClose).toBeDefined();
        controller.saveAnnouncementDraftAndClose();

      });


      it('it should saveAnnouncementDraftAndOpenNew  ', function () {
        expect(controller.saveAnnouncementDraftAndOpenNew).toBeDefined();
        controller.saveAnnouncementDraftAndOpenNew();

      });

      it('it should saveAnnouncementDraft ', function () {
        expect(controller.saveAnnouncementDraft).toBeDefined();
        controller.saveAnnouncementDraft();

      });

      it('it should saveAnnouncementDraftAndContinue  ', function () {
        expect(controller.saveAnnouncementDraftAndContinue).toBeDefined();
        controller.saveAnnouncementDraftAndContinue();

      });

      it('it should saveAnnoucementPostCall  ', function () {
        var confirmFlag = true;
        var announcement = {
          selectedRoles: [{
            id: "test"
          }],
          selectedRoleNames: "cj"
        }
        var announcementRoles = [{
          id: "test",
          label: "roles"

        }]
        // announcement.selectedRoles.length = 1;
        expect(controller.saveAnnoucementPostCall).toBeDefined();
        var existingCount = $ngDialog.open.calls.count();
        controller.saveAnnoucementPostCall(confirmFlag);

        expect($ngDialog.open).toHaveBeenCalled();
        expect($ngDialog.open.calls.count()).toBe(existingCount + 1);
        var args = $ngDialog.open.calls.argsFor(existingCount);
        expect(args).not.toBe(null);
        expect(args.length).toBe(1);

        expect(args[0].controller).toBe('cancelAnnouncementPopupController');
        expect(typeof args[0].resolve).toBe('object');
        args[0].resolve.item();
        // expect($rootScope.publishAnnouncementInfo).toBe("test");
      });

      it('it should confirmArchive  else', function () {
        var choice = false;
        expect(controller.confirmArchive).toBeDefined();
        $ngDialog.getOpenDialogs.and.returnValue($ngDialog);
        controller.confirmArchive(choice);

      });

      // it('it should confirmArchive if', function () {
      //   var choice = true;
      //   expect(controller['confirmArchive']).toBeDefined();
      //   controller.confirmArchive(choice);
      // });

      it('it should deleteAnnouncement   ', function () {
        successResponse = {
          data: {
            "message": "Announcement with ID 1137 has been deleted"
          }
        };
        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();

        expect(controller.deleteAnnouncement).toBeDefined();
        controller.deleteAnnouncement();
        $ngDialog.getOpenDialogs.and.returnValue($ngDialog);


      });

      it('it should deleteAnnouncement failureResponse ', function () {

        failureResponse = {
          "message": "No announcement with id 10000 found to delete."
        }
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();

        expect(controller.deleteAnnouncement).toBeDefined();
        controller.deleteAnnouncement();
        $ngDialog.getOpenDialogs.and.returnValue($ngDialog);


      });

      it('it should confirmDelete else', function () {
        var choice = false;
        var ngDialogArray = [$ngDialog, $ngDialog];

        expect($ngDialog.close).toBeDefined();
        expect(controller['confirmDelete']).toBeDefined();
        $ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        controller.confirmDelete(choice);
        expect($ngDialog.close).toHaveBeenCalledWith($ngDialog);

        expect($ngDialog.close).toBeDefined();
        expect(controller['confirmDelete']).toBeDefined();
        $ngDialog.getOpenDialogs.and.returnValue($ngDialog);
        controller.confirmDelete();
        expect($ngDialog.close).toHaveBeenCalledWith();

      });

      it('it should confirmDelete if', function () {
        var choice = true;
        expect(controller['confirmDelete']).toBeDefined();
        controller.confirmDelete(choice);
      });

      it('it should publishAnnouncement  ', function () {
        expect(controller.publishAnnouncement).toBeDefined();
        controller.publishAnnouncement();

      });

      it('it should saveAnnouncement   ', function () {
        expect(controller.saveAnnouncement).toBeDefined();
        controller.saveAnnouncement();

      });

      it('it should checkLengthTitle    ', function () {
        var announcement = {
          announcementTitleText: ""
        }
        controller.announcement.announcementTitleText = "";
        expect(controller.checkLengthTitle).toBeDefined();
        controller.checkLengthTitle();

        controller.announcement.announcementTitleText = "test";
        controller.checkLengthTitle();

      });

      it('it should checkLengthContent     ', function () {
        var announcement = {
          announcementText: ""
        }
        controller.announcement.announcementText = "";
        expect(controller.checkLengthContent).toBeDefined();
        controller.checkLengthContent();

        // controller.announcement.announcementText.length = 5000;
        // controller.checkLengthContent();

        controller.announcement.announcementText = "test";
        controller.checkLengthContent();

      });

      it('it should checkLengthContent     ', function () {

        controller.announcement.announcementText = "Functions double as object constructors, along with their typical role. Prefixing a function call with new will create an instance of a prototype, inheriting properties and methods from the constructor (including properties from the Object prototype).[38] ECMAScript 5 offers the Object.create method, allowing explicit creation of an instance without automatically inheriting from the Object prototype (older environments can assign the prototype to null).Functions double as object constructors, along with their typical role. Prefixing a function call with new will create an instance of a prototype, inheriting properties and methods from the constructor (including properties from the Object prototype).[38] ECMAScript 5 offers the Object.create method, allowing explicit creation of an instance without automatically inheriting from the Object prototype (older environments can assign the prototype to null).Functions double as object constructors, along with their typical role. Prefixing a function call with new will create an instance of a prototype, inheriting properties and methods from the constructor (including properties from the Object prototype).[38] ECMAScript 5 offers the Object.create method, allowing explicit creation of an instance without automatically inheriting from the Object prototype (older environments can assign the prototype to null).Functions double as object constructors, along with their typical role. Prefixing a function call with new will create an instance of a prototype, inheriting properties and methods from the constructor (including properties from the Object prototype).[38] ECMAScript 5 offers the Object.create method, allowing explicit creation of an instance without automatically inheriting from the Object prototype (older environments can assign the prototype to null).Functions double as object constructors, along with their typical role. Prefixing a function call with new will create an instance of a prototype, inheriting properties and methods from the constructor (including properties from the Object prototype).[38] ECMAScript 5 offers the Object.create method, allowing explicit creation of an instance without automatically inheriting from the Object prototype (older environments can assign the prototype to null).Functions double as object constructors, along with their typical role. Prefixing a function call with new will create an instance of a prototype, inheriting properties and methods from the constructor (including properties from the Object prototype).[38] ECMAScript 5 offers the Object.create method, allowing explicit creation of an instance without automatically inheriting from the Object prototype (older environments can assign the prototype to null).Functions double as object constructors, along with their typical role. Prefixing a function call with new will create an instance of a prototype, inheriting properties and methods from the constructor (including properties from the Object prototype).[38] ECMAScript 5 offers the Object.create method, allowing explicit creation of an instance without automatically inheriting from the Object prototype (older environments can assign the prototype to null).Functions double as object constructors, along with their typical role. Prefixing a function call with new will create an instance of a prototype, inheriting properties and methods from the constructor (including properties from the Object prototype).[38] ECMAScript 5 offers the Object.create method, allowing explicit creation of an instance without automatically inheriting from the Object prototype (older environments can assign the prototype to null).Functions double as object constructors, along with their typical role. Prefixing a function call with new will create an instance of a prototype, inheriting properties and methods from the constructor (including properties from the Object prototype).[38] ECMAScript 5 offers the Object.create method, allowing explicit creation of an instance without ";
        expect(controller.checkLengthContent).toBeDefined();
        controller.checkLengthContent();


      });

      it('it should checkLengthRoles      ', function () {
        var announcement = {
          selectedRoles: ""
        }
        controller.announcement.selectedRoles = "test";
        expect(controller.checkLengthRoles).toBeDefined();
        controller.checkLengthRoles();


        controller.announcement.selectedRoles = "";
        controller.checkLengthRoles();

      });

      it('it should checkLengthType     ', function () {
        var announcement = {
          selectedType: ""
        }
        controller.announcement.selectedType = "test";
        expect(controller.checkLengthType).toBeDefined();
        controller.checkLengthType();

        controller.announcement.selectedType = "";
        controller.checkLengthType();

      });

      it('it should datePickerChangedCheckStartedDate  ', function () {
        var date = new Date("Wed May 04 2016 00:00:00 GMT+0530 (India Standard Time)");
        var compareDate = true;
        var announcement = {
          lifeCycle: {
            beginEffectiveDate: "Wed May 10 2018 00:00:00 GMT+0530 (India Standard Time)"
          }
        };
        expect(controller.datePickerChangedCheckStartedDate).toBeDefined();
        controller.datePickerChangedCheckStartedDate(compareDate);

      });

      it('it should datePickerChangedCheckEndDate ', function () {
        var compareDate = true;
        expect(controller.datePickerChangedCheckEndDate).toBeDefined();
        controller.datePickerChangedCheckEndDate(compareDate);

      });

      it('it should checkStartDate      ', function () {
        var compareDate = true;
        controller.announcement = {
          announcementStatusCategory: "PREVIEW",
          statusToSave: "PREVIEW",
          toClose: true,
          lifeCycle: {
            endEffectiveDate: 2018,
            beginEffectiveDate: 2017,
            audienceStr: "test"
          },
          selectedRoles: [{

          }]
        }
        // announcement.lifeCycle.beginEffectiveDate = true;
        expect(controller.checkStartDate).toBeDefined();
        controller.checkStartDate(compareDate);


        var compareDate = false;
        controller.checkStartDate(compareDate);

      });

      it('it should checkEndDate     ', function () {
        var compareDate = true;
        var announcement = {
          lifeCycle: {
            endEffectiveDate: true
          }
        }
        announcement.lifeCycle = {
          endEffectiveDate: true
        };
        expect(controller.checkEndDate).toBeDefined();
        controller.checkEndDate(compareDate);


        var compareDate = false;
        controller.checkEndDate(compareDate);

      });


    });


  });
})();
