(function () {
  'use strict';
  /**
   * This controller is the Announcement Admin Controller.  It communications with the Annouments Modal dialog.
   */
  angular
    .module('ptabe2e')
    .controller('AnnouncementAdminController', function (ngDialog, uiGridConstants, CONSTANTS, HttpFactory, $scope, $timeout, CommonHelperService) {
      var vm = this;
      vm.announcement = {};
      vm.content = true;
      vm.constants = {};
      vm.constants.published = CONSTANTS.ANNOUNCEMENTS.STATUS_PUBLISHED;
      vm.constants.draft = CONSTANTS.ANNOUNCEMENTS.STATUS_DRAFT;
      vm.constants.archived = CONSTANTS.ANNOUNCEMENTS.STATUS_ARCHIVED;
      var scope = angular.element(document.getElementById('global-header')).scope();

      if (scope) {
        vm.userInfo = {
          appUserInfo: scope.vm.userInfo.appUserInfo ? scope.vm.userInfo.appUserInfo : null,
          userId: scope.vm.userInfo.appUserInfo[0].loginId ? scope.vm.userInfo.appUserInfo[0].loginId : window.sessionStorage.getItem('workerNumber'),
          displayName: scope.vm.userInfo.appUserInfo[0].fullName ? scope.vm.userInfo.appUserInfo[0].fullName : null,
          assigneeNumber: scope.vm.userInfo.appUserInfo[0].userIdentiifier ? scope.vm.userInfo.appUserInfo[0].userIdentiifier : null
        };
      }
      vm.cancelAnnouncementAdminModal = function () {
        ngDialog.closeAll();
      };

      /*administration modal tabs */
      /* istanbul ignore next  */
      vm.getAdminTabs = function () {

        HttpFactory.getActions(CONSTANTS.URL.ADMINTABS)
          .then(function (successResponse) {
            vm.adminTabs = successResponse.data;

          }, function () {
            //intentional
          });
      };

      vm.toggleFiltering = function () {
        vm.gridOptions.enableFiltering = !vm.gridOptions.enableFiltering;
        vm.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
      };

      var rowtpl = '<div ng-class="{ \'grid-highlight-active\':row.entity.announcementStatusCategory ===\'' +
        vm.constants.published +
        '\' && row.entity.publishIndicator===\'Y\'  }">' +
        '<div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name"' +
        'class="ui-grid-cell" ng-class="{ \'ui-grid-row-header-cell\': col.isRowHeader }" ui-grid-cell></div></div>';

      vm.gridOptions = {
        enableCellEdit: false,
        paginationPageSizes: [10, 20, 30, 50],
        paginationPageSize: 20,
        enableFiltering: true,
        enableHorizontalScrollbar: 0,
        enableVerticalScrollbar: 0,
        rowTemplate: rowtpl,
        columnDefs: [{
            name: 'Status',
            field: 'announcementStatusCategory',
            headerTooltip: 'Status',
            width: 75,
            filter: {
              term: '',
              type: uiGridConstants.filter.SELECT,
              width: '*',
              selectOptions: [{
                value: '',
                label: 'All'
              }, {
                value: CONSTANTS.ANNOUNCEMENTS.STATUS_PUBLISHED,
                label: 'Published'
              }, {
                value: CONSTANTS.ANNOUNCEMENTS.STATUS_DRAFT,
                label: 'Drafts'
              }, {
                value: CONSTANTS.ANNOUNCEMENTS.STATUS_ARCHIVED,
                label: 'Archived'
              }],
              ariaLabel: 'Filter for column'
            }
          },

          /* pre-populated search field*/
          {
            name: 'Subject',
            headerTooltip: 'Subject',
            field: 'announcementTitleText',
            width: '140'
          },
          /* no filter input*/
          {
            name: 'Content',
            headerTooltip: 'Content',
            field: 'announcementText',
            width: '240',
            cellTemplate: '<div class="truncateTitle" ng-bind-html="row.entity.announcementText" style="padding-top:5px; padding-left:5px; " ></div>'

          },
          /* pre-populated search field*/
          {
            name: 'Start date',
            headerTooltip: 'Start date',
            width: 90,
            field: 'lifeCycle.beginEffectiveDate',
            sort: {
              direction: uiGridConstants.ASC,
              priority: 0
            },
            enableFiltering: false,
            enableCellEdit: false,
            type: 'date',
            cellFilter: 'date:"MM/dd/yyyy"'
          },
          {
            name: 'End date',
            headerTooltip: 'End date',
            width: 90,
            field: 'lifeCycle.endEffectiveDate',
            type: 'date',
            cellFilter: 'date:"MM/dd/yyyy"',
            enableFiltering: false,
            enableCellEdit: false,
            sort: {
              direction: 'asc',
              priority: 0
            }
          },
          // no filter input
          {
            name: 'Last modified By',
            headerTooltip: 'Lat modified By',
            width: 75,
            field: 'audit.lastModifiedUserName'
          },
          // pre-populated search field
          {
            name: 'Created by',
            headerTooltip: 'Created by',
            width: 75,
            field: 'audit.createdUserName'
          },
          {
            name: 'Type',
            headerTooltip: 'Type',
            width: 100,
            field: 'announcementTypeData.announcementTypeNameText'
          },
          {
            name: 'Target audience',
            headerTooltip: 'Target audience',
            width: 100,
            field: 'audienceStr'

          },
          // no filter input
          {
            name: 'Actions',
            headerTooltip: 'Actions',
            enableFiltering: false,
            enableSorting: false,
            width: 90,
            enableColumnMenu: false,
            cellClass: 'action-drop-down-grid',
            cellTemplate: 'app/components/announcementAdmin/actionDropDown.html'
          }, {
            name: 'Active',
            headerTooltip: 'Active',
            enableFiltering: false,
            field: 'publishIndicator',
            visible: false
          }
        ],

        onRegisterApi: function (gridApi) {
          vm.gridApi = gridApi;
        }
      };
      /* istanbul ignore next  */
      function dataProcess(data) {
        data.forEach(function (row) {

          row.lifeCycle.beginEffectiveDate = row.lifeCycle.beginEffectiveDate ? (new Date(row.lifeCycle.beginEffectiveDate)) : null;
          row.lifeCycle.endEffectiveDate = row.lifeCycle.endEffectiveDate ? (new Date(row.lifeCycle.endEffectiveDate)) : null;

          var audienceStr = '';
          if (row.roleAnnouncements.length > 0) {
            angular.forEach(row.roleAnnouncements, function (role) {
              audienceStr += role.userRoleName + ',';
            });
          }
          if (audienceStr) {
            row.audienceStr = audienceStr.substring(0, audienceStr.length - 1);
          }
        });
        return data;
      }

      /* istanbul ignore next  */
      vm.getAllAnnouncements = function () {
        vm.searchAnnouncements = '';
        HttpFactory.getActions(CONSTANTS.URL.GET_ANNOUNCEMENTS)
          .then(function (successResponse) {
            var theData = dataProcess(successResponse.data);
            $scope.datasample = theData;
            vm.gridOptions.data = angular.copy(theData);

          }, function () {
            //intentional
          });
      };
      /* istanbul ignore next  */
      $scope.editAnnouncement = function (row, type) {


        HttpFactory.getActions(CONSTANTS.URL.GET_ANNOUNCEMENT_BY_ID + row.entity.announcementIdentifier)
          .then(function (successResponse) {
            var theData = dataProcess(successResponse.data);



            if (theData[0].announcementStatusCategory === row.entity.announcementStatusCategory) {
              vm.announcement = theData[0];
              vm.announcement.flag = type;
              vm.openAddNewAnnouncementModal("edit");
            } else {
              CommonHelperService.setToastr(CONSTANTS.TOASTER.annoucementAdminError, "error");
            }
          }, function () {
            //intentional
          });


      };

      vm.openAddNewAnnouncementModal = function (neworedit) {
        if (neworedit === "new") {
          vm.announcement = {};

          ngDialog.open({
            template: 'app/components/announcementAdmin/addNewAnnouncementModal.html',
            controller: 'AnnouncementManagementController',
            controllerAs: 'vm',
            width: '45%',
            showClose: false,
            resolve: {
              items: function () {
                return vm.announcement;
              }
            }
          }).closePromise.then(function () {
            vm.announcement.flag = null;
            $timeout(vm.getAllAnnouncements, 700);
          });
        } else {
          ngDialog.open({
            template: 'app/components/announcementAdmin/addNewAnnouncementModal.html',
            controller: 'AnnouncementManagementController',
            controllerAs: 'vm',
            width: '45%',
            showClose: false,
            resolve: {
              items: function () {
                return vm.announcement;
              }
            }
          }).closePromise.then(function () {
            vm.announcement.flag = null;
            $timeout(vm.getAllAnnouncements, 700);
          });
        }
      };

      vm.filterGrid = function (value) {
        vm.gridApi.grid.columns[0].filters[0].term = value;
      };

      /* istanbul ignore next  */
      vm.filterService = function () {
        var data = vm.searchAnnouncements;
        HttpFactory.postActions(CONSTANTS.URL.ANNOUNCEMENT_SEARCH, data)
          .then(function (successResponse) {
            vm.gridOptions.data = dataProcess(successResponse.data);
          }, function () {
            vm.gridOptions.data = [];
          });
      };


      vm.pressEnter = function (event) {
        if (event.keyCode === 13) {
          vm.filterService();
        }
      };

      $scope.viewAnnouncement = function (row, type) {
        vm.announcement = row.entity;
        vm.announcement.flag = type;

        $scope.selectedAnnouns = vm.announcement;

        ngDialog
          .open({
            template: "app/components/announcementAdmin/viewAnnouncement.html",
            scope: $scope,
            width: '50%',
            showClose: false,
            resolve: {}
          }).closePromise.then(function () {

            vm.announcement.flag = null;
          });


      };

      $scope.deleteAnnouncement = function (row, type) {

        vm.announcement = row.entity;
        vm.announcement.flag = type;
        ngDialog.open({
          template: 'app/components/announcementAdmin/deleteConfirmation.html',
          controller: 'AnnouncementManagementController',
          controllerAs: 'vm',
          width: '45%',
          showClose: false,
          resolve: {
            items: function () {
              return vm.announcement;
            }
          }
        }).closePromise.then(function () {
          vm.announcement.flag = null;
          $timeout(vm.getAllAnnouncements, 700);
        });
      };
      /* istanbul ignore next  */
      $scope.copyAnnouncement = function (row, type) {
        HttpFactory.getActions(CONSTANTS.URL.GET_ANNOUNCEMENT_BY_ID + row.entity.announcementIdentifier)
          .then(function (successResponse) {
            var theData = dataProcess(successResponse.data);



            if (theData[0].announcementStatusCategory === row.entity.announcementStatusCategory) {
              vm.announcement = theData[0];
            } else {
              CommonHelperService.setToastr(CONSTANTS.TOASTER.annoucementAdminError, "error");
            }
          }, function () {
            //intentional
          });
        vm.announcement.announcementIdentifier = null;
        vm.announcement.flag = type;
        vm.announcement.announcementStatusCategory = null;
        vm.announcement.lifeCycle.beginEffectiveDate = null;
        vm.announcement.lifeCycle.endEffectiveDate = null;
        vm.openAddNewAnnouncementModal();
      };

      $scope.announcementToArchieve = function (row, type) {
        vm.announcement = row.entity;
        vm.announcement.flag = type;
        ngDialog.open({
          template: 'app/components/announcementAdmin/archiveConfirmation.html',
          controller: 'AnnouncementManagementController',
          controllerAs: 'vm',
          width: '45%',
          showClose: false,
          resolve: {
            items: function () {
              return vm.announcement;
            }
          }
        }).closePromise.then(function () {
          vm.announcement.flag = null;
          $timeout(vm.getAllAnnouncements, 700);
        });
      };

      vm.closeAnnouncementDialog = function () {
        ngDialog.close();
      };
      vm.getAllAnnouncements();

      var fullNameTemplate = '<div><div id="{{row.treeNode.children[0].row.entity.judgeFullName}}" ng-if="!col.grouping || col.grouping.groupPriority === undefined || ' +
        'col.grouping.groupPriority === null || ( row.groupHeader && col.grouping.groupPriority === row.treeLevel )" class="ui-grid-cell-contents" ' +
        'title="TOOLTIP">{{COL_FIELD CUSTOM_FILTERS}}({{row.treeNode.children[0].row.entity.attorneyCount}})</div></div>';

      var attorneyNameTemplate = '<div><div ng-if="!col.grouping || col.grouping.groupPriority === undefined || col.grouping.groupPriority === null || ' +
        '( row.groupHeader && col.grouping.groupPriority === row.treeLevel )" class="ui-grid-cell-contents" title="TOOLTIP">{{COL_FIELD CUSTOM_FILTERS}}</div></div>';

      var actionsTemplate = '<button style="margin-left:18px;" for="{{row.treeNode.children[0].row.entity.judgeFullName}}" ng-click="grid.appScope.editJudge(row)" ' +
        'title="Edit judge {{row.treeNode.children[0].row.entity.judgeFullName}}"><i class="fa fa-edit"></i><span class="sr-only">Edit judge</span></button>';
      vm.gridOptionsJudgeRelationship = {
        enableFiltering: true,
        treeRowHeaderAlwaysVisible: false,
        showGridFooter: true,
        enableGridMenu: true,
        groupingShowAggregationMenu: false,
        groupingShowCounts: false,

        columnDefs: [{
            name: 'judgeFullName',
            enableHiding: false,
            groupingShowAggregationMenu: false,
            displayName: 'Judge',
            headerTooltip: 'Judge',
            grouping: {
              groupPriority: 0
            },
            sort: {
              priority: 0,
              direction: 'asc'
            },
            width: '38%',
            cellTemplate: fullNameTemplate
          },
          {
            name: 'attorneyFirstName',
            displayName: "Patent attorney/law clerk",
            headerTooltip: 'Patent attorney/law clerk',
            groupingShowAggregationMenu: false,
            enableHiding: false,
            cellTemplate: attorneyNameTemplate
          },
          {
            name: 'Actions',
            headerTooltip: 'Actions',
            enableHiding: false,
            enableFiltering: false,
            enableSorting: false,
            groupingShowAggregationMenu: false,
            width: '12%',
            enableColumnMenu: false,
            cellTemplate: actionsTemplate
          }
        ],
        onRegisterApi: function (gridApi) {
          vm.gridOptionsJudgeRelationship.gridApi = gridApi;
        }
      };


      $scope.editJudge = function (row) {
        if (row.entity.judgeEmpNo) {
          vm.openJudgeDialog(row.entity);
        } else {
          var values = Object.keys(row.entity).filter(function (x) {
            return row.entity[x].groupVal;
          }).map(function (x) {
            return row.entity[x].groupVal;
          });
          vm.openJudgeDialog(getjudgeEmpNo(values[0]));
        }
      };

      function getjudgeEmpNo(judgeFullName) {
        var judgeEmpNo;
        angular.forEach(vm.gridOptionsJudgeRelationship.data, function (row) {
          if (row.judgeFullName === judgeFullName) {
            judgeEmpNo = row;
          }
        });
        return judgeEmpNo;
      }

      vm.getJudgeRelatedData = function () {
        HttpFactory.getActions(CONSTANTS.URL.JUDGERELATIONSHIP)
          .then(function (successResponse) {
            buildGridData(successResponse.data);
          }, function () {
            // intentional
          });
      };

      vm.showGrid1 = true;
      /* istanbul ignore next  */
      function buildGridData(judges) {
        var newData = [];
        angular.forEach(judges, function (aJudge) {
          if (aJudge.attorneys.length === 0) {
            newData.push(getJudgeOnlyRowData(aJudge.judge));
          } else {
            vm.lengthOfAttorneys = aJudge.attorneys.length;
            angular.forEach(aJudge.attorneys, function (aAttorney) {
              newData.push(getJudgeRowData(aJudge.judge, aAttorney));
            });
          }
        });
        vm.gridOptionsJudgeRelationship.data = newData;
        $timeout(function () {
          vm.gridOptionsJudgeRelationship.gridApi.core.refresh();
        }, 4000);
      }

      function getJudgeRowData(judge, attorney) {
        return {
          judgeFullName: judge.fullName,
          judgeEmpNo: judge.userIdentiifier,
          judgeWorkerNumber: judge.userWorkerNumber,
          attorneyFirstName: attorney.fullName,
          attorneyEmpNo: attorney.userIdentiifier,
          attorneyCount: vm.lengthOfAttorneys
        };
      }

      function getJudgeOnlyRowData(judge) {
        return {
          judgeFullName: judge.fullName,
          judgeEmpNo: judge.userIdentiifier,
          judgeWorkerNumber: judge.userWorkerNumber,
          attorneyCount: 0
        };
      }
      vm.openJudgeDialog = function (row) {
        vm.judgeName = row.judgeFullName;
        vm.judgeEmpNo = row.judgeEmpNo;
        vm.judgeWorkerNumber = row.judgeWorkerNumber;
        ngDialog.open({
          template: "app/components/announcementAdmin/judgeRelationship.html",
          scope: $scope,
          width: '60%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            judgeId: function () {
              return row;
            }
          }
        }).closePromise.then(function () {
          // intentional
        });
      };

      /* istanbul ignore next  */
      vm.getAttorneys = function () {
        HttpFactory.getActions(CONSTANTS.URL.ATTRONEYLIST + vm.judgeEmpNo)
          .then(function (successResponse) {
            $scope.judgeList = successResponse.data.nonAssignedAttorneyList;
            $scope.destjudgeList = successResponse.data.assignedAttorneyList;
            $scope.oldList = angular.copy($scope.destjudgeList);
            $scope.originalList = angular.copy($scope.judgeList);
          }, function () {
            // intentional
          });
      };

      vm.getJudgeRelatedData();
      /* istanbul ignore next  */
      $scope.dataSelected = function (a) {
        $scope.tempItem = $scope.judgeList[a];
        $scope.items = a;
      };
      /* istanbul ignore next  */
      $scope.moveJudgeToPanel = function () {
        $scope.tempArray = [];
        angular.forEach($scope.items, function (itemTodelete) {
          $scope.itemToMove = $scope.judgeList[itemTodelete];
          $scope.tempArray.push($scope.itemToMove);
          if (!$scope.destjudgeList.includes($scope.itemToMove) && $scope.itemToMove !== "" && $scope.itemToMove !== undefined) {
            var obj = $scope.judgeList[itemTodelete];
            var i = 0;
            angular.forEach($scope.originalList, function (each) {
              i++;
              if (each.assigneeNumberText === obj.assigneeNumberText) {
                $scope.indeForOrignal = i;
              }
            });
            $scope.destjudgeList.push($scope.itemToMove);
          }
        });
        angular.forEach($scope.tempArray, function (itemTodelete) {
          var i = 0;
          angular.forEach($scope.originalList, function (each) {
            i++;
            if (each.assigneeNumberText === itemTodelete.assigneeNumberText) {
              $scope.indeForOrignal = i;
            }
          });
          var j = 0;
          angular.forEach($scope.judgeList, function (each) {
            j++;
            if (each.assigneeNumberText === itemTodelete.assigneeNumberText) {
              $scope.indexForjudge = j;
            }
          });
          $scope.originalList.splice($scope.indeForOrignal - 1, 1);
          $scope.judgeList.splice($scope.indexForjudge - 1, 1);
        });
        $scope.itemToMove = "";
        $scope.items = "";
      };

      /* istanbul ignore next  */
      $scope.removeJudgeFromPanel = function (a, judge) {
        $scope.destjudgeList.splice(a, 1);
        if (!$scope.judgeList.includes(judge)) {
          $scope.judgeList.push(judge);
          $scope.originalList.push(judge);
        }
        if (!$scope.originalList.includes(judge)) {
          $scope.originalList.push(judge);
        }
      };
      /* istanbul ignore next  */
      $scope.criteriaMatch = function (input) {
        $scope.searchText = input;
        $scope.itemToMove = "";
        var tempList = [];
        if (angular.isDefined(input) && input.trim() !== "") {
          angular.forEach($scope.judgeList, function (currentJudge) {
            if (currentJudge.assigneeFullNameText.toLowerCase().includes(input.toLowerCase())) {
              tempList.push(currentJudge);
            }
          });
          $scope.judgeList = angular.copy(tempList);
        } else {
          tempList = angular.copy($scope.originalList);
          for (var i = 0; i < $scope.destjudgeList.length; i++) {
            for (var j = 0; j < tempList.length; j++) {
              if (tempList[j].assigneeNumberText === $scope.destjudgeList[i].assigneeNumberText) {
                tempList.splice(j, 1);
              }
            }
          }
          $scope.judgeList = tempList;
        }
      };
      /* istanbul ignore next  */
      $scope.associateAttorney = function () {
        var newAssignedList = [];
        var oldAssignedList = [];
        angular.forEach($scope.destjudgeList, function (aJudge) {
          var newAttorneyObj = {
            "assigneeNumberText": aJudge.workerNumber,
            "assigneeFullNameText": aJudge.assigneeFullNameText
          };
          newAssignedList.push(newAttorneyObj);
        });
        angular.forEach($scope.oldList, function (aJudge) {
          var obj = {
            "assigneeNumberText": aJudge.workerNumber,
            "assigneeFullNameText": aJudge.assigneeFullNameText
          };
          oldAssignedList.push(obj);
        });

        var dataObject = {
          "judgeId": vm.judgeWorkerNumber,
          "lastModifiedUserId": vm.userInfo.userId,
          "lastModifiedTimeStamp": new Date().getTime(),
          "assignedAttorneyList": oldAssignedList,
          "nonAssignedAttorneyList": newAssignedList
        };
        HttpFactory.postActions(CONSTANTS.URL.ASSOCIATEJUDGE, dataObject)
          .then(function () {
            $scope.abandonChanges();
            CommonHelperService.setToastr(CONSTANTS.TOASTER.annoucementAdminPa, "success");
            vm.getJudgeRelatedData();
          }, function (failureResponse) {
            CommonHelperService.setToastr(failureResponse.data.message, "error");
          });
      };
      /* istanbul ignore next  */
      $scope.removeAllAttorneys = function () {
        angular.forEach($scope.destjudgeList, function (aJudge) {
          $scope.originalList.push(aJudge);
          $scope.judgeList.push(aJudge);
        });
        $scope.destjudgeList = [];
      };
      $scope.removeJudgeFromPanel;

      var ieDefs = [{
          name: 'rankId',
          displayName: 'Rank',
          headerTooltip: 'Rank',
          field: 'rankId',
          width: 100,
          type: 'number',
          sort: {
            direction: 'asc',
            priority: 0
          }

        },
        {
          name: 'assigneeFullNameText',
          displayName: 'Judge',
          headerTooltip: 'Judge',
          field: 'assigneeFullNameText'
        },
        {
          name: 'workerNumber',
          displayName: 'Actions',
          headerTooltip: 'Actions',
          width: 150,
          enableFiltering: false,
          enableColumnMenu: false,
          enableSorting: false,
          cellTemplate: '<button title="Change rank for {{row.entity.assigneeFullNameText}}"' +
            'class="btn btn-default" style="cursor: pointer; margin-left: 13px; padding-top:5px; width: 83%" index="{{index}}"ng-click="grid.appScope.changeRank(row)">' +
            "Change rank" +
            '</button>'
        }
      ];

      vm.gridOptionsJudgeRank = {
        enableColumnResizing: true,
        enableHorizontalScrollbar: 2,
        enableGridMenu: true,
        rowHeight: 35,
        exporterCsvFilename: 'StatusInteractionHistory.csv',
        exporterOlderExcelCompatibility: true,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        columnDefs: ieDefs,
        enableFiltering: true,
        enableSorting: true,
        onRegisterApi: function (gridApi) {
          vm.gridOptionsJudgeRank.gridApi = gridApi;
        }
      };
      /* istanbul ignore next  */
      vm.getJudgeRanks = function () {

        HttpFactory.getActions(CONSTANTS.URL.JUDGERANKS)
          .then(function (successResponse) {
            vm.gridOptionsJudgeRank.data = successResponse.data;
          }, function () {
            //intentional
          });
      };

      /* istanbul ignore next  */
      $scope.changeRank = function (row) {
        $scope.judgeName = row.entity.assigneeFullNameText;
        $scope.judgeRank = row.entity.rankId;
        $scope.workerNumber = row.entity.workerNumber;
        ngDialog.open({
          template: "app/components/announcementAdmin/updateJudgeRank.html",
          scope: $scope,
          width: '25%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            judgeId: function () {
              return row;
            }
          }
        }).closePromise.then(function () {
          // intentional
        });
      };

      /*update rank*/
      $scope.errorRank = false;
      /* istanbul ignore next  */
      $scope.update = function (workerNumber, judgeRank) {
        if (!$scope.errorRank) {
          var i = 0;
          vm.gridOptionsJudgeRank.data.forEach(function (row) {
            if (row.workerNumber === workerNumber) {
              vm.oldRank = row.rankId;
            }
          });
          vm.gridOptionsJudgeRank.data.forEach(function (row) {
            i++;
            if (row.workerNumber === workerNumber) {
              vm.gridOptionsJudgeRank.data.splice(i - 1, 1);
              row.rankId = judgeRank;
              vm.gridOptionsJudgeRank.data.splice(judgeRank - 1, 0, row);
              vm.gridOptionsJudgeRank.gridApi.core.refresh();

            }
            if (judgeRank > vm.oldRank) {
              $scope.increaseRank(judgeRank, i);
            } else if (judgeRank < vm.oldRank) {
              $scope.decreaseRank(judgeRank, i);
            }
          });
        }
        $scope.abandonChanges();
      };

      /* istanbul ignore next  */
      $scope.checkError = function (judgeRank) {
        if (judgeRank > vm.gridOptionsJudgeRank.data.length) {
          $scope.errorRank = true;
          return;
        } else {
          $scope.errorRank = false;
        }
      };
      /* istanbul ignore next  */
      $scope.increaseRank = function (judgeRank, i) {
        vm.gridOptionsJudgeRank.data.forEach(function (row, index) {
          vm.gridOptionsJudgeRank.data[i - 1].rankId = i;
        });
      };
      /* istanbul ignore next  */
      $scope.decreaseRank = function (judgeRank, i) {

        vm.gridOptionsJudgeRank.data.forEach(function (row, index) {
          if (i < vm.oldRank) {
            vm.gridOptionsJudgeRank.data[i - 1].rankId = i + 1;
            if ((i - 1 === 0) && judgeRank !== 1) {
              vm.gridOptionsJudgeRank.data[i - 1].rankId = i;
            } else if (i < judgeRank && i !== 1) {
              vm.gridOptionsJudgeRank.data[i - 1].rankId = i;
            }
          } else if (i > vm.oldRank && i < vm.gridOptionsJudgeRank.data.length) {
            vm.gridOptionsJudgeRank.data[i].rankId = i + 1;
          }
        });
      };
      /* istanbul ignore next  */
      $scope.saveRanks = function () {
        HttpFactory.putActions(CONSTANTS.URL.JUDGERANKS, vm.gridOptionsJudgeRank.data)
          .then(function () {
            //intentional
          }, function () {
            // intentional
          });

      };

      $scope.closeDialog = function () {
        ngDialog.close();
      };
      /* istanbul ignore next */
      $scope.abandonChanges = function () {
        ngDialog.close(lastDialog(), true);
        $scope.setClose = true;
      };
      /* istanbul ignore next */
      function lastDialog() {
        var openDialogs = ngDialog.getOpenDialogs();
        return openDialogs[openDialogs.length - 1];
      }

      vm.gridOptionsUserManagement = {
        enableColumnResizing: true,
        enableHorizontalScrollbar: 2,
        enableGridMenu: true,
        rowHeight: 35,
        exporterCsvFilename: 'StatusInteractionHistory.csv',
        exporterOlderExcelCompatibility: true,
        exporterMenuExcel: false,
        exporterMenuPdf: false,

        enableFiltering: true,
        enableSorting: true,
        onRegisterApi: function (gridApi) {
          vm.gridOptionsUserManagement.gridApi = gridApi;
        }
      };
      /* istanbul ignore next  */
      vm.getUserManagementData = function (url) {
        HttpFactory.getActions(CONSTANTS.URL.USERMANAGEMENT + url)
          .then(function (successResponse) {
            vm.gridOptionsUserManagement.columnDefs = successResponse.data.columnDetails;
            vm.gridOptionsUserManagement.data = successResponse.data.caseDetailsData;
          }, function () {
            vm.gridOptionsUserManagement.data = [];
            CommonHelperService.setToastr(CONSTANTS.TOASTER.noRecords, "error");

          });
      };
      /* istanbul ignore next  */
      $scope.openUserInfo = function (row) {

        vm.getDetailedData = function () {
          HttpFactory.getActions(CONSTANTS.URL.USERDETAILEDDATA + row.entity.userWorkerNumber).then(
            function (successResponse) {
              vm.userInfoDetails = successResponse.data;
            }
          );
        };
        vm.getDetailedData();
        ngDialog.open({
          template: "app/components/announcementAdmin/adminUserInfo.html",
          scope: $scope,
          width: '30%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            judgeId: function () {
              return row;
            }
          }
        }).closePromise.then(function () {
          // intentional
        });
      };
      $scope.pressEnter = function (event, searchText) {
        if (event.keyCode === 13) {
          vm.searchUserInfo();
        }
      };
      vm.getUserData = true;
      /* istanbul ignore next  */
      vm.searchUserInfo = function () {
        if (vm.lastName === " " || vm.lastName === undefined) {
          vm.getUserData = false;
          vm.errorMessageForLastName = "Last name cannot be empty";
        } else {
          vm.getUserData = true;
        }
        if (vm.getUserData) {
          var url = "?lastName=" + vm.lastName;
          if (vm.firstName !== "" && vm.firstName !== undefined) {
            url = url + "&firstName=" + vm.firstName;
          }
          vm.getUserManagementData(url);
        }
      };
    });
})();
