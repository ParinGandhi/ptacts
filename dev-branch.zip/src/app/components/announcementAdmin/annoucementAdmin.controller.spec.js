// (function () {
//   'use strict';

//   describe('AnnouncementAdminController', function () {

//     beforeEach(module('ptabe2e'));

//     var vm = this;
//     var scope;
//     var controller, $controller;
//     var $rootScope, timeout;
//     var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'close', 'closeAll']);
//     var $q, HttpFactoryDeferred, spy;
//     var row, type;
//     // var announcement;

//     var successResponse = {
//       data: {
//         events: {},
//         refreshInterval: 0
//       }
//     };

//     var failureResponse = {};

//     var fakeElement = function (params) {
//       return {
//         scope: function () {
//           return {
//             vm: {
//               getWidgetZone: function () {

//               },
//               setWidgetContentHeight: function () {

//               }
//             }
//           }
//         }
//       }
//     };

//     beforeEach(inject(function (_$controller_, _$rootScope_, _$timeout_, _$q_, HttpFactory) {
//       $q = _$q_;
//       timeout = _$timeout_;
//       scope = _$rootScope_.$new();
//       $rootScope = _$rootScope_;
//       $controller = _$controller_;
//       ngDialog.open.and.returnValue({
//         closePromise: {
//           then: function (callback) {
//             callback({
//               value: 1
//             });
//           }
//         }
//       });

//       // setup the promise
//       HttpFactoryDeferred = _$q_.defer();
//       spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
//       spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);
//       spy = spyOn(angular, 'element').and.callFake(fakeElement);
//       // spyOn(HttpFactory, 'postActions', {
//       //   'text': 'test'
//       // }).and.returnValue(HttpFactoryDeferred.promise);
//       controller = $controller('AnnouncementAdminController', {
//         $scope: scope,
//         ngDialog: ngDialog,
//         $rootScope: _$rootScope_,
//         HttpFactory: HttpFactory

//       });

//     }));

//     describe('check functions', function () {

//       // it('it should call focus', function () {

//       //   var dummyElement = document.createElement('div');
//       //   document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(dummyElement);
//       //   spyOn(document.getElementById("dialogClose"), 'blur');
//       //   expect(document.getElementById("dialogClose").blur).toBeDefined();
//       //   expect(controller['focus']).toBeDefined();
//       //   controller.focus();
//       //   timeout.flush();
//       //   expect(dummyElement.blur).toHaveBeenCalled();

//       // });

//       // it('Should invoke focus', function () {

//       //   spyOn(controller, 'focus');
//       //   expect(controller['focus']).toBeDefined();

//       // });

//       it('it should call getAdminTabs ', function () {
//         successResponse = {
//           data: [{
//             lifeCycle:{
//               beginEffectiveDate: "2018",
//               endEffectiveDate: "2019"
//             },
//             roleAnnouncements: []
//           }]

//         };

//         // HttpFactoryDeferred.resolve(successResponse);
//         // $rootScope.$apply();

//         // expect(controller.getAdminTabs).toBeDefined();
//         // controller.getAdminTabs();


//       });

//       it('it should call getAdminTabs ', function () {
//         failureResponse = {
//           data: {
//           }

//         };

//         expect(controller.getAdminTabs).toBeDefined();
//         controller.getAdminTabs();
//         HttpFactoryDeferred.reject(failureResponse);
//         $rootScope.$apply();

//       });

//       it('it should call gridOptionsJudgeRank', function () {

//         var gridApi = {
//           core: {
//             on: {
//               filterChanged: function ($scope, callback) {}
//             }
//           }
//         };
//         expect(controller.gridOptionsJudgeRank).toBeDefined();
//         expect(controller.gridOptionsJudgeRank.onRegisterApi).toBeDefined();
//         controller.gridOptionsJudgeRank.onRegisterApi(gridApi);
//         // expect(scope.gridApi).toBe(gridApi);
//         // scope.gridApi.core.on.filterChanged();

//       });

//       it('it should call gridOptionsUserManagement', function () {

//         var gridApi = {
//           core: {
//             on: {
//               filterChanged: function ($scope, callback) {}
//             }
//           }
//         };
//         expect(controller.gridOptionsUserManagement).toBeDefined();
//         expect(controller.gridOptionsUserManagement.onRegisterApi).toBeDefined();
//         controller.gridOptionsUserManagement.onRegisterApi(gridApi);
//         // expect(scope.gridApi).toBe(gridApi);
//         // scope.gridApi.core.on.filterChanged();

//       });

//       it('it should call closeDialog', function () {
//         expect(ngDialog.close).toBeDefined();
//         expect(scope.closeDialog).toBeDefined();
//         scope.closeDialog();
//         expect(ngDialog.close).toHaveBeenCalled();
//       });

//       it('it should call cancelAnnouncementAdminModal', function () {
//         expect(ngDialog.closeAll).toBeDefined();
//         expect(controller.cancelAnnouncementAdminModal).toBeDefined();
//         controller.cancelAnnouncementAdminModal();
//         expect(ngDialog.closeAll).toHaveBeenCalled();
//       });

//       it('it should call gridOPtions', function () {
//         var gridApi = {};
//         expect(controller.gridOptions).toBeDefined();
//         expect(controller.gridOptions.onRegisterApi).toBeDefined();
//         controller.gridOptions.onRegisterApi(gridApi);
//         expect(controller.gridApi).toBe(gridApi);

//       });

//       it('it should toggle filtering ', function () {

//         controller.gridOptions.enableFiltering = true;
//         controller.gridApi = {
//           core: {

//             notifyDataChange: function (arg0, arg1) {

//             }
//           }
//         };
//         expect(controller.toggleFiltering).toBeDefined();
//         controller.toggleFiltering();
//       });


//       it('getAllAnnouncements  should return successResponse ', function () {

//         successResponse = {
//           data: [{
//             lifeCycle: {
//               endEffectiveDate: true,
//               beginEffectiveDate: true,
//               audienceStr: "test"
//             },
//             roleAnnouncements: [{
//               userRoleName: "testing"
//             }]
//           }]
//         };
//         // HttpFactoryDeferred.resolve(successResponse);
//         // $rootScope.$apply();

//         controller.getAllAnnouncements();
//       });

//       it('getAllAnnouncements  should return successResponse to check null in data process', function () {

//         successResponse = {
//           data: [{
//             lifeCycle: {
//               endEffectiveDate: false,
//               beginEffectiveDate: false,
//               audienceStr: "test"
//             },
//             roleAnnouncements: [{
//               userRoleName: "testing"
//             }]
//           }]
//         };
//         // HttpFactoryDeferred.resolve(successResponse);
//         // $rootScope.$apply();

//         controller.getAllAnnouncements();
//       });

//       it('filterService  should return successresponse', function () {

//         successResponse = {
//           data: [

//           ]

//         }
//         expect(controller.filterService).toBeDefined();
//         controller.filterService();
//       });

//       // it('getAllAnnouncements  should return successResponse to check else blocks', function () {

//       //   successResponse = {
//       //     data: [{
//       //       lifeCycle: {
//       //         endEffectiveDate: false,
//       //         beginEffectiveDate: false,
//       //         audienceStr: false
//       //       },
//       //       roleAnnouncements: []
//       //     }]
//       //   };
//       //   HttpFactoryDeferred.resolve(successResponse);
//       //   $rootScope.$apply();

//       //   controller.getAllAnnouncements();
//       // });


//       it('getAllAnnouncements  should return failureResponse ', function () {

//         failureResponse = {};
//         HttpFactoryDeferred.reject(failureResponse);
//         $rootScope.$apply();

//         controller.getAllAnnouncements();
//       });

//       it('filterService  should return failureResponse ', function () {

//         failureResponse = {

//         };

//         HttpFactoryDeferred.reject(failureResponse);
//         $rootScope.$apply();

//         controller.filterService();
//       });

//       it('it should open add new announcement modal', function () {
//         var existingCount = ngDialog.open.calls.count();
//         expect(controller.openAddNewAnnouncementModal).toBeDefined();

//         controller.openAddNewAnnouncementModal();
//         expect(ngDialog.open).toHaveBeenCalled();
//         expect(ngDialog.open.calls.count()).toBe(existingCount + 1);
//         var args = ngDialog.open.calls.argsFor(existingCount);
//         expect(args).not.toBe(null);
//         expect(args.length).toBe(1);

//         expect(args[0].controller).toBe('AnnouncementManagementController');
//         expect(typeof args[0].resolve).toBe('object');
//         args[0].resolve.items();
//       });

//       it('Should call edit filterGrid', function () {
//         var value = "";
//         controller.gridApi = {
//           grid: {
//             columns: [{
//               filters: [{
//                 term: "test"
//               }]
//             }]
//           }
//         };
//         expect(controller['filterGrid']).toBeDefined();
//         controller.filterGrid(value);

//       });

//       it('Should call editAnnouncement  success response', function () {

//         successResponse = {
//           data: [{
//             "announcementIdentifier": 152,
//             "announcementTitleText": "Modified Announcement Title  2018_06_13_14_17_16_Copy",
//             "announcementTextRaw": "&nbsp;New Announcement Content &nbsp;2018_06_12_02_08_42&nbsp;",
//             "announcementText": "<p>New Announcement Content &nbsp;2018_06_12_02_08_42</p>",
//             "announcementStatusCategory": "Published",
//             "publishIndicator": "N",
//             "announcementTypeData": {
//               "announcementTypeName": "ReJoin PTAB",
//               "backgroundConfigurationText": "announcementBlue",
//               "displayOrderSequenceNumber": 1
//             },
//             "roleAnnouncements": [{
//               "userRoleIdentifier": 107,
//               "userRoleName": "Daily_Reports_Email_Mailbox",
//               "announcementIdentifier": 152,
//               "displayOrderSequenceNumber": 1,
//               "lifeCycle": {
//                 "beginEffectiveDate": 1529985600,
//                 "endEffectiveDate": 1530158400
//               },
//               "audit": {
//                 "createDateTime": 1530039681,
//                 "createUserIdentifier": "465",
//                 "lastModifiedDateTime": 1530039681,
//                 "lastModifiedUserIdentifier": "465",
//                 "lockControlNumber": 1
//               }
//             }],
//             "lifeCycle": {
//               "beginEffectiveDate": 1529985600,
//               "endEffectiveDate": 1530158400
//             },
//             "audit": {
//               "createDateTime": 1530039681,
//               "createUserIdentifier": "465",
//               "lastModifiedDateTime": 1530039681,
//               "lastModifiedUserIdentifier": "465",
//               "lockControlNumber": 1
//             },
//             "actions": [
//               "Copy",
//               "Edit",
//               "Unpublish",
//               "View"
//             ],
//             "createApplicationUserData": {
//               "applicationUserIdentifier": 465,
//               "employeeNumber": "C87234",
//               "userIdentifier": "ptabuser"
//             },
//             "updateApplicationUserData": {
//               "applicationUserIdentifier": 465,
//               "employeeNumber": "C87234",
//               "userIdentifier": "ptabuser"
//             }
//           }]
//         }
//         row = {
//           entity: {
//             announcementIdentifier: "152",
//             announcementStatusCategory: "Published"
//           }
//         }
//         type = {

//         }
//         expect(scope['editAnnouncement']).toBeDefined();
//         scope.editAnnouncement(row, type);

//         // HttpFactoryDeferred.resolve(successResponse);
//         // $rootScope.$apply();
//       });

//       it('Should call editAnnouncement  success response else block', function () {

//         successResponse = {
//           data: [{
//             "announcementIdentifier": 152,
//             "announcementTitleText": "Modified Announcement Title  2018_06_13_14_17_16_Copy",
//             "announcementTextRaw": "&nbsp;New Announcement Content &nbsp;2018_06_12_02_08_42&nbsp;",
//             "announcementText": "<p>New Announcement Content &nbsp;2018_06_12_02_08_42</p>",
//             "announcementStatusCategory": "Published",
//             "publishIndicator": "N",
//             "announcementTypeData": {
//               "announcementTypeName": "ReJoin PTAB",
//               "backgroundConfigurationText": "announcementBlue",
//               "displayOrderSequenceNumber": 1
//             },
//             "roleAnnouncements": [{
//               "userRoleIdentifier": 107,
//               "userRoleName": "Daily_Reports_Email_Mailbox",
//               "announcementIdentifier": 152,
//               "displayOrderSequenceNumber": 1,
//               "lifeCycle": {
//                 "beginEffectiveDate": 1529985600,
//                 "endEffectiveDate": 1530158400
//               },
//               "audit": {
//                 "createDateTime": 1530039681,
//                 "createUserIdentifier": "465",
//                 "lastModifiedDateTime": 1530039681,
//                 "lastModifiedUserIdentifier": "465",
//                 "lockControlNumber": 1
//               }
//             }],
//             "lifeCycle": {
//               "beginEffectiveDate": 1529985600,
//               "endEffectiveDate": 1530158400
//             },
//             "audit": {
//               "createDateTime": 1530039681,
//               "createUserIdentifier": "465",
//               "lastModifiedDateTime": 1530039681,
//               "lastModifiedUserIdentifier": "465",
//               "lockControlNumber": 1
//             },
//             "actions": [
//               "Copy",
//               "Edit",
//               "Unpublish",
//               "View"
//             ],
//             "createApplicationUserData": {
//               "applicationUserIdentifier": 465,
//               "employeeNumber": "C87234",
//               "userIdentifier": "ptabuser"
//             },
//             "updateApplicationUserData": {
//               "applicationUserIdentifier": 465,
//               "employeeNumber": "C87234",
//               "userIdentifier": "ptabuser"
//             }
//           }]
//         }
//         row = {
//           entity: {
//             announcementIdentifier: "152",
//           }
//         }
//         type = {

//         }
//         expect(scope['editAnnouncement']).toBeDefined();
//         scope.editAnnouncement(row, type);

//         // HttpFactoryDeferred.resolve(successResponse);
//         // $rootScope.$apply();
//       });

//       it('Should call editAnnouncement  failure response', function () {

//         row = {
//           entity: {
//             announcementIdentifier: "152"
//           }
//         }
//         type = {

//         }

//         failureResponse = {
//           data: {}
//         }
//         expect(scope['editAnnouncement']).toBeDefined();
//         scope.editAnnouncement(row, type);

//         HttpFactoryDeferred.reject(failureResponse);
//         $rootScope.$apply();
//       });

//       it('Should invoke pressEnter ', function () {
//         var event = {};
//         event.keyCode = 13;

//         spyOn(controller, 'filterService');
//         expect(controller['filterService']).toBeDefined();
//         expect(controller['pressEnter']).toBeDefined();
//         controller.pressEnter(event);
//         expect(controller.filterService).toHaveBeenCalled();
//       });

//       it('Should not invoke pressEnter ', function () {
//         var event = {};
//         event.keyCode = 14;

//         spyOn(controller, 'filterService');
//         expect(controller['filterService']).toBeDefined();
//         expect(controller['pressEnter']).toBeDefined();
//         controller.pressEnter(event);
//         expect(controller.filterService).not.toHaveBeenCalled();
//       });

//       it('Should not invoke filterService', function () {
//         var data = {
//           'text': "test"
//         };

//         successResponse = {
//           data: [{
//             "announcementIdentifier": 226,
//             "announcementTitleText": "Modified Announcement Title 2018_07_07_03_25_43",
//             "announcementTextRaw": "&nbsp;Test506&nbsp;",
//             "announcementText": "<p>Test506</p>",
//             "announcementStatusCategory": "Published",
//             "publishIndicator": "Y",
//             "announcementTypeData": {
//               "announcementTypeName": "announcementBlue",
//               "backgroundConfigurationText": "announcementGreen",
//               "displayOrderSequenceNumber": 1
//             },
//             "roleAnnouncements": [{
//               "userRoleIdentifier": 22,
//               "userRoleName": "PO_ApprovedMN_FirstBkUpCounsel",
//               "announcementIdentifier": 226,
//               "displayOrderSequenceNumber": 1,
//               "lifeCycle": {
//                 "beginEffectiveDate": 1530936000,
//                 "endEffectiveDate": 1562472000
//               },
//               "audit": {
//                 "createDateTime": 1530948363,
//                 "createUserIdentifier": "465",
//                 "lastModifiedDateTime": 1530948363,
//                 "lastModifiedUserIdentifier": "465",
//                 "lockControlNumber": 1
//               }
//             }],
//             "lifeCycle": {
//               "beginEffectiveDate": 1530936000,
//               "endEffectiveDate": 1562472000
//             },
//             "audit": {
//               "createDateTime": 1530948363,
//               "createUserIdentifier": "465",
//               "lastModifiedDateTime": 1530948363,
//               "lastModifiedUserIdentifier": "465",
//               "lockControlNumber": 1
//             },
//             "actions": [
//               "Copy",
//               "Edit",
//               "Unpublish",
//               "View"
//             ],
//             "createApplicationUserData": {
//               "applicationUserIdentifier": 465,
//               "employeeNumber": "C87234",
//               "userIdentifier": "ptabuser"
//             },
//             "updateApplicationUserData": {
//               "applicationUserIdentifier": 465,
//               "employeeNumber": "C87234",
//               "userIdentifier": "ptabuser"
//             }
//           }]
//         }

//         expect(controller['filterService']).toBeDefined();
//         controller.filterService();

//         // HttpFactoryDeferred.resolve(successResponse);
//         // $rootScope.$apply();
//       });

//       it('Should call view  Announcement', function () {

//         failureResponse = {
//           data: {

//           }
//         }
//         expect(controller['filterService']).toBeDefined();
//         controller.filterService();

//         HttpFactoryDeferred.reject(failureResponse);
//         $rootScope.$apply();
//       });

//       it('Should call view  Announcement', function () {
//         expect(scope.viewAnnouncement).toBeDefined();
//         var row = {
//           entity: {}
//         };
//         var type = null;
//         scope.viewAnnouncement(row, type);
//         expect(controller.announcement).toBe(row.entity);
//         expect(controller.announcement.flag).toBe(type);

//       });

//       it('Should call deleteAnnouncement  ', function () {

//         var row = {
//           entity: {}
//         };
//         var type = null;
//         var existingCount = ngDialog.open.calls.count();
//         expect(scope.deleteAnnouncement).toBeDefined();

//         scope.deleteAnnouncement(row, type);
//         expect(controller.announcement).toBe(row.entity);
//         expect(controller.announcement.flag).toBe(type);
//         expect(ngDialog.open).toHaveBeenCalled();
//         expect(ngDialog.open.calls.count()).toBe(existingCount + 1);
//         var args = ngDialog.open.calls.argsFor(existingCount);
//         expect(args).not.toBe(null);
//         expect(args.length).toBe(1);

//         expect(args[0].controller).toBe('AnnouncementManagementController');
//         expect(typeof args[0].resolve).toBe('object');
//         args[0].resolve.items();

//       });

//       it('Should call announcementToArchieve ', function () {

//         var row = {
//           entity: {}
//         };
//         var type = null;
//         var existingCount = ngDialog.open.calls.count();
//         expect(scope.announcementToArchieve).toBeDefined();

//         scope.announcementToArchieve(row, type);
//         expect(controller.announcement).toBe(row.entity);
//         expect(controller.announcement.flag).toBe(type);
//         expect(ngDialog.open).toHaveBeenCalled();
//         expect(ngDialog.open.calls.count()).toBe(existingCount + 1);
//         var args = ngDialog.open.calls.argsFor(existingCount);
//         expect(args).not.toBe(null);
//         expect(args.length).toBe(1);

//         expect(args[0].controller).toBe('AnnouncementManagementController');
//         expect(typeof args[0].resolve).toBe('object');
//         args[0].resolve.items();

//       });
//       // it('Should call copyAnnouncement  success response', function () {

//       //   successResponse = {
//       //     data: [{
//       //       "announcementIdentifier": 152,
//       //       "announcementTitleText": "Modified Announcement Title  2018_06_13_14_17_16_Copy",
//       //       "announcementTextRaw": "&nbsp;New Announcement Content &nbsp;2018_06_12_02_08_42&nbsp;",
//       //       "announcementText": "<p>New Announcement Content &nbsp;2018_06_12_02_08_42</p>",
//       //       "announcementStatusCategory": "Published",
//       //       "publishIndicator": "N",
//       //       "announcementTypeData": {
//       //         "announcementTypeName": "ReJoin PTAB",
//       //         "backgroundConfigurationText": "announcementBlue",
//       //         "displayOrderSequenceNumber": 1
//       //       },
//       //       "roleAnnouncements": [{
//       //         "userRoleIdentifier": 107,
//       //         "userRoleName": "Daily_Reports_Email_Mailbox",
//       //         "announcementIdentifier": 152,
//       //         "displayOrderSequenceNumber": 1,
//       //         "lifeCycle": {
//       //           "beginEffectiveDate": 1529985600,
//       //           "endEffectiveDate": 1530158400
//       //         },
//       //         "audit": {
//       //           "createDateTime": 1530039681,
//       //           "createUserIdentifier": "465",
//       //           "lastModifiedDateTime": 1530039681,
//       //           "lastModifiedUserIdentifier": "465",
//       //           "lockControlNumber": 1
//       //         }
//       //       }],
//       //       "lifeCycle": {
//       //         "beginEffectiveDate": 1529985600,
//       //         "endEffectiveDate": 1530158400
//       //       },
//       //       "audit": {
//       //         "createDateTime": 1530039681,
//       //         "createUserIdentifier": "465",
//       //         "lastModifiedDateTime": 1530039681,
//       //         "lastModifiedUserIdentifier": "465",
//       //         "lockControlNumber": 1
//       //       },
//       //       "actions": [
//       //         "Copy",
//       //         "Edit",
//       //         "Unpublish",
//       //         "View"
//       //       ],
//       //       "createApplicationUserData": {
//       //         "applicationUserIdentifier": 465,
//       //         "employeeNumber": "C87234",
//       //         "userIdentifier": "ptabuser"
//       //       },
//       //       "updateApplicationUserData": {
//       //         "applicationUserIdentifier": 465,
//       //         "employeeNumber": "C87234",
//       //         "userIdentifier": "ptabuser"
//       //       }
//       //     }]
//       //   }
//       //   row = {
//       //     entity: {
//       //       announcementIdentifier: "152",
//       //       announcementStatusCategory: "Published"
//       //     }
//       //   }
//       //   type = {

//       //   }

//       //   spyOn(controller, ["openAddNewAnnouncementModal"]);
//       //   expect(controller['openAddNewAnnouncementModal']).toBeDefined();
//       //   expect(scope['copyAnnouncement']).toBeDefined();
//       //   scope.copyAnnouncement(row, type);
//       //   expect(controller.openAddNewAnnouncementModal).toHaveBeenCalledWith();

//       //   HttpFactoryDeferred.resolve(successResponse);
//       //   $rootScope.$apply();
//       // });

//       // it('Should call copyAnnouncement  success response else block', function () {

//       //   successResponse = {
//       //     data: [{
//       //       "announcementIdentifier": 152,
//       //       "announcementTitleText": "Modified Announcement Title  2018_06_13_14_17_16_Copy",
//       //       "announcementTextRaw": "&nbsp;New Announcement Content &nbsp;2018_06_12_02_08_42&nbsp;",
//       //       "announcementText": "<p>New Announcement Content &nbsp;2018_06_12_02_08_42</p>",
//       //       "announcementStatusCategory": "Published",
//       //       "publishIndicator": "N",
//       //       "announcementTypeData": {
//       //         "announcementTypeName": "ReJoin PTAB",
//       //         "backgroundConfigurationText": "announcementBlue",
//       //         "displayOrderSequenceNumber": 1
//       //       },
//       //       "roleAnnouncements": [{
//       //         "userRoleIdentifier": 107,
//       //         "userRoleName": "Daily_Reports_Email_Mailbox",
//       //         "announcementIdentifier": 152,
//       //         "displayOrderSequenceNumber": 1,
//       //         "lifeCycle": {
//       //           "beginEffectiveDate": 1529985600,
//       //           "endEffectiveDate": 1530158400
//       //         },
//       //         "audit": {
//       //           "createDateTime": 1530039681,
//       //           "createUserIdentifier": "465",
//       //           "lastModifiedDateTime": 1530039681,
//       //           "lastModifiedUserIdentifier": "465",
//       //           "lockControlNumber": 1
//       //         }
//       //       }],
//       //       "lifeCycle": {
//       //         "beginEffectiveDate": 1529985600,
//       //         "endEffectiveDate": 1530158400
//       //       },
//       //       "audit": {
//       //         "createDateTime": 1530039681,
//       //         "createUserIdentifier": "465",
//       //         "lastModifiedDateTime": 1530039681,
//       //         "lastModifiedUserIdentifier": "465",
//       //         "lockControlNumber": 1
//       //       },
//       //       "actions": [
//       //         "Copy",
//       //         "Edit",
//       //         "Unpublish",
//       //         "View"
//       //       ],
//       //       "createApplicationUserData": {
//       //         "applicationUserIdentifier": 465,
//       //         "employeeNumber": "C87234",
//       //         "userIdentifier": "ptabuser"
//       //       },
//       //       "updateApplicationUserData": {
//       //         "applicationUserIdentifier": 465,
//       //         "employeeNumber": "C87234",
//       //         "userIdentifier": "ptabuser"
//       //       }
//       //     }]
//       //   }
//       //   row = {
//       //     entity: {
//       //       announcementIdentifier: "152",
//       //     }
//       //   }
//       //   type = {

//       //   }

//       //   spyOn(controller, ["openAddNewAnnouncementModal"]);
//       //   expect(controller['openAddNewAnnouncementModal']).toBeDefined();
//       //   expect(scope['copyAnnouncement']).toBeDefined();
//       //   scope.copyAnnouncement(row, type);
//       //   expect(controller.openAddNewAnnouncementModal).toHaveBeenCalledWith();

//       //   HttpFactoryDeferred.resolve(successResponse);
//       //   $rootScope.$apply();
//       // });

//       // it('Should call copyAnnouncement  failure response', function () {

//       //   row = {
//       //     entity: {
//       //       announcementIdentifier: "152"
//       //     }
//       //   }
//       //   type = {

//       //   }

//       //   failureResponse = {
//       //     data: {}
//       //   }

//       //   spyOn(controller, ["openAddNewAnnouncementModal"]);
//       //   expect(controller['openAddNewAnnouncementModal']).toBeDefined();
//       //   expect(scope['copyAnnouncement']).toBeDefined();
//       //   scope.copyAnnouncement(row, type);
//       //   expect(controller.openAddNewAnnouncementModal).toHaveBeenCalledWith();

//       //   HttpFactoryDeferred.reject(failureResponse);
//       //   $rootScope.$apply();
//       // });

//       it('Should invoke openAddNewAnnouncementModal ', function () {

//         var neworedit = "new"
//         controller.announcement = {};
//         expect(controller['openAddNewAnnouncementModal']).toBeDefined();
//         expect(ngDialog.open).toBeDefined();
//         controller.openAddNewAnnouncementModal(neworedit);

//         expect(ngDialog.open).toHaveBeenCalled();

//         expect(ngDialog.open.calls.count()).toBe(5);
//         var args = ngDialog.open.calls.argsFor(4);
//         expect(args).not.toBe(null);
//         expect(args.length).toBe(1);

//         expect(args[0].controller).toBe('AnnouncementManagementController');
//         expect(typeof args[0].resolve).toBe('object');
//         args[0].resolve.items();

//       });

//       it('Should invoke close on ngDialog', function () {
//         expect(ngDialog.close).toBeDefined();
//         expect(controller['closeAnnouncementDialog']).toBeDefined();
//         controller.closeAnnouncementDialog();
//         expect(ngDialog.close).toHaveBeenCalledWith();

//       });

//       it('it should invoke getJudgeRelatedData successresponse', function () {

//         successResponse =
//           [
//             {
//               judge: {
//                 loginId: "lren",
//                 userWorkerNumber: "92980",
//                 userIdentiifier: 5982,
//                 firstName: "LILAN",
//                 lastName: "REN",
//                 fullName: "REN, LILAN ",
//                 activeIn: "Active",
//                 emailAddress: "lilan.ren@uspto.gov ",
//                 roleDescription: "All Judges",
//                 privileges: []
//               },
//               attorneys: []
//             },
//             {
//               judge: {
//                 loginId: "jschneider1",
//                 userWorkerNumber: "92981",
//                 userIdentiifier: 5970,
//                 firstName: "JOHN",
//                 lastName: "SCHNEIDER",
//                 fullName: "SCHNEIDER, JOHN E",
//                 activeIn: "Active",
//                 emailAddress: "john.schneider@uspto.gov",
//                 roleDescription: "All Judges",
//                 privileges: []
//               },
//               attorneys: []
//             }
//           ]
//         expect(controller['getJudgeRelatedData']).toBeDefined();
//         controller.getJudgeRelatedData();

//       });
//       it('it should invoke getJudgeRelatedData failureResponse ', function () {

//         failureResponse = {};
//         HttpFactoryDeferred.reject(failureResponse);
//         $rootScope.$apply();

//         controller.getJudgeRelatedData();
//       });

//       it('it should invoke getJudgeRanks failureResponse ', function () {

//         failureResponse = {};
//         HttpFactoryDeferred.reject(failureResponse);
//         $rootScope.$apply();

//         controller.getJudgeRanks();
//       });

//       it('it should invoke getJudgeRanks successresponse', function () {

//         successResponse =
//           [
//             {
//               assigneeNumberText: "6015",
//               assigneeFullNameText: "SMITH, JEFFREY ",
//               workerNumber: "66869",
//               rankId: 1
//             },
//             {
//               assigneeNumberText: "6162",
//               assigneeFullNameText: "HORNER, LINDA ",
//               workerNumber: "82916",
//               rankId: 2
//             },
//             {
//               assigneeNumberText: "6043",
//               assigneeFullNameText: "GARRIS, BRADLEY R",
//               workerNumber: "59949",
//               rankId: 3
//             }
//           ]
//         expect(controller['getJudgeRanks']).toBeDefined();
//         controller.getJudgeRanks();

//       });

//       it('it should invoke getAttorneys successresponse', function () {

//         successResponse = {
//           data: {

//             assignedAttorneyList: [
//               {
//                 assigneeNumberText: "6099",
//                 assigneeFullNameText: "DELMENDO, ROMULO ",
//                 workerNumber: "67683"
//               },
//               {
//                 assigneeNumberText: "6251",
//                 assigneeFullNameText: "Dove, Esther ",
//                 workerNumber: "66889"
//               },
//               {
//                 assigneeNumberText: "6161",
//                 assigneeFullNameText: "HOELTER, MICHAEL ",
//                 workerNumber: "87120"
//               }
//             ],
//             nonAssignedAttorneyList: [
//               {
//                 assigneeNumberText: "6099",
//                 assigneeFullNameText: "DELMENDO, ROMULO ",
//                 workerNumber: "67683"
//               },
//               {
//                 assigneeNumberText: "6251",
//                 assigneeFullNameText: "Dove, Esther ",
//                 workerNumber: "66889"
//               },
//               {
//                 assigneeNumberText: "6161",
//                 assigneeFullNameText: "HOELTER, MICHAEL ",
//                 workerNumber: "87120"
//               }
//             ]
//           }

//         }

//         //$rootScope.$apply();
//         controller.judgeList = [
//           {
//             assigneeNumberText: "6099",
//             assigneeFullNameText: "DELMENDO, ROMULO ",
//             workerNumber: "67683"
//           },
//           {
//             assigneeNumberText: "6251",
//             assigneeFullNameText: "Dove, Esther ",
//             workerNumber: "66889"
//           },
//           {
//             assigneeNumberText: "6161",
//             assigneeFullNameText: "HOELTER, MICHAEL ",
//             workerNumber: "87120"
//           }
//         ]
//         controller.destjudgeList = [
//           {
//             assigneeNumberText: "6099",
//             assigneeFullNameText: "DELMENDO, ROMULO ",
//             workerNumber: "67683"
//           },
//           {
//             assigneeNumberText: "6251",
//             assigneeFullNameText: "Dove, Esther ",
//             workerNumber: "66889"
//           },
//           {
//             assigneeNumberText: "6161",
//             assigneeFullNameText: "HOELTER, MICHAEL ",
//             workerNumber: "87120"
//           }
//         ]
//         controller.judgeEmpNo = "45489";
//         expect(controller['getAttorneys']).toBeDefined();
//         HttpFactoryDeferred.resolve(successResponse);
//         controller.getAttorneys();

//         // expect(controller.getAttorneys).toBeDefined();
//         // controller.getAttorneys();
//         expect(controller.judgeList).toEqual(successResponse.data.nonAssignedAttorneyList);
//         expect(controller.destjudgeList).toEqual(successResponse.data.assignedAttorneyList);





//       });

//       it('it should invoke getAttorneys failureResponse ', function () {

//         failureResponse = {};
//         HttpFactoryDeferred.reject(failureResponse);
//         $rootScope.$apply();

//         controller.getAttorneys();
//       });
//       it('it should invoke judgelist  ', function () {

//         var row = {
//           entity: {
//             uisd: {
//               groupVal: "ABRAHAM, JEFFREY W",
//               rendered: "ABRAHAM, JEFFREY W"
//             }
//           }
//         }
//         controller.gridOptionsJudgeRelationship.data =
//           [{
//             judgeFullName: "ABRAHAM, JEFFREY W",
//             judgeEmpNo: '1562',
//             judgeWorkerNumber: '54'
//           }
//           ]
//         scope.editJudge(row);
//         expect(controller.gridOptionsJudgeRelationship.data).toBeDefined();
//       });
//       it('it should invoke moveJudgetopanel  ', function () {


//         controller.gridOptionsJudgeRelationship.data =
//           [{
//             judgeFullName: "ABRAHAM, JEFFREY W",
//             judgeEmpNo: '1562',
//             judgeWorkerNumber: '54'
//           },
//           {
//             assigneeNumberText: "6099",
//             assigneeFullNameText: "DELMENDO, ROMULO ",
//             workerNumber: "67683"
//           },
//           {
//             assigneeNumberText: "6251",
//             assigneeFullNameText: "Dove, Esther ",
//             workerNumber: "66889"
//           }
//           ]
//         scope.items = ["1", "2"];
//         scope.destjudgeList = [{
//           assigneeNumberText: "6099",
//           assigneeFullNameText: "DELMENDO, ROMULO ",
//           workerNumber: "67683"
//         },
//         {
//           assigneeNumberText: "6251",
//           assigneeFullNameText: "Dove, Esther ",
//           workerNumber: "66889"
//         }
//         ]
//         scope.judgeList = [{
//           judgeFullName: "ABRAHAM, JEFFREY W",
//           judgeEmpNo: '1562',
//           judgeWorkerNumber: '54'
//         },
//         {
//           assigneeNumberText: "6099",
//           assigneeFullNameText: "DELMENDO, ROMULO ",
//           workerNumber: "67683"
//         },
//         {
//           assigneeNumberText: "6251",
//           assigneeFullNameText: "Dove, Esther ",
//           workerNumber: "66889"
//         }
//         ]
//         scope.originalList = [{
//           judgeFullName: "ABRAHAM, JEFFREY W",
//           judgeEmpNo: '1562',
//           judgeWorkerNumber: '54'
//         },
//         {
//           assigneeNumberText: "6099",
//           assigneeFullNameText: "DELMENDO, ROMULO ",
//           workerNumber: "67683"
//         },
//         {
//           assigneeNumberText: "6251",
//           assigneeFullNameText: "Dove, Esther ",
//           workerNumber: "66889"
//         }
//         ]
//         scope.itemToMove = {
//           judgeFullName: "ABRAHAM, JEFFREY W",
//           judgeEmpNo: '1562',
//           judgeWorkerNumber: '54'
//         }
//         //scope.moveJudgeToPanel ();
//         expect(scope.items).toBeDefined();
//       });
//       // it('copyAnnouncement  should return successresponse', function () {
//       //   successResponse = {
//       //     data: [
//       //     ]
//       //   }
//       //   row = {
//       //     entity: {
//       //       announcementIdentifier: "152",
//       //       announcementStatusCategory: "Published"
//       //     }
//       //   }
//       //   type = {

//       //   }
//       //   expect(scope['copyAnnouncement']).toBeDefined();
//       //   scope.copyAnnouncement(row, type);
//       // });


//       // it('it should invoke copyAnnouncement failureResponse ', function () {

//       //   row = {
//       //     entity: {
//       //       announcementIdentifier: "152"
//       //     }
//       //   }
//       //   type = {

//       //   }

//       //   failureResponse = {
//       //     data: {}
//       //   }
//       //   expect(scope['copyAnnouncement']).toBeDefined();
//       //   scope.copyAnnouncement(row, type);

//       //   HttpFactoryDeferred.reject(failureResponse);
//       //   $rootScope.$apply();
//       // });
//     });

//   });
// })();
