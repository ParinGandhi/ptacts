(function () {
    'use strict';
  
    describe('AdminController', function () {
  
      beforeEach(module('ptabe2e'));
      var $controller;
      var vm = this;
      var controller;
      var $rootScope;
      var $ngDialog = jasmine.createSpyObj('ngDialog', ['open']);
     
      beforeEach(inject(function (_$controller_, _$rootScope_) {
        $controller = _$controller_;
        $rootScope = _$rootScope_;
               
        $ngDialog.open.and.returnValue({
          closePromise:{
            then:function(callback){

              callback({value: 1});
            }
            
          }
        });

        controller = $controller('AdminController', {
          ngDialog: $ngDialog
        });
      }));
  
      describe('AdminController ', function () {
  
        it('it should open admin console', function () {
          controller.userInfo ={};
         
          controller.workerNumber =100; 
   
          expect(controller.openAdminConsole).toBeDefined();
          
          controller.openAdminConsole();
          expect($ngDialog.open).toHaveBeenCalled();
   
          expect($ngDialog.open.calls.count()).toBe(1);
          var args = $ngDialog.open.calls.argsFor(0);
          expect(args).not.toBe(null);
          expect(args.length).toBe(1);

          expect(args[0].controller).toBe('AnnouncementAdminController');
          expect(typeof args[0].resolve).toBe('object');
          args[0].resolve.userInfo();
          expect($rootScope.worker).toBe(100);
        });
   
      });
  
  
    });
  })();
  