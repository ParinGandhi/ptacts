(function () {
  'use strict';

  describe('cancelAnnouncementPopupController', function () {

    beforeEach(module('ptabe2e'));

    var vm = this;
    var scope;
    var controller, $controller;
    var $rootScope, timeout, CONSTANTS;
    var $q, HttpFactoryDeferred, spy, item;
    var successResponse, failureResponse;
    var item = {
      constant: {},
      constants: {
        published: "PUBLISHED",
        draft: "DRAFT",
        archived: "ARCHIVED"
      },
      statusToSave: "DRAFT",
      lifeCycle: {
        beginEffectiveDate: null,
        endEffectiveDate: null
      },
      selectedRoles: [{

      }]
    }
    CONSTANTS = {
      "ANNOUNCEMENTS": {
        "STATUS_DRAFT": "DRAFT"
      }
    }
    var ngDialog = jasmine.createSpyObj('ngDialog', ['close', 'getOpenDialogs']);

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, _$timeout_, HttpFactory, CONSTANTS) {
      $q = _$q_;
      timeout = _$timeout_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      $controller = _$controller_;
      CONSTANTS = CONSTANTS

      CONSTANTS.ANNOUNCEMENTS = {
        STATUS_PUBLISHED: "PUBLISHED",
        STATUS_DRAFT: "DRAFT",
        STATUS_ARCHIVED: "ARCHIVED"
      }

      $rootScope.userInfo = {
        "userId": "pgandhi"
      }


      // setup the promise
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);

      controller = $controller('cancelAnnouncementPopupController', {

        $scope: scope,
        item: item,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory,
        CONSTANTS: CONSTANTS

      });

    }));

    describe('check functions', function () {

      it('it should call focus', function () {

        var dummyElement = document.createElement('div');
        document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(dummyElement);
        spyOn(document.getElementById("modalClose"), 'blur');
        expect(document.getElementById("modalClose").blur).toBeDefined();
        expect(controller['focus']).toBeDefined();
        controller.focus();
        timeout.flush();
        expect(dummyElement.blur).toHaveBeenCalled();

      });

      it('Should invoke focus', function () {

        spyOn(controller, 'focus');
        expect(controller['focus']).toBeDefined();

      });

      it('it should confirm confirmCancel', function () {
        var choice = true;
        expect(controller.confirmCancel).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.confirmCancel(choice);

      });

      it('it should confirm confirmCancel', function () {
        var choice = false;
        var ngDialogArray = [ngDialog, ngDialog];

        expect(ngDialog.close).toBeDefined();
        expect(controller['confirmCancel']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        controller.confirmCancel();
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog);

        expect(ngDialog.close).toBeDefined();
        expect(controller['confirmCancel']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.confirmCancel();
        expect(ngDialog.close).toHaveBeenCalledWith();

      });

      it('it should put announcement', function () {
        // var choice = true;
        controller.publishAnnouncement = {
          announcementIdentifier: "157"
          // createApplicationUserData: "defined"
        }
        var data = {
          announcementTypeData: {},
          listRoleDisplaySequence: {},
          lifeCycle: {
            beginEffectiveDate: '',
            endEffectiveDate: ''
          }

        };

        successResponse = {
          data: {
            "announcementIdentifier": 157,
            "announcementTitleText": "Modified Announcement Title 2018_06_27_03_19_59",
            "announcementText": "<p>Test1231111111111</p>",
            "announcementStatusCategory": "Published",
            "announcementTypeData": {
              "announcementTypeName": "announcementGreen"
            },
            "listRoleDisplaySequence": [{
              "userRoleIdentifier": 24,
              "userRoleName": null,
              "announcementIdentifier": null,
              "displayOrderSequenceNumber": 1,
              "lifeCycle": null,
              "audit": null
            }],
            "lifeCycle": {
              "beginEffectiveDate": 1534996800,
              "endEffectiveDate": 1561608000
            },
            "audit": {
              "createUserIdentifier": "pgandhi",
              "lastModifiedUserIdentifier": "pgandhi"
            }
          }
        }

        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();

        expect(controller.putAnnouncement).toBeDefined();
        spyOn(controller, ['buildAnnouncementData']).and.returnValue(data);
        expect(controller.buildAnnouncementData).toBeDefined();
        controller.putAnnouncement();
        expect(controller.buildAnnouncementData).toHaveBeenCalled();

      });


      it('it should post announcemnt', function () {
        // var choice = true;
        var data = {
          "announcementTitleText": "test",
          "announcementText": "<p>testing&nbsp;</p>",
          "announcementTypeData": {
            "announcementTypeName": "APPEALS"
          },
          "listRoleDisplaySequence": [{
            "userRoleIdentifier": 18,
            "displayOrderSequenceNumber": 1
          }],
          "lifeCycle": {
            "beginEffectiveDate": 1535515200,
            "endEffectiveDate": 1536379200
          },
          "audit": {
            "createUserIdentifier": "pgandhi",
            "lastModifiedUserIdentifier": "pgandhi"
          },
          "announcementStatusCategory": "Published"
        }

        successResponse = {
          data: {
            "announcementIdentifier": 302,
            "announcementTitleText": "test",
            "announcementTextRaw": "&nbsp;testing&nbsp;&nbsp;",
            "announcementText": "<p>testing&nbsp;</p>",
            "announcementStatusCategory": "Published",
            "publishIndicator": "N",
            "announcementTypeData": {
              "announcementTypeName": "APPEALS",
              "backgroundConfigurationText": "announcementBlue",
              "displayOrderSequenceNumber": 1
            },
            "listRoleDisplaySequence": [{
              "userRoleIdentifier": 18,
              "userRoleName": "Petitioner_ApprovedMN_LeadCounsel",
              "announcementIdentifier": 302,
              "displayOrderSequenceNumber": 1,
              "lifeCycle": {
                "beginEffectiveDate": 1535515200,
                "endEffectiveDate": 1536379200
              },
              "audit": {
                "createDateTime": 1534798793,
                "createUserIdentifier": "5768",
                "lastModifiedDateTime": 1534798793,
                "lastModifiedUserIdentifier": "5768",
                "lockControlNumber": 1
              }
            }],
            "lifeCycle": {
              "beginEffectiveDate": 1535515200,
              "endEffectiveDate": 1536379200
            },
            "audit": {
              "createDateTime": 1534798793,
              "createUserIdentifier": "5768",
              "lastModifiedDateTime": 1534798793,
              "lastModifiedUserIdentifier": "5768",
              "lockControlNumber": 1
            },
            "actions": [
              "Copy",
              "Edit",
              "Unpublish",
              "View"
            ],
            "createApplicationUserData": {
              "applicationUserIdentifier": 5768,
              "employeeNumber": "C54957",
              "userIdentifier": "pgandhi"
            },
            "updateApplicationUserData": {
              "applicationUserIdentifier": 5768,
              "employeeNumber": "C54957",
              "userIdentifier": "pgandhi"
            }
          }
        }
        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();

        expect(controller.postAnnouncement).toBeDefined();
        spyOn(controller, ['buildAnnouncementData']);
        expect(controller.buildAnnouncementData).toBeDefined();
        controller.postAnnouncement();
        expect(controller.buildAnnouncementData).toHaveBeenCalled();

      });

      it('it should post announcemnt', function () {

        failureResponse = {
          "message": "posted"
        };
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();

        expect(controller.postAnnouncement).toBeDefined();
        controller.postAnnouncement();

      });

      // it('it should call buildAnnouncementData', function () {
      //   controller.publishAnnouncement = {
      //     "statusToSave": "DRAFT",
      //     "selectedType": ""
      //   }

      //   expect(controller.buildAnnouncementData).toBeDefined();
      //   controller.buildAnnouncementData();

      // });

      it('it should confirm confirmPublishCancel', function () {
        var choice = false;
        var ngDialogArray = [ngDialog, ngDialog];

        expect(ngDialog.close).toBeDefined();
        expect(controller['confirmPublishCancel']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialogArray);
        controller.confirmPublishCancel();
        expect(ngDialog.close).toHaveBeenCalledWith(ngDialog);

        expect(ngDialog.close).toBeDefined();
        expect(controller['confirmPublishCancel']).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.confirmPublishCancel();
        expect(ngDialog.close).toHaveBeenCalledWith();

      });

      it('it should confirm publish', function () {
        var choice = true;
        controller.publishAnnouncement = {
          lifeCycle: {
            beginEffectiveDate: 2018
          },
          announcementStatusCategory: "PUBLISHED",
          statusToSave: "PUBLISHED"
        }
        expect(controller.confirmPublish).toBeDefined();
        spyOn(controller, ['putAnnouncement']);
        expect(controller.putAnnouncement).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.confirmPublish(choice);
        expect(controller.putAnnouncement).toHaveBeenCalled();


        controller.publishAnnouncement = {
          lifeCycle: {
            beginEffectiveDate: 2018
          },
          announcementStatusCategory: "PUBLISHED",
          statusToSave: "SAVE"
        }

        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.confirmPublish(choice);
        expect(controller.putAnnouncement).toHaveBeenCalled();

      });


      it('it should confirmDraft', function () {
        // var choice = true;
        controller.publishAnnouncement = {
          announcementStatusCategory: "DRAFT",
          statusToSave: "DRAFT",
          toClose: true,
          lifeCycle: {
            endEffectiveDate: 2018,
            beginEffectiveDate: 2017,
            audienceStr: "test"
          },
          selectedRoles: [{

          }]
        }
        expect(controller.confirmDraft).toBeDefined();
        spyOn(controller, ['putAnnouncement']);
        expect(controller.putAnnouncement).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.confirmDraft();
        expect(controller.putAnnouncement).toHaveBeenCalled();

        controller.publishAnnouncement.announcementStatusCategory = 'Test';
        controller.confirmDraft();
        expect(controller.putAnnouncement).toHaveBeenCalled();

      });

    });

  });
})();
