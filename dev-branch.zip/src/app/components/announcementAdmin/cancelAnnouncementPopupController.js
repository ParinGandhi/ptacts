(function () {
  'use strict';
  /**
   * Cancel AnnouncementPopupController is attached to the cacnel announcement dialog
   */
  angular
    .module('ptabe2e')
    .controller('cancelAnnouncementPopupController', function (ngDialog, item, HttpFactory, CONSTANTS, $rootScope, CommonHelperService, $timeout, $log) {
      var vm = this;
      vm.publishAnnouncement = item;


      vm.focus = function () {
        $timeout(function () {
          var title = document.getElementById("modalClose");
          title.blur();
        }, 300);

      };

      vm.focus();
      if (vm.publishAnnouncement !== false) {
        vm.publishAnnouncement.constant = {};
        vm.publishAnnouncement.constants.published = CONSTANTS.ANNOUNCEMENTS.STATUS_PUBLISHED;
        vm.publishAnnouncement.constants.draft = CONSTANTS.ANNOUNCEMENTS.STATUS_DRAFT;
        vm.publishAnnouncement.constants.archived = CONSTANTS.ANNOUNCEMENTS.STATUS_ARCHIVED;
      }
      vm.confirmCancel = function (choice) {
        if (choice) {
          // closes confirmation popup and announcement popup
          closeAnnouncementDialog(1);
          closeAnnouncementDialog(1);
        }
        if (!choice) {
          closeAnnouncementDialog(1);

        }
      };

      function closeAnnouncementDialog(popupsToClose) {

        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose]);
        } else {
          ngDialog.close();
        }
      }
      vm.buildAnnouncementData = function () {

        var audit = {
          'createUserIdentifier': $rootScope.userInfo.userId,
          'lastModifiedUserIdentifier': $rootScope.userInfo.userId
        };

        var announcementTypeData = {
          'announcementTypeNameText': vm.publishAnnouncement.selectedType
        };

        var roleAnnouncements = [];
        angular.forEach(vm.publishAnnouncement.selectedRoles, function (role) {
          var roleObj = {
            'userRoleIdentifier': role.id,
            "displayOrderSequenceNumber": 1
          };
          roleObj.audit = audit;
          roleAnnouncements.push(roleObj);


        });
        var lifeCycle = {};

        buildLifeCycle(lifeCycle);

        var announcementData = {
          'announcementTitleText': vm.publishAnnouncement.announcementTitleText,
          'announcementText': vm.publishAnnouncement.announcementText,
          'announcementTypeData': announcementTypeData,
          'roleAnnouncements': roleAnnouncements,
          'lifeCycle': lifeCycle,
          'audit': audit,
          'announcementStatusCategory': vm.publishAnnouncement.statusToSave
        };
        if (vm.publishAnnouncement.statusToSave === CONSTANTS.ANNOUNCEMENTS.STATUS_DRAFT) {
          /* istanbul ignore if */
          if (vm.publishAnnouncement.selectedType === '') {
            delete announcementData.announcementTypeData;
          }
          /* istanbul ignore if */
          if (vm.publishAnnouncement.selectedRoles.length === 0) {
            delete announcementData.roleAnnouncements;
          }

          prepareLifeCycle(announcementData);

        }
        return announcementData;
      };

      function prepareLifeCycle(announcementData) {
        /* istanbul ignore if */
        if (vm.publishAnnouncement.lifeCycle.beginEffectiveDate === '' ||
          vm.publishAnnouncement.lifeCycle.beginEffectiveDate === 0 ||
          vm.publishAnnouncement.lifeCycle.beginEffectiveDate === null) {
          if (vm.publishAnnouncement.lifeCycle.endEffectiveDate === '' ||
            vm.publishAnnouncement.lifeCycle.endEffectiveDate === 0 ||
            vm.publishAnnouncement.lifeCycle.endEffectiveDate === null) {
            delete announcementData.lifeCycle;
          } else {
            delete announcementData.lifeCycle.beginEffectiveDate;
          }
        } else {
          /* istanbul ignore if */
          if (vm.publishAnnouncement.lifeCycle.endEffectiveDate === '' ||
            vm.publishAnnouncement.lifeCycle.endEffectiveDate === 0 ||
            vm.publishAnnouncement.lifeCycle.endEffectiveDate === null) {
            delete announcementData.lifeCycle.endEffectiveDate;
          }
        }
      }

      function buildLifeCycle(lifeCycle) {
        if (vm.publishAnnouncement.lifeCycle.beginEffectiveDate !== null &&
          vm.publishAnnouncement.lifeCycle.beginEffectiveDate !== 0 &&
          vm.publishAnnouncement.lifeCycle.beginEffectiveDate !== '') {

          lifeCycle.beginEffectiveDate = new Date(vm.publishAnnouncement.lifeCycle.beginEffectiveDate).getTime();

        }
        if (vm.publishAnnouncement.lifeCycle.endEffectiveDate !== null &&
          vm.publishAnnouncement.lifeCycle.endEffectiveDate !== 0 &&
          vm.publishAnnouncement.lifeCycle.endEffectiveDate !== '') {

          lifeCycle.endEffectiveDate = new Date(vm.publishAnnouncement.lifeCycle.endEffectiveDate).getTime();
        }
      }

      vm.putAnnouncement = function () {
        var data = vm.buildAnnouncementData();
        /* istanbul ignore if */
        if (angular.isDefined(vm.publishAnnouncement.createApplicationUserData)) {
          data.audit.createUserIdentifier = vm.publishAnnouncement.createApplicationUserData.userIdentifier;
        }
        data.announcementIdentifier = vm.publishAnnouncement.announcementIdentifier;
        /* istanbul ignore next */
        HttpFactory.putActions(CONSTANTS.URL.UPDATE_ANNOUNCEMENT + vm.publishAnnouncement.announcementIdentifier, data)
          .then(function () {
            $log.debug("success put");
            vm.publishAnnouncement.flag = null;
            closeAnnouncementDialog(1);
            closeAnnouncementDialog(1);
          }, function (failureResponse) {
            $log.debug(failureResponse);
            if (angular.isDefined(failureResponse.message)) {
              CommonHelperService.setToastr(failureResponse.message, "error");
            } else {
              CommonHelperService.setToastr(failureResponse.data.message, "success");
            }
          });
      };


      function verifyTypeAndRoles(data) {
        if (vm.publishAnnouncement.statusToSave === CONSTANTS.ANNOUNCEMENTS.STATUS_DRAFT) {
          /* istanbul ignore if */
          if (vm.publishAnnouncement.selectedType === '') {
            delete data.announcementTypeData;
          }
          /* istanbul ignore if */
          if (vm.publishAnnouncement.selectedRoles.length === 0) {
            delete data.roleAnnouncements;
          }
        }
      }
      /* istanbul ignore next */
      function verifyBeginEffectiveDate(data) {
        if (vm.publishAnnouncement.lifeCycle.endEffectiveDate === '' || vm.publishAnnouncement.lifeCycle.endEffectiveDate === 0) {
          delete data.lifeCycle;
        } else {
          delete data.lifeCycle.beginEffectiveDate;
        }
      }


      vm.postAnnouncement = function () {
        var data = vm.buildAnnouncementData();

        verifyTypeAndRoles(data);
        /* istanbul ignore if */
        if (vm.publishAnnouncement.lifeCycle.beginEffectiveDate === '' || vm.publishAnnouncement.lifeCycle.beginEffectiveDate === 0) {
          verifyBeginEffectiveDate(data);
        } else {
          /* istanbul ignore if */
          if (vm.publishAnnouncement.lifeCycle.endEffectiveDate === '' || vm.publishAnnouncement.lifeCycle.endEffectiveDate === 0) {
            delete data.lifeCycle.endEffectiveDate;
          }
        }
        /* istanbul ignore next */
        HttpFactory.postActions(CONSTANTS.URL.PUBLISH_ANNOUNCEMENT, data)
          .then(function (successResponse) {
            $log.debug("success post");
            vm.publishAnnouncement.announcementIdentifier = successResponse.data.announcementIdentifier;
          }, function (failureResponse) {
            $log.debug(failureResponse);
            if (angular.isDefined(failureResponse.message)) {
              CommonHelperService.setToastr(failureResponse.message, "success");
            } else {
              CommonHelperService.setToastr(failureResponse.data.message, "success");
            }
          });
      };


      //function to close publish confirmation popup
      vm.confirmPublishCancel = function (choice) {

        if (!choice) {
          closeAnnouncementDialog(1);
        }
      };

      // method to call service to publish announcement
      vm.confirmPublish = function (choice) {
        if (choice) {
          vm.publishAnnouncement.confirmClicked = true;
          if ((vm.publishAnnouncement.announcementStatusCategory ===
              CONSTANTS.ANNOUNCEMENTS.STATUS_DRAFT ||
              vm.publishAnnouncement.announcementStatusCategory ===
              CONSTANTS.ANNOUNCEMENTS.STATUS_PUBLISHED) &&
            vm.publishAnnouncement.statusToSave ===
            CONSTANTS.ANNOUNCEMENTS.STATUS_PUBLISHED) {

            vm.putAnnouncement();
          } else {
            vm.postAnnouncement();
            closeAnnouncementDialog(1);
            closeAnnouncementDialog(1);
          }
        }
      };


      vm.confirmDraft = function () {
        vm.publishAnnouncement.confirmClicked = true;
        if (vm.publishAnnouncement.announcementStatusCategory ===
          CONSTANTS.ANNOUNCEMENTS.STATUS_DRAFT &&
          vm.publishAnnouncement.statusToSave ===
          CONSTANTS.ANNOUNCEMENTS.STATUS_DRAFT) {

          vm.putAnnouncement();
        } else {
          vm.postAnnouncement();
          if (vm.publishAnnouncement.toClose) {
            closeAnnouncementDialog(1);
          }
          closeAnnouncementDialog(1);
        }
      };
    });

})();
