(function () {
  'use strict';

  describe('ErratumOrderMiscController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open', 'getOpenDialogs', 'close']);
    var controller, scope, $rootScope, documentType;
    var $q, HttpFactoryDeferred, caseInfo, content;
    var successResponse = "";

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);

      controller = $controller('ErratumOrderMiscController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        caseInfo: caseInfo,
        HttpFactory: HttpFactory,
      });
    }));

    describe('ErratumOrderMiscController', function () {

      it('Should invoke dismiss on ngDialog', function () {
        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['cancelInitiate']).toBeDefined();
        controller.cancelInitiate();
        expect(ngDialog.closeAll).toHaveBeenCalledWith(false);
      });

      it('it should call moreAssigneesData', function () {
        expect(controller.moreAssigneesData).toBeDefined();
        controller.moreAssigneesData();
      });


      //   it(' should call change', function () {
      //     content = {
      //       assigneeFullNameText: "JKG",
      //       activeCaseCount: "2",
      //       assigneeStatus: "A",
      //       assigneeNumberText: "2"
      //     }
      //     expect(controller.change).toBeDefined();
      //     controller.change(content);
      //   });

    });
  });
})();
