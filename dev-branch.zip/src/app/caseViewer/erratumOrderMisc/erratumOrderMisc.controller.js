(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('ErratumOrderMiscController', function (caseInfo, ngDialog, HttpFactory, CONSTANTS, $window, CirculationHelperService, CommonHelperService) {
      var vm = this;
      vm.assignedTo = false;
      var documentType;
      vm.submitted = false;

      function getAssigneeList() {
        HttpFactory.getActions(CONSTANTS.URL.ASSIGNEEUSERS + $window.sessionStorage.getItem("workerNumber"))
          .then(function (assigneeListSuccess) {
            console.log('assigneeListSuccess: ', assigneeListSuccess);
            vm.myMangers = assigneeListSuccess.data.managersData;
            vm.myTeamData = assigneeListSuccess.data.teamData;
            vm.myGroupData = assigneeListSuccess.data.groupData;
            vm.workQueueData = assigneeListSuccess.data.workQueueData;
            if (vm.myGroupData === null) {
              vm.moreAssignees = true;
            } else {
              vm.groupLength = vm.myGroupData.length;
              if (vm.groupLength === 0) {
                vm.moreAssignees = true;
              }
            }
            vm.foundAssigne = false;

            if (!vm.foundAssigne) {
              vm.currentAssignee = {
                assigneeFullNameText: 'Not assigned',
                activeCaseCount: '',
                assigneeStatus: '',
                assigneeNumberText: ""
              };
            }
            vm.originalcurrentAssignee = angular.copy(vm.currentAssignee);
            vm.change(vm.currentAssignee);
            vm.assignedTo = false;
          }, function (assigneeListFailure) {
            console.log('assigneeListFailure: ', assigneeListFailure);

          });
      }

      getAssigneeList();

      function getDocumentTypeList() {
        HttpFactory.getActions("/reference-data/code-reference-types?typeCode=SPL_ACTIONS")
          .then(function (documentTypeListSuccess) {
            vm.documentTypeList = documentTypeListSuccess.data;
          }, function (documentTypeListFailure) {
            console.log('documentTypeListFailure: ', documentTypeListFailure);

          });
      }
      getDocumentTypeList();

      vm.change = function (content) {
        vm.currentAssignee.assigneeFullNameText = content.assigneeFullNameText;
        vm.currentAssignee.activeCaseCount = content.activeCaseCount;
        vm.currentAssignee.assigneeStatus = content.assigneeStatus;
        vm.currentAssignee.assigneeNumberText = content.assigneeNumberText;
        vm.assignedTo = true;
      };

      vm.moreAssigneesData = function () {
        vm.extraData = false;
        vm.moreAssignees = true;
        vm.myGroup = vm.myGroupData;
      };

      function setAssignmentDueDate() {
        var nextBusinessDay = new Date();
        var numberOfDays = 2;
        nextBusinessDay.setDate(nextBusinessDay.getDate() + numberOfDays);
        while (!CirculationHelperService.isBusinessDay(nextBusinessDay)) {
          nextBusinessDay.setDate(nextBusinessDay.getDate() + 1);
        }
        vm.assignmentDueDate = nextBusinessDay;
      }

      setAssignmentDueDate();

      vm.submitDraft = function () {
        vm.submitted = true;
        if (angular.isString(vm.selectedDocumentType)) {
          documentType = JSON.parse(vm.selectedDocumentType);
        } else {
          documentType = vm.selectedDocumentType;
        }
        var initiateErratum = {
          "serialNumber": caseInfo.applicationNumber,
          "appealNumber": caseInfo.appealNumberText,
          "assignee": vm.currentAssignee.assigneeNumberText,
          "dueDate": vm.assignmentDueDate.getTime(),
          "notes": vm.addedNotes,
          "interruptType": documentType.valueText,
          "isInterruptAssignment": false,
          "audit": {
            "lastModifiedTimestamp": new Date().getTime(),
            "lastModifiedUserIdentifier": $window.sessionStorage.getItem("workerNumber"),
            "createTimestamp": new Date().getTime(),
            "createUserIdentifier": $window.sessionStorage.getItem("workerNumber")
          }
        };
        HttpFactory.putActions('/assignments/interrupts', initiateErratum)
          .then(function () {
            CommonHelperService.setToastr('"Create ' + documentType.descriptionText + ' draft" assignment created successfully', 'success');
            ngDialog.closeAll(true);
          }, function (erratumOrderMiscFailure) {
            CommonHelperService.setToastr(erratumOrderMiscFailure.data.message, 'error');
          }).finally(function () {
            vm.submitted = false;
          });
      };

      vm.setDocType = function (docType) {
        console.log('docType: ', docType);
        var temp = JSON.parse(docType);
        vm.docDescription = temp.descriptionText.toLowerCase();
      };

      vm.cancelInitiate = function () {
        ngDialog.closeAll(false);
      };
    });
})();
