(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('RemandDismissalConfirmationController', function (remandDismissalInfo, ngDialog, $window, HttpFactory, CommonHelperService) {

      var vm = this;
      var serviceCallMessage = remandDismissalInfo.isRemand ? "admin remand draft" : "dismissal draft";

      function setMessage() {
        if (remandDismissalInfo.casePaneled && remandDismissalInfo.briefHearingTypeCode !== "Heard") {
          vm.message = "System will delete all the pending open assignments and clear the panel.";
        } else if (remandDismissalInfo.casePaneled && remandDismissalInfo.briefHearingTypeCode === "Heard") {
          vm.message = "System will delete all the pending open assignments, clear the panel, and clear the hearing schedule.";
        } else if (!remandDismissalInfo.casePaneled) {
          vm.message = "System will delete all the pending open assignments.";
        }
      }

      setMessage();


      vm.noConfirm = function () {
        ngDialog.close(lastDialog());
      };

      function lastDialog() {
        var openDialogs = ngDialog.getOpenDialogs();
        return openDialogs[openDialogs.length - 1];
      }


      vm.yesConfirm = function () {
        var remandDismissalObject = {
          "serialNumber": remandDismissalInfo.applicationNumber,
          "appealNumber": remandDismissalInfo.appealNumberText,
          "assignee": remandDismissalInfo.assignedTo,
          "dueDate": remandDismissalInfo.assignmentDueDate,
          "notes": remandDismissalInfo.addedNotes,
          "interruptType": remandDismissalInfo.isRemand ? "REMAND" : "DISMISSAL",
          "isInterruptAssignment": true,
          "audit": {
            "lastModifiedTimestamp": new Date().getTime(),
            "lastModifiedUserIdentifier": $window.sessionStorage.getItem("workerNumber"),
            "createTimestamp": new Date().getTime(),
            "createUserIdentifier": $window.sessionStorage.getItem("workerNumber")
          }
        };
        HttpFactory.putActions('/assignments/interrupts', remandDismissalObject)
          .then(function (updateInterruptSuccess) {
            console.log('updateInterruptSuccess: ', updateInterruptSuccess);
            CommonHelperService.setToastr('Successfully created ' + serviceCallMessage, 'success');
            ngDialog.closeAll(true);
          }, function (updateInterruptFailure) {
            console.log('updateInterruptFailure: ', updateInterruptFailure);
            CommonHelperService.setToastr('Failure creating ' + serviceCallMessage, 'error');
          });


      };

    });
})();
