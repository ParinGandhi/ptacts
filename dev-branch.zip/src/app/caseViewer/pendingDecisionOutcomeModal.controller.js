(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('PendingDecisionOutcomeModalController', function ($scope, HttpFactory, info, $window, ngDialog, CommonHelperService, CONSTANTS) {

      $scope.info = info;
      $scope.disciplineChanged = false;
      $scope.selectedDecisionPanelList = [];

      function getOutcomeList() {
        // HttpFactory.getActions("/appeal-paneling-discipline")
        //   .then(function (successResponse) {
        //     $scope.panelingDisciplineList = successResponse.data.sort(compare);
        //     for (var i = 0; i < $scope.panelingDisciplineList.length; i++) {
        //       if ($scope.panelingDisciplineList[i].proceedingDisciplineDescriptionText === $scope.info.originalPanelingDiscipline) {
        //         $scope.selectedDiscipline = i.toString();
        //       }
        //     }
        //   }, function () {
        //     //intentional
        //   });
          HttpFactory.getActions(CONSTANTS.URL.DECISIONTYPE)
          .then(function (successResponse) {
            $scope.decisionList = successResponse.data;
            for (var i = 0; i < $scope.decisionList.length; i++) {
              if ($scope.decisionList[i].descriptionText === $scope.info.outcome) {
                $scope.selectedOutcome = i.toString();
                $scope.changeOutcome(i);
              }
            }
          }, function (failureResponse) {
            $log.info(failureResponse);
          });  
      }

      getOutcomeList();      

      $scope.changeOutcome = function (index) {
        //if ($scope.decisionList[parseInt(index, CONSTANTS.GLOBAL.RADIX)].descriptionText !== $scope.info.outcome) {
          $scope.changed = $scope.decisionList[parseInt(index, CONSTANTS.GLOBAL.RADIX)];
          $scope.disciplineChanged = true;
        //}
      };


      $scope.updateOutcome = function () {
        var newOutcome = {
          // "panelingDisciplineCode": $scope.changed.proceedingDisciplineCode,
          // "caseDisciplineCode": $scope.info.caseDiscipline,
          // "appealNumber": $scope.info.appealNumber,
          // "audit": {
          //   "createUserIdentifier": $window.sessionStorage.getItem("workerNumber"),
          //   "lastModifiedUserIdentifier": $window.sessionStorage.getItem("workerNumber")
          // }
          "serialNumber": $scope.info.serialNumber,
          "appealNumber": $scope.info.appealNumber,
          "decisionTypeCode": $scope.changed ? $scope.changed.descriptionText : undefined,
          "decisionTypeName": $scope.changed ? $scope.changed.valueText : undefined,    
          "audit": {
              "createUserIdentifier": $window.sessionStorage.getItem("workerNumber"),
              "createdUserName": null,
              "lockControlNumber": 0,
              "lastModifiedUserIdentifier": $window.sessionStorage.getItem("workerNumber"),
              "lastModifiedUserName": null,
              "lastModifiedTimestamp": (new Date()).getTime(),
              "createTimestamp": null
          },
          judgePanel:[]
        };
        if($scope.selectedDecisionPanelList.length>0){
          newOutcome.judgePanel = $scope.selectedDecisionPanelList;
        }
        
        console.log(newOutcome);
        console.log(JSON.stringify(newOutcome));

        HttpFactory.putActions("/appeal-decision/update-decision-outcome", newOutcome)
          .then(function (successResponse) {
            CommonHelperService.setToastr("Outcome successfully updated.", "success");
            ngDialog.closeAll();
            console.log(successResponse);
          }, function (failureResponse) {
            CommonHelperService.setToastr(failureResponse.data.message, 'error');
          });
      };


      $scope.cancelPanelDiscipline = function () {
        ngDialog.closeAll();
      };

      /** Sort the list of disciplines alphabetically */
      function compare(a, b) {
        var disciplineA = a.proceedingDisciplineDescriptionText.toUpperCase();
        var disciplineB = b.proceedingDisciplineDescriptionText.toUpperCase();

        var comparison = 0;
        if (disciplineA > disciplineB) {
          comparison = 1;
        } else if (disciplineA < disciplineB) {
          comparison = -1;
        }
        return comparison;
      }

      

      $scope.getSelectedJudgeList = function () {
        HttpFactory.getActions(CONSTANTS.URL.GET_SELECTED_JUDGES + $scope.info.appealNumber + "&applicationNumber=" + $scope.info.serialNumber)
          .then(function (successResponse) {
            var tempList = [];
            $scope.rsNum = successResponse.data.judgePanel[0].reconsiderSequenceNumber;
            $scope.panelToBeCreatedArray = successResponse.data.judgePanel[0].panelToBeCreated;
            var lowest = 0;
            var highest = 0;
            var tmp;
            for (var i = $scope.panelToBeCreatedArray.length - 1; i >= 0; i--) {
              tmp = $scope.panelToBeCreatedArray[i].panelSequenceNumber;
              if (tmp < lowest) lowest = tmp;
              if (tmp > highest) highest = tmp;
            }
            $scope.adsNum = highest;
            angular.forEach(successResponse.data.judgePanel[0].panelToBeCreated, function (panel) {


              if (panel.activeIndicator === "Y" || panel.activeIndicator === "P") {

                if (panel.panelRank === 0) {
                  $scope.paName = panel.panelName;
                  $scope.paRank = panel.panelRank;
                }
                tempList[panel.panelRank - 1] = {
                  "identifier": panel.identifier,
                  "panelName": panel.panelName,
                  "panelRank": panel.panelRank,
                  "activeIndicator": panel.activeIndicator,
                  "reconsiderSequenceNumber": panel.reconsiderSequenceNumber,
                  "lastModifiedUserIdentifier": $window.sessionStorage.getItem("workerNumber"),
                  "lastModifiedTimestamp": new Date().getTime(),
                  "serialNumber": $scope.info.serialNumber,
                  "appealNumber": $scope.info.appealNumber,
                  "lastModifiedTs":panel.lastModifiedTs,
                  "panelSequenceNumber":panel.panelSequenceNumber,
                  "assigneeStatus":panel.assigneeStatus,
                  "apjStatus":panel.apjStatus,
                  "panelMember":panel.panelMember,
                  "rulingCategory":panel.rulingCategory                  
                };
              }
            });

            $scope.judgesToPanel = tempList;
            if (angular.isDefined($scope.paRank) && $scope.paRank - 1 === -1) {
              var tempOrder = tempList[-1];
              tempList[tempList.length] = tempOrder;
            }
            $scope.apjList = [];
            $scope.tempApjList = tempList;
            $scope.apjList = $scope.tempApjList;
          });
      };
      
      $scope.getApjPanel = function () {
        HttpFactory.getActions(CONSTANTS.URL.APJPANEL)
          .then(function (successResponse) {

            $scope.apjPanelList = successResponse.data;
            if($scope.adhocFlag){
              angular.forEach($scope.apjPanelList, function (judgeList) {
                if(judgeList.descriptionText = $scope.apjPanel1RulingCategory){
                  $scope.setSelectedApj(judgeList.valueText,judgeList.descriptionText,0);
                }
                if(judgeList.descriptionText = $scope.apjPanel2RulingCategory){
                  $scope.setSelectedPA(judgeList.valueText,judgeList.descriptionText);
                }
              });
            }
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };

      $scope.getApj1 = function () {
        HttpFactory.getActions(CONSTANTS.URL.APJ1)
          .then(function (successResponse) {

            $scope.apjoneList = successResponse.data;
            if($scope.adhocFlag){
              angular.forEach($scope.apjoneList, function (judgeList) {
                if(judgeList.descriptionText = $scope.apj1RulingCategory){
                  $scope.setSelected(judgeList.valueText,judgeList.descriptionText);
                }
              });
            }
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };

      $scope.selectedDecision = {};
      $scope.selectedDecisionApj = {};
      $scope.selectedDecisionPA = {};

      $scope.setSelected = function (value, description) {
        $scope.selectedDecision.value = value;
        $scope.selectedDecision.description = description;
        $scope.judgesToPanel[0].rulingCategory = description;
        if ($scope.selectedDecision.value === 'PERCURIAM' || $scope.selectedDecision.value === 'per curiam' || $scope.selectedDecision.value === 'Per Curiam') {
          $scope.selectedDecisionApj.description = $scope.selectedDecision.description;
          $scope.selectedDecisionPA.description = $scope.selectedDecision.description;
          $scope.judgesToPanel.rulingCategory;
          angular.forEach($scope.judgesToPanel, function (judgeList) {
            judgeList.rulingCategory = value;
            $scope.selectedDecisionApj.description = "Per Curiam";
          });
        }
        $scope.disciplineChanged = true;
        $scope.setJudgelistObject(description,0);
      };

      $scope.setSelectedApj = function (value, description, id) {
        $scope.judgesToPanel[id + 1].rulingCategory = value;
        $scope.selectedDecisionApj.description = $scope.judgesToPanel[id + 1].rulingCategory.descriptionText;
        $scope.selectedDecisionApj.value = $scope.judgesToPanel[id + 1].rulingCategory.valueText;
        if (value === 'PERCURIAM' || value === 'per curiam' || value === 'Per Curiam') {
          $scope.selectedDecisionPA.description = value;
          $scope.selectedDecision.value = value;
          $scope.selectedDecision.description = description;
          $scope.judgesToPanel.rulingCategory;
          angular.forEach($scope.judgesToPanel, function (judgeList) {
            judgeList.rulingCategory = value;
            $scope.selectedDecisionApj.description = "Per Curiam";
          });
        }
        $scope.disciplineChanged = true;
        $scope.setJudgelistObject(description,id+1);
      };

      // $scope.setSelectedPA = function (value, description) {
      //   $scope.selectedDecisionPA.value = value;
      //   $scope.selectedDecisionPA.description = description;
      //   if (value === 'PERCURIAM' || value === 'per curiam' || value === 'Per Curiam') {
      //     $scope.selectedDecision.value = value;
      //     $scope.selectedDecision.description = description;
      //     $scope.judgesToPanel.rulingCategory;
      //     angular.forEach($scope.judgesToPanel, function (judgeList) {
      //       judgeList.rulingCategory = value;
      //       $scope.selectedDecisionApj.description = "Per Curiam";
      //     });
      //   }
      //   $scope.judgesToPanel[$scope.judgesToPanel.length - 1].rulingCategory = value;
      //   $scope.disciplineChanged = true;
      //   $scope.setJudgelistObject(description,2);
      // };


      $scope.setJudgelistObject = function(description,index){        
        if (description == 'Per Curiam') {
          $scope.selectedDecisionPanelList = [];
            for(var i=0;i<$scope.apjList.length;i++){
              $scope.setObject(i,description);
            }
        }
        else if($scope.selectedDecisionPanelList.length > 0 && $scope.selectedDecisionPanelList[index]){
          $scope.selectedDecisionPanelList[index].rulingCategory = description;
        }
        else {
          $scope.setObject(index,description);
        }
      }

      $scope.setObject = function(index,description){ 
        var obj = {
          "identifier":$scope.apjList[index].identifier,
          "panelName":$scope.apjList[index].panelName,
          "lastModifiedTs":$scope.apjList[index].lastModifiedTs,
          "panelSequenceNumber":$scope.apjList[index].panelSequenceNumber,
          "panelRank":$scope.apjList[index].panelRank,
          "assigneeStatus":$scope.apjList[index].assigneeStatus,
          "apjStatus":$scope.apjList[index].apjStatus,
          "panelMember":$scope.apjList[index].panelMember,
          "rulingCategory":description
          }
          $scope.selectedDecisionPanelList.push(obj);
      }

      $scope.getSelectedJudgeList();
      $scope.getApjPanel();

    });
})();
