(function () {
  'use strict';

  describe('CaseViewerController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var controller, scope, $rootScope, route;
    var successResponse, timeout, $window;
    var $httpBackend, spy, $q, HttpFactoryDeferred;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['open']);
    var number, clickedTab, num, selectedChevron, ststs, expandState, recievedDate, currentTab, tab, userInfo;
    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              getWidgetZone: function () {

              },
              setWidgetContentHeight: function () {

              }
            }
          }
        }
      }
    };

        var paper = '';
    var exhibit = '';
    var allCombinePapers = {
      data: {}
    };
    var boardCombine = {
      data: {}
    };
    var petitionerCombine = {
      data: {}
    };
    var patentOwnerBagCombine = {
      data: {}
    };
    var AiaExhibitsCombineAll = {
      data: {}
    }
    var AiaExhibitsCombinethousands = {
      data: {}
    }
    var AiaExhibitsCombinetwoThousands = {
      data: {}
    }
    var AiaExhibitsCombinethreeThousands = {
      data: {}
    }
    var workerNumber = {
      value: "pgandhi"
    }

    var workerNumber = {
      value: "pgandhi"
    }

    beforeEach(inject(function (_$controller_, _$rootScope_, _$httpBackend_, _$timeout_, $route, _$q_, HttpFactory, $window) {
      $q = _$q_;
      scope = _$rootScope_.$new();
      $controller = _$controller_;
      $rootScope = _$rootScope_;
      $httpBackend = _$httpBackend_;
      timeout = _$timeout_;
      route = $route;

      ngDialog.open.and.returnValue({
        then: function (callback1, callback2) {
          callback1();
          callback2();
        },
        closePromise: {
          then: function (callback3, callback4) {
            callback3();
            callback4();
          }
        }
      });

      $route.current = {
        params: {
          applicationNumber: '10651537',
          caseNumber: '2018005604'
        }
      };

      $window.opener = {
        userInfo: {
          "userId": "pgandhi"
        }
      }

      userInfo = {
        "userId": "sbartlett",
        "displayName": "Bartlett, Steven J",
        "appUserInfo": [{
          "userIdentiifier": 5850,
          "activeIn": "Active",
          "lastName": "Bartlett",
          "privileges": ["ImportManager_PostDecisionCaseManager Privileges", "panel_Update", "Paneling"],
          "loginId": "sbartlett",
          "fullName": "Bartlett, Steven J",
          "disiplanceCd": "Admin",
          "jobClassificationCode": "ADM",
          "firstName": "Steven",
          "emailAddress": "Jacqueline.Bui@USPTO.GOV",
          "userWorkerNumber": "83707",
          "roleDescription": "Business Administrator",
          "apjSeniorityRank": 0
        }]
      }

      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      controller = $controller('CaseViewerController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory,
        $route: route,
        $window: $window
      });
    }));

    describe('CaseViewerController ', function () {
              it(' should call allPapersCombine', function () {
        // paper = 0;
        allCombinePapers = {
          data: {}
        };
        expect(controller.allPapersCombine).toBeDefined();
        controller.allPapersCombine();
      });
      it(' should call boardPapersCombine', function () {
        boardCombine = {
          data: {}
        };
        expect(controller.boardPapersCombine).toBeDefined();
        controller.boardPapersCombine();
      });

      it(' should call petitionerPapersCombine', function () {
        petitionerCombine = {
          data: {}
        };
        expect(controller.petitionerPapersCombine).toBeDefined();
        controller.petitionerPapersCombine();
      });

      it(' should call patentOwnerCombine', function () {
        patentOwnerBagCombine = {
          data: {}
        };
        expect(controller.patentOwnerCombine).toBeDefined();
        controller.patentOwnerCombine();
      });


      it(' should call allExhibitsCombine', function () {
        AiaExhibitsCombineAll = {
          data: {}
        };
        expect(controller.allExhibitsCombine).toBeDefined();
        controller.allExhibitsCombine();
      });
      it(' should call thousandsExhibitsCombine', function () {
        AiaExhibitsCombinethousands = {
          data: {}
        };
        expect(controller.thousandsExhibitsCombine).toBeDefined();
        controller.thousandsExhibitsCombine();
      });

      it(' should call twothousandsExhibitsCombine', function () {
        AiaExhibitsCombinethousands = {
          data: {}
        };
        expect(controller.twothousandsExhibitsCombine).toBeDefined();
        controller.thousandsExhibitsCombine();
      });
      it(' should call threethousandsExhibitsCombine', function () {
        AiaExhibitsCombinethreeThousands = {
          data: {}
        };
        expect(controller.threethousandsExhibitsCombine).toBeDefined();
        controller.threethousandsExhibitsCombine();
      });

      it(' should call twothousandsExhibitsCombine ', function () {
        AiaExhibitsCombinetwoThousands = {
          data: {}
        };
        expect(controller.twothousandsExhibitsCombine ).toBeDefined();
        controller.twothousandsExhibitsCombine ();
      });

    //   it(' should call constructAllPapersDownload ', function () {
    //     var allPapersCount  = 0;
    //     expect(controller.constructAllPapersDownload).toBeDefined();
    //     controller.constructAllPapersDownload();
    //   });

    //   it(' should call constructAllPapersDownload ', function () {
    //     allPapersCount  = 2;
    //     expect(controller.constructAllPapersDownload).toBeDefined();
    //     controller.constructAllPapersDownload();
    //   });
      //TODO - fix test case
      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        number = 1;
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, "null");
      });

      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        number = 2;
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
      });

      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        number = 3;
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
      });

      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        number = 4;
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
      });

      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        scope.status5 = {
          open: true
        }
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
      });

      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        clickedTab = 'appealTab';
        scope.status5 = {
          open: false
        }
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
        // timeout.flush();
      });

      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        scope.status6 = {
          open: true
        }
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
      });

      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        clickedTab = 'pendingDocketingTab';
        scope.status6 = {
          open: false
        }
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
        // timeout.flush();
      });

      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        scope.status7 = {
          open: true
        }
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
      });

      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        clickedTab = 'pendingPanelingTab';
        scope.status7 = {
          open: false
        }
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
        // timeout.flush();
      });

      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        scope.status8 = {
          open: true
        }
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
      });

      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        clickedTab = 'pendingDecisionTab';
        scope.status8 = {
          open: false
        }
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
        // timeout.flush();
      });

      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        scope.status8 = {
          open: true
        }
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
        // timeout.flush();
      });

      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        clickedTab = 'closedTab';
        scope.status10 = {
          open: false
        }
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
        // timeout.flush();
      });

      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        clickedTab = 'null';
        scope.expandedValue = 0;
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
      });

      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        clickedTab = 'null';
        scope.expandedValue = 1;
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
      });


      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        clickedTab = 'null';
        scope.expandedValue = 2;
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
      });


      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        clickedTab = 'null';
        scope.expandedValue = 3;
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
      });

      it('it should call setExpanded ', function () {
        controller.loadCaseViewer(userInfo);
        clickedTab = 'null';
        scope.expandedValue = 4;
        expect(scope.setExpanded).toBeDefined();
        scope.setExpanded(number, clickedTab);
      });

      it('it should call actionFromChevron ', function () {
        controller.loadCaseViewer(userInfo);
        num = 4;
        selectedChevron = 'pendingDecisionTab';
        expect(controller.actionFromChevron).toBeDefined();
        controller.actionFromChevron(num, selectedChevron);
      });

      it('it should call refreshactionchev  ', function () {
        controller.loadCaseViewer(userInfo);
        ststs = 'pendingDecisionTab';
        expect(controller.refreshactionchev).toBeDefined();
        controller.refreshactionchev(ststs);
      });

      it('it should call changeState  ', function () {
        controller.loadCaseViewer(userInfo);
        expandState = 'pendingDecisionTab';
        scope.currentTab = 'bib';
        expect(controller.changeState).toBeDefined();
        controller.changeState(expandState);
      });

      it('it should call changeState  ', function () {
        controller.loadCaseViewer(userInfo);
        expandState = 'pendingDecisionTab';
        scope.currentTab = 'appeal';
        expect(controller.changeState).toBeDefined();
        controller.changeState(expandState);
      });

      it('it should call changeState  ', function () {
        controller.loadCaseViewer(userInfo);
        expandState = 'pendingDecisionTab';
        scope.currentTab = 'caseHistory';
        expect(controller.changeState).toBeDefined();
        controller.changeState(expandState);
      });

      it('it should call changeState  ', function () {
        controller.loadCaseViewer(userInfo);
        expandState = 'pendingDecisionTab';
        scope.currentTab = 'auditTrail';
        expect(controller.changeState).toBeDefined();
        controller.changeState(expandState);
      });

      // it('it should call getBibliographic', function () {

      //   controller.bibliographic = {
      //     descriptiveInfo: {
      //       appealNumberText: "2019000359",
      //       appealType: "On brief",
      //       caseDiscipline: "Electrical",
      //       inventors: [{
      //           lifeCycle: {
      //             beginDate: 1238793791
      //           },
      //           audit: {
      //             lastModifiedUser: "ttu",
      //             lastModifiedTime: 1239882096
      //           },
      //           interestedParty: {
      //             status: "F",
      //             referenceType: "AP",
      //             sequenceNumber: 1,
      //             authorityType: "INV",
      //             partyIdentifier: "42116212",
      //             interestedPartyType: "IND"
      //           },
      //           persons: {
      //             firstName: "Jianwen",
      //             lastName: "Yin",
      //             identifier: "42116212",
      //             citizenship: "CN",
      //             address: {
      //               physicalAddress: [{
      //                   nameLineOneText: "Jianwen  Yin",
      //                   addressLineOneText: "8335 Lofty Lane",
      //                   cityName: "Round Rock",
      //                   geographicRegionCode: "TX",
      //                   geographicRegionName: "TEXAS",
      //                   countryCode: "US",
      //                   countryName: "UNITED STATES",
      //                   postalCode: "78681",
      //                   addressCategory: "postal"
      //                 },
      //                 {
      //                   nameLineOneText: "Jianwen  Yin",
      //                   cityName: "Round Rock",
      //                   geographicRegionCode: "TX",
      //                   geographicRegionName: "TEXAS",
      //                   countryCode: "US",
      //                   countryName: "UNITED STATES",
      //                   addressCategory: "residence"
      //                 }
      //               ],
      //               telecommunication: [],
      //               emails: []
      //             }
      //           }
      //         },
      //         {
      //           lifeCycle: {
      //             beginDate: 1239882184
      //           },
      //           audit: {
      //             lastModifiedUser: "ttu",
      //             lastModifiedTime: 1239882184
      //           },
      //           interestedParty: {
      //             status: "F",
      //             referenceType: "AP",
      //             sequenceNumber: 2,
      //             authorityType: "INV",
      //             partyIdentifier: "42178801",
      //             interestedPartyType: "IND"
      //           },
      //           persons: {
      //             firstName: "Yong",
      //             lastName: "Cao",
      //             identifier: "42178801",
      //             citizenship: "CN",
      //             address: {
      //               physicalAddress: [{
      //                 nameLineOneText: "Yong  Cao",
      //                 cityName: "Cedar Park",
      //                 geographicRegionCode: "TX",
      //                 geographicRegionName: "TEXAS",
      //                 countryCode: "US",
      //                 countryName: "UNITED STATES",
      //                 addressCategory: "residence"
      //               }],
      //               telecommunication: [],
      //               emails: []
      //             }
      //           }
      //         },
      //         {
      //           lifeCycle: {
      //             beginDate: 1239882241
      //           },
      //           audit: {
      //             lastModifiedUser: "ttu",
      //             lastModifiedTime: 1239882241
      //           },
      //           interestedParty: {
      //             status: "F",
      //             referenceType: "AP",
      //             sequenceNumber: 3,
      //             authorityType: "INV",
      //             partyIdentifier: "42178812",
      //             interestedPartyType: "IND"
      //           },
      //           persons: {
      //             firstName: "Xianghong",
      //             lastName: "Qian",
      //             identifier: "42178812",
      //             citizenship: "US",
      //             address: {
      //               physicalAddress: [{
      //                 nameLineOneText: "Xianghong  Qian",
      //                 cityName: "Austin",
      //                 geographicRegionCode: "TX",
      //                 geographicRegionName: "TEXAS",
      //                 countryCode: "US",
      //                 countryName: "UNITED STATES",
      //                 addressCategory: "residence"
      //               }],
      //               telecommunication: [],
      //               emails: []
      //             }
      //           }
      //         }
      //       ],
      //       applicationType: "REGULAR",
      //       artClassNumber: "718",
      //       artSubClassNumber: "100000",
      //       cpcCodeFirst: null,
      //       techCenterNumber: "2100",
      //       artUnit: "2182",
      //       specialType: null,
      //       ptabReceivedDate: 1541168298000,
      //       worker: {
      //         workerNumber: "82856",
      //         activeIndicator: false,
      //         fullName: "GIROUX, GEORGE "
      //       },
      //       realPartiesDetails: [],
      //       appellantsDetails: [
      //         "Yin, Jianwen  et al."
      //       ]
      //     },
      //     parentInfo: {
      //       applicationNumberText: null,
      //       artClassNumber: null,
      //       artSubClassNumber: null,
      //       techCenterNumber: null,
      //       artUnit: null,
      //       inventors: null,
      //       inventionTitleText: null
      //     },
      //     corrAddress: {
      //       customerNumberText: "33438",
      //       nameLineOneText: "TERRILE, CANNATTI & CHAMBERS, LLP",
      //       nameLineTwoText: "",
      //       streetAddressLineOneText: "P.O. BOX 203518",
      //       streetAddressLineTwoText: "",
      //       cityName: "AUSTIN",
      //       geographicRegionName: "TX",
      //       postalCode: "78720"
      //     },
      //     thirdPartyInfo: {
      //       customerNumber: "33438",
      //       nameLineOneText: null,
      //       nameLineTwoText: null,
      //       addressLineOneText: null,
      //       addressLineTwoText: null,
      //       cityName: null,
      //       geographicRegionCode: null,
      //       geographicRegionName: null,
      //       postalCode: null,
      //       worker: {
      //         workerNumber: "32946",
      //         activeIndicator: false,
      //         fullName: "TERRILE, STEPHEN"
      //       }
      //     }
      //   }
      //   successResponse = {
      //     data: {
      //       descriptiveInfo: {
      //         appealNumberText: "2019000359",
      //         appealType: "On brief",
      //         caseDiscipline: "Electrical",
      //         inventors: [{
      //             lifeCycle: {
      //               beginDate: 1238793791
      //             },
      //             audit: {
      //               lastModifiedUser: "ttu",
      //               lastModifiedTime: 1239882096
      //             },
      //             interestedParty: {
      //               status: "F",
      //               referenceType: "AP",
      //               sequenceNumber: 1,
      //               authorityType: "INV",
      //               partyIdentifier: "42116212",
      //               interestedPartyType: "IND"
      //             },
      //             persons: {
      //               firstName: "Jianwen",
      //               lastName: "Yin",
      //               identifier: "42116212",
      //               citizenship: "CN",
      //               address: {
      //                 physicalAddress: [{
      //                     nameLineOneText: "Jianwen  Yin",
      //                     addressLineOneText: "8335 Lofty Lane",
      //                     cityName: "Round Rock",
      //                     geographicRegionCode: "TX",
      //                     geographicRegionName: "TEXAS",
      //                     countryCode: "US",
      //                     countryName: "UNITED STATES",
      //                     postalCode: "78681",
      //                     addressCategory: "postal"
      //                   },
      //                   {
      //                     nameLineOneText: "Jianwen  Yin",
      //                     cityName: "Round Rock",
      //                     geographicRegionCode: "TX",
      //                     geographicRegionName: "TEXAS",
      //                     countryCode: "US",
      //                     countryName: "UNITED STATES",
      //                     addressCategory: "residence"
      //                   }
      //                 ],
      //                 telecommunication: [],
      //                 emails: []
      //               }
      //             }
      //           },
      //           {
      //             lifeCycle: {
      //               beginDate: 1239882184
      //             },
      //             audit: {
      //               lastModifiedUser: "ttu",
      //               lastModifiedTime: 1239882184
      //             },
      //             interestedParty: {
      //               status: "F",
      //               referenceType: "AP",
      //               sequenceNumber: 2,
      //               authorityType: "INV",
      //               partyIdentifier: "42178801",
      //               interestedPartyType: "IND"
      //             },
      //             persons: {
      //               firstName: "Yong",
      //               lastName: "Cao",
      //               identifier: "42178801",
      //               citizenship: "CN",
      //               address: {
      //                 physicalAddress: [{
      //                   nameLineOneText: "Yong  Cao",
      //                   cityName: "Cedar Park",
      //                   geographicRegionCode: "TX",
      //                   geographicRegionName: "TEXAS",
      //                   countryCode: "US",
      //                   countryName: "UNITED STATES",
      //                   addressCategory: "residence"
      //                 }],
      //                 telecommunication: [],
      //                 emails: []
      //               }
      //             }
      //           },
      //           {
      //             lifeCycle: {
      //               beginDate: 1239882241
      //             },
      //             audit: {
      //               lastModifiedUser: "ttu",
      //               lastModifiedTime: 1239882241
      //             },
      //             interestedParty: {
      //               status: "F",
      //               referenceType: "AP",
      //               sequenceNumber: 3,
      //               authorityType: "INV",
      //               partyIdentifier: "42178812",
      //               interestedPartyType: "IND"
      //             },
      //             persons: {
      //               firstName: "Xianghong",
      //               lastName: "Qian",
      //               identifier: "42178812",
      //               citizenship: "US",
      //               address: {
      //                 physicalAddress: [{
      //                   nameLineOneText: "Xianghong  Qian",
      //                   cityName: "Austin",
      //                   geographicRegionCode: "TX",
      //                   geographicRegionName: "TEXAS",
      //                   countryCode: "US",
      //                   countryName: "UNITED STATES",
      //                   addressCategory: "residence"
      //                 }],
      //                 telecommunication: [],
      //                 emails: []
      //               }
      //             }
      //           }
      //         ],
      //         applicationType: "REGULAR",
      //         artClassNumber: "718",
      //         artSubClassNumber: "100000",
      //         cpcCodeFirst: null,
      //         techCenterNumber: "2100",
      //         artUnit: "2182",
      //         specialType: null,
      //         ptabReceivedDate: 1541168298000,
      //         worker: {
      //           workerNumber: "82856",
      //           activeIndicator: false,
      //           fullName: "GIROUX, GEORGE "
      //         },
      //         realPartiesDetails: [],
      //         appellantsDetails: [
      //           "Yin, Jianwen  et al."
      //         ]
      //       },
      //       parentInfo: {
      //         applicationNumberText: null,
      //         artClassNumber: null,
      //         artSubClassNumber: null,
      //         techCenterNumber: null,
      //         artUnit: null,
      //         inventors: null,
      //         inventionTitleText: null
      //       },
      //       corrAddress: {
      //         customerNumberText: "33438",
      //         nameLineOneText: "TERRILE, CANNATTI & CHAMBERS, LLP",
      //         nameLineTwoText: "",
      //         streetAddressLineOneText: "P.O. BOX 203518",
      //         streetAddressLineTwoText: "",
      //         cityName: "AUSTIN",
      //         geographicRegionName: "TX",
      //         postalCode: "78720"
      //       },
      //       thirdPartyInfo: {
      //         customerNumber: "33438",
      //         nameLineOneText: null,
      //         nameLineTwoText: null,
      //         addressLineOneText: null,
      //         addressLineTwoText: null,
      //         cityName: null,
      //         geographicRegionCode: null,
      //         geographicRegionName: null,
      //         postalCode: null,
      //         worker: {
      //           workerNumber: "32946",
      //           activeIndicator: false,
      //           fullName: "TERRILE, STEPHEN"
      //         }
      //       }
      //     }


      //   };

      //   controller.lengthOfChevron.length = 2;

      //   controller.loadCaseViewer(userInfo);
      //   expect(controller.getBibliographic).toBeDefined();
      //   controller.getBibliographic();

      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();

      // });

      // //   //toaster error
      // //   // it('getBibliographic failureResponse ', function () {

      // //   //   var failureResponse = {
      // //   //     data: {}
      // //   //   };

      // //   //   expect(controller.getBibliographic).toBeDefined();
      // //   //   controller.getBibliographic();

      // //   //   HttpFactoryDeferred.reject(failureResponse);
      // //   //   $rootScope.$apply();
      // //   // });

      // it('it should call getCasePhase', function () {

      //   successResponse = {
      //     data: {
      //       serialNumber: "15009603",
      //       sequenceNumber: null,
      //       appealNumber: "2019000465",
      //       lifeCycle: null,
      //       audit: null,
      //       preAppealInfo: {
      //         ptabReceivedDate: 1541962533000,
      //         appealNumberText: 2019000465,
      //         preAppealReviewAssigneeName: "Gandhi, Parin",
      //         appealAssignedDate: 1541962533000,
      //         applicationFilingDate: 1453957200000
      //       },
      //       masterDocketInfo: {
      //         appealNumber: 2019000465,
      //         docketingNoticeMailedUserName: null,
      //         docketingNoticeDate: null,
      //         ewfCompletionDate: null,
      //         ewfCreatedUserName: null,
      //         masterDocketDate: null,
      //         masterDocketDiscipline: "Electrical",
      //         caseType: "B"
      //       },
      //       hearingInfo: {
      //         appealNumber: null,
      //         appealPanelJudgeOne: null,
      //         appealPanelJudgeTwo: null,
      //         appealPanelJudgeThree: null,
      //         panelDate: null,
      //         hearingNoticeDate: null,
      //         hearingNoticeMailedUserName: null,
      //         hearingDate: null,
      //         caseType: "B",
      //         heard: null
      //       },
      //       panellingInfo: {
      //         appealPanelJudgeOne: null,
      //         appealPanelJudgeTwo: null,
      //         appealPanelJudgeThree: null,
      //         panelDate: null,
      //         caseType: "B",
      //         heard: null
      //       },
      //       decisionInfo: {
      //         draftDecisionReviewCompletionDate: null,
      //         panelCirculationCompletionDate: null,
      //         decisionOutcome: null,
      //         decisionMailedUserName: null,
      //         decisionMailDate: null,
      //         draftReviewDecisionCompleted: false
      //       },
      //       caseClosedInfo: {
      //         caseClosedDate: null
      //       },
      //       casetransactionDetails: [{
      //           draftDecisionReviewCompletionDate: null,
      //           panelCirculationCompletionDate: null,
      //           decisionOutcome: null,
      //           decisionMailedUserName: null,
      //           decisionMailDate: null,
      //           draftReviewDecisionCompleted: false,
      //           statusCode: 124
      //         },
      //         {
      //           draftDecisionReviewCompletionDate: null,
      //           panelCirculationCompletionDate: null,
      //           decisionOutcome: null,
      //           decisionMailedUserName: null,
      //           decisionMailDate: null,
      //           draftReviewDecisionCompleted: false,
      //           statusCode: 124
      //         }
      //       ]
      //     }


      //   };

      //   controller.loadCaseViewer(userInfo);
      //   expect(controller.getCasePhase).toBeDefined();
      //   controller.getCasePhase();

      //   HttpFactoryDeferred.resolve(successResponse);
      //   $rootScope.$apply();

      // });

      // //   //toaster error
      // //   // it('getCasePhase failureResponse ', function () {

      // //   //   var failureResponse = {
      // //   //     data: {}
      // //   //   };

      // //   //   expect(controller.getCasePhase).toBeDefined();
      // //   //   controller.getCasePhase();

      // //   //   HttpFactoryDeferred.reject(failureResponse);
      // //   //   $rootScope.$apply();
      // //   // });

      // //   it('it should call getCaseMilestones', function () {

      // //     successResponse = {
      // //       data: {
      // //         descriptiveInfo: {
      // //           appealNumberText: "2019000359",
      // //           appealType: "On brief",
      // //           caseDiscipline: "Electrical",
      // //           inventors: [{
      // //               lifeCycle: {
      // //                 beginDate: 1238793791
      // //               },
      // //               audit: {
      // //                 lastModifiedUser: "ttu",
      // //                 lastModifiedTime: 1239882096,
      // //               },
      // //               interestedParty: {
      // //                 status: "F",
      // //                 referenceType: "AP",
      // //                 sequenceNumber: 1,
      // //                 authorityType: "INV",
      // //                 partyIdentifier: "42116212",
      // //                 interestedPartyType: "IND",
      // //               },
      // //               persons: {
      // //                 firstName: "Jianwen",
      // //                 lastName: "Yin",
      // //                 identifier: "42116212",
      // //                 citizenship: "CN",
      // //                 address: {
      // //                   physicalAddress: [{
      // //                       nameLineOneText: "Jianwen  Yin",
      // //                       addressLineOneText: "8335 Lofty Lane",
      // //                       cityName: "Round Rock",
      // //                       geographicRegionCode: "TX",
      // //                       geographicRegionName: "TEXAS",
      // //                       countryCode: "US",
      // //                       countryName: "UNITED STATES",
      // //                       postalCode: "78681",
      // //                       addressCategory: "postal",
      // //                     },
      // //                     {
      // //                       nameLineOneText: "Jianwen  Yin",
      // //                       cityName: "Round Rock",
      // //                       geographicRegionCode: "TX",
      // //                       geographicRegionName: "TEXAS",
      // //                       countryCode: "US",
      // //                       countryName: "UNITED STATES",
      // //                       addressCategory: "residence",
      // //                     },
      // //                   ],
      // //                   telecommunication: [],
      // //                   emails: [],
      // //                 },
      // //               },
      // //             },
      // //             {
      // //               lifeCycle: {
      // //                 beginDate: 1239882184
      // //               },
      // //               audit: {
      // //                 lastModifiedUser: "ttu",
      // //                 lastModifiedTime: 1239882184,
      // //               },
      // //               interestedParty: {
      // //                 status: "F",
      // //                 referenceType: "AP",
      // //                 sequenceNumber: 2,
      // //                 authorityType: "INV",
      // //                 partyIdentifier: "42178801",
      // //                 interestedPartyType: "IND",
      // //               },
      // //               persons: {
      // //                 firstName: "Yong",
      // //                 lastName: "Cao",
      // //                 identifier: "42178801",
      // //                 citizenship: "CN",
      // //                 address: {
      // //                   physicalAddress: [{
      // //                     nameLineOneText: "Yong  Cao",
      // //                     cityName: "Cedar Park",
      // //                     geographicRegionCode: "TX",
      // //                     geographicRegionName: "TEXAS",
      // //                     countryCode: "US",
      // //                     countryName: "UNITED STATES",
      // //                     addressCategory: "residence",
      // //                   }],
      // //                   telecommunication: [],
      // //                   emails: [],
      // //                 },
      // //               },
      // //             },
      // //             {
      // //               lifeCycle: {
      // //                 beginDate: 1239882241
      // //               },
      // //               audit: {
      // //                 lastModifiedUser: "ttu",
      // //                 lastModifiedTime: 1239882241,
      // //               },
      // //               interestedParty: {
      // //                 status: "F",
      // //                 referenceType: "AP",
      // //                 sequenceNumber: 3,
      // //                 authorityType: "INV",
      // //                 partyIdentifier: "42178812",
      // //                 interestedPartyType: "IND",
      // //               },
      // //               persons: {
      // //                 firstName: "Xianghong",
      // //                 lastName: "Qian",
      // //                 identifier: "42178812",
      // //                 citizenship: "US",
      // //                 address: {
      // //                   physicalAddress: [{
      // //                     nameLineOneText: "Xianghong  Qian",
      // //                     cityName: "Austin",
      // //                     geographicRegionCode: "TX",
      // //                     geographicRegionName: "TEXAS",
      // //                     countryCode: "US",
      // //                     countryName: "UNITED STATES",
      // //                     addressCategory: "residence",
      // //                   }],
      // //                   telecommunication: [],
      // //                   emails: [],
      // //                 },
      // //               },
      // //             },
      // //           ],
      // //           applicationType: "REGULAR",
      // //           artClassNumber: "718",
      // //           artSubClassNumber: "100000",
      // //           cpcCodeFirst: null,
      // //           techCenterNumber: "2100",
      // //           artUnit: "2182",
      // //           specialType: null,
      // //           ptabReceivedDate: 1541168298000,
      // //           worker: {
      // //             workerNumber: "82856",
      // //             activeIndicator: false,
      // //             fullName: "GIROUX, GEORGE ",
      // //           },
      // //           realPartiesDetails: [],
      // //           appellantsDetails: [
      // //             "Yin, Jianwen  et al."
      // //           ],
      // //         },
      // //         parentInfo: {
      // //           applicationNumberText: null,
      // //           artClassNumber: null,
      // //           artSubClassNumber: null,
      // //           techCenterNumber: null,
      // //           artUnit: null,
      // //           inventors: null,
      // //           inventionTitleText: null,
      // //         },
      // //         corrAddress: {
      // //           customerNumberText: "33438",
      // //           nameLineOneText: "TERRILE, CANNATTI & CHAMBERS, LLP",
      // //           nameLineTwoText: "",
      // //           streetAddressLineOneText: "P.O. BOX 203518",
      // //           streetAddressLineTwoText: "",
      // //           cityName: "AUSTIN",
      // //           geographicRegionName: "TX",
      // //           postalCode: "78720",
      // //         },
      // //         thirdPartyInfo: {
      // //           customerNumber: "33438",
      // //           nameLineOneText: null,
      // //           nameLineTwoText: null,
      // //           addressLineOneText: null,
      // //           addressLineTwoText: null,
      // //           cityName: null,
      // //           geographicRegionCode: null,
      // //           geographicRegionName: null,
      // //           postalCode: null,
      // //           worker: {
      // //             workerNumber: "32946",
      // //             activeIndicator: false,
      // //             fullName: "TERRILE, STEPHEN",
      // //           },
      // //         },
      // //       }
      // //     };

      // //     expect(controller.getCaseMilestones).toBeDefined();
      // //     controller.getCaseMilestones();

      // //     HttpFactoryDeferred.resolve(successResponse);
      // //     $rootScope.$apply();

      // //   });

      // //   //toaster error
      // //   // it('getCaseMilestones failureResponse ', function () {

      // //   //   var failureResponse = {
      // //   //     data: {}
      // //   //   };

      // //   //   expect(controller.getCaseMilestones).toBeDefined();
      // //   //   controller.getCaseMilestones();

      // //   //   HttpFactoryDeferred.reject(failureResponse);
      // //   //   $rootScope.$apply();
      // //   // });


      // //   it('it should call getStatusHistory', function () {

      // //     successResponse = {
      // //       data: {
      // //         columDetails: null,
      // //         caseDetailsData: [{
      // //             sequenceNumber: 1,
      // //             date: 1541168454000,
      // //             typeCode: "APAS",
      // //             appealNumber: 2019000359,
      // //             creditGrantedUserIdentifier: "pgandhi",
      // //             lastModifiedUserIdentifier: "pgandhi",
      // //             lastModifiedTimeStamp: 1541174623000,
      // //             description: "Assignment of Appeal Number",
      // //           },
      // //           {
      // //             sequenceNumber: 3,
      // //             date: 1541174645000,
      // //             typeCode: "APREP",
      // //             appealNumber: 2019000359,
      // //             creditGrantedUserIdentifier: "pgandhi",
      // //             lastModifiedUserIdentifier: "pgandhi",
      // //             lastModifiedTimeStamp: 1541174727000,
      // //             description: "Assigned to Paralegal/Legal Technician for prepping",
      // //           },
      // //           {
      // //             sequenceNumber: 4,
      // //             date: 1541174727000,
      // //             typeCode: "PREP",
      // //             appealNumber: 2019000359,
      // //             creditGrantedUserIdentifier: "pgandhi",
      // //             lastModifiedUserIdentifier: "pgandhi",
      // //             lastModifiedTimeStamp: 1541174727000,
      // //             description: "Prepping - Awaiting Panel Assignment (Selected by Prepper)",
      // //           },
      // //           {
      // //             sequenceNumber: 2,
      // //             date: 1541174623000,
      // //             typeCode: "DNMA",
      // //             appealNumber: 2019000359,
      // //             creditGrantedUserIdentifier: "pgandhi",
      // //             lastModifiedUserIdentifier: "pgandhi",
      // //             lastModifiedTimeStamp: 1541174645000,
      // //             description: "Docket Notice Mailed to Appellant",
      // //           },
      // //         ],
      // //       }
      // //     };

      // //     expect(controller.getStatusHistory).toBeDefined();
      // //     controller.getStatusHistory();

      // //     HttpFactoryDeferred.resolve(successResponse);
      // //     $rootScope.$apply();

      // //   });

      // //   //toaster error
      // //   // it('getStatusHistory failureResponse ', function () {

      // //   //   var failureResponse = {
      // //   //     data: {}
      // //   //   };

      // //   //   expect(controller.getStatusHistory).toBeDefined();
      // //   //   controller.getStatusHistory();

      // //   //   HttpFactoryDeferred.reject(failureResponse);
      // //   //   $rootScope.$apply();
      // //   // });

      // //   it('it should call getAssignHistory', function () {

      // //     successResponse = {
      // //       data: {
      // //         columDetails: null,
      // //         caseDetailsData: [{
      // //             serialNumber: "12418336",
      // //             sequenceNumber: null,
      // //             appealNumber: null,
      // //             lifeCycle: null,
      // //             audit: {
      // //               lastModifiedTimestamp: 1541168453000,
      // //               lastModifiedUserIdentifier: null,
      // //               createUserIdentifier: "pgandhi",
      // //               createdUserName: null,
      // //               lastModifiedUserName: null,
      // //               createTimestamp: null,
      // //               lockControlNumber: 1,
      // //             },
      // //             assignmentIdentifier: 1405,
      // //             assignmentType: "52",
      // //             assignmentTypeIdentifier: null,
      // //             assignee: "Gandhi, Parin ",
      // //             assignor: "Gandhi, Parin ",
      // //             caseType: null,
      // //             priorityIndicator: null,
      // //             activeIndicator: null,
      // //             title: "Review Checklist Assignment To POC1 for 0",
      // //             description: "Review Checklist Assignment To POC1 for 0",
      // //             notes: null,
      // //             assignedDate: 1541168298000,
      // //             dueDate: null,
      // //             completionDate: 1541168453000,
      // //             palmMailedDate: null,
      // //             standardAssignmentType: null,
      // //             completedUserName: null,
      // //             lastModifiedUserName: null,
      // //             noOfActiveCases: 0,
      // //             assignmentStatusCode: "Completed",
      // //             assigneeRoleCode: null,
      // //             assigneeRoleDescription: null,
      // //             assignmentSequence: null,
      // //             reconsiderSequence: null,
      // //             pendingLocationText: null,
      // //             assignmentTypeDescription: null,
      // //             completionCode: null,
      // //             message: null,
      // //             globalMetaData: null,
      // //           },
      // //           {
      // //             serialNumber: "12418336",
      // //             sequenceNumber: null,
      // //             appealNumber: null,
      // //             lifeCycle: null,
      // //             audit: {
      // //               lastModifiedTimestamp: 1541174622000,
      // //               lastModifiedUserIdentifier: null,
      // //               createUserIdentifier: "pgandhi",
      // //               createdUserName: null,
      // //               lastModifiedUserName: null,
      // //               createTimestamp: null,
      // //               lockControlNumber: 1,
      // //             },
      // //             assignmentIdentifier: 1406,
      // //             assignmentType: "4",
      // //             assignmentTypeIdentifier: null,
      // //             assignee: "Gandhi, Parin ",
      // //             assignor: "Gandhi, Parin ",
      // //             caseType: null,
      // //             priorityIndicator: null,
      // //             activeIndicator: null,
      // //             title: "Review Checklist Assignment To POC1 for 0",
      // //             description: "Review Checklist Assignment To POC1 for 0",
      // //             notes: null,
      // //             assignedDate: 1541168454000,
      // //             dueDate: 1541168436000,
      // //             completionDate: 1541174622000,
      // //             palmMailedDate: null,
      // //             standardAssignmentType: null,
      // //             completedUserName: null,
      // //             lastModifiedUserName: null,
      // //             noOfActiveCases: 0,
      // //             assignmentStatusCode: "Completed",
      // //             assigneeRoleCode: null,
      // //             assigneeRoleDescription: null,
      // //             assignmentSequence: null,
      // //             reconsiderSequence: null,
      // //             pendingLocationText: null,
      // //             assignmentTypeDescription: null,
      // //             completionCode: null,
      // //             message: null,
      // //             globalMetaData: null,
      // //           },
      // //         ],
      // //       }
      // //     };

      // //     expect(controller.getAssignHistory).toBeDefined();
      // //     controller.getAssignHistory();

      // //     HttpFactoryDeferred.resolve(successResponse);
      // //     $rootScope.$apply();

      // //   });

      // //   //toaster error
      // //   // it('getAssignHistory failureResponse ', function () {

      // //   //   var failureResponse = {
      // //   //     data: {}
      // //   //   };

      // //   //   expect(controller.getAssignHistory).toBeDefined();
      // //   //   controller.getAssignHistory();

      // //   //   HttpFactoryDeferred.reject(failureResponse);
      // //   //   $rootScope.$apply();
      // //   // });


      // //   it('it should call dateConvert ', function () {
      // //     recievedDate = '07/25/2018';
      // //     expect(controller.dateConvert).toBeDefined();
      // //     controller.dateConvert(recievedDate);
      // //   });

      it('it should call dateConvert ', function () {
        controller.loadCaseViewer(userInfo);
        recievedDate = null;
        expect(controller.dateConvert).toBeDefined();
        controller.dateConvert(recievedDate);
      });

      it('it should call showAlert ', function () {
        controller.loadCaseViewer(userInfo);
        expect(controller.showAlert).toBeDefined();
        controller.showAlert();
      });

      // //   it('it should call gridOptionsRelatedCases', function () {

      // //     var gridApi = {
      // //       core: {
      // //         on: {},
      // //       },
      // //     };
      // //     expect(controller.gridOptionsRelatedCases).toBeDefined();
      // //     expect(controller.gridOptionsRelatedCases.onRegisterApi).toBeDefined();
      // //     controller.gridOptionsRelatedCases.onRegisterApi(gridApi);
      // //     expect(controller.gridApi).toBe(gridApi);
      // //   });

      // //   it('it should call getRelatedCases', function () {

      // //     successResponse = {
      // //       data: {
      // //         descriptiveInfo: {
      // //           appealNumberText: "2019000359",
      // //           appealType: "On brief",
      // //           caseDiscipline: "Electrical",
      // //           inventors: [{
      // //               lifeCycle: {
      // //                 beginDate: 1238793791
      // //               },
      // //               audit: {
      // //                 lastModifiedUser: "ttu",
      // //                 lastModifiedTime: 1239882096,
      // //               },
      // //               interestedParty: {
      // //                 status: "F",
      // //                 referenceType: "AP",
      // //                 sequenceNumber: 1,
      // //                 authorityType: "INV",
      // //                 partyIdentifier: "42116212",
      // //                 interestedPartyType: "IND",
      // //               },
      // //               persons: {
      // //                 firstName: "Jianwen",
      // //                 lastName: "Yin",
      // //                 identifier: "42116212",
      // //                 citizenship: "CN",
      // //                 address: {
      // //                   physicalAddress: [{
      // //                       nameLineOneText: "Jianwen  Yin",
      // //                       addressLineOneText: "8335 Lofty Lane",
      // //                       cityName: "Round Rock",
      // //                       geographicRegionCode: "TX",
      // //                       geographicRegionName: "TEXAS",
      // //                       countryCode: "US",
      // //                       countryName: "UNITED STATES",
      // //                       postalCode: "78681",
      // //                       addressCategory: "postal",
      // //                     },
      // //                     {
      // //                       nameLineOneText: "Jianwen  Yin",
      // //                       cityName: "Round Rock",
      // //                       geographicRegionCode: "TX",
      // //                       geographicRegionName: "TEXAS",
      // //                       countryCode: "US",
      // //                       countryName: "UNITED STATES",
      // //                       addressCategory: "residence",
      // //                     },
      // //                   ],
      // //                   telecommunication: [],
      // //                   emails: [],
      // //                 },
      // //               },
      // //             },
      // //             {
      // //               lifeCycle: {
      // //                 beginDate: 1239882184
      // //               },
      // //               audit: {
      // //                 lastModifiedUser: "ttu",
      // //                 lastModifiedTime: 1239882184,
      // //               },
      // //               interestedParty: {
      // //                 status: "F",
      // //                 referenceType: "AP",
      // //                 sequenceNumber: 2,
      // //                 authorityType: "INV",
      // //                 partyIdentifier: "42178801",
      // //                 interestedPartyType: "IND",
      // //               },
      // //               persons: {
      // //                 firstName: "Yong",
      // //                 lastName: "Cao",
      // //                 identifier: "42178801",
      // //                 citizenship: "CN",
      // //                 address: {
      // //                   physicalAddress: [{
      // //                     nameLineOneText: "Yong  Cao",
      // //                     cityName: "Cedar Park",
      // //                     geographicRegionCode: "TX",
      // //                     geographicRegionName: "TEXAS",
      // //                     countryCode: "US",
      // //                     countryName: "UNITED STATES",
      // //                     addressCategory: "residence",
      // //                   }],
      // //                   telecommunication: [],
      // //                   emails: [],
      // //                 },
      // //               },
      // //             },
      // //             {
      // //               lifeCycle: {
      // //                 beginDate: 1239882241
      // //               },
      // //               audit: {
      // //                 lastModifiedUser: "ttu",
      // //                 lastModifiedTime: 1239882241,
      // //               },
      // //               interestedParty: {
      // //                 status: "F",
      // //                 referenceType: "AP",
      // //                 sequenceNumber: 3,
      // //                 authorityType: "INV",
      // //                 partyIdentifier: "42178812",
      // //                 interestedPartyType: "IND",
      // //               },
      // //               persons: {
      // //                 firstName: "Xianghong",
      // //                 lastName: "Qian",
      // //                 identifier: "42178812",
      // //                 citizenship: "US",
      // //                 address: {
      // //                   physicalAddress: [{
      // //                     nameLineOneText: "Xianghong  Qian",
      // //                     cityName: "Austin",
      // //                     geographicRegionCode: "TX",
      // //                     geographicRegionName: "TEXAS",
      // //                     countryCode: "US",
      // //                     countryName: "UNITED STATES",
      // //                     addressCategory: "residence",
      // //                   }],
      // //                   telecommunication: [],
      // //                   emails: [],
      // //                 },
      // //               },
      // //             },
      // //           ],
      // //           applicationType: "REGULAR",
      // //           artClassNumber: "718",
      // //           artSubClassNumber: "100000",
      // //           cpcCodeFirst: null,
      // //           techCenterNumber: "2100",
      // //           artUnit: "2182",
      // //           specialType: null,
      // //           ptabReceivedDate: 1541168298000,
      // //           worker: {
      // //             workerNumber: "82856",
      // //             activeIndicator: false,
      // //             fullName: "GIROUX, GEORGE ",
      // //           },
      // //           realPartiesDetails: [],
      // //           appellantsDetails: [
      // //             "Yin, Jianwen  et al."
      // //           ],
      // //         },
      // //         parentInfo: {
      // //           applicationNumberText: null,
      // //           artClassNumber: null,
      // //           artSubClassNumber: null,
      // //           techCenterNumber: null,
      // //           artUnit: null,
      // //           inventors: null,
      // //           inventionTitleText: null,
      // //         },
      // //         corrAddress: {
      // //           customerNumberText: "33438",
      // //           nameLineOneText: "TERRILE, CANNATTI & CHAMBERS, LLP",
      // //           nameLineTwoText: "",
      // //           streetAddressLineOneText: "P.O. BOX 203518",
      // //           streetAddressLineTwoText: "",
      // //           cityName: "AUSTIN",
      // //           geographicRegionName: "TX",
      // //           postalCode: "78720",
      // //         },
      // //         thirdPartyInfo: {
      // //           customerNumber: "33438",
      // //           nameLineOneText: null,
      // //           nameLineTwoText: null,
      // //           addressLineOneText: null,
      // //           addressLineTwoText: null,
      // //           cityName: null,
      // //           geographicRegionCode: null,
      // //           geographicRegionName: null,
      // //           postalCode: null,
      // //           worker: {
      // //             workerNumber: "32946",
      // //             activeIndicator: false,
      // //             fullName: "TERRILE, STEPHEN",
      // //           },
      // //         },
      // //       }
      // //     };

      // //     expect(controller.getRelatedCases).toBeDefined();
      // //     controller.getRelatedCases();

      // //     HttpFactoryDeferred.resolve(successResponse);
      // //     $rootScope.$apply();

      // //   });

      // //   //toaster error
      // //   // it('getRelatedCases failureResponse ', function () {

      // //   //   var failureResponse = {
      // //   //     data: {}
      // //   //   };

      // //   //   expect(controller.getRelatedCases).toBeDefined();
      // //   //   controller.getRelatedCases();

      // //   //   HttpFactoryDeferred.reject(failureResponse);
      // //   //   $rootScope.$apply();
      // //   // });

      // //   it('it should call openAssignHistory ', function () {

      // //     var row = {
      // //       entity: {
      // //         "serialNumber": "09773340",
      // //         "sequenceNumber": 1,
      // //         "appealNumber": "2018005708"
      // //       }
      // //     }

      // //     scope.assignData = {
      // //       "serialNumber": "09773340",
      // //       "sequenceNumber": 1,
      // //       "appealNumber": "2018005708"
      // //     }
      // //     expect(scope['openAssignHistory']).toBeDefined();
      // //     expect(ngDialog.open).toBeDefined();
      // //     scope.openAssignHistory(row);


      // //     expect(ngDialog.open).toHaveBeenCalled();

      // //     expect(ngDialog.open.calls.count()).toBe(1);
      // //     var args = ngDialog.open.calls.argsFor(0);
      // //     expect(args).not.toBe(null);
      // //     expect(args.length).toBe(1);

      // //     expect(args[0].controller).toBe('AssignmentHistoryController');
      // //     expect(typeof args[0].resolve).toBe('object');
      // //     // args[0].resolve.assignData();

      // //   });

      it('it should call sort  ', function () {
        controller.loadCaseViewer(userInfo);
        var param = true;
        expect(scope.sort).toBeDefined();
        scope.sort(param);
      });

      it('it should call getNotes  ', function () {
        controller.loadCaseViewer(userInfo);
        expect(scope.getNotes).toBeDefined();
        scope.getNotes();
      });

      // it('it should call saveNotes  ', function () {
      //   controller.loadCaseViewer(userInfo);
      //   expect(scope.saveNotes).toBeDefined();
      //   scope.saveNotes();
      // });

      it('it should call selectTab 1 ', function () {
        controller.loadCaseViewer(userInfo);
        currentTab = 'bib';
        scope.currentTab = 'bib';
        expect(scope.selectTab).toBeDefined();
        scope.selectTab(currentTab);
      });

      it('it should call selectTab 2 ', function () {
        controller.loadCaseViewer(userInfo);
        currentTab = 'appeal';
        scope.currentTab = 'appeal';
        expect(scope.selectTab).toBeDefined();
        scope.selectTab(currentTab);
      });

      it('it should call selectTab 3 ', function () {
        controller.loadCaseViewer(userInfo);
        currentTab = 'caseHistory';
        scope.currentTab = 'caseHistory';
        expect(scope.selectTab).toBeDefined();
        scope.selectTab(currentTab);
      });

      it('it should call selectTab 4 ', function () {
        controller.loadCaseViewer(userInfo);
        currentTab = 'relatedCases';
        scope.currentTab = 'relatedCases';
        expect(scope.selectTab).toBeDefined();
        scope.selectTab(currentTab);
      });

      it('it should call selectTab 5 ', function () {
        controller.loadCaseViewer(userInfo);
        currentTab = 'auditTrail';
        scope.currentTab = 'auditTrail';
        expect(scope.selectTab).toBeDefined();
        scope.selectTab(currentTab);
      });

      it('it should call isActiveTab  ', function () {
        controller.loadCaseViewer(userInfo);
        tab = 'pendingDecisionTab';
        expect(scope.isActiveTab).toBeDefined();
        scope.isActiveTab(tab);
      });

      // //   // it('it should call getUserInfo ', function () {

      // //   //   controller.userInfo = {}
      // //   //   expect(controller['getUserInfo']).toBeDefined();
      // //   //   controller.getUserInfo();

      // //   // expect(ngDialog.open).toHaveBeenCalled();

      // //   // expect(ngDialog.open.calls.count()).toBe(1);
      // //   // var args = ngDialog.open.calls.argsFor(0);
      // //   // expect(args).not.toBe(null);
      // //   // expect(args.length).toBe(1);

      // //   // expect(args[0].controller).toBe('GetUserInfoController');
      // //   // expect(typeof args[0].resolve).toBe('object');
      // //   // args[0].resolve.userInfo();

      // //   // });

      // //   // it('it should call reloadScreen  ', function () {
      // //   //   expect(controller.reloadScreen).toBeDefined();
      // //   //   controller.reloadScreen();
      // //   // });

      // //   it('it should call collapseAll  ', function () {
      // //     expect(controller.collapseAll).toBeDefined();
      // //     controller.collapseAll();
      // //   });

      // it('it should call gridOptionsRelatedCases', function () {
      //   controller.loadCaseViewer(userInfo);
      //   var gridApi = {};
      //   expect(controller.gridOptionsRelatedCases).toBeDefined();
      //   expect(controller.gridOptionsRelatedCases.onRegisterApi).toBeDefined();
      //   controller.gridOptionsRelatedCases.onRegisterApi(gridApi);
      //   expect(controller.gridApi).toBe(gridApi);
      // });

    });
  });
})();
