(function () {
    'use strict';
    /**
     * This controller is for updateing special types.
     */
    angular
      .module('ptabe2e')
      .controller('SpecialTypesFastTrackController', function (ngDialog, CONSTANTS, HttpFactory, $scope, CommonHelperService, specialTypesData) {
        $scope.postData = specialTypesData;

        $scope.saveSpecialTypes = function (iswaived) {
            $scope.postData.fastTrackWaived = iswaived;

            HttpFactory.putActions("/appeals/special_type", $scope.postData)
              .then(function (successResponse) {
                $scope.warningMessage = successResponse.data.warningMessage;
                $scope.disableSave = true;
                CommonHelperService.setToastr("", "clear");
                CommonHelperService.setToastr(CONSTANTS.TOASTER.specialTypesControllerSuccess, "success");
                ngDialog.closeAll();
                if(null != $scope.warningMessage && $scope.warningMessage != ""){
                  $scope.openSpecialTypeWarning($scope.warningMessage);
                }
                // if ($scope.close) {
                // }
              }, function (failureResponse) {
                CommonHelperService.setToastr("", "clear");
                CommonHelperService.setToastr(failureResponse.data.message, "error");
              });
          };

                
      $scope.openSpecialTypeWarning = function (warningMessage) {
        ngDialog.open({
          template: 'app/caseViewer/specialTypesUpdateWarning.html',
          width: '25%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          data: {
            message: warningMessage
          }
        });
      };
    

      });
  })();
  