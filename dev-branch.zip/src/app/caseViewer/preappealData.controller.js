(function () {
  "use strict";
  angular
    .module('ptabe2e')
    .controller('preappealDataController', function ($scope) {
      $scope.enabledPreappealediting = false;
      $scope.enableEdit = function () {
        $scope.enabledPreappealediting = true;
      };
    });
})();
