(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .directive('fileModel', ['$parse', function ($parse) {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var model = $parse(attrs.fileModel);
          var modelSetter = model.assign;

          element.bind('change', function () {
            scope.$apply(function () {
              modelSetter(scope, element[0].files[0]);
            });
          });
        }
      };
    }])
    .directive('customOnChange', function () {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var onChangeFunc = scope.$eval(attrs.customOnChange);
          element.bind('change', onChangeFunc);
        }
      };
    })
    .controller('InitiateVacateDecisionController', function ($scope, ngDialog, HttpFactory, CONSTANTS, $http, toastr, $sce, caseInfo, $rootScope) {
      var vm = this;
      vm.fileAdded = false;
      $scope.showDiff = false;
      $scope.dockType = null;
      $scope.fileNumber = 0;
      $scope.caseInfo = caseInfo;
      $scope.listOfFileNames = [];
      $scope.fileContent;
      $scope.multiPdf = [];
      $scope.docketFileContent = [];
      $scope.show = true;
      $scope.editable = true;
      $scope.showPreview = true;
      $scope.fileUploadDisable = true;
      $scope.hideAdd = true;
      $scope.rtfBaseLink = CONSTANTS.URL.BASE;
      $scope.transactionDate = new Date().getTime();
      $scope.enterDays = '';
      vm.hearingStatusIndicator = '';
      $scope.showHearingStatus = false;
      $scope.showUploadButtons = false;
      $scope.readyToCreateRemand = false;
      $scope.uploadFile = true;
      $scope.value = "yes";
      $scope.showMailOptions = false;



      //method to display PDF
      /* istanbul ignore next */
      vm.addFile = function (file) {
        if (!vm.fileAdded) {
          vm.fileAdded = true;
          $scope.errorMessage = false;
          var fileName = file.currentTarget.files["0"].name;
          if (angular.isUndefined(fileName)) {
            return;
          } else {
            var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
            if (ext !== 'pdf') {
              $scope.errorMessage = true;
              toastr.error(CONSTANTS.TOAST.initiateVacateDecisionControllerSelectPDF, {
                iconClass: 'toast-danger',
                timeOut: 9000000,
                extendedTimeOut: 9000000
              });
            }
            if (!$scope.errorMessage) {
              $scope.fileContent = file.currentTarget.files["0"];
              $scope.listOfFileNames = file.currentTarget.files["0"].name;
              $scope.$apply();
            }
            $scope.showPreviewPdf();
          }
        }
      };

      $scope.fileSelect = function (p) {
        if (p.keyCode === '13') {
          document.getElementById('file1').click();
        }
      };


      /* istanbul ignore next */
      $scope.showPreviewPdf = function () {
        $scope.loading = true;
        var pdfDataFile = new FormData();
        pdfDataFile.append('uploadMultipartFileContents', $scope.fileContent);
        var url = CONSTANTS.URL.PTAB_NOTICE + CONSTANTS.URL.USERGEN + 'appealNumber=' + $scope.caseInfo.entity.appealNumber +
          '&ptabAssignmentId=' + $scope.caseInfo.applicationNumber;
        HttpFactory.postPdf(url, pdfDataFile)
          .then(function (successResponse) {
            $scope.dockType= "USER";
            $scope.PostDataResponse = successResponse.data.fileContent;
            $scope.genPdfFileName = successResponse.data.fileName;
            $rootScope.genPdfFileName = successResponse.data.fileName;
            $scope.contentsPreview = 'data:application/pdf;base64,' + $scope.PostDataResponse;
            $rootScope.contentsPreview = $scope.contentsPreview;
            $scope.getPreview($scope.contentsPreview);
            $scope.loading = false;
            $scope.hideAdd = false;
            vm.fileAdded = false;
          }, function () {
            // intentional
          });
      };

      //delete pdf
      $scope.deletePdf = function (index) {
        $scope.listOfFileNames.splice(index, 1);
        $scope.fileContent.splice(index, 1);
      };

      //get call for preview
      /* istanbul ignore next */
      $scope.getPreview = function (contents) {
        $http.get(contents, {
            responseType: 'arraybuffer',
            headers: {
              'Accept': 'application/pdf'
            }
          })
          .success(function (data) {
            var file = new Blob([data], {
              type: 'application/pdf'
            });
            $scope.showDiff = true;
            var fileURL = URL.createObjectURL(file);
            var fileOne = window.URL.createObjectURL(file);
            $scope.pdfContent = $sce.trustAsResourceUrl(fileOne);
            if (null !== $scope.pdfContent && document.getElementById('miscDoc') !== null) {
              angular.element(document.getElementById('miscDoc')).scope().pdfContent = $sce.trustAsResourceUrl(fileURL);
            } else {
              $scope.pdfContent = $sce.trustAsResourceUrl(fileURL);
            }
            if (fileURL !== '' || angular.isDefined(fileURL)) {
              $scope.show = false;
              $scope.showUploadButtons = true;
              $scope.editable = false;
              $scope.pdfStyle = {
                "border": "1px solid grey"
              };
            }
          }).error(function () {
            $scope.showDiff = true;
          });
      };

      $scope.cancelUpload = function () {
        $scope.pdfContent = '';
        $scope.editable = true;
        $scope.show = true;
        $scope.hideAdd = true;
        $scope.pdfStyle = {
          "border": "none"
        };
      };

      $scope.selectFilespdf = function () {
        ngDialog.open({
          template: "app/components/widgets/assignments/src/addMiscFile.html",
          controller: 'miscellaneousDocController',
          controllerAs: "vm",
          scope: $scope,
          width: '45%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            partiesData: function () {
              return $scope.caseDetailsData;
            },
            partiesFlag: function () {
              return $scope.partiesShow;
            }
          }
        }).closePromise.then(function (data) {
          if (data.value !== "No file" && data.value !== 0) {
            $scope.fileNumber = data.value;
          }
          $scope.getDocketInfo($scope.caseInfo.appealNumberText, $scope.caseInfo.appealNumberText);
        }, function () {
          // intentional
        });
      };


      /* istanbul ignore next */
      $scope.palmUpload = function (docFlag) {
        $scope.shareAssign[0].docFlag = docFlag;
        ngDialog.open({
          template: 'app/components/widgets/assignments/src/confirmPdfUpload.html',
          controller: 'pdfUploadController',
          width: '35%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          ariaLabelledById: 'pdfUploadTitle',
          ariaDescribedById: 'pdfUploadTitle',
          resolve: {
            pdfContent: function () {
              return $rootScope.contentsPreview;
            },
            docketInfo: function () {
              return $scope.shareAssign;
            },
            mailer: function () {
              return null;
            },
            genPdfFile: function () {
              return $rootScope.genPdfFileName;
            },
            panelData: function () {
              return null;
            },
            decisionType: function () {
              return null;
            },
            decisionDueDate: function () {
              return null;
            },
            decisionDate: function () {
              return null;
            },
            judgeList: function () {
              return null;
            },
            hearingRoomRosterData: function () {
              return null;
            },
            reconsiderSequenceNumber: function () {
              return null;
            },
            adSequenceNumber: function () {
              return null;
            },
            dockType: function(){
              return $scope.dockType;
            },
            appealDecisionData: function(){
              return null;
            }
          }
        }).closePromise.then(function (pdfData) {
          $scope.$parent.$parent.refreshGrid = true;
          $scope.disableUpload = false;
          if (pdfData.value === 'closeAll') {
            $scope.closeDocketingNotice();
          } else if (angular.isDefined(pdfData.value.fileName)) {
            $scope.fileToEmail = pdfData.value.fileName;
            if (pdfData.value.deliveryMode === 'Electronic' || pdfData.value.deliveryMode === 'EMAIL') {
              $scope.showMailOptions = false;
              toastr.success("Document for case " + $scope.appealNumber + " has been successfully uploaded. Mailing assignment has been closed", {
                iconClass: 'toast-success'
              });
            } else {
              $scope.showMailOptions = true;
              toastr.success($scope.shareAssign[0].assignmentTypeDescription + " for case " + $scope.appealNumber + " has been successfully uploaded.", {
                iconClass: 'toast-success'
              });
            }
            $scope.uploadPdfContent = 'data:application/pdf;base64,' + pdfData.value.fileContent;
            $scope.getPreview($scope.uploadPdfContent);
          } else {
            toastr.error("Upload to PDP for Case " + $scope.shareAssign[0].appealNumber + " was unsuccessful.", {
              iconClass: 'toast-danger'
            });
          }
        });
      };





      $scope.closeDocketingNotice = function () {
        ngDialog.closeAll('true');
      };


      $scope.uploadDocumentSelection = function (value) {
        $scope.uploadFile = value === 'yes' ? true : false;
      };




      $scope.maxSequenceNumbers = {};

      vm.cancelInitiate = function () {
        ngDialog.closeAll(false);
      };

    });
})();
