(function () {
    'use strict';

    angular
      .module('ptabe2e')
      .controller('ArpAssignmentController', function (caseInfo, ngDialog, HttpFactory, CONSTANTS, $window, CirculationHelperService, CommonHelperService) {
        var vm = this;
        vm.assignedTo = false;
        var assignmentType;
        vm.submitted = false;

        function getAssigneeList() {
          vm.currentAssignee = {
            assigneeFullNameText: 'Loading...',
            activeCaseCount: '',
            assigneeStatus: 'InActive',
            assigneeNumberText: ""
          };
          HttpFactory.getActions(CONSTANTS.URL.ASSIGNEEUSERS + $window.sessionStorage.getItem("workerNumber"))
            .then(function (assigneeListSuccess) {
              console.log('assigneeListSuccess: ', assigneeListSuccess);
              vm.myMangers = assigneeListSuccess.data.managersData;
              vm.myTeamData = assigneeListSuccess.data.teamData;
              vm.myGroupData = assigneeListSuccess.data.groupData;
              vm.workQueueData = assigneeListSuccess.data.workQueueData;
              if (vm.myGroupData === null) {
                vm.moreAssignees = true;
              } else {
                vm.groupLength = vm.myGroupData.length;
                if (vm.groupLength === 0) {
                  vm.moreAssignees = true;
                }
              }
              vm.foundAssigne = false;

              if (!vm.foundAssigne) {
                vm.currentAssignee = {
                  assigneeFullNameText: 'Not assigned',
                  activeCaseCount: '',
                  assigneeStatus: '',
                  assigneeNumberText: ""
                };
              }
              vm.originalcurrentAssignee = angular.copy(vm.currentAssignee);
              vm.change(vm.currentAssignee);
              vm.assignedTo = false;
            }, function (assigneeListFailure) {
              console.log('assigneeListFailure: ', assigneeListFailure);

            });
        }

        getAssigneeList();

        function getAssignmentTypeList() {
          HttpFactory.getActions("/reference-data/code-reference-types?typeCode=CARP_ASSIGNMENTS")
            .then(function (assignmentTypeListSuccess) {
              vm.assignmentTypeList = assignmentTypeListSuccess.data;             
                vm.assignmentTypeList.sort(function(a,b){
                  return a.descriptionText > b.descriptionText ? 1 : -1;
                });         
            }, function (assignmentTypeListFailure) {
              console.log('assignmentTypeListFailure: ', assignmentTypeListFailure);

            });
        }
        getAssignmentTypeList();

        vm.change = function (content) {
          vm.currentAssignee.assigneeFullNameText = content.assigneeFullNameText;
          vm.currentAssignee.activeCaseCount = content.activeCaseCount;
          vm.currentAssignee.assigneeStatus = content.assigneeStatus;
          vm.currentAssignee.assigneeNumberText = content.assigneeNumberText;
          vm.assignedTo = true;
        };

        vm.moreAssigneesData = function () {
          vm.extraData = false;
          vm.moreAssignees = true;
          vm.myGroup = vm.myGroupData;
        };

        function setAssignmentDueDate() {
          var nextBusinessDay = new Date();
          var numberOfDays = 2;
          nextBusinessDay.setDate(nextBusinessDay.getDate() + numberOfDays);
          while (!CirculationHelperService.isBusinessDay(nextBusinessDay)) {
            nextBusinessDay.setDate(nextBusinessDay.getDate() + 1);
          }
          vm.assignmentDueDate = nextBusinessDay;
        }

        setAssignmentDueDate();

        vm.submitDraft = function () {
          vm.submitted = true;
          if (angular.isString(vm.selectedassignmentType)) {
            assignmentType = JSON.parse(vm.selectedassignmentType);
          } else {
            assignmentType = vm.selectedassignmentType;
          }
          var assignmentData = {
            "assignmentType": assignmentType.valueText,
            "assignee": vm.currentAssignee.assigneeNumberText,
            "serialNumber": caseInfo.applicationNumber,
            "title": assignmentType.descriptionText,
            "description": assignmentType.descriptionText,
            "dueDate": vm.assignmentDueDate.getTime(),
            "completionDate": null,
            "caseType": "APPEAL",
            "appealNumber": caseInfo.appealNumberText,
            "sequenceNumber": 0,
            "priorityIndicator": "N",
            "audit": {
              "lastModifiedTimestamp": new Date().getTime(),
              "lastModifiedUserIdentifier": $window.sessionStorage.getItem("workerNumber"),
              "createTimestamp": new Date().getTime(),
              "createUserIdentifier": $window.sessionStorage.getItem("workerNumber")
            },
          }
          HttpFactory.postActions(CONSTANTS.URL.CREATEASSIGNMENT, assignmentData)
            .then(function () {
              CommonHelperService.setToastr(CONSTANTS.TOASTER.assignment, 'success');
              ngDialog.closeAll(true);
            }, function (failureResponse) {
              CommonHelperService.setToastr(failureResponse.data.message, 'error');
            }).finally(function () {
              vm.submitted = false;
            });
        };

        vm.setDocType = function (docType) {
          console.log('docType: ', docType);
          var temp = JSON.parse(docType);
          vm.docDescription = temp.descriptionText.toLowerCase();
        };

        vm.cancelInitiate = function () {
          ngDialog.closeAll(false);
        };
      });
  })();
