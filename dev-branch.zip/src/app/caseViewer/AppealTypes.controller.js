(function () {
  'use strict';
  /**
   * This controller is for updating appeal type
   */
  angular
    .module('ptabe2e')
    .controller('AppealTypesController',
      function (partiesData, appealTypeAssignmnet, appealMergedType, appealNumber, applicationNumber, toastr, ngDialog,
        $rootScope, HttpFactory, $scope, appealType, $log) {
        var vm = this;
        $scope.shareAssign = partiesData;
        $scope.appealTypeAssignmnet = appealTypeAssignmnet;
        $scope.appealMergedType = appealMergedType;
        vm.appealNumber = appealNumber;
        vm.caseNumber = applicationNumber;
        vm.briefOrHeard = appealType;
        vm.originalAppealType = appealType === 'Heard' ? 'H' : 'B';
        vm.newAppealType = appealType;
        vm.valueChanged = false;
        vm.b_hOrh_b;
        vm.currentValue;
        vm.mergedApplListForToastr = $rootScope.mergedApplListForToastr;

        function checkApplicationListLength() {
          var templist = vm.mergedApplListForToastr.split(",");
          var applNum = vm.caseNumber;
          var removedApplNum = [];
          vm.finalList = "";
          for (var j = 0; j < templist.length; j++) {
            if (templist[j] !== applNum) {
              removedApplNum.push(templist[j]);
            }
          }
          for (var i = 0; i < removedApplNum.length; i++) {
            if (i === removedApplNum.length - 1 && removedApplNum.length > 1) {
              vm.finalList = vm.finalList + " & " + removedApplNum[i];
            } else if (i === removedApplNum.length) {
              vm.finalList = vm.finalList + removedApplNum[i];
            } else if (i === 0) {
              vm.finalList = removedApplNum[i];
            } else {
              vm.finalList = vm.finalList + ", " + removedApplNum[i];
            }
          }
        }

        checkApplicationListLength();

        vm.setAppealType = function (appType) {
          if (appType !== vm.originalAppealType) {
            vm.valueChanged = true;
          } else {
            vm.valueChanged = false;
          }
          vm.currentValue = appType;
          if (vm.currentValue === 'H') {
            vm.b_hOrh_b = 'B_H';
          } else {
            vm.b_hOrh_b = 'H_B';
          }
        };

        vm.saveAppealTypes = function () {

          if (vm.currentValue !== vm.originalAppealType) {

            var updateAppealType = {
              "serialNumber": vm.caseNumber,
              "appealNumber": vm.appealNumber,
              "completionCode": vm.b_hOrh_b,
              "lastModifiedUserIdentifier": $scope.shareAssign.workerNumber,
              "briefHearingTypeCode": vm.currentValue,
            };

            HttpFactory.putActions("/appeals/update_assignment_appeal", updateAppealType)
              .then(function (successResponse) {
                $log.info(successResponse);
                if (!$scope.appealMergedType) {
                  toastr.success("The appeal type for case # " + vm.appealNumber +
                    ", application/reexamination control number " + vm.caseNumber +
                    " has been changed from " + vm.briefOrHeard + " to " + vm.newAppealType, {
                      iconClass: 'toast-success'
                    });
                } else {
                  toastr.success("The appeal type for case # " + vm.appealNumber +
                    ", application/reexamination control number " + vm.caseNumber + "," + vm.finalList +
                    " has been changed from " + vm.briefOrHeard + " to " + vm.newAppealType, {
                      iconClass: 'toast-success'
                    });
                }
              }, function (failureResponse) {
                toastr.error(failureResponse.data.message, {
                  iconClass: 'toast-danger'
                });
              });
            ngDialog.closeAll();
          }
        };

        vm.closeAppealType = function () {
          ngDialog.closeAll();
        };

      });
})();
