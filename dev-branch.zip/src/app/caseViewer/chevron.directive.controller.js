'use strict';
/**
 * Date picker controller.  This is an angular element directive
 */
angular.module('ptabe2e').controller(
  'chevronDirectiveController',
  function ($scope, ngDialog, HttpFactory, CONSTANTS, $window, CommonHelperService, $route, $rootScope) {
    var vm = this;
    vm.appealTabCollapse = 0;
    vm.pendingDocketingTabCollapse = 0;
    vm.pendingPanelingTabCollapse = 0;
    vm.PendingHearingTabCollapse = 0;
    vm.pendingDisposalTabCollapse = 0;
    vm.pendingRehearingDecisionTabCollapse = 0;
    vm.panelInString = "";
    vm.pendingDecisionTabCollapse = 0;
    vm.updatedDate = new Date();
    vm.expandedValue = 0;
    vm.pendingDocketingTabExpand = 1;
    $scope.showData = false;
    $scope.hideData = true;
    vm.applicationNumber = $route.current.params.applicationNumber;
    vm.caseNumber = $route.current.params.caseNumber;
    vm.isAttorney = false;
    $scope.isMergedCase = false;
    vm.isPanelMember = false;

    vm.isTrials = vm.caseNumber.match(/[a-z]/i) ? true : false;

    vm.chevronCallback = function (userInfo) {

      $scope.userInfo = {
        "assigneeNumber": userInfo.appUserInfo[0].userIdentiifier,
        "loginId": userInfo.appUserInfo[0].loginId,
        "roleDescription": userInfo.appUserInfo[0].roleDescription,
        "privileges": userInfo.appUserInfo[0].privileges
      };

      if(userInfo.appUserInfo[0].roleId == CONSTANTS.ROLE.roleId){
        vm.readOnlyUser = true;
      }


      vm.getPhases = function () {
        HttpFactory.getActions("/reference-data/code-reference-types?typeCode=CHEVRON_PHASES").then(
          function (successResponse) {
            if (successResponse.data.length > 0) {
              successResponse.data.forEach(function (eachPhase) {
                switch (eachPhase.valueText) {
                  case "PHASE_VALUES":
                    var clob = JSON.parse(eachPhase.descriptionText);
                    vm.Preappeal = clob.Preappeal;
                    vm.PendingDocketing = clob.PendingDocketing;
                    vm.PendingMasterDocketing = clob.PendingMasterDocketing;
                    vm.PendingPaneling = clob.PendingPaneling;
                    vm.PendingHearing = clob.PendingHearing;
                    vm.PendingDecision = clob.PendingDecision;
                    vm.PendingRehearingDecision = clob.PendingRehearingDecision;
                    vm.PendingSubDecision = clob.PendingSubDecision;
                    vm.PendingRehDecision = clob.PendingRehDecision;
                    vm.PendingDisposal = clob.PendingDisposal;
                    vm.panelTab = clob.panelTab;
                    vm.PendingAdminRemand = clob.PendingAdminRemand;
                    vm.PendingDismissal = clob.PendingDismissal;
                    vm.decisionClosed = clob.decisionClosed;
                    vm.pendingDisp = clob.PendingDisp;
                    vm.rehearingDecisionRendered = clob.rehearingDecisionRendered;
                    vm.decisionRend = clob.decisionRend;
                    vm.SubDecisionRend = clob.SubDecisionRend;
                    vm.penPaneling = clob.penPaneling;
                    vm.penHearing = clob.penHearing;
                    vm.onBrief = clob.onBrief;
                    vm.heard = clob.heard;
                    vm.caseDisposed = clob.caseDisposed;
                    vm.penDicision = clob.penDicision;
                    vm.casePaneled = clob.casePaneled;
                    vm.masterDocket = clob.masterDocket;
                    vm.hearingComplete = clob.hearingComplete;
                    vm.dismissed = clob.dismissed;
                    vm.remanded = clob.remanded;
                    vm.penRehaering = clob.penRehaering;
                    vm.decision = clob.decision;
                    break;
                  case "UPDATE_PANEL_ACCESS":
                    vm.panelAccessList = eachPhase.descriptionText.split(',');
                    break;
                  case "SHORT_PHASE_VALUES":
                    var shortClob = JSON.parse(eachPhase.descriptionText);
                    vm.PendingDocketingCollapse = shortClob.PendingDocketingCollapse;
                    vm.PendingPanelingCollapse = shortClob.PendingPanelingCollapse;
                    vm.PendingHearingCollapse = shortClob.PendingHearingCollapse;
                    vm.PendingDecisionCollapse = shortClob.PendingDecisionCollapse;
                    vm.PendingRehearingDecisionCollapse = shortClob.PendingRehearingDecisionCollapse;
                    vm.PendingDisposalCollapse = shortClob.PendingDisposalCollapse;
                    vm.masterDocCollapse = shortClob.masterDocCollapse;
                    vm.pendingAdminRemCollapse = shortClob.pendingAdminRemCollapse;
                    vm.pendingDocollapse = shortClob.pendingDocollapse;
                    vm.pendingHRCollapse = shortClob.pendingHRCollapse;
                    vm.pendingREHCollapse = shortClob.pendingREHCollapse;
                    vm.pendingSUBCollapse = shortClob.pendingSUBCollapse;
                    vm.pendingPanelCollapse = shortClob.pendingPanelCollapse;
                    vm.decisionRenCollapse = shortClob.decisionRenCollapse;
                    vm.decisionDisCollapse = shortClob.decisionDisCollapse;
                    vm.statusCodeADM = shortClob.statusCodeADM;
                    vm.remandCollapse = shortClob.remandCollapse;
                    vm.hearingCollapse = shortClob.hearingCollapse;
                    vm.panelCollapse = shortClob.panelCollapse;
                    vm.pendingMasterCollapse = shortClob.pendingMasterCollapse;
                    vm.rehearingRenderedSmall = shortClob.rehearingRenderedSmall;
                    vm.subsequentRenderedSmall = shortClob.subsequentRenderedSmall;
                    break;
                  default:
                    break;
                }
              });
            }
          }
        );
      };

      vm.getPhases();

      /* istanbul ignore next */
      vm.getCaseInfo = function () {
        HttpFactory.getActions("/case-information/details?serialNumber=" + vm.applicationNumber + "&appealNumber=" + vm.caseNumber).then(function (successResponse) {
          vm.ptabReadOnlyUser = successResponse.data.ptabReadOnlyUser;
          vm.circulationReorderExists = successResponse.data.circulationReorderExists;
          vm.interruptInProcess = successResponse.data.interruptInProcess;
          vm.caseInfo = successResponse.data;
          vm.splLoggedIn = $scope.userInfo.roleDescription === 'Supervisor';
          if($scope.userInfo.privileges.length > 0){
            for (var k = 0; k <= $scope.userInfo.privileges.length - 1; k++) {
              vm.actionsMenuAccess = $scope.userInfo.privileges[k] === 'ActionsMenu';
            }
          }
          vm.circulationViewable = vm.caseInfo.circulationViewable;
          if (angular.isDefined(successResponse.data.allowedResourceObjectList)) {
            vm.isPanelMember = checkForPanelPrivilege(successResponse.data.allowedResourceObjectList);
          }
          if (vm.caseInfo.keyDates != null) {
            if (vm.caseInfo.keyDates.length > 0) {
              if (vm.caseInfo.keyDates.length === 1) {
                vm.caseViewerkeyDates = vm.caseInfo.keyDates[0];
              } else {
                vm.caseViewerkeyDates = vm.caseInfo.keyDates.join('| ');
              }
            }
          }
          vm.displayPaneledAttorneys = [];
          vm.isAttorney = false;
          vm.attorneyName = null;
          vm.panelInString = "";
          vm.constructPanelStr = "";
          var prepend = "";
          var apj1 = "";
          if (vm.caseInfo.attorneys !== null) {
            for (var i = 0; i <= vm.caseInfo.attorneys.length - 1; i++) {
              if (vm.caseInfo.attorneys[i]) {
                var seperator = i == 0 ? '' : ' | ';
                apj1 = vm.caseInfo.attorneys[i].rank === 1 ? vm.caseInfo.attorneys[i].employeeName : apj1;
                vm.constructPanelStr += vm.caseInfo.attorneys[i].rank !== 1 && vm.caseInfo.attorneys[i].rank !== 0 ? seperator + vm.caseInfo.attorneys[i].employeeName : '';
                if (i <= 3) {
                  vm.displayPaneledAttorneys.push(vm.caseInfo.attorneys[i]);
                  if (vm.caseInfo.attorneys[i].rank === 0) {
                    vm.isAttorney = true;
                    vm.attorneyName = vm.caseInfo.attorneys[i].employeeName;
                    prepend = '(' + vm.attorneyName + ')';
                  }
                }
              }
            }
            vm.panelInString = apj1 + prepend + vm.constructPanelStr;
          }
          vm.caseInfoParties = successResponse.data.parties;
          vm.briefHearingTypeCode = vm.caseInfo.briefHearingTypeCode;
          if (vm.briefHearingTypeCode === vm.onBrief) {
            vm.titleForPendingPaneling = vm.PendingPaneling;
          } else if (vm.briefHearingTypeCode === vm.heard) {
            vm.titleForPendingPaneling = vm.PendingHearing;
          }
          vm.casetransactionDetails = vm.caseInfo.casetransactionDetails;
          vm.lengthOfChevron = vm.casetransactionDetails;
          vm.chevronStatusCode = vm.casetransactionDetails[vm.lengthOfChevron.length - 1].statusCode;
          vm.chevronStatusDescription = vm.casetransactionDetails[vm.lengthOfChevron.length - 1].statusDescription;
          vm.chevronDetails = vm.casetransactionDetails[0].phaseName;
          vm.currentPhase = vm.casetransactionDetails[vm.lengthOfChevron.length - 1].phaseName;
          vm.currentStatusCode = vm.casetransactionDetails[vm.lengthOfChevron.length - 1].statusCode;
          if (vm.isPanelMember) {
            if (vm.panelAccessList) {
              if (!vm.panelAccessList.includes(vm.currentStatusCode)) {
                vm.isPanelMember = false;
              }
            }
          }
          if (vm.lengthOfChevron.length >= 2) {
            vm.previousPhase = vm.casetransactionDetails[vm.lengthOfChevron.length - 2].phaseName;
            vm.previousStatusCode = vm.casetransactionDetails[vm.lengthOfChevron.length - 2].statusCode;
          }
          if (vm.lengthOfChevron.length >= 3) {
            vm.beforePreviousPhase = vm.casetransactionDetails[vm.lengthOfChevron.length - 3].phaseName;
            vm.beforePreviousStatusCode = vm.casetransactionDetails[vm.lengthOfChevron.length - 3].statusCode;
          }
          if (vm.currentPhase === vm.PendingSubDecision) {
            for (var j = 0; j < vm.lengthOfChevron.length; j++) {
              if (vm.casetransactionDetails[j].phaseName === vm.PendingRehDecision) {
                vm.rehearingRendered = vm.rehearingDecisionRendered;
                vm.rehearingRenderedCollapse = vm.rehearingRenderedSmall;
                break;
              }
            }
          }
          if (vm.currentPhase === vm.PendingRehDecision) {
            for (var k = 0; k < vm.lengthOfChevron.length; k++) {
              if (vm.casetransactionDetails[k].phaseName === vm.PendingSubDecision) {
                vm.subsequentRendered = vm.SubDecisionRend;
                vm.subsequentRenderedCollapse = vm.subsequentRenderedSmall;
                break;
              }
            }
          }
          if (vm.currentPhase === vm.pendingDisp) {
            for (var m = 0; m < vm.lengthOfChevron.length; m++) {
              if (vm.casetransactionDetails[m].phaseName === vm.PendingRehDecision) {
                for (var n = 0; n < vm.lengthOfChevron.length; n++) {
                  if (vm.casetransactionDetails[n].phaseName === vm.PendingSubDecision) {
                    if (vm.previousPhase === vm.PendingRehDecision) {
                      vm.subsequentRendered = vm.SubDecisionRend;
                      vm.subsequentRenderedCollapse = vm.subsequentRenderedSmall;
                      break;
                    } else {
                      vm.rehearingRendered = vm.rehearingDecisionRendered;
                      vm.rehearingRenderedCollapse = vm.rehearingRenderedSmall;
                      break;
                    }
                  }
                }
              }
            }
          }
          if (vm.currentPhase === vm.caseDisposed) {
            for (var p = 0; p < vm.lengthOfChevron.length; p++) {
              if (vm.casetransactionDetails[p].phaseName === vm.penPaneling) {
                vm.masterDocketDisp = vm.masterDocket;
                break;
              } else {
                vm.masterDocketDisp = vm.PendingMasterDocketing;
              }
            }
            for (var q = 0; q < vm.lengthOfChevron.length; q++) {
              if (vm.casetransactionDetails[q].phaseName === vm.penDicision || vm.casetransactionDetails[q].phaseName === vm.pendingDisp) {
                vm.pendingPanelDisp = vm.casePaneled;
                break;
              } else {
                vm.pendingPanelDisp = vm.penPaneling;
              }
            }
            for (var r = 0; r < vm.lengthOfChevron.length; r++) {
              if (vm.casetransactionDetails[r].statusCode === vm.decision) {
                vm.decisionDisp = vm.decisionRend;
                break;
              } else {
                vm.decisionDisp = vm.penDicision;
              }
            }
            for (var s = 0; s < vm.lengthOfChevron.length; s++) {
              if (vm.casetransactionDetails[s].phaseName === vm.PendingRehDecision) {
                vm.rehearingDisp = vm.rehearingDecisionRendered;
                break;
              }
            }
            for (var t = 0; t < vm.lengthOfChevron.length; t++) {
              if (vm.casetransactionDetails[t].phaseName === vm.PendingSubDecision) {
                vm.subsequentDisp = vm.SubDecisionRend;
                break;
              }
            }
            for (var v = 0; v < vm.lengthOfChevron.length; v++) {
              if (vm.casetransactionDetails[v].phaseName === vm.PendingRehDecision) {
                for (var w = 0; w < vm.lengthOfChevron.length; w++) {
                  if (vm.casetransactionDetails[w].phaseName === vm.PendingSubDecision) {
                    if (vm.beforePreviousPhase === vm.PendingSubDecision) {
                      vm.rehearingRendered = vm.rehearingDecisionRendered;
                      vm.rehearingRenderedCollapse = vm.rehearingRenderedSmall;
                      break;
                    } else {
                      vm.subsequentRendered = vm.SubDecisionRend;
                      vm.subsequentRenderedCollapse = vm.subsequentRenderedSmall;
                      break;
                    }
                  }
                }
              }
            }
          }
          if (vm.currentPhase === vm.PendingAdminRemand || vm.currentPhase === vm.PendingDismissal) {
            setCounter();
          }
          if (vm.currentPhase === vm.Preappeal) {
            vm.counter = 0;
            vm.phasecount = vm.counter + 1;
            vm.setExpanded(vm.counter, "null");
            vm.checkCurrentTab();
          }
          if (vm.currentPhase === vm.PendingMasterDocketing) {
            vm.counter = 1;
            vm.phasecount = vm.counter + 1;
            vm.setExpanded(vm.counter, "null");
            vm.checkCurrentTab();
          }
          if (vm.currentPhase === vm.penPaneling || vm.currentPhase === vm.penHearing || vm.currentPhase === vm.penRehaering) {
            vm.counter = 2;
            vm.phasecount = vm.counter + 1;
            vm.setExpanded(vm.counter, "null");
            vm.checkCurrentTab();
          }
          if (vm.currentPhase === vm.penDicision) {
            vm.counter = 3;
            vm.phasecount = vm.counter + 1;
            vm.setExpanded(vm.counter, "null");
            vm.checkCurrentTab();
          }
          if (vm.currentPhase === vm.caseDisposed) {
            vm.isPanelMember = false;
            vm.counter = undefined;
            vm.phasecount = vm.counter + 1;
            vm.setExpanded(vm.counter, "null");
            vm.checkCurrentTab();
          }
          if (vm.currentPhase === vm.PendingRehDecision || vm.currentPhase === vm.pendingDisp || vm.currentPhase === vm.PendingSubDecision) {
            vm.counter = 4;
            vm.phasecount = vm.counter + 1;
            vm.setExpanded(vm.counter, "null");
            vm.checkCurrentTab();
          }
          if (vm.currentPhase === vm.pendingDisp) {
            vm.isPanelMember = false;
            vm.counter = 5;
            vm.phasecount = vm.counter + 1;
            vm.setExpanded(vm.counter, "null");
            vm.checkCurrentTab();
          }
        }, function (failureResponse) {
          vm.ptabReadOnlyUser = failureResponse.data.ptabReadOnlyUser;
          CommonHelperService.setToastr(failureResponse.data.message, "error");
        });
      };

      function checkForPanelPrivilege(privilegeList) {
        return privilegeList.includes("panel_Update");
      }

      function setCounter() {
        if (vm.previousPhase === vm.PendingMasterDocketing) {
          vm.counter = 1;
        } else if ((vm.previousPhase === vm.penPaneling || vm.previousPhase === vm.penHearing) && vm.pendingPanelDisp !== vm.casePaneled) {
          vm.counter = 2;
        } else if (vm.pendingPanelDisp === vm.casePaneled) {
          vm.counter = 3;
        } else if (vm.decisionDisp === vm.decisionRend) {
          vm.counter = 4;
        } else {
          vm.counter = 5;
        }
        vm.phasecount = vm.counter + 1;
        vm.setExpanded(vm.counter, "null");
        vm.checkCurrentTab();
      }

      vm.getCaseInfo();

      vm.caseNumSearch = function () {
        HttpFactory.getActions(CONSTANTS.URL.CASE_SEARCH + vm.applicationNumber)
          .then(function (successResponse) {
            vm.appealNumberList = successResponse.data.appealNumber;
          }, function () {
            // intentional
          });
      };

      vm.caseNumSearch();

      vm.appliNumSearch = function () {
        HttpFactory.getActions("/mergeCase/leadApplication?appealNumber=" + vm.caseNumber)
          .then(function (successResponse) {
            vm.serialNumberList = [];
            vm.serialNumberList[0] = 0;
            vm.applicationList = successResponse.data;
            $scope.isMergedCase = vm.applicationList.length > 0 ? true : false;
            $rootScope.isMergedCase = $scope.isMergedCase;

            var tempList = [];
            angular.forEach(vm.applicationList, function (eachCase) {
              tempList.push(eachCase.applicationNumber);
            });
            $scope.mergedApplListForToastr = tempList.join(", ");
            $rootScope.mergedApplListForToastr = $scope.mergedApplListForToastr;

            vm.applicationList.forEach(function (element) {
              if (element.leadIndicator === true) {
                vm.serialNumberList[0] = element.applicationNumber;
              } else {
                vm.serialNumberList.push(element.applicationNumber);
              }
            });
          }, function () {
            // intentional

          });
      };
      if (!vm.isTrials) {
        vm.appliNumSearch();
      }


      /* istanbul ignore next */
      vm.checkCurrentTab = function () {
        if (vm.counter === 0) {
          vm.currentTab = vm.Preappeal;
          vm.panelTab = vm.PendingPaneling;
        }
        if (vm.counter === 1) {
          if (vm.currentPhase === vm.PendingAdminRemand || vm.currentPhase === vm.PendingDismissal) {
            vm.currentTab = vm.currentPhase;
          } else {
            vm.currentTab = vm.PendingDocketing;
          }

          vm.panelTab = vm.PendingPaneling;
        }
        if (vm.counter === 2) {
          vm.currentTab = vm.currentPhase;
          vm.panelTab = vm.currentPhase;
        }
        if (vm.counter === 3) {
          if (vm.currentPhase === vm.PendingAdminRemand || vm.currentPhase === vm.PendingDismissal) {
            vm.currentTab = vm.currentPhase;
          } else {
            vm.currentTab = vm.PendingDecision;
          }

          if (vm.briefHearingTypeCode === vm.onBrief) {
            vm.panelTab = vm.PendingPaneling;
          } else if (vm.briefHearingTypeCode === vm.heard) {
            vm.panelTab = vm.PendingHearing;
          }
        }
        if (vm.counter === 4) {

          vm.currentTab = vm.currentPhase;
          if (vm.briefHearingTypeCode === vm.onBrief) {
            vm.panelTab = vm.PendingPaneling;
          } else if (vm.briefHearingTypeCode === vm.heard) {
            vm.panelTab = vm.PendingHearing;
          }
        }
        if (angular.isUndefined(vm.counter)) {
          vm.currentTab = vm.caseDisposed;
          if (vm.briefHearingTypeCode === vm.onBrief) {
            vm.panelTab = vm.PendingPaneling;
          } else if (vm.briefHearingTypeCode === vm.heard) {
            vm.panelTab = vm.PendingHearing;
          }
        }
        if (vm.counter === 5) {

          vm.currentTab = vm.currentPhase;
          if (vm.briefHearingTypeCode === vm.onBrief) {
            vm.panelTab = vm.PendingPaneling;
          } else if (vm.briefHearingTypeCode === vm.heard) {
            vm.panelTab = vm.PendingHearing;
          }
        }
        if (vm.counter === 6) {
          vm.currentTab = "Closed";
          vm.panelTab = vm.PendingRehearingDecision;
        }

      };
      /* istanbul ignore next */
      vm.setExpanded = function (number, selectedTab) {
        vm.phasecount = number;
        if (vm.counter > 1) {
          vm.PendingDocketing = vm.masterDocket;
          vm.PendingDocketingCollapse = vm.masterDocCollapse;
        } else {
          if (vm.masterDocketDisp === vm.masterDocket) {
            vm.PendingDocketing = vm.masterDocket;
            vm.PendingDocketingCollapse = vm.masterDocCollapse;
          } else if (vm.currentPhase === vm.PendingAdminRemand) {
            vm.PendingDocketing = vm.currentPhase;
            vm.PendingDocketingCollapse = vm.pendingAdminRemCollapse;
          } else if (vm.currentPhase === vm.PendingDismissal) {
            vm.PendingDocketing = vm.currentPhase;
            vm.PendingDocketingCollapse = vm.pendingDocollapse;
          } else {
            vm.PendingDocketing = vm.PendingMasterDocketing;
            vm.PendingDocketingCollapse = vm.pendingMasterCollapse;
          }

        }
        if (vm.counter > 2) {
          vm.PendingPaneling = vm.casePaneled;
          vm.PendingPanelingCollapse = vm.panelCollapse;
          vm.PendingHearing = vm.hearingComplete;
          vm.PendingHearingCollapse = vm.hearingCollapse;
        } else {
          if (vm.panelTab === vm.penPaneling) {
            vm.PendingPaneling = vm.penPaneling;
            vm.PendingPanelingCollapse = vm.pendingPanelCollapse;
            vm.PanelCollapse = vm.pendingPanelCollapse;
          } else {
            vm.PendingHearing = vm.penHearing;
            vm.PendingHearingCollapse = vm.pendingHRCollapse;
            vm.PanelCollapse = vm.pendingHRCollapse;
          }

          if (vm.currentPhase === vm.caseDisposed) {
            if (vm.pendingPanelDisp === vm.casePaneled) {
              vm.PendingPaneling = vm.casePaneled;
              vm.PendingPanelingCollapse = vm.panelCollapse;
              vm.PendingHearing = vm.hearingComplete;
              vm.PendingHearingCollapse = vm.hearingCollapse;
            } else {
              if (vm.panelTab === vm.penPaneling) {
                vm.PendingPaneling = vm.penPaneling;
                vm.PendingPanelingCollapse = vm.pendingPanelCollapse;
                vm.PanelCollapse = vm.pendingPanelCollapse;
              } else {
                vm.PendingHearing = vm.penHearing;
                vm.PendingHearingCollapse = vm.pendingHRCollapse;
                vm.PanelCollapse = vm.pendingHRCollapse;
              }
            }
          }

          if ((vm.currentPhase === vm.PendingAdminRemand || vm.currentPhase === vm.PendingDismissal) && vm.previousPhase !== vm.PendingMasterDocketing) {
            vm.panelTab = vm.currentPhase;
          }

        }
        if (vm.counter > 3) {
          if (vm.currentPhase === vm.PendingAdminRemand) {
            vm.PendingDecision = vm.currentPhase;
            vm.PendingDecisionCollapse = vm.pendingAdminRemCollapse;
          } else if (vm.currentPhase === vm.PendingDismissal) {
            vm.PendingDecision = vm.currentPhase;
            vm.PendingDecisionCollapse = vm.pendingDocollapse;
          } else {
            vm.PendingDecision = vm.decisionRend;
            vm.PendingDecisionCollapse = vm.decisionRenCollapse;
          }
        } else {
          if (vm.decisionDisp === vm.decisionRend) {
            vm.PendingDecision = vm.decisionRend;
            vm.PendingDecisionCollapse = vm.decisionRenCollapse;
          } else if (vm.currentPhase === vm.caseDisposed && vm.previousPhase === vm.PendingDismissal) {
            vm.PendingDecision = vm.dismissed;
            vm.PendingDecisionCollapse = vm.decisionDisCollapse;
          } else if (vm.currentPhase === vm.caseDisposed && vm.previousPhase === vm.PendingAdminRemand) {
            vm.PendingDecision = vm.remanded;
            vm.PendingDecisionCollapse = vm.remandCollapse;
          } else {
            vm.PendingDecision = vm.penDicision;
            vm.PendingDecisionCollapse = vm.pendingDocollapse;
          }
        }
        if (vm.counter > 4) {
          if (vm.currentPhase === vm.pendingDisp) {
            if (vm.previousPhase === vm.PendingRehDecision) {
              vm.PendingRehearingDecision = vm.rehearingDecisionRendered;
              vm.PendingRehearingDecisionCollapse = vm.rehearingRenderedSmall;
            } else if (vm.previousPhase === vm.PendingSubDecision) {
              vm.PendingRehearingDecision = vm.SubDecisionRend;
              vm.PendingRehearingDecisionCollapse = vm.subsequentRenderedSmall;
            } else {
              vm.PendingRehearingDecision = vm.pendingDisp;
              vm.PendingRehearingDecisionCollapse = vm.pendingDocollapse;
            }
          } else
          if (vm.previousStatusCode === vm.statusCodeADM) {
            vm.PendingRehearingDecision = vm.PendingRehDecision;
            vm.PendingRehearingDecisionCollapse = vm.pendingREHCollapse;
          } else {
            if (vm.currentPhase !== vm.PendingAdminRemand && vm.currentPhase !== vm.PendingDismissal) {
              vm.PendingRehearingDecision = vm.rehearingDecisionRendered;
              vm.PendingRehearingDecisionCollapse = vm.rehearingRenderedSmall;
            }

          }

        } else {
          if (vm.currentPhase === vm.pendingDisp) {
            vm.PendingRehearingDecision = vm.pendingDisp;
            vm.PendingRehearingDecisionCollapse = vm.pendingDocollapse;
          } else if (vm.currentPhase === vm.caseDisposed) {

            if (vm.rehearingDisp === vm.rehearingDecisionRendered && vm.subsequentDisp === vm.SubDecisionRend) {
              if (vm.beforePreviousPhase === vm.PendingSubDecision) {
                vm.PendingRehearingDecisionCollapse = vm.subsequentRenderedSmall;
                vm.PendingRehearingDecision = vm.SubDecisionRend;
              } else {
                vm.PendingRehearingDecisionCollapse = vm.rehearingRenderedSmall;
                vm.PendingRehearingDecision = vm.rehearingDecisionRendered;
              }

            } else if (vm.rehearingDisp === vm.rehearingDecisionRendered) {
              vm.PendingRehearingDecisionCollapse = vm.rehearingRenderedSmall;
              vm.PendingRehearingDecision = vm.rehearingDecisionRendered;
            } else if (vm.subsequentDisp === vm.SubDecisionRend) {
              vm.PendingRehearingDecisionCollapse = vm.subsequentRenderedSmall;
              vm.PendingRehearingDecision = vm.SubDecisionRend;
            } else {
              vm.PendingRehearingDecision = vm.PendingRehDecision;
              vm.PendingRehearingDecisionCollapse = vm.pendingREHCollapse;
            }
            vm.PendingRehearingDecisionCollapse = vm.pendingDocollapse;
            vm.PendingDisposal = vm.caseDisposed;
          } else if (vm.currentPhase === vm.PendingSubDecision) {
            vm.PendingRehearingDecision = vm.PendingSubDecision;
            vm.PendingRehearingDecisionCollapse = vm.pendingSUBCollapse;
          } else {
            vm.PendingRehearingDecision = vm.PendingRehDecision;
            vm.PendingRehearingDecisionCollapse = vm.pendingREHCollapse;
          }
        }
        processSelectedTab(selectedTab);

        vm.expandedValue = 0;
        vm.chevronAction(vm.counter, selectedTab);
      };

      function processSelectedTab(selectedTab) {
        if (selectedTab === "appealTab") {
          vm.currentTab = vm.Preappeal;
          vm.appealTabExpand = 0;
          vm.appealTabCollapse = 1;
          vm.pendingDocketingTabCollapse = 0;
          vm.pendingDocketingTabExpand = 1;
          vm.pendingPanelingTabExpand = 1;
          vm.pendingPanelingTabCollapse = 0;
          vm.PendingHearingTabExpand = 1;
          vm.PendingHearingTabCollapse = 0;
          vm.pendingDecisionTabCollapse = 0;
          vm.pendingDecisionTabExpand = 1;
          vm.pendingRehearingDecisionTabCollapse = 0;
          vm.pendingRehearingDecisionTabExpand = 1;
          vm.pendingRehearingDecisionTabCollapse = 1;
          vm.pendingRehearingDecisionTabExpand = 0;
        }
        if (selectedTab === "pendingDocketingTab") {
          vm.currentTab = vm.PendingDocketing;
          vm.pendingDocketingTabCollapse = 1;
          vm.pendingDocketingTabExpand = 0;
          vm.pendingPanelingTabCollapse = 0;
          vm.pendingPanelingTabExpand = 1;
          vm.PendingHearingTabExpand = 1;
          vm.PendingHearingTabCollapse = 0;
          vm.pendingDecisionTabCollapse = 0;
          vm.pendingDecisionTabExpand = 1;
          vm.appealTabExpand = 1;
          vm.appealTabCollapse = 0;
          vm.pendingRehearingDecisionTabCollapse = 0;
          vm.pendingRehearingDecisionTabExpand = 1;
          vm.pendingRehearingDecisionTabCollapse = 1;
          vm.pendingRehearingDecisionTabExpand = 0;
        }
        if (selectedTab === "pendingPanelingTab") {
          if (vm.briefHearingTypeCode === vm.onBrief) {
            vm.currentTab = vm.PendingPaneling;
          } else if (vm.briefHearingTypeCode === vm.heard) {
            vm.currentTab = vm.PendingHearing;
          }
          vm.pendingPanelingTabExpand = 0;
          vm.pendingPanelingTabCollapse = 1;
          vm.PendingHearingTabExpand = 0;
          vm.PendingHearingTabCollapse = 1;
          vm.pendingDecisionTabCollapse = 0;
          vm.pendingDecisionTabExpand = 1;
          vm.pendingDocketingTabCollapse = 0;
          vm.pendingDocketingTabExpand = 1;
          vm.appealTabExpand = 1;
          vm.appealTabCollapse = 0;
          vm.pendingRehearingDecisionTabCollapse = 0;
          vm.pendingRehearingDecisionTabExpand = 1;
          vm.pendingRehearingDecisionTabCollapse = 1;
          vm.pendingRehearingDecisionTabExpand = 0;
        }
        if (selectedTab === "pendingDecisionTab") {
          vm.currentTab = vm.PendingDecision;
          vm.pendingDecisionTabCollapse = 1;
          vm.pendingDecisionTabExpand = 0;
          vm.pendingPanelingTabExpand = 1;
          vm.pendingPanelingTabCollapse = 0;
          vm.PendingHearingTabExpand = 1;
          vm.PendingHearingTabCollapse = 0;
          vm.pendingDocketingTabCollapse = 0;
          vm.pendingDocketingTabExpand = 1;
          vm.appealTabExpand = 1;
          vm.appealTabCollapse = 0;
          vm.pendingRehearingDecisionTabCollapse = 0;
          vm.pendingRehearingDecisionTabExpand = 1;
          vm.pendingRehearingDecisionTabCollapse = 1;
          vm.pendingRehearingDecisionTabExpand = 0;
        }
        //Need to check
        if (selectedTab === "pendingRehearingDecisionTab") {
          if (vm.currentPhase === vm.pendingDisp) {
            vm.currentTab = vm.PendingDisposal;
            vm.pendingRehearingDecisionTabCollapse = 1;
            vm.pendingRehearingDecisionTabExpand = 0;
            vm.pendingDecisionTabCollapse = 0;
            vm.pendingDecisionTabExpand = 1;
            vm.pendingPanelingTabExpand = 1;
            vm.pendingPanelingTabCollapse = 0;
            vm.PendingHearingTabExpand = 1;
            vm.PendingHearingTabCollapse = 0;
            vm.pendingDocketingTabCollapse = 0;
            vm.pendingDocketingTabExpand = 1;
            vm.appealTabExpand = 1;
            vm.appealTabCollapse = 0;
          } else {
            vm.currentTab = vm.PendingRehearingDecision;
            vm.pendingRehearingDecisionTabCollapse = 1;
            vm.pendingRehearingDecisionTabExpand = 0;
            vm.pendingDecisionTabCollapse = 0;
            vm.pendingDecisionTabExpand = 1;
            vm.pendingPanelingTabExpand = 1;
            vm.pendingPanelingTabCollapse = 0;
            vm.PendingHearingTabExpand = 1;
            vm.PendingHearingTabCollapse = 0;
            vm.pendingDocketingTabCollapse = 0;
            vm.pendingDocketingTabExpand = 1;
            vm.appealTabExpand = 1;
            vm.appealTabCollapse = 0;
            vm.pendingRehearingDecisionTabCollapse = 1;
            vm.pendingRehearingDecisionTabExpand = 0;
          }
        }

        if (selectedTab === "pendingDisposalTab") {
          vm.currentTab = vm.PendingDisposal;
          vm.pendingDisposalTabCollapse = 1;
          vm.pendingDisposalTabExpand = 0;
          vm.pendingRehearingDecisionTabCollapse = 0;
          vm.pendingRehearingDecisionTabExpand = 1;
          vm.pendingDecisionTabCollapse = 0;
          vm.pendingDecisionTabExpand = 1;
          vm.pendingPanelingTabExpand = 1;
          vm.pendingPanelingTabCollapse = 0;
          vm.PendingHearingTabExpand = 1;
          vm.PendingHearingTabCollapse = 0;
          vm.pendingDocketingTabCollapse = 0;
          vm.pendingDocketingTabExpand = 1;
          vm.appealTabExpand = 1;
          vm.appealTabCollapse = 0;
        }
      }

      vm.appealPhase = function () {
        vm.getCaseInfo();
        vm.updatedDate = new Date();
        if (vm.fnCallback) {
          vm.fnCallback();
        }
      };

      vm.chevronRefreshData = function () {
        vm.appealPhase();
      };

      $rootScope.chevronRefreshData = function () {
        vm.appealPhase();
      };

      /* istanbul ignore next: if block */
      vm.chevronAction = function (number, selectedTab) {
        if (vm.callBackFunction) {
          vm.callBackFunction(number, selectedTab);
        }
      };

      /* istanbul ignore next*/
      vm.showDetails = function () {

        vm.scopeForShowHide = angular.element(document.getElementById('showHide')).scope();
        vm.scopeForShowHide.showData = true;
        $scope.hideData = false;
        $scope.showData = true;
      };
      vm.hideDetails = function () {
        vm.scopeForShowHide.showData = false;
        $scope.showData = false;
        $scope.hideData = true;
      };

      $scope.openPartiesDialog = function () {


        $scope.partiesShow = "Parties";
        $scope.caseDetailsData = {

          "applicationNumber": vm.applicationNumber,
          "appealNumber": vm.caseNumber
        };
        ngDialog.open({
          template: "app/components/helperComponents/appellantsPartiesAndRealParties/appellantsPartiesAndRealParties.html",
          controller: 'AppellantsPartiesController',
          scope: $scope,
          width: '60%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,

          resolve: {
            partiesData: function () {
              return $scope.caseDetailsData;
            },
            partiesFlag: function () {
              return $scope.partiesShow;
            }
          }
        }).closePromise.then(function () {

          vm.getCaseInfo();
          if (vm.fnCallback) {
            vm.fnCallback();
          }
        }, function () {
          // intentional

        });
      };


      $scope.getExternalUrls = function () {
        HttpFactory.getActions(CONSTANTS.URL.EXTERNALURLS)
          .then(function (successResponse) {
            $scope.externalUrls = [];
            for (var key in successResponse.data) {
              if (key !== "Open in PTOZone" && key !== "ptabReadOnlyUser" && key !== "allowedResourceObjectList" &&
                key !== "ptabDueDateNonEditableUser" && key !== 'ptabDefaultRefreshTime') {
                var url = {
                  description: key,
                  url: successResponse.data[key]
                };
                $scope.externalUrls.push(url);
              }
            }

          }, function () {
            // intentional
          });
      };
      $scope.getExternalUrls();

      $scope.openupdateAssignmentModal = function () {
        var ptabAssignment = {
          "assignee": $scope.userInfo.assigneeNumber,
          "serialNumber": vm.applicationNumber,
          "caseType": vm.caseInfo.appealNumberText !== 'Pending' || vm.caseInfo.appealNumberText !== 0 ? "APPEAL" : "PREAPPEAL",
          "appealNumber": vm.caseInfo.appealNumberText,
          "actionCode": vm.circulationReorderExists ? "Reorder" : "Panel",
          "priorityIndicator": "N",
          "audit": {
            "createUserIdentifier": $scope.userInfo.loginId,
            "lastModifiedUserIdentifier": $scope.userInfo.loginId,
            "lockControlNumber": 0
          }
        };
        HttpFactory.postActions(CONSTANTS.URL.UPDATE_OR_CLEAR_PANEL, ptabAssignment)
          .then(function (successResponse) {
            $scope.itemsSelected = [];
            $scope.itemsSelected.push(successResponse.data);
            $scope.itemsSelected[0].fromCaseViewer = true;
            $window.sessionStorage.setItem("panelExists", successResponse.data.assignmentExist);
            HttpFactory.getActions(CONSTANTS.URL.ASSIGNMENTBYID + $scope.itemsSelected[0].assignmentIdentifier)
              .then(function (successResponse) {
                $scope.itemsSelected[0].globalMetaData = successResponse.data.globalMetaData;
                $scope.itemsSelected[0].audit.lockControlNumber = successResponse.data.audit.lockControlNumber;
                ngDialog.open({
                  template: "app/components/widgets/assignments/src/updateAssignmentModal.html",
                  controller: 'updateAssignmentManagementController',
                  scope: $scope,
                  width: '62%',
                  appendClassName: 'ngdialog-content-cust',
                  showClose: false,
                  closeByEscape: false,
                  closeByDocument: false,
                  resolve: {
                    items: function () {
                      return $scope.itemsSelected;
                    },
                    readOnly: function () {
                      return false;
                    }
                  }
                }).closePromise.then(function () {
                  vm.getCaseInfo();
                }, function () { // intentional

                });
              }, function () {
                // intentional

              });
            $scope.itemsSelected[0].briefHearingTypeCode = vm.caseInfo.briefHearingTypeCode;

          }, function (failureResponse) {
            CommonHelperService.setToastr(failureResponse.data.message, "error");
          });
      };

      vm.openInNewWindow = function (appl, num) {
        $window.open("#/caseViewer/" + appl + "/" + num);
      };


      vm.openCirculationManager = function () {
        var url = '/circulation/isCirculationAccessible?appealNumber=' + vm.caseNumber + '&serialNumber=' + vm.applicationNumber + '&userId=' + $scope.userInfo.loginId;
        HttpFactory.getActions(url)
          .then(function (circulationExists) {
            if (circulationExists.data) {
              $window.open("#/circulation/" + vm.applicationNumber + "/" + vm.caseNumber);
            } else {
              ngDialog.open({
                template: 'app/circulation/circulationConfirmation.modal.html',
                controller: 'CirculationConfirmationController',
                controllerAs: 'vm',
                width: '25%',
                showClose: false,
                closeByEscape: false,
                closeByDocument: false,
                resolve: {
                  rowToDelete: function () {
                    return null;
                  },
                  flag: function () {
                    return 'noCirculation';
                  }
                }
              });
            }
          }, function (failureResponse) {
            console.log(failureResponse);
          });
      };

      vm.initiateAdminRemand = function (isRemand) {
        var initiateInfo = vm.caseInfo;
        initiateInfo.petition=false;
        initiateInfo.casePaneled = vm.caseInfo.attorneys ? vm.caseInfo.attorneys.length > 0 : false;
        initiateInfo.isRemand = isRemand;
        initiateInfo.applicationNumber = vm.applicationNumber;
        ngDialog.open({
          template: 'app/caseViewer/initiateRemandDismissal.modal.html',
          controller: 'InitiateRemandDismissalController',
          controllerAs: 'vm',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            caseInfo: function () {
              return initiateInfo;
            }
          }
        }).closePromise.then(function (results) {
          if (results.value) {
            vm.interruptInProcess = true;
          }
        });
      };

      vm.initiatePetitionDraft = function (isRemand) {
        var initiateInfo = {};
        initiateInfo.applicationNumber = vm.applicationNumber;
        initiateInfo.user=$scope.userInfo;
        ngDialog.open({
          template: 'app/caseViewer/initiatePetitionRequest.modal.html',
          controller: 'InitiatePetitionRequestController',
          controllerAs: 'vm',
          showClose: false,
          width:"80%",
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            caseInfo: function () {
              return initiateInfo;
            }
          }
        }).closePromise.then(function (results) {
          if (results.value) {
            vm.interruptInProcess = true;
          }
        });
      }


      vm.initiateErratumOrderMisc = function () {
        var initiateInfo = vm.caseInfo;
        initiateInfo.casePaneled = vm.caseInfo.attorneys ? vm.caseInfo.attorneys.length > 0 : false;
        initiateInfo.applicationNumber = vm.applicationNumber;
        ngDialog.open({
          template: 'app/caseViewer/erratumOrderMisc/erratumOrderMisc.modal.html',
          controller: 'ErratumOrderMiscController',
          controllerAs: 'vm',
          appendClassName: 'ngdialog-cust',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            caseInfo: function () {
              return initiateInfo;
            }
          }
        }).closePromise.then(function (results) {
          console.log('results: ', results);
        });
      };

      vm.createARPAssignment = function () {
        var initiateInfo = vm.caseInfo;
        initiateInfo.casePaneled = vm.caseInfo.attorneys ? vm.caseInfo.attorneys.length > 0 : false;
        initiateInfo.applicationNumber = vm.applicationNumber;
        ngDialog.open({
          template: 'app/caseViewer/appealReviewPanel/arpAssignment.modal.html',
          controller: 'ArpAssignmentController',
          controllerAs: 'vm',
          width: '31%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            caseInfo: function () {
              return initiateInfo;
            }
          }
        }).closePromise.then(function (results) {
          console.log('results: ', results);
        });
      };

    };
  });
