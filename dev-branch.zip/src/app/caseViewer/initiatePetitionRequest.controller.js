(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('InitiatePetitionRequestController', function (caseInfo, ngDialog, HttpFactory, CONSTANTS, $window, CirculationHelperService, toastr, AssignmentHelperService, CommonHelperService) {
      var vm = this;
      vm.petition =true;
      vm.petitions = [];
      var remandDismissalInfo = caseInfo;
      vm.applicationNumberText = caseInfo.applicationNumber
       vm.assignedTo = false;
      getApplicationInfo();
    
      vm.assignedToColumnDescription = "Petition decision process initiated with user assignment listed";
      vm.selectRowColumnDescription = "Petitions available for selection do not have a petition decision process initiated";
      vm.submitButtonText = 'Submit for draft creation';
      getPetitionPalmCodes();
      vm.assigneePlaceholders='Loading assignees...';
      vm.assigneePlaceholders2 = 'Loading PALM codes...';
      vm.submitButtonText= 'Submit for processing';
      getDefaultUser();
      getDefaultUsersForAllPetitions();
      getLkryza();

      function getPetitionPalmCodes() {
        vm.more=false;
        HttpFactory.getActions("/petition/types")
          .then(function (assigneeListSuccess) {
            vm.palmCodes = assigneeListSuccess.data;
            angular.forEach(vm.palmCodes, function(code) {
              code.assigneeFullNameText = code.petitionTypeCd + " - " + code.description;
            });
            vm.assigneePlaceholders2 = "Select PALM code";
            vm.backupAllUsers2 = angular.copy( vm.palmCodes);
            getCurrentPetition();
          }, function (assigneeListFailure) {
            console.log('assigneeListFailure: ', assigneeListFailure);
           });
       
      }

      function getPALMobject(code) {
        var theObject;
        angular.forEach(vm.backupAllUsers2, function(palmCode) {
          if (code === palmCode.petitionTypeCd) {
            theObject = palmCode;
          }
        });
        return theObject;
      }

 
      function getAssigneeList(workerNumber) {
        HttpFactory.getActions(CONSTANTS.URL.ASSIGNEEUSERS + workerNumber)
          .then(function (assigneeListSuccess) {
            console.log('assigneeListSuccess: ', assigneeListSuccess);
            vm.myMangers = assigneeListSuccess.data.managersData;
            vm.myTeamData = assigneeListSuccess.data.teamData;
            vm.myGroupData = assigneeListSuccess.data.groupData;
            vm.workQueueData = assigneeListSuccess.data.workQueueData;
            if (vm.petition) {
              combineAsignees(workerNumber);
            }
            if (vm.myGroupData === null) {
              vm.moreAssignees = true;
            } else {
              vm.groupLength = vm.myGroupData.length;
              if (vm.groupLength === 0) {
                vm.moreAssignees = true;
              }
            }

            if (vm.petition) {
              vm.currentAssignee= getDefaultAssigneeObject();
              if (vm.currentAssignee) {
                vm.setSelectedJudge(vm.currentAssignee);
              }
              
              vm.assignedTo = true;
            }

            if (!vm.currentAssignee) {
              vm.currentAssignee = {
                assigneeFullNameText: 'Not assigned',
                activeCaseCount: '',
                assigneeStatus: '',
                assigneeNumberText: ""
              };
              vm.assignedTo = false;
            } else {
              vm.assignedTo = true;
            }
            vm.originalcurrentAssignee = angular.copy(vm.currentAssignee);
            vm.change(vm.currentAssignee);
          }, function (assigneeListFailure) {
            console.log('assigneeListFailure: ', assigneeListFailure);
          });      }

       function getDefaultAssigneeObject(workerNumber) {
        
        if (vm.showAddPetition) {
          for (var i=0; i<vm.myTeamData.length; i++) {
            if(vm.selectedAssignmentType2.petitionTypeCd){
            if (vm.myTeamData[i].assigneeNumberText===vm.defaultUser.valueText && vm.selectedAssignmentType2.petitionTypeCd === vm.defaultUserLkryza.descriptionText) {
              return vm.myTeamData[i];
            }
            else if (vm.myTeamData[i].assigneeNumberText===vm.defaultUserForAllPetitions.valueText && vm.selectedAssignmentType2.petitionTypeCd != vm.defaultUserLkryza.descriptionText) {
              vm.myTeamData[i].assigneeFullNameText="";
              return vm.myTeamData[i];
            }
          }
          }
        }
        else{
          var rowData = vm.petitions[vm.selectedTab];
          for (var i=0; i<vm.myTeamData.length; i++) {
            if(rowData.petitionTypeReq){
            if (vm.myTeamData[i].assigneeNumberText===vm.defaultUser.valueText && rowData.petitionTypeReq === vm.defaultUserLkryza.descriptionText) {
              return vm.myTeamData[i];
            }
            else if (vm.myTeamData[i].assigneeNumberText===vm.defaultUserForAllPetitions.valueText && rowData.petitionTypeReq != vm.defaultUserLkryza.descriptionText) {
              return vm.myTeamData[i];
            }
          }
          }

        }
        return null;
      }

      function addUsersToList(users) {
        angular.forEach(users, function(aUser) {
          vm.allUsers.push(aUser);
        });
      }

      function combineAsignees(workerNumber) {
        vm.allUsers=[];
        addUsersToList(vm.myMangers);
        addUsersToList(vm.myTeamData);
        addUsersToList(vm.myGroupData);
        addUsersToList(vm.workQueueData);
        vm.backupAllUsers = angular.copy(vm.allUsers);
        vm.assigneePlaceholders="Select assignee";
        if(workerNumber == vm.lkryzaValue){
          vm.lkryzaList=vm.allUsers;
        }
        if(workerNumber == vm.defaultUserValue){
          vm.defaultUserList=vm.allUsers;
        } 
      }


      function getDefaultUser() {
        AssignmentHelperService.getDefaultUser(CONSTANTS.URL.DEFAULT_PETITION_USER).then(function(returnValue) {
          vm.defaultUser=returnValue;
          vm.lkryzaList=[];
          vm.lkryzaValue = returnValue.descriptionText;
          getAssigneeList(returnValue.descriptionText);
        });   
      }

      function getDefaultUsersForAllPetitions() {
        AssignmentHelperService.getDefaultUser(CONSTANTS.URL.DEFAULT_PETITION_FOR_ALL_USERS).then(function(returnValue) {
          vm.defaultUserForAllPetitions=returnValue;
          vm.defaultUserList=[];
          vm.defaultUserValue = returnValue.descriptionText;
          getAssigneeList(returnValue.descriptionText);
        });   
      }

      function getLkryza() {
        AssignmentHelperService.getDefaultUser(CONSTANTS.URL.DEFAULT_PETITION_FOR_LKRYZA).then(function(returnValue) {
          vm.defaultUserLkryza=returnValue;
        });   
      }

      function getApplicationInfo() {
        var inputData ={
              "applicationNumber": caseInfo.applicationNumber,
                      "petitionIndicator": "Y",
                      "userIdentifier":caseInfo.user.loginId
                    };
                  
          
          
                  //  appeals/appealNumbers?caseNumber=14077922
                  HttpFactory.getActions('/appeals/appealNumbers?caseNumber=' + caseInfo.applicationNumber)
                  .then(function (successResponse) {
                    vm.appealNumbers = successResponse.data.appealNumbers;
                    if (vm.appealNumbers && vm.appealNumbers.length>0) {
                      vm.appealNumbers.sort(function (a, b) {
                        return b - a;
                      });
                      vm.appealNumberTxt = vm.appealNumbers.join(" | ")
                    } else {
                      vm.appealNumberTxt = "0";
                      vm.appealNumbers = ["0"];
                    }

                   }, function (failureResponse) {
  
                    CommonHelperService.setToastr(failureResponse.data.message, "error");
                  });
      }

      vm.checkCompletionDate = function() {
        checkDuplicate();
      };

      function checkDuplicate() {
        if (!vm.selectedAssignmentType2 || !vm.selectedAssignmentType2.petitionTypeCd || !vm.assignmentDueDate) {
          return false;
        }
        vm.warnDuplicate=false;

        angular.forEach(vm.petitions, function(item) {
          if (vm.selectedAssignmentType2.petitionTypeCd === item.petitionTypeReq) {
            var filDate = new Date(item.entryDate*1000);
            var month = filDate.getMonth();
            var year = filDate.getFullYear();
            var theDay = filDate.getDate();

            var month2 = vm.assignmentDueDate.getMonth();
            var year2 = vm.assignmentDueDate.getFullYear();
            var theDay2 = vm.assignmentDueDate.getDate();
            if (month===month2 && year === year2 && theDay === theDay2) {
              vm.warnDuplicate = true;
            }
          }
        });
      }

      function getCurrentPetition() {
      //  http://localhost:8080/petition/current-petitions-info?serialNumber=15764089

      //HttpFactory.getActions('/petition/current-petitions-info?serialNumber=' + vm.applicationNumberText)
      HttpFactory.getActions('/petition/all-petitions-info?serialNumber=' + vm.applicationNumberText)
      .then(function (successResponse) {
        var petitions=successResponse.data;
        vm.petitions = successResponse.data;
        // vm.regularPetition = petitions;
        var count=0;
        angular.forEach(petitions, function(petition) {
          var palmCodeObject = getPALMobject(petition.petitionTypeReq);
          if (!palmCodeObject) {
            CommonHelperService.setToastr("PALM code of " + petition.petitionTypeReq + " is not valid for a petition", "error");
            return;
          }
          vm.petitions[count].palmCodeDescription=palmCodeObject.description;
          count = count+1;
        });
        // getPTABpetitions();
       }, function (failureResponse) {
        getPTABpetitions();
  //      CommonHelperService.setToastr(failureResponse.data.message, "error");
      });        
      }

      function getPTABpetitions() {
//http://localhost:8080/petition/ptab-types?serialNumber=
        HttpFactory.getActions('/petition/ptab-types?serialNumber=' + vm.applicationNumberText)
        .then(function (successResponse) {
          var petitions=successResponse.data;
          vm.PTABPetition = petitions;

          angular.forEach(petitions, function(petition) {
            addPTABpetition(petition)
          });
         }, function (failureResponse) {
        //      CommonHelperService.setToastr(failureResponse.data.message, "error");
        });        
      
      }

      function addPTABpetition(petition) {
        var pushFlag = true;
        var count=0;
        //angular.forEach(vm.PTABPetition, function(petitionObj) {
          angular.forEach(vm.regularPetition, function(innerPetitionObj) {
          var newString = (innerPetitionObj.applicationNumber).replace(/\s+/g,' ').trim();
            if(petition.referenceId == innerPetitionObj.petitionIdentifier && petition.serialNumber == newString){
              pushFlag = false;
              vm.petitions[count].inPTACTS=true;
            }
            count = count+1;
          });
       // });
       if(pushFlag){
        var palmCodeObject = getPALMobject(petition.petitionerType);
        var aPetition = {
          palmCode:palmCodeObject.petitionTypeCd,
          palmCodeDescription:palmCodeObject.description,
          assignedTo:"",
          filingDate:petition.recordedDate*1000,
          assignedDate:(new Date()).getTime(),
          inPTACTS:true
        }
        vm.petitions.push(aPetition);
      }
      }

      function addPetition(petition) {
        var palmCodeObject = getPALMobject(petition.petitionTypeReq);
        if (!palmCodeObject) {
          CommonHelperService.setToastr("PALM code of " + petition.petitionTypeReq + " is not valid for a petition", "error");
          return;
        }
        var aPetition = {
          palmCode:palmCodeObject.petitionTypeCd,
          palmCodeDescription:palmCodeObject.description,
          filingDate:petition.entryDate*1000
          
        }
        vm.petitions.push(aPetition);
      }

      vm.change = function (content) {
        vm.currentAssignee.assigneeFullNameText = content.assigneeFullNameText;
        vm.currentAssignee.activeCaseCount = content.activeCaseCount;
        vm.currentAssignee.assigneeStatus = content.assigneeStatus;
        vm.currentAssignee.assigneeNumberText = content.assigneeNumberText;
        vm.assignedTo = true;
      };

      function setAssignmentDueDate() {
        var nextBusinessDay = new Date();
        if (!vm.petition) {
          var numberOfDays = 2;
          nextBusinessDay.setDate(nextBusinessDay.getDate() + numberOfDays);
          while (!CirculationHelperService.isBusinessDay(nextBusinessDay)) {
            nextBusinessDay.setDate(nextBusinessDay.getDate() + 1);
          }
        }

        vm.assignmentDueDate = nextBusinessDay;
      }

      setAssignmentDueDate();

      vm.submitDraft = function () {
        if (vm.showAddPetition) {
        ngDialog.openConfirm({
          template: 'app/caseViewer/confirmCreatePetition.html',
          controller: 'confirmCreatePetitionController',
          controllerAs: 'vm',
          width: '30%',
          resolve: {
            palmCode: function () {
              return vm.selectedAssignmentType2;
            }
          }
        }).then(function () {
         console.info("got here")
         startSubmit();
        }, function () {
          console.info("message");
        
        });
      }
      else{
        startSubmit();
      }
      };


      vm.cancelInitiate = function () {
        ngDialog.closeAll(false);
      };

      function createAssignmentAction(petitionToPalm) {

        //var appealNumber = remandDismissalInfo.appealNumberText;
        var appealNumber = vm.appealNumbers[0];
        try {
          if (appealNumber.indexOf("Pending")>=0) {
            appealNumber = "0";
          }
        } catch(error) {
          console.info(error);
        }

        // if (appealNumber ==="0") {
        //   appealNumber = "99" + remandDismissalInfo.applicationNumber.toString();
        // }

        vm.saveInProgress=true;
        var createAssignment = {};
        createAssignment.assignmentType = "PCPD";
        createAssignment.dueDate = (new Date()).getTime();
          createAssignment.assignee = vm.selectedAssignmentType.assigneeNumberText;
       
        createAssignment.appealNumber = appealNumber;
        createAssignment.serialNumber = remandDismissalInfo.applicationNumber;
        createAssignment.priorityIndicator="N";
        createAssignment.sequenceNumber=1;
        createAssignment.title="Create petition decision draft";
        createAssignment.audit = {
          lastModifiedUserIdentifier: remandDismissalInfo.user.loginId,
          createUserIdentifier: remandDismissalInfo.user.loginId
        };
        createAssignment.petitionTypeCode=petitionToPalm.petitionType;

        if (vm.addedNotes) {
          createAssignment.notes = vm.addedNotes;
        }
        if(vm.petitions.length>0){
          createAssignment.inPetition = true;
        }
        HttpFactory.postActions(CONSTANTS.URL.CREATEASSIGNMENT, createAssignment)
        .then(function (successResponse) {
          //updatePopulation(createAssignment);
          vm.PTABassignmentIdentifier=successResponse.data.assignmentIdentifier;
          console.log(petitionToPalm);
          postPetition(petitionToPalm);
        }, function (failureResponse) {
          vm.saveInProgress=false;
          vm.saveInProgress=false;
         console.info(failureResponse);
          toastr.clear();
          toastr.error(failureResponse.data.message, {
            iconClass: 'toast-danger'
          });

        });
      }
      function createPetitionNumber() {
        ngDialog.closeAll(true);
      }

      function updatePopulation(createAssignment)  {
        // AssignmentHelperService.calUpdatePopulation(createAssignment).then(function(response) {
        //   if (!response) {
             createPetitionNumber(createAssignment);
        //   } else {
        //      vm.saveInProgress=false;
        //     toastr.clear();
        //     toastr.error(failureResponse.data.message, {
        //       iconClass: 'toast-danger'
        //     });
        //   }
        // });
      }

      function savePALMcode() {
        createAssignmentAction();
      }

      vm.startAddPetition = function() {
        vm.showAddPetition=true;
        vm.showEditPetition=false;
        vm.selectedTab="";

      }
     vm.assignmentListEnterKey = function(event) {
        if (event.keyCode===13) {
          if (vm.allUsers.length>0) {
           vm.setSelectedJudge(vm.allUsers[0]);
           vm.dontMakeVisible=true;
          }
        }
      }
    
      vm.showJudgeList = function () {
        if (vm.assigneePlaceholders==='Loading assignees...') {
          return;
        }
    
        if (vm.dontMakeVisible) {
            vm.dontMakeVisible=false;
        return;
        }
        if (!vm.judgeListVisible) {
          vm.judgeListVisible = !vm.judgeListVisible;
        }
      };
    
      vm.setSelectedJudge = function (judge) {
        if (judge.assigneeFullNameText !== "Select assignee") {
         vm.selectedAssignmentType = judge;
        } else {
          vm.selectedAssignmentType={};
        }
        vm.judgeListVisible=false;
      };
    
    
      vm.selectJudgeEntered = function(event, judge) {
        if (event.keyCode === 13) {
          vm.setSelectedJudge(judge);
        }
      };
    
      vm.searchForJudge = function (input) {
        vm.judgeListVisible=true;
        var tempList = [];
        if (angular.isDefined(input) && input.assigneeFullNameText.trim() !== "") {
          angular.forEach(vm.backupAllUsers, function (currentJudge) {
            if (currentJudge.assigneeFullNameText.toLowerCase().includes(input.assigneeFullNameText.toLowerCase())) {
              tempList.push(currentJudge);
            }
          });
          vm.allUsers = angular.copy(tempList);
        } else {
          vm.allUsers = angular.copy(vm.backupAllUsers);
        }
      };


      vm.setSelected = function(index) {
        vm.showEditPetition = true;
        vm.theSelectedIndex = index;
        vm.selectedTab = index;
      }

      /**
       * Functions for PALM code drop downs
       */
       vm.assignmentListEnterKey2 = function(event) {
        if (event.keyCode===13) {
          if (vm.palmCodes.length>0) {
           vm.setSelectedJudge2(vm.palmCodes[0]);
           vm.dontMakeVisible2=true;
          }
        }
      }
    
      vm.showJudgeList2 = function () {
        if (vm.assigneePlaceholders2==='Loading PALM codes...') {
          return;
        }
    
        if (vm.dontMakeVisible2) {
            vm.dontMakeVisible2=false;
        return;
        }
        if (!vm.judgeListVisible2) {
          vm.judgeListVisible2 = !vm.judgeListVisible2;
        }
      };
    
      vm.setSelectedJudge2 = function (judge) {
        
        if(judge.petitionTypeCd != vm.defaultUserLkryza.descriptionText){
          vm.allUsers=vm.defaultUserList;
        }
        else{
          vm.allUsers=vm.lkryzaList;
        }


        if (judge.assigneeFullNameText !== "Select PALM code") {
         vm.selectedAssignmentType2 = judge;
         checkDuplicate();
        } else {
          vm.selectedAssignmentType2={};
        }
        vm.judgeListVisible2=false;
        
        if (vm.petition) {
          vm.currentAssignee= getDefaultAssigneeObject();
          if (vm.currentAssignee) {
            vm.setSelectedJudge(vm.currentAssignee);
          }
          
          vm.assignedTo = true;
        }
      };
    
    
      vm.selectJudgeEntered2 = function(event, judge) {
        if (event.keyCode === 13) {
          vm.setSelectedJudge2(judge);
        }
      };
    
      vm.searchForJudge2 = function (input) {
        vm.judgeListVisible2=true;
        var tempList = [];
        if (angular.isDefined(input) && input.assigneeFullNameText.trim() !== "") {
          angular.forEach(vm.backupAllUsers2, function (currentJudge) {
            if (currentJudge.assigneeFullNameText.toLowerCase().includes(input.assigneeFullNameText.toLowerCase())) {
              tempList.push(currentJudge);
            }
          });
          vm.palmCodes = angular.copy(tempList);
        } else {
          vm.palmCodes = angular.copy(vm.backupAllUsers2);
        }
      };

      /** Save operations */
    

      function startSubmit() {

    
  //  http://localhost:8080/petition  POST CALL

       
        var petitionToPalm = getPetitionData();
//petitionToPalm = {"petitionType":"714","applicationNumberText":"13689548","actionDate":1632498001,"decidingOfficial":"","auditData":{"lastModifiedUserIdentifier":"sbartlett"}};
        callUpdateAppeal(petitionToPalm);
      }

      function postPetition(petitionToPalm){
        console.log(petitionToPalm);
        var status;
        if(vm.showAddPetition){
          status=false;
        }
        else{
          status=true;
        }
          HttpFactory.postActions("/petition?ptabAssignmentId="+vm.PTABassignmentIdentifier+"&existsInPalmNotInPtacts="+status, petitionToPalm)
          .then(function (successResponse) {
          // updatePopulation(createAssignment);
          toastr.clear();
          toastr.success("Assignment create petition decision draft has been successfully created.", {
            iconClass: 'toast-success'
          });
          createPetitionNumber();
          //callUpdateAppeal(petitionToPalm)
          }, function (failureResponse) {
            vm.saveInProgress=false;
            vm.saveInProgress=false;
          console.info(failureResponse);
            toastr.clear();
            toastr.error(failureResponse.data.message, {
              iconClass: 'toast-danger'
            });
          });
      }

      function callUpdateAppeal(petitionToPalm) {
        //http://localhost:8080/appeals/update_petition_appeal
        var appealNum = vm.appealNumbers[0];
        // if (vm.appealNumberTxt==='0') {
        //   appealNum="";
        // }

        var updateObject = {
          "serialNumber": petitionToPalm.applicationNumberText,
          "appealNumber":appealNum,
           "audit": {
              "createUserIdentifier": caseInfo.user.loginId,
              "lastModifiedUserIdentifier": caseInfo.user.loginId,
              "lastModifiedTimestamp": (new Date()).getTime(),
              "createTimestamp": (new Date()).getTime(),
              "lockControlNumber": 0
            }
        }
        HttpFactory.putActions("/appeals/update_petition_appeal", updateObject)
        .then(function (successResponse) {
          console.log(petitionToPalm);
          //createAssignmentAction(petitionToPalm);
          saveAssignment(petitionToPalm);
        }, function (failureResponse) {
          vm.saveInProgress=false;
          vm.saveInProgress=false;
          toastr.clear();
          toastr.error(failureResponse.data.message, {
            iconClass: 'toast-danger'
          });

        });

      }

      function getPetitionData() {
        var petitionToPalm;
        if (vm.showAddPetition) {
          var aDate = new Date(vm.assignmentDueDate.getTime()); // The 0 there is the key, which sets the date to the epoch
          //     aDate.setUTCSeconds(epochDate);
         
                 var epoch =  (aDate.getTime()-aDate.getMilliseconds())/1000;
          petitionToPalm =  {
            "petitionType": vm.selectedAssignmentType2.petitionTypeCd,    
            "applicationNumberText": vm.applicationNumberText,
            "actionDate": epoch,
            "decidingOfficial": "",
            "auditData": {
                "lastModifiedUserIdentifier": caseInfo.user.loginId
            }
          }
          return petitionToPalm;
        } else {
          var rowData = vm.petitions[vm.selectedTab];
          var aDate = new Date(rowData.entryDate*1000); 
          var epoch =  (aDate.getTime()-aDate.getMilliseconds())/1000;
          petitionToPalm =  {
            "petitionType": rowData.petitionTypeReq,    
            "applicationNumberText": vm.applicationNumberText,
            "actionDate": epoch,
            "decidingOfficial": "",
            "referenceIdentifier": rowData.petitionIdentifier,
            "auditData": {
                "lastModifiedUserIdentifier": caseInfo.user.loginId
            }
          }
          return petitionToPalm;       
        }
      }

      function saveAssignment(petitionToPalm) {
        var appealNumber = vm.appealNumbers[0];
        try {
          if (appealNumber.indexOf("Pending")>=0) {
            appealNumber = "0";
          }
        } catch(error) {
          console.info(error);
        }
        console.log(vm.selectedAssignmentType);
        var updateObject = {
          "serialNumber": petitionToPalm.applicationNumberText,
          "appealNumber":appealNumber,
           "audit": {
              "createUserIdentifier": caseInfo.user.loginId,
              "lastModifiedUserIdentifier": caseInfo.user.loginId,
              "lastModifiedTimestamp": (new Date()).getTime(),
              "createTimestamp": (new Date()).getTime(),
              "lockControlNumber": 0
            }, 
            "assignmentType": "ANY",
            "assignee": vm.selectedAssignmentType.assigneeNumberText,
            "title": "Create petition decision draft",
            "description": "This case is currently awaiting action by a judicial panel",
            "dueDate": (new Date()).getTime(),
            "completionDate": (new Date()).getTime(),
            "completionCode": "PETITION",
            "caseType": "APPEAL",
            "sequenceNumber": 1,
            "notes": "",
            "priorityIndicator": "N",
            "inPetition": true,
            "assignor": "",
            "activeIndicator": "A",
            "nextAssignee": "",
            "petitionTypeCode": petitionToPalm.petitionType
        }

        if (vm.addedNotes) {
          updateObject.notes = vm.addedNotes;
        }
        if(vm.petitions.length>0){
          updateObject.inPetition = true;
        }   
        HttpFactory.putActions(CONSTANTS.URL.UPDATE_ASSIGNMENT, updateObject)
          .then(function (successResponse) {
              console.log(successResponse);
              vm.PTABassignmentIdentifier=successResponse.data.assignmentIdentifier;
              postPetition(petitionToPalm);
          }, function (failureResponse) {
            $scope.saveInProgress=false;
            $scope.disableeWFButton=false;
            toastr.clear();
            toastr.warning(failureResponse.data.message, {
              iconClass: 'toast-warning'
            });
        
    
          });
      
      }

    });
})();
