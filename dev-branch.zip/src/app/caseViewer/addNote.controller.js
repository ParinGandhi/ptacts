(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('AddNoteController', function (HttpFactory, ngDialog, caseInfo, maxSequenceNumbers, rowToEdit, CommonHelperService, CONSTANTS, $log, $timeout) {
      var vm = this;
      vm.disableSave = false;
      vm.caseInfo = caseInfo;
      vm.note= rowToEdit;
      vm.noteSequenceNumber = maxSequenceNumbers.notes;
      vm.enteredNote = "";
      vm.modalTitle = "Add note";
      if (rowToEdit) {
        vm.enteredNote = rowToEdit.caseNotesRaw;
        vm.modalTitle = "Edit note";
      }

      $timeout(function () {
        setAriaAttribute('mceu_0', 'Undo');
        setAriaAttribute('mceu_1', 'Redo');
        setAriaAttribute('mceu_2', 'Bold');
        setAriaAttribute('mceu_3', "Italic");
        setAriaAttribute('mceu_4', "insert link");
      }, 2000);

      function setAriaAttribute(timeMcButtonId, text) {
        try {
          var tinyMcButton = document.getElementById(timeMcButtonId);
          var tinyMcButtonHTML = tinyMcButton.childNodes[0];
          tinyMcButtonHTML.setAttribute("aria-label", text);
        } catch (error) {
          $log.info("Error finding TinyMCE button");
        }
      }

      /**
       * This function will close the modal when Cancel or 'X' is clicked
       */
      vm.closeAddNoteModal = function () {
        ngDialog.closeAll();
      };

      /**
       * TinyMCE editor configurations for the note section
       */
      /* istanbul ignore next */
      vm.addNoteTinymceOptions = {
        plugins: 'link image',
        toolbar: "undo redo bold italic",
        menu: {},
        browser_spellcheck: true,
        contextmenu: false,
        elementpath: false,
        init_instance_callback: function (editor) {
          var textContentTrigger = function () {
            vm.newNote = editor.getBody().textContent;
          };
          editor.on('KeyUp', textContentTrigger);
          editor.on('ExecCommand', textContentTrigger);
          editor.on('SetContent', function (e) {
            if (!e.initial) {
              textContentTrigger();
            }
          });
        }
      };

      /**
       * This function will post the note entered
       */
      vm.addNote = function () {
        if (vm.note) {
          saveNote();
          return;
        }
        vm.disableSave = true;
        vm.noteSequenceNumber++;
        var postNotesObject = {};
        postNotesObject.appealNoteHistoryList = [];
        var dataObject = {
          "serialNumber": vm.caseInfo.serialNumber,
          "sequenceNumber": vm.noteSequenceNumber,
          "appealNumber": vm.caseInfo.appealNumber,
          "lifeCycle": null,
          "audit": {
            "lastModifiedUserIdentifier": vm.caseInfo.audit.lastModifiedUserIdentifier,
            "lastModifiedTimestamp": new Date().getTime(),
            "createUserIdentifier": null,
            "createdUserName": null,
            "lastModifiedUserName": null,
            "createTimestamp": null,
            "lockControlNumber": null
          },
          "noteText": vm.enteredNote
        };
        postNotesObject.appealNoteHistoryList.push(dataObject);

        HttpFactory.postActions("/case-information/notes", postNotesObject)
          .then(function () {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.addNoteControllerSuccess, "success");
            ngDialog.closeAll(true);
          }, function (failureResponse) {
            CommonHelperService.setToastr(failureResponse.data.message, "error");
            vm.noteSequenceNumber--;
          })
          .finally(function () {
            vm.disableSave = false;
          });
      };

      function saveNote() {
        vm.disableSave = true;
        var saveObject = {
          "appealNoteHistoryList": [
            {
              "serialNumber": vm.caseInfo.serialNumber,
              "sequenceNumber": vm.noteSequenceNumber,
              "appealNumber": vm.caseInfo.appealNumber,
              "lifeCycle": null,
              "audit": {
              "createUserIdentifier": vm.caseInfo.audit.createUserIdentifier,
              "createdUserName": null,
              "lockControlNumber": null,
              "lastModifiedUserIdentifier": vm.caseInfo.audit.lastModifiedUserIdentifier,
              "lastModifiedUserName": null,
              "lastModifiedTimestamp":  new Date().getTime(),
              "createTimestamp":  vm.caseInfo.audit.createTimestamp
              },
              "noteText": vm.enteredNote
            }
          ]
        };

        HttpFactory.putActions("/case-information/notes", saveObject)
          .then(function () {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.addNoteControllerSuccess, "success");
            ngDialog.closeAll(true);
          }, function (failureResponse) {
            CommonHelperService.setToastr(failureResponse.data.message, "error");
            vm.noteSequenceNumber--;
          })
          .finally(function () {
            vm.disableSave = false;
          });
          }
        });
})();
