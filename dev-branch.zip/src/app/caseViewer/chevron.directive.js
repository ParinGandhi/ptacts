(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .directive('chevronDirective', chevronBar);

  /** @ngInject */
  function chevronBar() {
    var directive = {
      restrict: 'E',
      templateUrl: 'app/caseViewer/chevron.directive.html',
      scope: {
        callBackFunction: '=?',
        refreshFunction: '=?',
        applicationNumber: '=?',
        caseNumber: '=?',
        caseType: '=?',
        chevronRefreshData: '=?',
        fnCallback: '=?',
        chevronCallback: '=?'
      },
      controller: 'chevronDirectiveController',
      controllerAs: 'vm',
      bindToController: true
    };

    return directive;

  }
})();
