(function () {
  'use strict';

  describe('ArrangeDocumentsController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var controller, scope, $rootScope, $CommonHelperService;
    var successResponse, failureResponse;
    var $httpBackend, spy, $q, HttpFactoryDeferred
    var caseInfo = {};
    var maxSequenceNumbers = {
      comments: {

      }
    }
    var commentsList = [{

    }];
    var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'closeAll']);

    var fakeElement = function () {
      return {
        scope: function () {
          return {
            vm: {
              getWidgetZone: function () {

              },
              setWidgetContentHeight: function () {

              }
            }
          }
        }
      }
    };

    beforeEach(inject(function (_$controller_, _$rootScope_, _$httpBackend_, _$q_, HttpFactory, _CommonHelperService_) {
      $q = _$q_;
      scope = _$rootScope_.$new();
      $controller = _$controller_;
      $rootScope = _$rootScope_;
      $httpBackend = _$httpBackend_;
      $CommonHelperService = _CommonHelperService_;
      // $ngDialog.open.and.returnValue({
      //   then: function (callback1, callback2) {
      //     callback1();
      //     callback2();
      //   }
      // });
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn($CommonHelperService, 'setToastr').and.callFake(function () {
        return "toastr";
      });
      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      controller = $controller('AddCommentController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory,
        caseInfo: caseInfo,
        maxSequenceNumbers: maxSequenceNumbers,
        commentsList: commentsList
      });
    }));

    describe('AddCommentController ', function () {

      it('should call closeAddCommentModal ', function () {
        expect(ngDialog.closeAll).toBeDefined();
        expect(controller.closeAddCommentModal).toBeDefined();
        controller.closeAddCommentModal();
        expect(ngDialog.closeAll).toHaveBeenCalled();
      });

      it('should call addComment and get successResponse', function () {
        var postCommentsObject = {
          "commentHistoryList": [{
              "serialNumber": "14754001",
              "sequenceNumber": 3,
              "appealNumber": "2019000028",
              "lifeCycle": null,
              "audit": {
                "lastModifiedTimestamp": 1539789420000,
                "lastModifiedUserIdentifier": "pgandhi",
                "createUserIdentifier": null,
                "createdUserName": null,
                "lastModifiedUserName": null,
                "createTimestamp": null,
                "lockControlNumber": null
              },
              "commentText": "<p>test</p>"
            },
            {
              "serialNumber": "14754001",
              "sequenceNumber": 2,
              "appealNumber": "2019000028",
              "lifeCycle": null,
              "audit": {
                "lastModifiedTimestamp": 1538611180000,
                "lastModifiedUserIdentifier": "pgandhi",
                "createUserIdentifier": null,
                "createdUserName": null,
                "lastModifiedUserName": null,
                "createTimestamp": null,
                "lockControlNumber": null
              },
              "commentText": "Test with default sequence number"
            },
            {
              "serialNumber": "14754001",
              "sequenceNumber": 0,
              "appealNumber": "2019000028",
              "lifeCycle": null,
              "audit": {
                "lastModifiedTimestamp": 1538611180000,
                "lastModifiedUserIdentifier": "pgandhi",
                "createUserIdentifier": null,
                "createdUserName": null,
                "lastModifiedUserName": null,
                "createTimestamp": null,
                "lockControlNumber": null
              },
              "commentText": "TestTestwith zero sequence number"
            },
            {
              "serialNumber": "14754001",
              "sequenceNumber": 1,
              "appealNumber": "2019000028",
              "lifeCycle": null,
              "audit": {
                "lastModifiedTimestamp": 1538611180000,
                "lastModifiedUserIdentifier": "pgandhi",
                "createUserIdentifier": null,
                "createdUserName": null,
                "lastModifiedUserName": null,
                "createTimestamp": null,
                "lockControlNumber": null
              },
              "commentText": "TestTestwith sequence number"
            }
          ]
        };


        expect(controller.addComment).toBeDefined();
        controller.addComment(postCommentsObject);
        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();
      });

      it('should call addComment and get failureResponse', function () {
        failureResponse = {
          data: {
            "message": "Comment not saved"
          }
        };
        expect(controller.addComment).toBeDefined();
        controller.addComment();
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });

    });
  });
})();
