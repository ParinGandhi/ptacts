(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('ArrangeDocumentsController', function (HttpFactory, CommonHelperService, $scope, $rootScope, ngDialog, caseNumber, selectedDocuments, CONSTANTS) {
      var vm = this;
      $scope.sortableOptions = {
        containment: '#arrangeSelectedDocuments',
        scroll: true,
        axis: 'y',
        cursor: 'move',
        scrollSpeed: 2,
        scrollSensitivity: 160,
        update: function () {
          $rootScope.documentsChanged = true;
        }
      };
      vm.disableSave = false;
      $scope.selectedDocuments = selectedDocuments;
      vm.documentName = caseNumber + "_selected-files";
      vm.hasSelected=true;
      vm.caseNumber = caseNumber;

      /**
       * This function will close the modal when Cancel or 'X' is clicked
       */
      vm.closeTheModal = function () {
        ngDialog.closeAll();
      };

      vm.toggleInclude = function(column) {
        column.dontInclude = !column.dontInclude;
        checkIsAtLeast1DocInList();
      }

      function checkIsAtLeast1DocInList() {
        vm.hasSelected=false;
        angular.forEach($scope.selectedDocuments, function(doc) {
          if (!doc.dontInclude) {
            vm.hasSelected=true;
          }
        });
      }

      vm.listItemUp = function (itemIndex) {
        moveItem(itemIndex, itemIndex - 1);
      };
  
      vm.listItemDown = function (itemIndex) {
        moveItem(itemIndex, itemIndex + 1);
      };

      function moveItem(origin, destination) {
        var temp = $scope.selectedDocuments[destination];
        $scope.selectedDocuments[destination] = $scope.selectedDocuments[origin];
        $scope.selectedDocuments[origin] = temp;
        $scope.vcdListOrderChanged = true;
      }

      /**
       * This function will post the selected document and download file
       */
      vm.downloadeWF = function () {
        vm.spinnerShow=true;
        var docsToUse = [];
        angular.forEach($scope.selectedDocuments, function(doc) {
          if (!doc.dontInclude) {
            docsToUse.push(doc.contentManagementId);
          }
        });
          HttpFactory.downloadzip(CONSTANTS.URL.DOWNLOAD_CASEVIEWER_PDF, docsToUse)
            .then(function (successResponse) {
              var blob = new Blob([successResponse.data], {
                type: "application/pdf"
              });
              var a = document.createElement('a');
              a.href = URL.createObjectURL(blob);
              a.download = vm.documentName + ".pdf";
              a.click();
              ngDialog.closeAll('success');
            }, function (failureResponse) {
              vm.spinnerShow=false;
              CommonHelperService.setToastr(CONSTANTS.TOASTER.downloadingError, "error", 8000);
           
            });
      };


    });
})();
