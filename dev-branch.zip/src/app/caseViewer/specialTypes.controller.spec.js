(function () {
    'use strict';
  
    describe('SpecialTypesController', function () {
  
      beforeEach(module('ptabe2e'));
      var $controller;
      var vm = this;
      var controller, scope, $rootScope;
        var successResponse;
        var $httpBackend, spy, $q, HttpFactoryDeferred;
        var partiesData = {
            applicationNumber: "201010"
        };
      var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'closeAll']);
  
        var fakeElement = function (params) {
          return {
            scope: function () {
              return {
                vm: {
                  getWidgetZone: function () {
  
                  },
                  setWidgetContentHeight: function () {
  
                  }
                }
              }
            }
          }
        };
  
      beforeEach(inject(function (_$controller_, _$rootScope_, _$httpBackend_, _$q_, HttpFactory) {
          $q = _$q_;
        scope = _$rootScope_.$new();
        $controller = _$controller_;
        $rootScope = _$rootScope_;
          $httpBackend = _$httpBackend_;
        // $ngDialog.open.and.returnValue({
        //   then: function (callback1, callback2) {
        //     callback1();
        //     callback2();
        //   }
        // });
        HttpFactoryDeferred = _$q_.defer();
        spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
        spy = spyOn(angular, 'element').and.callFake(fakeElement);
  
        controller = $controller('SpecialTypesController', {
          $scope: scope,
          ngDialog: ngDialog,
          $rootScope: _$rootScope_,
          HttpFactory: HttpFactory,
          partiesData: partiesData
        });
      }));
  
      describe('SpecialTypesController ', function () {
  
        it(' it should get getSpecialTypes  ', function () {

            successResponse = {
              data: {
                avaiableAppealSpecialTypes: [],
                exsitingAppealSpecialTypes: []
              }
            };
            // HttpFactoryDeferred.resolve(successResponse);
            // $rootScope.$apply();

            // expect(scope.getSpecialTypes).toBeDefined();
            // scope.getSpecialTypes();
          });
      
          it(' getSpecialTypes  failureResponse ', function () {
            var failureResponse = {
              data: {}
            };
            
            expect(scope.getSpecialTypes).toBeDefined();
            scope.getSpecialTypes();

            HttpFactoryDeferred.reject(failureResponse);
            $rootScope.$apply();

          });

          it('listUp should call move item', function () {

            expect(scope.listUp).toBeDefined();
            spyOn(scope, 'moveItem');
            expect(scope['moveItem']).toBeDefined();
            scope.listUp(1);
            expect(scope.moveItem).toHaveBeenCalledWith(1, undefined, NaN);
    
          });
    
          it('listDown should call move item', function () {
            expect(scope.listDown).toBeDefined();
            spyOn(scope, 'moveItem');
            expect(scope['moveItem']).toBeDefined();
            scope.listDown(1);
            expect(scope.moveItem).toHaveBeenCalledWith(1, undefined, NaN);
    
          });

          it('it should call moveSourcetoDestinationCancel ', function () {
            var data = {
              value: 'assignees'
            }
            var index;
            scope.selectedCols = [{
                value: 'assignees'
              },
              {
                value: 'applicants'
              },
              {
                value: 'inventors'
              },
              {
                value: 'thirdPartyRequesters'
              }
            ]
            scope.sortAssigneesData = [];
            scope.sortApplicantsData = [];
            scope.sortInventorsData = [];
            scope.sortThirdPartyData = [];
            expect(scope.moveSourcetoDestinationCancel).toBeDefined();
            scope.moveSourcetoDestinationCancel(data, index);
    
    
            var data = {
              value: 'applicants'
            }
            expect(scope.moveSourcetoDestinationCancel).toBeDefined();
            scope.moveSourcetoDestinationCancel(data, index);
    
            var data = {
              value: 'inventors'
            }
            expect(scope.moveSourcetoDestinationCancel).toBeDefined();
            scope.moveSourcetoDestinationCancel(data, index);
    
            var data = {
              value: 'thirdPartyRequesters'
            }
            expect(scope.moveSourcetoDestinationCancel).toBeDefined();
            scope.moveSourcetoDestinationCancel(data, index);
          });
    
          it('it should call moveSourcetoDestinationDataCancel ', function () {
            var data = {
              value: 'assignees'
            }
            var index;
            scope.selectedCols = [{
                value: 'assignees'
              },
              {
                value: 'applicants'
              },
              {
                value: 'inventors'
              },
              {
                value: 'thirdPartyRequesters'
              }
            ]
    
            scope.selectedThirdPartyCols = [{
                value: 'assignees'
              },
              {
                value: 'applicants'
              },
              {
                value: 'inventors'
              },
              {
                value: 'thirdPartyRequesters'
              }
            ]
            scope.sortAssigneesData = [];
            scope.sortApplicantsData = [];
            scope.sortInventorsData = [];
            scope.sortThirdPartyData = [];
            expect(scope.moveSourcetoDestinationDataCancel).toBeDefined();
            scope.moveSourcetoDestinationDataCancel(data, index);
    
    
            var data = {
              value: 'applicants'
            }
            expect(scope.moveSourcetoDestinationDataCancel).toBeDefined();
            scope.moveSourcetoDestinationDataCancel(data, index);
    
            var data = {
              value: 'inventors'
            }
            expect(scope.moveSourcetoDestinationDataCancel).toBeDefined();
            scope.moveSourcetoDestinationDataCancel(data, index);
    
            var data = {
              value: 'thirdPartyRequesters'
            }
            expect(scope.moveSourcetoDestinationDataCancel).toBeDefined();
            scope.moveSourcetoDestinationDataCancel(data, index);
          });
    

      });
    });
  })();
  