// (function () {
//   'use strict';

//   describe('chevronDirectiveController', function () {

//     beforeEach(module('ptabe2e'));
//     var $controller;
//     var vm = this;
//     var controller, scope, $rootScope, route;
//     var number, selectedTab, num, selectedChevron, ststs, expandState, recievedDate, currentTab, tab, counter;
//     var ngDialog = jasmine.createSpyObj('ngDialog', ['open']);
//     var successResponse, timeout, userInfo;
//     var $httpBackend, spy, $q, HttpFactoryDeferred;
//     var checkTargetId = {

//     }

//     beforeEach(inject(function (_$controller_, _$rootScope_, _$httpBackend_, _$q_, HttpFactory, $route) {
//       $q = _$q_;
//       scope = _$rootScope_.$new();
//       $controller = _$controller_;
//       $rootScope = _$rootScope_;
//       $httpBackend = _$httpBackend_;
//       route = $route;

//       $route.current = {
//         params: {
//           applicationNumber: '10651537',
//           caseNumber: '2018005604'
//         }
//       };

//       HttpFactoryDeferred = _$q_.defer();
//       spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
//       // spy = spyOn(angular, 'element').and.callFake(fakeElement);

//       ngDialog.open.and.returnValue({
//         closePromise: {
//           then: function (callback1, callback2) {
//             callback1(checkTargetId);
//             callback2();
//           }
//         },
//         then: function (callback3, callback4) {
//           callback3();
//           callback4();
//         }
//       });

//       userInfo = {
//         "userId": "sbartlett",
//         "displayName": "Bartlett, Steven J",
//         "appUserInfo": [{
//           "userIdentiifier": 5850,
//           "activeIn": "Active",
//           "lastName": "Bartlett",
//           "privileges": ["ImportManager_PostDecisionCaseManager Privileges", "panel_Update", "Paneling"],
//           "loginId": "sbartlett",
//           "fullName": "Bartlett, Steven J",
//           "disiplanceCd": "Admin",
//           "jobClassificationCode": "ADM",
//           "firstName": "Steven",
//           "emailAddress": "Jacqueline.Bui@USPTO.GOV",
//           "userWorkerNumber": "83707",
//           "roleDescription": "Business Administrator",
//           "apjSeniorityRank": 0
//         }]
//       }

//       controller = $controller('chevronDirectiveController', {
//         $scope: scope,
//         ngDialog: ngDialog,
//         $rootScope: _$rootScope_,
//         HttpFactory: HttpFactory
//       });
//     }));

//     describe('chevronDirectiveController ', function () {

//       //TODO - fix test case
//       it('it should call getCaseInfo 1', function () {

//         successResponse = {
//           data: {
//             "appealNumberText": "2019002643",
//             "applicationTypeCategory": "REEXAM",
//             "mileStoneDates": null,
//             "keyDates": [
//               " - Rehearing Decision Due Date ",
//               "03/04/2019 - Rehearing Decision transaction date ",
//               "06/28/2019 - Rehearing Decision Due Date ",
//               "03/04/2019 - Rehearing Decision transaction date "
//             ],
//             "patentNumberText": null,
//             "parties": "5851095  et al.",
//             "inventionTitle": "CAPTIVE SCREW",
//             "attorneys": [
//               "ASTORINO, MICHAEL C",
//               "NAPPI, ROBERT ",
//               "KRIVAK, CARLA "
//             ],
//             "briefHearingTypeCode": "On brief",
//             "casetransactionDetails": [{
//                 "statusCode": "APAS",
//                 "statusDescription": "Assignment of Appeal Number",
//                 "statusCodeDates": 1550091952000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Master Docketing"
//               },
//               {
//                 "statusCode": "DNMA",
//                 "statusDescription": "Docket Notice Mailed to Appellant",
//                 "statusCodeDates": 1550092337000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Master Docketing"
//               },
//               {
//                 "statusCode": "APREP",
//                 "statusDescription": "Assigned to Paralegal/Legal Technician for prepping",
//                 "statusCodeDates": 1550092628000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Master Docketing"
//               },
//               {
//                 "statusCode": "PREP",
//                 "statusDescription": "Prepping - Awaiting Panel Assignment (Selected by Prepper)",
//                 "statusCodeDates": 1550092854000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Paneling"
//               },
//               {
//                 "statusCode": "NOHMNO",
//                 "statusDescription": "NOHMNO",
//                 "statusCodeDates": 1550092957000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Hearing"
//               },
//               {
//                 "statusCode": "NOHM",
//                 "statusDescription": "Pending Decision",
//                 "statusCodeDates": 1550093007000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Hearing"
//               }
//             ],
//             "caseDetailsData": [{
//               "loginId": "sbartlett",
//               "userWorkerNumber": "83707",
//               "userIdentiifier": 1810,
//               "firstName": "Steven",
//               "lastName": "Bartlett",
//               "disiplanceCd": "Admin",
//               "fullName": "Bartlett, Steven ",
//               "activeIn": "Active",
//               "emailAddress": "TEST1_steven.bartlett.test@uspto.gov",
//               "roleDescription": "Business Administrator",
//               "jobClassificationCode": "ADM",
//               "privileges": [
//                 "ImportManager Privileges ",
//                 " PostDecisionCaseManager Privileges",
//                 "Paneling"
//               ],
//               "preferredFullName": "Steven J. Bartlett",
//               "apjSeniorityRank": 0,
//               "trialJudgeIndicator": "No",
//               "leadApjIndicator": "No"
//             }]
//           }

//         };

//         controller.chevronCallback(userInfo);

//         expect(controller.getCaseInfo).toBeDefined();
//         controller.getCaseInfo();

//         HttpFactoryDeferred.resolve(successResponse);
//         $rootScope.$apply();

//       });

//       //TODO - fix test case
//       it('it should call getCaseInfo 2', function () {

//         successResponse = {
//           data: {
//             "appealNumberText": "2019002643",
//             "applicationTypeCategory": "REEXAM",
//             "mileStoneDates": null,
//             "keyDates": [
//               " - Rehearing Decision Due Date ",
//               "03/04/2019 - Rehearing Decision transaction date ",
//               "06/28/2019 - Rehearing Decision Due Date ",
//               "03/04/2019 - Rehearing Decision transaction date "
//             ],
//             "patentNumberText": null,
//             "parties": "5851095  et al.",
//             "inventionTitle": "CAPTIVE SCREW",
//             "attorneys": [
//               "ASTORINO, MICHAEL C",
//               "NAPPI, ROBERT ",
//               "KRIVAK, CARLA "
//             ],
//             "briefHearingTypeCode": "On brief",
//             "casetransactionDetails": [{
//                 "statusCode": "APAS",
//                 "statusDescription": "Assignment of Appeal Number",
//                 "statusCodeDates": 1550091952000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Master Docketing"
//               },
//               {
//                 "statusCode": "APAS",
//                 "statusDescription": "Assignment of Appeal Number",
//                 "statusCodeDates": 1550091952000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Master Docketing"
//               }
//             ],
//             "caseDetailsData": [{
//               "loginId": "sbartlett",
//               "userWorkerNumber": "83707",
//               "userIdentiifier": 1810,
//               "firstName": "Steven",
//               "lastName": "Bartlett",
//               "disiplanceCd": "Admin",
//               "fullName": "Bartlett, Steven ",
//               "activeIn": "Active",
//               "emailAddress": "TEST1_steven.bartlett.test@uspto.gov",
//               "roleDescription": "Business Administrator",
//               "jobClassificationCode": "ADM",
//               "privileges": [
//                 "ImportManager Privileges ",
//                 " PostDecisionCaseManager Privileges",
//                 "Paneling"
//               ],
//               "preferredFullName": "Steven J. Bartlett",
//               "apjSeniorityRank": 0,
//               "trialJudgeIndicator": "No",
//               "leadApjIndicator": "No"
//             }]
//           }

//         };

//         controller.chevronCallback(userInfo);

//         expect(controller.getCaseInfo).toBeDefined();
//         controller.getCaseInfo();

//         HttpFactoryDeferred.resolve(successResponse);
//         $rootScope.$apply();

//       });


//       //TODO - fix test case
//       it('it should call getCaseInfo 3', function () {

//         successResponse = {
//           data: {
//             "appealNumberText": "2019002643",
//             "applicationTypeCategory": "REEXAM",
//             "mileStoneDates": null,
//             "patentNumberText": null,
//             "keyDates": [],
//             "parties": "5851095  et al.",
//             "inventionTitle": "CAPTIVE SCREW",
//             "attorneys": [
//               "ASTORINO, MICHAEL C",
//               "NAPPI, ROBERT ",
//               "KRIVAK, CARLA "
//             ],
//             "briefHearingTypeCode": "On brief",
//             "casetransactionDetails": [{
//                 "statusCode": "APAS",
//                 "statusDescription": "Assignment of Appeal Number",
//                 "statusCodeDates": 1550091952000,
//                 "shevoronText": null,
//                 "phaseName": "Pre-Appeal"
//               },
//               {
//                 "statusCode": "APAS",
//                 "statusDescription": "Assignment of Appeal Number",
//                 "statusCodeDates": 1550091952000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Master Docketing"
//               }
//             ],
//             "caseDetailsData": [{
//               "loginId": "sbartlett",
//               "userWorkerNumber": "83707",
//               "userIdentiifier": 1810,
//               "firstName": "Steven",
//               "lastName": "Bartlett",
//               "disiplanceCd": "Admin",
//               "fullName": "Bartlett, Steven ",
//               "activeIn": "Active",
//               "emailAddress": "TEST1_steven.bartlett.test@uspto.gov",
//               "roleDescription": "Business Administrator",
//               "jobClassificationCode": "ADM",
//               "privileges": [
//                 "ImportManager Privileges ",
//                 " PostDecisionCaseManager Privileges",
//                 "Paneling"
//               ],
//               "preferredFullName": "Steven J. Bartlett",
//               "apjSeniorityRank": 0,
//               "trialJudgeIndicator": "No",
//               "leadApjIndicator": "No"
//             }]
//           }

//         };

//         controller.chevronCallback(userInfo);

//         expect(controller.getCaseInfo).toBeDefined();
//         controller.getCaseInfo();

//         HttpFactoryDeferred.resolve(successResponse);
//         $rootScope.$apply();
//       });


//       //TODO - fix test case
//       it('it should call getCaseInfo 4', function () {

//         successResponse = {
//           data: {
//             "appealNumberText": "2019002643",
//             "applicationTypeCategory": "REEXAM",
//             "mileStoneDates": null,
//             "keyDates": [],
//             "patentNumberText": null,
//             "parties": "5851095  et al.",
//             "inventionTitle": "CAPTIVE SCREW",
//             "attorneys": [
//               "ASTORINO, MICHAEL C",
//               "NAPPI, ROBERT ",
//               "KRIVAK, CARLA "
//             ],
//             "briefHearingTypeCode": "On brief",
//             "casetransactionDetails": [{
//                 "statusCode": "APAS",
//                 "statusDescription": "Assignment of Appeal Number",
//                 "statusCodeDates": 1550091952000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Decision"
//               },
//               {
//                 "statusCode": "APAS",
//                 "statusDescription": "Assignment of Appeal Number",
//                 "statusCodeDates": 1550091952000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Master Docketing"
//               }
//             ],
//             "caseDetailsData": [{
//               "loginId": "sbartlett",
//               "userWorkerNumber": "83707",
//               "userIdentiifier": 1810,
//               "firstName": "Steven",
//               "lastName": "Bartlett",
//               "disiplanceCd": "Admin",
//               "fullName": "Bartlett, Steven ",
//               "activeIn": "Active",
//               "emailAddress": "TEST1_steven.bartlett.test@uspto.gov",
//               "roleDescription": "Business Administrator",
//               "jobClassificationCode": "ADM",
//               "privileges": [
//                 "ImportManager Privileges ",
//                 " PostDecisionCaseManager Privileges",
//                 "Paneling"
//               ],
//               "preferredFullName": "Steven J. Bartlett",
//               "apjSeniorityRank": 0,
//               "trialJudgeIndicator": "No",
//               "leadApjIndicator": "No"
//             }]
//           }

//         };

//         controller.chevronCallback(userInfo);
//         expect(controller.getCaseInfo).toBeDefined();
//         controller.getCaseInfo();

//         HttpFactoryDeferred.resolve(successResponse);
//         $rootScope.$apply();
//       });

//       //TODO - fix test case
//       it('it should call getCaseInfo 5', function () {

//         successResponse = {
//           data: {
//             "appealNumberText": "2019002643",
//             "applicationTypeCategory": "REEXAM",
//             "mileStoneDates": null,
//             "keyDates": [],
//             "patentNumberText": null,
//             "parties": "5851095  et al.",
//             "inventionTitle": "CAPTIVE SCREW",
//             "attorneys": [
//               "ASTORINO, MICHAEL C",
//               "NAPPI, ROBERT ",
//               "KRIVAK, CARLA "
//             ],
//             "briefHearingTypeCode": "On brief",
//             "casetransactionDetails": [{
//                 "statusCode": "APAS",
//                 "statusDescription": "Assignment of Appeal Number",
//                 "statusCodeDates": 1550091952000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Rehearing Decision"
//               },
//               {
//                 "statusCode": "APAS",
//                 "statusDescription": "Assignment of Appeal Number",
//                 "statusCodeDates": 1550091952000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Master Docketing"
//               }
//             ],
//             "caseDetailsData": [{
//               "loginId": "sbartlett",
//               "userWorkerNumber": "83707",
//               "userIdentiifier": 1810,
//               "firstName": "Steven",
//               "lastName": "Bartlett",
//               "disiplanceCd": "Admin",
//               "fullName": "Bartlett, Steven ",
//               "activeIn": "Active",
//               "emailAddress": "TEST1_steven.bartlett.test@uspto.gov",
//               "roleDescription": "Business Administrator",
//               "jobClassificationCode": "ADM",
//               "privileges": [
//                 "ImportManager Privileges ",
//                 " PostDecisionCaseManager Privileges",
//                 "Paneling"
//               ],
//               "preferredFullName": "Steven J. Bartlett",
//               "apjSeniorityRank": 0,
//               "trialJudgeIndicator": "No",
//               "leadApjIndicator": "No"
//             }]
//           }

//         };

//         controller.chevronCallback(userInfo);

//         expect(controller.getCaseInfo).toBeDefined();
//         controller.getCaseInfo();

//         HttpFactoryDeferred.resolve(successResponse);
//         $rootScope.$apply();
//       });

//       //TODO - fix test case
//       it('it should call getCaseInfo 6', function () {

//         successResponse = {
//           data: {
//             "appealNumberText": "2019002643",
//             "applicationTypeCategory": "REEXAM",
//             "mileStoneDates": null,
//             "keyDates": [],
//             "patentNumberText": null,
//             "parties": "5851095  et al.",
//             "inventionTitle": "CAPTIVE SCREW",
//             "attorneys": [
//               "ASTORINO, MICHAEL C",
//               "NAPPI, ROBERT ",
//               "KRIVAK, CARLA "
//             ],
//             "briefHearingTypeCode": "On brief",
//             "casetransactionDetails": [{
//                 "statusCode": "APAS",
//                 "statusDescription": "Assignment of Appeal Number",
//                 "statusCodeDates": 1550091952000,
//                 "shevoronText": null,
//                 "phaseName": "Decision Rendered->Closed"
//               },
//               {
//                 "statusCode": "APAS",
//                 "statusDescription": "Assignment of Appeal Number",
//                 "statusCodeDates": 1550091952000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Master Docketing"
//               }
//             ],
//             "caseDetailsData": [{
//               "loginId": "sbartlett",
//               "userWorkerNumber": "83707",
//               "userIdentiifier": 1810,
//               "firstName": "Steven",
//               "lastName": "Bartlett",
//               "disiplanceCd": "Admin",
//               "fullName": "Bartlett, Steven ",
//               "activeIn": "Active",
//               "emailAddress": "TEST1_steven.bartlett.test@uspto.gov",
//               "roleDescription": "Business Administrator",
//               "jobClassificationCode": "ADM",
//               "privileges": [
//                 "ImportManager Privileges ",
//                 " PostDecisionCaseManager Privileges",
//                 "Paneling"
//               ],
//               "preferredFullName": "Steven J. Bartlett",
//               "apjSeniorityRank": 0,
//               "trialJudgeIndicator": "No",
//               "leadApjIndicator": "No"
//             }]
//           }

//         };

//         controller.chevronCallback(userInfo);

//         expect(controller.getCaseInfo).toBeDefined();
//         controller.getCaseInfo();

//         HttpFactoryDeferred.resolve(successResponse);
//         $rootScope.$apply();
//       });

//       //TODO - fix test case
//       it('it should call getCaseInfo 7', function () {

//         successResponse = {
//           data: {
//             "appealNumberText": "2019002643",
//             "applicationTypeCategory": "REEXAM",
//             "mileStoneDates": null,
//             "keyDates": [],
//             "patentNumberText": null,
//             "parties": "5851095  et al.",
//             "inventionTitle": "CAPTIVE SCREW",
//             "attorneys": [
//               "ASTORINO, MICHAEL C",
//               "NAPPI, ROBERT ",
//               "KRIVAK, CARLA "
//             ],
//             "briefHearingTypeCode": "Heard",
//             "casetransactionDetails": [{
//                 "statusCode": "APAS",
//                 "statusDescription": "Assignment of Appeal Number",
//                 "statusCodeDates": 1550091952000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Rehearing Decision"
//               },
//               {
//                 "statusCode": "APAS",
//                 "statusDescription": "Assignment of Appeal Number",
//                 "statusCodeDates": 1550091952000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Master Docketing"
//               }
//             ],
//             "caseDetailsData": [{
//               "loginId": "sbartlett",
//               "userWorkerNumber": "83707",
//               "userIdentiifier": 1810,
//               "firstName": "Steven",
//               "lastName": "Bartlett",
//               "disiplanceCd": "Admin",
//               "fullName": "Bartlett, Steven ",
//               "activeIn": "Active",
//               "emailAddress": "TEST1_steven.bartlett.test@uspto.gov",
//               "roleDescription": "Business Administrator",
//               "jobClassificationCode": "ADM",
//               "privileges": [
//                 "ImportManager Privileges ",
//                 " PostDecisionCaseManager Privileges",
//                 "Paneling"
//               ],
//               "preferredFullName": "Steven J. Bartlett",
//               "apjSeniorityRank": 0,
//               "trialJudgeIndicator": "No",
//               "leadApjIndicator": "No"
//             }]
//           }

//         };

//         controller.chevronCallback(userInfo);

//         expect(controller.getCaseInfo).toBeDefined();
//         controller.getCaseInfo();

//         HttpFactoryDeferred.resolve(successResponse);
//         $rootScope.$apply();
//       });

//       //TODO - fix test case
//       it('it should call getCaseInfo 8', function () {

//         successResponse = {
//           data: {
//             "appealNumberText": "2019002643",
//             "applicationTypeCategory": "REEXAM",
//             "mileStoneDates": null,
//             "keyDates": [],
//             "patentNumberText": null,
//             "parties": "5851095  et al.",
//             "inventionTitle": "CAPTIVE SCREW",
//             "attorneys": [
//               "ASTORINO, MICHAEL C",
//               "NAPPI, ROBERT ",
//               "KRIVAK, CARLA "
//             ],
//             "briefHearingTypeCode": "Heard",
//             "casetransactionDetails": [{
//                 "statusCode": "APAS",
//                 "statusDescription": "Assignment of Appeal Number",
//                 "statusCodeDates": 1550091952000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Decision"
//               },
//               {
//                 "statusCode": "APAS",
//                 "statusDescription": "Assignment of Appeal Number",
//                 "statusCodeDates": 1550091952000,
//                 "shevoronText": null,
//                 "phaseName": "Pending Master Docketing"
//               }
//             ],
//             "caseDetailsData": [{
//               "loginId": "sbartlett",
//               "userWorkerNumber": "83707",
//               "userIdentiifier": 1810,
//               "firstName": "Steven",
//               "lastName": "Bartlett",
//               "disiplanceCd": "Admin",
//               "fullName": "Bartlett, Steven ",
//               "activeIn": "Active",
//               "emailAddress": "TEST1_steven.bartlett.test@uspto.gov",
//               "roleDescription": "Business Administrator",
//               "jobClassificationCode": "ADM",
//               "privileges": [
//                 "ImportManager Privileges ",
//                 " PostDecisionCaseManager Privileges",
//                 "Paneling"
//               ],
//               "preferredFullName": "Steven J. Bartlett",
//               "apjSeniorityRank": 0,
//               "trialJudgeIndicator": "No",
//               "leadApjIndicator": "No"
//             }]
//           }

//         };

//         controller.chevronCallback(userInfo);

//         expect(controller.getCaseInfo).toBeDefined();
//         controller.getCaseInfo();

//         HttpFactoryDeferred.resolve(successResponse);
//         $rootScope.$apply();
//       });


//       //TODO - fix test case
//       it('it should call setExpanded ', function () {
//         controller.chevronCallback(userInfo);
//         expect(controller.setExpanded).toBeDefined();
//         controller.setExpanded();
//       });

//       it('it should call setExpanded ', function () {
//         controller.chevronCallback(userInfo);
//         controller.counter = 1;
//         expect(controller.setExpanded).toBeDefined();
//         controller.setExpanded();
//       });

//       it('it should call setExpanded ', function () {
//         controller.chevronCallback(userInfo);
//         controller.counter = 2;
//         expect(controller.setExpanded).toBeDefined();
//         controller.setExpanded(number, selectedTab);
//       });

//       it('it should call setExpanded ', function () {
//         controller.chevronCallback(userInfo);
//         controller.counter = 3;
//         controller.panelTab = "Pending Paneling";
//         expect(controller.setExpanded).toBeDefined();
//         controller.setExpanded(number, selectedTab);
//       });

//       it('it should call setExpanded ', function () {
//         controller.chevronCallback(userInfo);
//         controller.counter = 4;
//         expect(controller.setExpanded).toBeDefined();
//         controller.setExpanded(number, selectedTab);
//       });

//       it('it should call setExpanded ', function () {
//         controller.chevronCallback(userInfo);
//         expect(controller.setExpanded).toBeDefined();
//         controller.setExpanded(number, selectedTab);
//       });

//       it('it should call setExpanded ', function () {
//         controller.chevronCallback(userInfo);
//         selectedTab = 'appealTab';
//         expect(controller.setExpanded).toBeDefined();
//         controller.setExpanded(number, selectedTab);
//         // timeout.flush();
//       });

//       it('it should call setExpanded ', function () {
//         controller.chevronCallback(userInfo);
//         expect(controller.setExpanded).toBeDefined();
//         controller.setExpanded(number, selectedTab);
//       });

//       it('it should call setExpanded ', function () {
//         controller.chevronCallback(userInfo);
//         selectedTab = 'pendingDocketingTab';
//         expect(controller.setExpanded).toBeDefined();
//         controller.setExpanded(number, selectedTab);
//         // timeout.flush();
//       });

//       it('it should call setExpanded ', function () {
//         controller.chevronCallback(userInfo);
//         expect(controller.setExpanded).toBeDefined();
//         controller.setExpanded(number, selectedTab);
//       });

//       it('it should call setExpanded ', function () {
//         controller.chevronCallback(userInfo);
//         selectedTab = 'pendingPanelingTab';
//         controller.briefHearingTypeCode = "On brief";
//         expect(controller.setExpanded).toBeDefined();
//         controller.setExpanded(number, selectedTab);
//         // timeout.flush();
//       });

//       it('it should call setExpanded ', function () {
//         controller.chevronCallback(userInfo);
//         selectedTab = 'pendingPanelingTab';
//         controller.briefHearingTypeCode = "Heard";
//         expect(controller.setExpanded).toBeDefined();
//         controller.setExpanded(number, selectedTab);
//         // timeout.flush();
//       });

//       it('it should call setExpanded ', function () {
//         controller.chevronCallback(userInfo);
//         expect(controller.setExpanded).toBeDefined();
//         controller.setExpanded(number, selectedTab);
//       });

//       it('it should call setExpanded ', function () {
//         controller.chevronCallback(userInfo);
//         selectedTab = 'pendingDecisionTab';
//         expect(controller.setExpanded).toBeDefined();
//         controller.setExpanded(number, selectedTab);
//         // timeout.flush();
//       });

//       it('it should call setExpanded ', function () {
//         controller.chevronCallback(userInfo);
//         selectedTab = 'pendingRehearingDecisionTab';
//         expect(controller.setExpanded).toBeDefined();
//         controller.setExpanded(number, selectedTab);
//       });

//       it('it should call checkCurrentTab ', function () {
//         controller.chevronCallback(userInfo);
//         controller.counter = 0;
//         expect(controller.checkCurrentTab).toBeDefined();
//         controller.checkCurrentTab();
//       });

//       it('it should call checkCurrentTab ', function () {
//         controller.chevronCallback(userInfo);
//         controller.counter = 1;
//         expect(controller.checkCurrentTab).toBeDefined();
//         controller.checkCurrentTab();
//       });

//       it('it should call checkCurrentTab ', function () {
//         controller.chevronCallback(userInfo);
//         controller.counter = 2;
//         expect(controller.checkCurrentTab).toBeDefined();
//         controller.checkCurrentTab();
//       });

//       it('it should call checkCurrentTab ', function () {
//         controller.chevronCallback(userInfo);
//         controller.counter = 3;
//         expect(controller.checkCurrentTab).toBeDefined();
//         controller.checkCurrentTab();
//       });

//       it('it should call checkCurrentTab ', function () {
//         controller.chevronCallback(userInfo);
//         controller.counter = 4;
//         expect(controller.checkCurrentTab).toBeDefined();
//         controller.checkCurrentTab();
//       });

//       it('it should call appealPhase ', function () {
//         controller.chevronCallback(userInfo);
//         expect(controller.appealPhase).toBeDefined();
//         controller.appealPhase();
//       });


//       it('it should call hideDetails ', function () {
//         controller.chevronCallback(userInfo);
//         controller.scopeForShowHide = {
//           "showData": false
//         }
//         expect(controller.hideDetails).toBeDefined();
//         controller.hideDetails();
//       });

//       it('it should call openPartiesDialog ', function () {
//         controller.chevronCallback(userInfo);
//         expect(scope.openPartiesDialog).toBeDefined();
//         scope.openPartiesDialog();

//         expect(ngDialog.open).toHaveBeenCalled();

//         expect(ngDialog.open.calls.count()).toBe(1);
//         var args = ngDialog.open.calls.argsFor(0);
//         expect(args).not.toBe(null);
//         expect(args.length).toBe(1);

//         expect(args[0].controller).toBe('AppellantsPartiesController');
//         expect(typeof args[0].resolve).toBe('object');
//         args[0].resolve.partiesData();
//         args[0].resolve.partiesFlag();
//       });

//       it('it should call openupdateAssignmentModal ', function () {
//         controller.chevronCallback(userInfo);
//         scope.userInfo = {
//           userId: "sbartlett"
//         }
//         controller.caseInfo = {
//           appealNumberText: "Pending"
//         }
//         expect(scope.openupdateAssignmentModal).toBeDefined();
//         scope.openupdateAssignmentModal();
//       });


//       it('should call getPhases', function () {
//         controller.chevronCallback(userInfo);
//         expect(controller.getPhases).toBeDefined();
//         controller.getPhases();
//       });

//     });
//   });
// })();
