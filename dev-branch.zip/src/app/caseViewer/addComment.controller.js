(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('AddCommentController', function (HttpFactory, ngDialog, caseInfo, maxSequenceNumbers, CommonHelperService, commentsList, CONSTANTS) {
      var vm = this;
      vm.disableSave = false;
      vm.caseInfo = caseInfo;
      vm.commentsSequenceNumber = maxSequenceNumbers.comments;
      vm.commentsDropdownList = commentsList;
      vm.selectedComment = vm.commentsDropdownList[0];

      /**
       * This function will close the modal when Cancel or 'X' is clicked
       */
      vm.closeAddCommentModal = function () {
        ngDialog.closeAll();
      };

      /**
       * This function will post the selected comment
       */
      vm.addComment = function () {
        vm.disableSave = true;
        vm.commentsSequenceNumber++;
        var newComment = [];
        vm.caseInfo.commentText = vm.selectedComment.descriptionText;
        vm.caseInfo.sequenceNumber = vm.commentsSequenceNumber;
        newComment.push(vm.caseInfo);
        var postCommentsObject = {};
        postCommentsObject.commentHistoryList = newComment;
        HttpFactory.postActions(CONSTANTS.URL.ADD_COMMENTS_CASEVIEWER, postCommentsObject)
          .then(function () {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.addNoteCaseviewer, "success");
            ngDialog.closeAll(true);
          }, function (failureResponse) {
            CommonHelperService.setToastr(failureResponse.data.message, "error");
          })
          .finally(function () {
            vm.disableSave = false;
          });
      };


    });
})();
