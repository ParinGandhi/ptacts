(function () {
  'use strict';

  describe('RemandDismissalConfirmationController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open', 'getOpenDialogs', 'close']);
    var controller, scope, $rootScope, remandDismissalInfo;
    var $q, HttpFactoryDeferred, caseInfo;
    var successResponse = "";
    remandDismissalInfo = {
      isRemand: true,
      applicationNumber: "2",
      appealNumberText: "3",
      assignedTo: "abc",
      assignmentDueDate: "",
      addedNotes: "",
      casePaneled: "",
      briefHearingTypeCode: ""
    }
    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);

      controller = $controller('RemandDismissalConfirmationController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        remandDismissalInfo: remandDismissalInfo,
        HttpFactory: HttpFactory,
      });
    }));

    describe('RemandDismissalConfirmationController', function () {

      it('it should call noConfirm', function () {
        expect(controller.noConfirm).toBeDefined();
        ngDialog.getOpenDialogs.and.returnValue(ngDialog);
        controller.noConfirm();
      });

      it('it should call setMessage', function () {
        expect(controller.message).toBeDefined();
      });

    });
  });
})();
