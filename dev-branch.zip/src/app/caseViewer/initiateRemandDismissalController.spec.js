(function () {
  'use strict';

  describe('InitiateRemandDismissalController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'open', 'getOpenDialogs', 'close']);
    var controller, scope, $rootScope, content;
    var $q, HttpFactoryDeferred;
    var caseInfo = {};
    var successResponse = "";

    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);

      controller = $controller('InitiateRemandDismissalController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory,
        caseInfo: caseInfo
      });
    }));

    describe('InitiateRemandDismissalController', function () {
      it('it should call moreAssigneesData ', function () {
        expect(controller.moreAssigneesData).toBeDefined();
        controller.moreAssigneesData();
      });

      it('Should invoke dismiss on ngDialog', function () {
        expect(ngDialog.closeAll).toBeDefined();
        expect(controller['cancelInitiate']).toBeDefined();
        controller.cancelInitiate();
        expect(ngDialog.closeAll).toHaveBeenCalledWith(false);
      });

      //   it('it should call submitDraft ', function () {
      //     controller.assignmentDueDate = "";
      //     controller.currentAssignee = {
      //       assigneeNumberText: ""
      //     };
      //     controller.addedNotes = "";
      //     controller.isRemand = "";
      //     expect(controller.submitDraft).toBeDefined();
      //     controller.submitDraft();
      //   });

      //   it('it should call change   ', function () {
      //     content = {
      //       "beNo": "5779",
      //       "name": "Bui, Jacqueline",
      //       "activeCases": "3",
      //       "assigneeStatus": "Active"
      //     }
      //     expect(controller['change']).toBeDefined();
      //     controller.change(content);
      //   });


      // it(' should call change', function () {
      //   content = {
      //     assigneeFullNameText: 'Name',
      //     activeCaseCount: '1',
      //     assigneeStatus: '',
      //     assigneeNumberText: '2',
      //   }
      //   expect(controller.change).toBeDefined();
      //   controller.change(content);
      // });

    });
  });
})();
