(function () {
  'use strict';
  /**
   * This controller is for updateing special types.
   */
  angular
    .module('ptabe2e')
    .controller('SpecialTypesController', function (partiesData, ngDialog, CONSTANTS, HttpFactory, $scope, CommonHelperService) {

      $scope.shareAssign = partiesData;
      $scope.disableSave = true;
      // $scope.fastTrackAdded = true;
      /* istanbul ignore next*/
      $scope.getSpecialTypes = function () {
        HttpFactory.getActions("/appeals/special_type/" + $scope.shareAssign.applicationNumber + "/" + $scope.shareAssign.appealNumber)
          .then(function (successResponse) {
              $scope.specialTypesList = successResponse.data.allTypes;
              $scope.existingList = successResponse.data.exsistingTypes;
              for (var i = $scope.specialTypesList.length - 1; i >= 0; i--) {
                for (var j = 0; j < $scope.existingList.length; j++) {
                  if($scope.existingList[j].typeNameText === "SP" || $scope.existingList[j].typeNameText === "FC" || $scope.existingList[j].typeNameText === "FG") {
                    $scope.fastTrackAdded = false;
                  }
                  if ($scope.specialTypesList[i] && ($scope.specialTypesList[i].specialTypeIdentifier === $scope.existingList[j].specialTypeIdentifier)) {
                    $scope.specialTypesList.splice(i, 1);
                  }
                }
              }
            },
            function () {
              //intentional
            });
      };

      /* istanbul ignore next*/
      $scope.getRealPartiesData = function () {
        HttpFactory.getActions(CONSTANTS.URL.APPEAL_METADATA + "?caseNumber=" + $scope.shareAssign.applicationNumber + "&appealNumber=" + $scope.shareAssign.appealNumber)
          .then(function (successResponse) {
              $scope.realAppellants = successResponse.data.appeal.appellants;
              $scope.realRealParties = successResponse.data.appeal.realParties;
              $scope.realPatentOwners = successResponse.data.appeal.patentOwners;
              $scope.realThirdPartyRequestor = successResponse.data.appeal.thirdPartyRequestor;
              $scope.originalSelectedCols = angular.copy($scope.selectedCols);
              $scope.originalSelectedThirdPartyCols = angular.copy($scope.selectedThirdPartyCols);
            },
            function () {
              //intentional
            });
      };
      $scope.getRealPartiesData();


      $scope.listUp = function (array, itemIndex) {
        $scope.moveItem(array, itemIndex, itemIndex - 1);
      };

      $scope.listDown = function (array, itemIndex) {
        $scope.moveItem(array, itemIndex, itemIndex + 1);
      };

      /* istanbul ignore next*/
      $scope.moveItem = function (array, origin, destination) {
        var temp = array[destination];
        array[destination] = array[origin];
        array[origin] = temp;
      };
      /* istanbul ignore next*/
      $scope.checkKey = function () {
        if ($scope.otherAppellantData.length > 0) {
          $scope.otherAppellantData = [];
          $scope.setData();
        } else {
          $scope.setData();
        }
        $scope.clickedColumn = $scope.otherAppellantData;
      };

      /* istanbul ignore next*/
      $scope.setData = function () {
        $scope.otherAppellantData.push({
          key: $scope.otherAppellant,
          value: "otherData"
        });
      };

      /* istanbul ignore next*/
      $scope.moveSourcetoDestination = function () {
        angular.forEach($scope.availableColumn, function (column) {
          $scope.existingList.push(column);
          if ($scope.specialTypesList.includes(column)) {
            $scope.specialTypesList.splice($scope.specialTypesList.indexOf(column), 1);
          }
        });
      };
      /* istanbul ignore next*/
      $scope.moveDestinationtoSource = function () {
        angular.forEach($scope.existingColumn, function (column) {
          $scope.specialTypesList.push(column);
          if ($scope.existingList.includes(column)) {
            $scope.existingList.splice($scope.existingList.indexOf(column), 1);
          }
        });
      };
      /* istanbul ignore next*/
      $scope.moveSourcetoDestinationData = function () {

        angular.forEach($scope.clickedColumn, function (column) {
          $scope.selectedThirdPartyCols.push(column);
          if ($scope.sortAssigneesData.includes(column)) {
            $scope.sortAssigneesData.splice($scope.sortAssigneesData.indexOf(column), 1);
          }
          if ($scope.sortApplicantsData.includes(column)) {
            $scope.sortApplicantsData.splice($scope.sortApplicantsData.indexOf(column), 1);
          }
          if ($scope.sortInventorsData.includes(column)) {
            $scope.sortInventorsData.splice($scope.sortInventorsData.indexOf(column), 1);
          }
          if ($scope.sortThirdPartyData.includes(column)) {
            $scope.sortThirdPartyData.splice($scope.sortThirdPartyData.indexOf(column), 1);
          }
        });
        $scope.closeSaveAndClose();
        $scope.clickedColumn = [];
        $scope.otherAppellantData = [];
        $scope.otherAppellant = "";

      };

      /* istanbul ignore next*/
      $scope.closePartiesData = function () {
        var data = false;
        if (!angular.equals($scope.originalSelectedCols, $scope.selectedCols) || !angular.equals($scope.originalSelectedThirdPartyCols, $scope.selectedThirdPartyCols)) {
          $scope.openUnsavedChanges(event, data);
        } else {
          closeSaveDialog(1);
        }
      };

      $scope.closeSaveAndClose = function () {
        if (!angular.equals($scope.originalSelectedCols, $scope.selectedCols) && $scope.selectedCols.length > 0) {
          $scope.disableSave = false;
        } else {
          $scope.disableSave = true;
        }
      };

      /* istanbul ignore next*/
      function closeSaveDialog(popupsToClose) {
        var openDialogs = ngDialog.getOpenDialogs();
        if (openDialogs.length > 1) {
          ngDialog.close(openDialogs[openDialogs.length - popupsToClose], true);
        } else {
          ngDialog.closeAll(true);
        }
      }

      $scope.moveSourcetoDestinationCancel = function (data, index) {
        if (data.value === "assignees") {
          $scope.sortAssigneesData.push(data);
        }
        if (data.value === "applicants") {
          $scope.sortApplicantsData.push(data);
        }
        if (data.value === "inventors") {
          $scope.sortInventorsData.push(data);
        }
        if (data.value === "thirdPartyRequesters") {
          $scope.sortThirdPartyData.push(data);
        }
        $scope.selectedCols.splice(index, 1);
        $scope.closeSaveAndClose();
      };

      $scope.moveSourcetoDestinationDataCancel = function (data, index) {
        if (data.value === "assignees") {
          $scope.sortAssigneesData.push(data);
        }
        if (data.value === "applicants") {
          $scope.sortApplicantsData.push(data);
        }
        if (data.value === "inventors") {
          $scope.sortInventorsData.push(data);
        }
        if (data.value === "thirdPartyRequesters") {
          $scope.sortThirdPartyData.push(data);
        }
        $scope.selectedThirdPartyCols.splice(index, 1);
        $scope.closeSaveAndClose();
      };
      /* istanbul ignore next*/
      $scope.moveAllToDest = function () {
        angular.forEach($scope.specialTypesList, function (data) {
          $scope.existingList.push(data);
        });
        $scope.specialTypesList = [];
      };
      /* istanbul ignore next*/
      $scope.moveAllToSource = function () {
        angular.forEach($scope.existingList, function (data) {
          $scope.specialTypesList.push(data);
        });
        $scope.existingList = [];
      };
      /* istanbul ignore next*/
      $scope.saveSpecialTypes = function () {
        $scope.appealSpecialTypes = [];

        angular.forEach($scope.existingList, function (column) {
          var specialType = {
            "fkSpecialTypId": column.specialTypeIdentifier,
            "isChecked": true,
            "typeNameText": column.typeNameText
          };
          $scope.appealSpecialTypes.push(specialType);
        });

        var postData = {
          "serialNumber": $scope.shareAssign.applicationNumber,
          "appealNumber": $scope.shareAssign.appealNumber,
          "lifeCycle": null,
          "audit": {
            "lastModifiedTimestamp": new Date().getTime(),
            "lastModifiedUserIdentifier": $scope.shareAssign.workerNumber,
            "createUserIdentifier": $scope.shareAssign.workerNumber,
            "lastModifiedUserName": $scope.shareAssign.fullName,
            "createTimestamp": new Date().getTime(),
            "lockControlNumber": 0
          },
          "specialTypes": $scope.appealSpecialTypes

        };

        for (var s = 0; s < $scope.appealSpecialTypes.length; s++) {
          if($scope.shareAssign.appealType=="Heard" && $scope.shareAssign.panelInString==""&& ($scope.appealSpecialTypes[s].typeNameText === "SP" || $scope.appealSpecialTypes[s].typeNameText === "FC" || $scope.appealSpecialTypes[s].typeNameText === "FG") && $scope.fastTrackAdded == undefined) {
            $scope.fastTrackAdded = true;
          }
        }

        if($scope.fastTrackAdded){
          $scope.openFastTrackConfirmation(postData);
        }else{
        HttpFactory.putActions("/appeals/special_type", postData)
          .then(function (successResponse) {
            $scope.warningMessage = successResponse.data.warningMessage;
            $scope.disableSave = true;
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(CONSTANTS.TOASTER.specialTypesControllerSuccess, "success");
            if(null != $scope.warningMessage && $scope.warningMessage != ""){
              $scope.openSpecialTypeWarning($scope.warningMessage);
            }
            if ($scope.close) {
              closeSaveDialog(1);
            }
          }, function (failureResponse) {
            CommonHelperService.setToastr("", "clear");
            CommonHelperService.setToastr(failureResponse.data.message, "error");
          });
        }
      };
      /* istanbul ignore next*/
      $scope.saveCloseSpecialTypes = function () {
        $scope.close = true;
        $scope.saveSpecialTypes();
      };
      /* istanbul ignore next*/
      $scope.savePostInventors = function () {
        $scope.close = false;
        $scope.postInventors();
      };

      
      $scope.openFastTrackConfirmation = function (postData) {

        ngDialog.open({
          template: 'app/caseViewer/specialTypeFastTrackWaived.html',
          controller: 'SpecialTypesFastTrackController',
          width: '25%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            specialTypesData: function () {
              return postData;
            }
          }
        });
      };

      $scope.openSpecialTypeWarning = function (warningMessage) {
        ngDialog.open({
          template: 'app/caseViewer/specialTypesUpdateWarning.html',
          width: '25%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          data: {
            message: warningMessage
          }
        });
      };

    });
})();
