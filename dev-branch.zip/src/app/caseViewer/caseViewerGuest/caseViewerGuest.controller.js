(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('CaseViewerGuestController', function (ngDialog) {

      ngDialog.open({
        template: 'app/caseViewer/caseViewerGuest/caseViewerGuestModal.html',
        controller: 'CaseViewerGuestModalController',
        controllerAs: 'vm',
        width: '30%',
        showClose: false,
        closeByEscape: false,
        closeByDocument: false
      });
    });
})();
