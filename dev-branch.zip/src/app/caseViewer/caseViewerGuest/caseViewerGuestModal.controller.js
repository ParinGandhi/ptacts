(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('CaseViewerGuestModalController', function (CommonHelperService, HttpFactory, CONSTANTS, $window, ngDialog) {
      var vm = this;
      vm.invalidNumber = false;

      vm.viewCase = function () {
        vm.isTrials = vm.caseNumber.match(/[a-z]/i) ? true : false;
        if(!vm.isTrials){
          vm.caseNumber = vm.caseNumber.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, '');
        }
        if (vm.caseNumber.toUpperCase().indexOf('DER') >= 0) {
          CommonHelperService.getRedirectUrl();
          return false;
        }
        HttpFactory.getActions(CONSTANTS.URL.CASE_SEARCH + vm.caseNumber)
          .then(function (successResponse) {
            vm.appealNumber = successResponse.data.appealNumber;
            vm.serialNumber = successResponse.data.serialNumber;
            if (vm.appealNumber === null || vm.serialNumber === null) {
              CommonHelperService.setToastr("Case or application number " + vm.caseNumber + " not found. Please check the number and try again.", "error");
              vm.invalidNumber = true;
            } else {
              $window.sessionStorage.setItem("fromCVGuest", "0");
              $window.open("#/caseViewer/" + vm.serialNumber[0] + "/" + vm.appealNumber[0], "_self");
              ngDialog.closeAll();
            }

          }, function () {
            CommonHelperService.setToastr("Case or application number " + vm.caseNumber + " not found. Please check the number and try again.", "error");
            vm.invalidNumber = true;
          });

      };

    });
})();
