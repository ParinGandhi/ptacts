(function () {
  'use strict';

  describe('CaseViewerGuestController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['open']);
    var controller, scope, $rootScope, $CommonHelperService;
    var timeout;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;


    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory, _CommonHelperService_) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      $CommonHelperService = _CommonHelperService_;
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn($CommonHelperService, 'setToastr').and.callFake(function () {
        return "toastr";
      });


      controller = $controller('CaseViewerGuestController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory

      });
    }));

    describe('CaseViewerGuestController ', function () {

      it('it should open case viewer guest dialog ', function () {
        expect(ngDialog.open).toHaveBeenCalled();
      });



    });
  });
})();
