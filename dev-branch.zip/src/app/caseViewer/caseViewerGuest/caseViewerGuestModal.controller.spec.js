(function () {
  'use strict';

  describe('CaseViewerGuestModalController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'close']);
    var controller, scope, $rootScope, $CommonHelperService;
    var timeout;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;


    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory, _CommonHelperService_) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      $CommonHelperService = _CommonHelperService_;
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn($CommonHelperService, 'setToastr').and.callFake(function () {
        return "toastr";
      });


      controller = $controller('CaseViewerGuestModalController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory

      });
    }));

    describe('CaseViewerGuestModalController ', function () {

      it('it should call viewCase with IPR case', function () {
        controller.caseNumber = "IPR-12345678";
        expect(controller.viewCase).toBeDefined();
        controller.viewCase();
        // expect(ngDialog.close).toHaveBeenCalled();
      });

      it('it should call viewCase with CBM case', function () {
        controller.caseNumber = "CBM-12345678";
        expect(controller.viewCase).toBeDefined();
        controller.viewCase();
        // expect(ngDialog.close).toHaveBeenCalled();
      });

      it('it should call viewCase with PGR case', function () {
        controller.caseNumber = "PGR-12345678";
        expect(controller.viewCase).toBeDefined();
        controller.viewCase();
        // expect(ngDialog.close).toHaveBeenCalled();
      });

      it('it should call viewCase with DER case', function () {
        controller.caseNumber = "DER-12345678";
        expect(controller.viewCase).toBeDefined();
        controller.viewCase();
        // expect(ngDialog.close).toHaveBeenCalled();
      });

      it('it should call viewCase with appeals case', function () {
        var successResponse = {
          data: {
            "serialNumber": ["14620653"],
            "sequenceNumber": null,
            "appealNumber": ["2019003831"],
            "lifeCycle": null,
            "audit": null
          }
        };
        controller.caseNumber = "2019003831";
        expect(controller.viewCase).toBeDefined();
        controller.viewCase();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
      });

      it('it should call viewCase with appeals case with null serial number', function () {
        var successResponse = {
          data: {
            "serialNumber": null,
            "sequenceNumber": null,
            "appealNumber": ["2019003831"],
            "lifeCycle": null,
            "audit": null
          }
        };
        controller.caseNumber = "2019003831";
        expect(controller.viewCase).toBeDefined();
        controller.viewCase();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
      });

      it('it should call viewCase with appeals case with null appeal number', function () {
        var successResponse = {
          data: {
            "serialNumber": ["14620653"],
            "sequenceNumber": null,
            "appealNumber": null,
            "lifeCycle": null,
            "audit": null
          }
        };
        controller.caseNumber = "2019003831";
        expect(controller.viewCase).toBeDefined();
        controller.viewCase();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
      });


      it('it should call viewCase with appeals case with failureResponse', function () {
        failureResponse = {
          data: {
            message: "Some error message"
          },
          status: 404

        };
        controller.caseNumber = "2019003831";
        expect(controller.viewCase).toBeDefined();
        controller.viewCase();
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });

    });
  });
})();
