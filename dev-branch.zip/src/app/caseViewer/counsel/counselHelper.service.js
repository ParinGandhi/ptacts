'use strict';
angular.module('ptabe2e').factory('CounselHelperService', function () {

  var counselHelperService = {
    getLeadAndFirstBackupCounsel: getLeadAndFirstBackupCounsel,
    getRealPartyInformationGrid: getRealPartyInformationGrid
  };


  function getRealPartyInformationGrid() {
    var realParty = {
      enableColumnMenus: false,
      columnDefs: [{
          name: 'Type',
          width: 105,
          displayName: 'Type',
          headerTooltip: 'Type',
          cellTooltip: true,
          field: 'type'
        },
        {
          name: 'name',
          displayName: 'Name',
          width: 275,
          headerTooltip: 'Name',
          cellTooltip: true,
          field: 'organizationOrIndividual',
        },
        {
          name: 'email',
          displayName: 'Email',
          headerTooltip: 'Email address',
          cellTooltip: true,
          field: 'email',
          cellTemplate: "<div style=\"margin-left: 5px;\" class=\"ui-grid-cell-contents\"><a title='{{row.entity.partyEmails[0].email}}' href='mailto:{{row.entity.partyEmails[0].email}}'>{{row.entity.partyEmails[0].email}}</a></div>"
        },
        {
          name: 'address',
          displayName: 'Mailing address',
          headerTooltip: 'Mailing address',
          cellTooltip: true,
          width: 240,
          field: 'postalInformation',
        }
      ]
    };
    return realParty;

  }


  function getLeadAndFirstBackupCounsel() {
    var gridPetitionerCounsels = {
      enableColumnMenus: false,
      columnDefs: [{
          name: 'role',
          width: 105,
          displayName: 'Role',
          headerTooltip: 'Counsel role',
          cellTooltip: true,
          field: 'role'
        },
        {
          name: 'name',
          displayName: 'Name',
          headerTooltip: 'Name',
          width: 180,
          cellTooltip: true,
          field: 'name',
          cellTemplate: "<div  title='{{row.entity.firstName}} {{row.entity.lastName}}' style=\"margin-left: 5px;\" class=\"ui-grid-cell-contents\" >{{row.entity.firstName}} {{row.entity.lastName}}</div>",
        },
        {
          name: 'patentRegistrationNumber',
          displayName: 'USPTO reg #',
          width: 95,
          headerTooltip: 'USPTO registration number',
          cellTooltip: true,
          field: 'patentRegistrationNumber',
        },
        {
          name: 'email',
          displayName: 'Email',
          headerTooltip: 'Email address',
          cellTooltip: true,
          field: 'email',
          cellTemplate: "<div style=\"margin-left: 5px;\" class=\"ui-grid-cell-contents\"><a title='{{row.entity.partyEmails[0].email}}' href='mailto:{{row.entity.partyEmails[0].email}}'>{{row.entity.partyEmails[0].email}}</a></div>"
        },
        {
          name: 'Phone',
          displayName: 'Phone',
          headerTooltip: 'Phone number',
          cellTooltip: true,
          width: 100,
          field: 'phone',
        },
        {
          name: 'Fax',
          displayName: 'Fax',
          headerTooltip: 'Fax number',
          cellTooltip: true,
          width: 100,
          field: 'fax'

        }
      ]
    };
    return gridPetitionerCounsels;
  }


  return counselHelperService;
});
