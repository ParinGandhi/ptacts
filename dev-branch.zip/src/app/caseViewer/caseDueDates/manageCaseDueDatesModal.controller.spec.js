(function () {
  'use strict';

  describe('ManageCaseDueDatesController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['closeAll', 'close']);
    var controller, scope, $rootScope, $CommonHelperService;
    var timeout;
    var $httpBackend, spy, $q, HttpFactoryDeferred, successResponse, failureResponse;
    var caseDueDates, userInfo, applicationInfo, isTrial;


    beforeEach(inject(function (_$controller_, _$rootScope_, _$q_, HttpFactory, _CommonHelperService_) {
      $q = _$q_;
      $controller = _$controller_;
      scope = _$rootScope_.$new();
      $rootScope = _$rootScope_;
      HttpFactoryDeferred = _$q_.defer();
      $CommonHelperService = _CommonHelperService_;
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn($CommonHelperService, 'setToastr').and.callFake(function () {
        return "toastr";
      });


      controller = $controller('ManageCaseDueDatesController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        caseDueDates: caseDueDates,
        HttpFactory: HttpFactory,
        userInfo:userInfo,
        applicationInfo:applicationInfo,
        isTrial:isTrial

      });
    }));

    describe('ManageCaseDueDatesController ', function () {

      it('it should call closeManageDialog ', function () {
        expect(controller.closeManageDialog).toBeDefined();
        controller.closeManageDialog();
        // expect(ngDialog.close).toHaveBeenCalled();
      });

      it('should call cancelChanges', function () {
        expect(controller.cancelChanges).toBeDefined();
        controller.cancelChanges();
      });

      it('should call saveChanges', function () {
        var row = {
          date: null,
          lastModifiedTS: null
        }
        expect(controller.saveChanges).toBeDefined();
        controller.saveChanges(row);
      });

      it('should call addNewDueDate', function () {
        expect(controller.addNewDueDate).toBeDefined();
        controller.addNewDueDate();
      });

      it('should call addNewDueDate with valid inputs', function () {
        controller.selectedDueDateType = "some type";
        controller.newDueDate = new Date();
        expect(controller.addNewDueDate).toBeDefined();
        controller.addNewDueDate();
      });

      it('should call editDueDate', function () {
        var row = {
          date: new Date()
        }
        expect(controller.editDueDate).toBeDefined();
        controller.editDueDate(1, row);

      });

    });
  });
})();
