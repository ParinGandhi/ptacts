(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('ManageCaseDueDatesController', function ($log, caseDueDates, isTrial, $timeout, CONSTANTS, ngDialog, userInfo, applicationInfo, HttpFactory, CommonHelperService) {
      var vm = this;
      vm.caseDueDates = caseDueDates;
      vm.inEditState = false;
      vm.disbale = false;
      vm.addNewDate = false;
      vm.copyOfCaseDueDates = [];
      vm.caseDueDateNames = [{
          "id": 1,
          "description": "Hearing decision due date"
        },
        {
          "id": 2,
          "description": "Rehearing decision due date"
        },
        {
          "id": 3,
          "description": "Quarterly close out   "
        },
        {
          "id": 4,
          "description": "Appeal decision due date"
        },
        {
          "id": 5,
          "description": "Oldest on brief decision due date"
        },
        {
          "id": 6,
          "description": "Court remand decision due date"
        },
        {
          "id": 7,
          "description": "Court mandate decision due date"
        }
      ];

      vm.closeManageDialog = function () {
        ngDialog.close();
      };

      vm.editDueDate = function (index, row) {
        vm.inEditState = true;
        vm.selectedRow = index;
        vm.originalDueDate = row.date;
        vm.editedDueDate = row.date;
      };

      vm.cancelChanges = function () {
        vm.selectedRow = null;
        vm.inEditState = false;
      };
      vm.putCaseDueDates = function () {
        vm.copyOfCaseDueDates = [];
        vm.caseDueDates.forEach(function (element) {
          if (element.date && element.date !== "") {
            element.date = new Date(element.date).getTime();
          } else {
            element.date = null;
          }
          if (element.label && element.label !== "") {
            //intentional
          } else {
            element.label = null;
          }
          vm.copyOfCaseDueDates.push(element);
        });
        // vm.copyOfCaseDueDates = JSON.parse(JSON.stringify(vm.caseDueDates))

        var obj = {
          "applicationUserId": userInfo.userIdentiifier,
          "serialNumber": applicationInfo.applicationNumber,
          "appealNumber": applicationInfo.caseNumber,
          "proceedingType": isTrial ? "TRIAL" : "APPEAL",
          "audit": {
            "lastModifiedUserIdentifier": userInfo.loginId,
            "lockControlNumber": 0,
            "lastModifiedTimestamp": new Date().getTime(),
            "createUserIdentifier": userInfo.loginId,
            "createTimestamp": new Date().getTime()
          },
          "definedDates": vm.copyOfCaseDueDates
        };
        HttpFactory.putActions(CONSTANTS.URL.CUSTOM_DATES, obj)
          .then(function (successResponse) {
            $log.info(successResponse);
            CommonHelperService.setToastr(CONSTANTS.TOASTER.manageCaseDueDate, "success");
            ngDialog.closeAll(true);
          }, function (error) {
            CommonHelperService.setToastr(error.data.message, "error");
          });
      };

      vm.disablSave = function () {
        $timeout(function () {
          var count = 0;
          vm.disbale = false;
          vm.caseDueDates.forEach(function (element) {
            if ((element.date && !element.label) || (element.date && element.label.trim() === "")) {
              count++;
            }
          });
          if (count > 0) {
            vm.disbale = true;
          }
        }, 200);
      };

      vm.saveChanges = function (row) {
        CommonHelperService.setToastr(CONSTANTS.TOASTER.manageDueDateUpdateSuccessful, "success");
        row.date = vm.editedDueDate;
        row.lastModifiedTS = new Date().getTime();
        vm.cancelChanges();
      };

      vm.addNewDueDate = function () {
        if (inputsAreValid()) {
          //save new date
          CommonHelperService.setToastr(CONSTANTS.TOASTER.manageDueDateSuccessful, "success");
        }
      };

      function inputsAreValid() {
        var validInputs = true;
        if (angular.isUndefined(vm.selectedDueDateType) || vm.selectedDueDateType === null) {
          CommonHelperService.setToastr(CONSTANTS.TOASTER.manageValidDueDt, "warning");
          validInputs = false;
        }
        if (angular.isUndefined(vm.newDueDate) || vm.newDueDate === null) {
          CommonHelperService.setToastr(CONSTANTS.TOASTER.manageSelectDueDt, "warning");
          validInputs = false;
        }
        return validInputs;
      }

    });
})();
