(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('InitiateRemandDismissalController', function (caseInfo, ngDialog, HttpFactory, CONSTANTS, $window, CirculationHelperService, toastr, AssignmentHelperService) {
      var vm = this;
      vm.petition = caseInfo.petition;
      var remandDismissalInfo = caseInfo;
      vm.isRemand = caseInfo.isRemand;
      vm.assignedTo = false;
      vm.submitButtonText = 'Submit for draft creation';
      if (vm.petition) {
        vm.applicationNumberTxt = caseInfo.applicationNumber;
        if (caseInfo.appealNumberText==="Pending") {
          vm.appealNumberTxt = "0";
        } else {
          vm.appealNumberTxt = caseInfo.appealNumberText
        }
        vm.assigneePlaceholders='Loading assignees...';
        vm.submitButtonText= 'Submit for processing';

        checkPetitionInProgress();
        
      } else {
        getAssigneeList($window.sessionStorage.getItem("workerNumber"));
      }

      function getAssigneeList(workerNumber) {
        HttpFactory.getActions(CONSTANTS.URL.ASSIGNEEUSERS + workerNumber)
          .then(function (assigneeListSuccess) {
            console.log('assigneeListSuccess: ', assigneeListSuccess);
            vm.myMangers = assigneeListSuccess.data.managersData;
            vm.myTeamData = assigneeListSuccess.data.teamData;
            vm.myGroupData = assigneeListSuccess.data.groupData;
            vm.workQueueData = assigneeListSuccess.data.workQueueData;
            if (vm.petition) {
              combineAsignees();
            }
            if (vm.myGroupData === null) {
              vm.moreAssignees = true;
            } else {
              vm.groupLength = vm.myGroupData.length;
              if (vm.groupLength === 0) {
                vm.moreAssignees = true;
              }
            }

            if (vm.petition) {
              vm.currentAssignee= getDefaultAssigneeObject();
              if (vm.currentAssignee) {
                vm.setSelectedJudge(vm.currentAssignee);
              }
              
              vm.assignedTo = true;
            }

            if (!vm.currentAssignee) {
              vm.currentAssignee = {
                assigneeFullNameText: 'Not assigned',
                activeCaseCount: '',
                assigneeStatus: '',
                assigneeNumberText: ""
              };
              vm.assignedTo = false;
            } else {
              vm.assignedTo = true;
            }
            vm.originalcurrentAssignee = angular.copy(vm.currentAssignee);
            vm.change(vm.currentAssignee);
          }, function (assigneeListFailure) {
            console.log('assigneeListFailure: ', assigneeListFailure);
          });
      }

      function addUsersToList(users) {
        angular.forEach(users, function(aUser) {
          vm.allUsers.push(aUser);
        });
      }


      function combineAsignees() {
        vm.allUsers=[];
        addUsersToList(vm.myMangers);
        addUsersToList(vm.myTeamData);
        addUsersToList(vm.myGroupData);
        addUsersToList(vm.workQueueData);
        vm.backupAllUsers = angular.copy(vm.allUsers);
        vm.assigneePlaceholders="Select assignee";

      }

      function getDefaultAssigneeObject(workerNumber) {
        for (var i=0; i<vm.myTeamData.length; i++) {
          if (vm.myTeamData[i].assigneeNumberText===vm.defaultUser.valueText) {
            return vm.myTeamData[i];
          }
        }
        return null;
      }

      function checkPetitionInProgress() {
        vm.applicationNumberTxt = caseInfo.applicationNumber;
        if (caseInfo.appealNumberText==="Pending") {
          vm.appealNumberTxt = "0";
        }

        var searchAppealNumber = vm.appealNumberTxt;
        if (vm.appealNumberTxt==="0")  {
          searchAppealNumber = "99" + vm.applicationNumberTxt
        }
        AssignmentHelperService.checkPetitionInProgress(vm.applicationNumberTxt, searchAppealNumber).then(function(theResponse) {
          if (!theResponse.data) {
            getDefaultUser();
          } else {
            vm.petitionInProgress=true;
            vm.assigneePlaceholders="";
            vm.customDisabled=true;
            vm.assignmentDueDate='';
          }
        });
  
      }
      function getDefaultUser() {
        AssignmentHelperService.getDefaultUser(CONSTANTS.URL.DEFAULT_PETITION_USER).then(function(returnValue) {
          vm.defaultUser=returnValue;
          getAssigneeList(returnValue.descriptionText);
        });   
      }

      vm.change = function (content) {
        vm.currentAssignee.assigneeFullNameText = content.assigneeFullNameText;
        vm.currentAssignee.activeCaseCount = content.activeCaseCount;
        vm.currentAssignee.assigneeStatus = content.assigneeStatus;
        vm.currentAssignee.assigneeNumberText = content.assigneeNumberText;
        vm.assignedTo = true;
      };

      vm.moreAssigneesData = function () {
        vm.extraData = false;
        vm.moreAssignees = true;
        vm.myGroup = vm.myGroupData;
      };

      function setAssignmentDueDate() {
        var nextBusinessDay = new Date();
        if (!vm.petition) {
          var numberOfDays = 2;
          nextBusinessDay.setDate(nextBusinessDay.getDate() + numberOfDays);
          while (!CirculationHelperService.isBusinessDay(nextBusinessDay)) {
            nextBusinessDay.setDate(nextBusinessDay.getDate() + 1);
          }
        }

        vm.assignmentDueDate = nextBusinessDay;
      }

      setAssignmentDueDate();

      vm.submitDraft = function () {
        if (vm.petition) {
          createAssignmentAction();
          return;
        }
        remandDismissalInfo.assignmentDueDate = vm.assignmentDueDate.getTime();
        remandDismissalInfo.assignedTo = vm.currentAssignee.assigneeNumberText;
        remandDismissalInfo.addedNotes = vm.addedNotes;
        remandDismissalInfo.isRemand = vm.isRemand;
        ngDialog.open({
          template: 'app/caseViewer/initiateRemandDismissalConfirmation.modal.html',
          controller: 'RemandDismissalConfirmationController',
          controllerAs: 'vm',
          width: '30%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            remandDismissalInfo: function () {
              return remandDismissalInfo;
            }
          }
        }).closePromise.then(function (response) {
          vm.saveInProgress=false;
          if (response.value) {
            ngDialog.closeAll(true);
          }
        });
      };

      vm.cancelInitiate = function () {
        ngDialog.closeAll(false);
      };

      function createAssignmentAction() {

        var appealNumber = remandDismissalInfo.appealNumberText;
        try {
          if (appealNumber.indexOf("Pending")>=0) {
            appealNumber = "0";
          }
        } catch(error) {
          console.info(error);
        }

        if (appealNumber ==="0") {
          appealNumber = "99" + remandDismissalInfo.applicationNumber.toString();
        }

        vm.saveInProgress=true;
        var createAssignment = {};
        createAssignment.assignmentType = "PCPD";
        createAssignment.dueDate = vm.assignmentDueDate.getTime();
        if (vm.petition) {
          createAssignment.assignee = vm.selectedAssignmentType.assigneeNumberText;
        } else {
          createAssignment.assignee = vm.currentAssignee.assigneeNumberText;  
        }
        
        createAssignment.appealNumber = appealNumber;
        createAssignment.serialNumber = remandDismissalInfo.applicationNumber;
        createAssignment.priorityIndicator="N";
        createAssignment.sequenceNumber=1;
        createAssignment.title="Create petition draft";
        createAssignment.audit = {
          createUserIdentifier:remandDismissalInfo.user.loginId,
          lastModifiedUserIdentifier: remandDismissalInfo.user.loginId
        };

        if (vm.addedNotes) {
          createAssignment.notes = vm.addedNotes;
        }

        HttpFactory.postActions(CONSTANTS.URL.CREATEASSIGNMENT, createAssignment)
        .then(function (successResponse) {
          updatePopulation(createAssignment);
        }, function (failureResponse) {
          vm.saveInProgress=false;
          vm.saveInProgress=false;
         console.info(failureResponse);
          toastr.clear();
          toastr.error(failureResponse.data.message, {
            iconClass: 'toast-danger'
          });

        });
      }
      function createPetitionNumber(createAssignment) {
        ngDialog.closeAll(true);
      }

      function updatePopulation(createAssignment)  {
        AssignmentHelperService.calUpdatePopulation(createAssignment).then(function(response) {
          if (!response) {
            createPetitionNumber(createAssignment);
          } else {
            vm.saveInProgress=false;
            vm.saveInProgress=false;
            toastr.clear();
            toastr.error(failureResponse.data.message, {
              iconClass: 'toast-danger'
            });
          }
        });
      }

     vm.assignmentListEnterKey = function(event) {
        if (event.keyCode===13) {
          if (vm.allUsers.length>0) {
           vm.setSelectedJudge(vm.allUsers[0]);
           vm.dontMakeVisible=true;
          }
        }
      }
    
      vm.showJudgeList = function () {
        if (vm.assigneePlaceholders==='Loading assignees...') {
          return;
        }
    
        if (vm.dontMakeVisible) {
            vm.dontMakeVisible=false;
        return;
        }
        if (!vm.judgeListVisible) {
          vm.judgeListVisible = !vm.judgeListVisible;
        }
      };
    
      vm.setSelectedJudge = function (judge) {
        if (judge.assigneeFullNameText !== "Select assignee") {
         vm.selectedAssignmentType = judge;
        } else {
          vm.selectedAssignmentType={};
        }
        vm.judgeListVisible=false;
      };
    
    
      vm.selectJudgeEntered = function(event, judge) {
        if (event.keyCode === 13) {
          vm.setSelectedJudge(judge);
        }
      };
    
      vm.searchForJudge = function (input) {
        vm.judgeListVisible=true;
        var tempList = [];
        if (angular.isDefined(input) && input.assigneeFullNameText.trim() !== "") {
          angular.forEach(vm.backupAllUsers, function (currentJudge) {
            if (currentJudge.assigneeFullNameText.toLowerCase().includes(input.assigneeFullNameText.toLowerCase())) {
              tempList.push(currentJudge);
            }
          });
          vm.allUsers = angular.copy(tempList);
        } else {
          vm.allUsers = angular.copy(vm.backupAllUsers);
        }
      };

  });
})();
