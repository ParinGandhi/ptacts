(function () {
  'use strict';

  describe('preappealDataController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var controller, scope, $rootScope;
    //   var successResponse;
    //   var $httpBackend, spy, $q, HttpFactoryDeferred;
    var $ngDialog = jasmine.createSpyObj('ngDialog', ['open']);

    //   var fakeElement = function (params) {
    //     return {
    //       scope: function () {
    //         return {
    //           vm: {
    //             getWidgetZone: function () {

    //             },
    //             setWidgetContentHeight: function () {

    //             }
    //           }
    //         }
    //       }
    //     }
    //   };

    beforeEach(inject(function (_$controller_, _$rootScope_) {
      //   $q = _$q_;
      scope = _$rootScope_.$new();
      $controller = _$controller_;
      $rootScope = _$rootScope_;
      //   $httpBackend = _$httpBackend_;
      // $ngDialog.open.and.returnValue({
      //   then: function (callback1, callback2) {
      //     callback1();
      //     callback2();
      //   }
      // });
      // HttpFactoryDeferred = _$q_.defer();
      // spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      // spy = spyOn(angular, 'element').and.callFake(fakeElement);

      controller = $controller('preappealDataController', {
        $scope: scope,
        ngDialog: $ngDialog,
        $rootScope: _$rootScope_,
        // HttpFactory: HttpFactory
      });
    }));

    describe('preappealDataController ', function () {

      it('it should call enableEdit ', function () {
        expect(scope.enableEdit).toBeDefined();
        scope.enableEdit();
      });

    });
  });
})();
