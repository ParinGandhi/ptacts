"use strict";
angular
  .module('ptabe2e')
  .controller('CaseViewerController',
    function (ngDialog, HttpFactory, toastr, $scope, $http, $timeout, uiGridConstants, $route, $sce,
      $log, $window, $location, $anchorScroll, CONSTANTS, $filter, $rootScope, SearchHelperService, CounselHelperService, CommonHelperService) {
      var vm = this;
      var paper = 0;
      if ($route.current.params.caseNumber && $route.current.params.caseNumber.match(/[a-z]/i)) {
            vm.isTrials = true;
            $scope.currentTab  = "documents";
      } else {
      	vm.isTrials=false;
      	$scope.currentTab = 'bib';
      }
      var exhibit = 0;
      vm.exhibitsFirst = true;
      vm.papersFirst = true;
      vm.maxSequenceNumbers = {};
      $scope.initialExhibitLoad = true;
      $scope.initialPaperLoad = true;
      $scope.initialDocumentLoad = true;
      var workerNumber;
      vm.isJudge = false;
      var rowInfo = $window.rowInfo;
      $log.info("Row from assignment widget: %o", rowInfo);
      vm.spinnerShow = false;
      vm.appealsSpinner = false;
      vm.showDownloadButton;
      /* istanbul ignore else */
      vm.gridOptionsStatus = {
        enableColumnResizing: true,
        enableHorizontalScrollbar: 2,
        enableGridMenu: true,
        useExternalFiltering: true,
        rowHeight: 35,
        exporterCsvFilename: 'StatusInteractionHistory.csv',
        exporterOlderExcelCompatibility: true,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        columnDefs: [{
            name: 'appealNumber',
            displayName: 'Appeal #',
            headerTooltip: 'Appeal #',
            cellTooltip: true,
            field: 'appealNumber',
            width: 100
          },
          {
            name: 'sequenceNumber',
            displayName: 'Sequence #',
            headerTooltip: 'Sequence #',
            cellTooltip: true,
            field: 'sequenceNumber',
            width: 98
          },
          {
            name: 'typeCode',
            displayName: 'Status',
            headerTooltip: 'Status',
            cellTooltip: true,
            field: 'typeCode',
            width: 390
          },
          {
            name: 'date',
            displayName: 'PTAB transaction date',
            headerTooltip: 'PTAB transaction date',
            cellTooltip: true,
            field: 'date',
            type: 'date',
            cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'",
            width: 120
          },
          {
            name: 'creditGrantedUserIdentifier',
            displayName: 'Completed by',
            headerTooltip: 'Completed by',
            cellTooltip: true,
            field: 'creditGrantedUserIdentifier'
          },
          {
            name: 'lastModifiedTimeStamp',
            displayName: 'Last modified date',
            headerTooltip: 'Last modified date',
            cellTooltip: true,
            field: 'lastModifiedTimeStamp',
            type: 'date',
            cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'",
            width: 160
          },
          {
            name: 'lastModifiedUserIdentifier',
            displayName: 'Updated by',
            headerTooltip: 'Updated by',
            cellTooltip: true,
            field: 'lastModifiedUserIdentifier'
          },
          {
            name: 'description',
            displayName: 'Action taken',
            headerTooltip: 'Action taken',
            cellTooltip: true,
            field: 'description',
            width: 390
          }
        ],
        enableFiltering: true
      };
      /* istanbul ignore next */
      vm.gridOptionsStatus.onRegisterApi = function (gridApi) {
        vm.gridApiStatus = gridApi;
        $scope.gridApiStatus = gridApi;
        $scope.gridApiStatus.core.on.filterChanged($scope, function () {
          var grid = this.grid;
          $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
          if ($scope.numberOfFilters === 0) {
            vm.gridOptionsStatus.data = angular.copy($scope.myData2);
          } else {
            var filteredData = SearchHelperService.filterGrid(grid, $scope.myData2);
            vm.gridOptionsStatus.data = filteredData;
          }
        });
      };
      vm.gridOptionsHistory = {
        enableColumnResizing: true,
        enableHorizontalScrollbar: 2,
        enableGridMenu: true,
        useExternalFiltering: true,
        rowHeight: 35,
        exporterCsvFilename: 'AssignmentsHistory.csv',
        exporterOlderExcelCompatibility: true,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        enableFiltering: true,
        columnDefs: [{
            name: 'assignmentStatusCode',
            displayName: 'Assignment status',
            headerTooltip: 'Assignment status',
            cellTooltip: true,
            field: 'assignmentStatusCode'
          },
          {
            name: 'completionDate',
            displayName: 'Completion/cancelled date',
            headerTooltip: 'Completion/cancelled date',
            cellTooltip: true,
            field: 'completionDate',
            type: 'date',
            cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'",
            sort: {
              direction: uiGridConstants.DESC,
              priority: 0
            }
          },
          {
            name: 'title',
            displayName: 'Assignment title',
            headerTooltip: 'Assignment title',
            cellTooltip: true,
            field: 'title',
            width: 170
          },
          {
            name: 'assignedDate',
            displayName: 'Assigned date',
            headerTooltip: 'Assigned date',
            cellTooltip: true,
            field: 'assignedDate',
            type: 'date',
            cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'"
          },
          {
            name: 'dueDate',
            displayName: 'Assignment due date',
            headerTooltip: 'Assignment due date',
            cellTooltip: true,
            field: 'dueDate',
            type: 'date',
            cellFilter: "date:'MM/dd/yyyy'"
          },
          {
            name: 'assignee',
            displayName: 'Assignee',
            headerTooltip: 'Assignee',
            cellTooltip: true,
            field: 'assignee'
          },
          {
            name: 'assignor',
            displayName: 'Assignor',
            headerTooltip: 'Assignor',
            cellTooltip: true,
            field: 'assignor'
          },
          {
            name: 'notes',
            displayName: 'Updates/notes',
            headerTooltip: 'Updates/notes',
            field: 'notes',
            cellTemplate: "<div title='{{row.entity.notes}}' style=\"margin-top:5px; margin-left:5px;\" class=\"ui-grid-cell-contents\" ng-bind-html=\"row.entity.notes\"></div>",
            type: 'string'
          },
          {
            name: 'audit.lastModifiedTimestamp',
            displayName: 'Update date(s)',
            headerTooltip: 'Update date(s)',
            field: 'lastModifiedTimestamp',
            type: 'date',
            cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'",
            cellTooltip: true
          },
          {
            name: 'audit.createTimestamp',
            displayName: 'Creation date',
            headerTooltip: 'Creation date',
            cellTooltip: true,
            field: 'createTimestamp',
            type: 'date',
            cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'"
          },
          {
            name: 'assignmentTypeDescription',
            displayName: 'Assignment type',
            headerTooltip: 'Assignment type',
            cellTooltip: true,
            field: 'assignmentTypeDescription'
          },
          {
            name: 'description',
            displayName: 'Description',
            headerTooltip: 'Description',
            cellTooltip: true,
            field: 'description'
          },
          {
            name: 'serialNumber',
            displayName: 'Application #',
            headerTooltip: 'Application #',
            cellTooltip: true,
            field: 'serialNumber'
          },
          {
            name: 'audit',
            displayName: 'Audit log',
            headerTooltip: 'Audit log',
            cellTooltip: true,
            field: 'audit',
            cellTemplate: '<div data-toggle="tooltip" title="Audit log" class="truncateTitle" ' +
              'style="cursor: pointer; margin-left: 8px; padding-top:5px; text-decoration: underline;">' +
              '<a ng-click="grid.appScope.openAssignHistory(row)" target="_blank" id="{{row.entity.assignmentIdentifier}}">' +
              'Audit log <i class="fas fa-external-link-alt"></i></a></div>'
          }
        ]
      };
      /*istanbul ignore next */
      vm.gridOptionsHistory.onRegisterApi = function (gridApi) {
        $scope.gridApi = gridApi;
        $scope.gridApi.core.on.filterChanged($scope, function () {
          var grid = this.grid;
          $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
          if ($scope.numberOfFilters === 0) {
            vm.gridOptionsHistory.data = $scope.myData1;
          } else {
            var filteredData = SearchHelperService.filterGrid(grid, $scope.myData1);
            vm.gridOptionsHistory.data = filteredData;
          }
        });
      };
      vm.gridPetitionersCounsels = CounselHelperService.getLeadAndFirstBackupCounsel();
      vm.gridPetitionersCounsels.data = [];
      vm.gridPatentOwnersCounsels = CounselHelperService.getLeadAndFirstBackupCounsel();
      vm.gridPatentOwnersCounsels.data = [];
      vm.gridPetitionersRealParty = CounselHelperService.getRealPartyInformationGrid();
      vm.gridPetitionersRealParty.data = [];
      vm.gridPatentOwnersRealParty = CounselHelperService.getRealPartyInformationGrid();
      vm.gridPatentOwnersRealParty.data = [];
      vm.gridAddtlPetitionersRealParty = CounselHelperService.getRealPartyInformationGrid();
      vm.gridAddtlPetitionersRealParty.data = [];
      vm.gridAddtlPatentOwnersRealParty = CounselHelperService.getRealPartyInformationGrid();
      vm.gridAddtlPatentOwnersRealParty.data = [];

      function buildCounselData(data, theGrid) {
        theGrid.data = [];
        var rankNumbers = ['Lead counsel', 'First backup', 'Backup'];
        angular.forEach(data, function (row) {
          if (row.partyPhones && row.partyPhones[0] && row.partyPhones[0].phone) {
            row.phone = getPhoneFormat(row.partyPhones[0].phone);
          }
          if (row.partyPhones && row.partyPhones[1] && row.partyPhones[1].phone) {
            row.fax = getPhoneFormat(row.partyPhones[1].phone);
          }
          switch (row.rankNo) {
            case '1':
              row.role = rankNumbers[0];
              break;
            case '2':
              row.role = rankNumbers[1];
              break;
            default:
              row.role = rankNumbers[2];
          }
          theGrid.data.push(row);
        });
      }

      function buildRealPartyData(data, realPartyGrid, addtlPartyGrid) {
        realPartyGrid.data = [];
        addtlPartyGrid.data = [];
        var index = 0;
        angular.forEach(data, function (row) {
          if (row.organizationName) {
            row.type = "Organization";
            row.organizationOrIndividual = row.organizationName;
          }
          if (row.firstName && row.organizationName === null) {
            row.type = "Individual";
            row.organizationOrIndividual = row.firstName + " " + row.lastName;
          }
          if (index === 0) {
            realPartyGrid.data.push(row);
          } else {
            addtlPartyGrid.data.push(row);
          }
          index++;
        });
      }

      function getPhoneFormat(value) {
        try {
          var country = value.slice(0, 3);
          var city = value.slice(3, 6);
          var number = value.slice(6);
          return "(" + country + ") " + city + "-" + number;
        } catch (error) {
          return "";
        }
      }

      vm.gridOptionsAiapapers = {
        columnDefs: [{
          name: 'paperNumber',
          displayName: 'Paper #',
          field: 'paperNumber',
          type: 'number',
        }]
      };

      vm.constructAllPapersDownload = function () {
        vm.spinnerShow = true;
        vm.downloadAllPapers = [];
        if (vm.allPapersCount !== 0) {
          vm.allCombinePapers.forEach(function (element) {
            vm.downloadAllPapers.push(element.contentManagementId);
          });
          vm.downloadPapers();
        } else {
          toastr.error("No papers to download", {
            iconClass: 'toast-danger',
            timeOut: 8000
          });
          vm.spinnerShow = false;
        }
      };

      vm.constructAllAiaDownload = function () {
        vm.spinnerShow = true;
        vm.downloadAllAia = [];
        if (vm.allPapersCount !== 0) {
          vm.allCombinePapers.forEach(function (element) {
            vm.downloadAllAia.push(element.contentManagementId);
          });
        }
        if (vm.allExhibitsCount !== 0) {
          vm.AiaExhibitsCombineAll.forEach(function (element) {
            vm.downloadAllAia.push(element.contentManagementId);
          });
        }
        if (vm.downloadAllAia.length >= 1) {
          vm.downloadAia();
        }
        if (vm.allPapersCount === 0 && vm.allExhibitsCount === 0) {
          toastr.error("No papers and exhibits to download", {
            iconClass: 'toast-danger',
            timeOut: 8000
          });
          vm.spinnerShow = false;
        }
      };

      vm.downloadAia = function () {
        HttpFactory.downloadzip(CONSTANTS.URL.DOWNLOAD_CASEVIEWER_PDF, vm.downloadAllAia)
          .then(function (successResponse) {
            var blob = new Blob([successResponse.data], {
              type: "application/pdf"
            });
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = vm.caseNumber + "_All-documents" +  ".pdf";
            a.click();
            vm.spinnerShow = false;
          }, function () {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.downloadingError, "error", 8000);
            vm.spinnerShow = false;
          });
      };

      vm.constructSelectedDownload = function () {
        
        var selectedRowsExhibitCombine = vm.gridApiEC.selection.getSelectedRows();
        var selectedRowsPapersCombine = vm.gridApiPc.selection.getSelectedRows();
        vm.downloadSelected = [];
        selectedRowsPapersCombine.forEach(function (element) {
          vm.downloadSelected.push(element);
        });
        selectedRowsExhibitCombine.forEach(function (element) {
          vm.downloadSelected.push(element);
        });

        ngDialog.open({
          template: "app/caseViewer/arrangeDocuments.html",
          controller: 'ArrangeDocumentsController',
          controllerAs: "vm",
          width: '90%',
          showClose: false,
          closeByEscape: false,
          closeByDocument: false,
          resolve: {
            selectedDocuments: function () {
              return vm.downloadSelected;
            },
            caseNumber: function () {
              return vm.caseNumber;
            }
          }
        }).closePromise.then(function (selectedDocs) {
          if (selectedDocs.value==='success') {
            vm.gridApiEC.selection.clearSelectedRows();
            vm.gridApiPc.selection.clearSelectedRows();
          }
         console.log(selectedDocs);
        }, function () { //intentional
        });
 //      
      };

      vm.downloadSlectedpdf = function () {
        HttpFactory.downloadzip(CONSTANTS.URL.DOWNLOAD_CASEVIEWER_PDF, vm.downloadSelected)
          .then(function (successResponse) {
            var blob = new Blob([successResponse.data], {
              type: "application/pdf"
            });
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = vm.caseNumber+ "_selected-files" + ".pdf";
            a.click();
            vm.spinnerShow = false;
          }, function (failureResponse) {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.downloadingError, "error", 8000);
            $log.info(failureResponse);
            vm.spinnerShow = false;
          });
      };

      vm.constructSelectedAppealDownload = function () {
        vm.appealsSpinner = true;
        var selectedRowsForAppeal = vm.selectedRowsForAppeals;
        vm.downloadSelectedAppealList = [];
        vm.serialNumber = vm.serialNumber;
        selectedRowsForAppeal.forEach(function (element) {
          var downloadSelectedAppealZip = {
            "serialNumber": vm.serialNumber,
            "docCode": element.documentCode,
            "officialStrtDate": element.officialDateEpoch,
          };
          vm.downloadSelectedAppealList.push(downloadSelectedAppealZip);
        });
        vm.downloadSelectedAppealpdf1();
      };

      vm.downloadSelectedAppealpdf1 = function () {
        HttpFactory.downloadzip("/data-documents/download-zip", vm.downloadSelectedAppealList)
          .then(function (successResponse) {
            var blob = new Blob([successResponse.data], {
              type: "application/zip"
            });
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = "SelectedAppealfiles" + new Date() + ".zip";
            a.click();
            vm.appealsSpinner = false;
          }, function () {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.downloadingError, "error", 8000);
            vm.appealsSpinner = false;
          });
      };

      /* istanbul ignore next */
      $scope.openPaperPdf = function (row) {
        HttpFactory.viewpdf("/artifacts/download?contentManagementId=" + row.contentManagementId)
          .then(function (successResponse) {
            var file = new Blob([successResponse.data], {
              type: 'application/pdf'
            });
            var fileURL = URL.createObjectURL(file);
            $scope.pdfPaperContent = $sce.trustAsResourceUrl(fileURL);
            if (fileURL !== '' || angular.isDefined(fileURL)) {
              $scope.pdfStyle = {
                "border": "1px solid grey"
              };
            }
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };

      $scope.openPaperPdfCombine = function (row) {
        HttpFactory.viewpdf("/artifacts/download?contentManagementId=" + row.contentManagementId)
          .then(function (successResponse) {
            var file = new Blob([successResponse.data], {
              type: 'application/pdf'
            });
            var fileURL = URL.createObjectURL(file);
            $scope.pdfPaperContentCombine = $sce.trustAsResourceUrl(fileURL);
            if (fileURL !== '' || angular.isDefined(fileURL)) {
              $scope.pdfStyle = {
                "border": "1px solid grey"
              };
            }
            $window.open(fileURL);
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };

      vm.downloadPapers = function () {
        HttpFactory.downloadzip(CONSTANTS.URL.DOWNLOAD_CASEVIEWER_PDF, vm.downloadAllPapers)
          .then(function (successResponse) {
            var blob = new Blob([successResponse.data], {
              type: "application/pdf"
            });
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = vm.caseNumber+ "_papers" + ".pdf";
            a.click();
            vm.spinnerShow = false;
          }, function (failureResponse) {
            $log.info(failureResponse);
            CommonHelperService.setToastr(CONSTANTS.TOASTER.downloadingError, "error", 8000);
            vm.spinnerShow = false;
          });
      };

      vm.gridOptionsAiaexhibits = {
        columnDefs: [{
          name: 'exhibitNumber',
          displayName: 'Exhibits #',
          field: 'exhibitNumber',
          type: 'number'
        }]
      };

      vm.constructAllExhibitsDownload = function () {
        vm.spinnerShow = true;
        vm.downloadAllExhibits = [];
        if (vm.allExhibitsCount !== 0) {
          vm.AiaExhibitsCombineAll.forEach(function (element) {
            vm.downloadAllExhibits.push(element.contentManagementId);
          });
          vm.downloadExhibits();
        } else {
          toastr.error("No exhibits to download", {
            iconClass: 'toast-danger',
            timeOut: 8000
          });
          vm.spinnerShow = false;
        }
      };

      vm.constructAppealsDownload = function () {
        vm.appealsSpinner = true;
        vm.downloadAppealList = [];
        vm.serialNumber = vm.serialNumber;
        vm.DocumentHistory.forEach(function (element) {
          var downloadAppealZip = {
            "serialNumber": vm.serialNumber,
            "docCode": element.documentCode,
            "officialStrtDate": element.officialDateEpoch,
          };
          vm.downloadAppealList.push(downloadAppealZip);
        });
        vm.downloadAppeal();
      };

      vm.gridOptionsAiaexhibitsCombine = {
        enableColumnResizing: true,
        enableRowSelection: true,
        enableSelectAll: true,
        enableHorizontalScrollbar: 2,
        enableVerticalScrollbar: 0,
        useExternalFiltering: true,
        enableGridMenu: true,
        exporterCsvFilename: 'Aiaexhibits.csv',
        exporterOlderExcelCompatibility: true,
        exporterMenuCsv: true,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        enableFiltering: true,
        rowHeight: 45,
        columnDefs: [{
            name: 'exhibitNumber',
            displayName: '#',
            field: 'exhibitNumber',
            headerTooltip: '#',
            type: 'number',
            width: 60,
            cellTooltip: true,
            allowCellFocus: false
          },
          {
            name: 'filingDate',
            displayName: 'Filing date',
            field: 'filingDate',
            headerTooltip: 'Filing date',
            type: 'date',
            cellFilter: "date:'MM/dd/yyyy'",
            width: 100,
            cellTooltip: true,
            allowCellFocus: false
          },
          {
            name: 'documentTitle',
            displayName: 'Title',
            field: 'documentTitle',
            headerTooltip: 'Title',
            cellTooltip: true,
            cellTemplate: '<div title="{{row.entity.documentTitle}}" class="truncateTitle" style="margin-left: 8px; margin-right: 8px;padding-top:5px; text-decoration: none; white-space: normal;">' +
          '<span ng-if=\"row.entity.statusCode === \'EXPUNGED\' && grid.appScope.userInfo.roleDescription !== \'Business Administrator\'\">{{row.entity.documentTitle}}</span>'+
          '<span ng-if=\"row.entity.statusCode === \'EXPUNGED\' && grid.appScope.userInfo.roleDescription === \'Business Administrator\'\" ng-click="grid.appScope.openexhibitpdfCombine(row.entity)" style="color:#004C97;cursor: pointer">{{row.entity.documentTitle}}</span>'+
          '<span ng-if=\"row.entity.statusCode !== \'EXPUNGED\'\" ng-click="grid.appScope.openexhibitpdfCombine(row.entity)" style="color:#004C97;cursor: pointer">{{row.entity.documentTitle}}</span>'+
          '</div>'
          },
          {
            name: 'availability',
            displayName: 'Confidentiality',
            field: 'availability',
            headerTooltip: 'Availability',
            width: 130,
            cellTooltip: true,
            allowCellFocus: false,
            cellTemplate: '<div class="truncateTitle" style="margin-left: 8px; padding-top:5px; white-space: normal; text-decoration: none;">' +
              '<span ng-if=\"row.entity.statusCode !== \'EXPUNGED\'\">{{row.entity.availability}}</span>'+
              '<span ng-if=\"row.entity.statusCode === \'EXPUNGED\'\"><i class="fa fa-eraser" style="padding-right:8px"></i>{{row.entity.availability}}</span></div>',
          },
        ]
      };

      vm.gridOptionsAiaPapersCombine = {
        enableColumnResizing: true,
        enableVerticalScrollbar: 0,
        enableSelectAll: true,
        enableRowSelection: true,
        enableHorizontalScrollbar: 2,
        useExternalFiltering: true,
        enableGridMenu: true,
        exporterCsvFilename: 'Aiapapers.csv',
        exporterOlderExcelCompatibility: true,
        exporterMenuCsv: true,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        enableFiltering: true,
        rowHeight: 45,
        columnDefs: [{
            name: 'paperNumber',
            displayName: '#',
            field: 'paperNumber',
            headerTooltip: '#',
            cellTooltip: true,
            width: 60,
            type: 'number',
            allowCellFocus: false
          },
          {
            name: 'filingDate',
            displayName: 'Filing date',
            field: 'filingDate',
            type: 'date',
            cellFilter: "date:'MM/dd/yyyy'",
            cellTooltip: true,
            width: 100,
            headerTooltip: 'Filing date',
            allowCellFocus: false
          },
          {
            name: 'fileName',
            displayName: 'Paper type',
            field: 'fileName',
            headerTooltip: 'Paper type',
            cellTemplate: '<div  title="{{row.entity.fileName}}" ' +
              'class="truncateTitle"style="cursor: pointer; margin-left: 8px; margin-right: 8px;padding-top:5px; text-decoration: none;white-space: normal;">' +
              '{{row.entity.fileName}}</div>',
            cellTooltip: true,
            width: 150,
            allowCellFocus: false
          },
          {
            name: 'documentTitle',
            displayName: 'Title',
            field: 'documentTitle',
            headerTooltip: 'Title',
            cellTemplate: '<div title="{{row.entity.documentTitle}}" class="truncateTitle" style="margin-left: 8px; margin-right: 8px;padding-top:5px; text-decoration: none; white-space: normal;">' +
            '<span ng-if=\"row.entity.statusCode === \'EXPUNGED\' && grid.appScope.userInfo.roleDescription !== \'Business Administrator\'\">{{row.entity.documentTitle}}</span>'+
            '<span ng-if=\"row.entity.statusCode === \'EXPUNGED\' && grid.appScope.userInfo.roleDescription === \'Business Administrator\'\" ng-click="grid.appScope.openPaperPdfCombine(row.entity)" style="color:#004C97;cursor: pointer">{{row.entity.documentTitle}}</span>'+
            '<span ng-if=\"row.entity.statusCode !== \'EXPUNGED\'\" ng-click="grid.appScope.openPaperPdfCombine(row.entity)" style="color:#004C97;cursor: pointer">{{row.entity.documentTitle}}</span>'+
            '</div>'
            
          },
          {
            name: 'filingParty',
            displayName: 'Party',
            field: 'filingParty',
            headerTooltip: 'Party',
            cellTemplate: '<div class="truncateTitle" style="margin-left: 8px; padding-top:5px; white-space: normal; text-decoration: none;" title="{{row.entity.filingParty}}">' +
              '<span ng-if=\"row.entity.filingParty === \'PETITIONER\'\"><i class="fas fa-square-full" style="color:#9BB8D3"></i></span>' +
              '<span ng-if=\"row.entity.filingParty === \'PATENT OWNER\'\"><i class="fas fa-square-full" style="color: #B55002"></i></span>' +
              '<span ng-if=\"row.entity.filingParty === \'BOARD\'\"><i class="fas fa-bars fa-rotate-90" style="color:#4FA80A"></i></span>' +
              '<span ng-if=\"row.entity.filingParty === \'POTENTIAL PO\'\"><i class="fas fa-square-full" style="color:#B55002"></i></span></div>',
            cellTooltip: true,
            width: 70,
            allowCellFocus: false
          },
          {
            name: 'confidentiality',
            displayName: 'Confidentiality',
            field: 'confidentiality',
            headerTooltip: 'Confidentiality',
            cellTooltip: true,
            width: 130,
            allowCellFocus: false,
            cellTemplate: '<div class="truncateTitle" style="margin-left: 8px; padding-top:5px; white-space: normal; text-decoration: none;">' +
              '<span ng-if=\"row.entity.statusCode !== \'EXPUNGED\'\">{{row.entity.confidentiality}}</span>'+
              '<span ng-if=\"row.entity.statusCode === \'EXPUNGED\'\"><i class="fa fa-eraser" style="padding-right:8px"></i>{{row.entity.confidentiality}}</span></div>',
          },
        ]
      };

      vm.gridOptionsAppealsNew = {
        enableColumnResizing: true,
    //    enableVerticalScrollbar: 0,
        enableSelectAll: true,
        enableRowSelection: true,
        enableHorizontalScrollbar: 2,
        useExternalFiltering: true,
        enableGridMenu: true,
        exporterCsvFilename: 'Appeals.csv',
        exporterOlderExcelCompatibility: true,
        exporterMenuCsv: true,
        exporterMenuExcel: false,
        exporterMenuPdf: false,
        enableFiltering: true,
        rowHeight: 45,
        columnDefs: [{
            name: 'documentCode',
            displayName: 'Document Code',
            field: 'documentCode',
            cellTooltip: true,
            headerTooltip: 'Document Code',
            cellTemplate: '<div title="Open PDF for {{row.entity.documentCode}}" class="truncateTitle" ng-click="grid.appScope.openPdf(row.entity)" ' +
              'ng-bind-html="row.entity.documentCode" style="cursor: pointer; margin-left: 8px; padding-top:5px; text-decoration: underline; color:blue"></div>',
            width: 150
          },
          {
            name: 'documentDescription',
            displayName: 'Document Description',
            cellTooltip: true,
            field: 'documentDescription',
            headerTooltip: 'Document Description',
            allowCellFocus: false
          },
          {
            name: 'document',
            displayName: 'Open in new tab',
            cellTooltip: true,
            // field: 'documentDescription',
            headerTooltip: 'Open in new tab',
            cellTemplate: '<div  title="Open PDF in new tab" class="truncateTitle" ng-click="grid.appScope.openPdfCombine(row.entity)" ' +
              'style="cursor: pointer; margin-left: 8px; padding-top:5px; text-decoration: underline; color:blue"><i class="fas fa-external-link-alt"></i></div>',
            allowCellFocus: false,
            width: 150
          },
          {
            name: 'officialDateEpoch',
            displayName: 'Official Date',
            field: 'officialDateEpoch',
            headerTooltip: 'Official Date',
            type: 'date',
            cellFilter: "date:'MM/dd/yyyy'",
            cellTooltip: true,
            width: 150
          }
        ]
      };

      vm.gridOptionsAiaexhibitsCombine.onRegisterApi = function (gridApi) {
        vm.gridApiEC = gridApi;
        vm.gridApiEC.selection.on.rowSelectionChanged($scope, function () {
          vm.selectedRowsECom = vm.gridApiEC.selection.getSelectedRows();
        });
        vm.gridApiEC.selection.on.rowSelectionChangedBatch($scope, function () {
          vm.selectedRowsECom = vm.gridApiEC.selection.getSelectedRows();
        });
        $scope.gridApiEC = gridApi;
        $scope.gridApiEC.core.on.filterChanged($scope, function () {
          var grid = this.grid;
          $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
          if ($scope.numberOfFilters === 0) {
            getFilteredDataNoFilters();
          } else {
            getFilteredDataFilters();
            var filteredData = SearchHelperService.filterGrid(grid, $scope.myDataEC);
            vm.gridOptionsAiaexhibitsCombine.data = filteredData;
          }
        });
      };

      function getFilteredDataNoFilters() {
        if (exhibit === 0) {
          vm.gridOptionsAiaexhibitsCombine.data = $scope.myDataEC;
          return;
        }
        if (exhibit === 1) {
          vm.gridOptionsAiaexhibitsCombine.data = vm.AiaExhibitsCombinethousands;
          return;
        }
        if (exhibit === 2) {
          vm.gridOptionsAiaexhibitsCombine.data = vm.AiaExhibitsCombinetwoThousands;
          return;
        }
        if (exhibit === 3) {
          vm.gridOptionsAiaexhibitsCombine.data = vm.AiaExhibitsCombinethreeThousands;
          return;
        }
      }

      function getFilteredDataFilters() {
        if (exhibit === 0) {
          $scope.myDataEC = $scope.myDataEC;
          return;
        }
        if (exhibit === 1) {
          $scope.myDataEC = vm.AiaExhibitsCombinethousands;
          return;
        }
        if (exhibit === 2) {
          $scope.myDataEC = vm.AiaExhibitsCombinetwoThousands;
          return;
        }
        if (exhibit === 3) {
          $scope.myDataEC = vm.AiaExhibitsCombinethreeThousands;
          return;
        }
      }

      vm.gridOptionsAiaPapersCombine.onRegisterApi = function (gridApi) {
        vm.gridApiPc = gridApi;
        vm.gridApiPc.selection.on.rowSelectionChanged($scope, function () {
          vm.selectedRowsPCom = vm.gridApiPc.selection.getSelectedRows();
        });

        vm.gridApiPc.selection.on.rowSelectionChangedBatch($scope, function () {
          vm.selectedRowsPCom = vm.gridApiPc.selection.getSelectedRows();
        });

        $scope.gridApiPc = gridApi;
        $scope.gridApiPc.core.on.filterChanged($scope, function () {
          var grid = this.grid;
          $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
          if ($scope.numberOfFilters === 0) {
            setPaperGridOptionsDataNoFilters();
          } else {
            setPaperGridOptionsDataFilters();
            var filteredData = SearchHelperService.filterGrid(grid, $scope.myDataPc);
            vm.gridOptionsAiaPapersCombine.data = filteredData;
          }
        });
      };

      function setPaperGridOptionsDataNoFilters() {
        if (paper === 0) {
          vm.gridOptionsAiaPapersCombine.data = $scope.myDataPc;
          return;
        }
        if (paper === 1) {
          vm.gridOptionsAiaPapersCombine.data = vm.boardCombine;
          return;
        }
        if (paper === 2) {
          vm.gridOptionsAiaPapersCombine.data = vm.petitionerCombine;
          return;
        }
        if (paper === 3) {
          vm.gridOptionsAiaPapersCombine.data = vm.patentOwnerBagCombine;
          return;
        }
      }

      function setPaperGridOptionsDataFilters() {
        if (paper === 0) {
          $scope.myDataPc = $scope.myDataPc;
          return;
        }
        if (paper === 1) {
          $scope.myDataPc = vm.boardCombine;
          return;
        }
        if (paper === 2) {
          $scope.myDataPc = vm.petitionerCombine;
          return;
        }
        if (paper === 3) {
          $scope.myDataPc = vm.patentOwnerBagCombine;
          return;
        }
      }

      vm.gridOptionsAppealsNew.onRegisterApi = function (gridApi) {
        vm.gridApiForAppeals = gridApi;
        vm.gridApiForAppeals.selection.on.rowSelectionChanged($scope, function () {
          vm.selectedRowsForAppeals = vm.gridApiForAppeals.selection.getSelectedRows();
        });
        vm.gridApiForAppeals.selection.on.rowSelectionChangedBatch($scope, function () {
          vm.selectedRowsForAppeals = vm.gridApiForAppeals.selection.getSelectedRows();
        });
        $scope.gridApiForAppeals = gridApi;
        $scope.gridApiForAppeals.core.on.filterChanged($scope, function () {
          var grid = this.grid;
          $scope.numberOfFilters = SearchHelperService.getNumberOfFilters(grid.columns);
          if ($scope.numberOfFilters === 0) {
            vm.gridOptionsAppealsNew.data = $scope.myDataD;
          } else {
            var filteredData = SearchHelperService.filterGrid(grid, $scope.myDataD);
            vm.gridOptionsAppealsNew.data = filteredData;
            vm.gridOptionsAppealsNew.data = filteredData;
          }
        });
      };

      vm.getTableHeightExhibits = function () {
        var rowHeight = 45;
        var headerHeight = 75;
 		var gridHeight = ((vm.allExhibitsCount * rowHeight) + (headerHeight));
        gridHeight = Math.max(gridHeight, 275);        
        return {
          height: gridHeight + "px"
        };
      };

      /* istanbul ignore next: toaster error*/
      vm.getAiaExhibitsCombine = function () {
        HttpFactory.getActions("/case-documents/all-exhibits-with-count?proceedingNumber=" + vm.caseNumber)
          .then(function (successResponse) {
            vm.allExhibitsCount = successResponse.data.allExhibitsCount;
            vm.thousandsExhibitsCount = successResponse.data.thousandsExhibitsCount;
            vm.twoThousandsExhibitsCount = successResponse.data.twoThousandsExhibitsCount;
            vm.threeThousandsExhibitsCount = successResponse.data.threeThousandsExhibitsCount;
            vm.AiaExhibitsCombineAll = successResponse.data.allExhibitsBag;
            vm.gridOptionsAiaexhibitsCombine.data = vm.AiaExhibitsCombineAll;
            $scope.myDataEC = angular.copy(vm.gridOptionsAiaexhibitsCombine.data);
            vm.AiaExhibitsCombinethousands = successResponse.data.thousandsExhibitsBag;
            vm.AiaExhibitsCombinetwoThousands = successResponse.data.twoThousandsExhibitsBag;
            vm.AiaExhibitsCombinethreeThousands = successResponse.data.threeThousandsExhibitsBag;
            $scope.myDataAiaExhibits = angular.copy(vm.gridOptionsAiaexhibitsCombine.data);
            vm.getAiaPapersCombine();
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
        vm.getTableHeightExhibits();
      };

      vm.allExhibitsCombine = function () {
        vm.gridOptionsAiaexhibitsCombine.data = vm.AiaExhibitsCombineAll;
        exhibit = 0;
      };
      vm.allExhibitsCombine();
      vm.thousandsExhibitsCombine = function () {
        vm.gridOptionsAiaexhibitsCombine.data = vm.AiaExhibitsCombinethousands;
        exhibit = 1;
      };
      vm.twothousandsExhibitsCombine = function () {
        vm.gridOptionsAiaexhibitsCombine.data = vm.AiaExhibitsCombinetwoThousands;
        exhibit = 2;
      };
      vm.threethousandsExhibitsCombine = function () {
        vm.gridOptionsAiaexhibitsCombine.data = vm.AiaExhibitsCombinethreeThousands;
        exhibit = 3;
      };
      vm.getTableHeight = function () {
        var rowHeight = 45;
        var headerHeight = 75;
        var gridHeight = ((vm.allPapersCount * rowHeight) + (headerHeight));
        gridHeight = Math.max(gridHeight, 275);
        return {
          height: gridHeight + "px"
        };
      };

      vm.getAiaPapersCombine = function () {
        HttpFactory.getActions("/case-documents/all-papers-with-count?proceedingNumber=" + vm.caseNumber)
          .then(function (successResponse) {
            vm.allPapersCount = successResponse.data.allPapersCount;
            vm.boardPapersCount = successResponse.data.boardPapersCount;
            vm.petitionerPapersCount = successResponse.data.petitionerPapersCount;
            vm.patentOwnerPapersCount = successResponse.data.patentOwnerPapersCount;
            vm.allCombinePapers = successResponse.data.allPapersBag;
            vm.gridOptionsAiaPapersCombine.data = vm.allCombinePapers;
            $scope.myDataPc = angular.copy(vm.gridOptionsAiaPapersCombine.data);
            vm.boardCombine = successResponse.data.boardPapersBag;
            vm.petitionerCombine = successResponse.data.petitionerPapersBag;
            vm.patentOwnerBagCombine = successResponse.data.patentOwnerPapersBag;
            $scope.myDataAiaPapers = angular.copy(vm.gridOptionsAiaPapersCombine.data);
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
        vm.getTableHeight();
      };

      /* istanbul ignore next: toaster error*/
      vm.getDocumentHistory = function () {
        HttpFactory.getActions("/data-documents/application-doc-info/" + vm.applicationNumber)
          .then(function (successResponse) {
            vm.DocumentHistory = successResponse.data.resultBag[0].documentBag;
            vm.serialNumber = successResponse.data.resultBag[0].applicationNumberText;
            for (var i = 0; i < vm.DocumentHistory.length; i++) {
              vm.DocumentHistory[i].officialDateStr = vm.dateConvert(vm.DocumentHistory[i].officialDateStr);
              vm.DocumentHistory[i].date = vm.dateConvert(vm.DocumentHistory[i].date);
            }
            vm.gridOptionsAppealsNew.data = successResponse.data.resultBag[0].documentBag;
            $scope.myDataD = angular.copy(vm.gridOptionsAppealsNew.data);
            if ($scope.initialDocumentLoad) {
              $scope.openPdf(vm.gridOptionsAppealsNew.data[0]);
              $scope.initialDocumentLoad = false;
            }
          }, function (failureResponse) {
            toastr.error(failureResponse.data.message, {
              iconClass: 'toast-danger',
              timeOut: 8000
            });
          });
      };

      vm.allPapersCombine = function () {
        vm.gridOptionsAiaPapersCombine.data = vm.allCombinePapers;
        paper = 0;
      };
      vm.boardPapersCombine = function () {
        vm.gridOptionsAiaPapersCombine.data = vm.boardCombine;
        paper = 1;
      };
      vm.petitionerPapersCombine = function () {
        vm.gridOptionsAiaPapersCombine.data = vm.petitionerCombine;
        paper = 2;
      };
      vm.patentOwnerCombine = function () {
        vm.gridOptionsAiaPapersCombine.data = vm.patentOwnerBagCombine;
        paper = 3;
      };

      /* istanbul ignore next */
      $scope.openexhibitpdf = function (row) {
        HttpFactory.viewpdf("/artifacts/download?contentManagementId=" + row.contentManagementId)
          .then(function (successResponse) {
            var file = new Blob([successResponse.data], {
              type: 'application/pdf'
            });
            var fileURL = URL.createObjectURL(file);
            $scope.pdfExhibitContent = $sce.trustAsResourceUrl(fileURL);
            if (fileURL !== '' || angular.isDefined(fileURL)) {
              $scope.pdfStyle = {
                "border": "1px solid grey"
              };
            }
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };

      /* istanbul ignore next */
      $scope.openexhibitpdfCombine = function (row) {
        HttpFactory.viewpdf("/artifacts/download?contentManagementId=" + row.contentManagementId)
          .then(function (successResponse) {
            var file = new Blob([successResponse.data], {
              type: 'application/pdf'
            });
            var fileURL = URL.createObjectURL(file);
            $scope.pdfExhibitContentCombine = $sce.trustAsResourceUrl(fileURL);
            if (fileURL !== '' || angular.isDefined(fileURL)) {
              $scope.pdfStyle = {
                "border": "1px solid grey"
              };
            }
            window.open(fileURL);
          }, function (failureResponse) {
            $log.info(failureResponse);
          });
      };

      vm.downloadExhibits = function () {
        HttpFactory.downloadzip(CONSTANTS.URL.DOWNLOAD_CASEVIEWER_PDF, vm.downloadAllExhibits)
          .then(function (successResponse){
            var blob = new Blob([successResponse.data], {
              type: "application/pdf"
            });
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = vm.caseNumber + "_exhibits" + ".pdf";
            a.click();
            vm.spinnerShow = false;
          }, function () {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.downloadingError, "error", 8000);
            vm.spinnerShow = false;
          });
      };

      vm.downloadAppeal = function () {
        HttpFactory.downloadzip("/data-documents/download-zip", vm.downloadAppealList)
          .then(function (successResponse) {
            var blob = new Blob([successResponse.data], {
              type: "application/zip"
            });
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = "AllAppealfiles" + new Date() + ".zip";
            a.click();
            vm.appealsSpinner = false;
          }, function (failureResponse) {
            toastr.error(failureResponse.data.message, {
              iconClass: 'toast-danger'
            });
            vm.appealsSpinner = false;
          });
      };

      vm.closeAiaDialog = function () {
        ngDialog.closeAll();
      };

      vm.checkTeamLead = function () {
        HttpFactory.getActions("/user-management/validate-team-lead?userId=" + $window.sessionStorage.getItem("workerNumber"))
          .then(function (successResponse) {
            vm.lead = successResponse.data;
          }, function () { //Non 200 response means empty return.   Expected response.
          });
      };

      vm.loadCaseViewer = function (userInfo) {
        workerNumber = $window.sessionStorage.getItem("workerNumber");
        $window.document.title = $route.current.params.caseNumber ? $route.current.params.caseNumber + " - Case Viewer - P-TACTS" : 0 + " - Case Viewer - P-TACTS";
        workerNumber = userInfo.appUserInfo[0].loginId;
        $scope.workerNumber = workerNumber;
        if (userInfo && userInfo.appUserInfo) {
          console.log(userInfo.appUserInfo[0].roleDescription);
          vm.isJudge = userInfo.appUserInfo[0].roleDescription ? userInfo.appUserInfo[0].roleDescription.toUpperCase().indexOf('JUDGE') > -1 ? true : false : false;
          vm.isPatentAttorney = userInfo.appUserInfo[0].roleDescription ? userInfo.appUserInfo[0].roleDescription.toUpperCase().indexOf('PATENT ATTORNEY') > -1 ? true : false : false;
          vm.checkTeamLead();
        }

        $scope.userInfo = {
          "userId": userInfo.appUserInfo[0].userIdentiifier,
          "loginId": userInfo.appUserInfo[0].loginId,
          "fullName": userInfo.appUserInfo[0].fullName,
          "userWorkerNumber": userInfo.appUserInfo[0].userWorkerNumber,
          "userIdentiifier": userInfo.appUserInfo[0].userIdentiifier,
          "roleDescription": userInfo.appUserInfo[0].roleDescription
        };

        if(userInfo.appUserInfo[0].roleId == CONSTANTS.ROLE.roleId){
          vm.readOnlyUser = true;
        }

        vm.workerNumber = workerNumber;
        $log.info("###" + vm.workerNumber);
        vm.applicationNumber = $route.current.params.applicationNumber;
        vm.caseNumber = $route.current.params.caseNumber;
        vm.scrollToId = $route.current.params.scrollToId;
        vm.workspaces = [];
        vm.workspaceOrderChanged = false;
        vm.initialWorkspace = false;
        vm.deleteWp = false;
        vm.workspacesMoved = false;
        vm.configurationChanged = false;
        vm.isAllOpen = false;
        vm.defaultUpdated = false;
        vm.initialLoad = false;
        vm.newWorkspace = false;
        vm.trialType = false;
        $scope.reverse = false;
        $scope.expandedValue = 0;
        $scope.statusAppDates = {};
        $scope.statusKeyDates = {};
        $scope.statusNotes = {};
        $scope.statusAT1 = {};
        $scope.statusAT2 = {};
        $scope.statusDoc = {};
        $scope.statusTrial = {};
        $scope.statusNH = {};
        $scope.status1 = {};
        $scope.status2 = {};
        $scope.status3 = {};
        $scope.status3T = {};
        $scope.status4 = {};
        $scope.status5 = {};
        $scope.status6 = {};
        $scope.status7 = {};
        $scope.status8 = {};
        $scope.status10 = {};
        $scope.status12 = {};
        $scope.status13 = {};
        $scope.status14 = {};
        $scope.status15 = {};
        $scope.showData = false;
        $scope.status5.open = false;
        $scope.status6.open = false;
        $scope.status7.open = false;
        $scope.status8.open = false;
        $scope.status12.open = false;
        $scope.status13.open = false;
        $scope.status14.open = false;
        $scope.status15.open = false;
        $scope.statusDoc.open = true;
        $scope.statusTrial.open = true;

        if (vm.isTrials) {
         $scope.status3T.open=true;
        } else {
          $timeout(function () {
            $scope.status1.open=true;
          }, 1000);
        }

        vm.statusCodeADM = "ADM";
//        $scope.currentTab = 'auditTrail';
        vm.isPanelMember = false;

        vm.getPhases = function () {
          HttpFactory.getActions("/reference-data/code-reference-types?typeCode=CHEVRON_PHASES").then(
            function (successResponse) {
              if (successResponse.data.length > 0) {
                successResponse.data.forEach(function (eachPhase) {
                  switch (eachPhase.valueText) {
                    case "PHASE_VALUES":
                      var clob = JSON.parse(eachPhase.descriptionText);
                      vm.Preappeal = clob.Preappeal;
                      vm.currentTab = clob.Preappeal;
                      vm.PendingDocketing = clob.PendingDocketing;
                      vm.PendingMasterDocketing = clob.PendingMasterDocketing;
                      vm.PendingPaneling = clob.PendingPaneling;
                      vm.PendingHearing = clob.PendingHearing;
                      vm.PendingDecision = clob.PendingDecision;
                      vm.PendingRehearingDecision = clob.PendingRehearingDecision;
                      vm.PendingSubDecision = clob.PendingSubDecision;
                      vm.PendingRehDecision = clob.PendingRehDecision;
                      vm.PendingDisposal = clob.PendingDisposal;
                      vm.panelTab = clob.panelTab;
                      vm.PendingAdminRemand = clob.PendingAdminRemand;
                      vm.PendingDismissal = clob.PendingDismissal;
                      vm.decisionClosed = clob.decisionClosed;
                      vm.pendingDisp = clob.PendingDisp;
                      vm.rehearingDecisionRendered = clob.rehearingDecisionRendered;
                      vm.decisionRend = clob.decisionRend;
                      vm.SubDecisionRend = clob.SubDecisionRend;
                      vm.penPaneling = clob.penPaneling;
                      vm.penHearing = clob.penHearing;
                      vm.onBrief = clob.onBrief;
                      vm.heard = clob.heard;
                      vm.caseDisposed = clob.caseDisposed;
                      vm.penDicision = clob.penDicision;
                      vm.casePaneled = clob.casePaneled;
                      vm.masterDocket = clob.masterDocket;
                      vm.hearingComplete = clob.hearingComplete;
                      vm.dismissed = clob.dismissed;
                      vm.remanded = clob.remanded;
                      vm.penRehaering = clob.penRehaering;
                      vm.decision = clob.decision;
                      break;
                    case "INVENTOR_URL":
                      vm.inventorUrl = eachPhase.descriptionText;
                      break;
                    default:
                      break;
                  }
                });
              }
            });
        };
        vm.getPhases();

        vm.checkForTrials = function () {
          if (vm.caseNumber.match(/[a-z]/i)) {
            vm.isTrials = true;
            vm.getAiaExhibitsCombine();
          }
        };
        vm.checkForTrials();

        /* istanbul ignore next */
        vm.getCaseInformation = function () {
          var url = "/case-information/details?serialNumber=" + vm.applicationNumber + "&appealNumber=" + vm.caseNumber;
          if (vm.isTrials) {
            url += "&proceedingType=TRIAL";
          } else {
            url += "&proceedingType=APPEAL";
          }
          HttpFactory.getActions(url)
            .then(function (successResponse) {
                vm.ptabReadOnlyUser = successResponse.data.ptabReadOnlyUser;
                if (angular.isDefined(successResponse.data.allowedResourceObjectList)) {
                  vm.isPanelMember = checkForPanelPrivilege(successResponse.data.allowedResourceObjectList);
                }
                vm.caseInfo = successResponse.data;
                if (vm.isTrials) {
                  vm.caseStatusTrial = vm.caseInfo.caseStatus;
                }
                if (vm.isTrials && vm.caseInfo.keyDates != null) {
                  if (vm.caseInfo.keyDates.length > 0) {
                    if (vm.caseInfo.keyDates.length === 1) {
                      vm.caseViewerkeyDates = vm.caseInfo.keyDates[0];
                    } else {
                      vm.caseViewerkeyDates = vm.caseInfo.keyDates.join('| ');
                    }
                  }
                }
                vm.displayPaneledAttorneys = [];
                vm.panelInString = "";
                vm.constructPanelStr = "";
                var prepend = "";
                var apj1 = "";
                vm.caseInfoParties = vm.caseInfo.parties;
                if (vm.caseInfo.attorneys !== null) {
                  for (var i = 0; i <= vm.caseInfo.attorneys.length - 1; i++) {
                    if (vm.caseInfo.attorneys[i]) {
                      var seperator = i == 0 ? '' : ' | ';
                      apj1 = vm.caseInfo.attorneys[i].rank === 1 ? vm.caseInfo.attorneys[i].employeeName : apj1;
                      vm.constructPanelStr += vm.caseInfo.attorneys[i].rank !== 1 && vm.caseInfo.attorneys[i].rank !== 0 ? seperator + vm.caseInfo.attorneys[i].employeeName : '';
                      if (i <= 99) {
                        vm.displayPaneledAttorneys.push(vm.caseInfo.attorneys[i]);
                        if (vm.caseInfo.attorneys[i].rank === 0) {
                          vm.isAttorney = true;
                          vm.attorneyName = vm.caseInfo.attorneys[i].employeeName;
                          prepend = '(' + vm.attorneyName + ')';
                        }
                      }
                    }
                    vm.panelInString = apj1 + prepend + vm.constructPanelStr;
                  }
                }
                vm.circulationViewable = vm.caseInfo.circulationViewable;
                vm.casetransactionDetails = vm.caseInfo.casetransactionDetails;
                vm.lengthOfChevron = vm.casetransactionDetails;
                vm.chevronStatusCode = vm.casetransactionDetails[vm.lengthOfChevron.length - 1].statusCode;
                vm.chevronStatusDescription = vm.casetransactionDetails[vm.lengthOfChevron.length - 1].statusDescription;
                vm.chevronDetails = vm.casetransactionDetails[0].phaseName;
                vm.currentPhase = vm.casetransactionDetails[vm.lengthOfChevron.length - 1].phaseName;
                if (vm.lengthOfChevron.length >= 2) {
                  vm.previousPhase = vm.casetransactionDetails[vm.lengthOfChevron.length - 2].phaseName;
                  vm.previousStatusCode = vm.casetransactionDetails[vm.lengthOfChevron.length - 2].statusCode;
                }

                if (vm.lengthOfChevron.length >= 3) {
                  vm.beforePreviousPhase = vm.casetransactionDetails[vm.lengthOfChevron.length - 3].phaseName;
                  vm.beforePreviousStatusCode = vm.casetransactionDetails[vm.lengthOfChevron.length - 3].statusCode;
                }
                if (vm.currentPhase === vm.PendingSubDecision) {
                  for (var i = 0; i < vm.lengthOfChevron.length; i++) {
                    if (vm.casetransactionDetails[i].phaseName === vm.PendingRehDecision) {
                      vm.rehearingRendered = vm.rehearingDecisionRendered;
                      break;
                    }
                  }
                }
                if (vm.currentPhase === vm.PendingRehDecision) {
                  for (var m = 0; m < vm.lengthOfChevron.length; m++) {
                    if (vm.casetransactionDetails[m].phaseName === vm.PendingSubDecision) {
                      vm.subsequentRendered = vm.SubDecisionRend;
                      break;
                    }
                  }
                }
                if (vm.currentPhase === vm.pendingDisp) {
                  for (var k = 0; k < vm.lengthOfChevron.length; k++) {
                    if (vm.casetransactionDetails[k].phaseName === vm.PendingRehDecision) {
                      for (var j = 0; j < vm.lengthOfChevron.length; j++) {
                        if (vm.casetransactionDetails[j].phaseName === vm.PendingSubDecision) {
                          if (vm.previousPhase === vm.PendingRehDecision) {
                            vm.subsequentRendered = vm.SubDecisionRend;
                            break;
                          } else {
                            vm.rehearingRendered = vm.rehearingDecisionRendered;
                            break;
                          }
                        }
                      }
                    }
                  }
                }

                if (vm.currentPhase === vm.caseDisposed) {
                  for (var n = 0; n < vm.lengthOfChevron.length; n++) {
                    if (vm.casetransactionDetails[n].phaseName === vm.penPaneling) {
                      vm.masterDocketDisp = vm.masterDocket;
                      break;
                    } else {
                      vm.masterDocketDisp = vm.PendingMasterDocketing;
                    }
                  }

                  for (var p = 0; p < vm.lengthOfChevron.length; p++) {
                    if (vm.casetransactionDetails[p].phaseName === vm.penDicision || vm.casetransactionDetails[p].phaseName === vm.pendingDisp) {
                      vm.pendingPanelDisp = vm.casePaneled;
                      break;
                    } else {
                      vm.pendingPanelDisp = vm.penPaneling;
                    }
                  }

                  for (var q = 0; q < vm.lengthOfChevron.length; q++) {
                    if (vm.casetransactionDetails[q].statusCode === vm.decision) {
                      vm.decisionDisp = vm.decisionRend;
                      break;
                    } else {
                      vm.decisionDisp = vm.penDicision;
                    }
                  }

                  for (var r = 0; r < vm.lengthOfChevron.length; r++) {
                    if (vm.casetransactionDetails[r].phaseName === vm.PendingRehDecision) {
                      vm.rehearingDisp = vm.rehearingDecisionRendered;
                      break;
                    }
                  }

                  for (var s = 0; s < vm.lengthOfChevron.length; s++) {
                    if (vm.casetransactionDetails[s].phaseName === vm.PendingSubDecision) {
                      vm.subsequentDisp = vm.SubDecisionRend;
                      break;
                    }
                  }

                  for (var t = 0; t < vm.lengthOfChevron.length; t++) {
                    if (vm.casetransactionDetails[t].phaseName === vm.PendingRehDecision) {
                      for (var v = 0; v < vm.lengthOfChevron.length; v++) {
                        if (vm.casetransactionDetails[v].phaseName === vm.PendingSubDecision) {
                          if (vm.beforePreviousPhase === vm.PendingSubDecision) {
                            vm.rehearingRendered = vm.rehearingDecisionRendered;
                            break;
                          } else {
                            vm.subsequentRendered = vm.SubDecisionRend;
                            break;
                          }
                        }
                      }
                    }
                  }
                }

              }, /* istanbul ignore next */
              function (failureResponse) {
                toastr.error(failureResponse, {
                  iconClass: 'toast-danger'
                });
              });
        };
        vm.getCaseInformation();

        function checkForPanelPrivilege(privilegeList) {
          return privilegeList.includes("panel_Update");
        }

        vm.scroll = function (idToScroll) {
          $timeout(function () {
            $location.hash(idToScroll);
            $anchorScroll();
          }, 1000);
        };
        if (vm.scrollToId) {
          var tokens = vm.scrollToId.split('-');
          $timeout(function () {
            $scope.selectTab(tokens[0]);
            angular.element(document.querySelector('#' + tokens[0])).tab('show');
            vm.scroll(tokens[1]);
          }, 1000);
        }

        vm.PendingRehearingDecision = vm.PendingRehDecision;
        vm.PendingDisposal = vm.pendingDisp;
        /* istanbul ignore next */
        function setPendingDocketing(number) {
          if (number > 1) {
            vm.PendingDocketing = vm.masterDocket;
          } else {
            if (vm.masterDocketDisp === vm.masterDocket) {
              vm.PendingDocketing = vm.masterDocket;
            } else if (vm.currentPhase === vm.PendingAdminRemand) {
              vm.PendingDocketing = vm.currentPhase;
            } else if (vm.currentPhase === vm.PendingDismissal) {
              vm.PendingDocketing = vm.currentPhase;
            } else {
              vm.PendingDocketing = vm.PendingMasterDocketing;
            }
          }
        }

        function setPanelingHearing(number) {
          if (number > 2) {
            vm.PendingPaneling = vm.casePaneled;
            vm.PendingHearing = vm.hearingComplete;
          } else {
            vm.PendingPaneling = vm.penPaneling;
            vm.PendingHearing = vm.penHearing;
          }
        }
        /* istanbul ignore next */
        function setPendingDecision(number) {
          if (number > 3) {
            if (vm.currentPhase === vm.PendingAdminRemand) {
              vm.PendingDecision = vm.currentPhase;
            } else if (vm.currentPhase === vm.PendingDismissal) {
              vm.PendingDecision = vm.currentPhase;
            } else {
              vm.PendingDecision = vm.decisionRend;
            }
          } else {
            if (vm.decisionDisp === vm.decisionRend || vm.previousPhase === vm.pendingDisp) {
              vm.PendingDecision = vm.decisionRend;
            } else if (vm.currentPhase === vm.caseDisposed && vm.previousPhase === vm.PendingDismissal) {
              vm.PendingDecision = vm.dismissed;
            } else if (vm.currentPhase === vm.caseDisposed && vm.previousPhase === vm.PendingAdminRemand) {
              vm.PendingDecision = vm.remanded;
            } else {
              vm.PendingDecision = vm.penDicision;
            }
          }
        }
        /* istanbul ignore next */
        function setPendingRehearingDecision(number) {
          if (number > 4) {
            if (vm.previousStatusCode === vm.statusCodeADM) {
              vm.PendingRehearingDecision = vm.PendingRehDecision;
            } else {
              if (vm.previousPhase === vm.PendingSubDecision) {
                vm.PendingRehearingDecision = vm.SubDecisionRend;
              } else {
                if (vm.currentPhase !== vm.PendingAdminRemand && vm.currentPhase !== vm.PendingDismissal) {
                  vm.PendingRehearingDecision = vm.rehearingDecisionRendered;
                }
              }
            }
          } else if (number === undefined) {
            vm.PendingDisposal = vm.caseDisposed;
            if (vm.rehearingDisp === vm.rehearingDecisionRendered && vm.subsequentDisp === vm.SubDecisionRend) {
              if (vm.beforePreviousPhase === vm.PendingSubDecision) {
                vm.PendingRehearingDecision = vm.SubDecisionRend;
              } else {
                vm.PendingRehearingDecision = vm.rehearingDecisionRendered;
              }
            } else if (vm.rehearingDisp === vm.rehearingDecisionRendered) {
              vm.PendingRehearingDecision = vm.rehearingDecisionRendered;
            } else if (vm.subsequentDisp === vm.SubDecisionRend) {
              vm.PendingRehearingDecision = vm.SubDecisionRend;
            } else {
              vm.PendingRehearingDecision = vm.PendingRehDecision;
            }
          } else {
            if (vm.currentPhase === vm.PendingSubDecision) {
              vm.PendingRehearingDecision = vm.PendingSubDecision;
            } else if (vm.currentPhase === vm.pendingDisp) {
              if (vm.previousPhase === vm.PendingRehDecision) {
                vm.PendingRehearingDecision = vm.rehearingDecisionRendered;
              } else if (vm.previousPhase === vm.PendingSubDecision) {
                vm.PendingRehearingDecision = vm.SubDecisionRend;
              } else {
                vm.PendingRehearingDecision = vm.pendingDisp;
              }
            } else {
              vm.PendingRehearingDecision = vm.PendingRehDecision;
            }
          }
        }

        function checkStatus5(clickedTab) {
          if ($scope.status5.open === true) {
            $scope.status5.open = false;
          } else {
            if (clickedTab === 'appealTab') {
              $scope.counter = 0;
              $scope.performClickOnCasePhase();
              $scope.status5.open = true;
            }
          }
        }
        $scope.performClickOnCasePhase = function () {
          $timeout(function () {
            angular.element(document.querySelector('#casePhase')).click();
          }, 0);
        };

        function checkStatus6(clickedTab) {
          if ($scope.status6.open === true) {
            $scope.status6.open = false;
          } else {
            if (clickedTab === 'pendingDocketingTab') {
              $scope.counter = 1;
              $scope.performClickOnCasePhase();
              $scope.status6.open = true;
            }
          }
        }

        function checkStatus7(clickedTab) {
          if ($scope.status7.open === true) {
            $scope.status7.open = false;
          } else {
            if (clickedTab === 'pendingPanelingTab') {
              $scope.counter = 2;
              $scope.performClickOnCasePhase();
              $scope.status7.open = true;
            }
          }
        }

        function checkStatus8(clickedTab) {
          if ($scope.status8.open === true) {
            $scope.status8.open = false;
          } else {
            if (clickedTab === 'pendingDecisionTab') {
              $scope.counter = 3;
              $scope.performClickOnCasePhase();
              $scope.status8.open = true;
            }
          }
        }
        /* istanbul ignore next*/
        function checkStatus12(clickedTab) {
          if ($scope.status12.open === true) {
            $scope.status12.open = false;
          } else {
            if (clickedTab === 'pendingRehearingDecisionTab') {
              $scope.counter = 4;
              $scope.performClickOnCasePhase();
              $scope.status12.open = true;
            }
          }
        }
        /* istanbul ignore next*/
        function checkStatus13(clickedTab) {
          if ($scope.status13.open === true) {
            $scope.status13.open = false;
          } else {
            if (clickedTab === 'pendingDisposal') {
              $scope.counter = 5;
              $scope.performClickOnCasePhase();
              $scope.status13.open = true;
            }
          }
        }

        /* istanbul ignore next*/
        function checkStatus14(clickedTab) {
          if ($scope.status14.open === true) {
            $scope.status14.open = false;
          } else {
            if (clickedTab === 'RehearingDecisionTab') {
              $scope.counter = 5;
              $scope.performClickOnCasePhase();
              $scope.status14.open = true;
            }
          }
        }

        /* istanbul ignore next*/
        function checkStatus15(clickedTab) {
          if ($scope.status15.open === true) {
            $scope.status15.open = false;
          } else {
            if (clickedTab === 'subDecisionTab') {
              $scope.counter = 5;
              $scope.performClickOnCasePhase();
              $scope.status15.open = true;
            }
          }
        }

        function checkStatus10(clickedTab) {
          if ($scope.status10.open === true) {
            $scope.status10.open = false;
          } else {
            if (clickedTab === 'closedTab') {
              $scope.performClickOnCasePhase();
              $scope.status10.open = true;
            }
          }
        }
        /* istanbul ignore next*/
        function setNullClickedTab() {
          if ($scope.expandedValue === 0) {
            $scope.status5.open = true;
          }
          if ($scope.expandedValue === 1) {
            $scope.status6.open = true;
          }
          if ($scope.expandedValue === 2) {
            $scope.status7.open = true;
          }
          if ($scope.expandedValue === 3) {
            $scope.status8.open = true;
          }
          if ($scope.expandedValue === 5) {
            $scope.status10.open = true;
          }
          if ($scope.expandedValue === 4) {
            $scope.status12.open = true;
          }
          if ($scope.expandedValue === 4) {
            $scope.status13.open = true;
          }
        }

        $scope.setExpanded = function (number, clickedTab) {
          $scope.expandedValue = number;
          setPendingDocketing(number);
          setPanelingHearing(number);
          setPendingDecision(number);
          setPendingRehearingDecision(number);
          checkStatus5(clickedTab);
          checkStatus6(clickedTab);
          checkStatus7(clickedTab);
          checkStatus8(clickedTab);
          checkStatus10(clickedTab);
          checkStatus12(clickedTab);
          checkStatus13(clickedTab);
          checkStatus14(clickedTab);
          checkStatus15(clickedTab);
          if (clickedTab === "null") {
            setNullClickedTab();
          }
        };
        vm.actionFromChevron = function (num, selectedChevron) {
          $scope.setExpanded(num, selectedChevron);
        };
        vm.refreshactionchev = function (ststs) {
          $log.debug(ststs);
        };

        vm.changeState = function (expandState) {
          if ($scope.currentTab === 'bib' && !vm.isTrials) {
            $scope.status1.open = expandState;
            $scope.status2.open = expandState;
            $scope.status3.open = expandState;
            $scope.status3T.open = expandState;
            $scope.status4.open = expandState;
            $scope.statusNotes.open = expandState;
          }
          if ($scope.currentTab === 'bib' && vm.isTrials) {
            $scope.status3T.open = expandState;
          }
          if ($scope.currentTab === 'appeal') {
            $scope.status5.open = expandState;
            $scope.status6.open = expandState;
            $scope.status7.open = expandState;
            $scope.status8.open = expandState;
            $scope.status12.open = expandState;
            $scope.status13.open = expandState;
            $scope.status10.open = expandState;
          }
          if ($scope.currentTab === 'caseHistory') {
            $scope.statusAppDates.open = expandState;
            $scope.statusKeyDates.open = expandState;
          }
          if ($scope.currentTab === 'auditTrail') {
            $scope.statusAT1.open = expandState;
            $scope.statusAT2.open = expandState;
            $scope.statusNH.open = expandState;
          }
          if ($scope.currentTab === 'documents' && !vm.isTrials) {
            vm.getDocumentHistory();
          }
          if ($scope.currentTab === 'documents' && vm.isTrials) {
            vm.getAiaExhibitsCombine();
          }
        };

	    if (!$scope.currentTab) {
	    	$scope.currentTab = 'bib';
	    	vm.changeState(1);
	    } else {
	    	vm.changeState(0);
	    }
        
        
        /* istanbul ignore next*/
        vm.getBibliographic = function () {
          if (angular.isUndefined(vm.caseNumber)) {
            vm.caseNumber = 0;
          }
          var bibUrl = "/case-information/bib-data?serialNumber=" + vm.applicationNumber + "&appealNumber=" + vm.caseNumber;
          if (vm.isTrials) {
            bibUrl += "&proceedingType=TRIAL";
          } else {
            bibUrl += "&proceedingType=APPEAL";
          }
          HttpFactory.getActions(bibUrl)
            .then(function (successResponse) {
              vm.bibliographic = successResponse.data;
              vm.desInfo = vm.bibliographic.descriptiveInfo;
              vm.applentInfo = vm.bibliographic.descriptiveInfo.appellantsDetails;
              vm.applentToString = vm.applentInfo ? vm.applentInfo.join(' | ') : "--";
              vm.realPartiesInfo = vm.bibliographic.descriptiveInfo.realPartiesDetails;
              vm.realPartiesToString = vm.realPartiesInfo ? vm.realPartiesInfo.join(' | ') : "--";
              vm.parentInfo = vm.bibliographic.parentInfo;
              vm.corresInfo = vm.bibliographic.corrAddress;
              vm.thirdPartyInfo = vm.bibliographic.thirdPartyInfo;
              vm.caseNotesHistory = vm.bibliographic.caseNotesHistory;
              if (vm.bibliographic.partysInformation) {
                vm.petitionerside = vm.bibliographic.partysInformation.petitionCounsel;
                vm.petitionRealParty = vm.bibliographic.partysInformation.petitionRealParty;
                vm.poCounsel = vm.bibliographic.partysInformation.poCounsel;
                vm.poRealParty = vm.bibliographic.partysInformation.poRealParty;
              }
              buildCounselData(vm.petitionerside, vm.gridPetitionersCounsels);
              buildCounselData(vm.poCounsel, vm.gridPatentOwnersCounsels);
              buildRealPartyData(vm.petitionRealParty, vm.gridPetitionersRealParty, vm.gridAddtlPetitionersRealParty);
              buildRealPartyData(vm.poRealParty, vm.gridPatentOwnersRealParty, vm.gridAddtlPatentOwnersRealParty);
            }, function (failureResponse) {
              toastr.error(failureResponse, {
                iconClass: 'toast-danger'
              });
            });
        };

        /*update special types modal*/
        $scope.openSpecialTypes = function () {
          $scope.caseDetailsData = {
            "applicationNumber": vm.applicationNumber,
            "appealNumber": vm.caseNumber,
            "workerNumber": vm.workerNumber,
            "fullName": $scope.userInfo.fullName,
            "panelInString": vm.panelInString,
            "appealType": vm.desInfo.appealType
          };
          ngDialog.open({
            template: "app/caseViewer/updateSpecialTypes.html",
            controller: 'SpecialTypesController',
            scope: $scope,
            width: '50%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              partiesData: function () {
                return $scope.caseDetailsData;
              }
            }
          }).closePromise.then(function () {
            vm.getBibliographic();
          }, function () { //intentional
          });
        };

        /* to get assignment type, merged or non-mergedr*/
        vm.getAppealType = function () {
          HttpFactory.getActions("/appeals/assignment_type_merge_indicator?appealNumber=" + vm.caseNumber + "&serialNumber=" + vm.applicationNumber)
            .then(function (successResponse) {
              vm.appealType = successResponse.data;
            }, function () { //Non 200 response means empty return.   Expected response.
            });
        };

        if (!vm.isTrials) {
          vm.getAppealType();
        }
        /*update appeal type modal*/
        $scope.openAppealTypes = function () {
          $scope.caseDetailsData = {
            "applicationNumber": vm.applicationNumber,
            "appealNumber": vm.caseNumber,
            "workerNumber": vm.workerNumber,
            "fullName": $scope.userInfo.fullName,
          };
          ngDialog.open({
            template: "app/caseViewer/updateAppealTypes.html",
            controller: 'AppealTypesController',
            controllerAs: 'vm',
            scope: $scope,
            width: '40%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              partiesData: function () {
                return $scope.caseDetailsData;
              },
              appealType: function () {
                return vm.desInfo.appealType;
              },
              applicationNumber: function () {
                return vm.applicationNumber;
              },
              appealNumber: function () {
                return vm.caseNumber;
              },
              appealTypeAssignmnet: function () {
                return vm.appealType.assignmentType;
              },
              appealMergedType: function () {
                return vm.appealType.mergedCaseIndicator;
              },
            }
          }).closePromise.then(function () {
            $timeout(function () {
              vm.getBibliographic();
              $rootScope.chevronRefreshData();
            }, 500);
          }, function () { //intentional
          });
        };

        vm.closeAppealType = function () {
          ngDialog.closeAll();
        };

        /* istanbul ignore next*/
        $scope.openApplentDialog = function (event) {
          $scope.partiesShow = event.currentTarget.id;
          $scope.caseDetailsData = {
            "applicationNumber": vm.applicationNumber,
            "appealNumber": vm.caseNumber
          };
          ngDialog.open({
            template: "app/components/helperComponents/appellantsPartiesAndRealParties/appellantsPartiesAndRealParties.html",
            controller: 'AppellantsPartiesController',
            scope: $scope,
            width: '60%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              partiesData: function () {
                return $scope.caseDetailsData;
              },
              partiesFlag: function () {
                return $scope.partiesShow;
              },
            }
          }).closePromise.then(function () {
            vm.getBibliographic();
            vm.refreshData();
          }, function () { //intentional
          });
        };

        vm.refreshCaseviewer = function () {
          vm.getBibliographic();
        };

        vm.isAttorney = false;
        /* istanbul ignore next: toaster error*/
        vm.getCasePhase = function () {
          if (angular.isDefined(vm.caseNumber) && vm.caseNumber != null) {
            vm.caseNumberParam = vm.caseNumber;
          } else {
            vm.caseNumberParam = 0;
          }
          HttpFactory.getActions("/case-information/phases?serialNumber=" + vm.applicationNumber + "&appealNumber=" + vm.caseNumberParam)
            .then(function (successResponse) {
              vm.casePhase = successResponse.data;
              vm.casePhase.preAppealInfo.ptabReceivedDate = vm.dateConvert(vm.casePhase.preAppealInfo.ptabReceivedDate);
              vm.casePhase.preAppealInfo.appealAssignedDate = vm.dateConvert(vm.casePhase.preAppealInfo.appealAssignedDate);
              vm.casePhase.preAppealInfo.applicationFilingDate = vm.dateConvert(vm.casePhase.preAppealInfo.applicationFilingDate);
              vm.preAppeal = vm.casePhase.preAppealInfo;
              vm.casePhase.masterDocketInfo.docketingNoticeDate = vm.dateConvert(vm.casePhase.masterDocketInfo.docketingNoticeDate);
              vm.casePhase.masterDocketInfo.ewfCompletionDate = vm.dateConvert(vm.casePhase.masterDocketInfo.ewfCompletionDate);
              vm.casePhase.masterDocketInfo.masterDocketDate = vm.dateConvert(vm.casePhase.masterDocketInfo.masterDocketDate);
              vm.masterDocketInfo = vm.casePhase.masterDocketInfo;
              vm.casePhase.panellingInfo.panelDate = vm.dateConvert(vm.casePhase.panellingInfo.panelDate);
              vm.pendingPanelingPanellingInfo = vm.casePhase.panellingInfo;
              vm.casePhase.hearingInfo.panelDate = vm.dateConvert(vm.casePhase.hearingInfo.panelDate);
              vm.casePhase.hearingInfo.hearingNoticeDate = vm.dateConvert(vm.casePhase.hearingInfo.hearingNoticeDate);
              vm.casePhase.hearingInfo.hearingDate = vm.dateConvert(vm.casePhase.hearingInfo.hearingDate);
              vm.casePhase.hearingInfo.hearingTime = vm.casePhase.hearingInfo.hearingTime;
              vm.casePhase.hearingInfo.hearingLocationDescription = vm.casePhase.hearingInfo.hearingLocationDescription;
              vm.casePhase.hearingInfo.hearingAttendance = vm.casePhase.hearingInfo.hearingAttendance;

              vm.hearingInfo = vm.casePhase.hearingInfo;
              if (vm.hearingInfo.panelNames) {
                angular.forEach(vm.hearingInfo.panelNames, function (panel) {
                  if (panel.rank === 0) {
                    vm.isAttorney = true;
                    vm.attorneyName = panel.employeeName;
                  }
                });
              }

              vm.casePhase.decisionInfo.draftDecisionReviewCompletionDate = vm.dateConvert(vm.casePhase.decisionInfo.draftDecisionReviewCompletionDate);
              vm.casePhase.decisionInfo.panelCirculationCompletionDate = vm.dateConvert(vm.casePhase.decisionInfo.panelCirculationCompletionDate);
              vm.casePhase.decisionInfo.decisionMailDate = vm.dateConvert(vm.casePhase.decisionInfo.decisionMailDate);
              vm.casePhase.decisionInfo.decisionDueDate = vm.dateConvert(vm.casePhase.decisionInfo.decisionDueDate);
              vm.decisionInfo = vm.casePhase.decisionInfo;
              vm.pendingRehearingDecision = vm.casePhase.pendingRehearingDecision;
              vm.pendingSubsequentDecision = vm.casePhase.pendingSubsequentDecision;
              if (!vm.pendingSubsequentDecision.palmDate) {
                vm.pendingSubsequentDecision.palmDate = "N/A";
              }
              vm.pendingDismissal = vm.casePhase.pendingDismissal;
              vm.caseClosedDate = vm.dateConvert(vm.casePhase.caseClosedDate);
              vm.caseDisposedDate = vm.dateConvert(vm.casePhase.disposedDate);
            }, function (failureResponse) {
              toastr.error(failureResponse, {
                iconClass: 'toast-danger'
              });
            });
        };

        /* istanbul ignore next: toaster error*/
        vm.getCaseMilestones = function () {
          HttpFactory.getActions("/case-information/milestones?serialNumber=" + vm.applicationNumber + "&appealNumber=" + vm.caseNumber)
            .then(function (successResponse) {
              vm.caseMilestones = successResponse.data;
              vm.applicationDates = vm.caseMilestones.applicationDates;
              if (vm.applicationDates != null) {
                vm.rehearingRequestDate = vm.applicationDates.rehearingRequestDate;
                vm.rehearingPaneledDate = vm.applicationDates.rehearingPaneledDate;
                vm.rehearingRequestDueDate = vm.applicationDates.rehearingRequestDueDate;
                vm.rehearingRenderedDate = vm.applicationDates.rehearingRenderedDate;
                vm.applicationDates.filingDate = vm.dateConvert(vm.applicationDates.filingDate);
                vm.applicationDates.docketingNoticeDate = vm.dateConvert(vm.applicationDates.docketingNoticeDate);
                vm.applicationDates.docketingNoticeMailDate = vm.dateConvert(vm.applicationDates.docketingNoticeMailDate);
                vm.applicationDates.oralHearingRequestDate = vm.dateConvert(vm.applicationDates.oralHearingRequestDate);
                vm.applicationDates.noticeOfAppealDate = vm.dateConvert(vm.applicationDates.noticeOfAppealDate);
                vm.applicationDates.noticeOfHearingMailDate = vm.dateConvert(vm.applicationDates.noticeOfHearingMailDate);
                vm.applicationDates.noticeOfHearingDate = vm.dateConvert(vm.applicationDates.noticeOfHearingDate);
                vm.applicationDates.noticeOfAppealDate = vm.dateConvert(vm.applicationDates.noticeOfAppealDate);
                vm.applicationDates.hearingDate = vm.dateConvert(vm.applicationDates.hearingDate);
                vm.applicationDates.appealBriefDate = vm.dateConvert(vm.applicationDates.appealBriefDate);
                vm.applicationDates.examinerAnswerDate = vm.dateConvert(vm.applicationDates.examinerAnswerDate);
                vm.applicationDates.replyBriefDate = vm.dateConvert(vm.applicationDates.replyBriefDate);
                vm.applicationDates.hearingTranscriptDate = vm.dateConvert(vm.applicationDates.hearingTranscriptDate);
                vm.applicationDates.hearingTranscriptMailDate = vm.dateConvert(vm.applicationDates.hearingTranscriptMailDate);

                vm.applicationDates.paDueDate = vm.dateConvert(vm.applicationDates.paDueDate);
                vm.applicationDates.paDueDateAssignedDate = vm.dateConvert(vm.applicationDates.paDueDateAssignedDate);
                vm.applicationDates.conferenceDate = vm.dateConvert(vm.applicationDates.conferenceDate);

              }
              vm.caseInfo = vm.caseMilestones.appealDates;
              if (vm.caseInfo != null) {
                vm.caseInfo.filingDate = vm.dateConvert(vm.caseInfo.filingDate);
                vm.caseInfo.decisionDueDate = vm.dateConvert(vm.caseInfo.decisionDueDate);
                vm.caseInfo.docketingNoticeDate = vm.dateConvert(vm.caseInfo.docketingNoticeDate);
                vm.caseInfo.docketingNoticeMailDate = vm.dateConvert(vm.caseInfo.docketingNoticeMailDate);
                vm.caseInfo.oralHearingRequestDate = vm.dateConvert(vm.caseInfo.oralHearingRequestDate);
                vm.caseInfo.noticeOfHearingMailDate = vm.dateConvert(vm.caseInfo.noticeOfHearingMailDate);
                vm.caseInfo.noticeOfHearingDate = vm.dateConvert(vm.caseInfo.noticeOfHearingDate);
                vm.caseInfo.noticeOfAppealDate = vm.dateConvert(vm.caseInfo.noticeOfAppealDate);
                vm.caseInfo.hearingDate = vm.dateConvert(vm.caseInfo.hearingDate);
                vm.caseInfo.decisionMailDate = vm.dateConvert(vm.caseInfo.decisionMailDate);
                vm.caseInfo.appealBriefDate = vm.dateConvert(vm.caseInfo.appealBriefDate);
                vm.caseInfo.examinerAnswerDate = vm.dateConvert(vm.caseInfo.examinerAnswerDate);
                vm.caseInfo.replyBriefDate = vm.dateConvert(vm.caseInfo.replyBriefDate);
                vm.caseInfo.receivedDate = vm.dateConvert(vm.caseInfo.receivedDate);
                vm.caseInfo.decisionRenderedDate = vm.dateConvert(vm.caseInfo.decisionRenderedDate);
                vm.caseInfo.disposedDate = vm.dateConvert(vm.caseInfo.disposedDate);
                vm.caseInfo.rehearingDecisionMailDate = vm.dateConvert(vm.caseInfo.rehearingDecisionMailDate);
                vm.caseInfo.hearingTranscriptDate = vm.dateConvert(vm.caseInfo.hearingTranscriptDate);
                vm.caseInfo.hearingTranscriptMailDate = vm.dateConvert(vm.caseInfo.hearingTranscriptMailDate);
              }
            }, function (failureResponse) {
              toastr.error(failureResponse, {
                iconClass: 'toast-danger'
              });
            });
        };

        vm.dateConvert = function (recievedDate) {
          if (recievedDate !== null && recievedDate !== undefined) {
            return new Date(recievedDate).toLocaleDateString();
          } else {
            return null;
          }
        };

        vm.showAlert = function () { //intentional
        };

        /* istanbul ignore next: toaster error*/
        vm.getStatusHistory = function () {
          HttpFactory.getActions("/case-information/status-history?serialNumber=" + vm.applicationNumber + "&appealNumber=" + vm.caseNumber)
            .then(function (successResponse) {
              vm.statusHistory = successResponse.data.caseDetailsData;
              for (var i = 0; i < vm.statusHistory.length; i++) { //intentional
              }
              vm.gridOptionsStatus.data = successResponse.data.caseDetailsData;
              $scope.myData2 = angular.copy(vm.gridOptionsStatus.data);
            }, function (failureResponse) {
              toastr.error(failureResponse);
            });
        };

        /* istanbul ignore next: resolve error*/
        $scope.openAssignHistory = function (row) {
          $scope.assignData = row.entity;
          ngDialog.open({
            template: 'app/components/widgets/assignments/src/assignmnetHistory.html',
            controller: 'AssignmentHistoryController',
            controllerAs: 'vm',
            width: '80%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              assignmentData: function () {
                return $scope.assignData;
              }
            }
          });
        };

        vm.gridOptionsHistory.exporterFieldCallback = function (grid, row, col, value) {
          if (col.colDef.field === "audit") {
            value = "";
          }
          if (col.colDef.type === "date") {
            value = $filter('date')(value, 'MM/dd/yyyy');
          }
          return value;
        };

        /* istanbul ignore next: toaster error*/
        vm.getAssignHistory = function () {
          HttpFactory.getActions("/case-information/assignment-history?serialNumber=" + vm.applicationNumber + "&appealNumber=" + vm.caseNumber)
            .then(function (successResponse) {
              vm.assignHistory = successResponse.data.caseDetailsData;
              for (var i = 0; i < successResponse.data.caseDetailsData.length; i++) {
                vm.assignHistory[i].createTs = vm.dateConvert(vm.assignHistory[i].createTs);
                vm.assignHistory[i].assignmentDueDt = vm.dateConvert(vm.assignHistory[i].assignmentDueDt);
                vm.assignHistory[i].assignedDt = vm.dateConvert(vm.assignHistory[i].assignedDt);
                vm.assignHistory[i].completionDt = vm.dateConvert(vm.assignHistory[i].completionDt);
                vm.assignHistory[i].lastModifiedTs = vm.dateConvert(vm.assignHistory[i].lastModifiedTs);
              }
              vm.gridOptionsHistory.data = successResponse.data.caseDetailsData;
              angular.forEach(vm.gridOptionsHistory.data, function (row) {
                row.lastModifiedTimestamp = row.audit.lastModifiedTimestamp;
                row.createTimestamp = row.audit.createTimestamp;
              });
              $scope.myData1 = angular.copy(vm.gridOptionsHistory.data);
            }, function (failureResponse) {
              toastr.error(failureResponse);
            });
        };

        vm.expand = function (data) {
          if (data.show && data.show === 1) {
            data.show = 0;
            return '';
          }
          data.show = 1;
          return 'expandRow';
        };

        vm.isExpanded = function (data) {
          if (!data.show) {
            data.show = 0;
            return '';
          }
          if (data.show && data.show === 1) {
            return 'expandRow';
          }
          return '';
        };

        var ieDefs3 = [{
            name: 'Decision',
            displayName: 'Decision',
            width: 200,
            field: 'createDateTime',
            headerTooltip: 'Decision',
            sort: {
              direction: uiGridConstants.ASC,
              priority: 0
            }
          },
          {
            name: 'Decision date',
            displayName: 'Decision date',
            field: 'sendDateTime',
            type: 'date',
            cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'",
            width: 200,
            headerTooltip: 'Decision date'
          },
          {
            name: 'DecisionCode',
            displayName: 'Decision code',
            field: 'name',
            width: 467,
            headerTooltip: 'Decision code',
          },
          {
            name: 'Decision type',
            displayName: 'Decision type',
            width: 200,
            field: 'sender',
            headerTooltip: 'Decision type'
          },
          {
            name: 'APJ1/Administrator',
            displayName: 'APJ1/Administrator',
            width: 750,
            field: 'recipients',
            headerTooltip: 'APJ1/Administrator'
          },
          {
            name: 'APJ1 assigned date',
            displayName: 'APJ1 assigned date',
            width: 750,
            type: 'date',
            cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'",
            field: 'recipients',
            headerTooltip: 'APJ1 assigned date'
          },
          {
            name: 'Document reviewer',
            displayName: 'Document reviewer',
            width: 750,
            field: 'recipients',
            headerTooltip: 'Document reviewer'
          },
          {
            name: 'Document review completion date',
            displayName: 'Document review completion date',
            width: 750,
            type: 'date',
            cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'",
            field: 'recipients',
            headerTooltip: 'Document review completion date'
          },
          {
            name: 'Mailer',
            displayName: 'Mailer',
            width: 750,
            field: 'recipients',
            headerTooltip: 'Mailer'
          },
          {
            name: 'Mailed date',
            displayName: 'Mailed date',
            width: 750,
            type: 'date',
            cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'",
            field: 'recipients',
            headerTooltip: 'Mailed date'
          },
          {
            name: 'Rehearing requester',
            displayName: '1st rehearing requester',
            width: 750,
            field: 'recipients',
            headerTooltip: '1st rehearing requester'
          },
          {
            name: 'Rehearing request filed date',
            displayName: 'Rehearing request filed date',
            width: 750,
            type: 'date',
            cellFilter: "date:'MM/dd/yyyy hh:mm:ss a'",
            field: 'recipients',
            headerTooltip: 'Rehearing request filed date'
          },
        ];

        /* **This method finds the APJ1 judge and returns the judges name.*/
        /* istanbul ignore next*/
        vm.getAPJ1 = function (panel) {
          if (panel.length !== 0) {
            var foundJudge;
            angular.forEach(panel, function (judge) {
              if (judge.panelRank === 1) {
                foundJudge = judge;
              }
            });
            return foundJudge.panelName;
          }
          return "";
        };

        /*** This method finds the APJ1 judge and returns the judges assigned date.*/
        /* istanbul ignore next*/
        vm.getAPJ1AssignedDate = function (panel) {
          if (panel.length !== 0) {
            var foundJudge;
            angular.forEach(panel, function (judge) {
              if (judge.panelRank === 1) {
                foundJudge = judge;
              }
            });
            return $filter('date')(foundJudge.assignedDate, "MM/dd/yyyy  hh:mm:ss a");
          }
          return "";
        };

        vm.decisionExpandAll = function () {
          angular.forEach(vm.rehearingHistoryDetailsNow, function (row) {
            row.show = 1;
          });
        };
        vm.decisionCollapseAll = function () {
          angular.forEach(vm.rehearingHistoryDetailsNow, function (row) {
            row.show = 0;
          });
        };
        /*decision history*/
        vm.getDecisionHistoryDetails = function () {
          HttpFactory.getActions("/decision-history?serialNumber=" + vm.applicationNumber + "&appealNumber=" + vm.caseNumber)
            .then(function (successResponse) {
                vm.rehearingHistoryDetailsNow = successResponse.data.decisions;
                $scope.rehearingIndex = 0;
                vm.rehearingHistoryDetails = vm.rehearingHistoryDetailsNow[0];
              },
              function (failureResponse) {
                $log.info(failureResponse);
              });
        };
        if (!vm.isTrials) {
          vm.getDecisionHistoryDetails();
        }

        vm.gridOptionsNotificationHistory = {
          enableColumnResizing: true,
          enableHorizontalScrollbar: 2,
          enableGridMenu: true,
          rowHeight: 35,
          enableFiltering: true,
          columnDefs: ieDefs3
        };

        vm.gridOptionsNotificationHistory.data = [];
        var dataRow = {
          createDateTime: "07/04/2018",
          sendDateTime: "07/25/2018",
          sender: "Simon, Paul",
          recipients: "tom.sawyer@uspto.gov huck.finn@uspto.gov"
        };
        vm.gridOptionsNotificationHistory.data.push(dataRow);
        dataRow = {
          createDateTime: "07/04/2018",
          sendDateTime: "07/25/2018",
          sender: "Simon, Paul",
          recipients: "tom.sawyer@uspto.gov huck.finn@uspto.gov"
        };
        vm.gridOptionsNotificationHistory.data.push(dataRow);
        dataRow = {
          createDateTime: "07/04/2018",
          sendDateTime: "07/25/2018",
          sender: "Simon, Paul",
          recipients: "tom.sawyer@uspto.gov huck.finn@uspto.gov"
        };
        vm.gridOptionsNotificationHistory.data.push(dataRow);
        vm.gridOptionsNotificationHistory.data.push(dataRow);
        vm.gridOptionsNotificationHistory.data.push(dataRow);
        vm.gridOptionsNotificationHistory.data.push(dataRow);
        vm.gridOptionsNotificationHistory.data.push(dataRow);
        vm.gridOptionsNotificationHistory.data.push(dataRow);
        vm.gridOptionsNotificationHistory.data.push(dataRow);
        vm.gridOptionsNotificationHistory.data.push(dataRow);

        vm.gridOptionsRelatedCases = {
          enableColumnResizing: true,
          enableHorizontalScrollbar: 2,
          enableGridMenu: true,
          rowHeight: 35,
          columnDefs: [{
              name: 'appealNumber',
              displayName: 'Case #',
              headerTooltip: 'Case #',
              field: 'appealNumber',
              sort: {
                direction: uiGridConstants.ASC,
                priority: 0
              }
            },
            {
              name: 'caseType',
              displayName: 'Case type',
              headerTooltip: 'Case type',
              field: 'caseType'
            },
            {
              name: ' relationship',
              displayName: 'Relationship ',
              headerTooltip: 'Relationship',
              field: 'relationship'
            },
            {
              name: 'status',
              displayName: 'Status',
              headerTooltip: 'Status',
              field: 'statusCode'
            },
            {
              name: 'statusDate',
              displayName: 'Status date',
              headerTooltip: 'Status date',
              field: 'statusDate',
              type: 'date',
              cellFilter: 'date:"MM/dd/yyyy"'
            }
          ],
          onRegisterApi: function (gridApi) {
            vm.gridApiN = gridApi;
          }
        };

        /* istanbul ignore next: toaster error*/
        vm.getRelatedCases = function () {
          HttpFactory.getActions("/case-information/related-applications?serialNumber=" + vm.applicationNumber)
            .then(function (successResponse) {
              for (var i = 0; i < successResponse.data.relatedCases.length; i++) {
                successResponse.data.relatedCases[i].statusDate = vm.dateConvert(successResponse.data.relatedCases[i].statusDate);
              }
              vm.gridOptionsRelatedCases.data = successResponse.data.relatedCases;
            }, function (failureResponse) {
              toastr.error(failureResponse);
            });
        };
        if (!$scope.currentTab) {
        	$scope.currentTab = "bib";
        }
        if ($scope.currentTab === 'bib') {
          vm.getBibliographic();
        }

        /* istanbul ignore next*/
        $scope.notesText = {

        };
        $scope.tinymceOptionsforCaseNotes = {
          plugins: 'link image',
          toolbar: "undo redo bold italic",
          menu: {},
          browser_spellcheck: true,
          contextmenu: false,
          elementpath: false,

          init_instance_callback: function (editor) {
            var textContentTrigger = function () {
              $scope.newNote = editor.getBody().textContent;
            };
            editor.on('KeyUp', textContentTrigger);
            editor.on('ExecCommand', textContentTrigger);
            editor.on('SetContent', function (e) {
              if (!e.initial) {
                textContentTrigger();
              }
            });
          }
        };

        $timeout(function () {
          setAriaAttribute('mceu_0', "Undo");
          setAriaAttribute('mceu_1', "Redo");
          setAriaAttribute('mceu_2', "Bold");
          setAriaAttribute('mceu_3', "Italic");
        }, 4000);

        /* istanbul ignore next*/
        function setAriaAttribute(timeMcButtonId, text) {
          try {
            var tinyMcButton = document.getElementById(timeMcButtonId);
            var tinyMcButtonHTML = tinyMcButton.childNodes[0];
            tinyMcButtonHTML.setAttribute("aria-label", "Undo text");
            tinyMcButtonHTML.setAttribute("title", text);
          } catch (error) {
            $log.info("Error finding TinyMCE button");
          }
        }

        $scope.sort = function (param) {
          $scope.propertyName = param;
          if (param !== $scope.propertyName) {
            $scope.reverse = false;
          } else {
            $scope.reverse = !$scope.reverse;
          }
        };

        /**
         * This function will retrieve the list of comments to populate the dropdown
         */
        $scope.getCommentsList = function () {
          HttpFactory.getActions(CONSTANTS.URL.COMMENT_LIST)
            .then(function (successResponse) {
              $scope.commentsDropdownList = successResponse.data;
            }, function () { //Emptpy list is acceptable
            });
        };

        $scope.getCommentsList();
        /* istanbul ignore next*/
        $scope.getNotes = function () {
          if (!vm.isTrials) {
            HttpFactory.getActions("/case-information/notes?serialNumber=" + vm.applicationNumber + "&appealNumber=" + vm.caseNumber)
              .then(function (successResponse) {
                if (successResponse.data.appealNoteHistoryList) {
                  successResponse.data.appealNoteHistoryList.sort(function (a, b) {
                    return b.sequenceNumber - a.sequenceNumber;
                  });
                  vm.caseNotes = successResponse.data.appealNoteHistoryList;
                  for (var i = 0; i < vm.caseNotes.length; i++) {
                    var html = vm.caseNotes[i].noteText;
                    var div = document.createElement("div");
                    div.innerHTML = html;
                    vm.caseNotes[i].caseNotesRaw = div.innerText;
                  }
                }
                vm.caseType = successResponse.data.caseType;
                if (!$scope.propertyName) {
                  $scope.propertyName="lastModifiedTime";
                }

                $scope.sort($scope.propertyName);
              }, function (failureResponse) {
                toastr.error(failureResponse);
              })
              .finally(function () {
                $scope.getComments();
              });
          }
        };
        $scope.getNotes();

        /* istanbul ignore next*/
        $scope.getComments = function () {
          if (!vm.isTrials) {
            HttpFactory.getActions('/appeal-comment-history?serialNumber=' + vm.applicationNumber + '&appealNumber=' + vm.caseNumber)
              .then(function (successResponse) {
                successResponse.data.sort(function (a, b) {
                  return b.sequenceNumber - a.sequenceNumber;
                });
                if (successResponse.data.length > 0) {
                  vm.maxSequenceNumbers.comments = successResponse.data[0].sequenceNumber;
                } else {
                  vm.maxSequenceNumbers.comments = -1;
                }
                vm.caseComments = successResponse.data;
              }, function (failureResponse) {
                toastr.error(failureResponse);
              })
              .finally(function () {
                vm.createTableData();
              });
          }
        };

        /* istanbul ignore next*/
        vm.createTableData = function () {
          vm.tableData = [];
          angular.forEach(vm.caseNotes, function (note) {
            var tempNote = {
              "caseNotesRaw": note.caseNotesRaw,
              "text": note.noteText,
              "type": "Note",
              "sequenceNumber": note.sequenceNumber,
              "lastModifiedUserId": note.audit.lastModifiedUserIdentifier,
              "lastModifiedTime": note.audit.lastModifiedTimestamp
            };
            vm.tableData.push(tempNote);
          });
          angular.forEach(vm.caseComments, function (comment) {
            var tempComment = {
              "caseNotesRaw": comment.commentText,
              "text": comment.commentText,
              "type": "Comment",
              "lastModifiedUserId": comment.audit.lastModifiedUserIdentifier,
              "lastModifiedTime": comment.audit.lastModifiedTimestamp
            };
            vm.tableData.push(tempComment);
          });
          vm.tableData.sort(function (a, b) {
            return b.lastModifiedTime - a.lastModifiedTime;
          });
          vm.disableSaveButton = true;
        };

        /* istanbul ignore next*/
        $scope.saveNotes = function () {
          var seqNo = vm.caseNotes[0].sequenceNumber;
          seqNo++;
          var postNotesObject = {};
          postNotesObject.appealNoteHistoryList = [];
          var dataObject = {
            "serialNumber": vm.applicationNumber,
            "sequenceNumber": seqNo,
            "appealNumber": vm.caseNumber,
            "lifeCycle": null,
            "audit": {
              "lastModifiedUserIdentifier": workerNumber,
              "lastModifiedTimestamp": new Date().getTime(),
              "createUserIdentifier": null,
              "createdUserName": null,
              "lastModifiedUserName": null,
              "createTimestamp": null,
              "lockControlNumber": null
            },
            "noteText": $scope.notesText.tx
          };
          postNotesObject.appealNoteHistoryList.push(dataObject);
          HttpFactory.postActions("/case-information/notes", postNotesObject)
            .then(function () {
              $scope.getNotes();
              $scope.notesText.tx = "";
            }, function (failureResponse) {
              toastr.error(failureResponse);
            });
        };

        vm.constructAllDocumentListDownload = function() {
          HttpFactory.downloadzip("/case-documents/createExcelReport-papers-exhibits?proceedingNumber=" + vm.caseNumber)
          .then(function (successResponse) {
            var blob = new Blob([successResponse.data], {
              type: 'text/csv'
            });
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = vm.caseNumber + "_docs.xlsx";
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
          }, function (failureResponse) {
            toastr.error(failureResponse);
          });
        };

        //get call for pdf preview for documents
        /* istanbul ignore next */
        $scope.openPdf = function (row) {
          vm.selectedDocument = row;
          HttpFactory.getActions("/data-documents/pdf?serialNumber=" + vm.applicationNumber + '&docCode=' + row.documentCode + '&officialStrtDate=' + row.officialDateEpoch)
            .then(function (successResponse) {
              vm.pdfContent = 'data:application/pdf;base64,' + successResponse.data.fileContent;
              $http.get(vm.pdfContent, {
                  responseType: 'arraybuffer'
                })
                .success(function (data) {
                  var file = new Blob([data], {
                    type: 'application/pdf'
                  });
                  var fileURL = URL.createObjectURL(file);
                  if (null !== $scope.pdfContent && document.getElementById('documentPreview') !== null) {
                    angular.element(document.getElementById('documentPreview')).scope().pdfContent = $sce.trustAsResourceUrl(fileURL);
                  } else {
                    $scope.pdfContent = $sce.trustAsResourceUrl(fileURL);
                  }
                  if (fileURL !== '' || angular.isDefined(fileURL)) {
                    $scope.pdfStyle = {
                      "border": "1px solid grey"
                    };
                  }
                }).error(function () { //intentional
                });
            }, function (failureResponse) {
              toastr.error(failureResponse);
            });
        };

        /* istanbul ignore next */
        $scope.openPdfCombine = function (row) {
          HttpFactory.getActions("/data-documents/pdf?serialNumber=" + vm.applicationNumber + '&docCode=' + row.documentCode + '&officialStrtDate=' + row.officialDateEpoch)
            .then(function (successResponse) {
              vm.pdfContentDoc = 'data:application/pdf;base64,' + successResponse.data.fileContent;
              $http.get(vm.pdfContentDoc, {
                  responseType: 'arraybuffer'
                })
                .success(function (data) {
                  var file = new Blob([data], {
                    type: 'application/pdf'
                  });
                  var fileURL = URL.createObjectURL(file);
                  if ($scope.pdfContentDoc !== null) {
                    angular.element(document.getElementById('documentPreview')).scope().pdfContentDoc = $sce.trustAsResourceUrl(fileURL);
                  } else {
                    $scope.pdfContentDoc = $sce.trustAsResourceUrl(fileURL);
                  }
                  if (fileURL !== '' || angular.isDefined(fileURL)) {
                    $scope.pdfStyle = {
                      "border": "1px solid grey"
                    };
                  }
                  var w=$window.open(fileURL);
                  setTimeout(function(){ w.document.title= vm.caseNumber+" - "+row.documentDescription;},3000);
                }).error(function () {
                  // Intentional
                });
            }, function (failureResponse) {
              toastr.error(failureResponse);
            });
        };

        /**
         * This function will open the add comment modal from the Bibliographic Data tab in the case viewer
         * @caseInfo - Contains application number, case number, and userID
         * @maxSequenceNumbers - Maximum sequence numbers for comments and notes
         * @commentsList - List of comments to populate the dropdown in the modal
         */
        /* istanbul ignore next*/
        $scope.openCommentModal = function () {
          var info = {
            "serialNumber": vm.applicationNumber,
            "appealNumber": vm.caseNumber,
            "audit": {
              "lastModifiedUserIdentifier": vm.workerNumber
            }
          };
          ngDialog.open({
            template: "app/caseViewer/addComment.html",
            controller: 'AddCommentController',
            controllerAs: "vm",
            width: '25%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              caseInfo: function () {
                return info;
              },
              maxSequenceNumbers: function () {
                return vm.maxSequenceNumbers;
              },
              commentsList: function () {
                return $scope.commentsDropdownList;
              }
            }
          }).closePromise.then(function (response) {
            if (response.value) {
              $scope.getNotes();
            }
          }, function () { //Empty response is ok.
          });
        };


        function setUpNoteModal() {
           var info = {
            "serialNumber": vm.applicationNumber,
            "appealNumber": vm.caseNumber,
            "audit": {
              "lastModifiedUserIdentifier": vm.workerNumber
            }
          };
          return info;
        }
        /**
         * This function will open the add note modal from the Bibliographic Data tab in the case viewer
         * @caseInfo - Contains application number, case number, and userID
         * @maxSequenceNumbers - Maximum sequence numbers for comments and notes
         */
        /* istanbul ignore next*/
        $scope.openNoteModal = function (row) {
          if (row) {
            vm.maxSequenceNumbers.notes = row.sequenceNumber;
          } else {
            vm.maxSequenceNumbers.notes = (angular.isDefined(vm.caseNotes) && vm.caseNotes.length > 0) ? vm.caseNotes[0].sequenceNumber : -1;
          }

          var info = setUpNoteModal();

          ngDialog.open({
            template: "app/caseViewer/addNote.html",
            controller: 'AddNoteController',
            controllerAs: "vm",
            width: '60%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              caseInfo: function () {
                return info;
              },
              maxSequenceNumbers: function () {
                return vm.maxSequenceNumbers;
              },
              rowToEdit : function() {
                return row;
              }
            }
          }).closePromise.then(function (response) {
            if (response.value) {
              $scope.getNotes();
            }
          }, function () { // Empty reponse is fine.
          });
        };


        $scope.selectTab = function (currentTab) {
          $scope.currentTab = currentTab;
          if ($scope.currentTab === 'bib') {
            vm.getBibliographic();
            $scope.status5.open = false;
            if (vm.isTrials) {
              vm.showDownloadButton = false;
            }
          }
          if ($scope.currentTab === 'appeal') {
            if (vm.isTrials) {
              vm.showDownloadButton = false;
            }
            if (vm.currentPhase === vm.caseDisposed && vm.beforePreviousPhase === vm.PendingMasterDocketing) {
              vm.getCasePhase();
            } else {
              if (document.getElementById("panelTab")) {
                vm.tab = document.getElementById("panelTab").innerHTML;
              }
              vm.getCasePhase();
            }
          }
          if ($scope.currentTab === 'caseHistory') {
            vm.getCaseMilestones();
            vm.changeState(1);
            if (vm.isTrials) {
              vm.showDownloadButton = false;
            }
          }
          if ($scope.currentTab === 'relatedCases') {
            vm.getRelatedCases();
            vm.changeState(1);
            if (vm.isTrials) {
              vm.showDownloadButton = false;
            }
          }
          if ($scope.currentTab === 'auditTrail') {
            vm.getStatusHistory();
            vm.getAssignHistory();
            vm.changeState(1);
            if (vm.isTrials) {
              vm.showDownloadButton = false;
            }
          }
          if ($scope.currentTab === 'caseDueDates') {
            vm.getKeyDates();
            if (vm.isTrials) {
              vm.showDownloadButton = false;
            }
          }
          if ($scope.currentTab === 'documents' && !vm.isTrials) {
            vm.getDocumentHistory();
            vm.showDownloadButton = false;
          }
          if ($scope.currentTab === 'documents' && vm.isTrials) {
            vm.showDownloadButton = true;
          }
        };
        $scope.isActiveTab = function (tab) {
          return $scope.currentTab === tab;
        };

        window.onbeforeunload = closingCode;
        /* istanbul ignore next */
        function closingCode() {
          workerNumber = $window.sessionStorage.removeItem("workerNumber");
        }
        vm.getCustomDatesClob = function () {
          HttpFactory.getActions(CONSTANTS.URL.CUSTOMDATES)
            .then(function (successResponse) {
              $scope.customObj = {};
              if (successResponse.data[0].valueText === "VIEW_CASE_DOCKETS") {
                vm.dueDatesClob = successResponse.data[0].descriptionText ? JSON.parse(successResponse.data[0].descriptionText) : {};
              }
            }, function (failureResponse) {
              $log.info(failureResponse);
            });
        };

        vm.getKeyDates = function () {
          vm.getCustomDatesClob();
          var isTrialUrl = "";
          if (vm.isTrials) {
            isTrialUrl = "&proceedingType=TRIAL";
          } else {
            isTrialUrl = "&proceedingType=APPEAL";
          }
          HttpFactory.getActions(CONSTANTS.URL.CUSTOM_DATES + "?applicationNumber=" +
              vm.applicationNumber + "&appealNumber=" + vm.caseNumber + "&applicationUserId=" +
              $scope.userInfo.userIdentiifier + isTrialUrl)
            .then(function (successResponse) {
              vm.caseDueDates = successResponse.data.definedDates;
              if (vm.caseDueDates.length === 0) {
                vm.caseDueDates = vm.dueDatesClob;
              } else if (vm.caseDueDates.length !== 5) {
                vm.dueDatesClob.forEach(function (ele, i) {
                  if (i > vm.caseDueDates.length - 1) {
                    vm.caseDueDates.push(ele);
                  }
                });
              }
              vm.thereAreCaseDueDates = vm.caseDueDates.length > 0 ? true : false;
            }, function () {
              vm.caseDueDates = vm.dueDatesClob;
              vm.thereAreCaseDueDates = true;
            });
        };
        vm.openManageCaseDueDatesModal = function () {
          ngDialog.open({
            template: "app/caseViewer/caseDueDates/manageCaseDueDatesModal.html",
            controller: 'ManageCaseDueDatesController',
            controllerAs: "vm",
            width: '40%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              caseDueDates: function () {
                return JSON.parse(JSON.stringify(vm.caseDueDates));
              },
              caseDueDateNames: function () {
                return vm.caseDueDateNames;
              },
              userInfo: function () {
                return $scope.userInfo;
              },
              isTrial: function () {
                return vm.isTrials;
              },
              applicationInfo: function () {
                return {
                  'applicationNumber': vm.applicationNumber,
                  'caseNumber': vm.caseNumber
                };
              }
            }
          }).closePromise.then(function (response) {
            if (response.value) {
              vm.getKeyDates();
            }
          });
        };

        $scope.getExternalUrls = function () {
          HttpFactory.getActions(CONSTANTS.URL.EXTERNALURLS)
            .then(function (successResponse) {
              $scope.externalUrls = [];
              for (var key in successResponse.data) {
                if (key !== "Open in PTOZone" && key !== "ptabReadOnlyUser" &&
                  key !== "allowedResourceObjectList" && key !== "ptabDueDateNonEditableUser" && key !== 'ptabDefaultRefreshTime') {
                  var url = {
                    description: key,
                    url: successResponse.data[key]
                  };
                  $scope.externalUrls.push(url);
                }
              }
            }, function () { // Empty response is ok.
            });
        };
        $scope.getExternalUrls();

        /** Update PTAB paneling discipline */
        $scope.updatePanelingDiscipline = function () {
          var info = {
            "applicationNumber": vm.applicationNumber,
            "appealNumber": vm.caseNumber,
            "originalPanelingDiscipline": vm.desInfo.panellingDisciplineDescriptionText ? vm.desInfo.panellingDisciplineDescriptionText : vm.desInfo.caseDiscipline,
            "panelingDiscipline": vm.desInfo.panelingDisciplineCode ? vm.desInfo.panelingDisciplineCode : vm.desInfo.caseDisciplineCode,
            "caseDiscipline": vm.desInfo.caseDisciplineCode
          };
          ngDialog.open({
            template: "app/caseViewer/panelingDisciplineModal.html",
            controller: 'PanelingDisciplineModalController',
            scope: $scope,
            width: '30%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              info: function () {
                return info;
              }
            }
          }).closePromise.then(function () {
            vm.getBibliographic();
            vm.getCasePhase();
          }, function () { // User clicked cancel.
          });
        };

        /** Update Decision Outcome */
        $scope.updateDecisionOutcome = function () {
          var info = {
            "outcome":vm.decisionInfo.decisionOutcome,
            "applicationNumber": vm.applicationNumber,
            "appealNumber": vm.caseNumber,
            "serialNumber": vm.applicationNumber,
          };
          ngDialog.open({
            template: "app/caseViewer/pendingDecisionOutcomeModal.html",
            controller: 'PendingDecisionOutcomeModalController',
            scope: $scope,
            width: '41%',
            showClose: false,
            closeByEscape: false,
            closeByDocument: false,
            resolve: {
              info: function () {
                return info;
              }
            }
          }).closePromise.then(function () {
            vm.getBibliographic();
            vm.getCasePhase();
          }, function () { // User clicked cancel.
          });
        };

        /** Update PA dates */
        vm.openPAdateModal = function (type, date) {
          var info = {
            "type" : type,
            "applicationNumber": vm.applicationNumber,
            "appealNumber": vm.caseNumber,
            "assignmentDueDate": date,
            "paDueDate": vm.applicationDates.paDueDate,
            "paDueDateAssignedDate": vm.applicationDates.paDueDateAssignedDate,
            "conferenceDate": vm.applicationDates.conferenceDate,
            "userId" : vm.workerNumber
          };


          ngDialog.openConfirm({
            template: 'app/caseViewer/paDatesModal.html',
            controller: 'PAdatesController',
            data: info,
            width: '20%',
            controllerAs: '$scope'
          }).then(function (newData) {
            vm.applicationDates.paDueDate = newData.paDueDate;
            vm.applicationDates.paDueDateAssignedDate = newData.paDueDateAssignedDate;
            vm.applicationDates.conferenceDate = newData.conferenceDate;
          }, function () { // User clicked cancel.
            console.info("Cancel");
          });
        };

        



      };
    });
