(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('PAdatesController', function ($scope, HttpFactory, $window, ngDialog, CommonHelperService, CONSTANTS) {
      $scope.info = $scope.ngDialogData;
      $scope.info.assignmentDueDate = convertToTime($scope.info.assignmentDueDate);
      $scope.noDateChanged=true;

      var dateInput = {
        "serialNumber": $scope.info.applicationNumber,
        "appealNumber": $scope.info.appealNumber,
        "audit": {
          "lastModifiedUserIdentifier": $scope.info.userId,
          "createUserIdentifier": $scope.info.userId
        }
      };
      var dateToSave;
      if ($scope.info.type==='dueDate') {
        $scope.title= 'Update PA due date';
        dateToSave = "paDueDate";
      } else if ($scope.info.type==='conferenceDate') {
        dateToSave = "conferenceDate";
        $scope.title="Update PA conference date";
      } else {
        dateToSave="paDueDateAssignedDate";
        $scope.title="Update PA assigned due date";
      } 
      $scope.assignmentDate =  $scope.info.currentDate;

      $scope.updateDate = function () {
        
        var dateToSave;
        if ($scope.info.type==='dueDate') {
          dateInput.paDueDate = $scope.info.assignmentDueDate.getTime();
          dateInput.conferenceDate = convertToTime($scope.info.conferenceDate);
          dateInput.paDueDateAssignedDate = new Date().getTime();
        } else if ($scope.info.type==='conferenceDate') {
          dateInput.conferenceDate = $scope.info.assignmentDueDate.getTime();
          dateInput.paDueDate = convertToTime($scope.info.paDueDate);
          dateInput.paDueDateAssignedDate = convertToTime($scope.info.paDueDateAssignedDate);
        } else {
          dateInput.paDueDateAssignedDate = $scope.info.assignmentDueDate.getTime();     
          dateInput.conferenceDate = convertToTime($scope.info.conferenceDate);
          dateInput.paDueDate = convertToTime($scope.info.paDueDate);
        } 

        HttpFactory.putActions("/appeal-decision/update_pa_dates", dateInput)
          .then(function (successResponse) {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.panelingDisciplineModalControllerSuccess, "success");
           
            $scope.confirm(dateInput);
          
          }, function (failureResponse) {
            CommonHelperService.setToastr(failureResponse.data.message, 'error');
          });
      };

      $scope.dateValueChanged = function() {
        $scope.noDateChanged = false;
      };

      function convertToTime(dateString) {
        if (dateString) {
          return new Date(dateString).getTime();
        }
        return null;
      }
    });
})();
