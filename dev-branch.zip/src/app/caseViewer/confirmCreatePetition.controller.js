(function () {
  'use strict';
  angular
    .module('ptabe2e')
    .controller('confirmCreatePetitionController', function ($scope, ngDialog, palmCode, HttpFactory, CommonHelperService, CONSTANTS) {
      var vm = this;
      vm.palmCode = palmCode;
      vm.closeModal = function () {
        ngDialog.closeAll();
      };

    });
})();
