(function () {
  'use strict';

  describe('AddNoteController', function () {

    beforeEach(module('ptabe2e'));
    var $controller;
    var vm = this;
    var controller, scope, $rootScope, $CommonHelperService;
    var successResponse, failureResponse;
    var $httpBackend, spy, $q, HttpFactoryDeferred;
    var caseInfo = {};
    caseInfo.audit = {};
    var maxSequenceNumbers = {
      comments: {

      }
    }
    var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'closeAll']);

    var fakeElement = function (params) {
      return {
        scope: function () {
          return {
            vm: {
              getWidgetZone: function () {

              },
              setWidgetContentHeight: function () {

              }
            }
          }
        }
      }
    };

    beforeEach(inject(function (_$controller_, _$rootScope_, _$httpBackend_, _$q_, HttpFactory, _CommonHelperService_) {
      $q = _$q_;
      scope = _$rootScope_.$new();
      $controller = _$controller_;
      $rootScope = _$rootScope_;
      $httpBackend = _$httpBackend_;
      $CommonHelperService = _CommonHelperService_;
      // $ngDialog.open.and.returnValue({
      //   then: function (callback1, callback2) {
      //     callback1();
      //     callback2();
      //   }
      // });
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'postActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn($CommonHelperService, 'setToastr').and.callFake(function () {
        return "toastr";
      });
      spy = spyOn(angular, 'element').and.callFake(fakeElement);

      controller = $controller('AddNoteController', {
        $scope: scope,
        ngDialog: ngDialog,
        $rootScope: _$rootScope_,
        HttpFactory: HttpFactory,
        caseInfo: caseInfo,
        maxSequenceNumbers: maxSequenceNumbers
      });
    }));

    describe('AddNoteController ', function () {

      it('should call closeAddNoteModal ', function () {
        expect(ngDialog.closeAll).toBeDefined();
        expect(controller.closeAddNoteModal).toBeDefined();
        controller.closeAddNoteModal();
        expect(ngDialog.closeAll).toHaveBeenCalled();
      });

      it('should call addNote and get successResponse', function () {
        expect(controller.addNote).toBeDefined();
        controller.addNote();
        HttpFactoryDeferred.resolve(successResponse);
        $rootScope.$apply();
      });

      it('should call addNote and get failureResponse', function () {
        failureResponse = {
          data: {
            "message": "Note not saved"
          }
        };
        expect(controller.addNote).toBeDefined();
        controller.addNote();
        HttpFactoryDeferred.reject(failureResponse);
        $rootScope.$apply();
      });

    });
  });
})();
