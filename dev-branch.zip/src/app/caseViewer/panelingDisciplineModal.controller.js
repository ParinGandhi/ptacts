(function () {
  'use strict';

  angular
    .module('ptabe2e')
    .controller('PanelingDisciplineModalController', function ($scope, HttpFactory, info, $window, ngDialog, CommonHelperService, CONSTANTS) {

      $scope.info = info;
      $scope.disciplineChanged = false;

      function getPanelingDisciplineList() {
        HttpFactory.getActions("/appeal-paneling-discipline")
          .then(function (successResponse) {
            $scope.panelingDisciplineList = successResponse.data.sort(compare);
            for (var i = 0; i < $scope.panelingDisciplineList.length; i++) {
              if ($scope.panelingDisciplineList[i].proceedingDisciplineDescriptionText === $scope.info.originalPanelingDiscipline) {
                $scope.selectedDiscipline = i.toString();
              }
            }
          }, function () {
            //intentional
          });
      }

      getPanelingDisciplineList();

      $scope.changeDiscipline = function (index) {
        if ($scope.panelingDisciplineList[parseInt(index, CONSTANTS.GLOBAL.RADIX)].proceedingDisciplineDescriptionText !== $scope.info.originalPanelingDiscipline) {
          $scope.changed = $scope.panelingDisciplineList[parseInt(index, CONSTANTS.GLOBAL.RADIX)];
          $scope.disciplineChanged = true;
        }
      };


      $scope.updateDiscipline = function () {
        var newDiscipline = {
          "panelingDisciplineCode": $scope.changed.proceedingDisciplineCode,
          "caseDisciplineCode": $scope.info.caseDiscipline,
          "appealNumber": $scope.info.appealNumber,
          "audit": {
            "createUserIdentifier": $window.sessionStorage.getItem("workerNumber"),
            "lastModifiedUserIdentifier": $window.sessionStorage.getItem("workerNumber")
          }
        };
        console.log(newDiscipline);
        console.log(JSON.stringify(newDiscipline));

        HttpFactory.putActions("/appeal-paneling-discipline/update-appeal-appealpanelingdisciplinelog", newDiscipline)
          .then(function (successResponse) {
            CommonHelperService.setToastr(CONSTANTS.TOASTER.panelingDisciplineModalControllerSuccess, "success");
            ngDialog.closeAll();
            console.log(successResponse);
          }, function (failureResponse) {
            CommonHelperService.setToastr(failureResponse.data.message, 'error');
          });
      };


      $scope.cancelPanelDiscipline = function () {
        ngDialog.closeAll();
      };

      /** Sort the list of disciplines alphabetically */
      function compare(a, b) {
        var disciplineA = a.proceedingDisciplineDescriptionText.toUpperCase();
        var disciplineB = b.proceedingDisciplineDescriptionText.toUpperCase();

        var comparison = 0;
        if (disciplineA > disciplineB) {
          comparison = 1;
        } else if (disciplineA < disciplineB) {
          comparison = -1;
        }
        return comparison;
      }

    });
})();
