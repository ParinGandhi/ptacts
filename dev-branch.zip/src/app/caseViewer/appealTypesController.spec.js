(function () {
  'use strict';

  describe('AppealTypesController', function () {

    beforeEach(module('ptabe2e'))
    var $controller;
    var vm = this;
    var controller, scope, $rootScope;
    var successResponse, row, appType;
    var $httpBackend, spy, HttpFactoryDeferred;
    var ngDialog = jasmine.createSpyObj('ngDialog', ['open', 'close', 'closeAll']);
    var $q, $http, $interval;
    var appealTypeAssignmnet, appealMergedType;
    var valueChanged, b_hOrh_b;
    var failureResponse = '';
    var successResponse = '';
    var partiesData = {
      "applicationNumber": "15374255",
      "appealNumber": "2020000257",
      "workerNumber": "eswift",
      "fullName": "Swift, Erica "
    };
    var applicationNumber = "15374255";
    var appealType = "Heard";
    //var originalAppealType = "H";
    var valueChanged = false;

    var appealNumber = "2020000257";
    // appealTypeAssignmnet = "CDDD";
    // appealMergedType = true;

    beforeEach(inject(function (_$controller_, _$http_, _$rootScope_, _$interval_, _$q_, HttpFactory) {
      $q = _$q_;
      $http = _$http_;
      scope = _$rootScope_.$new();
      $interval = _$interval_;
      $rootScope = _$rootScope_;
      $rootScope.mergedApplListForToastr = ""
      //   partiesData = partiesData;
      //   appealTypeAssignmnet = appealTypeAssignmnet;
      //   appealTypeAssignmnet = appealMergedType;
      //   applicationNumber = applicationNumber;
      //   appealType = appealType;
      // scope.mergedApplListForToastr = "";
      scope.partiesData = {
        "applicationNumber": "15374255",
        "appealNumber": "2020000257",
        "workerNumber": "eswift",
        "fullName": "Swift, Erica "
      };
      scope.appealType = "Heard";
      // scope.applicationNumber = "15374255";
      // scope.appealNumber = "2020000257";
      // scope.appealTypeAssignmnet = "CDDD";
      // scope.appealMergedType = true;
      // scope.valueChanged = true;
      // scope.b_hOrh_b = "H_B";
      // scope.originalAppealType = "H";
      // scope.valueChanged = true;
      // scope.b_hOrh_b = "H_B";

      // setup the promise
      HttpFactoryDeferred = _$q_.defer();
      spyOn(HttpFactory, 'getActions').and.returnValue(HttpFactoryDeferred.promise);
      spyOn(HttpFactory, 'putActions').and.returnValue(HttpFactoryDeferred.promise);
      $controller = _$controller_;

      controller = $controller('AppealTypesController', {
        $http: $http,
        $scope: scope,
        $rootScope: _$rootScope_,
        $interval: $interval,
        HttpFactory: HttpFactory,
        // shareAssign: shareAssign,
        appealTypeAssignmnet: appealTypeAssignmnet,
        appealMergedType: appealMergedType,
        appealNumber: appealNumber,
        applicationNumber: applicationNumber,
        appealType: appealType,
        // originalAppealType: originalAppealType,
        valueChanged: valueChanged,
        b_hOrh_b: b_hOrh_b,
        // mergedApplListForToastr: mergedApplListForToastr,
        partiesData: partiesData
        // newAppealType: newAppealType
      });
    }));


    describe('check functions', function () {

      it('it should call setAppealType ', function () {
        expect(controller.setAppealType).toBeDefined();
        controller.setAppealType();
      });


      it('it should call closeAppealType ', function () {
        expect(controller.closeAppealType).toBeDefined();
        controller.closeAppealType();
      });

      it('it should call saveAppealTypes failureResponse', function () {

        failureResponse = {
          data: "FAILED"
        };
        expect(controller.saveAppealTypes).toBeDefined();
        controller.saveAppealTypes();
        HttpFactoryDeferred.reject(failureResponse);
        scope.$digest();
      });

      it('it should call saveAppealTypes failureResponse', function () {

        successResponse = {
          data: ""
        };
        expect(controller.saveAppealTypes).toBeDefined();
        controller.saveAppealTypes();
        HttpFactoryDeferred.resolve(successResponse);
        scope.$digest();
      });

      //       // it('it should call closeAppealType ', function () {
      //       //   expect(ngDialog.closeAll).toBeDefined();
      //       //   expect(controller['closeAppealType']).toBeDefined();
      //       //   controller.closeAppealType();
      //       //   expect(ngDialog.closeAll).toHaveBeenCalledWith();
      //       // });

      //       //   it(' should call setAppealType', function () {
      //       //     appType = "B";
      //       //     // controller.originalAppealType = "H";
      //       //     // controller.valueChanged = true;
      //       //     // controller.b_hOrh_b = "H_B";
      //       //     expect(controller.setAppealType).toBeDefined();
      //       //     controller.setAppealType(appType);
      //       //   });

      //       // it(' should call openCirculationManager', function () {
      //       //   row = {
      //       //     "entity": {
      //       //       "serialNumber": "90008169",
      //       //       "appealNumber": "2020000030",
      //       //       "patentNumber": "RE34783",
      //       //       "trialsNumber": "2020000030"
      //       //     }
      //       //   }
      //       //   controller.circulationViewable = true;
      //       //   expect(scope['openCirculationManager']).toBeDefined();
      //       //   scope.openCirculationManager(row);
      //       // });

      //       // it('it should call getCaseInfo failureResponse', function () {
      //       //   row = {
      //       //     "entity": {
      //       //       "serialNumber": "90008169",
      //       //       "appealNumber": "545666",
      //       //       "patentNumber": "RE34783",
      //       //       "trialsNumber": "2020000030"
      //       //     }
      //       //   }
      //       //   failureResponse = {
      //       //     data: "FAILED"
      //       //   };
      //       //   expect(scope.getCaseInfo).toBeDefined();
      //       //   scope.getCaseInfo(row);
      //       //   HttpFactoryDeferred.reject(failureResponse);
      //       //   scope.$digest();
      //       // });

      //       // it('it should call getCaseInfo success', function () {
      //       //   row = {
      //       //     "entity": {
      //       //       "serialNumber": "90008169",
      //       //       "appealNumber": "545666",
      //       //       "patentNumber": "RE34783",
      //       //       "trialsNumber": "2020000030"
      //       //     }
      //       //   }
      //       //   successResponse = {
      //       //     data: [{
      //       //       "circulationReorderExists": false,
      //       //       "casetransactionDetails": [],
      //       //       "briefHearingTypeCode": "On brief",
      //       //       "casePhase": "Pending Decision",
      //       //       "inventionTitle": "CONFOCAL WAFER-INSPECTION SYSTEM",
      //       //       "interruptInProcess": false,
      //       //       "patentNumberText": "6934019",
      //       //       "proceedingNumber": "2019004454",
      //       //       "ptabDefaultRefreshTime": 300000,
      //       //       "ptabReadOnlyUser": false,
      //       //       "mileStoneDates": null,
      //       //       "parties": "6,934,019  et al.",
      //       //       "attorneys": [{
      //       //         employeeName: "Squire, Monte T.",
      //       //         rank: 1
      //       //       }, {
      //       //         employeeName: "Lebovitz, Richard M.",
      //       //         rank: 2
      //       //       }],
      //       //       "ptabDueDateNonEditableUser": false,
      //       //       "circulationViewable": true,
      //       //       "appealNumberText": "2019004454",
      //       //       "applicationTypeCategory": "REEXAM"
      //       //     }]
      //       //   };
      //       //   expect(scope.getCaseInfo).toBeDefined();
      //       //   scope.getCaseInfo(row);
      //       //   HttpFactoryDeferred.resolve(successResponse);
      //       //   $rootScope.$apply();
      //       // });



      //       // it(' should call optionCase', function () {
      //       //   scope.searchThis = ""
      //       //   scope.searchTerm = "CASE_NUMBER";
      //       //   scope.searchOption = "Case #";
      //       //   controller.showResults = false;
      //       //   scope.failureResponse = false;
      //       //   expect(controller.optionCase).toBeDefined();
      //       //   controller.optionCase();
      //       // });


      //       // it(' should call optionTrials', function () {
      //       //   scope.searchThis = ""
      //       //   scope.searchTerm = "TRIAL_NUMBER";
      //       //   scope.searchOption = "AIA Trails #";
      //       //   controller.showResults = false;
      //       //   scope.failureResponse = false;
      //       //   expect(controller.optionTrials).toBeDefined();
      //       //   controller.optionTrials();
      //       // });

      //       // it(' should call optionApplication', function () {
      //       //   scope.searchThis = ""
      //       //   scope.searchTerm = "APPLICATION_NUMBER";
      //       //   scope.searchOption = "Application #";
      //       //   controller.showResults = false;
      //       //   scope.failureResponse = false;
      //       //   expect(controller.optionApplication).toBeDefined();
      //       //   controller.optionApplication();
      //       // });

      //       // it(' should call optionPatent', function () {
      //       //   scope.searchThis = ""
      //       //   scope.searchTerm = "PATENt_NUMBER";
      //       //   scope.searchOption = "Patent #";
      //       //   controller.showResults = false;
      //       //   scope.failureResponse = false;
      //       //   expect(controller.optionPatent).toBeDefined();
      //       //   controller.optionPatent();
      //       // });

      //       // it(' should call numberLook', function () {
      //       //   controller.showResults = false;
      //       //   controller.noNumberSelected = false;
      //       //   scope.failureResponse = false;
      //       //   expect(controller.numberLook).toBeDefined();
      //       //   controller.numberLook();
      //       // });

      //       // it(' should call advancedSearch', function () {
      //       //   scope.searchTotalLength = 0;
      //       //   scope.failureResponse = false;
      //       //   controller.displayNone = true;
      //       //   controller.gridOptions.data = [];
      //       //   scope.searchThis = ""
      //       //   controller.showResults = false;
      //       //   controller.noNumberSelected = true;
      //       //   expect(controller.advancedSearch).toBeDefined();
      //       //   controller.advancedSearch();
      //       // });

      //       // it(' should call advancedSearch success', function () {
      //       //   controller.gridOptions.data = [];
      //       //   var successResponse = {
      //       //     data: [{
      //       //       "searchNumbers": {
      //       //         "serialNumber": "90008169",
      //       //         "appealNumber": "545666",
      //       //         "patentNumber": "RE34783",
      //       //         "trialsNumber": "2020000030"
      //       //       }
      //       //     }]
      //       //   };
      //       //   //  controller.gridOptions = {
      //       //   //       data: [{
      //       //   //         "searchNumbers": {
      //       //   //           "serialNumber": "90008169",
      //       //   //           "appealNumber": "545666",
      //       //   //           "patentNumber": "RE34783",
      //       //   //           "trialsNumber": "2020000030"
      //       //   //         }
      //       //   //       }]
      //       //   //     };
      //       //   scope.searchTotalLength = 3;
      //       //   scope.searchTotalLength = 0;
      //       //   scope.failureResponse = false;
      //       //   controller.displayNone = true;
      //       //   controller.gridOptions.data = [];
      //       //   scope.searchThis = "hjhh"
      //       //   expect(controller.advancedSearch).toBeDefined();
      //       //   controller.advancedSearch();
      //       //   HttpFactoryDeferred.resolve(successResponse);
      //       //   scope.$digest();
      //       // });

    });
  });
})();
