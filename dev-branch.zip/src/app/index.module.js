(function () {
  'use strict';

  angular
    .module('ptabe2e', ['ngAnimate', 'ngCookies', 'ngTouch', 'ngSanitize', 'ngMessages', 'ngAria', 'ngResource', 'ngRoute', 'ui.bootstrap', 'toastr', 'adf', 'adf.widget.viewCaseDockets', 'adf.widget.announcements', 'adf.widget.systemStatus', 'adf.widget.exportCaseDockets',
      'adf.widget.assignmentBasedDocket', 'adf.widget.assignments', 'adf.widget.reportCenter', 'adf.widget.updateTasks', 'adf.widget.myFavorites', 'adf.widget.masterDocket', 'adf.widget.myProduction', 'adf.widget.myCredits', 'adf.widget.workQueue', 'adf.widget.myCreditsPl', 'adf.widget.myCreditsPA', 'adf.widget.myCreditsJudge', 'adf.widget.dynamicViewCaseDockets', 'adf.widget.appealsCaseDocket', 'adf.widget.trialsCaseDocket', 'ui.sortable', 'ngDialog', 'ui.grid', 'ui.grid.selection', 'ui.grid.pinning', 'ui.grid.cellNav', 'ui.grid.pagination',
      'ui.grid.moveColumns', 'ui.grid.resizeColumns', 'ui.grid.saveState', 'ui.grid.autoResize', 'ui.grid.edit', 'ui.tinymce', 'ui.grid.exporter', 'angularjs-dropdown-multiselect', 'ui.grid.cellNav', 'adf.widget.quarterlyCloseout'
    ])
    .factory('context', function ($location, CONSTANTS) {

      // Revision 1711

      var protocol = $location.protocol() + '://';
      var host = $location.host();
      var port = $location.port();
      var base = CONSTANTS.URL.BASE;

      if ($location.host() === 'localhost') {
        //return 'http://localhost:8080';
         return 'https://ptabe2eint-fqt.etc.uspto.gov/PTABAppealsServices';
        // return 'https://ptab-services1.sit.uspto.gov/PTABAppealsServices';
        // return 'https://ptabe2eint-pvt.etc.uspto.gov/PTABAppealsServices';
        // return 'https://ptabe2eint-fqt.etc.uspto.gov/PTABAppealsServices';
        // + base;
        //return 'https://ptab-q318-services-eap-0.sit.uspto.gov:8443' + base;
      } else {
        return protocol + host + ":" + port + base;
      }

    })
    .factory('getURL', function (context) {
      return function (url) {
        return context + url;
      };
    });

})();
